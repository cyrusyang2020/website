/* See license.txt for terms of usage */

define(
{
    "root": {
        "homeTabLabel": "Load",
        "loadingHar": "Loading..."
    }
});
