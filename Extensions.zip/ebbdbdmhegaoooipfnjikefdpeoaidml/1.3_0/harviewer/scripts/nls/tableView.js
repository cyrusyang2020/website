/* See license.txt for terms of usage */

define(
{
    "root": {
        "objectProperties": "Object Properties"
    }
});
