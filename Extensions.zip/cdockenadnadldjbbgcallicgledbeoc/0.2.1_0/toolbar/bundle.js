const sugar = {
  on: function(names, fn) {
    names
      .split(' ')
      .forEach(name =>
        this.addEventListener(name, fn));
    return this
  },
  off: function(names, fn) {
    names
      .split(' ')
      .forEach(name =>
        this.removeEventListener(name, fn));
    return this
  },
  attr: function(attr, val) {
    if (val === undefined) return this.getAttribute(attr)

    val == null
      ? this.removeAttribute(attr)
      : this.setAttribute(attr, val || '');
      
    return this
  }
};

function $(query, $context = document) {
  let $nodes = query instanceof NodeList || Array.isArray(query)
    ? query
    : query instanceof HTMLElement || query instanceof SVGElement
      ? [query]
      : $context.querySelectorAll(query);

  if (!$nodes.length) $nodes = [];

  return Object.assign(
    [...$nodes].map($el => Object.assign($el, sugar)), 
    {
      on: function(names, fn) {
        this.forEach($el => $el.on(names, fn));
        return this
      },
      off: function(names, fn) {
        this.forEach($el => $el.off(names, fn));
        return this
      },
      attr: function(attrs, val) {
        if (typeof attrs === 'string' && val === undefined)
          return this[0].attr(attrs)

        else if (typeof attrs === 'object') 
          this.forEach($el =>
            Object.entries(attrs)
              .forEach(([key, val]) =>
                $el.attr(key, val)));

        else if (typeof attrs == 'string' && (val || val == null || val == ''))
          this.forEach($el => $el.attr(attrs, val));

        return this
      }
    }
  )
}

/*!
 * hotkeys-js v3.3.5
 * A simple micro-library for defining and dispatching keyboard shortcuts. It has no dependencies.
 * 
 * Copyright (c) 2018 kenny wong <wowohoo@qq.com>
 * http://jaywcjlove.github.io/hotkeys
 * 
 * Licensed under the MIT license.
 */

var isff = typeof navigator !== 'undefined' ? navigator.userAgent.toLowerCase().indexOf('firefox') > 0 : false;

// 绑定事件
function addEvent(object, event, method) {
  if (object.addEventListener) {
    object.addEventListener(event, method, false);
  } else if (object.attachEvent) {
    object.attachEvent('on' + event, function () {
      method(window.event);
    });
  }
}

// 修饰键转换成对应的键码
function getMods(modifier, key) {
  var mods = key.slice(0, key.length - 1);
  for (var i = 0; i < mods.length; i++) {
    mods[i] = modifier[mods[i].toLowerCase()];
  }return mods;
}

// 处理传的key字符串转换成数组
function getKeys(key) {
  if (!key) key = '';

  key = key.replace(/\s/g, ''); // 匹配任何空白字符,包括空格、制表符、换页符等等
  var keys = key.split(','); // 同时设置多个快捷键，以','分割
  var index = keys.lastIndexOf('');

  // 快捷键可能包含','，需特殊处理
  for (; index >= 0;) {
    keys[index - 1] += ',';
    keys.splice(index, 1);
    index = keys.lastIndexOf('');
  }

  return keys;
}

// 比较修饰键的数组
function compareArray(a1, a2) {
  var arr1 = a1.length >= a2.length ? a1 : a2;
  var arr2 = a1.length >= a2.length ? a2 : a1;
  var isIndex = true;

  for (var i = 0; i < arr1.length; i++) {
    if (arr2.indexOf(arr1[i]) === -1) isIndex = false;
  }
  return isIndex;
}

var _keyMap = { // 特殊键
  backspace: 8,
  tab: 9,
  clear: 12,
  enter: 13,
  return: 13,
  esc: 27,
  escape: 27,
  space: 32,
  left: 37,
  up: 38,
  right: 39,
  down: 40,
  del: 46,
  delete: 46,
  ins: 45,
  insert: 45,
  home: 36,
  end: 35,
  pageup: 33,
  pagedown: 34,
  capslock: 20,
  '⇪': 20,
  ',': 188,
  '.': 190,
  '/': 191,
  '`': 192,
  '-': isff ? 173 : 189,
  '=': isff ? 61 : 187,
  ';': isff ? 59 : 186,
  '\'': 222,
  '[': 219,
  ']': 221,
  '\\': 220
};

var _modifier = { // 修饰键
  '⇧': 16,
  shift: 16,
  '⌥': 18,
  alt: 18,
  option: 18,
  '⌃': 17,
  ctrl: 17,
  control: 17,
  '⌘': isff ? 224 : 91,
  cmd: isff ? 224 : 91,
  command: isff ? 224 : 91
};
var _downKeys = []; // 记录摁下的绑定键
var modifierMap = {
  16: 'shiftKey',
  18: 'altKey',
  17: 'ctrlKey'
};
var _mods = { 16: false, 18: false, 17: false };
var _handlers = {};

// F1~F12 特殊键
for (var k = 1; k < 20; k++) {
  _keyMap['f' + k] = 111 + k;
}

// 兼容Firefox处理
modifierMap[isff ? 224 : 91] = 'metaKey';
_mods[isff ? 224 : 91] = false;

var _scope = 'all'; // 默认热键范围
var isBindElement = false; // 是否绑定节点

// 返回键码
var code = function code(x) {
  return _keyMap[x.toLowerCase()] || x.toUpperCase().charCodeAt(0);
};

// 设置获取当前范围（默认为'所有'）
function setScope(scope) {
  _scope = scope || 'all';
}
// 获取当前范围
function getScope() {
  return _scope || 'all';
}
// 获取摁下绑定键的键值
function getPressedKeyCodes() {
  return _downKeys.slice(0);
}

// 表单控件控件判断 返回 Boolean
function filter(event) {
  var tagName = event.target.tagName || event.srcElement.tagName;
  // 忽略这些标签情况下快捷键无效
  return !(tagName === 'INPUT' || tagName === 'SELECT' || tagName === 'TEXTAREA');
}

// 判断摁下的键是否为某个键，返回true或者false
function isPressed(keyCode) {
  if (typeof keyCode === 'string') {
    keyCode = code(keyCode); // 转换成键码
  }
  return _downKeys.indexOf(keyCode) !== -1;
}

// 循环删除handlers中的所有 scope(范围)
function deleteScope(scope, newScope) {
  var handlers = void 0;
  var i = void 0;

  // 没有指定scope，获取scope
  if (!scope) scope = getScope();

  for (var key in _handlers) {
    if (Object.prototype.hasOwnProperty.call(_handlers, key)) {
      handlers = _handlers[key];
      for (i = 0; i < handlers.length;) {
        if (handlers[i].scope === scope) handlers.splice(i, 1);else i++;
      }
    }
  }

  // 如果scope被删除，将scope重置为all
  if (getScope() === scope) setScope(newScope || 'all');
}

// 清除修饰键
function clearModifier(event) {
  var key = event.keyCode || event.which || event.charCode;
  var i = _downKeys.indexOf(key);

  // 从列表中清除按压过的键
  if (i >= 0) _downKeys.splice(i, 1);

  // 修饰键 shiftKey altKey ctrlKey (command||metaKey) 清除
  if (key === 93 || key === 224) key = 91;
  if (key in _mods) {
    _mods[key] = false;

    // 将修饰键重置为false
    for (var k in _modifier) {
      if (_modifier[k] === key) hotkeys[k] = false;
    }
  }
}

// 解除绑定某个范围的快捷键
function unbind(key, scope) {
  var multipleKeys = getKeys(key);
  var keys = void 0;
  var mods = [];
  var obj = void 0;

  for (var i = 0; i < multipleKeys.length; i++) {
    // 将组合快捷键拆分为数组
    keys = multipleKeys[i].split('+');

    // 记录每个组合键中的修饰键的键码 返回数组
    if (keys.length > 1) mods = getMods(_modifier, keys);

    // 获取除修饰键外的键值key
    key = keys[keys.length - 1];
    key = key === '*' ? '*' : code(key);

    // 判断是否传入范围，没有就获取范围
    if (!scope) scope = getScope();

    // 如何key不在 _handlers 中返回不做处理
    if (!_handlers[key]) return;

    // 清空 handlers 中数据，
    // 让触发快捷键键之后没有事件执行到达解除快捷键绑定的目的
    for (var r = 0; r < _handlers[key].length; r++) {
      obj = _handlers[key][r];
      // 判断是否在范围内并且键值相同
      if (obj.scope === scope && compareArray(obj.mods, mods)) {
        _handlers[key][r] = {};
      }
    }
  }
}

// 对监听对应快捷键的回调函数进行处理
function eventHandler(event, handler, scope) {
  var modifiersMatch = void 0;

  // 看它是否在当前范围
  if (handler.scope === scope || handler.scope === 'all') {
    // 检查是否匹配修饰符（如果有返回true）
    modifiersMatch = handler.mods.length > 0;

    for (var y in _mods) {
      if (Object.prototype.hasOwnProperty.call(_mods, y)) {
        if (!_mods[y] && handler.mods.indexOf(+y) > -1 || _mods[y] && handler.mods.indexOf(+y) === -1) modifiersMatch = false;
      }
    }

    // 调用处理程序，如果是修饰键不做处理
    if (handler.mods.length === 0 && !_mods[16] && !_mods[18] && !_mods[17] && !_mods[91] || modifiersMatch || handler.shortcut === '*') {
      if (handler.method(event, handler) === false) {
        if (event.preventDefault) event.preventDefault();else event.returnValue = false;
        if (event.stopPropagation) event.stopPropagation();
        if (event.cancelBubble) event.cancelBubble = true;
      }
    }
  }
}

// 处理keydown事件
function dispatch(event) {
  var asterisk = _handlers['*'];
  var key = event.keyCode || event.which || event.charCode;

  // 搜集绑定的键
  if (_downKeys.indexOf(key) === -1) _downKeys.push(key);

  // Gecko(Firefox)的command键值224，在Webkit(Chrome)中保持一致
  // Webkit左右command键值不一样
  if (key === 93 || key === 224) key = 91;

  if (key in _mods) {
    _mods[key] = true;

    // 将特殊字符的key注册到 hotkeys 上
    for (var k in _modifier) {
      if (_modifier[k] === key) hotkeys[k] = true;
    }

    if (!asterisk) return;
  }

  // 将modifierMap里面的修饰键绑定到event中
  for (var e in _mods) {
    if (Object.prototype.hasOwnProperty.call(_mods, e)) {
      _mods[e] = event[modifierMap[e]];
    }
  }

  // 表单控件过滤 默认表单控件不触发快捷键
  if (!hotkeys.filter.call(this, event)) return;

  // 获取范围 默认为all
  var scope = getScope();

  // 对任何快捷键都需要做的处理
  if (asterisk) {
    for (var i = 0; i < asterisk.length; i++) {
      if (asterisk[i].scope === scope) eventHandler(event, asterisk[i], scope);
    }
  }
  // key 不在_handlers中返回
  if (!(key in _handlers)) return;

  for (var _i = 0; _i < _handlers[key].length; _i++) {
    // 找到处理内容
    eventHandler(event, _handlers[key][_i], scope);
  }
}

function hotkeys(key, option, method) {
  var keys = getKeys(key); // 需要处理的快捷键列表
  var mods = [];
  var scope = 'all'; // scope默认为all，所有范围都有效
  var element = document; // 快捷键事件绑定节点
  var i = 0;

  // 对为设定范围的判断
  if (method === undefined && typeof option === 'function') {
    method = option;
  }

  if (Object.prototype.toString.call(option) === '[object Object]') {
    if (option.scope) scope = option.scope; // eslint-disable-line
    if (option.element) element = option.element; // eslint-disable-line
  }

  if (typeof option === 'string') scope = option;

  // 对于每个快捷键进行处理
  for (; i < keys.length; i++) {
    key = keys[i].split('+'); // 按键列表
    mods = [];

    // 如果是组合快捷键取得组合快捷键
    if (key.length > 1) mods = getMods(_modifier, key);

    // 将非修饰键转化为键码
    key = key[key.length - 1];
    key = key === '*' ? '*' : code(key); // *表示匹配所有快捷键

    // 判断key是否在_handlers中，不在就赋一个空数组
    if (!(key in _handlers)) _handlers[key] = [];

    _handlers[key].push({
      scope: scope,
      mods: mods,
      shortcut: keys[i],
      method: method,
      key: keys[i]
    });
  }
  // 在全局document上设置快捷键
  if (typeof element !== 'undefined' && !isBindElement) {
    isBindElement = true;
    addEvent(element, 'keydown', function (e) {
      dispatch(e);
    });
    addEvent(element, 'keyup', function (e) {
      clearModifier(e);
    });
  }
}

var _api = {
  setScope: setScope,
  getScope: getScope,
  deleteScope: deleteScope,
  getPressedKeyCodes: getPressedKeyCodes,
  isPressed: isPressed,
  filter: filter,
  unbind: unbind
};
for (var a in _api) {
  if (Object.prototype.hasOwnProperty.call(_api, a)) {
    hotkeys[a] = _api[a];
  }
}

if (typeof window !== 'undefined') {
  var _hotkeys = window.hotkeys;
  hotkeys.noConflict = function (deep) {
    if (deep && window.hotkeys === hotkeys) {
      window.hotkeys = _hotkeys;
    }
    return hotkeys;
  };
  window.hotkeys = hotkeys;
}

var css = ":host {\n  --theme-bg: hsl(0,0%,100%);\n  --theme-color: hotpink;\n  --theme-blue: hsl(188, 90%, 45%);\n  --theme-purple: hsl(267, 100%, 58%);\n  --theme-icon_color: hsl(0,0%,20%);\n  --theme-icon_hover-bg: hsl(0,0%,95%);\n}\n\n:host {\n  position: fixed;\n  top: 0;\n  left: 0;\n  z-index: 2147483646;\n  font-size: 16px;\n  font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;\n}\n\n:host > ol {\n  display: flex;\n  flex-direction: column;\n  margin: 1em 0 0.5em 1em;\n  padding: 0;\n  list-style-type: none;\n  border-radius: 2em\n}\n\n:host > ol:not([colors]) {\n    box-shadow: 0 0.25em 0.5em hsla(0,0%,0%,10%);\n    background: var(--theme-bg);\n  }\n\n:host li {\n  height: 2.25em;\n  width: 2.25em;\n  margin: 0.05em 0.25em;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  position: relative;\n  border-radius: 50%\n}\n\n:host li:first-child { margin-top: 0.25em; }\n\n:host li:last-child { margin-bottom: 0.25em; }\n\n:host li[data-tool]:hover {\n      cursor: pointer;\n      background-color: var(--theme-icon_hover-bg);\n    }\n\n:host li[data-tool]:active {\n      background-color: hsl(0,0%,90%);\n    }\n\n:host li[data-active=true] > svg:not(.icon-cursor) {\n    fill: var(--theme-color);\n  }\n\n:host li[data-active=true] > .icon-cursor {\n    stroke: var(--theme-color);\n  }\n\n@media (max-height: 768px) {\n    :host li:nth-of-type(10) > aside, :host li:nth-of-type(11) > aside, :host li:nth-of-type(12) > aside, :host li:nth-of-type(13) > aside {\n      top: auto;\n    }\n  }\n\n:host li > aside {\n    overflow: hidden;\n    position: absolute;\n    direction: ltr;\n    text-align: left;\n    left: 3em;\n    top: 0;\n    z-index: -2;\n    pointer-events: none;\n    background: white;\n    color: hsl(0,0%,30%);\n    box-shadow: 0 0.1em 4.5em hsla(0,0%,0%,15%);\n    border-radius: 1em;\n\n    transition: opacity 0.3s ease, -webkit-transform 0.2s ease;\n\n    transition: opacity 0.3s ease, transform 0.2s ease;\n\n    transition: opacity 0.3s ease, transform 0.2s ease, -webkit-transform 0.2s ease;\n    opacity: 0;\n    -webkit-transform: translateX(-1em);\n            transform: translateX(-1em);\n    will-change: transform, opacity\n  }\n\n:host li > aside > figure {\n      margin: 0;\n      display: grid;\n    }\n\n:host li > aside figcaption {\n      padding: 1em;\n      display: grid;\n      grid-gap: 0.5em\n    }\n\n:host li > aside figcaption > h2, :host li > aside figcaption > p {\n        margin: 0;\n      }\n\n:host li > aside figcaption > h2 {\n        font-size: 1.5em;\n        line-height: 1.1;\n        margin-bottom: 0.5em;\n        display: grid;\n        grid-auto-flow: column;\n        justify-content: space-between;\n        align-items: center;\n      }\n\n:host li > aside figcaption > p {\n        font-size: 1em;\n        line-height: 1.5;\n        padding-right: 3em;\n      }\n\n:host li > aside figcaption [table] {\n        display: grid;\n        grid-gap: 0.5em\n      }\n\n:host li > aside figcaption [table] > div {\n          display: grid;\n          grid-auto-flow: column;\n          grid-template-columns: 1fr auto;\n          justify-content: space-between;\n        }\n\n:host li > aside [hotkey] {\n      border-radius: 5em;\n      height: 1.5em;\n      width: 1.5em;\n      display: inline-flex;\n      align-items: center;\n      justify-content: center;\n      border: 1px solid var(--theme-color);\n      color: var(--theme-color);\n      font-weight: 300;\n      font-size: 0.5em;\n      text-transform: uppercase;\n    }\n\n:host li:hover:not([data-tool=\"search\"]) > aside,\n  :host li[data-tool=\"search\"] > svg:hover + aside {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n            transform: translateX(0);\n    transition-delay: 0.75s;\n  }\n\n:host li input::-webkit-calendar-picker-indicator {\n    background: inherit;\n    color: var(--theme-color);\n  }\n\n:host [colors] {\n  margin-top: 0;\n}\n\n:host [colors] > li {\n  overflow: hidden;\n  border-radius: 50%;\n  box-shadow: 0 0.25em 0.5em hsla(0,0%,0%,10%);\n  background: var(--theme-bg);\n  margin-bottom: 0.5em\n}\n\n:host [colors] > li:first-child {\n    margin-top: 0;\n  }\n\n:host [colors] li:hover:after {\n  top: 0;\n}\n\n:host li > svg {\n  width: 50%;\n  fill: var(--theme-icon_color);\n}\n\n:host li > svg.icon-cursor {\n  width: 35%;\n  fill: white;\n  stroke: var(--theme-icon_color);\n  stroke-width: 2px;\n}\n\n:host li[data-tool=\"search\"][data-active=\"true\"]:before {\n    -webkit-transform: translateX(-1em);\n            transform: translateX(-1em);\n    opacity: 0;\n  }\n\n:host li[data-tool=\"search\"] > .search {\n  position: absolute;\n  left: calc(100% - 1.25em);\n  top: 0;\n  height: 100%;\n  z-index: -1;\n  box-shadow: 0 0.25em 0.5em hsla(0,0%,0%,10%);\n  border-radius: 0 2em 2em 0;\n  overflow: hidden;\n}\n\n:host li[data-tool=\"search\"] > .search > input {\n  direction: ltr;\n  border: none;\n  font-size: 1em;\n  padding: 0.4em 0.4em 0.4em 2em;\n  outline: none;\n  height: 100%;\n  width: 250px;\n  box-sizing: border-box;\n  caret-color: hotpink\n}\n\n:host li[data-tool=\"search\"] > .search > input::-webkit-input-placeholder {\n    font-weight: lighter;\n    font-size: 0.8em;\n  }\n\n:host li[data-tool=\"search\"] > .search > input::-ms-input-placeholder {\n    font-weight: lighter;\n    font-size: 0.8em;\n  }\n\n:host li[data-tool=\"search\"] > .search > input::placeholder {\n    font-weight: lighter;\n    font-size: 0.8em;\n  }\n\n:host [colors] > li > svg {\n  position: relative;\n  top: -2px;\n}\n\n:host [colors] > li > svg > rect:last-child {\n  stroke: hsla(0,0%,0%,20%);\n  stroke-width: 0.5px;\n}\n\n:host input[type='color'] {\n  opacity: 0.01;\n  position: absolute;\n  top: 0; left: 0;\n  width: 100%; height: 100%;\n  z-index: 1;\n  box-sizing: border-box;\n  border: white;\n  padding: 0;\n  cursor: pointer;\n}\n\n:host input[type='color']:focus {\n  outline: none;\n}\n\n:host input[type='color']::-webkit-color-swatch-wrapper {\n  padding: 0;\n}\n\n:host input[type='color']::-webkit-color-swatch {\n  border: none;\n}\n\n:host input[type='color'][value='']::-webkit-color-swatch {\n  background-color: transparent !important;\n  background-image: linear-gradient(155deg, #ffffff 0%,#ffffff 46%,#ff0000 46%,#ff0000 54%,#ffffff 55%,#ffffff 100%);\n}\n";

class Handles extends HTMLElement {

  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'closed'});
  }

  connectedCallback() {
    window.addEventListener('resize', this.on_resize.bind(this));
  }
  disconnectedCallback() {
    window.removeEventListener('resize', this.on_resize);
  }

  on_resize() {
    window.requestAnimationFrame(() => {
      const node_label_id = this.$shadow.host.getAttribute('data-label-id');
      const [source_el] = $(`[data-label-id="${node_label_id}"]`);

      if (!source_el) return

      this.position = {
        node_label_id,
        boundingRect: source_el.getBoundingClientRect(),
      };
    });
  }

  set position({boundingRect, node_label_id}) {
    this.$shadow.innerHTML  = this.render(boundingRect, node_label_id);
  }

  render({ x, y, width, height, top, left }, node_label_id) {
    this.$shadow.host.setAttribute('data-label-id', node_label_id);
    return `
      ${this.styles({top,left})}
      <svg
        class="visbug-handles"
        width="${width}" height="${height}"
        viewBox="0 0 ${width} ${height}"
        version="1.1" xmlns="http://www.w3.org/2000/svg"
      >
        <rect stroke="hotpink" fill="none" width="100%" height="100%"></rect>
        <circle stroke="hotpink" fill="white" cx="0" cy="0" r="2"></circle>
        <circle stroke="hotpink" fill="white" cx="100%" cy="0" r="2"></circle>
        <circle stroke="hotpink" fill="white" cx="100%" cy="100%" r="2"></circle>
        <circle stroke="hotpink" fill="white" cx="0" cy="100%" r="2"></circle>
        <circle fill="hotpink" cx="${width/2}" cy="0" r="2"></circle>
        <circle fill="hotpink" cx="0" cy="${height/2}" r="2"></circle>
        <circle fill="hotpink" cx="${width/2}" cy="${height}" r="2"></circle>
        <circle fill="hotpink" cx="${width}" cy="${height/2}" r="2"></circle>
      </svg>
    `
  }

  styles({top,left}) {
    return `
      <style>
        :host > svg {
          position: absolute;
          top: ${top + window.scrollY}px;
          left: ${left}px;
          overflow: visible;
          pointer-events: none;
          z-index: 2147483644;
        }
      </style>
    `
  }
}

customElements.define('visbug-handles', Handles);

class Hover extends Handles {

  constructor() {
    super();
  }

  render({ x, y, width, height, top, left }) {
    return `
      ${this.styles({top,left})}
      <style>
        :host rect {
          width: 100%;
          height: 100%;
          vector-effect: non-scaling-stroke;
          stroke: hsl(267, 100%, 58%);
          stroke-width: 1px;
          fill: none;
        }

        :host > svg {
          z-index: 2147483642;
        }
      </style>
      <svg width="${width}" height="${height}">
        <rect></rect>
      </svg>
    `
  }
}

customElements.define('visbug-hover', Hover);

class Label extends HTMLElement {

  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'closed'});
  }

  connectedCallback() {
    $('a', this.$shadow).on('click mouseenter', this.dispatchQuery.bind(this));
    window.addEventListener('resize', this.on_resize.bind(this));
  }

  disconnectedCallback() {
    $('a', this.$shadow).off('click', this.dispatchQuery);
    window.removeEventListener('resize', this.on_resize);
  }

  on_resize() {
    window.requestAnimationFrame(() => {
      const node_label_id = this.$shadow.host.getAttribute('data-label-id');
      const [source_el]   = $(`[data-label-id="${node_label_id}"]`);

      if (!source_el) return

      this.position = {
        node_label_id,
        boundingRect: source_el.getBoundingClientRect(),
      };
    });
  }

  dispatchQuery(e) {
    this.$shadow.host.dispatchEvent(new CustomEvent('query', {
      bubbles: true,
      detail:   {
        text:       e.target.textContent,
        activator:  e.type,
      }
    }));
  }

  set text(content) {
    this._text = content;
  }

  set position({boundingRect, node_label_id}) {
    this.$shadow.innerHTML  = this.render(boundingRect, node_label_id);
  }

  set update({x,y}) {
    const label = this.$shadow.children[1];
    label.style.top  = y + window.scrollY + 'px';
    label.style.left = x - 1 + 'px';
  }

  render({ x, y, width, height, top, left }, node_label_id) {
    this.$shadow.host.setAttribute('data-label-id', node_label_id);

    return `
      ${this.styles({top,left,width})}
      <span>
        ${this._text}
      </span>
    `
  }

  styles({top,left,width}) {
    return `
      <style>
        :host {
          font-size: 16px;
        }

        :host > span {
          position: absolute;
          top: ${top + window.scrollY}px;
          left: ${left - 1}px;
          max-width: ${width + (window.innerWidth - left - width - 20)}px;
          z-index: 2147483643;
          transform: translateY(-100%);
          background: var(--label-bg, hotpink);
          border-radius: 0.2em 0.2em 0 0;
          text-shadow: 0 0.5px 0 hsla(0, 0%, 0%, 0.4);
          color: white;
          display: inline-flex;
          justify-content: center;
          font-size: 0.8em;
          font-weight: normal;
          font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;
          white-space: nowrap;
          padding: 0.25em 0.4em 0.15em;
          line-height: 1.1;
        }

        :host a {
          text-decoration: none;
          color: inherit;
          cursor: pointer;
          text-overflow: ellipsis;
          overflow: hidden;
        }

        :host a:hover {
          text-decoration: underline;
          color: white;
        }

        :host a[node]:before {
          content: "\\003c";
        }

        :host a[node]:after {
          content: "\\003e";
        }
      </style>
    `
  }
}

customElements.define('visbug-label', Label);

const desiredPropMap = {
  color:               'rgb(0, 0, 0)',
  backgroundColor:     'rgba(0, 0, 0, 0)',
  backgroundImage:     'none',
  backgroundSize:      'auto',
  backgroundPosition:  '0% 0%',
  // borderColor:      'rgb(0, 0, 0)',
  borderWidth:         '0px',
  borderRadius:        '0px',
  boxShadow:           'none',
  padding:             '0px',
  margin:              '0px',
  fontFamily:          '',
  fontSize:            '16px',
  fontWeight:          '400',
  textAlign:           'start',
  textShadow:          'none',
  textTransform:       'none',
  lineHeight:          'normal',
  letterSpacing:       'normal',
  display:             'block',
  alignItems:          'normal',
  justifyContent:      'normal',
  flexDirection:       'row',
  flexWrap:            'nowrap',
  flexBasis:           'auto',
  // flexFlow:         'none',
  fill:                'rgb(0, 0, 0)',
  stroke:              'none',
  gridTemplateColumns: 'none',
  gridAutoColumns:     'auto',
  gridTemplateRows:    'none',
  gridAutoRows:        'auto',
  gridTemplateAreas:   'none',
  gridArea:            'auto / auto / auto / auto',
  gap:                 'normal normal',
  gridAutoFlow:        'row',
};

const desiredAccessibilityMap = [
  'role',
  'tabindex',
  'aria-*',
  'for',
  'alt',
  'title',
  'type',
];

const largeWCAG2TextMap = [
  {
    fontSize: '24px',
    fontWeight: '0'
  },
  {
    fontSize: '18.5px',
    fontWeight: '700'
  }
];

const getStyle = (el, name) => {
  if (document.defaultView && document.defaultView.getComputedStyle) {
    name = name.replace(/([A-Z])/g, '-$1');
    name = name.toLowerCase();
    let s = document.defaultView.getComputedStyle(el, '');
    return s && s.getPropertyValue(name)
  } 
};

const getStyles = el => {
  const elStyleObject = el.style;
  const computedStyle = window.getComputedStyle(el, null);

  let desiredValues = [];

  for (prop in el.style)
    if (prop in desiredPropMap && desiredPropMap[prop] != computedStyle[prop])
      desiredValues.push({
        prop,
        value: computedStyle[prop].replace(/, rgba/g, '\rrgba')
      });

  return desiredValues
};

const getComputedBackgroundColor = el => {
  let background = getStyle(el, 'background-color');

  if (background === 'rgba(0, 0, 0, 0)') {
    let node  = findNearestParentElement(el)
      , found = false;

    while(!found) {
      let bg  = getStyle(node, 'background-color');

      if (bg !== 'rgba(0, 0, 0, 0)') {
        found = true;
        background = bg;
      }

      node = findNearestParentElement(node);

      if (node.nodeName === 'HTML') {
        found = true;
        background = 'white';
      }
    }
  }

  return background
};

const findNearestParentElement = el =>
  el.parentNode && el.parentNode.nodeType === 1
    ? el.parentNode
    : el.parentNode.nodeName === '#document-fragment'
      ? el.parentNode.host
      : el.parentNode.parentNode.host;

const findNearestChildElement = el => {
  if (el.shadowRoot && el.shadowRoot.children.length) {
    return [...el.shadowRoot.children]
      .filter(({nodeName}) => 
        !['LINK','STYLE','SCRIPT','HTML','HEAD'].includes(nodeName)
      )[0]
  }
  else if (el.children.length)
    return el.children[0]
};

const loadStyles = async stylesheets => {
  const fetches = await Promise.all(stylesheets.map(url => fetch(url)));
  const texts   = await Promise.all(fetches.map(url => url.text()));
  const style   = document.createElement('style');

  style.textContent = texts.reduce((styles, fileContents) => 
    styles + fileContents
  , '');

  document.head.appendChild(style);
};

const getA11ys = el => {
  const elAttributes = el.getAttributeNames();

  return desiredAccessibilityMap.reduce((acc, attribute) => {
    if (elAttributes.includes(attribute))
      acc.push({
        prop:   attribute,
        value:  el.getAttribute(attribute)
      });

    if (attribute === 'aria-*')
      elAttributes.forEach(attr => {
        if (attr.includes('aria'))
          acc.push({
            prop:   attr,
            value:  el.getAttribute(attr)
          });
      });

    return acc
  }, [])
};

const getWCAG2TextSize = el => {
  
  const styles = getStyles(el).reduce((styleMap, style) => {
      styleMap[style.prop] = style.value;
      return styleMap
  }, {});

  const { fontSize   = desiredPropMap.fontSize,
          fontWeight = desiredPropMap.fontWeight
      } = styles;
  
  const isLarge = largeWCAG2TextMap.some(
    (largeProperties) => parseFloat(fontSize) >= parseFloat(largeProperties.fontSize) 
       && parseFloat(fontWeight) >= parseFloat(largeProperties.fontWeight) 
  );

  return  isLarge ? 'Large' : 'Small'
};

const camelToDash = (camelString = "") =>
  camelString.replace(/([A-Z])/g, ($1) =>
    "-"+$1.toLowerCase());

const nodeKey = node => {
  let tree = [];
  let furthest_leaf = node;

  while (furthest_leaf) {
    tree.push(furthest_leaf);
    furthest_leaf = furthest_leaf.parentNode
      ? furthest_leaf.parentNode
      : false;
  }

  return tree.reduce((path, branch) => `
    ${path}${branch.tagName}_${branch.className}_${[...node.parentNode.children].indexOf(node)}_${node.children.length}
  `, '')
};

const createClassname = (el, ellipse = false) => {
  if (!el.className) return ''
  
  const combined = Array.from(el.classList).reduce((classnames, classname) =>
    classnames += '.' + classname
  , '');

  return ellipse && combined.length > 30
    ? combined.substring(0,30) + '...'
    : combined
};

const metaKey = window.navigator.platform.includes('Mac')
  ? 'cmd'
  : 'ctrl';

const altKey = window.navigator.platform.includes('Mac')
  ? 'opt'
  : 'alt';

const deepElementFromPoint = (x, y) => {
  const el = document.elementFromPoint(x, y);

  const crawlShadows = node => {
    if (node.shadowRoot) {
      const potential = node.shadowRoot.elementFromPoint(x, y);

      if (potential == node)          return node
      else if (potential.shadowRoot)  return crawlShadows(potential)
      else                            return potential
    }
    else return node
  };

  const nested_shadow = crawlShadows(el);

  return nested_shadow || el
};

const getSide = direction => {
  let start = direction.split('+').pop().replace(/^\w/, c => c.toUpperCase());
  if (start == 'Up') start = 'Top';
  if (start == 'Down') start = 'Bottom';
  return start
};

const getNodeIndex = el => {
  return [...el.parentElement.parentElement.children]
    .indexOf(el.parentElement)
};

function showEdge(el) {
  return el.animate([
    { outline: '1px solid transparent' },
    { outline: '1px solid hsla(330, 100%, 71%, 80%)' },
    { outline: '1px solid transparent' },
  ], 600)
}

let timeoutMap = {};
const showHideSelected = (el, duration = 750) => {
  el.setAttribute('data-selected-hide', true);
  showHideNodeLabel(el, true);

  if (timeoutMap[nodeKey(el)])
    clearTimeout(timeoutMap[nodeKey(el)]);

  timeoutMap[nodeKey(el)] = setTimeout(_ => {
    el.removeAttribute('data-selected-hide');
    showHideNodeLabel(el, false);
  }, duration);

  return el
};

const showHideNodeLabel = (el, show = false) => {
  if (!el.hasAttribute('data-label-id'))
    return

  const label_id = el.getAttribute('data-label-id');

  const nodes = $(`
    visbug-label[data-label-id="${label_id}"],
    visbug-handles[data-label-id="${label_id}"]
  `);

  nodes.length && show
    ? nodes.forEach(el =>
      el.style.display = 'none')
    : nodes.forEach(el =>
      el.style.display = null);
};

const htmlStringToDom = (htmlString = "") =>
  (new DOMParser().parseFromString(htmlString, 'text/html'))
    .body.firstChild;

const isOffBounds = node =>
  node.closest && (
       node.closest('vis-bug')
    || node.closest('hotkey-map')
    || node.closest('visbug-metatip')
    || node.closest('visbug-ally')
    || node.closest('visbug-label')
    || node.closest('visbug-handles')
    || node.closest('visbug-gridlines')
  );

const isSelectorValid = (qs => (
  selector => {
    try { qs(selector); } catch (e) { return false }
    return true
  }
))(s => document.createDocumentFragment().querySelector(s));

function windowBounds() {
  const height  = window.innerHeight;
  const width   = window.innerWidth;
  const body    = document.body.clientWidth;

  const calcWidth = body <= width
    ? body
    : width;

  return {
    winHeight: height,
    winWidth:  calcWidth,
  }
}

class Gridlines extends HTMLElement {

  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'closed'});
  }

  connectedCallback() {}
  disconnectedCallback() {}

  set position(boundingRect) {
    this.$shadow.innerHTML  = this.render(boundingRect);
  }

  set update({ width, height, top, left }) {
    const { winHeight, winWidth } = windowBounds();

    this.$shadow.host.style.display = 'block';
    const svg = this.$shadow.children[1];

    svg.setAttribute('viewBox', `0 0 ${winWidth} ${winHeight}`);
    svg.children[0].setAttribute('width', width + 'px');
    svg.children[0].setAttribute('height', height + 'px');
    svg.children[0].setAttribute('x', left);
    svg.children[0].setAttribute('y', top);
    svg.children[1].setAttribute('x1', left);
    svg.children[1].setAttribute('x2', left);
    svg.children[2].setAttribute('x1', left + width);
    svg.children[2].setAttribute('x2', left + width);
    svg.children[3].setAttribute('y1', top);
    svg.children[3].setAttribute('y2', top);
    svg.children[3].setAttribute('x2', winWidth);
    svg.children[4].setAttribute('y1', top + height);
    svg.children[4].setAttribute('y2', top + height);
    svg.children[4].setAttribute('x2', winWidth);
  }

  render({ x, y, width, height, top, left }) {
    const { winHeight, winWidth } = windowBounds();

    return `
      ${this.styles({top,left})}
      <svg
        width="100%" height="100%"
        viewBox="0 0 ${winWidth} ${winHeight}"
        version="1.1" xmlns="http://www.w3.org/2000/svg"
      >
        <rect
          stroke="hotpink" fill="none"
          width="${width}" height="${height}"
          x="${x}" y="${y}"
          style="display:none;"
        ></rect>
        <line x1="${x}" y1="0" x2="${x}" y2="${winHeight}" stroke="hotpink" stroke-dasharray="2" stroke-dashoffset="3"></line>
        <line x1="${x + width}" y1="0" x2="${x + width}" y2="${winHeight}" stroke="hotpink" stroke-dasharray="2" stroke-dashoffset="3"></line>
        <line x1="0" y1="${y}" x2="${winWidth}" y2="${y}" stroke="hotpink" stroke-dasharray="2" stroke-dashoffset="3"></line>
        <line x1="0" y1="${y + height}" x2="${winWidth}" y2="${y + height}" stroke="hotpink" stroke-dasharray="2" stroke-dashoffset="3"></line>
      </svg>
    `
  }

  styles({top,left}) {
    return `
      <style>
        :host > svg {
          position:fixed;
          top:0;
          left:0;
          overflow:visible;
          pointer-events:none;
          z-index:2147483642;
        }
      </style>
    `
  }
}

customElements.define('visbug-gridlines', Gridlines);

class Distance extends HTMLElement {

  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'open'});
  }

  connectedCallback() {}
  disconnectedCallback() {}

  set position({line_model, node_label_id}) {
    this.$shadow.innerHTML  = this.render(line_model, node_label_id);
  }

  render(measurements, node_label_id) {
    this.$shadow.host.setAttribute('data-label-id', node_label_id);
    return `
      ${this.styles(measurements)}
      <figure quadrant="measurements.q">
        <div></div>
        <figcaption><b>${measurements.d}</b>px</figcaption>
        <div></div>
      </figure>
    `
  }

  styles({y,x,d,q,v = false}) {
    return `
      <style>
        :host {
          --line-color: hsl(267, 100%, 58%);
          --line-width: 1px;
          font-size: 16px;
        }

        :host > figure {
          margin: 0;
          position: absolute;
          ${v
            ? `height: ${d}px; width: 5px;`
            : `width: ${d}px; height: 5px;`}
          top: ${y + window.scrollY}px;
          left: ${x}px;
          transform: ${v
            ? 'translateX(-50%)'
            : 'translateY(-50%)'};
          overflow: visible;
          pointer-events: none;
          z-index: 2147483646;

          display: flex;
          align-items: center;
          flex-direction: ${v ? 'column' : 'row'};
        }

        :host > figure figcaption {
          color: white;
          text-shadow: 0 0.5px 0 hsla(0, 0%, 0%, 0.4);
          background: var(--line-color);
          border-radius: 1em;
          text-align: center;
          line-height: 1.1;
          font-size: 0.7em;
          font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;
          padding: 0.25em 0.5em 0.275em;
          font-variant-numeric: proportional-num oldstyle-nums stacked-fractions slashed-zero;
        }

        :host > figure span {
          background: var(--line-color);
          ${v
            ? 'height: var(--line-width); width: 5px;'
            : 'width: var(--line-width); height: 5px;'}
        }

        :host > figure div {
          flex: 2;
          background: var(--line-color);
          ${v
            ? 'width: var(--line-width);'
            : 'height: var(--line-width);'}
        }

        :host figure > div${q === 'top' || q === 'left' ? ':last-of-type' : ':first-of-type'} {
          background: linear-gradient(to ${q}, hotpink 0%, var(--line-color) 100%);
        }
      </style>
    `
  }
}

customElements.define('visbug-distance', Distance);

class Overlay extends HTMLElement {
  
  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'closed'});
  }

  connectedCallback() {}
  disconnectedCallback() {}

  set position(boundingRect) {
    this.$shadow.innerHTML  = this.render(boundingRect);
  }

  set update({ top, left, width, height }) {
    this.$shadow.host.style.display = 'block';

    const svg = this.$shadow.children[0];
    svg.style.display = 'block';
    svg.style.top = window.scrollY + top + 'px';
    svg.style.left = left + 'px';

    svg.setAttribute('width', width + 'px');
    svg.setAttribute('height', height + 'px');
  }

  render({id, top, left, height, width}) {
    return `
      <svg 
        class="visbug-overlay"
        overlay-id="${id}"
        style="
          display:none;
          position:absolute;
          top:0;
          left:0;
          overflow:visible;
          pointer-events:none;
          z-index: 999;
        " 
        width="${width}px" height="${height}px" 
        viewBox="0 0 ${width} ${height}" 
        version="1.1" xmlns="http://www.w3.org/2000/svg"
      >
        <rect 
          fill="hsla(330, 100%, 71%, 0.5)"
          width="100%" height="100%"
        ></rect>
      </svg>
    `
  }
}

customElements.define('visbug-overlay', Overlay);

var css$1 = ":host {\n  --theme-bg: hsl(0,0%,100%);\n  --theme-color: hotpink;\n  --theme-blue: hsl(188, 90%, 45%);\n  --theme-purple: hsl(267, 100%, 58%);\n  --theme-icon_color: hsl(0,0%,20%);\n  --theme-icon_hover-bg: hsl(0,0%,95%);\n}\n\n:host {\n  position: absolute;\n  z-index: 2147483647;\n  direction: ltr;\n  font-size: 16px;\n  font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;\n\n  --arrow-width: 15px;\n  --arrow-height: 8px;\n\n  --shadow-up: 5px;\n  --shadow-down: -5px;\n  --shadow-direction: var(--shadow-up);\n\n  --arrow-up: polygon(0 0, 100% 0, 50% 100%);\n  --arrow-down: polygon(50% 0, 0 100%, 100% 100%);\n  --arrow: var(--arrow-up);\n}\n\n:host figure {\n  max-width: 50vw;\n  background: white;\n  color: var(--theme-icon_color);\n  line-height: normal;\n  line-height: initial;\n  padding: 0.5em;\n  margin: 0;\n  display: flex;\n  flex-direction: column;\n  flex-wrap: nowrap;\n  border-radius: 0.25em;\n  line-height: initial;\n  -webkit-filter: drop-shadow(0 var(--shadow-direction) 0.5em hsla(0,0%,0%,35%));\n          filter: drop-shadow(0 var(--shadow-direction) 0.5em hsla(0,0%,0%,35%))\n}\n\n:host figure:after {\n    content: \"\";\n    background: white;\n    width: var(--arrow-width);\n    height: var(--arrow-height);\n    -webkit-clip-path: var(--arrow);\n            clip-path: var(--arrow);\n    position: absolute;\n    top: var(--arrow-top);\n    left: var(--arrow-left);\n  }\n\n:host figure a {\n    text-decoration: none;\n    color: inherit;\n    text-overflow: ellipsis;\n    overflow: hidden;\n    cursor: pointer\n  }\n\n:host figure a:hover {\n      color: var(--theme-color);\n      text-decoration: underline;\n    }\n\n:host figure a:empty {\n      display: none;\n    }\n\n:host figure a[node]:before {\n      content: \"\\003c\";\n    }\n\n:host figure a[node]:after {\n      content: \"\\003e\";\n    }\n\n:host h5 {\n  display: flex;\n  font-size: 1em;\n  font-weight: bolder;\n  margin: 0;\n  overflow: hidden;\n  white-space: nowrap;\n}\n\n:host h6 {\n  margin-top: 1em;\n  margin-bottom: 0;\n  font-weight: normal;\n}\n\n:host small {\n  font-size: 0.7em;\n  color: hsl(0,0%,60%)\n}\n\n:host small > span {\n    color: hsl(0,0%,20%);\n  }\n\n:host a:not(:hover) {\n  text-decoration: none;\n}\n\n:host [brand],\n:host [divider] {\n  color: var(--theme-color);\n}\n\n:host div {\n  display: grid;\n  grid-template-columns: auto auto;\n  grid-gap: 0.25em 0.5em;\n  margin: 0.5em 0 0;\n  padding: 0;\n  list-style-type: none;\n  color: hsl(0,0%,40%);\n  font-size: 0.8em;\n  font-family: 'Dank Mono', 'Operator Mono', 'Inconsolata', 'Fira Mono', 'SF Mono', 'Monaco', 'Droid Sans Mono', 'Source Code Pro', monospace;\n}\n\n:host [value] {\n  color: var(--theme-icon_color);\n  display: inline-flex;\n  align-items: center;\n  justify-content: flex-end;\n  text-align: right;\n  /* white-space: pre; */\n}\n\n:host [text] {\n  white-space: normal;\n}\n\n:host [longform] {\n  background: var(--theme-icon_hover-bg);\n  padding: 0.5em 0.75em;\n  border-radius: 0.25em;\n  font-family: sans-serif;\n  text-align: left;\n  line-height: 1.5;\n}\n\n:host [color] {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  width: 0.6em;\n  height: 0.6em;\n  border-radius: 50%;\n  margin-right: 0.25em;\n}\n\n:host [local-modifications] {\n  margin-top: 1rem;\n  color: var(--theme-color);\n  font-weight: bold;\n}\n\n:host [contrast] > span {\n  padding: 0 0.5em 0.1em;\n  border-radius: 1em;\n  box-shadow: 0 0 0 1px hsl(0,0%,90%);\n}\n";

class Metatip extends HTMLElement {

  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'closed'});
  }

  connectedCallback() {
    $(this.$shadow.host).on('mouseenter', this.observe.bind(this));
  }

  disconnectedCallback() {
    this.unobserve();
  }

  dispatchQuery(e) {
    this.$shadow.host.dispatchEvent(new CustomEvent('query', {
      bubbles: true,
      detail:   {
        text:       e.target.textContent,
        activator:  e.type,
      }
    }));
  }

  observe() {
    $('h5 > a', this.$shadow).on('click mouseenter', this.dispatchQuery.bind(this));
    $('h5 > a', this.$shadow).on('mouseleave', this.dispatchUnQuery.bind(this));
  }

  unobserve() {
    $('h5 > a', this.$shadow).off('click mouseenter', this.dispatchQuery.bind(this));
    $('h5 > a', this.$shadow).off('mouseleave', this.dispatchUnQuery.bind(this));
  }

  dispatchUnQuery(e) {
    this.$shadow.host.dispatchEvent(new CustomEvent('unquery', {
      bubbles: true
    }));
    this.unobserve();
  }

  set meta(data) {
    this.$shadow.innerHTML = this.render(data);
  }

  render({el, width, height, localModifications, notLocalModifications}) {
    return `
      ${this.styles()}
      <figure>
        <h5>
          <a node>${el.nodeName.toLowerCase()}</a>
          <a>${el.id && '#' + el.id}</a>
          ${createClassname(el).split('.')
            .filter(name => name != '')
            .reduce((links, name) => `
              ${links}
              <a>.${name}</a>
            `, '')
          }
        </h5>
        <small>
          <span">${Math.round(width)}</span>px
          <span divider>×</span>
          <span>${Math.round(height)}</span>px
        </small>
        <div>${notLocalModifications.reduce((items, item) => `
          ${items}
          <span prop>${item.prop}:</span>
          <span value>${item.value}</span>
        `, '')}
        </div>
        ${localModifications.length ? `
          <h6 local-modifications>Local Modifications</h6>
          <div>${localModifications.reduce((items, item) => `
            ${items}
            <span prop>${item.prop}:</span>
            <span value>${item.value}</span>
          `, '')}
          </div>
        ` : ''}
      </figure>
    `
  }

  styles() {
    return `
      <style>
        ${css$1}
      </style>
    `
  }
}

customElements.define('visbug-metatip', Metatip);

class Ally extends Metatip {
  constructor() {
    super();
  }
  
  render({el, ally_attributes, contrast_results}) {
    return `
      ${this.styles()}
      <figure>
        <h5>${el.nodeName.toLowerCase()}${el.id && '#' + el.id}</h5>
        <div>
          ${ally_attributes.reduce((items, attr) => `
            ${items}
            <span prop>${attr.prop}:</span>
            <span value>${attr.value}</span>
          `, '')}
          ${contrast_results}
        </div>
      </figure>
    `
  }
}

customElements.define('visbug-ally', Ally);

var css$2 = ":host {\n  --theme-bg: hsl(0,0%,100%);\n  --theme-color: hotpink;\n  --theme-blue: hsl(188, 90%, 45%);\n  --theme-purple: hsl(267, 100%, 58%);\n  --theme-icon_color: hsl(0,0%,20%);\n  --theme-icon_hover-bg: hsl(0,0%,95%);\n}\n\n:host {\n  display: none;\n  position: fixed;\n  z-index: 99998;\n  align-items: center;\n  justify-content: center;\n  width: 100vw;\n  height: 100vh;\n  background: hsl(0,0%,95%);\n  font-size: 16px;\n  font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;\n\n  --light-grey: hsl(0,0%,90%);\n  --grey: hsl(0,0%,60%);\n  --dark-grey: hsl(0,0%,40%);\n}\n\n:host [command] {\n  padding: 1em;\n  text-align: center;\n  font-size: 3vw;\n  font-weight: lighter;\n  letter-spacing: 0.1em;\n  color: var(--dark-grey)\n}\n\n:host [command] > [light] {\n    color: var(--grey);\n  }\n\n:host [command] > [tool] {\n    text-decoration: underline;\n    -webkit-text-decoration-color: var(--theme-color);\n            text-decoration-color: var(--theme-color);\n  }\n\n:host [command] > [negative], :host [command] > [side], :host [command] > [amount] {\n    font-weight: normal;\n  }\n\n:host [card] {\n  padding: 1em;\n  background: white;\n  box-shadow: 0 0.5em 3em hsla(0,0%,0%,20%);\n  border-radius: 0.5em;\n  color: var(--dark-grey);\n  display: flex;\n  justify-content: space-evenly\n}\n\n:host [card] > div:not([keyboard]) {\n    display: flex;\n    align-items: flex-end;\n    margin-left: 1em;\n  }\n\n:host [tool-icon] {\n  position: absolute;\n  top: 1em;\n  left: 0;\n  width: 100%;\n  padding: 0 1rem;\n  display: flex;\n  justify-content: center\n}\n\n:host [tool-icon] > span {\n    color: var(--dark-grey);\n    display: grid;\n    grid-template-columns: 5vmax auto;\n    grid-gap: 0.5em;\n    align-items: center;\n    text-transform: capitalize;\n    font-size: 4vmax;\n    font-weight: lighter;\n  }\n\n:host [tool-icon] svg {\n    width: 100%;\n    fill: var(--theme-color);\n  }\n\n:host section {\n  display: flex;\n  justify-content: center;\n}\n\n:host section > span, \n:host [arrows] > span {\n  border: 1px solid transparent;\n  border-radius: 0.5em;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  margin: 2px;\n  padding: 1.5vw;\n  font-size: 0.75em;\n  white-space: nowrap;\n}\n\n:host section > span:not([pressed=\"true\"]), \n:host [arrows] > span:not([pressed=\"true\"]) {\n  border: 1px solid var(--light-grey)\n}\n\n:host section > span:not([pressed=\"true\"]):hover, :host [arrows] > span:not([pressed=\"true\"]):hover {\n    border-color: var(--grey);\n  }\n\n:host span[pressed=\"true\"] {\n  background: var(--theme-color);\n  color: white;\n}\n\n:host span:not([pressed=\"true\"])[used] {\n  background: var(--light-grey);\n}\n\n:host span[hotkey] {\n  color: var(--theme-color);\n  font-weight: bold;\n  cursor: pointer;\n}\n\n:host section > span[hotkey]:not([pressed=\"true\"]) {\n  border-color: var(--theme-color);\n}\n\n:host [arrows] {\n  display: grid;\n  grid-template-columns: 1fr 1fr 1fr;\n  grid-template-rows: 1fr 1fr\n}\n\n:host [arrows] > span:nth-child(1) {\n    grid-row: 1;\n    grid-column: 2;\n  }\n\n:host [arrows] > span:nth-child(2) {\n    grid-row: 2;\n    grid-column: 2;\n  }\n\n:host [arrows] > span:nth-child(3) {\n    grid-row: 2;\n    grid-column: 1;\n  }\n\n:host [arrows] > span:nth-child(4) {\n    grid-row: 2;\n    grid-column: 3;\n  }\n\n:host [caps] > span:nth-child(1),\n:host [shift] > span:nth-child(1)  { justify-content: flex-start; }\n\n:host [shift] > span:nth-child(12) { justify-content: flex-end; }";

const cursor = `
  <svg class="icon-cursor" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
    <path d="M16.689 17.655l5.311 12.345-4 2-4.646-12.678-7.354 6.678v-26l20 16-9.311 1.655z"></path>
  </svg>
`;

const move = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M15 7.5V2H9v5.5l3 3 3-3zM7.5 9H2v6h5.5l3-3-3-3zM9 16.5V22h6v-5.5l-3-3-3 3zM16.5 9l-3 3 3 3H22V9h-5.5z"/>
  </svg>
`;

const search = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
  </svg>
`;

const margin = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M9 7H7v2h2V7zm0 4H7v2h2v-2zm0-8c-1.11 0-2 .9-2 2h2V3zm4 12h-2v2h2v-2zm6-12v2h2c0-1.1-.9-2-2-2zm-6 0h-2v2h2V3zM9 17v-2H7c0 1.1.89 2 2 2zm10-4h2v-2h-2v2zm0-4h2V7h-2v2zm0 8c1.1 0 2-.9 2-2h-2v2zM5 7H3v12c0 1.1.89 2 2 2h12v-2H5V7zm10-2h2V3h-2v2zm0 12h2v-2h-2v2z"/>
  </svg>
`;

const padding = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm2 4v-2H3c0 1.1.89 2 2 2zM3 9h2V7H3v2zm12 12h2v-2h-2v2zm4-18H9c-1.11 0-2 .9-2 2v10c0 1.1.89 2 2 2h10c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 12H9V5h10v10zm-8 6h2v-2h-2v2zm-4 0h2v-2H7v2z"/>
  </svg>
`;

const font = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M9 4v3h5v12h3V7h5V4H9zm-6 8h3v7h3v-7h3V9H3v3z"/>
  </svg>
`;

const text = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
  </svg>
`;

const align = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="transform:rotateZ(90deg);">
    <path d="M10 20h4V4h-4v16zm-6 0h4v-8H4v8zM16 9v11h4V9h-4z"/>
  </svg>
`;

const resize = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M19 12h-2v3h-3v2h5v-5zM7 9h3V7H5v5h2V9zm14-6H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16.01H3V4.99h18v14.02z"/>
  </svg>
`;

const transform = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M12,7C6.48,7,2,9.24,2,12c0,2.24,2.94,4.13,7,4.77V20l4-4l-4-4v2.73c-3.15-0.56-5-1.9-5-2.73c0-1.06,3.04-3,8-3s8,1.94,8,3
    c0,0.73-1.46,1.89-4,2.53v2.05c3.53-0.77,6-2.53,6-4.58C22,9.24,17.52,7,12,7z"/>
  </svg>
`;

const border = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M13 7h-2v2h2V7zm0 4h-2v2h2v-2zm4 0h-2v2h2v-2zM3 3v18h18V3H3zm16 16H5V5h14v14zm-6-4h-2v2h2v-2zm-4-4H7v2h2v-2z"/>
  </svg>
`;

const hueshift = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-5.5 9c-.83 0-1.5-.67-1.5-1.5S5.67 9 6.5 9 8 9.67 8 10.5 7.33 12 6.5 12zm3-4C8.67 8 8 7.33 8 6.5S8.67 5 9.5 5s1.5.67 1.5 1.5S10.33 8 9.5 8zm5 0c-.83 0-1.5-.67-1.5-1.5S13.67 5 14.5 5s1.5.67 1.5 1.5S15.33 8 14.5 8zm3 4c-.83 0-1.5-.67-1.5-1.5S16.67 9 17.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>
  </svg>
`;

const boxshadow = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M20 8.69V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69L23.31 12 20 8.69zM12 18c-.89 0-1.74-.2-2.5-.55C11.56 16.5 13 14.42 13 12s-1.44-4.5-3.5-5.45C10.26 6.2 11.11 6 12 6c3.31 0 6 2.69 6 6s-2.69 6-6 6z"/>
  </svg>
`;

const inspector = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <g>
      <rect x="11" y="7" width="2" height="2"/>
      <rect x="11" y="11" width="2" height="6"/>
      <path d="M12,2C6.48,2,2,6.48,2,12c0,5.52,4.48,10,10,10s10-4.48,10-10C22,6.48,17.52,2,12,2z M12,20c-4.41,0-8-3.59-8-8
        c0-4.41,3.59-8,8-8s8,3.59,8,8C20,16.41,16.41,20,12,20z"/>
    </g>
  </svg>
`;

const camera = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="3.2"/>
    <path d="M9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"/>
  </svg>
`;

const guides = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M21,6H3C1.9,6,1,6.9,1,8v8c0,1.1,0.9,2,2,2h18c1.1,0,2-0.9,2-2V8C23,6.9,22.1,6,21,6z M21,16H3V8h2v4h2V8h2v4h2V8h2v4h2V8
    h2v4h2V8h2V16z"/>
  </svg>
`;

const color_text = `
  <svg viewBox="0 0 25 27">
    <path d="M11 3L5.5 17h2.25l1.12-3h6.25l1.12 3h2.25L13 3h-2zm-1.38 9L12 5.67 14.38 12H9.62z"/>
    <rect fill="var(--contextual_color)" x="1" y="21" width="23" height="5"></rect>
  </svg>
`;

const color_background = `
  <svg viewBox="0 0 25 27">
    <path d="M16.56 8.94L7.62 0 6.21 1.41l2.38 2.38-5.15 5.15c-.59.59-.59 1.54 0 2.12l5.5 5.5c.29.29.68.44 1.06.44s.77-.15 1.06-.44l5.5-5.5c.59-.58.59-1.53 0-2.12zM5.21 10L10 5.21 14.79 10H5.21zM19 11.5s-2 2.17-2 3.5c0 1.1.9 2 2 2s2-.9 2-2c0-1.33-2-3.5-2-3.5z"/>
    <rect fill="var(--contextual_color)" x="1" y="21" width="23" height="5"></rect>
  </svg>
`;

const color_border = `
  <svg viewBox="0 0 25 27">
    <path d="M17.75 7L14 3.25l-10 10V17h3.75l10-10zm2.96-2.96c.39-.39.39-1.02 0-1.41L18.37.29c-.39-.39-1.02-.39-1.41 0L15 2.25 18.75 6l1.96-1.96z"/>
    <rect fill="var(--contextual_color)" x="1" y="21" width="23" height="5"></rect>
  </svg>
`;

const position = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M15.54 5.54L13.77 7.3 12 5.54 10.23 7.3 8.46 5.54 12 2zm2.92 10l-1.76-1.77L18.46 12l-1.76-1.77 1.76-1.77L22 12zm-10 2.92l1.77-1.76L12 18.46l1.77-1.76 1.77 1.76L12 22zm-2.92-10l1.76 1.77L5.54 12l1.76 1.77-1.76 1.77L2 12z"/>
    <circle cx="12" cy="12" r="3"/>
  </svg>
`;

const accessibility = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M12,2c1.1,0,2,0.9,2,2s-0.9,2-2,2s-2-0.9-2-2S10.9,2,12,2z M21,9h-6v13h-2v-6h-2v6H9V9H3V7h18V9z"/>
  </svg>
`;

var Icons = /*#__PURE__*/Object.freeze({
  cursor: cursor,
  move: move,
  search: search,
  margin: margin,
  padding: padding,
  font: font,
  text: text,
  align: align,
  resize: resize,
  transform: transform,
  border: border,
  hueshift: hueshift,
  boxshadow: boxshadow,
  inspector: inspector,
  camera: camera,
  guides: guides,
  color_text: color_text,
  color_background: color_background,
  color_border: color_border,
  position: position,
  accessibility: accessibility
});

class HotkeyMap extends HTMLElement {

  constructor() {
    super();

    this.keyboard_model = {
      num:    ['`','1','2','3','4','5','6','7','8','9','0','-','=','delete'],
      tab:    ['tab','q','w','e','r','t','y','u','i','o','p','[',']','\\'],
      caps:   ['caps','a','s','d','f','g','h','j','k','l','\'','return'],
      shift:  ['shift','z','x','c','v','b','n','m',',','.','/','shift'],
      space:  ['ctrl',altKey,'cmd','spacebar','cmd',altKey,'ctrl']
    };

    this.key_size_model = {
      num:    {12:2},
      tab:    {0:2},
      caps:   {0:3,11:3},
      shift:  {0:6,11:6},
      space:  {3:10},
    };

    this.$shadow    = this.attachShadow({mode: 'closed'});

    this._hotkey    = '';
    this._usedkeys  = [];

    this.tool       = 'hotkeymap';
  }

  connectedCallback() {
    this.$shift  = $('[keyboard] > section > [shift]', this.$shadow);
    this.$ctrl   = $('[keyboard] > section > [ctrl]', this.$shadow);
    this.$alt    = $(`[keyboard] > section > [${altKey}]`, this.$shadow);
    this.$cmd    = $(`[keyboard] > section > [${metaKey}]`, this.$shadow);
    this.$up     = $('[arrows] [up]', this.$shadow);
    this.$down   = $('[arrows] [down]', this.$shadow);
    this.$left   = $('[arrows] [left]', this.$shadow);
    this.$right  = $('[arrows] [right]', this.$shadow);
  }

  disconnectedCallback() {}

  set tool(tool) {
    this._tool = tool;
    this.$shadow.innerHTML = this.render();
  }

  show() {
    this.$shadow.host.style.display = 'flex';
    hotkeys('*', (e, handler) =>
      this.watchKeys(e, handler));
  }

  hide() {
    this.$shadow.host.style.display = 'none';
    hotkeys.unbind('*');
  }

  watchKeys(e, handler) {
    e.preventDefault();
    e.stopImmediatePropagation();

    this.$shift.attr('pressed', hotkeys.shift);
    this.$ctrl.attr('pressed', hotkeys.ctrl);
    this.$alt.attr('pressed', hotkeys.alt);
    this.$cmd.attr('pressed', hotkeys[metaKey]);
    this.$up.attr('pressed', e.code === 'ArrowUp');
    this.$down.attr('pressed', e.code === 'ArrowDown');
    this.$left.attr('pressed', e.code === 'ArrowLeft');
    this.$right.attr('pressed', e.code === 'ArrowRight');

    const { negative, negative_modifier, side, amount } = this.createCommand({e, hotkeys});

    $('[command]', this.$shadow)[0].innerHTML = this.displayCommand({
      negative, negative_modifier, side, amount,
    });
  }

  createCommand({e:{code}, hotkeys: hotkeys$$1}) {
    let amount              = hotkeys$$1.shift ? 10 : 1;
    let negative            = hotkeys$$1.alt ? 'Subtract' : 'Add';
    let negative_modifier   = hotkeys$$1.alt ? 'from' : 'to';

    let side = '[arrow key]';
    if (code === 'ArrowUp')     side = 'the top side';
    if (code === 'ArrowDown')   side = 'the bottom side';
    if (code === 'ArrowLeft')   side = 'the left side';
    if (code === 'ArrowRight')  side = 'the right side';
    if (hotkeys$$1[metaKey])            side = 'all sides';

    if (hotkeys$$1[metaKey] && code === 'ArrowDown') {
      negative            = 'Subtract';
      negative_modifier   = 'from';
    }

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({negative, negative_modifier, side, amount}) {
    return `
      <span negative>${negative} </span>
      <span tool>${this._tool}</span>
      <span light> ${negative_modifier} </span>
      <span side>${side}</span>
      <span light> by </span>
      <span amount>${amount}</span>
    `
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${Icons[this._tool]}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          ${this.displayCommand({
            negative: `±[${altKey}] `,
            negative_modifier: ' to ',
            tool: this._tool,
            side: '[arrow key]',
            amount: 1
          })}
        </div>
        <div card>
          <div keyboard>
            ${Object.entries(this.keyboard_model).reduce((keyboard, [row_name, row]) => `
              ${keyboard}
              <section ${row_name}>${row.reduce((row, key, i) => `
                ${row}
                <span
                  ${key}
                  ${this._hotkey == key ? 'hotkey title="Tool Shortcut Hotkey"' : ''}
                  ${this._usedkeys.includes(key) ? 'used' : ''}
                  style="flex:${this.key_size_model[row_name][i] || 1};"
                >${key}</span>
              `, '')}
              </section>
            `, '')}
          </div>
          <div>
            <section arrows>
              <span up used>↑</span>
              <span down used>↓</span>
              <span left used>←</span>
              <span right used>→</span>
            </section>
          </div>
        </div>
      </article>
    `
  }

  styles() {
    return `
      <style>
        ${css$2}
      </style>
    `
  }
}

customElements.define('hotkey-map', HotkeyMap);

class GuidesHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'g';
    this._usedkeys  = [];
    this.tool       = 'guides';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${guides}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-guides', GuidesHotkeys);

class InspectorHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'i';
    this._usedkeys  = [altKey];
    this.tool       = 'inspector';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${inspector}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-inspector', InspectorHotkeys);

class AccessibilityHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'p';
    this._usedkeys  = [altKey];
    this.tool       = 'accessibility';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${accessibility}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-accessibility', AccessibilityHotkeys);

class MoveHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey  = 'v';
    this.tool     = 'move';
  }

  createCommand({e:{code}, hotkeys}) {
    let amount, negative, negative_modifier;

    let side = '[arrow key]';
    if (code === 'ArrowUp')     side = 'up & out of div';
    if (code === 'ArrowDown')   side = 'down & into next sibling / out & under div';
    if (code === 'ArrowLeft')   side = 'towards the front/top of the stack';
    if (code === 'ArrowRight')  side = 'towards the back/bottom of the stack';

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({side}) {
    return `
      <span tool>${this._tool}</span>
      <span side>${side}</span>
    `
  }
}

customElements.define('hotkeys-move', MoveHotkeys);

class MarginHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'm';
    this._usedkeys  = ['shift',metaKey,altKey];

    this.tool       = 'margin';
  }
}

customElements.define('hotkeys-margin', MarginHotkeys);

class PaddingHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'p';
    this._usedkeys  = ['shift',metaKey,altKey];

    this.tool       = 'padding';
  }
}

customElements.define('hotkeys-padding', PaddingHotkeys);

const h_alignOptions  = ['left','center','right'];
const v_alignOptions  = ['top','center','bottom'];
const distOptions     = ['evenly','normal','between'];

class AlignHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey   = 'a';
    this._usedkeys = [metaKey,'shift'];

    this._htool   = 0;
    this._vtool   = 0;
    this._dtool   = 1;

    this._side         = 'top left';
    this._direction    = 'row';
    this._distribution = distOptions[this._dtool];

    this.tool     = 'align';
  }

  createCommand({e:{code}, hotkeys}) {
    let amount            = this._distribution
      , negative_modifier = this._direction
      , side              = this._side
      , negative;

    if (hotkeys.cmd && (code === 'ArrowRight' || code === 'ArrowDown')) {
      negative_modifier = code === 'ArrowDown'
        ? 'column'
        : 'row';
      this._direction = negative_modifier;
    }
    else {
      if (code === 'ArrowUp')           side = this.clamp(v_alignOptions, '_vtool');
      else if (code === 'ArrowDown')    side = this.clamp(v_alignOptions, '_vtool', true);
      else                              side = v_alignOptions[this._vtool];

      if (code === 'ArrowLeft')         side += ' ' + this.clamp(h_alignOptions, '_htool');
      else if (code === 'ArrowRight')   side += ' ' + this.clamp(h_alignOptions, '_htool', true);
      else                              side += ' ' + h_alignOptions[this._htool];

      this._side = side;

      if (hotkeys.shift && (code === 'ArrowRight' || code === 'ArrowLeft')) {
        amount = this.clamp(distOptions, '_dtool', code === 'ArrowRight');
        this._distribution = amount;
      }
    }

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({side, amount, negative_modifier}) {
    if (amount == 1) amount = this._distribution;
    if (negative_modifier == ' to ') negative_modifier = this._direction;

    return `
      <span tool>${this._tool}</span>
      <span light> as </span>
      <span>${negative_modifier}:</span>
      <span side>${side}</span>
      <span light> distributed </span>
      <span amount>${amount}</span>
    `
  }

  clamp(range, tool, increment = false) {
    if (increment) {
      if (this[tool] < range.length - 1)
        this[tool] = this[tool] + 1;
    }
    else if (this[tool] > 0)
      this[tool] = this[tool] - 1;

    return range[this[tool]]
  }
}

customElements.define('hotkeys-align', AlignHotkeys);

class HueshiftHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'h';
    this._usedkeys  = ['shift',metaKey];
    this.tool       = 'hueshift';
  }

  createCommand({e:{code}, hotkeys}) {
    let amount              = hotkeys.shift ? 10 : 1;
    let negative            = '[increase/decrease]';
    let negative_modifier   = 'by';
    let side                = '[arrow key]';

    // saturation
    if (hotkeys.cmd) {
      side ='hue';

      if (code === 'ArrowDown')
        negative  = 'decrease';
      if (code === 'ArrowUp')
        negative  = 'increase';
    }
    else if (code === 'ArrowLeft' || code === 'ArrowRight') {
      side = 'saturation';

      if (code === 'ArrowLeft')
        negative  = 'decrease';
      if (code === 'ArrowRight')
        negative  = 'increase';
    }
    // lightness
    else if (code === 'ArrowUp' || code === 'ArrowDown') {
      side = 'lightness';

      if (code === 'ArrowDown')
        negative  = 'decrease';
      if (code === 'ArrowUp')
        negative  = 'increase';
    }

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({negative, negative_modifier, side, amount}) {
    if (negative === `±[${altKey}] `)
      negative = '[increase/decrease]';
    if (negative_modifier === ' to ')
      negative_modifier = ' by ';

    return `
      <span negative>${negative}</span>
      <span side tool>${side}</span>
      <span light>${negative_modifier}</span>
      <span amount>${amount}</span>
    `
  }
}

customElements.define('hotkeys-hueshift', HueshiftHotkeys);

class BoxshadowHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'd';
    this._usedkeys  = ['shift',metaKey];
    this.tool       = 'boxshadow';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${boxshadow}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-boxshadow', BoxshadowHotkeys);

class PositionHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'l';
    this._usedkeys  = ['shift',altKey];
    this.tool       = 'position';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${position}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-position', PositionHotkeys);

class FontHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'f';
    this._usedkeys  = ['shift',metaKey];
    this.tool       = 'font';
  }

  createCommand({e:{code}, hotkeys}) {
    let amount              = hotkeys.shift ? 10 : 1;
    let negative            = '[increase/decrease]';
    let negative_modifier   = 'by';
    let side                = '[arrow key]';

    // kerning
    if (hotkeys.shift && (code === 'ArrowLeft' || code === 'ArrowRight')) {
      side    = 'kerning';
      amount  = '1px';

      if (code === 'ArrowLeft')
        negative  = 'decrease';
      if (code === 'ArrowRight')
        negative  = 'increase';
    }
    // leading
    else if (hotkeys.shift && (code === 'ArrowUp' || code === 'ArrowDown')) {
      side    = 'leading';
      amount  = '1px';

      if (code === 'ArrowUp')
        negative  = 'increase';
      if (code === 'ArrowDown')
        negative  = 'decrease';
    }
    // font weight
    else if (hotkeys.cmd && (code === 'ArrowUp' || code === 'ArrowDown')) {
      side                = 'font weight';
      amount              = '';
      negative_modifier   = '';

      if (code === 'ArrowUp')
        negative  = 'increase';
      if (code === 'ArrowDown')
        negative  = 'decrease';
    }
    // font size
    else if (code === 'ArrowUp' || code === 'ArrowDown') {
      side    = 'font size';
      amount  = '1px';

      if (code === 'ArrowUp')
        negative  = 'increase';
      if (code === 'ArrowDown')
        negative  = 'decrease';
    }
    // text alignment
    else if (code === 'ArrowRight' || code === 'ArrowLeft') {
      side                = 'text alignment';
      amount              = '';
      negative            = 'adjust';
      negative_modifier   = '';
    }

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({negative, negative_modifier, side, amount}) {
    if (negative === `±[${altKey}] `)
      negative = '[increase/decrease]';
    if (negative_modifier === ' to ')
      negative_modifier = ' by ';

    return `
      <span negative>${negative}</span>
      <span side tool>${side}</span>
      <span light>${negative_modifier}</span>
      <span amount>${amount}</span>
    `
  }
}

customElements.define('hotkeys-font', FontHotkeys);

class TextHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'e';
    this._usedkeys  = [];
    this.tool       = 'text';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${text}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-text', TextHotkeys);

class SearchHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 's';
    this._usedkeys  = [];
    this.tool       = 'search';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${search}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-search', SearchHotkeys);

class Hotkeys extends HTMLElement {

  constructor() {
    super();

    this.tool_map = {
      guides:         document.createElement('hotkeys-guides'),
      inspector:      document.createElement('hotkeys-inspector'),
      accessibility:  document.createElement('hotkeys-accessibility'),
      move:           document.createElement('hotkeys-move'),
      margin:         document.createElement('hotkeys-margin'),
      padding:        document.createElement('hotkeys-padding'),
      align:          document.createElement('hotkeys-align'),
      hueshift:       document.createElement('hotkeys-hueshift'),
      boxshadow:      document.createElement('hotkeys-boxshadow'),
      position:       document.createElement('hotkeys-position'),
      font:           document.createElement('hotkeys-font'),
      text:           document.createElement('hotkeys-text'),
      search:         document.createElement('hotkeys-search'),
    };

    Object.values(this.tool_map).forEach(tool =>
      this.appendChild(tool));
  }

  connectedCallback() {
    hotkeys('shift+/', e =>
      this.cur_tool
        ? this.hideTool()
        : this.showTool());

    hotkeys('esc', e => this.hideTool());
  }

  disconnectedCallback() {}

  hideTool() {
    if (!this.cur_tool) return
    this.cur_tool.hide();
    this.cur_tool = null;
  }

  showTool() {
    this.cur_tool = this.tool_map[
      $('vis-bug')[0].activeTool];
    this.cur_tool.show();
  }
}

customElements.define('visbug-hotkeys', Hotkeys);

// todo: show margin color
const key_events = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},alt+${event},shift+${event},shift+alt+${event}`
  , '')
  .substring(1);

const command_events = `${metaKey}+up,${metaKey}+shift+up,${metaKey}+down,${metaKey}+shift+down`;

function Margin({selection}) {
  hotkeys(key_events, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();
    pushElement(selection(), handler.key);
  });

  hotkeys(command_events, (e, handler) => {
    e.preventDefault();
    pushAllElementSides(selection(), handler.key);
  });

  return () => {
    hotkeys.unbind(key_events);
    hotkeys.unbind(command_events);
    hotkeys.unbind('up,down,left,right'); // bug in lib?
  }
}

function pushElement(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'margin' + getSide(direction),
      current:  parseInt(getStyle(el, 'margin' + getSide(direction)), 10),
      amount:   direction.split('+').includes('shift') ? 10 : 1,
      negative: direction.split('+').includes('alt'),
    }))
    .map(payload =>
      Object.assign(payload, {
        margin: payload.negative
          ? payload.current - payload.amount
          : payload.current + payload.amount
      }))
    .forEach(({el, style, margin}) =>
      el.style[style] = `${margin < 0 ? 0 : margin}px`);
}

function pushAllElementSides(els, keycommand) {
  const combo = keycommand.split('+');
  let spoof = '';

  if (combo.includes('shift'))  spoof = 'shift+' + spoof;
  if (combo.includes('down'))   spoof = 'alt+' + spoof;

  'up,down,left,right'.split(',')
    .forEach(side => pushElement(els, spoof + side));
}

const key_events$1 = 'up,down,left,right';
// todo: indicator for when node can descend
// todo: indicator where left and right will go
// todo: have it work with shadowDOM
function Moveable({selection}) {
  hotkeys(key_events$1, (e, {key}) => {
    if (e.cancelBubble) return
      
    e.preventDefault();
    e.stopPropagation();
    
    selection().forEach(el => {
      moveElement(el, key);
      updateFeedback(el);
    });
  });

  return () => {
    hotkeys.unbind(key_events$1);
  }
}

function moveElement(el, direction) {
  if (!el) return

  switch(direction) {
    case 'left':
      if (canMoveLeft(el))
        el.parentNode.insertBefore(el, el.previousElementSibling);
      else
        showEdge(el.parentNode);
      break

    case 'right':
      if (canMoveRight(el) && el.nextElementSibling.nextSibling)
        el.parentNode.insertBefore(el, el.nextElementSibling.nextSibling);
      else if (canMoveRight(el))
        el.parentNode.appendChild(el);
      else
        showEdge(el.parentNode);
      break

    case 'up':
      if (canMoveUp(el))
        popOut({el});
      break

    case 'down':
      if (canMoveUnder(el))
        popOut({el, under: true});
      else if (canMoveDown(el))
        el.nextElementSibling.prepend(el);
      break
  }
}

const canMoveLeft    = el => el.previousElementSibling;
const canMoveRight   = el => el.nextElementSibling;
const canMoveDown    = el => el.nextElementSibling && el.nextElementSibling.children.length;
const canMoveUnder   = el => !el.nextElementSibling && el.parentNode && el.parentNode.parentNode;
const canMoveUp      = el => el.parentNode && el.parentNode.parentNode;

const popOut = ({el, under = false}) =>
  el.parentNode.parentNode.insertBefore(el, 
    el.parentNode.parentNode.children[
      under
        ? getNodeIndex(el) + 1
        : getNodeIndex(el)]); 

function updateFeedback(el) {
  let options = '';
  // get current elements offset/size
  if (canMoveLeft(el))  options += '⇠';
  if (canMoveRight(el)) options += '⇢';
  if (canMoveDown(el))  options += '⇣';
  if (canMoveUp(el))    options += '⇡';
  // create/move arrows in absolute/fixed to overlay element
  options && console.info('%c'+options, "font-size: 2rem;");
}

let imgs      = []
  , overlays  = []
  , dragItem;

function watchImagesForUpload() {
  imgs = $([
    ...document.images,
    ...findBackgroundImages(document),
  ]);

  clearWatchers(imgs);
  initWatchers(imgs);
}

const initWatchers = imgs => {
  imgs.on('dragover', onDragEnter);
  imgs.on('dragleave', onDragLeave);
  imgs.on('drop', onDrop);
  $(document.body).on('dragover', onDragEnter);
  $(document.body).on('dragleave', onDragLeave);
  $(document.body).on('drop', onDrop);
  $(document.body).on('dragstart', onDragStart);
  $(document.body).on('dragend', onDragEnd);
};

const clearWatchers = imgs => {
  imgs.off('dragenter', onDragEnter);
  imgs.off('dragleave', onDragLeave);
  imgs.off('drop', onDrop);
  $(document.body).off('dragenter', onDragEnter);
  $(document.body).off('dragleave', onDragLeave);
  $(document.body).off('drop', onDrop);
  $(document.body).on('dragstart', onDragStart);
  $(document.body).on('dragend', onDragEnd);
  imgs = [];
};

const previewFile = file => {
  return new Promise((resolve, reject) => {
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = () => resolve(reader.result);
  })
};

// only fired for in-page drag events, track what the user picked up
const onDragStart = ({target}) =>
  dragItem = target;

const onDragEnd = e =>
  dragItem = undefined;

const onDragEnter = e => {
  e.preventDefault();
  const pre_selected = $('img[data-selected=true]');

  if (!pre_selected.length)
    showOverlay(e.currentTarget, 0);
  else
    pre_selected.forEach((img, i) =>
      showOverlay(img, i));
};

const onDragLeave = e => 
  hideOverlays();


const onDrop = async e => {
  e.stopPropagation();
  e.preventDefault();

  const selectedImages = $('img[data-selected=true]');
  
  const srcs = e.dataTransfer.files.length 
    ? await Promise.all([...e.dataTransfer.files]
      .filter(file => file.type.includes('image'))
      .map(previewFile)) 
    : [dragItem.src];
  
  if (srcs.length) {
    if (!selectedImages.length)
      if (e.target.nodeName === 'IMG')
        e.target.src = srcs[0];
      else
        imgs
          .filter(img => img.contains(e.target))
          .forEach(img => 
            img.style.backgroundImage = `url(${srcs[0]})`);
    else if (selectedImages.length) {
      let i = 0;
      selectedImages.forEach(img => {
        img.src = srcs[i++];
        if (i >= srcs.length) i = 0;
      });
    }
  }

  hideOverlays();
};

const showOverlay = (node, i) => {
  const rect    = node.getBoundingClientRect();
  const overlay = overlays[i];

  if (overlay) {
    overlay.update = rect;
  }
  else {
    overlays[i] = document.createElement('visbug-overlay');
    overlays[i].position = rect;
    document.body.appendChild(overlays[i]);
  }
};

const hideOverlays = () => {
  overlays.forEach(overlay =>
    overlay.remove());
  overlays = [];
};

const findBackgroundImages = el => {
  const src_regex = /url\(\s*?['"]?\s*?(\S+?)\s*?["']?\s*?\)/i;

  return $('*').reduce((collection, node) => {
    const prop = getStyle(node, 'background-image');
    const match = src_regex.exec(prop);

    // if (match) collection.push(match[1])
    if (match) collection.push(node);

    return collection
  }, [])
};

/**
 * @author Georgegriff@ (George Griffiths)
 * License Apache-2.0
 */

/**
* Finds first matching elements on the page that may be in a shadow root using a complex selector of n-depth
*
* Don't have to specify all shadow roots to button, tree is travered to find the correct element
*
* Example querySelectorAllDeep('downloads-item:nth-child(4) #remove');
*
* Example should work on chrome://downloads outputting the remove button inside of a download card component
*
* Example find first active download link element querySelectorDeep('#downloads-list .is-active a[href^="https://"]');
*
* Another example querySelectorAllDeep('#downloads-list div#title-area + a');
e.g.
*/
function querySelectorAllDeep(selector, root = document) {
    return _querySelectorDeep(selector, true, root);
}

function _querySelectorDeep(selector, findMany, root) {
    let lightElement = root.querySelector(selector);

    if (document.head.createShadowRoot || document.head.attachShadow) {
        // no need to do any special if selector matches something specific in light-dom
        if (!findMany && lightElement) {
            return lightElement;
        }

        // split on commas because those are a logical divide in the operation
        const selectionsToMake = splitByCharacterUnlessQuoted(selector, ',');

        return selectionsToMake.reduce((acc, minimalSelector) => {
            // if not finding many just reduce the first match
            if (!findMany && acc) {
                return acc;
            }
            // do best to support complex selectors and split the query
            const splitSelector = splitByCharacterUnlessQuoted(minimalSelector
                    //remove white space at start of selector
                    .replace(/^\s+/g, '')
                    .replace(/\s*([>+~]+)\s*/g, '$1'), ' ')
                // filter out entry white selectors
                .filter((entry) => !!entry);
            const possibleElementsIndex = splitSelector.length - 1;
            const possibleElements = collectAllElementsDeep(splitSelector[possibleElementsIndex], root);
            const findElements = findMatchingElement(splitSelector, possibleElementsIndex, root);
            if (findMany) {
                acc = acc.concat(possibleElements.filter(findElements));
                return acc;
            } else {
                acc = possibleElements.find(findElements);
                return acc || null;
            }
        }, findMany ? [] : null);


    } else {
        if (!findMany) {
            return lightElement;
        } else {
            return root.querySelectorAll(selector);
        }
    }

}

function findMatchingElement(splitSelector, possibleElementsIndex, root) {
    return (element) => {
        let position = possibleElementsIndex;
        let parent = element;
        let foundElement = false;
        while (parent) {
            const foundMatch = parent.matches(splitSelector[position]);
            if (foundMatch && position === 0) {
                foundElement = true;
                break;
            }
            if (foundMatch) {
                position--;
            }
            parent = findParentOrHost(parent, root);
        }
        return foundElement;
    };

}

function splitByCharacterUnlessQuoted(selector, character) {
    return selector.match(/\\?.|^$/g).reduce((p, c) => {
        if (c === '"' && !p.sQuote) {
            p.quote ^= 1;
            p.a[p.a.length - 1] += c;
        } else if (c === '\'' && !p.quote) {
            p.sQuote ^= 1;
            p.a[p.a.length - 1] += c;

        } else if (!p.quote && !p.sQuote && c === character) {
            p.a.push('');
        } else {
            p.a[p.a.length - 1] += c;
        }
        return p;
    }, { a: [''] }).a;
}


function findParentOrHost(element, root) {
    const parentNode = element.parentNode;
    return (parentNode && parentNode.host && parentNode.nodeType === 11) ? parentNode.host : parentNode === root ? null : parentNode;
}

/**
 * Finds all elements on the page, inclusive of those within shadow roots.
 * @param {string=} selector Simple selector to filter the elements by. e.g. 'a', 'div.main'
 * @return {!Array<string>} List of anchor hrefs.
 * @author ebidel@ (Eric Bidelman)
 * License Apache-2.0
 */
function collectAllElementsDeep(selector = null, root) {
    const allElements = [];

    const findAllElements = function(nodes) {
        for (let i = 0, el; el = nodes[i]; ++i) {
            allElements.push(el);
            // If the element has a shadow root, dig deeper.
            if (el.shadowRoot) {
                findAllElements(el.shadowRoot.querySelectorAll('*'));
            }
        }
    };
    if(root.shadowRoot) {
        findAllElements(root.shadowRoot.querySelectorAll('*'));
    }
    findAllElements(root.querySelectorAll('*'));

    return selector ? allElements.filter(el => el.matches(selector)) : allElements;
}

const commands = [
  'empty page',
  'blank page',
  'clear canvas',
];

function BlankPagePlugin() {
  document
    .querySelectorAll('body > *:not(vis-bug):not(script)')
    .forEach(node => node.remove());
}

const commands$1 = [
  'barrel roll',
  'do a barrel roll',
];

async function BarrelRollPlugin() {
  document.body.style.transformOrigin = 'center 50vh';
  
  await document.body.animate([
    { transform: 'rotateZ(0)' },
    { transform: 'rotateZ(1turn)' },
  ], { duration: 1500 }).finished;

  document.body.style.transformOrigin = '';
}

const commands$2 = [
  'pesticide',
];

async function PesticidePlugin() {
  await loadStyles(['https://unpkg.com/pesticide@1.3.1/css/pesticide.min.css']);
}

const commands$3 = [
  'trashy',
  'construct',
];

async function ConstructPlugin() {
  await loadStyles(['https://cdn.jsdelivr.net/gh/t7/construct.css@master/css/construct.boxes.css']);
}

const commands$4 = [
  'debug trashy',
  'debug construct',
];

async function ConstructDebugPlugin() {
  await loadStyles(['https://cdn.jsdelivr.net/gh/t7/construct.css@master/css/construct.debug.css']);
}

const commands$5 = [
  'wireframe',
  'blueprint',
];

async function WireframePlugin() {
  const styles = `
    *:not(path):not(g) {
      color: hsla(210, 100%, 100%, 0.9) !important;
      background: hsla(210, 100%, 50%, 0.5) !important;
      outline: solid 0.25rem hsla(210, 100%, 100%, 0.5) !important;
      box-shadow: none !important;
    }
  `;

  const style = document.createElement('style');
  style.textContent = styles;
  document.head.appendChild(style);
}

const commands$6 = [
  'skeleton',
  'outline',
];

async function SkeletonPlugin() {
  const styles = `
    *:not(path):not(g) {
      color: hsl(0, 0%, 0%) !important;
      text-shadow: none !important;
      background: hsl(0, 0%, 100%) !important;
      outline: 1px solid hsla(0, 0%, 0%, 0.5) !important;
      border-color: transparent !important;
      box-shadow: none !important;
    }
  `;

  const style = document.createElement('style');
  style.textContent = styles;
  document.head.appendChild(style);
}

// https://gist.github.com/addyosmani/fd3999ea7fce242756b1
const commands$7 = [
  'tag debugger',
  'osmani',
];

async function TagDebuggerPlugin() {
  for (i = 0; A = document.querySelectorAll('*')[i++];)
    A.style.outline = `solid hsl(${(A+A).length*9},99%,50%) 1px`;
}

// http://heydonworks.com/revenge_css_bookmarklet/

const commands$8 = [
  'revenge',
  'revenge.css',
  'heydon',
];

async function RevengePlugin() {
  await loadStyles(['https://cdn.jsdelivr.net/gh/Heydon/REVENGE.CSS@master/revenge.css']);
}

const commandsToHash = (plugin_commands, plugin_fn) =>
  plugin_commands.reduce((commands$$1, command) =>
    Object.assign(commands$$1, {[`/${command}`]:plugin_fn})
  , {});

const PluginRegistry = new Map(Object.entries({
  ...commandsToHash(commands, BlankPagePlugin),
  ...commandsToHash(commands$1, BarrelRollPlugin),
  ...commandsToHash(commands$2, PesticidePlugin),
  ...commandsToHash(commands$3, ConstructPlugin),
  ...commandsToHash(commands$4, ConstructDebugPlugin),
  ...commandsToHash(commands$5, WireframePlugin),
  ...commandsToHash(commands$6, SkeletonPlugin),
  ...commandsToHash(commands$7, TagDebuggerPlugin),
  ...commandsToHash(commands$8, RevengePlugin),
}));

const PluginHints = [
  commands[0],
  commands$1[0],
  commands$2[0],
  commands$3[0],
  commands$4[0],
  commands$5[0],
  commands$6[0],
  commands$7[0],
  commands$8[0],
].map(command => `/${command}`);

let SelectorEngine;

// create input
const search_base = document.createElement('div');
search_base.classList.add('search');
search_base.innerHTML = `
  <input list="visbug-plugins" type="text" placeholder="ex: images, .btn, button, text, ..."/>
  <datalist id="visbug-plugins">
    ${PluginHints.reduce((options, command) =>
      options += `<option value="${command}">plugin</option>`
    , '')}
    <option value="h1, h2, h3, .get-multiple">example</option>
    <option value="nav > a:first-child">example</option>
    <option value="#get-by-id">example</option>
    <option value=".get-by.class-names">example</option>
    <option value="images">alias</option>
    <option value="text">alias</option>
  </datalist>
`;

const search$1        = $(search_base);
const searchInput   = $('input', search_base);

const showSearchBar = () => search$1.attr('style', 'display:block');
const hideSearchBar = () => search$1.attr('style', 'display:none');
const stopBubbling  = e => e.key != 'Escape' && e.stopPropagation();

function Search(node) {
  if (node) node[0].appendChild(search$1[0]);

  const onQuery = e => {
    e.preventDefault();
    e.stopPropagation();

    const query = e.target.value;

    window.requestIdleCallback(_ =>
      queryPage(query));
  };

  searchInput.on('input', onQuery);
  searchInput.on('keydown', stopBubbling);
  // searchInput.on('blur', hideSearchBar)

  showSearchBar();
  searchInput[0].focus();

  // hotkeys('escape,esc', (e, handler) => {
  //   hideSearchBar()
  //   hotkeys.unbind('escape,esc')
  // })

  return () => {
    hideSearchBar();
    searchInput.off('oninput', onQuery);
    searchInput.off('keydown', stopBubbling);
    searchInput.off('blur', hideSearchBar);
  }
}

function provideSelectorEngine(Engine) {
  SelectorEngine = Engine;
}

function queryPage(query, fn) {
  // todo: should stash a cleanup method to be called when query doesnt match
  if (PluginRegistry.has(query))
    return PluginRegistry.get(query)(query)

  if (query == 'links')     query = 'a';
  if (query == 'buttons')   query = 'button';
  if (query == 'images')    query = 'img';
  if (query == 'text')      query = 'p,caption,a,h1,h2,h3,h4,h5,h6,small,date,time,li,dt,dd';

  if (!query) return SelectorEngine.unselect_all()
  if (query == '.' || query == '#' || query.trim().endsWith(',')) return

  try {
    let matches = querySelectorAllDeep(query + ':not(vis-bug):not(script):not(hotkey-map):not(.visbug-metatip):not(visbug-label):not(visbug-handles)');
    if (!matches.length) matches = querySelectorAllDeep(query);
    if (!fn) SelectorEngine.unselect_all();
    if (matches.length)
      matches.forEach(el =>
        fn
          ? fn(el)
          : SelectorEngine.select(el));
  }
  catch (err) {}
}

const state = {
  distances:  [],
  target:     null,
};

function createMeasurements({$anchor, $target}) {
  if (state.target == $target && state.distances.length) return
  else state.target = $target;

  if (state.distances.length) clearMeasurements();

  const anchorBounds = $anchor.getBoundingClientRect();
  const targetBounds = $target.getBoundingClientRect();

  const measurements = [];

  // right
  if (anchorBounds.right < targetBounds.left) {
    measurements.push({
      x: anchorBounds.right,
      y: anchorBounds.top + (anchorBounds.height / 2),
      d: targetBounds.left - anchorBounds.right,
      q: 'right',
    });
  }
  if (anchorBounds.right < targetBounds.right && anchorBounds.right > targetBounds.left) {
    measurements.push({
      x: anchorBounds.right,
      y: anchorBounds.top + (anchorBounds.height / 2),
      d: targetBounds.right - anchorBounds.right,
      q: 'right',
    });
  }

  // left
  if (anchorBounds.left > targetBounds.right) {
    measurements.push({
      x: targetBounds.right,
      y: anchorBounds.top + (anchorBounds.height / 2),
      d: anchorBounds.left - targetBounds.right,
      q: 'left',
    });
  }
  if (anchorBounds.left > targetBounds.left && anchorBounds.left < targetBounds.right) {
    measurements.push({
      x: targetBounds.left,
      y: anchorBounds.top + (anchorBounds.height / 2),
      d: anchorBounds.left - targetBounds.left,
      q: 'left',
    });
  }

  // top
  if (anchorBounds.top > targetBounds.bottom) {
    measurements.push({
      x: anchorBounds.left + (anchorBounds.width / 2),
      y: targetBounds.bottom,
      d: anchorBounds.top - targetBounds.bottom,
      q: 'top',
      v: true,
    });
  }
  if (anchorBounds.top > targetBounds.top && anchorBounds.top < targetBounds.bottom) {
    measurements.push({
      x: anchorBounds.left + (anchorBounds.width / 2),
      y: targetBounds.top,
      d: anchorBounds.top - targetBounds.top,
      q: 'top',
      v: true,
    });
  }

  // bottom
  if (anchorBounds.bottom < targetBounds.top) {
    measurements.push({
      x: anchorBounds.left + (anchorBounds.width / 2),
      y: anchorBounds.bottom,
      d: targetBounds.top - anchorBounds.bottom,
      q: 'bottom',
      v: true,
    });
  }
  if (anchorBounds.bottom < targetBounds.bottom && anchorBounds.bottom > targetBounds.top) {
    measurements.push({
      x: anchorBounds.left + (anchorBounds.width / 2),
      y: anchorBounds.bottom,
      d: targetBounds.bottom - anchorBounds.bottom,
      q: 'bottom',
      v: true,
    });
  }

  // inside left/right
  if (anchorBounds.right > targetBounds.right && anchorBounds.left < targetBounds.left) {
    measurements.push({
      x: targetBounds.right,
      y: anchorBounds.top + (anchorBounds.height / 2),
      d: anchorBounds.right - targetBounds.right,
      q: 'left',
    });
    measurements.push({
      x: anchorBounds.left,
      y: anchorBounds.top + (anchorBounds.height / 2),
      d: targetBounds.left - anchorBounds.left,
      q: 'right',
    });
  }

  // inside top/right
  if (anchorBounds.top < targetBounds.top && anchorBounds.bottom > targetBounds.bottom) {
    measurements.push({
      x: anchorBounds.left + (anchorBounds.width / 2),
      y: anchorBounds.top,
      d: targetBounds.top - anchorBounds.top,
      q: 'bottom',
      v: true,
    });
    measurements.push({
      x: anchorBounds.left + (anchorBounds.width / 2),
      y: targetBounds.bottom,
      d: anchorBounds.bottom - targetBounds.bottom,
      q: 'top',
      v: true,
    });
  }

  // create custom elements for all created measurements
  measurements
    .map(measurement => Object.assign(measurement, {
      d: Math.round(measurement.d.toFixed(1) * 100) / 100
    }))
    .forEach(measurement => {
      const $measurement = document.createElement('visbug-distance');

      $measurement.position = {
        line_model:     measurement,
        node_label_id:  state.distances.length,
      };

      document.body.appendChild($measurement);
      state.distances[state.distances.length] = $measurement;
    });
}

function clearMeasurements() {
  state.distances.forEach(node => node.remove());
  state.distances = [];
}

/**
 * Take input from [0, n] and return it as [0, 1]
 * @hidden
 */
function bound01(n, max) {
    if (isOnePointZero(n)) {
        n = '100%';
    }
    const processPercent = isPercentage(n);
    n = max === 360 ? n : Math.min(max, Math.max(0, parseFloat(n)));
    // Automatically convert percentage into number
    if (processPercent) {
        n = parseInt(String(n * max), 10) / 100;
    }
    // Handle floating point rounding errors
    if (Math.abs(n - max) < 0.000001) {
        return 1;
    }
    // Convert into [0, 1] range if it isn't already
    if (max === 360) {
        // If n is a hue given in degrees,
        // wrap around out-of-range values into [0, 360] range
        // then convert into [0, 1].
        n = (n < 0 ? n % max + max : n % max) / parseFloat(String(max));
    }
    else {
        // If n not a hue given in degrees
        // Convert into [0, 1] range if it isn't already.
        n = (n % max) / parseFloat(String(max));
    }
    return n;
}
/**
 * Force a number between 0 and 1
 * @hidden
 */
function clamp01(val) {
    return Math.min(1, Math.max(0, val));
}
/**
 * Need to handle 1.0 as 100%, since once it is a number, there is no difference between it and 1
 * <http://stackoverflow.com/questions/7422072/javascript-how-to-detect-number-as-a-decimal-including-1-0>
 * @hidden
 */
function isOnePointZero(n) {
    return typeof n === 'string' && n.indexOf('.') !== -1 && parseFloat(n) === 1;
}
/**
 * Check to see if string passed in is a percentage
 * @hidden
 */
function isPercentage(n) {
    return typeof n === 'string' && n.indexOf('%') !== -1;
}
/**
 * Return a valid alpha value [0,1] with all invalid values being set to 1
 * @hidden
 */
function boundAlpha(a) {
    a = parseFloat(a);
    if (isNaN(a) || a < 0 || a > 1) {
        a = 1;
    }
    return a;
}
/**
 * Replace a decimal with it's percentage value
 * @hidden
 */
function convertToPercentage(n) {
    if (n <= 1) {
        return +n * 100 + '%';
    }
    return n;
}
/**
 * Force a hex value to have 2 characters
 * @hidden
 */
function pad2(c) {
    return c.length === 1 ? '0' + c : '' + c;
}

// `rgbToHsl`, `rgbToHsv`, `hslToRgb`, `hsvToRgb` modified from:
// <http://mjijackson.com/2008/02/rgb-to-hsl-and-rgb-to-hsv-color-model-conversion-algorithms-in-javascript>
/**
 * Handle bounds / percentage checking to conform to CSS color spec
 * <http://www.w3.org/TR/css3-color/>
 * *Assumes:* r, g, b in [0, 255] or [0, 1]
 * *Returns:* { r, g, b } in [0, 255]
 */
function rgbToRgb(r, g, b) {
    return {
        r: bound01(r, 255) * 255,
        g: bound01(g, 255) * 255,
        b: bound01(b, 255) * 255,
    };
}
/**
 * Converts an RGB color value to HSL.
 * *Assumes:* r, g, and b are contained in [0, 255] or [0, 1]
 * *Returns:* { h, s, l } in [0,1]
 */
function rgbToHsl(r, g, b) {
    r = bound01(r, 255);
    g = bound01(g, 255);
    b = bound01(b, 255);
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0;
    let s = 0;
    const l = (max + min) / 2;
    if (max === min) {
        h = s = 0; // achromatic
    }
    else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r:
                h = (g - b) / d + (g < b ? 6 : 0);
                break;
            case g:
                h = (b - r) / d + 2;
                break;
            case b:
                h = (r - g) / d + 4;
                break;
        }
        h /= 6;
    }
    return { h, s, l };
}
/**
 * Converts an HSL color value to RGB.
 *
 * *Assumes:* h is contained in [0, 1] or [0, 360] and s and l are contained [0, 1] or [0, 100]
 * *Returns:* { r, g, b } in the set [0, 255]
 */
function hslToRgb(h, s, l) {
    let r;
    let g;
    let b;
    h = bound01(h, 360);
    s = bound01(s, 100);
    l = bound01(l, 100);
    function hue2rgb(p, q, t) {
        if (t < 0)
            t += 1;
        if (t > 1)
            t -= 1;
        if (t < 1 / 6) {
            return p + (q - p) * 6 * t;
        }
        if (t < 1 / 2) {
            return q;
        }
        if (t < 2 / 3) {
            return p + (q - p) * (2 / 3 - t) * 6;
        }
        return p;
    }
    if (s === 0) {
        r = g = b = l; // achromatic
    }
    else {
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        r = hue2rgb(p, q, h + 1 / 3);
        g = hue2rgb(p, q, h);
        b = hue2rgb(p, q, h - 1 / 3);
    }
    return { r: r * 255, g: g * 255, b: b * 255 };
}
/**
 * Converts an RGB color value to HSV
 *
 * *Assumes:* r, g, and b are contained in the set [0, 255] or [0, 1]
 * *Returns:* { h, s, v } in [0,1]
 */
function rgbToHsv(r, g, b) {
    r = bound01(r, 255);
    g = bound01(g, 255);
    b = bound01(b, 255);
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0;
    const v = max;
    const d = max - min;
    const s = max === 0 ? 0 : d / max;
    if (max === min) {
        h = 0; // achromatic
    }
    else {
        switch (max) {
            case r:
                h = (g - b) / d + (g < b ? 6 : 0);
                break;
            case g:
                h = (b - r) / d + 2;
                break;
            case b:
                h = (r - g) / d + 4;
                break;
        }
        h /= 6;
    }
    return { h: h, s: s, v: v };
}
/**
 * Converts an HSV color value to RGB.
 *
 * *Assumes:* h is contained in [0, 1] or [0, 360] and s and v are contained in [0, 1] or [0, 100]
 * *Returns:* { r, g, b } in the set [0, 255]
 */
function hsvToRgb(h, s, v) {
    h = bound01(h, 360) * 6;
    s = bound01(s, 100);
    v = bound01(v, 100);
    const i = Math.floor(h);
    const f = h - i;
    const p = v * (1 - s);
    const q = v * (1 - f * s);
    const t = v * (1 - (1 - f) * s);
    const mod = i % 6;
    const r = [v, q, p, p, t, v][mod];
    const g = [t, v, v, q, p, p][mod];
    const b = [p, p, t, v, v, q][mod];
    return { r: r * 255, g: g * 255, b: b * 255 };
}
/**
 * Converts an RGB color to hex
 *
 * Assumes r, g, and b are contained in the set [0, 255]
 * Returns a 3 or 6 character hex
 */
function rgbToHex(r, g, b, allow3Char) {
    const hex = [
        pad2(Math.round(r).toString(16)),
        pad2(Math.round(g).toString(16)),
        pad2(Math.round(b).toString(16)),
    ];
    // Return a 3 character hex if possible
    if (allow3Char &&
        hex[0].charAt(0) === hex[0].charAt(1) &&
        hex[1].charAt(0) === hex[1].charAt(1) &&
        hex[2].charAt(0) === hex[2].charAt(1)) {
        return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0);
    }
    return hex.join('');
}
/**
 * Converts an RGBA color plus alpha transparency to hex
 *
 * Assumes r, g, b are contained in the set [0, 255] and
 * a in [0, 1]. Returns a 4 or 8 character rgba hex
 */
function rgbaToHex(r, g, b, a, allow4Char) {
    const hex = [
        pad2(Math.round(r).toString(16)),
        pad2(Math.round(g).toString(16)),
        pad2(Math.round(b).toString(16)),
        pad2(convertDecimalToHex(a)),
    ];
    // Return a 4 character hex if possible
    if (allow4Char &&
        hex[0].charAt(0) === hex[0].charAt(1) &&
        hex[1].charAt(0) === hex[1].charAt(1) &&
        hex[2].charAt(0) === hex[2].charAt(1) &&
        hex[3].charAt(0) === hex[3].charAt(1)) {
        return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0) + hex[3].charAt(0);
    }
    return hex.join('');
}
/** Converts a decimal to a hex value */
function convertDecimalToHex(d) {
    return Math.round(parseFloat(d) * 255).toString(16);
}
/** Converts a hex value to a decimal */
function convertHexToDecimal(h) {
    return parseIntFromHex(h) / 255;
}
/** Parse a base-16 hex value into a base-10 integer */
function parseIntFromHex(val) {
    return parseInt(val, 16);
}

// https://github.com/bahamas10/css-color-names/blob/master/css-color-names.json
/**
 * @hidden
 */
const names = {
    aliceblue: '#f0f8ff',
    antiquewhite: '#faebd7',
    aqua: '#00ffff',
    aquamarine: '#7fffd4',
    azure: '#f0ffff',
    beige: '#f5f5dc',
    bisque: '#ffe4c4',
    black: '#000000',
    blanchedalmond: '#ffebcd',
    blue: '#0000ff',
    blueviolet: '#8a2be2',
    brown: '#a52a2a',
    burlywood: '#deb887',
    cadetblue: '#5f9ea0',
    chartreuse: '#7fff00',
    chocolate: '#d2691e',
    coral: '#ff7f50',
    cornflowerblue: '#6495ed',
    cornsilk: '#fff8dc',
    crimson: '#dc143c',
    cyan: '#00ffff',
    darkblue: '#00008b',
    darkcyan: '#008b8b',
    darkgoldenrod: '#b8860b',
    darkgray: '#a9a9a9',
    darkgreen: '#006400',
    darkgrey: '#a9a9a9',
    darkkhaki: '#bdb76b',
    darkmagenta: '#8b008b',
    darkolivegreen: '#556b2f',
    darkorange: '#ff8c00',
    darkorchid: '#9932cc',
    darkred: '#8b0000',
    darksalmon: '#e9967a',
    darkseagreen: '#8fbc8f',
    darkslateblue: '#483d8b',
    darkslategray: '#2f4f4f',
    darkslategrey: '#2f4f4f',
    darkturquoise: '#00ced1',
    darkviolet: '#9400d3',
    deeppink: '#ff1493',
    deepskyblue: '#00bfff',
    dimgray: '#696969',
    dimgrey: '#696969',
    dodgerblue: '#1e90ff',
    firebrick: '#b22222',
    floralwhite: '#fffaf0',
    forestgreen: '#228b22',
    fuchsia: '#ff00ff',
    gainsboro: '#dcdcdc',
    ghostwhite: '#f8f8ff',
    gold: '#ffd700',
    goldenrod: '#daa520',
    gray: '#808080',
    green: '#008000',
    greenyellow: '#adff2f',
    grey: '#808080',
    honeydew: '#f0fff0',
    hotpink: '#ff69b4',
    indianred: '#cd5c5c',
    indigo: '#4b0082',
    ivory: '#fffff0',
    khaki: '#f0e68c',
    lavender: '#e6e6fa',
    lavenderblush: '#fff0f5',
    lawngreen: '#7cfc00',
    lemonchiffon: '#fffacd',
    lightblue: '#add8e6',
    lightcoral: '#f08080',
    lightcyan: '#e0ffff',
    lightgoldenrodyellow: '#fafad2',
    lightgray: '#d3d3d3',
    lightgreen: '#90ee90',
    lightgrey: '#d3d3d3',
    lightpink: '#ffb6c1',
    lightsalmon: '#ffa07a',
    lightseagreen: '#20b2aa',
    lightskyblue: '#87cefa',
    lightslategray: '#778899',
    lightslategrey: '#778899',
    lightsteelblue: '#b0c4de',
    lightyellow: '#ffffe0',
    lime: '#00ff00',
    limegreen: '#32cd32',
    linen: '#faf0e6',
    magenta: '#ff00ff',
    maroon: '#800000',
    mediumaquamarine: '#66cdaa',
    mediumblue: '#0000cd',
    mediumorchid: '#ba55d3',
    mediumpurple: '#9370db',
    mediumseagreen: '#3cb371',
    mediumslateblue: '#7b68ee',
    mediumspringgreen: '#00fa9a',
    mediumturquoise: '#48d1cc',
    mediumvioletred: '#c71585',
    midnightblue: '#191970',
    mintcream: '#f5fffa',
    mistyrose: '#ffe4e1',
    moccasin: '#ffe4b5',
    navajowhite: '#ffdead',
    navy: '#000080',
    oldlace: '#fdf5e6',
    olive: '#808000',
    olivedrab: '#6b8e23',
    orange: '#ffa500',
    orangered: '#ff4500',
    orchid: '#da70d6',
    palegoldenrod: '#eee8aa',
    palegreen: '#98fb98',
    paleturquoise: '#afeeee',
    palevioletred: '#db7093',
    papayawhip: '#ffefd5',
    peachpuff: '#ffdab9',
    peru: '#cd853f',
    pink: '#ffc0cb',
    plum: '#dda0dd',
    powderblue: '#b0e0e6',
    purple: '#800080',
    rebeccapurple: '#663399',
    red: '#ff0000',
    rosybrown: '#bc8f8f',
    royalblue: '#4169e1',
    saddlebrown: '#8b4513',
    salmon: '#fa8072',
    sandybrown: '#f4a460',
    seagreen: '#2e8b57',
    seashell: '#fff5ee',
    sienna: '#a0522d',
    silver: '#c0c0c0',
    skyblue: '#87ceeb',
    slateblue: '#6a5acd',
    slategray: '#708090',
    slategrey: '#708090',
    snow: '#fffafa',
    springgreen: '#00ff7f',
    steelblue: '#4682b4',
    tan: '#d2b48c',
    teal: '#008080',
    thistle: '#d8bfd8',
    tomato: '#ff6347',
    turquoise: '#40e0d0',
    violet: '#ee82ee',
    wheat: '#f5deb3',
    white: '#ffffff',
    whitesmoke: '#f5f5f5',
    yellow: '#ffff00',
    yellowgreen: '#9acd32',
};

/**
 * Given a string or object, convert that input to RGB
 *
 * Possible string inputs:
 * ```
 * "red"
 * "#f00" or "f00"
 * "#ff0000" or "ff0000"
 * "#ff000000" or "ff000000"
 * "rgb 255 0 0" or "rgb (255, 0, 0)"
 * "rgb 1.0 0 0" or "rgb (1, 0, 0)"
 * "rgba (255, 0, 0, 1)" or "rgba 255, 0, 0, 1"
 * "rgba (1.0, 0, 0, 1)" or "rgba 1.0, 0, 0, 1"
 * "hsl(0, 100%, 50%)" or "hsl 0 100% 50%"
 * "hsla(0, 100%, 50%, 1)" or "hsla 0 100% 50%, 1"
 * "hsv(0, 100%, 100%)" or "hsv 0 100% 100%"
 * ```
 */
function inputToRGB(color) {
    let rgb = { r: 0, g: 0, b: 0 };
    let a = 1;
    let s = null;
    let v = null;
    let l = null;
    let ok = false;
    let format = false;
    if (typeof color === 'string') {
        color = stringInputToObject(color);
    }
    if (typeof color === 'object') {
        if (isValidCSSUnit(color.r) && isValidCSSUnit(color.g) && isValidCSSUnit(color.b)) {
            rgb = rgbToRgb(color.r, color.g, color.b);
            ok = true;
            format = String(color.r).substr(-1) === '%' ? 'prgb' : 'rgb';
        }
        else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.v)) {
            s = convertToPercentage(color.s);
            v = convertToPercentage(color.v);
            rgb = hsvToRgb(color.h, s, v);
            ok = true;
            format = 'hsv';
        }
        else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.l)) {
            s = convertToPercentage(color.s);
            l = convertToPercentage(color.l);
            rgb = hslToRgb(color.h, s, l);
            ok = true;
            format = 'hsl';
        }
        if (color.hasOwnProperty('a')) {
            a = color.a;
        }
    }
    a = boundAlpha(a);
    return {
        ok,
        format: color.format || format,
        r: Math.min(255, Math.max(rgb.r, 0)),
        g: Math.min(255, Math.max(rgb.g, 0)),
        b: Math.min(255, Math.max(rgb.b, 0)),
        a,
    };
}
// <http://www.w3.org/TR/css3-values/#integers>
const CSS_INTEGER = '[-\\+]?\\d+%?';
// <http://www.w3.org/TR/css3-values/#number-value>
const CSS_NUMBER = '[-\\+]?\\d*\\.\\d+%?';
// Allow positive/negative integer/number.  Don't capture the either/or, just the entire outcome.
const CSS_UNIT = `(?:${CSS_NUMBER})|(?:${CSS_INTEGER})`;
// Actual matching.
// Parentheses and commas are optional, but not required.
// Whitespace can take the place of commas or opening paren
const PERMISSIVE_MATCH3 = `[\\s|\\(]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})\\s*\\)?`;
const PERMISSIVE_MATCH4 = `[\\s|\\(]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})\\s*\\)?`;
const matchers = {
    CSS_UNIT: new RegExp(CSS_UNIT),
    rgb: new RegExp('rgb' + PERMISSIVE_MATCH3),
    rgba: new RegExp('rgba' + PERMISSIVE_MATCH4),
    hsl: new RegExp('hsl' + PERMISSIVE_MATCH3),
    hsla: new RegExp('hsla' + PERMISSIVE_MATCH4),
    hsv: new RegExp('hsv' + PERMISSIVE_MATCH3),
    hsva: new RegExp('hsva' + PERMISSIVE_MATCH4),
    hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
    hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
};
/**
 * Permissive string parsing.  Take in a number of formats, and output an object
 * based on detected format.  Returns `{ r, g, b }` or `{ h, s, l }` or `{ h, s, v}`
 */
function stringInputToObject(color) {
    color = color.trim().toLowerCase();
    if (color.length === 0) {
        return false;
    }
    let named = false;
    if (names[color]) {
        color = names[color];
        named = true;
    }
    else if (color === 'transparent') {
        return { r: 0, g: 0, b: 0, a: 0, format: 'name' };
    }
    // Try to match string input using regular expressions.
    // Keep most of the number bounding out of this function - don't worry about [0,1] or [0,100] or [0,360]
    // Just return an object and let the conversion functions handle that.
    // This way the result will be the same whether the tinycolor is initialized with string or object.
    let match = matchers.rgb.exec(color);
    if (match) {
        return { r: match[1], g: match[2], b: match[3] };
    }
    match = matchers.rgba.exec(color);
    if (match) {
        return { r: match[1], g: match[2], b: match[3], a: match[4] };
    }
    match = matchers.hsl.exec(color);
    if (match) {
        return { h: match[1], s: match[2], l: match[3] };
    }
    match = matchers.hsla.exec(color);
    if (match) {
        return { h: match[1], s: match[2], l: match[3], a: match[4] };
    }
    match = matchers.hsv.exec(color);
    if (match) {
        return { h: match[1], s: match[2], v: match[3] };
    }
    match = matchers.hsva.exec(color);
    if (match) {
        return { h: match[1], s: match[2], v: match[3], a: match[4] };
    }
    match = matchers.hex8.exec(color);
    if (match) {
        return {
            r: parseIntFromHex(match[1]),
            g: parseIntFromHex(match[2]),
            b: parseIntFromHex(match[3]),
            a: convertHexToDecimal(match[4]),
            format: named ? 'name' : 'hex8',
        };
    }
    match = matchers.hex6.exec(color);
    if (match) {
        return {
            r: parseIntFromHex(match[1]),
            g: parseIntFromHex(match[2]),
            b: parseIntFromHex(match[3]),
            format: named ? 'name' : 'hex',
        };
    }
    match = matchers.hex4.exec(color);
    if (match) {
        return {
            r: parseIntFromHex(match[1] + match[1]),
            g: parseIntFromHex(match[2] + match[2]),
            b: parseIntFromHex(match[3] + match[3]),
            a: convertHexToDecimal(match[4] + match[4]),
            format: named ? 'name' : 'hex8',
        };
    }
    match = matchers.hex3.exec(color);
    if (match) {
        return {
            r: parseIntFromHex(match[1] + match[1]),
            g: parseIntFromHex(match[2] + match[2]),
            b: parseIntFromHex(match[3] + match[3]),
            format: named ? 'name' : 'hex',
        };
    }
    return false;
}
/**
 * Check to see if it looks like a CSS unit
 * (see `matchers` above for definition).
 */
function isValidCSSUnit(color) {
    return !!matchers.CSS_UNIT.exec(String(color));
}

class TinyColor {
    constructor(color = '', opts = {}) {
        // If input is already a tinycolor, return itself
        if (color instanceof TinyColor) {
            return color;
        }
        this.originalInput = color;
        const rgb = inputToRGB(color);
        this.originalInput = color;
        this.r = rgb.r;
        this.g = rgb.g;
        this.b = rgb.b;
        this.a = rgb.a;
        this.roundA = Math.round(100 * this.a) / 100;
        this.format = opts.format || rgb.format;
        this.gradientType = opts.gradientType;
        // Don't let the range of [0,255] come back in [0,1].
        // Potentially lose a little bit of precision here, but will fix issues where
        // .5 gets interpreted as half of the total, instead of half of 1
        // If it was supposed to be 128, this was already taken care of by `inputToRgb`
        if (this.r < 1) {
            this.r = Math.round(this.r);
        }
        if (this.g < 1) {
            this.g = Math.round(this.g);
        }
        if (this.b < 1) {
            this.b = Math.round(this.b);
        }
        this.isValid = rgb.ok;
    }
    isDark() {
        return this.getBrightness() < 128;
    }
    isLight() {
        return !this.isDark();
    }
    /**
     * Returns the perceived brightness of the color, from 0-255.
     */
    getBrightness() {
        // http://www.w3.org/TR/AERT#color-contrast
        const rgb = this.toRgb();
        return (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1000;
    }
    /**
     * Returns the perceived luminance of a color, from 0-1.
     */
    getLuminance() {
        // http://www.w3.org/TR/2008/REC-WCAG20-20081211/#relativeluminancedef
        const rgb = this.toRgb();
        let R;
        let G;
        let B;
        const RsRGB = rgb.r / 255;
        const GsRGB = rgb.g / 255;
        const BsRGB = rgb.b / 255;
        if (RsRGB <= 0.03928) {
            R = RsRGB / 12.92;
        }
        else {
            R = Math.pow((RsRGB + 0.055) / 1.055, 2.4);
        }
        if (GsRGB <= 0.03928) {
            G = GsRGB / 12.92;
        }
        else {
            G = Math.pow((GsRGB + 0.055) / 1.055, 2.4);
        }
        if (BsRGB <= 0.03928) {
            B = BsRGB / 12.92;
        }
        else {
            B = Math.pow((BsRGB + 0.055) / 1.055, 2.4);
        }
        return 0.2126 * R + 0.7152 * G + 0.0722 * B;
    }
    /**
     * Sets the alpha value on the current color.
     *
     * @param alpha - The new alpha value. The accepted range is 0-1.
     */
    setAlpha(alpha) {
        this.a = boundAlpha(alpha);
        this.roundA = Math.round(100 * this.a) / 100;
        return this;
    }
    /**
     * Returns the object as a HSVA object.
     */
    toHsv() {
        const hsv = rgbToHsv(this.r, this.g, this.b);
        return { h: hsv.h * 360, s: hsv.s, v: hsv.v, a: this.a };
    }
    /**
     * Returns the hsva values interpolated into a string with the following format:
     * "hsva(xxx, xxx, xxx, xx)".
     */
    toHsvString() {
        const hsv = rgbToHsv(this.r, this.g, this.b);
        const h = Math.round(hsv.h * 360);
        const s = Math.round(hsv.s * 100);
        const v = Math.round(hsv.v * 100);
        return this.a === 1 ? `hsv(${h}, ${s}%, ${v}%)` : `hsva(${h}, ${s}%, ${v}%, ${this.roundA})`;
    }
    /**
     * Returns the object as a HSLA object.
     */
    toHsl() {
        const hsl = rgbToHsl(this.r, this.g, this.b);
        return { h: hsl.h * 360, s: hsl.s, l: hsl.l, a: this.a };
    }
    /**
     * Returns the hsla values interpolated into a string with the following format:
     * "hsla(xxx, xxx, xxx, xx)".
     */
    toHslString() {
        const hsl = rgbToHsl(this.r, this.g, this.b);
        const h = Math.round(hsl.h * 360);
        const s = Math.round(hsl.s * 100);
        const l = Math.round(hsl.l * 100);
        return this.a === 1 ? `hsl(${h}, ${s}%, ${l}%)` : `hsla(${h}, ${s}%, ${l}%, ${this.roundA})`;
    }
    /**
     * Returns the hex value of the color.
     * @param allow3Char will shorten hex value to 3 char if possible
     */
    toHex(allow3Char = false) {
        return rgbToHex(this.r, this.g, this.b, allow3Char);
    }
    /**
     * Returns the hex value of the color -with a # appened.
     * @param allow3Char will shorten hex value to 3 char if possible
     */
    toHexString(allow3Char = false) {
        return '#' + this.toHex(allow3Char);
    }
    /**
     * Returns the hex 8 value of the color.
     * @param allow4Char will shorten hex value to 4 char if possible
     */
    toHex8(allow4Char = false) {
        return rgbaToHex(this.r, this.g, this.b, this.a, allow4Char);
    }
    /**
     * Returns the hex 8 value of the color -with a # appened.
     * @param allow4Char will shorten hex value to 4 char if possible
     */
    toHex8String(allow4Char = false) {
        return '#' + this.toHex8(allow4Char);
    }
    /**
     * Returns the object as a RGBA object.
     */
    toRgb() {
        return {
            r: Math.round(this.r),
            g: Math.round(this.g),
            b: Math.round(this.b),
            a: this.a,
        };
    }
    /**
     * Returns the RGBA values interpolated into a string with the following format:
     * "RGBA(xxx, xxx, xxx, xx)".
     */
    toRgbString() {
        const r = Math.round(this.r);
        const g = Math.round(this.g);
        const b = Math.round(this.b);
        return this.a === 1 ? `rgb(${r}, ${g}, ${b})` : `rgba(${r}, ${g}, ${b}, ${this.roundA})`;
    }
    /**
     * Returns the object as a RGBA object.
     */
    toPercentageRgb() {
        const fmt = (x) => Math.round(bound01(x, 255) * 100) + '%';
        return {
            r: fmt(this.r),
            g: fmt(this.g),
            b: fmt(this.b),
            a: this.a,
        };
    }
    /**
     * Returns the RGBA relative values interpolated into a string
     */
    toPercentageRgbString() {
        const rnd = (x) => Math.round(bound01(x, 255) * 100);
        return this.a === 1
            ? `rgb(${rnd(this.r)}%, ${rnd(this.g)}%, ${rnd(this.b)}%)`
            : `rgba(${rnd(this.r)}%, ${rnd(this.g)}%, ${rnd(this.b)}%, ${this.roundA})`;
    }
    /**
     * The 'real' name of the color -if there is one.
     */
    toName() {
        if (this.a === 0) {
            return 'transparent';
        }
        if (this.a < 1) {
            return false;
        }
        const hex = '#' + rgbToHex(this.r, this.g, this.b, false);
        for (const key of Object.keys(names)) {
            if (names[key] === hex) {
                return key;
            }
        }
        return false;
    }
    /**
     * String representation of the color.
     *
     * @param format - The format to be used when displaying the string representation.
     */
    toString(format) {
        const formatSet = !!format;
        format = format || this.format;
        let formattedString = false;
        const hasAlpha = this.a < 1 && this.a >= 0;
        const needsAlphaFormat = !formatSet && hasAlpha && (format.startsWith('hex') || format === 'name');
        if (needsAlphaFormat) {
            // Special case for "transparent", all other non-alpha formats
            // will return rgba when there is transparency.
            if (format === 'name' && this.a === 0) {
                return this.toName();
            }
            return this.toRgbString();
        }
        if (format === 'rgb') {
            formattedString = this.toRgbString();
        }
        if (format === 'prgb') {
            formattedString = this.toPercentageRgbString();
        }
        if (format === 'hex' || format === 'hex6') {
            formattedString = this.toHexString();
        }
        if (format === 'hex3') {
            formattedString = this.toHexString(true);
        }
        if (format === 'hex4') {
            formattedString = this.toHex8String(true);
        }
        if (format === 'hex8') {
            formattedString = this.toHex8String();
        }
        if (format === 'name') {
            formattedString = this.toName();
        }
        if (format === 'hsl') {
            formattedString = this.toHslString();
        }
        if (format === 'hsv') {
            formattedString = this.toHsvString();
        }
        return formattedString || this.toHexString();
    }
    clone() {
        return new TinyColor(this.toString());
    }
    /**
     * Lighten the color a given amount. Providing 100 will always return white.
     * @param amount - valid between 1-100
     */
    lighten(amount = 10) {
        const hsl = this.toHsl();
        hsl.l += amount / 100;
        hsl.l = clamp01(hsl.l);
        return new TinyColor(hsl);
    }
    /**
     * Brighten the color a given amount, from 0 to 100.
     * @param amount - valid between 1-100
     */
    brighten(amount = 10) {
        const rgb = this.toRgb();
        rgb.r = Math.max(0, Math.min(255, rgb.r - Math.round(255 * -(amount / 100))));
        rgb.g = Math.max(0, Math.min(255, rgb.g - Math.round(255 * -(amount / 100))));
        rgb.b = Math.max(0, Math.min(255, rgb.b - Math.round(255 * -(amount / 100))));
        return new TinyColor(rgb);
    }
    /**
     * Darken the color a given amount, from 0 to 100.
     * Providing 100 will always return black.
     * @param amount - valid between 1-100
     */
    darken(amount = 10) {
        const hsl = this.toHsl();
        hsl.l -= amount / 100;
        hsl.l = clamp01(hsl.l);
        return new TinyColor(hsl);
    }
    /**
     * Mix the color with pure white, from 0 to 100.
     * Providing 0 will do nothing, providing 100 will always return white.
     * @param amount - valid between 1-100
     */
    tint(amount = 10) {
        return this.mix('white', amount);
    }
    /**
     * Mix the color with pure black, from 0 to 100.
     * Providing 0 will do nothing, providing 100 will always return black.
     * @param amount - valid between 1-100
     */
    shade(amount = 10) {
        return this.mix('black', amount);
    }
    /**
     * Desaturate the color a given amount, from 0 to 100.
     * Providing 100 will is the same as calling greyscale
     * @param amount - valid between 1-100
     */
    desaturate(amount = 10) {
        const hsl = this.toHsl();
        hsl.s -= amount / 100;
        hsl.s = clamp01(hsl.s);
        return new TinyColor(hsl);
    }
    /**
     * Saturate the color a given amount, from 0 to 100.
     * @param amount - valid between 1-100
     */
    saturate(amount = 10) {
        const hsl = this.toHsl();
        hsl.s += amount / 100;
        hsl.s = clamp01(hsl.s);
        return new TinyColor(hsl);
    }
    /**
     * Completely desaturates a color into greyscale.
     * Same as calling `desaturate(100)`
     */
    greyscale() {
        return this.desaturate(100);
    }
    /**
     * Spin takes a positive or negative amount within [-360, 360] indicating the change of hue.
     * Values outside of this range will be wrapped into this range.
     */
    spin(amount) {
        const hsl = this.toHsl();
        const hue = (hsl.h + amount) % 360;
        hsl.h = hue < 0 ? 360 + hue : hue;
        return new TinyColor(hsl);
    }
    mix(color, amount = 50) {
        const rgb1 = this.toRgb();
        const rgb2 = new TinyColor(color).toRgb();
        const p = amount / 100;
        const rgba = {
            r: (rgb2.r - rgb1.r) * p + rgb1.r,
            g: (rgb2.g - rgb1.g) * p + rgb1.g,
            b: (rgb2.b - rgb1.b) * p + rgb1.b,
            a: (rgb2.a - rgb1.a) * p + rgb1.a,
        };
        return new TinyColor(rgba);
    }
    analogous(results = 6, slices = 30) {
        const hsl = this.toHsl();
        const part = 360 / slices;
        const ret = [this];
        for (hsl.h = (hsl.h - ((part * results) >> 1) + 720) % 360; --results;) {
            hsl.h = (hsl.h + part) % 360;
            ret.push(new TinyColor(hsl));
        }
        return ret;
    }
    /**
     * taken from https://github.com/infusion/jQuery-xcolor/blob/master/jquery.xcolor.js
     */
    complement() {
        const hsl = this.toHsl();
        hsl.h = (hsl.h + 180) % 360;
        return new TinyColor(hsl);
    }
    monochromatic(results = 6) {
        const hsv = this.toHsv();
        const h = hsv.h;
        const s = hsv.s;
        let v = hsv.v;
        const res = [];
        const modification = 1 / results;
        while (results--) {
            res.push(new TinyColor({ h, s, v }));
            v = (v + modification) % 1;
        }
        return res;
    }
    splitcomplement() {
        const hsl = this.toHsl();
        const h = hsl.h;
        return [
            this,
            new TinyColor({ h: (h + 72) % 360, s: hsl.s, l: hsl.l }),
            new TinyColor({ h: (h + 216) % 360, s: hsl.s, l: hsl.l }),
        ];
    }
    triad() {
        return this.polyad(3);
    }
    tetrad() {
        return this.polyad(4);
    }
    /**
     * Get polyad colors, like (for 1, 2, 3, 4, 5, 6, 7, 8, etc...)
     * monad, dyad, triad, tetrad, pentad, hexad, heptad, octad, etc...
     */
    polyad(n) {
        const hsl = this.toHsl();
        const h = hsl.h;
        const result = [this];
        const increment = 360 / n;
        for (let i = 1; i < n; i++) {
            result.push(new TinyColor({ h: (h + i * increment) % 360, s: hsl.s, l: hsl.l }));
        }
        return result;
    }
    /**
     * compare color vs current color
     */
    equals(color) {
        return this.toRgbString() === new TinyColor(color).toRgbString();
    }
}

// Readability Functions
// ---------------------
// <http://www.w3.org/TR/2008/REC-WCAG20-20081211/#contrast-ratiodef (WCAG Version 2)
/**
 * AKA `contrast`
 *
 * Analyze the 2 colors and returns the color contrast defined by (WCAG Version 2)
 */
function readability(color1, color2) {
    const c1 = new TinyColor(color1);
    const c2 = new TinyColor(color2);
    return ((Math.max(c1.getLuminance(), c2.getLuminance()) + 0.05) /
        (Math.min(c1.getLuminance(), c2.getLuminance()) + 0.05));
}
/**
 * Ensure that foreground and background color combinations meet WCAG2 guidelines.
 * The third argument is an object.
 *      the 'level' property states 'AA' or 'AAA' - if missing or invalid, it defaults to 'AA';
 *      the 'size' property states 'large' or 'small' - if missing or invalid, it defaults to 'small'.
 * If the entire object is absent, isReadable defaults to {level:"AA",size:"small"}.
 *
 * Example
 * ```ts
 * new TinyColor().isReadable('#000', '#111') => false
 * new TinyColor().isReadable('#000', '#111', { level: 'AA', size: 'large' }) => false
 * ```
 */
function isReadable(color1, color2, wcag2 = { level: 'AA', size: 'small' }) {
    const readabilityLevel = readability(color1, color2);
    switch ((wcag2.level || 'AA') + (wcag2.size || 'small')) {
        case 'AAsmall':
        case 'AAAlarge':
            return readabilityLevel >= 4.5;
        case 'AAlarge':
            return readabilityLevel >= 3;
        case 'AAAsmall':
            return readabilityLevel >= 7;
    }
    return false;
}

const state$1 = {
  active: {
    tip:  null,
    target: null,
  },
  tips: new Map(),
};

const services = {};

function MetaTip({select}) {
  services.selectors = {select};

  $('body').on('mousemove', mouseMove);
  $('body').on('click', togglePinned);

  hotkeys('esc', _ => removeAll());

  restorePinnedTips();

  return () => {
    $('body').off('mousemove', mouseMove);
    $('body').off('click', togglePinned);
    hotkeys.unbind('esc');
    hideAll();
  }
}

const mouseMove = e => {
  const target = deepElementFromPoint(e.clientX, e.clientY);

  if (isOffBounds(target) || target.nodeName === 'VISBUG-METATIP' || target.hasAttribute('data-metatip')) { // aka: mouse out
    if (state$1.active.tip) {
      wipe({
        tip: state$1.active.tip,
        e: {target: state$1.active.target},
      });
      clearActive();
    }
    return
  }

  toggleTargetCursor(e.altKey, target);

  showTip(target, e);
};

function showTip(target, e) {
  if (!state$1.active.tip) { // create
    const tip = render(target);
    document.body.appendChild(tip);

    positionTip(tip, e);
    observe({tip, target});

    state$1.active.tip    = tip;
    state$1.active.target = target;
  }
  else if (target == state$1.active.target) { // update position
    // update position
    positionTip(state$1.active.tip, e);
  }
  else { // update content
    render(target, state$1.active.tip);
    state$1.active.target = target;
    positionTip(state$1.active.tip, e);
  }
}

function positionTip(tip, e) {
  const { north, west } = mouse_quadrant(e);
  const { left, top }   = tip_position(tip, e, north, west);

  tip.style.left  = left;
  tip.style.top   = top;

  tip.style.setProperty('--arrow', north
    ? 'var(--arrow-up)'
    : 'var(--arrow-down)');

  tip.style.setProperty('--shadow-direction', north
    ? 'var(--shadow-up)'
    : 'var(--shadow-down)');

  tip.style.setProperty('--arrow-top', !north
    ? '-7px'
    : 'calc(100% - 1px)');

  tip.style.setProperty('--arrow-left', west
    ? 'calc(100% - 15px - 15px)'
    : '15px');
}

const restorePinnedTips = () => {
  state$1.tips.forEach(({tip}, target) => {
    tip.style.display = 'block';
    render(target, tip);
    observe({tip, target});
  });
};

function hideAll() {
  state$1.tips.forEach(({tip}, target) =>
    tip.style.display = 'none');

  if (state$1.active.tip) {
    state$1.active.tip.remove();
    clearActive();
  }
}

function removeAll() {
  state$1.tips.forEach(({tip}, target) => {
    tip.remove();
    unobserve({tip, target});
  });

  $('[data-metatip]').attr('data-metatip', null);

  state$1.tips.clear();
}

const render = (el, tip = document.createElement('visbug-metatip')) => {
  const { width, height } = el.getBoundingClientRect();
  const styles = getStyles(el)
    .map(style => Object.assign(style, {
      prop: camelToDash(style.prop)
    }))
    .filter(style =>
      style.prop.includes('font-family')
        ? el.matches('h1,h2,h3,h4,h5,h6,p,a,date,caption,button,figcaption,nav,header,footer')
        : true
    )
    .map(style => {
      if (style.prop.includes('color') || style.prop.includes('Color') || style.prop.includes('fill') || style.prop.includes('stroke'))
        style.value = `<span color style="background-color:${style.value};"></span>${new TinyColor(style.value).toHslString()}`;

      if (style.prop.includes('font-family') && style.value.length > 25)
        style.value = style.value.slice(0,25) + '...';

      if (style.prop.includes('grid-template-areas'))
        style.value = style.value.replace(/" "/g, '"<br>"');

      if (style.prop.includes('background-image'))
        style.value = `<a target="_blank" href="${style.value.slice(style.value.indexOf('(') + 2, style.value.length - 2)}">${style.value.slice(0,25) + '...'}</a>`;

      // check if style is inline style, show indicator
      if (el.getAttribute('style') && el.getAttribute('style').includes(style.prop))
        style.value = `<span local-change>${style.value}</span>`;

      return style
    });

  const localModifications = styles.filter(style =>
    el.getAttribute('style') && el.getAttribute('style').includes(style.prop)
      ? 1
      : 0);

  const notLocalModifications = styles.filter(style =>
    el.getAttribute('style') && el.getAttribute('style').includes(style.prop)
      ? 0
      : 1);

  tip.meta = {
    el,
    width,
    height,
    localModifications,
    notLocalModifications,
  };

  return tip
};

const mouse_quadrant = e => ({
  north: e.clientY > window.innerHeight / 2,
  west:  e.clientX > window.innerWidth / 2
});

const tip_position = (node, e, north, west) => ({
  top: `${north
    ? e.pageY - node.clientHeight - 20
    : e.pageY + 25}px`,
  left: `${west
    ? e.pageX - node.clientWidth + 23
    : e.pageX - 21}px`,
});

const handleBlur = ({target}) => {
  if (!target.hasAttribute('data-metatip') && state$1.tips.has(target))
    wipe(state$1.tips.get(target));
};

const wipe = ({tip, e:{target}}) => {
  tip.remove();
  unobserve({tip, target});
  state$1.tips.delete(target);
};

const togglePinned = e => {
  const target = deepElementFromPoint(e.clientX, e.clientY);

  if (e.altKey && !target.hasAttribute('data-metatip')) {
    target.setAttribute('data-metatip', true);
    state$1.tips.set(target, {
      tip: state$1.active.tip,
      e,
    });
    clearActive();
  }
  else if (target.hasAttribute('data-metatip')) {
    target.removeAttribute('data-metatip');
    wipe(state$1.tips.get(target));
  }
};

const linkQueryClicked = ({detail:{ text, activator }}) => {
  if (!text) return

  queryPage('[data-pseudo-select]', el =>
    el.removeAttribute('data-pseudo-select'));

  queryPage(text + ':not([data-selected])', el =>
    activator === 'mouseenter'
      ? el.setAttribute('data-pseudo-select', true)
      : services.selectors.select(el));
};

const linkQueryHoverOut = e => {
  queryPage('[data-pseudo-select]', el =>
    el.removeAttribute('data-pseudo-select'));
};

const toggleTargetCursor = (key, target) =>
  key
    ? target.setAttribute('data-pinhover', true)
    : target.removeAttribute('data-pinhover');

const observe = ({tip, target}) => {
  $(tip).on('query', linkQueryClicked);
  $(tip).on('unquery', linkQueryHoverOut);
  $(target).on('DOMNodeRemoved', handleBlur);
};

const unobserve = ({tip, target}) => {
  $(tip).off('query', linkQueryClicked);
  $(tip).off('unquery', linkQueryHoverOut);
  $(target).off('DOMNodeRemoved', handleBlur);
};

const clearActive = () => {
  state$1.active.tip    = null;
  state$1.active.target = null;
};

const state$2 = {
  active: {
    tip:  null,
    target: null,
  },
  tips: new Map(),
};

function Accessibility() {
  $('body').on('mousemove', mouseMove$1);
  $('body').on('click', togglePinned$1);

  hotkeys('esc', _ => removeAll$1());

  restorePinnedTips$1();

  return () => {
    $('body').off('mousemove', mouseMove$1);
    $('body').off('click', togglePinned$1);
    hotkeys.unbind('esc');
    hideAll$1();
  }
}

const mouseMove$1 = e => {
  const target = deepElementFromPoint(e.clientX, e.clientY);

  if (isOffBounds(target) || target.nodeName === 'VISBUG-ALLYTIP' || target.hasAttribute('data-allytip')) { // aka: mouse out
    if (state$2.active.tip) {
      wipe$1({
        tip: state$2.active.tip,
        e: {target: state$2.active.target},
      });
      clearActive$1();
    }
    return
  }

  toggleTargetCursor$1(e.altKey, target);

  showTip$1(target, e);
};

function showTip$1(target, e) {
  if (!state$2.active.tip) { // create
    const tip = render$1(target);
    document.body.appendChild(tip);

    positionTip$1(tip, e);
    observe$1({tip, target});

    state$2.active.tip    = tip;
    state$2.active.target = target;
  }
  else if (target == state$2.active.target) { // update position
    // update position
    positionTip$1(state$2.active.tip, e);
  }
  else { // update content
    render$1(target, state$2.active.tip);
    state$2.active.target = target;
    positionTip$1(state$2.active.tip, e);
  }
}

function positionTip$1(tip, e) {
  const { north, west } = mouse_quadrant$1(e);
  const {left, top}     = tip_position$1(tip, e, north, west);

  tip.style.left  = left;
  tip.style.top   = top;

  tip.style.setProperty('--arrow', north
    ? 'var(--arrow-up)'
    : 'var(--arrow-down)');

  tip.style.setProperty('--shadow-direction', north
    ? 'var(--shadow-up)'
    : 'var(--shadow-down)');

  tip.style.setProperty('--arrow-top', !north
    ? '-7px'
    : 'calc(100% - 1px)');

  tip.style.setProperty('--arrow-left', west
    ? 'calc(100% - 15px - 15px)'
    : '15px');
}

const restorePinnedTips$1 = () => {
  state$2.tips.forEach(({tip}, target) => {
    tip.style.display = 'block';
    render$1(target, tip);
    observe$1({tip, target});
  });
};

function hideAll$1() {
  state$2.tips.forEach(({tip}, target) =>
    tip.style.display = 'none');

  if (state$2.active.tip) {
    state$2.active.tip.remove();
    clearActive$1();
  }
}

function removeAll$1() {
  state$2.tips.forEach(({tip}, target) => {
    tip.remove();
    unobserve$1({tip, target});
  });

  $('[data-allytip]').attr('data-allytip', null);

  state$2.tips.clear();
}

const render$1 = (el, tip = document.createElement('visbug-ally')) => {
  const contrast_results = determineColorContrast(el);
  const ally_attributes = getA11ys(el);

  ally_attributes.map(ally =>
    ally.prop.includes('alt')
      ? ally.value = `<span text>${ally.value}</span>`
      : ally);

  ally_attributes.map(ally =>
    ally.prop.includes('title')
      ? ally.value = `<span text longform>${ally.value}</span>`
      : ally);

  tip.meta = {
    el,
    ally_attributes,
    contrast_results,
  };

  return tip
};

const determineColorContrast = el => {
  // question: how to know if the current node is actually a black background?
  // question: is there an api for composited values?
  const text      = getStyle(el, 'color');
  const textSize  = getWCAG2TextSize(el);

  let background  = getComputedBackgroundColor(el);

  const [ aa_contrast, aaa_contrast ] = [
    isReadable(background, text, { level: "AA", size: textSize.toLowerCase() }),
    isReadable(background, text, { level: "AAA", size: textSize.toLowerCase() })
  ];

  return `
    <span prop>Color contrast</span>
    <span value contrast>
      <span style="
        background-color:${background};
        color:${text};
      ">${Math.floor(readability(background, text)  * 100) / 100}</span>
    </span>
    <span prop>› AA ${textSize}</span>
    <span value style="${aa_contrast ? 'color:green;' : 'color:red'}">${aa_contrast ? '✓' : '×'}</span>
    <span prop>› AAA ${textSize}</span>
    <span value style="${aaa_contrast ? 'color:green;' : 'color:red'}">${aaa_contrast ? '✓' : '×'}</span>
  `
};

const mouse_quadrant$1 = e => ({
  north: e.clientY > window.innerHeight / 2,
  west:  e.clientX > window.innerWidth / 2
});

const tip_position$1 = (node, e, north, west) => ({
  top: `${north
    ? e.pageY - node.clientHeight - 20
    : e.pageY + 25}px`,
  left: `${west
    ? e.pageX - node.clientWidth + 23
    : e.pageX - 21}px`,
});

const handleBlur$1 = ({target}) => {
  if (!target.hasAttribute('data-allytip') && state$2.tips.has(target))
    wipe$1(state$2.tips.get(target));
};

const wipe$1 = ({tip, e:{target}}) => {
  tip.remove();
  unobserve$1({tip, target});
  state$2.tips.delete(target);
};

const togglePinned$1 = e => {
  const target = deepElementFromPoint(e.clientX, e.clientY);

  if (e.altKey && !target.hasAttribute('data-allytip')) {
    target.setAttribute('data-allytip', true);
    state$2.tips.set(target, {
      tip: state$2.active.tip,
      e,
    });
    clearActive$1();
  }
  else if (target.hasAttribute('data-allytip')) {
    target.removeAttribute('data-allytip');
    wipe$1(state$2.tips.get(target));
  }
};

const toggleTargetCursor$1 = (key, target) =>
  key
    ? target.setAttribute('data-pinhover', true)
    : target.removeAttribute('data-pinhover');

const observe$1 = ({tip, target}) => {
  $(target).on('DOMNodeRemoved', handleBlur$1);
};

const unobserve$1 = ({tip, target}) => {
  $(target).off('DOMNodeRemoved', handleBlur$1);
};

const clearActive$1 = () => {
  state$2.active.tip    = null;
  state$2.active.target = null;
};

function Selectable() {
  const page              = document.body;
  let selected            = [];
  let selectedCallbacks   = [];
  let labels              = [];
  let handles             = [];

  const hover_state       = {
    target:   null,
    element:  null,
    label:    null,
  };

  const listen = () => {
    page.addEventListener('click', on_click, true);
    page.addEventListener('dblclick', on_dblclick, true);

    page.on('selectstart', on_selection);
    page.on('mousemove', on_hover);

    document.addEventListener('copy', on_copy);
    document.addEventListener('cut', on_cut);
    document.addEventListener('paste', on_paste);

    watchCommandKey();

    hotkeys(`${metaKey}+alt+c`, on_copy_styles);
    hotkeys(`${metaKey}+alt+v`, e => on_paste_styles());
    hotkeys('esc', on_esc);
    hotkeys(`${metaKey}+d`, on_duplicate);
    hotkeys('backspace,del,delete', on_delete);
    hotkeys('alt+del,alt+backspace', on_clearstyles);
    hotkeys(`${metaKey}+e,${metaKey}+shift+e`, on_expand_selection);
    hotkeys(`${metaKey}+g,${metaKey}+shift+g`, on_group);
    hotkeys('tab,shift+tab,enter,shift+enter', on_keyboard_traversal);
    hotkeys(`${metaKey}+shift+enter`, on_select_children);
  };

  const unlisten = () => {
    page.removeEventListener('click', on_click, true);
    page.removeEventListener('dblclick', on_dblclick, true);

    page.off('selectstart', on_selection);
    page.off('mousemove', on_hover);

    document.removeEventListener('copy', on_copy);
    document.removeEventListener('cut', on_cut);
    document.removeEventListener('paste', on_paste);

    hotkeys.unbind(`esc,${metaKey}+d,backspace,del,delete,alt+del,alt+backspace,${metaKey}+e,${metaKey}+shift+e,${metaKey}+g,${metaKey}+shift+g,tab,shift+tab,enter,shift+enter`);
  };

  const on_click = e => {
    const $target = deepElementFromPoint(e.clientX, e.clientY);

    if (isOffBounds($target) && !selected.filter(el => el == $target).length)
      return

    e.preventDefault();
    if (!e.altKey) e.stopPropagation();
    if (!e.shiftKey) unselect_all();

    if(e.shiftKey && $target.hasAttribute('data-selected'))
      unselect($target.getAttribute('data-label-id'));
    else
      select($target);
  };

  const unselect = id => {
    [...labels, ...handles]
      .filter(node =>
          node.getAttribute('data-label-id') === id)
        .forEach(node =>
          node.remove());

    selected.filter(node =>
      node.getAttribute('data-label-id') === id)
      .forEach(node =>
        $(node).attr({
          'data-selected':      null,
          'data-selected-hide': null,
          'data-label-id':      null,
          'data-pseudo-select':         null,
          'data-measuring':     null,
      }));

    selected = selected.filter(node => node.getAttribute('data-label-id') !== id);

    tellWatchers();
  };

  const on_dblclick = e => {
    e.preventDefault();
    e.stopPropagation();
    if (isOffBounds(e.target)) return
    $('vis-bug')[0].toolSelected('text');
  };

  const watchCommandKey = e => {
    let did_hide = false;

    document.onkeydown = function(e) {
      if (hotkeys.ctrl && selected.length) {
        $('visbug-handles, visbug-label, visbug-hover').forEach(el =>
          el.style.display = 'none');

        did_hide = true;
      }
    };

    document.onkeyup = function(e) {
      if (did_hide) {
        $('visbug-handles, visbug-label, visbug-hover').forEach(el =>
          el.style.display = null);

        did_hide = false;
      }
    };
  };

  const on_esc = _ =>
    selected.length && unselect_all();

  const on_duplicate = e => {
    const root_node = selected[0];
    if (!root_node) return

    const deep_clone = root_node.cloneNode(true);
    deep_clone.removeAttribute('data-selected');
    root_node.parentNode.insertBefore(deep_clone, root_node.nextSibling);
    e.preventDefault();
  };

  const on_delete = e =>
    selected.length && delete_all();

  const on_clearstyles = e =>
    selected.forEach(el =>
      el.attr('style', null));

  const on_copy = e => {
    // if user has selected text, dont try to copy an element
    if (window.getSelection().toString().length)
      return

    if (selected[0] && this.node_clipboard !== selected[0]) {
      e.preventDefault();
      let $node = selected[0].cloneNode(true);
      $node.removeAttribute('data-selected');
      this.copy_backup = $node.outerHTML;
      e.clipboardData.setData('text/html', this.copy_backup);
    }
  };

  const on_cut = e => {
    if (selected[0] && this.node_clipboard !== selected[0]) {
      let $node = selected[0].cloneNode(true);
      $node.removeAttribute('data-selected');
      this.copy_backup = $node.outerHTML;
      e.clipboardData.setData('text/html', this.copy_backup);
      selected[0].remove();
    }
  };

  const on_paste = e => {
    const clipData = e.clipboardData.getData('text/html');
    const potentialHTML = clipData || this.copy_backup;
    if (selected[0] && potentialHTML) {
      e.preventDefault();
      selected[0].appendChild(
        htmlStringToDom(potentialHTML));
    }
  };

  const on_copy_styles = e => {
    e.preventDefault();
    this.copied_styles = selected.map(el =>
      getStyles(el));
  };

  const on_paste_styles = (index = 0) =>
    selected.forEach(el => {
      this.copied_styles[index]
        .map(({prop, value}) =>
          el.style[prop] = value);

      index >= this.copied_styles.length - 1
        ? index = 0
        : index++;
    });

  const on_expand_selection = (e, {key}) => {
    e.preventDefault();

    const [root] = selected;
    if (!root) return

    const query = combineNodeNameAndClass(root);

    if (isSelectorValid(query))
      expandSelection({
        query,
        all: key.includes('shift'),
      });
  };

  const on_group = (e, {key}) => {
    e.preventDefault();

    if (key.split('+').includes('shift')) {
      let $selected = [...selected];
      unselect_all();
      $selected.reverse().forEach(el => {
        let l = el.children.length;
        while (el.children.length > 0) {
          var node = el.childNodes[el.children.length - 1];
          if (node.nodeName !== '#text')
            select(node);
          el.parentNode.prepend(node);
        }
        el.parentNode.removeChild(el);
      });
    }
    else {
      let div = document.createElement('div');
      selected[0].parentNode.prepend(
        selected.reverse().reduce((div, el) => {
          div.appendChild(el);
          return div
        }, div)
      );
      unselect_all();
      select(div);
    }
  };

  const on_selection = e =>
    !isOffBounds(e.target)
    && selected.length
    && selected[0].textContent != e.target.textContent
    && e.preventDefault();

  const on_keyboard_traversal = (e, {key}) => {
    if (!selected.length) return

    e.preventDefault();
    e.stopPropagation();

    const targets = selected.reduce((flat_n_unique, node) => {
      const element_to_left     = canMoveLeft(node);
      const element_to_right    = canMoveRight(node);
      const has_parent_element  = findNearestParentElement(node);
      const has_child_elements  = findNearestChildElement(node);

      if (key.includes('shift')) {
        if (key.includes('tab') && element_to_left)
          flat_n_unique.add(element_to_left);
        else if (key.includes('enter') && has_parent_element)
          flat_n_unique.add(has_parent_element);
        else
          flat_n_unique.add(node);
      }
      else {
        if (key.includes('tab') && element_to_right)
          flat_n_unique.add(element_to_right);
        else if (key.includes('enter') && has_child_elements)
          flat_n_unique.add(has_child_elements);
        else
          flat_n_unique.add(node);
      }

      return flat_n_unique
    }, new Set());

    if (targets.size) {
      unselect_all();
      targets.forEach(node => {
        select(node);
        show_tip(node);
      });
    }
  };

  const show_tip = el => {
    const active_tool = $('vis-bug')[0].activeTool;
    let tipFactory;

    if (active_tool === 'accessibility') {
      removeAll$1();
      tipFactory = showTip$1;
    }
    else if (active_tool === 'inspector') {
      removeAll();
      tipFactory = showTip;
    }

    if (!tipFactory) return

    const {top, left} = el.getBoundingClientRect();
    const { pageYOffset, pageXOffset } = window;

    tipFactory(el, {
      clientY:  top,
      clientX:  left,
      pageY:    pageYOffset + top - 10,
      pageX:    pageXOffset + left + 20,
    });
  };

  const on_hover = e => {
    const $target = deepElementFromPoint(e.clientX, e.clientY);

    if (isOffBounds($target) || $target.hasAttribute('data-selected'))
      return clearHover()

    overlayHoverUI($target);

    if (e.altKey && $('vis-bug')[0].activeTool === 'guides' && selected.length === 1 && selected[0] != $target) {
      $target.setAttribute('data-measuring', true);
      const [$anchor] = selected;
      return createMeasurements({$anchor, $target})
    }
    else if ($target.hasAttribute('data-measuring')) {
      $target.removeAttribute('data-measuring');
      clearMeasurements();
    }
  };

  const select = el => {
    el.setAttribute('data-selected', true);
    el.setAttribute('data-label-id', labels.length);

    clearHover();

    overlayMetaUI(el);
    selected.unshift(el);
    tellWatchers();
  };

  const selection = () =>
    selected;

  const unselect_all = () => {
    selected
      .forEach(el =>
        $(el).attr({
          'data-selected':      null,
          'data-selected-hide': null,
          'data-label-id':      null,
          'data-pseudo-select': null,
        }));

    Array.from([...handles, ...labels]).forEach(el =>
      el.remove());

    labels    = [];
    handles   = [];
    selected  = [];
  };

  const delete_all = () => {
    const selected_after_delete = selected.map(el => {
      if (canMoveRight(el))     return canMoveRight(el)
      else if (canMoveLeft(el)) return canMoveLeft(el)
      else if (el.parentNode)   return el.parentNode
    });

    Array.from([...selected, ...labels, ...handles]).forEach(el =>
      el.remove());

    labels    = [];
    handles   = [];
    selected  = [];

    selected_after_delete.forEach(el =>
      select(el));
  };

  const expandSelection = ({query, all = false}) => {
    if (all) {
      const unselecteds = $(query + ':not([data-selected])');
      unselecteds.forEach(select);
    }
    else {
      const potentials = $(query);
      if (!potentials) return

      const [anchor] = selected;
      const root_node_index = potentials.reduce((index, node, i) =>
        node == anchor
          ? index = i
          : index
      , null);

      if (root_node_index !== null) {
        if (!potentials[root_node_index + 1]) {
          const potential = potentials.filter(el => !el.attr('data-selected'))[0];
          if (potential) select(potential);
        }
        else {
          select(potentials[root_node_index + 1]);
        }
      }
    }
  };

  const combineNodeNameAndClass = node =>
    `${node.nodeName.toLowerCase()}${createClassname(node)}`;

  const overlayHoverUI = el => {
    if (hover_state.target === el) return

    hover_state.target  = el;
    hover_state.element = createHover(el);
    hover_state.label = createHoverLabel(el, `
      <a node>${el.nodeName.toLowerCase()}</a>
      <a>${el.id && '#' + el.id}</a>
      ${createClassname(el).split('.')
        .filter(name => name != '')
        .reduce((links, name) => `
          ${links}
          <a>.${name}</a>
        `, '')
      }
    `);
  };

  const clearHover = () => {
    if (!hover_state.target) return

    hover_state.element && hover_state.element.remove();
    hover_state.label && hover_state.label.remove();

    hover_state.target  = null;
    hover_state.element = null;
    hover_state.label   = null;
  };

  const overlayMetaUI = el => {
    let handle = createHandle(el);
    let label  = createLabel(el, `
      <a node>${el.nodeName.toLowerCase()}</a>
      <a>${el.id && '#' + el.id}</a>
      ${createClassname(el).split('.')
        .filter(name => name != '')
        .reduce((links, name) => `
          ${links}
          <a>.${name}</a>
        `, '')
      }
    `);

    let observer        = createObserver(el, {handle,label});
    let parentObserver  = createObserver(el, {handle,label});

    observer.observe(el, { attributes: true });
    parentObserver.observe(el.parentNode, { childList:true, subtree:true });

    $(label).on('DOMNodeRemoved', _ => {
      observer.disconnect();
      parentObserver.disconnect();
    });
  };

  const setLabel = (el, label) =>
    label.update = el.getBoundingClientRect();

  const createLabel = (el, text) => {
    const id = parseInt(el.getAttribute('data-label-id'));

    if (!labels[id]) {
      const label = document.createElement('visbug-label');

      label.text = text;
      label.position = {
        boundingRect:   el.getBoundingClientRect(),
        node_label_id:  id,
      };

      document.body.appendChild(label);

      $(label).on('query', ({detail}) => {
        if (!detail.text) return
        this.query_text = detail.text;

        queryPage('[data-pseudo-select]', el =>
          el.removeAttribute('data-pseudo-select'));

        queryPage(this.query_text + ':not([data-selected])', el =>
          detail.activator === 'mouseenter'
            ? el.setAttribute('data-pseudo-select', true)
            : select(el));
      });

      $(label).on('mouseleave', e => {
        e.preventDefault();
        e.stopPropagation();
        queryPage('[data-pseudo-select]', el =>
          el.removeAttribute('data-pseudo-select'));
      });

      labels[labels.length] = label;

      return label
    }
  };

  const createHandle = el => {
    const id = parseInt(el.getAttribute('data-label-id'));

    if (!handles[id]) {
      const handle = document.createElement('visbug-handles');

      handle.position = {
        boundingRect:   el.getBoundingClientRect(),
        node_label_id:  id,
      };

      document.body.appendChild(handle);

      handles[handles.length] = handle;
      return handle
    }
  };

  const createHover = el => {
    if (!el.hasAttribute('data-pseudo-select') && !el.hasAttribute('data-label-id')) {
      if (hover_state.element)
        hover_state.element.remove();

      hover_state.element = document.createElement('visbug-hover');

      hover_state.element.position = {
        boundingRect: el.getBoundingClientRect(),
      };

      document.body.appendChild(hover_state.element);

      return hover_state.element
    }
  };

  const createHoverLabel = (el, text) => {
    if (!el.hasAttribute('data-pseudo-select') && !el.hasAttribute('data-label-id')) {
      if (hover_state.label)
        hover_state.label.remove();

      hover_state.label = document.createElement('visbug-label');

      hover_state.label.text = text;
      hover_state.label.position = {
        boundingRect:   el.getBoundingClientRect(),
        node_label_id:  'hover',
      };

      hover_state.label.style = `--label-bg: hsl(267, 100%, 58%)`;

      document.body.appendChild(hover_state.label);

      return hover_state.label
    }
  };

  const setHandle = (node, handle) => {
    handle.position = {
      boundingRect:   node.getBoundingClientRect(),
      node_label_id:  node.getAttribute('data-label-id'),
    };
  };

  const createObserver = (node, {label,handle}) =>
    new MutationObserver(list => {
      setLabel(node, label);
      setHandle(node, handle);
    });

  const onSelectedUpdate = (cb, immediateCallback = true) => {
    selectedCallbacks.push(cb);
    if (immediateCallback) cb(selected);
  };

  const removeSelectedCallback = cb =>
    selectedCallbacks = selectedCallbacks.filter(callback => callback != cb);

  const tellWatchers = () =>
    selectedCallbacks.forEach(cb => cb(selected));

  const disconnect = () => {
    unselect_all();
    unlisten();
  };

  const on_select_children = (e, {key}) => {
    const targets = selected
      .filter(node => node.children.length)
      .reduce((flat, {children}) =>
        [...flat, ...Array.from(children)], []);

    if (targets.length) {
      e.preventDefault();
      e.stopPropagation();

      unselect_all();
      targets.forEach(node => select(node));
    }
  };

  watchImagesForUpload();
  listen();

  return {
    select,
    selection,
    unselect_all,
    onSelectedUpdate,
    removeSelectedCallback,
    disconnect,
  }
}

// todo: show padding color
const key_events$2 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},alt+${event},shift+${event},shift+alt+${event}`
  , '')
  .substring(1);

const command_events$1 = `${metaKey}+up,${metaKey}+shift+up,${metaKey}+down,${metaKey}+shift+down`;

function Padding({selection}) {
  hotkeys(key_events$2, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();
    padElement(selection(), handler.key);
  });

  hotkeys(command_events$1, (e, handler) => {
    e.preventDefault();
    padAllElementSides(selection(), handler.key);
  });

  return () => {
    hotkeys.unbind(key_events$2);
    hotkeys.unbind(command_events$1);
    hotkeys.unbind('up,down,left,right'); // bug in lib?
  }
}

function padElement(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'padding' + getSide(direction),
      current:  parseInt(getStyle(el, 'padding' + getSide(direction)), 10),
      amount:   direction.split('+').includes('shift') ? 10 : 1,
      negative: direction.split('+').includes('alt'),
    }))
    .map(payload =>
      Object.assign(payload, {
        padding: payload.negative
          ? payload.current - payload.amount
          : payload.current + payload.amount
      }))
    .forEach(({el, style, padding}) =>
      el.style[style] = `${padding < 0 ? 0 : padding}px`);
}

function padAllElementSides(els, keycommand) {
  const combo = keycommand.split('+');
  let spoof = '';

  if (combo.includes('shift'))  spoof = 'shift+' + spoof;
  if (combo.includes('down'))   spoof = 'alt+' + spoof;

  'up,down,left,right'.split(',')
    .forEach(side => padElement(els, spoof + side));
}

const removeEditability = ({target}) => {
  target.removeAttribute('contenteditable');
  target.removeAttribute('spellcheck');
  target.removeEventListener('blur', removeEditability);
  target.removeEventListener('keydown', stopBubbling$1);
  hotkeys.unbind('escape,esc');
};

const stopBubbling$1 = e => e.key != 'Escape' && e.stopPropagation();

const cleanup = (e, handler) => {
  $('[spellcheck="true"]').forEach(target => removeEditability({target}));
  window.getSelection().empty();
};

function EditText(elements) {
  if (!elements.length) return

  elements.map(el => {
    let $el = $(el);

    $el.attr({
      contenteditable: true,
      spellcheck: true,
    });
    el.focus();
    showHideNodeLabel(el, true);

    $el.on('keydown', stopBubbling$1);
    $el.on('blur', removeEditability);
  });

  hotkeys('escape,esc', cleanup);
}

const key_events$3 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},shift+${event}`
  , '')
  .substring(1);

const command_events$2 = `${metaKey}+up,${metaKey}+down`;

function Font({selection}) {
  hotkeys(key_events$3, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();

    let selectedNodes = selection()
      , keys = handler.key.split('+');

    if (keys.includes('left') || keys.includes('right'))
      keys.includes('shift')
        ? changeKerning(selectedNodes, handler.key)
        : changeAlignment(selectedNodes, handler.key);
    else
      keys.includes('shift')
        ? changeLeading(selectedNodes, handler.key)
        : changeFontSize(selectedNodes, handler.key);
  });

  hotkeys(command_events$2, (e, handler) => {
    e.preventDefault();
    let keys = handler.key.split('+');
    changeFontWeight(selection(), keys.includes('up') ? 'up' : 'down');
  });

  hotkeys('cmd+b', e => {
    selection().forEach(el =>
      el.style.fontWeight =
        el.style.fontWeight == 'bold'
          ? null
          : 'bold');
  });

  hotkeys('cmd+i', e => {
    selection().forEach(el =>
      el.style.fontStyle =
        el.style.fontStyle == 'italic'
          ? null
          : 'italic');
  });

  return () => {
    hotkeys.unbind(key_events$3);
    hotkeys.unbind(command_events$2);
    hotkeys.unbind('cmd+b,cmd+i');
    hotkeys.unbind('up,down,left,right');
  }
}

function changeLeading(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'lineHeight',
      current:  parseInt(getStyle(el, 'lineHeight')),
      amount:   1,
      negative: direction.split('+').includes('down'),
    }))
    .map(payload =>
      Object.assign(payload, {
        current: payload.current == 'normal' || isNaN(payload.current)
          ? 1.14 * parseInt(getStyle(payload.el, 'fontSize')) // document this choice
          : payload.current
      }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.negative
          ? payload.current - payload.amount
          : payload.current + payload.amount
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = `${value}px`);
}

function changeKerning(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'letterSpacing',
      current:  parseFloat(getStyle(el, 'letterSpacing')),
      amount:   .1,
      negative: direction.split('+').includes('left'),
    }))
    .map(payload =>
      Object.assign(payload, {
        current: payload.current == 'normal' || isNaN(payload.current)
          ? 0
          : payload.current
      }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.negative
          ? (payload.current - payload.amount).toFixed(2)
          : (payload.current + payload.amount).toFixed(2)
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = `${value <= -2 ? -2 : value}px`);
}

function changeFontSize(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'fontSize',
      current:  parseInt(getStyle(el, 'fontSize')),
      amount:   direction.split('+').includes('shift') ? 10 : 1,
      negative: direction.split('+').includes('down'),
    }))
    .map(payload =>
      Object.assign(payload, {
        font_size: payload.negative
          ? payload.current - payload.amount
          : payload.current + payload.amount
      }))
    .forEach(({el, style, font_size}) =>
      el.style[style] = `${font_size <= 6 ? 6 : font_size}px`);
}

const weightMap = {
  normal: 2,
  bold:   5,
  light:  0,
  "": 2,
  "100":0,"200":1,"300":2,"400":3,"500":4,"600":5,"700":6,"800":7,"900":8
};
const weightOptions = [100,200,300,400,500,600,700,800,900];

function changeFontWeight(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'fontWeight',
      current:  getStyle(el, 'fontWeight'),
      direction: direction.split('+').includes('down'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? weightMap[payload.current] - 1
          : weightMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = weightOptions[value < 0 ? 0 : value >= weightOptions.length
        ? weightOptions.length
        : value
      ]);
}

const alignMap = {
  start: 0,
  left: 0,
  center: 1,
  right: 2,
};
const alignOptions = ['left','center','right'];

function changeAlignment(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'textAlign',
      current:  getStyle(el, 'textAlign'),
      direction: direction.split('+').includes('left'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? alignMap[payload.current] - 1
          : alignMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = alignOptions[value < 0 ? 0 : value >= 2 ? 2: value]);
}

const key_events$4 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},shift+${event}`
  , '')
  .substring(1);

const command_events$3 = `${metaKey}+up,${metaKey}+down,${metaKey}+left,${metaKey}+right`;

function Flex({selection}) {
  hotkeys(key_events$4, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();

    let selectedNodes = selection()
      , keys = handler.key.split('+');

    if (keys.includes('left') || keys.includes('right'))
      keys.includes('shift')
        ? changeHDistribution(selectedNodes, handler.key)
        : changeHAlignment(selectedNodes, handler.key);
    else
      keys.includes('shift')
        ? changeVDistribution(selectedNodes, handler.key)
        : changeVAlignment(selectedNodes, handler.key);
  });

  hotkeys(command_events$3, (e, handler) => {
    e.preventDefault();

    let selectedNodes = selection()
      , keys = handler.key.split('+');

    changeDirection(selectedNodes, keys.includes('left') ? 'row' : 'column');
  });

  return () => {
    hotkeys.unbind(key_events$4);
    hotkeys.unbind(command_events$3);
    hotkeys.unbind('up,down,left,right');
  }
}

const ensureFlex = el => {
  el.style.display = 'flex';
  return el
};

const accountForOtherJustifyContent = (cur, want) => {
  if (want == 'align' && (cur != 'flex-start' && cur != 'center' && cur != 'flex-end'))
    cur = 'normal';
  else if (want == 'distribute' && (cur != 'space-around' && cur != 'space-between'))
    cur = 'normal';

  return cur
};

// todo: support reversing direction
function changeDirection(els, value) {
  els
    .map(ensureFlex)
    .map(el => {
      el.style.flexDirection = value;
    });
}

const h_alignMap      = {normal: 0,'flex-start': 0,'center': 1,'flex-end': 2,};
const h_alignOptions$1  = ['flex-start','center','flex-end'];

function changeHAlignment(els, direction) {
  els
    .map(ensureFlex)
    .map(el => ({
      el,
      style:    'justifyContent',
      current:  accountForOtherJustifyContent(getStyle(el, 'justifyContent'), 'align'),
      direction: direction.split('+').includes('left'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? h_alignMap[payload.current] - 1
          : h_alignMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = h_alignOptions$1[value < 0 ? 0 : value >= 2 ? 2: value]);
}
const v_alignOptions$1  = ['flex-start','center','flex-end'];

function changeVAlignment(els, direction) {
  els
    .map(ensureFlex)
    .map(el => ({
      el,
      style:    'alignItems',
      current:  getStyle(el, 'alignItems'),
      direction: direction.split('+').includes('up'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? h_alignMap[payload.current] - 1
          : h_alignMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = v_alignOptions$1[value < 0 ? 0 : value >= 2 ? 2: value]);
}

const h_distributionMap      = {normal: 1,'space-around': 0,'': 1,'space-between': 2,};
const h_distributionOptions  = ['space-around','','space-between'];

function changeHDistribution(els, direction) {
  els
    .map(ensureFlex)
    .map(el => ({
      el,
      style:    'justifyContent',
      current:  accountForOtherJustifyContent(getStyle(el, 'justifyContent'), 'distribute'),
      direction: direction.split('+').includes('left'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? h_distributionMap[payload.current] - 1
          : h_distributionMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = h_distributionOptions[value < 0 ? 0 : value >= 2 ? 2: value]);
}

const v_distributionMap      = {normal: 1,'space-around': 0,'': 1,'space-between': 2,};
const v_distributionOptions  = ['space-around','','space-between'];

function changeVDistribution(els, direction) {
  els
    .map(ensureFlex)
    .map(el => ({
      el,
      style:    'alignContent',
      current:  getStyle(el, 'alignContent'),
      direction: direction.split('+').includes('up'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? v_distributionMap[payload.current] - 1
          : v_distributionMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = v_distributionOptions[value < 0 ? 0 : value >= 2 ? 2: value]);
}

function ColorPicker(pallete, selectorEngine) {
  const foregroundPicker  = $('#foreground', pallete);
  const backgroundPicker  = $('#background', pallete);
  const borderPicker      = $('#border', pallete);
  const fgInput           = $('input', foregroundPicker[0]);
  const bgInput           = $('input', backgroundPicker[0]);
  const boInput           = $('input', borderPicker[0]);

  const shadows = {
    active:   'rgba(0, 0, 0, 0.1) 0px 0.25em 0.5em, 0 0 0 2px hotpink',
    inactive: 'rgba(0, 0, 0, 0.1) 0px 0.25em 0.5em',
  };

  this.active_color       = 'background';
  this.elements           = [];

  // set colors
  fgInput.on('input', e =>
    this.elements.map(el =>
      el.style['color'] = e.target.value));

  bgInput.on('input', e =>
    this.elements.map(el =>
      el.style[el instanceof SVGElement
        ? 'fill'
        : 'backgroundColor'
      ] = e.target.value));

  boInput.on('input', e =>
    this.elements.map(el =>
      el.style[el instanceof SVGElement
        ? 'stroke'
        : 'border-color'
      ] = e.target.value));

  // read colors
  selectorEngine.onSelectedUpdate(elements => {
    if (!elements.length) return
    this.elements = elements;

    let isMeaningfulForeground  = false;
    let isMeaningfulBackground  = false;
    let isMeaningfulBorder      = false;
    let FG, BG, BO;

    if (this.elements.length == 1) {
      const el = this.elements[0];
      const meaningfulDontMatter = pallete.host.active_tool.dataset.tool === 'hueshift';

      if (el instanceof SVGElement) {
        FG = new TinyColor('rgb(0, 0, 0)');
        var bo_temp = getStyle(el, 'stroke');
        BO = new TinyColor(bo_temp === 'none'
          ? 'rgb(0, 0, 0)'
          : bo_temp);
        BG = new TinyColor(getStyle(el, 'fill'));
      }
      else {
        FG = new TinyColor(getStyle(el, 'color'));
        BG = new TinyColor(getStyle(el, 'backgroundColor'));
        BO = getStyle(el, 'borderWidth') === '0px'
          ? new TinyColor('rgb(0, 0, 0)')
          : new TinyColor(getStyle(el, 'borderColor'));
      }

      let fg = FG.toHexString();
      let bg = BG.toHexString();
      let bo = BO.toHexString();

      isMeaningfulForeground = FG.originalInput !== 'rgb(0, 0, 0)' || (el.children.length === 0 && el.textContent !== '');
      isMeaningfulBackground = BG.originalInput !== 'rgba(0, 0, 0, 0)';
      isMeaningfulBorder     = BO.originalInput !== 'rgb(0, 0, 0)';

      if (isMeaningfulForeground && !isMeaningfulBackground)
        setActive('foreground');
      else if (isMeaningfulBackground && !isMeaningfulForeground)
        setActive('background');

      const new_fg = isMeaningfulForeground ? fg : '';
      const new_bg = isMeaningfulBackground ? bg : '';
      const new_bo = isMeaningfulBorder ? bo : '';

      fgInput.attr('value', new_fg);
      bgInput.attr('value', new_bg);
      boInput.attr('value', new_bo);

      foregroundPicker.attr('style', `
        --contextual_color: ${new_fg};
        display: ${isMeaningfulForeground || meaningfulDontMatter ? 'inline-flex' : 'none'};
      `);

      backgroundPicker.attr('style', `
        --contextual_color: ${new_bg};
        display: ${isMeaningfulBackground || meaningfulDontMatter ? 'inline-flex' : 'none'};
      `);

      borderPicker.attr('style', `
        --contextual_color: ${new_bo};
        display: ${isMeaningfulBorder || meaningfulDontMatter ? 'inline-flex' : 'none'};
      `);
    }
    else {
      // show all 3 if they've selected more than 1 node
      // todo: this is giving up, and can be solved
      foregroundPicker.attr('style', `
        box-shadow: ${this.active_color == 'foreground' ? shadows.active : shadows.inactive};
        display: inline-flex;
      `);

      backgroundPicker.attr('style', `
        box-shadow: ${this.active_color == 'background' ? shadows.active : shadows.inactive};
        display: inline-flex;
      `);

      borderPicker.attr('style', `
        box-shadow: ${this.active_color == 'border' ? shadows.active : shadows.inactive};
        display: inline-flex;
      `);
    }
  });

  const getActive = () =>
    this.active_color;

  const setActive = key => {
    removeActive();
    this.active_color = key;

    if (key === 'foreground')
      foregroundPicker[0].style.boxShadow = shadows.active;
    if (key === 'background')
      backgroundPicker[0].style.boxShadow = shadows.active;
    if (key === 'border')
      borderPicker[0].style.boxShadow = shadows.active;
  };

  const removeActive = () =>
    [foregroundPicker, backgroundPicker, borderPicker].forEach(([picker]) =>
      picker.style.boxShadow = shadows.inactive);

  return {
    getActive,
    setActive,
    foreground: { color: color =>
      foregroundPicker[0].style.setProperty('--contextual_color', color)},
    background: { color: color =>
      backgroundPicker[0].style.setProperty('--contextual_color', color)}
  }
}

const key_events$5 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},shift+${event}`
  , '')
  .substring(1);

const command_events$4 = `${metaKey}+up,${metaKey}+shift+up,${metaKey}+down,${metaKey}+shift+down,${metaKey}+left,${metaKey}+shift+left,${metaKey}+right,${metaKey}+shift+right`;

function BoxShadow({selection}) {
  hotkeys(key_events$5, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();

    let selectedNodes = selection()
      , keys = handler.key.split('+');

    if (keys.includes('left') || keys.includes('right'))
      keys.includes('shift')
        ? changeBoxShadow(selectedNodes, keys, 'size')
        : changeBoxShadow(selectedNodes, keys, 'x');
    else
      keys.includes('shift')
        ? changeBoxShadow(selectedNodes, keys, 'blur')
        : changeBoxShadow(selectedNodes, keys, 'y');
  });

  hotkeys(command_events$4, (e, handler) => {
    e.preventDefault();
    let keys = handler.key.split('+');
    keys.includes('left') || keys.includes('right')
      ? changeBoxShadow(selection(), keys, 'opacity')
      : changeBoxShadow(selection(), keys, 'inset');
  });

  return () => {
    hotkeys.unbind(key_events$5);
    hotkeys.unbind(command_events$4);
    hotkeys.unbind('up,down,left,right');
  }
}

const ensureHasShadow = el => {
  if (el.style.boxShadow == '' || el.style.boxShadow == 'none')
    el.style.boxShadow = 'hsla(0,0%,0%,30%) 0 0 0 0';
  return el
};

// todo: work around this propMap with a better split
const propMap = {
  'opacity':  3,
  'x':        4,
  'y':        5,
  'blur':     6,
  'size':     7,
  'inset':    8,
};

const parseCurrentShadow = el => getStyle(el, 'boxShadow').split(' ');

function changeBoxShadow(els, direction, prop) {
  els
    .map(ensureHasShadow)
    .map(el => showHideSelected(el, 1500))
    .map(el => ({
      el,
      style:     'boxShadow',
      current:   parseCurrentShadow(el), // ["rgb(255,", "0,", "0)", "0px", "0px", "1px", "0px"]
      propIndex: parseCurrentShadow(el)[0].includes('rgba') ? propMap[prop] : propMap[prop] - 1
    }))
    .map(payload => {
      let updated = [...payload.current];
      let cur     = prop === 'opacity'
        ? payload.current[payload.propIndex]
        : parseInt(payload.current[payload.propIndex]);

      switch(prop) {
        case 'blur':
          var amount = direction.includes('shift') ? 10 : 1;
          updated[payload.propIndex] = direction.includes('down')
            ? `${cur - amount}px`
            : `${cur + amount}px`;
          break
        case 'inset':
          updated[payload.propIndex] = direction.includes('down')
            ? 'inset'
            : '';
          break
        case 'opacity':
          let cur_opacity = parseFloat(cur.slice(0, cur.indexOf(')')));
          var amount = direction.includes('shift') ? 0.10 : 0.01;
          updated[payload.propIndex] = direction.includes('left')
            ? cur_opacity - amount + ')'
            : cur_opacity + amount + ')';
          break
        default:
          updated[payload.propIndex] = direction.includes('left') || direction.includes('up')
            ? `${cur - 1}px`
            : `${cur + 1}px`;
          break
      }

      payload.value = updated;
      return payload
    })
    .forEach(({el, style, value}) =>
      el.style[style] = value.join(' '));
}

const key_events$6 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},shift+${event}`
  , '')
  .substring(1);

const command_events$5 = `${metaKey}+up,${metaKey}+shift+up,${metaKey}+down,${metaKey}+shift+down,${metaKey}+left,${metaKey}+shift+left,${metaKey}+right,${metaKey}+shift+right`;

function HueShift(Color) {
  this.active_color   = Color.getActive();
  this.elements       = [];

  hotkeys(key_events$6, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();

    let selectedNodes = this.elements
      , keys = handler.key.split('+');

    keys.includes('left') || keys.includes('right')
      ? changeHue(selectedNodes, keys, 's', Color)
      : changeHue(selectedNodes, keys, 'l', Color);
  });

  hotkeys(command_events$5, (e, handler) => {
    e.preventDefault();
    let keys = handler.key.split('+');
    keys.includes('left') || keys.includes('right')
      ? changeHue(this.elements, keys, 'a', Color)
      : changeHue(this.elements, keys, 'h', Color);
  });

  hotkeys(']', (e, handler) => {
    e.preventDefault();

    if (this.active_color == 'foreground')
      this.active_color = 'background';
    else if (this.active_color == 'background')
      this.active_color = 'border';

    Color.setActive(this.active_color);
  });

  hotkeys('[', (e, handler) => {
    e.preventDefault();

    if (this.active_color == 'background')
      this.active_color = 'foreground';
    else if (this.active_color == 'border')
      this.active_color = 'background';

    Color.setActive(this.active_color);
  });

  const onNodesSelected = els => {
    this.elements = els;
    Color.setActive(this.active_color);
  };

  const disconnect = () => {
    hotkeys.unbind(key_events$6);
    hotkeys.unbind(command_events$5);
    hotkeys.unbind('up,down,left,right');
  };

  return {
    onNodesSelected,
    disconnect,
  }
}

function changeHue(els, direction, prop, Color) {
  els
    .map(el => showHideSelected(el))
    .map(el => {
      const { foreground, background, border } = extractPalleteColors(el);

      // todo: teach hueshift to do handle color
      switch(Color.getActive()) {
        case 'background':
          return { el, current: background.color.toHsl(), style: background.style }
        case 'foreground':
          return { el, current: foreground.color.toHsl(), style: foreground.style }
        case 'border': {
          if (el.style.border === '') el.style.border = '1px solid black';
          return { el, current: border.color.toHsl(), style: border.style }
        }
      }
    })
    .map(payload =>
      Object.assign(payload, {
        amount:   direction.includes('shift') ? 10 : 1,
        negative: direction.includes('down') || direction.includes('left'),
      }))
    .map(payload => {
      if (prop === 's' || prop === 'l' || prop === 'a')
        payload.amount = payload.amount * 0.01;

      payload.current[prop] = payload.negative
        ? payload.current[prop] - payload.amount
        : payload.current[prop] + payload.amount;

      if (prop === 's' || prop === 'l' || prop === 'a') {
        if (payload.current[prop] > 1) payload.current[prop] = 1;
        if (payload.current[prop] < 0) payload.current[prop] = 0;
      }

      return payload
    })
    .forEach(({el, style, current}) => {
      let color = new TinyColor(current).setAlpha(current.a);
      el.style[style] = color.toHslString();

      if (style == 'color') Color.foreground.color(color.toHexString());
      if (style == 'backgroundColor') Color.background.color(color.toHexString());
    });
}

function extractPalleteColors(el) {
  if (el instanceof SVGElement) {
    const  fg_temp = getStyle(el, 'stroke');

    return {
      foreground: {
        style: 'stroke',
        color: new TinyColor(fg_temp === 'none'
          ? 'rgb(0, 0, 0)'
          : fg_temp),
      },
      background: {
        style: 'fill',
        color: new TinyColor(getStyle(el, 'fill')),
      },
      border: {
        style: 'outline',
        color: new TinyColor(getStyle(el, 'outline')),
      }
    }
  }
  else
    return {
      foreground: {
        style: 'color',
        color: new TinyColor(getStyle(el, 'color')),
      },
      background: {
        style: 'backgroundColor',
        color: new TinyColor(getStyle(el, 'backgroundColor')),
      },
      border: {
        style: 'borderColor',
        color: new TinyColor(getStyle(el, 'borderColor')),
      }
    }
}

let gridlines;

function Guides() {
  $('body').on('mousemove', on_hover);
  $('body').on('mouseout', on_hoverout);
  window.addEventListener('scroll', hideGridlines);

  return () => {
    $('body').off('mousemove', on_hover);
    $('body').off('mouseout', on_hoverout);
    window.removeEventListener('scroll', hideGridlines);
    hideGridlines();
  }
}

const on_hover = e => {
  const target = deepElementFromPoint(e.clientX, e.clientY);
  if (isOffBounds(target)) return
  showGridlines(target);
};

const on_hoverout = ({target}) =>
  hideGridlines();

const showGridlines = node => {
  if (gridlines) {
    gridlines.style.display = null;
    gridlines.update = node.getBoundingClientRect();
  }
  else {
    gridlines = document.createElement('visbug-gridlines');
    gridlines.position = node.getBoundingClientRect();

    document.body.appendChild(gridlines);
  }
};

const hideGridlines = node => {
  if (!gridlines) return
  gridlines.style.display = 'none';
};

function Screenshot(node, page) {
  alert('Coming Soon!');

  return () => {}
}

const key_events$7 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},alt+${event},shift+${event},shift+alt+${event}`
  , '')
  .substring(1);

function Position() {
  const state = {
    elements: []
  };

  hotkeys(key_events$7, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();
    positionElement(state.elements, handler.key);
  });

  const onNodesSelected = els => {
    state.elements.forEach(el =>
      el.teardown());

    state.elements = els.map(el =>
      draggable(el));
  };

  const disconnect = () => {
    state.elements.forEach(el => el.teardown());
    hotkeys.unbind(key_events$7);
    hotkeys.unbind('up,down,left,right');
  };

  return {
    onNodesSelected,
    disconnect,
  }
}

function draggable(el) {
  this.state = {
    mouse: {
      down: false,
      x: 0,
      y: 0,
    },
    element: {
      x: 0,
      y: 0,
    }
  };

  const setup = () => {
    el.style.transition   = 'none';
    el.style.cursor       = 'move';

    el.addEventListener('mousedown', onMouseDown, true);
    el.addEventListener('mouseup', onMouseUp, true);
    document.addEventListener('mousemove', onMouseMove, true);
  };

  const teardown = () => {
    el.style.transition   = null;
    el.style.cursor       = null;

    el.removeEventListener('mousedown', onMouseDown, true);
    el.removeEventListener('mouseup', onMouseUp, true);
    document.removeEventListener('mousemove', onMouseMove, true);
  };

  const onMouseDown = e => {
    e.preventDefault();

    const el = e.target;

    el.style.position = 'relative';
    el.style.willChange = 'top,left';

    if (el instanceof SVGElement) {
      const translate = el.getAttribute('transform');

      const [ x, y ] = translate
        ? extractSVGTranslate(translate)
        : [0,0];

      this.state.element.x  = x;
      this.state.element.y  = y;
    }
    else {
      this.state.element.x  = parseInt(getStyle(el, 'left'));
      this.state.element.y  = parseInt(getStyle(el, 'top'));
    }

    this.state.mouse.x      = e.clientX;
    this.state.mouse.y      = e.clientY;
    this.state.mouse.down   = true;
  };

  const onMouseUp = e => {
    e.preventDefault();
    e.stopPropagation();

    this.state.mouse.down = false;
    el.style.willChange = null;

    if (el instanceof SVGElement) {
      const translate = el.getAttribute('transform');

      const [ x, y ] = translate
        ? extractSVGTranslate(translate)
        : [0,0];

      this.state.element.x    = x;
      this.state.element.y    = y;
    }
    else {
      this.state.element.x    = parseInt(el.style.left) || 0;
      this.state.element.y    = parseInt(el.style.top) || 0;
    }
  };

  const onMouseMove = e => {
    e.preventDefault();
    e.stopPropagation();

    if (!this.state.mouse.down) return

    if (el instanceof SVGElement) {
      el.setAttribute('transform', `translate(
        ${this.state.element.x + e.clientX - this.state.mouse.x},
        ${this.state.element.y + e.clientY - this.state.mouse.y}
      )`);
    }
    else {
      el.style.left = this.state.element.x + e.clientX - this.state.mouse.x + 'px';
      el.style.top  = this.state.element.y + e.clientY - this.state.mouse.y + 'px';
    }
  };

  setup();
  el.teardown = teardown;

  return el
}

function positionElement(els, direction) {
  els
    .map(el => ensurePositionable(el))
    .map(el => showHideSelected(el))
    .map(el => ({
        el,
        ...extractCurrentValueAndSide(el, direction),
        amount:   direction.split('+').includes('shift') ? 10 : 1,
        negative: determineNegativity(el, direction),
    }))
    .map(payload =>
      Object.assign(payload, {
        position: payload.negative
          ? payload.current + payload.amount
          : payload.current - payload.amount
      }))
    .forEach(({el, style, position}) =>
      el instanceof SVGElement
        ? setTranslateOnSVG(el, direction, position)
        : el.style[style] = position + 'px');
}

const extractCurrentValueAndSide = (el, direction) => {
  let style, current;

  if (el instanceof SVGElement) {
    const translate = el.attr('transform');

    const [ x, y ] = translate
      ? extractSVGTranslate(translate)
      : [0,0];

    style   = 'transform';
    current = direction.includes('down') || direction.includes('up')
      ? y
      : x;
  }
  else {
    const side = getSide(direction).toLowerCase();
    style = (side === 'top' || side === 'bottom') ? 'top' : 'left';
    current = getStyle(el, style);

    current === 'auto'
      ? current = 0
      : current = parseInt(current, 10);
  }

  return { style, current }
};

const extractSVGTranslate = translate =>
  translate.substring(
    translate.indexOf('(') + 1,
    translate.indexOf(')')
  ).split(',')
  .map(val => parseFloat(val));

const setTranslateOnSVG = (el, direction, position) => {
  const transform = el.attr('transform');
  const [ x, y ] = transform
    ? extractSVGTranslate(transform)
    : [0,0];

  const pos = direction.includes('down') || direction.includes('up')
    ? `${x},${position}`
    : `${position},${y}`;

  el.attr('transform', `translate(${pos})`);
};

const determineNegativity = (el, direction) =>
  direction.includes('right') || direction.includes('down');

const ensurePositionable = el => {
  if (el instanceof HTMLElement)
    el.style.position = 'relative';
  return el
};

const VisBugModel = {
  g: {
    tool:        'guides',
    icon:        guides,
    label:       'Guides',
    description: 'Verify alignment & check your grid',
    instruction: `<div table>
                    <div>
                      <b>Measure:</b>
                      <span>${altKey} + hover</span>
                    </div>
                  </div>`,
  },
  i: {
    tool:        'inspector',
    icon:        inspector,
    label:       'Inspect',
    description: 'Peek into common & current styles of an element',
    instruction: `<div table>
                    <div>
                      <b>Pin it:</b>
                      <span>${altKey} + click</span>
                    </div>
                  </div>`,
  },
  x: {
    tool:        'accessibility',
    icon:        accessibility,
    label:       'Accessibility',
    description: 'Peek into A11y attributes & compliance status',
    instruction: `<div table>
                    <div>
                      <b>Pin it:</b>
                      <span>${altKey} + click</span>
                    </div>
                  </div>`,
  },
  v: {
    tool:        'move',
    icon:        move,
    label:       'Move',
    description: 'Push elements in & out of their container, or shuffle them within it',
    instruction: `<div table>
                    <div>
                      <b>Lateral:</b>
                      <span>◀ ▶</span>
                    </div>
                    <div>
                      <b>Out and above:</b>
                      <span>▲</span>
                    </div>
                    <div>
                      <b>Down and in:</b>
                      <span>▼</span>
                    </div>
                  </div>`,
  },
  // r: {
  //   tool:        'resize',
  //   icon:        Icons.resize,
  //   label:       'Resize',
  //   description: ''
  // },
  m: {
    tool:        'margin',
    icon:        margin,
    label:       'Margin',
    description: 'Add or subtract outer space from any or all sides of the selected element(s)',
    instruction: `<div table>
                    <div>
                      <b>+ Margin:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>- Margin:</b>
                      <span>${altKey} + ◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>All Sides:</b>
                      <span>${metaKey} +  ▲ ▼</span>
                    </div>
                  </div>`,
  },
  p: {
    tool:        'padding',
    icon:        padding,
    label:       'Padding',
    description: `Add or subtract inner space from any or all sides of the selected element(s)`,
    instruction: `<div table>
                    <div>
                      <b>+ Padding:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>- Padding:</b>
                      <span>${altKey} + ◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>All Sides:</b>
                      <span>${metaKey} +  ▲ ▼</span>
                    </div>
                  </div>`
  },
  // b: {
  //   tool:        'border',
  //   icon:        Icons.border,
  //   label:       'Border',
  //   description: ''
  // },
  a: {
    tool:        'align',
    icon:        align,
    label:       'Flexbox Align',
    description: `Create or modify flexbox direction, distribution & alignment`,
    instruction: `<div table>
                    <div>
                      <b>Alignment:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>Distribution:</b>
                      <span>Shift + ◀ ▶</span>
                    </div>
                    <div>
                      <b>Direction:</b>
                      <span>${metaKey} +  ◀ ▼</span>
                    </div>
                  </div>`,
  },
  h: {
    tool:        'hueshift',
    icon:        hueshift,
    label:       'Hue Shift',
    description: `Change foreground/background hue, brightness, saturation & opacity`,
    instruction: `<div table>
                    <div>
                      <b>Saturation:</b>
                      <span>◀ ▶</span>
                    </div>
                    <div>
                      <b>Brightness:</b>
                      <span>▲ ▼</span>
                    </div>
                    <div>
                      <b>Hue:</b>
                      <span>${metaKey} +  ▲ ▼</span>
                    </div>
                    <div>
                      <b>Opacity:</b>
                      <span>${metaKey} +  ◀ ▶</span>
                    </div>
                  </div>`,
  },
  d: {
    tool:        'boxshadow',
    icon:        boxshadow,
    label:       'Shadow',
    description: `Create & adjust position, blur & opacity of a box shadow`,
    instruction: `<div table>
                    <div>
                      <b>X/Y Position:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>Blur:</b>
                      <span>Shift + ▲ ▼</span>
                    </div>
                    <div>
                      <b>Spread:</b>
                      <span>Shift + ◀ ▶</span>
                    </div>
                    <div>
                      <b>Opacity:</b>
                      <span>${metaKey} + ◀ ▶</span>
                    </div>
                  </div>`,
  },
  // t: {
  //   tool:        'transform',
  //   icon:        Icons.transform,
  //   label:       '3D Transform',
  //   description: ''
  // },
  l: {
    tool:        'position',
    icon:        position,
    label:       'Position',
    description: 'Move svg (x,y) and elements (top,left,bottom,right)',
    instruction: `<div table>
                    <div>
                      <b>Nudge:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>Move:</b>
                      <span>Click & drag</span>
                    </div>
                  </div>`,
  },
  f: {
    tool:        'font',
    icon:        font,
    label:       'Font Styles',
    description: 'Change size, alignment, leading, letter-spacing, & weight',
    instruction: `<div table>
                    <div>
                      <b>Size:</b>
                      <span>▲ ▼</span>
                    </div>
                    <div>
                      <b>Alignment:</b>
                      <span>◀ ▶</span>
                    </div>
                    <div>
                      <b>Leading:</b>
                      <span>Shift + ▲ ▼</span>
                    </div>
                    <div>
                      <b>Letter-spacing:</b>
                      <span>Shift + ◀ ▶</span>
                    </div>
                    <div>
                      <b>Weight:</b>
                      <span>${metaKey} + ▲ ▼</span>
                    </div>
                  </div>`,
  },
  e: {
    tool:        'text',
    icon:        text,
    label:       'Edit Text',
    description: 'Change any text on the page with a <b>double click</b>',
    instruction: '',
  },
  // c: {
  //   tool:        'screenshot',
  //   icon:        Icons.camera,
  //   label:       'Screenshot',
  //   description: 'Screenshot selected elements or the entire page'
  // },
  s: {
    tool:        'search',
    icon:        search,
    label:       'Search',
    description: 'Select elements programatically by searching for them or use built in plugins with special commands',
    instruction: '',
  },
};

class VisBug extends HTMLElement {
  constructor() {
    super();

    this.toolbar_model  = VisBugModel;
    this._tutsBaseURL   = 'tuts'; // can be set by content script
    this.$shadow        = this.attachShadow({mode: 'closed'});
  }

  connectedCallback() {
    if (!this.$shadow.innerHTML)
      this.setup();

    this.selectorEngine = Selectable();
    this.colorPicker    = ColorPicker(this.$shadow, this.selectorEngine);
    provideSelectorEngine(this.selectorEngine);
  }

  disconnectedCallback() {
    this.deactivate_feature();
    this.selectorEngine.disconnect();
    hotkeys.unbind(
      Object.keys(this.toolbar_model).reduce((events, key) =>
        events += ',' + key, ''));
    hotkeys.unbind(`${metaKey}+/`);
  }

  setup() {
    this.$shadow.innerHTML = this.render();

    $('li[data-tool]', this.$shadow).on('click', e =>
      this.toolSelected(e.currentTarget) && e.stopPropagation());

    Object.entries(this.toolbar_model).forEach(([key, value]) =>
      hotkeys(key, e => {
        e.preventDefault();
        this.toolSelected(
          $(`[data-tool="${value.tool}"]`, this.$shadow)[0]
        );
      })
    );

    hotkeys(`${metaKey}+/,${metaKey}+.`, e =>
      this.$shadow.host.style.display =
        this.$shadow.host.style.display === 'none'
          ? 'block'
          : 'none');

    this.toolSelected($('[data-tool="guides"]', this.$shadow)[0]);
  }

  toolSelected(el) {
    if (typeof el === 'string')
      el = $(`[data-tool="${el}"]`, this.$shadow)[0];

    if (this.active_tool && this.active_tool.dataset.tool === el.dataset.tool) return

    if (this.active_tool) {
      this.active_tool.attr('data-active', null);
      this.deactivate_feature();
    }

    el.attr('data-active', true);
    this.active_tool = el;
    this[el.dataset.tool]();
  }

  render() {
    return `
      ${this.styles()}
      <visbug-hotkeys></visbug-hotkeys>
      <ol>
        ${Object.entries(this.toolbar_model).reduce((list, [key, tool]) => `
          ${list}
          <li aria-label="${tool.label} Tool" aria-description="${tool.description}" aria-hotkey="${key}" data-tool="${tool.tool}" data-active="${key == 'g'}">
            ${tool.icon}
            ${this.demoTip({key, ...tool})}
          </li>
        `,'')}
      </ol>
      <ol colors>
        <li style="display: none;" class="color" id="foreground" aria-label="Text" aria-description="Change the text color">
          <input type="color" value="">
          ${color_text}
        </li>
        <li style="display: none;" class="color" id="background" aria-label="Background or Fill" aria-description="Change the background color or fill of svg">
          <input type="color" value="">
          ${color_background}
        </li>
        <li style="display: none;" class="color" id="border" aria-label="Border or Stroke" aria-description="Change the border color or stroke of svg">
          <input type="color" value="">
          ${color_border}
        </li>
      </ol>
    `
  }

  styles() {
    return `
      <style>
        ${css}
      </style>
    `
  }

  demoTip({key, tool, label, description, instruction}) {
    return `
      <aside ${tool}>
        <figure>
          <img src="${this._tutsBaseURL}/${tool}.gif" alt="${description}" />
          <figcaption>
            <h2>
              ${label}
              <span hotkey>${key}</span>
            </h2>
            <p>${description}</p>
            ${instruction}
          </figcaption>
        </figure>
      </aside>
    `
  }

  move() {
    this.deactivate_feature = Moveable(this.selectorEngine);
  }

  margin() {
    this.deactivate_feature = Margin(this.selectorEngine);
  }

  padding() {
    this.deactivate_feature = Padding(this.selectorEngine);
  }

  font() {
    this.deactivate_feature = Font(this.selectorEngine);
  }

  text() {
    this.selectorEngine.onSelectedUpdate(EditText);
    this.deactivate_feature = () =>
      this.selectorEngine.removeSelectedCallback(EditText);
  }

  align() {
    this.deactivate_feature = Flex(this.selectorEngine);
  }

  search() {
    this.deactivate_feature = Search($('[data-tool="search"]', this.$shadow));
  }

  boxshadow() {
    this.deactivate_feature = BoxShadow(this.selectorEngine);
  }

  hueshift() {
    let feature = HueShift(this.colorPicker);
    this.selectorEngine.onSelectedUpdate(feature.onNodesSelected);
    this.deactivate_feature = () => {
      this.selectorEngine.removeSelectedCallback(feature.onNodesSelected);
      feature.disconnect();
    };
  }

  inspector() {
    this.deactivate_feature = MetaTip(this.selectorEngine);
  }

  accessibility() {
    this.deactivate_feature = Accessibility();
  }

  guides() {
    this.deactivate_feature = Guides();
  }

  screenshot() {
    this.deactivate_feature = Screenshot();
  }

  position() {
    let feature = Position();
    this.selectorEngine.onSelectedUpdate(feature.onNodesSelected);
    this.deactivate_feature = () => {
      this.selectorEngine.removeSelectedCallback(feature.onNodesSelected);
      feature.disconnect();
    };
  }

  get activeTool() {
    return this.active_tool.dataset.tool
  }

  set tutsBaseURL(url) {
    this._tutsBaseURL = url;
    this.setup();
  }
}

customElements.define('vis-bug', VisBug);

if ('ontouchstart' in document.documentElement)
  document.getElementById('mobile-info').style.display = '';

if (metaKey === 'ctrl')
  [...document.querySelectorAll('kbd')]
    .forEach(node => {
      node.textContent = node.textContent.replace('cmd','ctrl');
      node.textContent = node.textContent.replace('opt','alt');
    });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVuZGxlLmpzIiwic291cmNlcyI6WyIuLi9ub2RlX21vZHVsZXMvYmxpbmdibGluZ2pzL3NyYy9pbmRleC5qcyIsIi4uL25vZGVfbW9kdWxlcy9ob3RrZXlzLWpzL2Rpc3QvaG90a2V5cy5lc20uanMiLCJjb21wb25lbnRzL3NlbGVjdGlvbi9oYW5kbGVzLmVsZW1lbnQuanMiLCJjb21wb25lbnRzL3NlbGVjdGlvbi9ob3Zlci5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9zZWxlY3Rpb24vbGFiZWwuZWxlbWVudC5qcyIsInV0aWxpdGllcy9kZXNpZ24tcHJvcGVydGllcy5qcyIsInV0aWxpdGllcy9zdHlsZXMuanMiLCJ1dGlsaXRpZXMvYWNjZXNzaWJpbGl0eS5qcyIsInV0aWxpdGllcy9zdHJpbmdzLmpzIiwidXRpbGl0aWVzL2NvbW1vbi5qcyIsInV0aWxpdGllcy93aW5kb3cuanMiLCJjb21wb25lbnRzL3NlbGVjdGlvbi9ncmlkbGluZXMuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvc2VsZWN0aW9uL2Rpc3RhbmNlLmVsZW1lbnQuanMiLCJjb21wb25lbnRzL3NlbGVjdGlvbi9vdmVybGF5LmVsZW1lbnQuanMiLCJjb21wb25lbnRzL21ldGF0aXAvbWV0YXRpcC5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9tZXRhdGlwL2FsbHkuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvdmlzLWJ1Zy92aXMtYnVnLmljb25zLmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL2Jhc2UuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9ndWlkZXMuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9pbnNwZWN0b3IuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9hY2Nlc3NpYmlsaXR5LmVsZW1lbnQuanMiLCJjb21wb25lbnRzL2hvdGtleS1tYXAvbW92ZS5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL21hcmdpbi5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL3BhZGRpbmcuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9hbGlnbi5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL2h1ZXNoaWZ0LmVsZW1lbnQuanMiLCJjb21wb25lbnRzL2hvdGtleS1tYXAvYm94c2hhZG93LmVsZW1lbnQuanMiLCJjb21wb25lbnRzL2hvdGtleS1tYXAvcG9zaXRpb24uZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9mb250LmVsZW1lbnQuanMiLCJjb21wb25lbnRzL2hvdGtleS1tYXAvdGV4dC5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL3NlYXJjaC5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL2hvdGtleXMuZWxlbWVudC5qcyIsImZlYXR1cmVzL21hcmdpbi5qcyIsImZlYXR1cmVzL21vdmUuanMiLCJmZWF0dXJlcy9pbWFnZXN3YXAuanMiLCIuLi9ub2RlX21vZHVsZXMvcXVlcnktc2VsZWN0b3Itc2hhZG93LWRvbS9zcmMvcXVlcnlTZWxlY3RvckRlZXAuanMiLCJwbHVnaW5zL2JsYW5rLXBhZ2UuanMiLCJwbHVnaW5zL2JhcnJlbC1yb2xsLmpzIiwicGx1Z2lucy9wZXN0aWNpZGUuanMiLCJwbHVnaW5zL2NvbnN0cnVjdC5qcyIsInBsdWdpbnMvY29uc3RydWN0LmRlYnVnLmpzIiwicGx1Z2lucy93aXJlZnJhbWUuanMiLCJwbHVnaW5zL3NrZWxldG9uLmpzIiwicGx1Z2lucy90YWctZGVidWdnZXIuanMiLCJwbHVnaW5zL3JldmVuZ2UuanMiLCJwbHVnaW5zL19yZWdpc3RyeS5qcyIsImZlYXR1cmVzL3NlYXJjaC5qcyIsImZlYXR1cmVzL21lYXN1cmVtZW50cy5qcyIsIi4uL25vZGVfbW9kdWxlcy9AY3RybC90aW55Y29sb3IvYnVuZGxlcy90aW55Y29sb3IuZXMyMDE1LmpzIiwiZmVhdHVyZXMvbWV0YXRpcC5qcyIsImZlYXR1cmVzL2FjY2Vzc2liaWxpdHkuanMiLCJmZWF0dXJlcy9zZWxlY3RhYmxlLmpzIiwiZmVhdHVyZXMvcGFkZGluZy5qcyIsImZlYXR1cmVzL3RleHQuanMiLCJmZWF0dXJlcy9mb250LmpzIiwiZmVhdHVyZXMvZmxleC5qcyIsImZlYXR1cmVzL2NvbG9yLmpzIiwiZmVhdHVyZXMvYm94c2hhZG93LmpzIiwiZmVhdHVyZXMvaHVlc2hpZnQuanMiLCJmZWF0dXJlcy9ndWlkZXMuanMiLCJmZWF0dXJlcy9zY3JlZW5zaG90LmpzIiwiZmVhdHVyZXMvcG9zaXRpb24uanMiLCJjb21wb25lbnRzL3Zpcy1idWcvbW9kZWwuanMiLCJjb21wb25lbnRzL3Zpcy1idWcvdmlzLWJ1Zy5lbGVtZW50LmpzIiwiaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc3VnYXIgPSB7XG4gIG9uOiBmdW5jdGlvbihuYW1lcywgZm4pIHtcbiAgICBuYW1lc1xuICAgICAgLnNwbGl0KCcgJylcbiAgICAgIC5mb3JFYWNoKG5hbWUgPT5cbiAgICAgICAgdGhpcy5hZGRFdmVudExpc3RlbmVyKG5hbWUsIGZuKSlcbiAgICByZXR1cm4gdGhpc1xuICB9LFxuICBvZmY6IGZ1bmN0aW9uKG5hbWVzLCBmbikge1xuICAgIG5hbWVzXG4gICAgICAuc3BsaXQoJyAnKVxuICAgICAgLmZvckVhY2gobmFtZSA9PlxuICAgICAgICB0aGlzLnJlbW92ZUV2ZW50TGlzdGVuZXIobmFtZSwgZm4pKVxuICAgIHJldHVybiB0aGlzXG4gIH0sXG4gIGF0dHI6IGZ1bmN0aW9uKGF0dHIsIHZhbCkge1xuICAgIGlmICh2YWwgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHRoaXMuZ2V0QXR0cmlidXRlKGF0dHIpXG5cbiAgICB2YWwgPT0gbnVsbFxuICAgICAgPyB0aGlzLnJlbW92ZUF0dHJpYnV0ZShhdHRyKVxuICAgICAgOiB0aGlzLnNldEF0dHJpYnV0ZShhdHRyLCB2YWwgfHwgJycpXG4gICAgICBcbiAgICByZXR1cm4gdGhpc1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICQocXVlcnksICRjb250ZXh0ID0gZG9jdW1lbnQpIHtcbiAgbGV0ICRub2RlcyA9IHF1ZXJ5IGluc3RhbmNlb2YgTm9kZUxpc3QgfHwgQXJyYXkuaXNBcnJheShxdWVyeSlcbiAgICA/IHF1ZXJ5XG4gICAgOiBxdWVyeSBpbnN0YW5jZW9mIEhUTUxFbGVtZW50IHx8IHF1ZXJ5IGluc3RhbmNlb2YgU1ZHRWxlbWVudFxuICAgICAgPyBbcXVlcnldXG4gICAgICA6ICRjb250ZXh0LnF1ZXJ5U2VsZWN0b3JBbGwocXVlcnkpXG5cbiAgaWYgKCEkbm9kZXMubGVuZ3RoKSAkbm9kZXMgPSBbXVxuXG4gIHJldHVybiBPYmplY3QuYXNzaWduKFxuICAgIFsuLi4kbm9kZXNdLm1hcCgkZWwgPT4gT2JqZWN0LmFzc2lnbigkZWwsIHN1Z2FyKSksIFxuICAgIHtcbiAgICAgIG9uOiBmdW5jdGlvbihuYW1lcywgZm4pIHtcbiAgICAgICAgdGhpcy5mb3JFYWNoKCRlbCA9PiAkZWwub24obmFtZXMsIGZuKSlcbiAgICAgICAgcmV0dXJuIHRoaXNcbiAgICAgIH0sXG4gICAgICBvZmY6IGZ1bmN0aW9uKG5hbWVzLCBmbikge1xuICAgICAgICB0aGlzLmZvckVhY2goJGVsID0+ICRlbC5vZmYobmFtZXMsIGZuKSlcbiAgICAgICAgcmV0dXJuIHRoaXNcbiAgICAgIH0sXG4gICAgICBhdHRyOiBmdW5jdGlvbihhdHRycywgdmFsKSB7XG4gICAgICAgIGlmICh0eXBlb2YgYXR0cnMgPT09ICdzdHJpbmcnICYmIHZhbCA9PT0gdW5kZWZpbmVkKVxuICAgICAgICAgIHJldHVybiB0aGlzWzBdLmF0dHIoYXR0cnMpXG5cbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIGF0dHJzID09PSAnb2JqZWN0JykgXG4gICAgICAgICAgdGhpcy5mb3JFYWNoKCRlbCA9PlxuICAgICAgICAgICAgT2JqZWN0LmVudHJpZXMoYXR0cnMpXG4gICAgICAgICAgICAgIC5mb3JFYWNoKChba2V5LCB2YWxdKSA9PlxuICAgICAgICAgICAgICAgICRlbC5hdHRyKGtleSwgdmFsKSkpXG5cbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIGF0dHJzID09ICdzdHJpbmcnICYmICh2YWwgfHwgdmFsID09IG51bGwgfHwgdmFsID09ICcnKSlcbiAgICAgICAgICB0aGlzLmZvckVhY2goJGVsID0+ICRlbC5hdHRyKGF0dHJzLCB2YWwpKVxuXG4gICAgICAgIHJldHVybiB0aGlzXG4gICAgICB9XG4gICAgfVxuICApXG59IiwiLyohXG4gKiBob3RrZXlzLWpzIHYzLjMuNVxuICogQSBzaW1wbGUgbWljcm8tbGlicmFyeSBmb3IgZGVmaW5pbmcgYW5kIGRpc3BhdGNoaW5nIGtleWJvYXJkIHNob3J0Y3V0cy4gSXQgaGFzIG5vIGRlcGVuZGVuY2llcy5cbiAqIFxuICogQ29weXJpZ2h0IChjKSAyMDE4IGtlbm55IHdvbmcgPHdvd29ob29AcXEuY29tPlxuICogaHR0cDovL2pheXdjamxvdmUuZ2l0aHViLmlvL2hvdGtleXNcbiAqIFxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlLlxuICovXG5cbnZhciBpc2ZmID0gdHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcgPyBuYXZpZ2F0b3IudXNlckFnZW50LnRvTG93ZXJDYXNlKCkuaW5kZXhPZignZmlyZWZveCcpID4gMCA6IGZhbHNlO1xuXG4vLyDnu5Hlrprkuovku7ZcbmZ1bmN0aW9uIGFkZEV2ZW50KG9iamVjdCwgZXZlbnQsIG1ldGhvZCkge1xuICBpZiAob2JqZWN0LmFkZEV2ZW50TGlzdGVuZXIpIHtcbiAgICBvYmplY3QuYWRkRXZlbnRMaXN0ZW5lcihldmVudCwgbWV0aG9kLCBmYWxzZSk7XG4gIH0gZWxzZSBpZiAob2JqZWN0LmF0dGFjaEV2ZW50KSB7XG4gICAgb2JqZWN0LmF0dGFjaEV2ZW50KCdvbicgKyBldmVudCwgZnVuY3Rpb24gKCkge1xuICAgICAgbWV0aG9kKHdpbmRvdy5ldmVudCk7XG4gICAgfSk7XG4gIH1cbn1cblxuLy8g5L+u6aWw6ZSu6L2s5o2i5oiQ5a+55bqU55qE6ZSu56CBXG5mdW5jdGlvbiBnZXRNb2RzKG1vZGlmaWVyLCBrZXkpIHtcbiAgdmFyIG1vZHMgPSBrZXkuc2xpY2UoMCwga2V5Lmxlbmd0aCAtIDEpO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IG1vZHMubGVuZ3RoOyBpKyspIHtcbiAgICBtb2RzW2ldID0gbW9kaWZpZXJbbW9kc1tpXS50b0xvd2VyQ2FzZSgpXTtcbiAgfXJldHVybiBtb2RzO1xufVxuXG4vLyDlpITnkIbkvKDnmoRrZXnlrZfnrKbkuLLovazmjaLmiJDmlbDnu4RcbmZ1bmN0aW9uIGdldEtleXMoa2V5KSB7XG4gIGlmICgha2V5KSBrZXkgPSAnJztcblxuICBrZXkgPSBrZXkucmVwbGFjZSgvXFxzL2csICcnKTsgLy8g5Yy56YWN5Lu75L2V56m655m95a2X56ymLOWMheaLrOepuuagvOOAgeWItuihqOespuOAgeaNoumhteespuetieetiVxuICB2YXIga2V5cyA9IGtleS5zcGxpdCgnLCcpOyAvLyDlkIzml7borr7nva7lpJrkuKrlv6vmjbfplK7vvIzku6UnLCfliIblibJcbiAgdmFyIGluZGV4ID0ga2V5cy5sYXN0SW5kZXhPZignJyk7XG5cbiAgLy8g5b+r5o236ZSu5Y+v6IO95YyF5ZCrJywn77yM6ZyA54m55q6K5aSE55CGXG4gIGZvciAoOyBpbmRleCA+PSAwOykge1xuICAgIGtleXNbaW5kZXggLSAxXSArPSAnLCc7XG4gICAga2V5cy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgIGluZGV4ID0ga2V5cy5sYXN0SW5kZXhPZignJyk7XG4gIH1cblxuICByZXR1cm4ga2V5cztcbn1cblxuLy8g5q+U6L6D5L+u6aWw6ZSu55qE5pWw57uEXG5mdW5jdGlvbiBjb21wYXJlQXJyYXkoYTEsIGEyKSB7XG4gIHZhciBhcnIxID0gYTEubGVuZ3RoID49IGEyLmxlbmd0aCA/IGExIDogYTI7XG4gIHZhciBhcnIyID0gYTEubGVuZ3RoID49IGEyLmxlbmd0aCA/IGEyIDogYTE7XG4gIHZhciBpc0luZGV4ID0gdHJ1ZTtcblxuICBmb3IgKHZhciBpID0gMDsgaSA8IGFycjEubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoYXJyMi5pbmRleE9mKGFycjFbaV0pID09PSAtMSkgaXNJbmRleCA9IGZhbHNlO1xuICB9XG4gIHJldHVybiBpc0luZGV4O1xufVxuXG52YXIgX2tleU1hcCA9IHsgLy8g54m55q6K6ZSuXG4gIGJhY2tzcGFjZTogOCxcbiAgdGFiOiA5LFxuICBjbGVhcjogMTIsXG4gIGVudGVyOiAxMyxcbiAgcmV0dXJuOiAxMyxcbiAgZXNjOiAyNyxcbiAgZXNjYXBlOiAyNyxcbiAgc3BhY2U6IDMyLFxuICBsZWZ0OiAzNyxcbiAgdXA6IDM4LFxuICByaWdodDogMzksXG4gIGRvd246IDQwLFxuICBkZWw6IDQ2LFxuICBkZWxldGU6IDQ2LFxuICBpbnM6IDQ1LFxuICBpbnNlcnQ6IDQ1LFxuICBob21lOiAzNixcbiAgZW5kOiAzNSxcbiAgcGFnZXVwOiAzMyxcbiAgcGFnZWRvd246IDM0LFxuICBjYXBzbG9jazogMjAsXG4gICfih6onOiAyMCxcbiAgJywnOiAxODgsXG4gICcuJzogMTkwLFxuICAnLyc6IDE5MSxcbiAgJ2AnOiAxOTIsXG4gICctJzogaXNmZiA/IDE3MyA6IDE4OSxcbiAgJz0nOiBpc2ZmID8gNjEgOiAxODcsXG4gICc7JzogaXNmZiA/IDU5IDogMTg2LFxuICAnXFwnJzogMjIyLFxuICAnWyc6IDIxOSxcbiAgJ10nOiAyMjEsXG4gICdcXFxcJzogMjIwXG59O1xuXG52YXIgX21vZGlmaWVyID0geyAvLyDkv67ppbDplK5cbiAgJ+KHpyc6IDE2LFxuICBzaGlmdDogMTYsXG4gICfijKUnOiAxOCxcbiAgYWx0OiAxOCxcbiAgb3B0aW9uOiAxOCxcbiAgJ+KMgyc6IDE3LFxuICBjdHJsOiAxNyxcbiAgY29udHJvbDogMTcsXG4gICfijJgnOiBpc2ZmID8gMjI0IDogOTEsXG4gIGNtZDogaXNmZiA/IDIyNCA6IDkxLFxuICBjb21tYW5kOiBpc2ZmID8gMjI0IDogOTFcbn07XG52YXIgX2Rvd25LZXlzID0gW107IC8vIOiusOW9leaRgeS4i+eahOe7keWumumUrlxudmFyIG1vZGlmaWVyTWFwID0ge1xuICAxNjogJ3NoaWZ0S2V5JyxcbiAgMTg6ICdhbHRLZXknLFxuICAxNzogJ2N0cmxLZXknXG59O1xudmFyIF9tb2RzID0geyAxNjogZmFsc2UsIDE4OiBmYWxzZSwgMTc6IGZhbHNlIH07XG52YXIgX2hhbmRsZXJzID0ge307XG5cbi8vIEYxfkYxMiDnibnmrorplK5cbmZvciAodmFyIGsgPSAxOyBrIDwgMjA7IGsrKykge1xuICBfa2V5TWFwWydmJyArIGtdID0gMTExICsgaztcbn1cblxuLy8g5YW85a65RmlyZWZveOWkhOeQhlxubW9kaWZpZXJNYXBbaXNmZiA/IDIyNCA6IDkxXSA9ICdtZXRhS2V5Jztcbl9tb2RzW2lzZmYgPyAyMjQgOiA5MV0gPSBmYWxzZTtcblxudmFyIF9zY29wZSA9ICdhbGwnOyAvLyDpu5jorqTng63plK7ojIPlm7RcbnZhciBpc0JpbmRFbGVtZW50ID0gZmFsc2U7IC8vIOaYr+WQpue7keWumuiKgueCuVxuXG4vLyDov5Tlm57plK7noIFcbnZhciBjb2RlID0gZnVuY3Rpb24gY29kZSh4KSB7XG4gIHJldHVybiBfa2V5TWFwW3gudG9Mb3dlckNhc2UoKV0gfHwgeC50b1VwcGVyQ2FzZSgpLmNoYXJDb2RlQXQoMCk7XG59O1xuXG4vLyDorr7nva7ojrflj5blvZPliY3ojIPlm7TvvIjpu5jorqTkuLon5omA5pyJJ++8iVxuZnVuY3Rpb24gc2V0U2NvcGUoc2NvcGUpIHtcbiAgX3Njb3BlID0gc2NvcGUgfHwgJ2FsbCc7XG59XG4vLyDojrflj5blvZPliY3ojIPlm7RcbmZ1bmN0aW9uIGdldFNjb3BlKCkge1xuICByZXR1cm4gX3Njb3BlIHx8ICdhbGwnO1xufVxuLy8g6I635Y+W5pGB5LiL57uR5a6a6ZSu55qE6ZSu5YC8XG5mdW5jdGlvbiBnZXRQcmVzc2VkS2V5Q29kZXMoKSB7XG4gIHJldHVybiBfZG93bktleXMuc2xpY2UoMCk7XG59XG5cbi8vIOihqOWNleaOp+S7tuaOp+S7tuWIpOaWrSDov5Tlm54gQm9vbGVhblxuZnVuY3Rpb24gZmlsdGVyKGV2ZW50KSB7XG4gIHZhciB0YWdOYW1lID0gZXZlbnQudGFyZ2V0LnRhZ05hbWUgfHwgZXZlbnQuc3JjRWxlbWVudC50YWdOYW1lO1xuICAvLyDlv73nlaXov5nkupvmoIfnrb7mg4XlhrXkuIvlv6vmjbfplK7ml6DmlYhcbiAgcmV0dXJuICEodGFnTmFtZSA9PT0gJ0lOUFVUJyB8fCB0YWdOYW1lID09PSAnU0VMRUNUJyB8fCB0YWdOYW1lID09PSAnVEVYVEFSRUEnKTtcbn1cblxuLy8g5Yik5pat5pGB5LiL55qE6ZSu5piv5ZCm5Li65p+Q5Liq6ZSu77yM6L+U5ZuedHJ1ZeaIluiAhWZhbHNlXG5mdW5jdGlvbiBpc1ByZXNzZWQoa2V5Q29kZSkge1xuICBpZiAodHlwZW9mIGtleUNvZGUgPT09ICdzdHJpbmcnKSB7XG4gICAga2V5Q29kZSA9IGNvZGUoa2V5Q29kZSk7IC8vIOi9rOaNouaIkOmUrueggVxuICB9XG4gIHJldHVybiBfZG93bktleXMuaW5kZXhPZihrZXlDb2RlKSAhPT0gLTE7XG59XG5cbi8vIOW+queOr+WIoOmZpGhhbmRsZXJz5Lit55qE5omA5pyJIHNjb3BlKOiMg+WbtClcbmZ1bmN0aW9uIGRlbGV0ZVNjb3BlKHNjb3BlLCBuZXdTY29wZSkge1xuICB2YXIgaGFuZGxlcnMgPSB2b2lkIDA7XG4gIHZhciBpID0gdm9pZCAwO1xuXG4gIC8vIOayoeacieaMh+WumnNjb3Bl77yM6I635Y+Wc2NvcGVcbiAgaWYgKCFzY29wZSkgc2NvcGUgPSBnZXRTY29wZSgpO1xuXG4gIGZvciAodmFyIGtleSBpbiBfaGFuZGxlcnMpIHtcbiAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKF9oYW5kbGVycywga2V5KSkge1xuICAgICAgaGFuZGxlcnMgPSBfaGFuZGxlcnNba2V5XTtcbiAgICAgIGZvciAoaSA9IDA7IGkgPCBoYW5kbGVycy5sZW5ndGg7KSB7XG4gICAgICAgIGlmIChoYW5kbGVyc1tpXS5zY29wZSA9PT0gc2NvcGUpIGhhbmRsZXJzLnNwbGljZShpLCAxKTtlbHNlIGkrKztcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyDlpoLmnpxzY29wZeiiq+WIoOmZpO+8jOWwhnNjb3Bl6YeN572u5Li6YWxsXG4gIGlmIChnZXRTY29wZSgpID09PSBzY29wZSkgc2V0U2NvcGUobmV3U2NvcGUgfHwgJ2FsbCcpO1xufVxuXG4vLyDmuIXpmaTkv67ppbDplK5cbmZ1bmN0aW9uIGNsZWFyTW9kaWZpZXIoZXZlbnQpIHtcbiAgdmFyIGtleSA9IGV2ZW50LmtleUNvZGUgfHwgZXZlbnQud2hpY2ggfHwgZXZlbnQuY2hhckNvZGU7XG4gIHZhciBpID0gX2Rvd25LZXlzLmluZGV4T2Yoa2V5KTtcblxuICAvLyDku47liJfooajkuK3muIXpmaTmjInljovov4fnmoTplK5cbiAgaWYgKGkgPj0gMCkgX2Rvd25LZXlzLnNwbGljZShpLCAxKTtcblxuICAvLyDkv67ppbDplK4gc2hpZnRLZXkgYWx0S2V5IGN0cmxLZXkgKGNvbW1hbmR8fG1ldGFLZXkpIOa4hemZpFxuICBpZiAoa2V5ID09PSA5MyB8fCBrZXkgPT09IDIyNCkga2V5ID0gOTE7XG4gIGlmIChrZXkgaW4gX21vZHMpIHtcbiAgICBfbW9kc1trZXldID0gZmFsc2U7XG5cbiAgICAvLyDlsIbkv67ppbDplK7ph43nva7kuLpmYWxzZVxuICAgIGZvciAodmFyIGsgaW4gX21vZGlmaWVyKSB7XG4gICAgICBpZiAoX21vZGlmaWVyW2tdID09PSBrZXkpIGhvdGtleXNba10gPSBmYWxzZTtcbiAgICB9XG4gIH1cbn1cblxuLy8g6Kej6Zmk57uR5a6a5p+Q5Liq6IyD5Zu055qE5b+r5o236ZSuXG5mdW5jdGlvbiB1bmJpbmQoa2V5LCBzY29wZSkge1xuICB2YXIgbXVsdGlwbGVLZXlzID0gZ2V0S2V5cyhrZXkpO1xuICB2YXIga2V5cyA9IHZvaWQgMDtcbiAgdmFyIG1vZHMgPSBbXTtcbiAgdmFyIG9iaiA9IHZvaWQgMDtcblxuICBmb3IgKHZhciBpID0gMDsgaSA8IG11bHRpcGxlS2V5cy5sZW5ndGg7IGkrKykge1xuICAgIC8vIOWwhue7hOWQiOW/q+aNt+mUruaLhuWIhuS4uuaVsOe7hFxuICAgIGtleXMgPSBtdWx0aXBsZUtleXNbaV0uc3BsaXQoJysnKTtcblxuICAgIC8vIOiusOW9leavj+S4que7hOWQiOmUruS4reeahOS/rumlsOmUrueahOmUrueggSDov5Tlm57mlbDnu4RcbiAgICBpZiAoa2V5cy5sZW5ndGggPiAxKSBtb2RzID0gZ2V0TW9kcyhfbW9kaWZpZXIsIGtleXMpO1xuXG4gICAgLy8g6I635Y+W6Zmk5L+u6aWw6ZSu5aSW55qE6ZSu5YC8a2V5XG4gICAga2V5ID0ga2V5c1trZXlzLmxlbmd0aCAtIDFdO1xuICAgIGtleSA9IGtleSA9PT0gJyonID8gJyonIDogY29kZShrZXkpO1xuXG4gICAgLy8g5Yik5pat5piv5ZCm5Lyg5YWl6IyD5Zu077yM5rKh5pyJ5bCx6I635Y+W6IyD5Zu0XG4gICAgaWYgKCFzY29wZSkgc2NvcGUgPSBnZXRTY29wZSgpO1xuXG4gICAgLy8g5aaC5L2Va2V55LiN5ZyoIF9oYW5kbGVycyDkuK3ov5Tlm57kuI3lgZrlpITnkIZcbiAgICBpZiAoIV9oYW5kbGVyc1trZXldKSByZXR1cm47XG5cbiAgICAvLyDmuIXnqbogaGFuZGxlcnMg5Lit5pWw5o2u77yMXG4gICAgLy8g6K6p6Kem5Y+R5b+r5o236ZSu6ZSu5LmL5ZCO5rKh5pyJ5LqL5Lu25omn6KGM5Yiw6L6+6Kej6Zmk5b+r5o236ZSu57uR5a6a55qE55uu55qEXG4gICAgZm9yICh2YXIgciA9IDA7IHIgPCBfaGFuZGxlcnNba2V5XS5sZW5ndGg7IHIrKykge1xuICAgICAgb2JqID0gX2hhbmRsZXJzW2tleV1bcl07XG4gICAgICAvLyDliKTmlq3mmK/lkKblnKjojIPlm7TlhoXlubbkuJTplK7lgLznm7jlkIxcbiAgICAgIGlmIChvYmouc2NvcGUgPT09IHNjb3BlICYmIGNvbXBhcmVBcnJheShvYmoubW9kcywgbW9kcykpIHtcbiAgICAgICAgX2hhbmRsZXJzW2tleV1bcl0gPSB7fTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuLy8g5a+555uR5ZCs5a+55bqU5b+r5o236ZSu55qE5Zue6LCD5Ye95pWw6L+b6KGM5aSE55CGXG5mdW5jdGlvbiBldmVudEhhbmRsZXIoZXZlbnQsIGhhbmRsZXIsIHNjb3BlKSB7XG4gIHZhciBtb2RpZmllcnNNYXRjaCA9IHZvaWQgMDtcblxuICAvLyDnnIvlroPmmK/lkKblnKjlvZPliY3ojIPlm7RcbiAgaWYgKGhhbmRsZXIuc2NvcGUgPT09IHNjb3BlIHx8IGhhbmRsZXIuc2NvcGUgPT09ICdhbGwnKSB7XG4gICAgLy8g5qOA5p+l5piv5ZCm5Yy56YWN5L+u6aWw56ym77yI5aaC5p6c5pyJ6L+U5ZuedHJ1Ze+8iVxuICAgIG1vZGlmaWVyc01hdGNoID0gaGFuZGxlci5tb2RzLmxlbmd0aCA+IDA7XG5cbiAgICBmb3IgKHZhciB5IGluIF9tb2RzKSB7XG4gICAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKF9tb2RzLCB5KSkge1xuICAgICAgICBpZiAoIV9tb2RzW3ldICYmIGhhbmRsZXIubW9kcy5pbmRleE9mKCt5KSA+IC0xIHx8IF9tb2RzW3ldICYmIGhhbmRsZXIubW9kcy5pbmRleE9mKCt5KSA9PT0gLTEpIG1vZGlmaWVyc01hdGNoID0gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8g6LCD55So5aSE55CG56iL5bqP77yM5aaC5p6c5piv5L+u6aWw6ZSu5LiN5YGa5aSE55CGXG4gICAgaWYgKGhhbmRsZXIubW9kcy5sZW5ndGggPT09IDAgJiYgIV9tb2RzWzE2XSAmJiAhX21vZHNbMThdICYmICFfbW9kc1sxN10gJiYgIV9tb2RzWzkxXSB8fCBtb2RpZmllcnNNYXRjaCB8fCBoYW5kbGVyLnNob3J0Y3V0ID09PSAnKicpIHtcbiAgICAgIGlmIChoYW5kbGVyLm1ldGhvZChldmVudCwgaGFuZGxlcikgPT09IGZhbHNlKSB7XG4gICAgICAgIGlmIChldmVudC5wcmV2ZW50RGVmYXVsdCkgZXZlbnQucHJldmVudERlZmF1bHQoKTtlbHNlIGV2ZW50LnJldHVyblZhbHVlID0gZmFsc2U7XG4gICAgICAgIGlmIChldmVudC5zdG9wUHJvcGFnYXRpb24pIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICBpZiAoZXZlbnQuY2FuY2VsQnViYmxlKSBldmVudC5jYW5jZWxCdWJibGUgPSB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4vLyDlpITnkIZrZXlkb3du5LqL5Lu2XG5mdW5jdGlvbiBkaXNwYXRjaChldmVudCkge1xuICB2YXIgYXN0ZXJpc2sgPSBfaGFuZGxlcnNbJyonXTtcbiAgdmFyIGtleSA9IGV2ZW50LmtleUNvZGUgfHwgZXZlbnQud2hpY2ggfHwgZXZlbnQuY2hhckNvZGU7XG5cbiAgLy8g5pCc6ZuG57uR5a6a55qE6ZSuXG4gIGlmIChfZG93bktleXMuaW5kZXhPZihrZXkpID09PSAtMSkgX2Rvd25LZXlzLnB1c2goa2V5KTtcblxuICAvLyBHZWNrbyhGaXJlZm94KeeahGNvbW1hbmTplK7lgLwyMjTvvIzlnKhXZWJraXQoQ2hyb21lKeS4reS/neaMgeS4gOiHtFxuICAvLyBXZWJraXTlt6blj7Njb21tYW5k6ZSu5YC85LiN5LiA5qC3XG4gIGlmIChrZXkgPT09IDkzIHx8IGtleSA9PT0gMjI0KSBrZXkgPSA5MTtcblxuICBpZiAoa2V5IGluIF9tb2RzKSB7XG4gICAgX21vZHNba2V5XSA9IHRydWU7XG5cbiAgICAvLyDlsIbnibnmrorlrZfnrKbnmoRrZXnms6jlhozliLAgaG90a2V5cyDkuIpcbiAgICBmb3IgKHZhciBrIGluIF9tb2RpZmllcikge1xuICAgICAgaWYgKF9tb2RpZmllcltrXSA9PT0ga2V5KSBob3RrZXlzW2tdID0gdHJ1ZTtcbiAgICB9XG5cbiAgICBpZiAoIWFzdGVyaXNrKSByZXR1cm47XG4gIH1cblxuICAvLyDlsIZtb2RpZmllck1hcOmHjOmdoueahOS/rumlsOmUrue7keWumuWIsGV2ZW505LitXG4gIGZvciAodmFyIGUgaW4gX21vZHMpIHtcbiAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKF9tb2RzLCBlKSkge1xuICAgICAgX21vZHNbZV0gPSBldmVudFttb2RpZmllck1hcFtlXV07XG4gICAgfVxuICB9XG5cbiAgLy8g6KGo5Y2V5o6n5Lu26L+H5rukIOm7mOiupOihqOWNleaOp+S7tuS4jeinpuWPkeW/q+aNt+mUrlxuICBpZiAoIWhvdGtleXMuZmlsdGVyLmNhbGwodGhpcywgZXZlbnQpKSByZXR1cm47XG5cbiAgLy8g6I635Y+W6IyD5Zu0IOm7mOiupOS4umFsbFxuICB2YXIgc2NvcGUgPSBnZXRTY29wZSgpO1xuXG4gIC8vIOWvueS7u+S9leW/q+aNt+mUrumDvemcgOimgeWBmueahOWkhOeQhlxuICBpZiAoYXN0ZXJpc2spIHtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFzdGVyaXNrLmxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAoYXN0ZXJpc2tbaV0uc2NvcGUgPT09IHNjb3BlKSBldmVudEhhbmRsZXIoZXZlbnQsIGFzdGVyaXNrW2ldLCBzY29wZSk7XG4gICAgfVxuICB9XG4gIC8vIGtleSDkuI3lnKhfaGFuZGxlcnPkuK3ov5Tlm55cbiAgaWYgKCEoa2V5IGluIF9oYW5kbGVycykpIHJldHVybjtcblxuICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgX2hhbmRsZXJzW2tleV0ubGVuZ3RoOyBfaSsrKSB7XG4gICAgLy8g5om+5Yiw5aSE55CG5YaF5a65XG4gICAgZXZlbnRIYW5kbGVyKGV2ZW50LCBfaGFuZGxlcnNba2V5XVtfaV0sIHNjb3BlKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBob3RrZXlzKGtleSwgb3B0aW9uLCBtZXRob2QpIHtcbiAgdmFyIGtleXMgPSBnZXRLZXlzKGtleSk7IC8vIOmcgOimgeWkhOeQhueahOW/q+aNt+mUruWIl+ihqFxuICB2YXIgbW9kcyA9IFtdO1xuICB2YXIgc2NvcGUgPSAnYWxsJzsgLy8gc2NvcGXpu5jorqTkuLphbGzvvIzmiYDmnInojIPlm7Tpg73mnInmlYhcbiAgdmFyIGVsZW1lbnQgPSBkb2N1bWVudDsgLy8g5b+r5o236ZSu5LqL5Lu257uR5a6a6IqC54K5XG4gIHZhciBpID0gMDtcblxuICAvLyDlr7nkuLrorr7lrprojIPlm7TnmoTliKTmlq1cbiAgaWYgKG1ldGhvZCA9PT0gdW5kZWZpbmVkICYmIHR5cGVvZiBvcHRpb24gPT09ICdmdW5jdGlvbicpIHtcbiAgICBtZXRob2QgPSBvcHRpb247XG4gIH1cblxuICBpZiAoT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG9wdGlvbikgPT09ICdbb2JqZWN0IE9iamVjdF0nKSB7XG4gICAgaWYgKG9wdGlvbi5zY29wZSkgc2NvcGUgPSBvcHRpb24uc2NvcGU7IC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbiAgICBpZiAob3B0aW9uLmVsZW1lbnQpIGVsZW1lbnQgPSBvcHRpb24uZWxlbWVudDsgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuICB9XG5cbiAgaWYgKHR5cGVvZiBvcHRpb24gPT09ICdzdHJpbmcnKSBzY29wZSA9IG9wdGlvbjtcblxuICAvLyDlr7nkuo7mr4/kuKrlv6vmjbfplK7ov5vooYzlpITnkIZcbiAgZm9yICg7IGkgPCBrZXlzLmxlbmd0aDsgaSsrKSB7XG4gICAga2V5ID0ga2V5c1tpXS5zcGxpdCgnKycpOyAvLyDmjInplK7liJfooahcbiAgICBtb2RzID0gW107XG5cbiAgICAvLyDlpoLmnpzmmK/nu4TlkIjlv6vmjbfplK7lj5blvpfnu4TlkIjlv6vmjbfplK5cbiAgICBpZiAoa2V5Lmxlbmd0aCA+IDEpIG1vZHMgPSBnZXRNb2RzKF9tb2RpZmllciwga2V5KTtcblxuICAgIC8vIOWwhumdnuS/rumlsOmUrui9rOWMluS4uumUrueggVxuICAgIGtleSA9IGtleVtrZXkubGVuZ3RoIC0gMV07XG4gICAga2V5ID0ga2V5ID09PSAnKicgPyAnKicgOiBjb2RlKGtleSk7IC8vICrooajnpLrljLnphY3miYDmnInlv6vmjbfplK5cblxuICAgIC8vIOWIpOaWrWtleeaYr+WQpuWcqF9oYW5kbGVyc+S4re+8jOS4jeWcqOWwsei1i+S4gOS4quepuuaVsOe7hFxuICAgIGlmICghKGtleSBpbiBfaGFuZGxlcnMpKSBfaGFuZGxlcnNba2V5XSA9IFtdO1xuXG4gICAgX2hhbmRsZXJzW2tleV0ucHVzaCh7XG4gICAgICBzY29wZTogc2NvcGUsXG4gICAgICBtb2RzOiBtb2RzLFxuICAgICAgc2hvcnRjdXQ6IGtleXNbaV0sXG4gICAgICBtZXRob2Q6IG1ldGhvZCxcbiAgICAgIGtleToga2V5c1tpXVxuICAgIH0pO1xuICB9XG4gIC8vIOWcqOWFqOWxgGRvY3VtZW505LiK6K6+572u5b+r5o236ZSuXG4gIGlmICh0eXBlb2YgZWxlbWVudCAhPT0gJ3VuZGVmaW5lZCcgJiYgIWlzQmluZEVsZW1lbnQpIHtcbiAgICBpc0JpbmRFbGVtZW50ID0gdHJ1ZTtcbiAgICBhZGRFdmVudChlbGVtZW50LCAna2V5ZG93bicsIGZ1bmN0aW9uIChlKSB7XG4gICAgICBkaXNwYXRjaChlKTtcbiAgICB9KTtcbiAgICBhZGRFdmVudChlbGVtZW50LCAna2V5dXAnLCBmdW5jdGlvbiAoZSkge1xuICAgICAgY2xlYXJNb2RpZmllcihlKTtcbiAgICB9KTtcbiAgfVxufVxuXG52YXIgX2FwaSA9IHtcbiAgc2V0U2NvcGU6IHNldFNjb3BlLFxuICBnZXRTY29wZTogZ2V0U2NvcGUsXG4gIGRlbGV0ZVNjb3BlOiBkZWxldGVTY29wZSxcbiAgZ2V0UHJlc3NlZEtleUNvZGVzOiBnZXRQcmVzc2VkS2V5Q29kZXMsXG4gIGlzUHJlc3NlZDogaXNQcmVzc2VkLFxuICBmaWx0ZXI6IGZpbHRlcixcbiAgdW5iaW5kOiB1bmJpbmRcbn07XG5mb3IgKHZhciBhIGluIF9hcGkpIHtcbiAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChfYXBpLCBhKSkge1xuICAgIGhvdGtleXNbYV0gPSBfYXBpW2FdO1xuICB9XG59XG5cbmlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICB2YXIgX2hvdGtleXMgPSB3aW5kb3cuaG90a2V5cztcbiAgaG90a2V5cy5ub0NvbmZsaWN0ID0gZnVuY3Rpb24gKGRlZXApIHtcbiAgICBpZiAoZGVlcCAmJiB3aW5kb3cuaG90a2V5cyA9PT0gaG90a2V5cykge1xuICAgICAgd2luZG93LmhvdGtleXMgPSBfaG90a2V5cztcbiAgICB9XG4gICAgcmV0dXJuIGhvdGtleXM7XG4gIH07XG4gIHdpbmRvdy5ob3RrZXlzID0gaG90a2V5cztcbn1cblxuZXhwb3J0IGRlZmF1bHQgaG90a2V5cztcbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcblxuZXhwb3J0IGNsYXNzIEhhbmRsZXMgZXh0ZW5kcyBIVE1MRWxlbWVudCB7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuICAgIHRoaXMuJHNoYWRvdyA9IHRoaXMuYXR0YWNoU2hhZG93KHttb2RlOiAnY2xvc2VkJ30pXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdGhpcy5vbl9yZXNpemUuYmluZCh0aGlzKSlcbiAgfVxuICBkaXNjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdGhpcy5vbl9yZXNpemUpXG4gIH1cblxuICBvbl9yZXNpemUoKSB7XG4gICAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICBjb25zdCBub2RlX2xhYmVsX2lkID0gdGhpcy4kc2hhZG93Lmhvc3QuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJylcbiAgICAgIGNvbnN0IFtzb3VyY2VfZWxdID0gJChgW2RhdGEtbGFiZWwtaWQ9XCIke25vZGVfbGFiZWxfaWR9XCJdYClcblxuICAgICAgaWYgKCFzb3VyY2VfZWwpIHJldHVyblxuXG4gICAgICB0aGlzLnBvc2l0aW9uID0ge1xuICAgICAgICBub2RlX2xhYmVsX2lkLFxuICAgICAgICBib3VuZGluZ1JlY3Q6IHNvdXJjZV9lbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSxcbiAgICAgIH1cbiAgICB9KVxuICB9XG5cbiAgc2V0IHBvc2l0aW9uKHtib3VuZGluZ1JlY3QsIG5vZGVfbGFiZWxfaWR9KSB7XG4gICAgdGhpcy4kc2hhZG93LmlubmVySFRNTCAgPSB0aGlzLnJlbmRlcihib3VuZGluZ1JlY3QsIG5vZGVfbGFiZWxfaWQpXG4gIH1cblxuICByZW5kZXIoeyB4LCB5LCB3aWR0aCwgaGVpZ2h0LCB0b3AsIGxlZnQgfSwgbm9kZV9sYWJlbF9pZCkge1xuICAgIHRoaXMuJHNoYWRvdy5ob3N0LnNldEF0dHJpYnV0ZSgnZGF0YS1sYWJlbC1pZCcsIG5vZGVfbGFiZWxfaWQpXG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoe3RvcCxsZWZ0fSl9XG4gICAgICA8c3ZnXG4gICAgICAgIGNsYXNzPVwidmlzYnVnLWhhbmRsZXNcIlxuICAgICAgICB3aWR0aD1cIiR7d2lkdGh9XCIgaGVpZ2h0PVwiJHtoZWlnaHR9XCJcbiAgICAgICAgdmlld0JveD1cIjAgMCAke3dpZHRofSAke2hlaWdodH1cIlxuICAgICAgICB2ZXJzaW9uPVwiMS4xXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgICA+XG4gICAgICAgIDxyZWN0IHN0cm9rZT1cImhvdHBpbmtcIiBmaWxsPVwibm9uZVwiIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIj48L3JlY3Q+XG4gICAgICAgIDxjaXJjbGUgc3Ryb2tlPVwiaG90cGlua1wiIGZpbGw9XCJ3aGl0ZVwiIGN4PVwiMFwiIGN5PVwiMFwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICAgIDxjaXJjbGUgc3Ryb2tlPVwiaG90cGlua1wiIGZpbGw9XCJ3aGl0ZVwiIGN4PVwiMTAwJVwiIGN5PVwiMFwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICAgIDxjaXJjbGUgc3Ryb2tlPVwiaG90cGlua1wiIGZpbGw9XCJ3aGl0ZVwiIGN4PVwiMTAwJVwiIGN5PVwiMTAwJVwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICAgIDxjaXJjbGUgc3Ryb2tlPVwiaG90cGlua1wiIGZpbGw9XCJ3aGl0ZVwiIGN4PVwiMFwiIGN5PVwiMTAwJVwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICAgIDxjaXJjbGUgZmlsbD1cImhvdHBpbmtcIiBjeD1cIiR7d2lkdGgvMn1cIiBjeT1cIjBcIiByPVwiMlwiPjwvY2lyY2xlPlxuICAgICAgICA8Y2lyY2xlIGZpbGw9XCJob3RwaW5rXCIgY3g9XCIwXCIgY3k9XCIke2hlaWdodC8yfVwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICAgIDxjaXJjbGUgZmlsbD1cImhvdHBpbmtcIiBjeD1cIiR7d2lkdGgvMn1cIiBjeT1cIiR7aGVpZ2h0fVwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICAgIDxjaXJjbGUgZmlsbD1cImhvdHBpbmtcIiBjeD1cIiR7d2lkdGh9XCIgY3k9XCIke2hlaWdodC8yfVwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICA8L3N2Zz5cbiAgICBgXG4gIH1cblxuICBzdHlsZXMoe3RvcCxsZWZ0fSkge1xuICAgIHJldHVybiBgXG4gICAgICA8c3R5bGU+XG4gICAgICAgIDpob3N0ID4gc3ZnIHtcbiAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgdG9wOiAke3RvcCArIHdpbmRvdy5zY3JvbGxZfXB4O1xuICAgICAgICAgIGxlZnQ6ICR7bGVmdH1weDtcbiAgICAgICAgICBvdmVyZmxvdzogdmlzaWJsZTtcbiAgICAgICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICAgICAgICB6LWluZGV4OiAyMTQ3NDgzNjQ0O1xuICAgICAgICB9XG4gICAgICA8L3N0eWxlPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ3Zpc2J1Zy1oYW5kbGVzJywgSGFuZGxlcylcbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCB7IEhhbmRsZXMgfSBmcm9tICcuL2hhbmRsZXMuZWxlbWVudCdcblxuZXhwb3J0IGNsYXNzIEhvdmVyIGV4dGVuZHMgSGFuZGxlcyB7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuICB9XG5cbiAgcmVuZGVyKHsgeCwgeSwgd2lkdGgsIGhlaWdodCwgdG9wLCBsZWZ0IH0pIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcyh7dG9wLGxlZnR9KX1cbiAgICAgIDxzdHlsZT5cbiAgICAgICAgOmhvc3QgcmVjdCB7XG4gICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICAgIHZlY3Rvci1lZmZlY3Q6IG5vbi1zY2FsaW5nLXN0cm9rZTtcbiAgICAgICAgICBzdHJva2U6IGhzbCgyNjcsIDEwMCUsIDU4JSk7XG4gICAgICAgICAgc3Ryb2tlLXdpZHRoOiAxcHg7XG4gICAgICAgICAgZmlsbDogbm9uZTtcbiAgICAgICAgfVxuXG4gICAgICAgIDpob3N0ID4gc3ZnIHtcbiAgICAgICAgICB6LWluZGV4OiAyMTQ3NDgzNjQyO1xuICAgICAgICB9XG4gICAgICA8L3N0eWxlPlxuICAgICAgPHN2ZyB3aWR0aD1cIiR7d2lkdGh9XCIgaGVpZ2h0PVwiJHtoZWlnaHR9XCI+XG4gICAgICAgIDxyZWN0PjwvcmVjdD5cbiAgICAgIDwvc3ZnPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ3Zpc2J1Zy1ob3ZlcicsIEhvdmVyKVxuIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuXG5leHBvcnQgY2xhc3MgTGFiZWwgZXh0ZW5kcyBIVE1MRWxlbWVudCB7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuICAgIHRoaXMuJHNoYWRvdyA9IHRoaXMuYXR0YWNoU2hhZG93KHttb2RlOiAnY2xvc2VkJ30pXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICAkKCdhJywgdGhpcy4kc2hhZG93KS5vbignY2xpY2sgbW91c2VlbnRlcicsIHRoaXMuZGlzcGF0Y2hRdWVyeS5iaW5kKHRoaXMpKVxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCB0aGlzLm9uX3Jlc2l6ZS5iaW5kKHRoaXMpKVxuICB9XG5cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7XG4gICAgJCgnYScsIHRoaXMuJHNoYWRvdykub2ZmKCdjbGljaycsIHRoaXMuZGlzcGF0Y2hRdWVyeSlcbiAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdGhpcy5vbl9yZXNpemUpXG4gIH1cblxuICBvbl9yZXNpemUoKSB7XG4gICAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICBjb25zdCBub2RlX2xhYmVsX2lkID0gdGhpcy4kc2hhZG93Lmhvc3QuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJylcbiAgICAgIGNvbnN0IFtzb3VyY2VfZWxdICAgPSAkKGBbZGF0YS1sYWJlbC1pZD1cIiR7bm9kZV9sYWJlbF9pZH1cIl1gKVxuXG4gICAgICBpZiAoIXNvdXJjZV9lbCkgcmV0dXJuXG5cbiAgICAgIHRoaXMucG9zaXRpb24gPSB7XG4gICAgICAgIG5vZGVfbGFiZWxfaWQsXG4gICAgICAgIGJvdW5kaW5nUmVjdDogc291cmNlX2VsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICBkaXNwYXRjaFF1ZXJ5KGUpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5kaXNwYXRjaEV2ZW50KG5ldyBDdXN0b21FdmVudCgncXVlcnknLCB7XG4gICAgICBidWJibGVzOiB0cnVlLFxuICAgICAgZGV0YWlsOiAgIHtcbiAgICAgICAgdGV4dDogICAgICAgZS50YXJnZXQudGV4dENvbnRlbnQsXG4gICAgICAgIGFjdGl2YXRvcjogIGUudHlwZSxcbiAgICAgIH1cbiAgICB9KSlcbiAgfVxuXG4gIHNldCB0ZXh0KGNvbnRlbnQpIHtcbiAgICB0aGlzLl90ZXh0ID0gY29udGVudFxuICB9XG5cbiAgc2V0IHBvc2l0aW9uKHtib3VuZGluZ1JlY3QsIG5vZGVfbGFiZWxfaWR9KSB7XG4gICAgdGhpcy4kc2hhZG93LmlubmVySFRNTCAgPSB0aGlzLnJlbmRlcihib3VuZGluZ1JlY3QsIG5vZGVfbGFiZWxfaWQpXG4gIH1cblxuICBzZXQgdXBkYXRlKHt4LHl9KSB7XG4gICAgY29uc3QgbGFiZWwgPSB0aGlzLiRzaGFkb3cuY2hpbGRyZW5bMV1cbiAgICBsYWJlbC5zdHlsZS50b3AgID0geSArIHdpbmRvdy5zY3JvbGxZICsgJ3B4J1xuICAgIGxhYmVsLnN0eWxlLmxlZnQgPSB4IC0gMSArICdweCdcbiAgfVxuXG4gIHJlbmRlcih7IHgsIHksIHdpZHRoLCBoZWlnaHQsIHRvcCwgbGVmdCB9LCBub2RlX2xhYmVsX2lkKSB7XG4gICAgdGhpcy4kc2hhZG93Lmhvc3Quc2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJywgbm9kZV9sYWJlbF9pZClcblxuICAgIHJldHVybiBgXG4gICAgICAke3RoaXMuc3R5bGVzKHt0b3AsbGVmdCx3aWR0aH0pfVxuICAgICAgPHNwYW4+XG4gICAgICAgICR7dGhpcy5fdGV4dH1cbiAgICAgIDwvc3Bhbj5cbiAgICBgXG4gIH1cblxuICBzdHlsZXMoe3RvcCxsZWZ0LHdpZHRofSkge1xuICAgIHJldHVybiBgXG4gICAgICA8c3R5bGU+XG4gICAgICAgIDpob3N0IHtcbiAgICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgIH1cblxuICAgICAgICA6aG9zdCA+IHNwYW4ge1xuICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICB0b3A6ICR7dG9wICsgd2luZG93LnNjcm9sbFl9cHg7XG4gICAgICAgICAgbGVmdDogJHtsZWZ0IC0gMX1weDtcbiAgICAgICAgICBtYXgtd2lkdGg6ICR7d2lkdGggKyAod2luZG93LmlubmVyV2lkdGggLSBsZWZ0IC0gd2lkdGggLSAyMCl9cHg7XG4gICAgICAgICAgei1pbmRleDogMjE0NzQ4MzY0MztcbiAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTEwMCUpO1xuICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWxhYmVsLWJnLCBob3RwaW5rKTtcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiAwLjJlbSAwLjJlbSAwIDA7XG4gICAgICAgICAgdGV4dC1zaGFkb3c6IDAgMC41cHggMCBoc2xhKDAsIDAlLCAwJSwgMC40KTtcbiAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgICAgZm9udC1zaXplOiAwLjhlbTtcbiAgICAgICAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgICAgICAgIGZvbnQtZmFtaWx5OiBzeXN0ZW0tdWksIC1hcHBsZS1zeXN0ZW0sIFNlZ29lIFVJLCBSb2JvdG8sIFVidW50dSwgQ2FudGFyZWxsLCBOb3RvIFNhbnMsIHNhbnMtc2VyaWY7XG4gICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICAgICAgICBwYWRkaW5nOiAwLjI1ZW0gMC40ZW0gMC4xNWVtO1xuICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxLjE7XG4gICAgICAgIH1cblxuICAgICAgICA6aG9zdCBhIHtcbiAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gICAgICAgICAgY29sb3I6IGluaGVyaXQ7XG4gICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgIH1cblxuICAgICAgICA6aG9zdCBhOmhvdmVyIHtcbiAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgIH1cblxuICAgICAgICA6aG9zdCBhW25vZGVdOmJlZm9yZSB7XG4gICAgICAgICAgY29udGVudDogXCJcXFxcMDAzY1wiO1xuICAgICAgICB9XG5cbiAgICAgICAgOmhvc3QgYVtub2RlXTphZnRlciB7XG4gICAgICAgICAgY29udGVudDogXCJcXFxcMDAzZVwiO1xuICAgICAgICB9XG4gICAgICA8L3N0eWxlPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ3Zpc2J1Zy1sYWJlbCcsIExhYmVsKVxuIiwiZXhwb3J0IGNvbnN0IGRlc2lyZWRQcm9wTWFwID0ge1xuICBjb2xvcjogICAgICAgICAgICAgICAncmdiKDAsIDAsIDApJyxcbiAgYmFja2dyb3VuZENvbG9yOiAgICAgJ3JnYmEoMCwgMCwgMCwgMCknLFxuICBiYWNrZ3JvdW5kSW1hZ2U6ICAgICAnbm9uZScsXG4gIGJhY2tncm91bmRTaXplOiAgICAgICdhdXRvJyxcbiAgYmFja2dyb3VuZFBvc2l0aW9uOiAgJzAlIDAlJyxcbiAgLy8gYm9yZGVyQ29sb3I6ICAgICAgJ3JnYigwLCAwLCAwKScsXG4gIGJvcmRlcldpZHRoOiAgICAgICAgICcwcHgnLFxuICBib3JkZXJSYWRpdXM6ICAgICAgICAnMHB4JyxcbiAgYm94U2hhZG93OiAgICAgICAgICAgJ25vbmUnLFxuICBwYWRkaW5nOiAgICAgICAgICAgICAnMHB4JyxcbiAgbWFyZ2luOiAgICAgICAgICAgICAgJzBweCcsXG4gIGZvbnRGYW1pbHk6ICAgICAgICAgICcnLFxuICBmb250U2l6ZTogICAgICAgICAgICAnMTZweCcsXG4gIGZvbnRXZWlnaHQ6ICAgICAgICAgICc0MDAnLFxuICB0ZXh0QWxpZ246ICAgICAgICAgICAnc3RhcnQnLFxuICB0ZXh0U2hhZG93OiAgICAgICAgICAnbm9uZScsXG4gIHRleHRUcmFuc2Zvcm06ICAgICAgICdub25lJyxcbiAgbGluZUhlaWdodDogICAgICAgICAgJ25vcm1hbCcsXG4gIGxldHRlclNwYWNpbmc6ICAgICAgICdub3JtYWwnLFxuICBkaXNwbGF5OiAgICAgICAgICAgICAnYmxvY2snLFxuICBhbGlnbkl0ZW1zOiAgICAgICAgICAnbm9ybWFsJyxcbiAganVzdGlmeUNvbnRlbnQ6ICAgICAgJ25vcm1hbCcsXG4gIGZsZXhEaXJlY3Rpb246ICAgICAgICdyb3cnLFxuICBmbGV4V3JhcDogICAgICAgICAgICAnbm93cmFwJyxcbiAgZmxleEJhc2lzOiAgICAgICAgICAgJ2F1dG8nLFxuICAvLyBmbGV4RmxvdzogICAgICAgICAnbm9uZScsXG4gIGZpbGw6ICAgICAgICAgICAgICAgICdyZ2IoMCwgMCwgMCknLFxuICBzdHJva2U6ICAgICAgICAgICAgICAnbm9uZScsXG4gIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICdub25lJyxcbiAgZ3JpZEF1dG9Db2x1bW5zOiAgICAgJ2F1dG8nLFxuICBncmlkVGVtcGxhdGVSb3dzOiAgICAnbm9uZScsXG4gIGdyaWRBdXRvUm93czogICAgICAgICdhdXRvJyxcbiAgZ3JpZFRlbXBsYXRlQXJlYXM6ICAgJ25vbmUnLFxuICBncmlkQXJlYTogICAgICAgICAgICAnYXV0byAvIGF1dG8gLyBhdXRvIC8gYXV0bycsXG4gIGdhcDogICAgICAgICAgICAgICAgICdub3JtYWwgbm9ybWFsJyxcbiAgZ3JpZEF1dG9GbG93OiAgICAgICAgJ3JvdycsXG59XG5cbmV4cG9ydCBjb25zdCBkZXNpcmVkQWNjZXNzaWJpbGl0eU1hcCA9IFtcbiAgJ3JvbGUnLFxuICAndGFiaW5kZXgnLFxuICAnYXJpYS0qJyxcbiAgJ2ZvcicsXG4gICdhbHQnLFxuICAndGl0bGUnLFxuICAndHlwZScsXG5dXG5cbmV4cG9ydCBjb25zdCBsYXJnZVdDQUcyVGV4dE1hcCA9IFtcbiAge1xuICAgIGZvbnRTaXplOiAnMjRweCcsXG4gICAgZm9udFdlaWdodDogJzAnXG4gIH0sXG4gIHtcbiAgICBmb250U2l6ZTogJzE4LjVweCcsXG4gICAgZm9udFdlaWdodDogJzcwMCdcbiAgfVxuXVxuIiwiaW1wb3J0IHsgZGVzaXJlZFByb3BNYXAgfSBmcm9tICcuL2Rlc2lnbi1wcm9wZXJ0aWVzJ1xuXG5leHBvcnQgY29uc3QgZ2V0U3R5bGUgPSAoZWwsIG5hbWUpID0+IHtcbiAgaWYgKGRvY3VtZW50LmRlZmF1bHRWaWV3ICYmIGRvY3VtZW50LmRlZmF1bHRWaWV3LmdldENvbXB1dGVkU3R5bGUpIHtcbiAgICBuYW1lID0gbmFtZS5yZXBsYWNlKC8oW0EtWl0pL2csICctJDEnKVxuICAgIG5hbWUgPSBuYW1lLnRvTG93ZXJDYXNlKClcbiAgICBsZXQgcyA9IGRvY3VtZW50LmRlZmF1bHRWaWV3LmdldENvbXB1dGVkU3R5bGUoZWwsICcnKVxuICAgIHJldHVybiBzICYmIHMuZ2V0UHJvcGVydHlWYWx1ZShuYW1lKVxuICB9IFxufVxuXG5leHBvcnQgY29uc3QgZ2V0U3R5bGVzID0gZWwgPT4ge1xuICBjb25zdCBlbFN0eWxlT2JqZWN0ID0gZWwuc3R5bGVcbiAgY29uc3QgY29tcHV0ZWRTdHlsZSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsLCBudWxsKVxuXG4gIGxldCBkZXNpcmVkVmFsdWVzID0gW11cblxuICBmb3IgKHByb3AgaW4gZWwuc3R5bGUpXG4gICAgaWYgKHByb3AgaW4gZGVzaXJlZFByb3BNYXAgJiYgZGVzaXJlZFByb3BNYXBbcHJvcF0gIT0gY29tcHV0ZWRTdHlsZVtwcm9wXSlcbiAgICAgIGRlc2lyZWRWYWx1ZXMucHVzaCh7XG4gICAgICAgIHByb3AsXG4gICAgICAgIHZhbHVlOiBjb21wdXRlZFN0eWxlW3Byb3BdLnJlcGxhY2UoLywgcmdiYS9nLCAnXFxycmdiYScpXG4gICAgICB9KVxuXG4gIHJldHVybiBkZXNpcmVkVmFsdWVzXG59XG5cbmV4cG9ydCBjb25zdCBnZXRDb21wdXRlZEJhY2tncm91bmRDb2xvciA9IGVsID0+IHtcbiAgbGV0IGJhY2tncm91bmQgPSBnZXRTdHlsZShlbCwgJ2JhY2tncm91bmQtY29sb3InKVxuXG4gIGlmIChiYWNrZ3JvdW5kID09PSAncmdiYSgwLCAwLCAwLCAwKScpIHtcbiAgICBsZXQgbm9kZSAgPSBmaW5kTmVhcmVzdFBhcmVudEVsZW1lbnQoZWwpXG4gICAgICAsIGZvdW5kID0gZmFsc2VcblxuICAgIHdoaWxlKCFmb3VuZCkge1xuICAgICAgbGV0IGJnICA9IGdldFN0eWxlKG5vZGUsICdiYWNrZ3JvdW5kLWNvbG9yJylcblxuICAgICAgaWYgKGJnICE9PSAncmdiYSgwLCAwLCAwLCAwKScpIHtcbiAgICAgICAgZm91bmQgPSB0cnVlXG4gICAgICAgIGJhY2tncm91bmQgPSBiZ1xuICAgICAgfVxuXG4gICAgICBub2RlID0gZmluZE5lYXJlc3RQYXJlbnRFbGVtZW50KG5vZGUpXG5cbiAgICAgIGlmIChub2RlLm5vZGVOYW1lID09PSAnSFRNTCcpIHtcbiAgICAgICAgZm91bmQgPSB0cnVlXG4gICAgICAgIGJhY2tncm91bmQgPSAnd2hpdGUnXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGJhY2tncm91bmRcbn1cblxuZXhwb3J0IGNvbnN0IGZpbmROZWFyZXN0UGFyZW50RWxlbWVudCA9IGVsID0+XG4gIGVsLnBhcmVudE5vZGUgJiYgZWwucGFyZW50Tm9kZS5ub2RlVHlwZSA9PT0gMVxuICAgID8gZWwucGFyZW50Tm9kZVxuICAgIDogZWwucGFyZW50Tm9kZS5ub2RlTmFtZSA9PT0gJyNkb2N1bWVudC1mcmFnbWVudCdcbiAgICAgID8gZWwucGFyZW50Tm9kZS5ob3N0XG4gICAgICA6IGVsLnBhcmVudE5vZGUucGFyZW50Tm9kZS5ob3N0XG5cbmV4cG9ydCBjb25zdCBmaW5kTmVhcmVzdENoaWxkRWxlbWVudCA9IGVsID0+IHtcbiAgaWYgKGVsLnNoYWRvd1Jvb3QgJiYgZWwuc2hhZG93Um9vdC5jaGlsZHJlbi5sZW5ndGgpIHtcbiAgICByZXR1cm4gWy4uLmVsLnNoYWRvd1Jvb3QuY2hpbGRyZW5dXG4gICAgICAuZmlsdGVyKCh7bm9kZU5hbWV9KSA9PiBcbiAgICAgICAgIVsnTElOSycsJ1NUWUxFJywnU0NSSVBUJywnSFRNTCcsJ0hFQUQnXS5pbmNsdWRlcyhub2RlTmFtZSlcbiAgICAgIClbMF1cbiAgfVxuICBlbHNlIGlmIChlbC5jaGlsZHJlbi5sZW5ndGgpXG4gICAgcmV0dXJuIGVsLmNoaWxkcmVuWzBdXG59XG5cbmV4cG9ydCBjb25zdCBsb2FkU3R5bGVzID0gYXN5bmMgc3R5bGVzaGVldHMgPT4ge1xuICBjb25zdCBmZXRjaGVzID0gYXdhaXQgUHJvbWlzZS5hbGwoc3R5bGVzaGVldHMubWFwKHVybCA9PiBmZXRjaCh1cmwpKSlcbiAgY29uc3QgdGV4dHMgICA9IGF3YWl0IFByb21pc2UuYWxsKGZldGNoZXMubWFwKHVybCA9PiB1cmwudGV4dCgpKSlcbiAgY29uc3Qgc3R5bGUgICA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJylcblxuICBzdHlsZS50ZXh0Q29udGVudCA9IHRleHRzLnJlZHVjZSgoc3R5bGVzLCBmaWxlQ29udGVudHMpID0+IFxuICAgIHN0eWxlcyArIGZpbGVDb250ZW50c1xuICAsICcnKVxuXG4gIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoc3R5bGUpXG59XG4iLCJpbXBvcnQgeyBkZXNpcmVkQWNjZXNzaWJpbGl0eU1hcCwgZGVzaXJlZFByb3BNYXAsIGxhcmdlV0NBRzJUZXh0TWFwIH0gZnJvbSAnLi9kZXNpZ24tcHJvcGVydGllcydcbmltcG9ydCB7IGdldFN0eWxlcyB9IGZyb20gJy4vc3R5bGVzJ1xuXG5leHBvcnQgY29uc3QgZ2V0QTExeXMgPSBlbCA9PiB7XG4gIGNvbnN0IGVsQXR0cmlidXRlcyA9IGVsLmdldEF0dHJpYnV0ZU5hbWVzKClcblxuICByZXR1cm4gZGVzaXJlZEFjY2Vzc2liaWxpdHlNYXAucmVkdWNlKChhY2MsIGF0dHJpYnV0ZSkgPT4ge1xuICAgIGlmIChlbEF0dHJpYnV0ZXMuaW5jbHVkZXMoYXR0cmlidXRlKSlcbiAgICAgIGFjYy5wdXNoKHtcbiAgICAgICAgcHJvcDogICBhdHRyaWJ1dGUsXG4gICAgICAgIHZhbHVlOiAgZWwuZ2V0QXR0cmlidXRlKGF0dHJpYnV0ZSlcbiAgICAgIH0pXG5cbiAgICBpZiAoYXR0cmlidXRlID09PSAnYXJpYS0qJylcbiAgICAgIGVsQXR0cmlidXRlcy5mb3JFYWNoKGF0dHIgPT4ge1xuICAgICAgICBpZiAoYXR0ci5pbmNsdWRlcygnYXJpYScpKVxuICAgICAgICAgIGFjYy5wdXNoKHtcbiAgICAgICAgICAgIHByb3A6ICAgYXR0cixcbiAgICAgICAgICAgIHZhbHVlOiAgZWwuZ2V0QXR0cmlidXRlKGF0dHIpXG4gICAgICAgICAgfSlcbiAgICAgIH0pXG5cbiAgICByZXR1cm4gYWNjXG4gIH0sIFtdKVxufVxuXG5leHBvcnQgY29uc3QgZ2V0V0NBRzJUZXh0U2l6ZSA9IGVsID0+IHtcbiAgXG4gIGNvbnN0IHN0eWxlcyA9IGdldFN0eWxlcyhlbCkucmVkdWNlKChzdHlsZU1hcCwgc3R5bGUpID0+IHtcbiAgICAgIHN0eWxlTWFwW3N0eWxlLnByb3BdID0gc3R5bGUudmFsdWVcbiAgICAgIHJldHVybiBzdHlsZU1hcFxuICB9LCB7fSlcblxuICBjb25zdCB7IGZvbnRTaXplICAgPSBkZXNpcmVkUHJvcE1hcC5mb250U2l6ZSxcbiAgICAgICAgICBmb250V2VpZ2h0ID0gZGVzaXJlZFByb3BNYXAuZm9udFdlaWdodFxuICAgICAgfSA9IHN0eWxlc1xuICBcbiAgY29uc3QgaXNMYXJnZSA9IGxhcmdlV0NBRzJUZXh0TWFwLnNvbWUoXG4gICAgKGxhcmdlUHJvcGVydGllcykgPT4gcGFyc2VGbG9hdChmb250U2l6ZSkgPj0gcGFyc2VGbG9hdChsYXJnZVByb3BlcnRpZXMuZm9udFNpemUpIFxuICAgICAgICYmIHBhcnNlRmxvYXQoZm9udFdlaWdodCkgPj0gcGFyc2VGbG9hdChsYXJnZVByb3BlcnRpZXMuZm9udFdlaWdodCkgXG4gIClcblxuICByZXR1cm4gIGlzTGFyZ2UgPyAnTGFyZ2UnIDogJ1NtYWxsJ1xufSIsImV4cG9ydCBjb25zdCBjYW1lbFRvRGFzaCA9IChjYW1lbFN0cmluZyA9IFwiXCIpID0+XG4gIGNhbWVsU3RyaW5nLnJlcGxhY2UoLyhbQS1aXSkvZywgKCQxKSA9PlxuICAgIFwiLVwiKyQxLnRvTG93ZXJDYXNlKCkpXG5cbmV4cG9ydCBjb25zdCBub2RlS2V5ID0gbm9kZSA9PiB7XG4gIGxldCB0cmVlID0gW11cbiAgbGV0IGZ1cnRoZXN0X2xlYWYgPSBub2RlXG5cbiAgd2hpbGUgKGZ1cnRoZXN0X2xlYWYpIHtcbiAgICB0cmVlLnB1c2goZnVydGhlc3RfbGVhZilcbiAgICBmdXJ0aGVzdF9sZWFmID0gZnVydGhlc3RfbGVhZi5wYXJlbnROb2RlXG4gICAgICA/IGZ1cnRoZXN0X2xlYWYucGFyZW50Tm9kZVxuICAgICAgOiBmYWxzZVxuICB9XG5cbiAgcmV0dXJuIHRyZWUucmVkdWNlKChwYXRoLCBicmFuY2gpID0+IGBcbiAgICAke3BhdGh9JHticmFuY2gudGFnTmFtZX1fJHticmFuY2guY2xhc3NOYW1lfV8ke1suLi5ub2RlLnBhcmVudE5vZGUuY2hpbGRyZW5dLmluZGV4T2Yobm9kZSl9XyR7bm9kZS5jaGlsZHJlbi5sZW5ndGh9XG4gIGAsICcnKVxufVxuXG5leHBvcnQgY29uc3QgY3JlYXRlQ2xhc3NuYW1lID0gKGVsLCBlbGxpcHNlID0gZmFsc2UpID0+IHtcbiAgaWYgKCFlbC5jbGFzc05hbWUpIHJldHVybiAnJ1xuICBcbiAgY29uc3QgY29tYmluZWQgPSBBcnJheS5mcm9tKGVsLmNsYXNzTGlzdCkucmVkdWNlKChjbGFzc25hbWVzLCBjbGFzc25hbWUpID0+XG4gICAgY2xhc3NuYW1lcyArPSAnLicgKyBjbGFzc25hbWVcbiAgLCAnJylcblxuICByZXR1cm4gZWxsaXBzZSAmJiBjb21iaW5lZC5sZW5ndGggPiAzMFxuICAgID8gY29tYmluZWQuc3Vic3RyaW5nKDAsMzApICsgJy4uLidcbiAgICA6IGNvbWJpbmVkXG59XG5cbmV4cG9ydCBjb25zdCBtZXRhS2V5ID0gd2luZG93Lm5hdmlnYXRvci5wbGF0Zm9ybS5pbmNsdWRlcygnTWFjJylcbiAgPyAnY21kJ1xuICA6ICdjdHJsJ1xuXG5leHBvcnQgY29uc3QgYWx0S2V5ID0gd2luZG93Lm5hdmlnYXRvci5wbGF0Zm9ybS5pbmNsdWRlcygnTWFjJylcbiAgPyAnb3B0J1xuICA6ICdhbHQnXG4iLCJpbXBvcnQgJCBmcm9tICdibGluZ2JsaW5nanMnXG5pbXBvcnQgeyBub2RlS2V5IH0gZnJvbSAnLi9zdHJpbmdzJ1xuXG5leHBvcnQgY29uc3QgZGVlcEVsZW1lbnRGcm9tUG9pbnQgPSAoeCwgeSkgPT4ge1xuICBjb25zdCBlbCA9IGRvY3VtZW50LmVsZW1lbnRGcm9tUG9pbnQoeCwgeSlcblxuICBjb25zdCBjcmF3bFNoYWRvd3MgPSBub2RlID0+IHtcbiAgICBpZiAobm9kZS5zaGFkb3dSb290KSB7XG4gICAgICBjb25zdCBwb3RlbnRpYWwgPSBub2RlLnNoYWRvd1Jvb3QuZWxlbWVudEZyb21Qb2ludCh4LCB5KVxuXG4gICAgICBpZiAocG90ZW50aWFsID09IG5vZGUpICAgICAgICAgIHJldHVybiBub2RlXG4gICAgICBlbHNlIGlmIChwb3RlbnRpYWwuc2hhZG93Um9vdCkgIHJldHVybiBjcmF3bFNoYWRvd3MocG90ZW50aWFsKVxuICAgICAgZWxzZSAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcG90ZW50aWFsXG4gICAgfVxuICAgIGVsc2UgcmV0dXJuIG5vZGVcbiAgfVxuXG4gIGNvbnN0IG5lc3RlZF9zaGFkb3cgPSBjcmF3bFNoYWRvd3MoZWwpXG5cbiAgcmV0dXJuIG5lc3RlZF9zaGFkb3cgfHwgZWxcbn1cblxuZXhwb3J0IGNvbnN0IGdldFNpZGUgPSBkaXJlY3Rpb24gPT4ge1xuICBsZXQgc3RhcnQgPSBkaXJlY3Rpb24uc3BsaXQoJysnKS5wb3AoKS5yZXBsYWNlKC9eXFx3LywgYyA9PiBjLnRvVXBwZXJDYXNlKCkpXG4gIGlmIChzdGFydCA9PSAnVXAnKSBzdGFydCA9ICdUb3AnXG4gIGlmIChzdGFydCA9PSAnRG93bicpIHN0YXJ0ID0gJ0JvdHRvbSdcbiAgcmV0dXJuIHN0YXJ0XG59XG5cbmV4cG9ydCBjb25zdCBnZXROb2RlSW5kZXggPSBlbCA9PiB7XG4gIHJldHVybiBbLi4uZWwucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LmNoaWxkcmVuXVxuICAgIC5pbmRleE9mKGVsLnBhcmVudEVsZW1lbnQpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzaG93RWRnZShlbCkge1xuICByZXR1cm4gZWwuYW5pbWF0ZShbXG4gICAgeyBvdXRsaW5lOiAnMXB4IHNvbGlkIHRyYW5zcGFyZW50JyB9LFxuICAgIHsgb3V0bGluZTogJzFweCBzb2xpZCBoc2xhKDMzMCwgMTAwJSwgNzElLCA4MCUpJyB9LFxuICAgIHsgb3V0bGluZTogJzFweCBzb2xpZCB0cmFuc3BhcmVudCcgfSxcbiAgXSwgNjAwKVxufVxuXG5sZXQgdGltZW91dE1hcCA9IHt9XG5leHBvcnQgY29uc3Qgc2hvd0hpZGVTZWxlY3RlZCA9IChlbCwgZHVyYXRpb24gPSA3NTApID0+IHtcbiAgZWwuc2V0QXR0cmlidXRlKCdkYXRhLXNlbGVjdGVkLWhpZGUnLCB0cnVlKVxuICBzaG93SGlkZU5vZGVMYWJlbChlbCwgdHJ1ZSlcblxuICBpZiAodGltZW91dE1hcFtub2RlS2V5KGVsKV0pXG4gICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRNYXBbbm9kZUtleShlbCldKVxuXG4gIHRpbWVvdXRNYXBbbm9kZUtleShlbCldID0gc2V0VGltZW91dChfID0+IHtcbiAgICBlbC5yZW1vdmVBdHRyaWJ1dGUoJ2RhdGEtc2VsZWN0ZWQtaGlkZScpXG4gICAgc2hvd0hpZGVOb2RlTGFiZWwoZWwsIGZhbHNlKVxuICB9LCBkdXJhdGlvbilcblxuICByZXR1cm4gZWxcbn1cblxuZXhwb3J0IGNvbnN0IHNob3dIaWRlTm9kZUxhYmVsID0gKGVsLCBzaG93ID0gZmFsc2UpID0+IHtcbiAgaWYgKCFlbC5oYXNBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnKSlcbiAgICByZXR1cm5cblxuICBjb25zdCBsYWJlbF9pZCA9IGVsLmdldEF0dHJpYnV0ZSgnZGF0YS1sYWJlbC1pZCcpXG5cbiAgY29uc3Qgbm9kZXMgPSAkKGBcbiAgICB2aXNidWctbGFiZWxbZGF0YS1sYWJlbC1pZD1cIiR7bGFiZWxfaWR9XCJdLFxuICAgIHZpc2J1Zy1oYW5kbGVzW2RhdGEtbGFiZWwtaWQ9XCIke2xhYmVsX2lkfVwiXVxuICBgKVxuXG4gIG5vZGVzLmxlbmd0aCAmJiBzaG93XG4gICAgPyBub2Rlcy5mb3JFYWNoKGVsID0+XG4gICAgICBlbC5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnKVxuICAgIDogbm9kZXMuZm9yRWFjaChlbCA9PlxuICAgICAgZWwuc3R5bGUuZGlzcGxheSA9IG51bGwpXG59XG5cbmV4cG9ydCBjb25zdCBodG1sU3RyaW5nVG9Eb20gPSAoaHRtbFN0cmluZyA9IFwiXCIpID0+XG4gIChuZXcgRE9NUGFyc2VyKCkucGFyc2VGcm9tU3RyaW5nKGh0bWxTdHJpbmcsICd0ZXh0L2h0bWwnKSlcbiAgICAuYm9keS5maXJzdENoaWxkXG5cbmV4cG9ydCBjb25zdCBpc09mZkJvdW5kcyA9IG5vZGUgPT5cbiAgbm9kZS5jbG9zZXN0ICYmIChcbiAgICAgICBub2RlLmNsb3Nlc3QoJ3Zpcy1idWcnKVxuICAgIHx8IG5vZGUuY2xvc2VzdCgnaG90a2V5LW1hcCcpXG4gICAgfHwgbm9kZS5jbG9zZXN0KCd2aXNidWctbWV0YXRpcCcpXG4gICAgfHwgbm9kZS5jbG9zZXN0KCd2aXNidWctYWxseScpXG4gICAgfHwgbm9kZS5jbG9zZXN0KCd2aXNidWctbGFiZWwnKVxuICAgIHx8IG5vZGUuY2xvc2VzdCgndmlzYnVnLWhhbmRsZXMnKVxuICAgIHx8IG5vZGUuY2xvc2VzdCgndmlzYnVnLWdyaWRsaW5lcycpXG4gIClcblxuZXhwb3J0IGNvbnN0IGlzU2VsZWN0b3JWYWxpZCA9IChxcyA9PiAoXG4gIHNlbGVjdG9yID0+IHtcbiAgICB0cnkgeyBxcyhzZWxlY3RvcikgfSBjYXRjaCAoZSkgeyByZXR1cm4gZmFsc2UgfVxuICAgIHJldHVybiB0cnVlXG4gIH1cbikpKHMgPT4gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpLnF1ZXJ5U2VsZWN0b3IocykpXG4iLCJleHBvcnQgZnVuY3Rpb24gd2luZG93Qm91bmRzKCkge1xuICBjb25zdCBoZWlnaHQgID0gd2luZG93LmlubmVySGVpZ2h0XG4gIGNvbnN0IHdpZHRoICAgPSB3aW5kb3cuaW5uZXJXaWR0aFxuICBjb25zdCBib2R5ICAgID0gZG9jdW1lbnQuYm9keS5jbGllbnRXaWR0aFxuXG4gIGNvbnN0IGNhbGNXaWR0aCA9IGJvZHkgPD0gd2lkdGhcbiAgICA/IGJvZHlcbiAgICA6IHdpZHRoXG5cbiAgcmV0dXJuIHtcbiAgICB3aW5IZWlnaHQ6IGhlaWdodCxcbiAgICB3aW5XaWR0aDogIGNhbGNXaWR0aCxcbiAgfVxufVxuIiwiaW1wb3J0IHsgd2luZG93Qm91bmRzIH0gZnJvbSAnLi4vLi4vdXRpbGl0aWVzLydcblxuZXhwb3J0IGNsYXNzIEdyaWRsaW5lcyBleHRlbmRzIEhUTUxFbGVtZW50IHtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG4gICAgdGhpcy4kc2hhZG93ID0gdGhpcy5hdHRhY2hTaGFkb3coe21vZGU6ICdjbG9zZWQnfSlcbiAgfVxuXG4gIGNvbm5lY3RlZENhbGxiYWNrKCkge31cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7fVxuXG4gIHNldCBwb3NpdGlvbihib3VuZGluZ1JlY3QpIHtcbiAgICB0aGlzLiRzaGFkb3cuaW5uZXJIVE1MICA9IHRoaXMucmVuZGVyKGJvdW5kaW5nUmVjdClcbiAgfVxuXG4gIHNldCB1cGRhdGUoeyB3aWR0aCwgaGVpZ2h0LCB0b3AsIGxlZnQgfSkge1xuICAgIGNvbnN0IHsgd2luSGVpZ2h0LCB3aW5XaWR0aCB9ID0gd2luZG93Qm91bmRzKClcblxuICAgIHRoaXMuJHNoYWRvdy5ob3N0LnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snXG4gICAgY29uc3Qgc3ZnID0gdGhpcy4kc2hhZG93LmNoaWxkcmVuWzFdXG5cbiAgICBzdmcuc2V0QXR0cmlidXRlKCd2aWV3Qm94JywgYDAgMCAke3dpbldpZHRofSAke3dpbkhlaWdodH1gKVxuICAgIHN2Zy5jaGlsZHJlblswXS5zZXRBdHRyaWJ1dGUoJ3dpZHRoJywgd2lkdGggKyAncHgnKVxuICAgIHN2Zy5jaGlsZHJlblswXS5zZXRBdHRyaWJ1dGUoJ2hlaWdodCcsIGhlaWdodCArICdweCcpXG4gICAgc3ZnLmNoaWxkcmVuWzBdLnNldEF0dHJpYnV0ZSgneCcsIGxlZnQpXG4gICAgc3ZnLmNoaWxkcmVuWzBdLnNldEF0dHJpYnV0ZSgneScsIHRvcClcbiAgICBzdmcuY2hpbGRyZW5bMV0uc2V0QXR0cmlidXRlKCd4MScsIGxlZnQpXG4gICAgc3ZnLmNoaWxkcmVuWzFdLnNldEF0dHJpYnV0ZSgneDInLCBsZWZ0KVxuICAgIHN2Zy5jaGlsZHJlblsyXS5zZXRBdHRyaWJ1dGUoJ3gxJywgbGVmdCArIHdpZHRoKVxuICAgIHN2Zy5jaGlsZHJlblsyXS5zZXRBdHRyaWJ1dGUoJ3gyJywgbGVmdCArIHdpZHRoKVxuICAgIHN2Zy5jaGlsZHJlblszXS5zZXRBdHRyaWJ1dGUoJ3kxJywgdG9wKVxuICAgIHN2Zy5jaGlsZHJlblszXS5zZXRBdHRyaWJ1dGUoJ3kyJywgdG9wKVxuICAgIHN2Zy5jaGlsZHJlblszXS5zZXRBdHRyaWJ1dGUoJ3gyJywgd2luV2lkdGgpXG4gICAgc3ZnLmNoaWxkcmVuWzRdLnNldEF0dHJpYnV0ZSgneTEnLCB0b3AgKyBoZWlnaHQpXG4gICAgc3ZnLmNoaWxkcmVuWzRdLnNldEF0dHJpYnV0ZSgneTInLCB0b3AgKyBoZWlnaHQpXG4gICAgc3ZnLmNoaWxkcmVuWzRdLnNldEF0dHJpYnV0ZSgneDInLCB3aW5XaWR0aClcbiAgfVxuXG4gIHJlbmRlcih7IHgsIHksIHdpZHRoLCBoZWlnaHQsIHRvcCwgbGVmdCB9KSB7XG4gICAgY29uc3QgeyB3aW5IZWlnaHQsIHdpbldpZHRoIH0gPSB3aW5kb3dCb3VuZHMoKVxuXG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoe3RvcCxsZWZ0fSl9XG4gICAgICA8c3ZnXG4gICAgICAgIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIlxuICAgICAgICB2aWV3Qm94PVwiMCAwICR7d2luV2lkdGh9ICR7d2luSGVpZ2h0fVwiXG4gICAgICAgIHZlcnNpb249XCIxLjFcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgID5cbiAgICAgICAgPHJlY3RcbiAgICAgICAgICBzdHJva2U9XCJob3RwaW5rXCIgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgIHdpZHRoPVwiJHt3aWR0aH1cIiBoZWlnaHQ9XCIke2hlaWdodH1cIlxuICAgICAgICAgIHg9XCIke3h9XCIgeT1cIiR7eX1cIlxuICAgICAgICAgIHN0eWxlPVwiZGlzcGxheTpub25lO1wiXG4gICAgICAgID48L3JlY3Q+XG4gICAgICAgIDxsaW5lIHgxPVwiJHt4fVwiIHkxPVwiMFwiIHgyPVwiJHt4fVwiIHkyPVwiJHt3aW5IZWlnaHR9XCIgc3Ryb2tlPVwiaG90cGlua1wiIHN0cm9rZS1kYXNoYXJyYXk9XCIyXCIgc3Ryb2tlLWRhc2hvZmZzZXQ9XCIzXCI+PC9saW5lPlxuICAgICAgICA8bGluZSB4MT1cIiR7eCArIHdpZHRofVwiIHkxPVwiMFwiIHgyPVwiJHt4ICsgd2lkdGh9XCIgeTI9XCIke3dpbkhlaWdodH1cIiBzdHJva2U9XCJob3RwaW5rXCIgc3Ryb2tlLWRhc2hhcnJheT1cIjJcIiBzdHJva2UtZGFzaG9mZnNldD1cIjNcIj48L2xpbmU+XG4gICAgICAgIDxsaW5lIHgxPVwiMFwiIHkxPVwiJHt5fVwiIHgyPVwiJHt3aW5XaWR0aH1cIiB5Mj1cIiR7eX1cIiBzdHJva2U9XCJob3RwaW5rXCIgc3Ryb2tlLWRhc2hhcnJheT1cIjJcIiBzdHJva2UtZGFzaG9mZnNldD1cIjNcIj48L2xpbmU+XG4gICAgICAgIDxsaW5lIHgxPVwiMFwiIHkxPVwiJHt5ICsgaGVpZ2h0fVwiIHgyPVwiJHt3aW5XaWR0aH1cIiB5Mj1cIiR7eSArIGhlaWdodH1cIiBzdHJva2U9XCJob3RwaW5rXCIgc3Ryb2tlLWRhc2hhcnJheT1cIjJcIiBzdHJva2UtZGFzaG9mZnNldD1cIjNcIj48L2xpbmU+XG4gICAgICA8L3N2Zz5cbiAgICBgXG4gIH1cblxuICBzdHlsZXMoe3RvcCxsZWZ0fSkge1xuICAgIHJldHVybiBgXG4gICAgICA8c3R5bGU+XG4gICAgICAgIDpob3N0ID4gc3ZnIHtcbiAgICAgICAgICBwb3NpdGlvbjpmaXhlZDtcbiAgICAgICAgICB0b3A6MDtcbiAgICAgICAgICBsZWZ0OjA7XG4gICAgICAgICAgb3ZlcmZsb3c6dmlzaWJsZTtcbiAgICAgICAgICBwb2ludGVyLWV2ZW50czpub25lO1xuICAgICAgICAgIHotaW5kZXg6MjE0NzQ4MzY0MjtcbiAgICAgICAgfVxuICAgICAgPC9zdHlsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCd2aXNidWctZ3JpZGxpbmVzJywgR3JpZGxpbmVzKVxuIiwiZXhwb3J0IGNsYXNzIERpc3RhbmNlIGV4dGVuZHMgSFRNTEVsZW1lbnQge1xuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcbiAgICB0aGlzLiRzaGFkb3cgPSB0aGlzLmF0dGFjaFNoYWRvdyh7bW9kZTogJ29wZW4nfSlcbiAgfVxuXG4gIGNvbm5lY3RlZENhbGxiYWNrKCkge31cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7fVxuXG4gIHNldCBwb3NpdGlvbih7bGluZV9tb2RlbCwgbm9kZV9sYWJlbF9pZH0pIHtcbiAgICB0aGlzLiRzaGFkb3cuaW5uZXJIVE1MICA9IHRoaXMucmVuZGVyKGxpbmVfbW9kZWwsIG5vZGVfbGFiZWxfaWQpXG4gIH1cblxuICByZW5kZXIobWVhc3VyZW1lbnRzLCBub2RlX2xhYmVsX2lkKSB7XG4gICAgdGhpcy4kc2hhZG93Lmhvc3Quc2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJywgbm9kZV9sYWJlbF9pZClcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcyhtZWFzdXJlbWVudHMpfVxuICAgICAgPGZpZ3VyZSBxdWFkcmFudD1cIm1lYXN1cmVtZW50cy5xXCI+XG4gICAgICAgIDxkaXY+PC9kaXY+XG4gICAgICAgIDxmaWdjYXB0aW9uPjxiPiR7bWVhc3VyZW1lbnRzLmR9PC9iPnB4PC9maWdjYXB0aW9uPlxuICAgICAgICA8ZGl2PjwvZGl2PlxuICAgICAgPC9maWd1cmU+XG4gICAgYFxuICB9XG5cbiAgc3R5bGVzKHt5LHgsZCxxLHYgPSBmYWxzZX0pIHtcbiAgICByZXR1cm4gYFxuICAgICAgPHN0eWxlPlxuICAgICAgICA6aG9zdCB7XG4gICAgICAgICAgLS1saW5lLWNvbG9yOiBoc2woMjY3LCAxMDAlLCA1OCUpO1xuICAgICAgICAgIC0tbGluZS13aWR0aDogMXB4O1xuICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgfVxuXG4gICAgICAgIDpob3N0ID4gZmlndXJlIHtcbiAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICR7dlxuICAgICAgICAgICAgPyBgaGVpZ2h0OiAke2R9cHg7IHdpZHRoOiA1cHg7YFxuICAgICAgICAgICAgOiBgd2lkdGg6ICR7ZH1weDsgaGVpZ2h0OiA1cHg7YH1cbiAgICAgICAgICB0b3A6ICR7eSArIHdpbmRvdy5zY3JvbGxZfXB4O1xuICAgICAgICAgIGxlZnQ6ICR7eH1weDtcbiAgICAgICAgICB0cmFuc2Zvcm06ICR7dlxuICAgICAgICAgICAgPyAndHJhbnNsYXRlWCgtNTAlKSdcbiAgICAgICAgICAgIDogJ3RyYW5zbGF0ZVkoLTUwJSknfTtcbiAgICAgICAgICBvdmVyZmxvdzogdmlzaWJsZTtcbiAgICAgICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICAgICAgICB6LWluZGV4OiAyMTQ3NDgzNjQ2O1xuXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiAke3YgPyAnY29sdW1uJyA6ICdyb3cnfTtcbiAgICAgICAgfVxuXG4gICAgICAgIDpob3N0ID4gZmlndXJlIGZpZ2NhcHRpb24ge1xuICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICB0ZXh0LXNoYWRvdzogMCAwLjVweCAwIGhzbGEoMCwgMCUsIDAlLCAwLjQpO1xuICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWxpbmUtY29sb3IpO1xuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDFlbTtcbiAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgbGluZS1oZWlnaHQ6IDEuMTtcbiAgICAgICAgICBmb250LXNpemU6IDAuN2VtO1xuICAgICAgICAgIGZvbnQtZmFtaWx5OiBzeXN0ZW0tdWksIC1hcHBsZS1zeXN0ZW0sIFNlZ29lIFVJLCBSb2JvdG8sIFVidW50dSwgQ2FudGFyZWxsLCBOb3RvIFNhbnMsIHNhbnMtc2VyaWY7XG4gICAgICAgICAgcGFkZGluZzogMC4yNWVtIDAuNWVtIDAuMjc1ZW07XG4gICAgICAgICAgZm9udC12YXJpYW50LW51bWVyaWM6IHByb3BvcnRpb25hbC1udW0gb2xkc3R5bGUtbnVtcyBzdGFja2VkLWZyYWN0aW9ucyBzbGFzaGVkLXplcm87XG4gICAgICAgIH1cblxuICAgICAgICA6aG9zdCA+IGZpZ3VyZSBzcGFuIHtcbiAgICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1saW5lLWNvbG9yKTtcbiAgICAgICAgICAke3ZcbiAgICAgICAgICAgID8gJ2hlaWdodDogdmFyKC0tbGluZS13aWR0aCk7IHdpZHRoOiA1cHg7J1xuICAgICAgICAgICAgOiAnd2lkdGg6IHZhcigtLWxpbmUtd2lkdGgpOyBoZWlnaHQ6IDVweDsnfVxuICAgICAgICB9XG5cbiAgICAgICAgOmhvc3QgPiBmaWd1cmUgZGl2IHtcbiAgICAgICAgICBmbGV4OiAyO1xuICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWxpbmUtY29sb3IpO1xuICAgICAgICAgICR7dlxuICAgICAgICAgICAgPyAnd2lkdGg6IHZhcigtLWxpbmUtd2lkdGgpOydcbiAgICAgICAgICAgIDogJ2hlaWdodDogdmFyKC0tbGluZS13aWR0aCk7J31cbiAgICAgICAgfVxuXG4gICAgICAgIDpob3N0IGZpZ3VyZSA+IGRpdiR7cSA9PT0gJ3RvcCcgfHwgcSA9PT0gJ2xlZnQnID8gJzpsYXN0LW9mLXR5cGUnIDogJzpmaXJzdC1vZi10eXBlJ30ge1xuICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byAke3F9LCBob3RwaW5rIDAlLCB2YXIoLS1saW5lLWNvbG9yKSAxMDAlKTtcbiAgICAgICAgfVxuICAgICAgPC9zdHlsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCd2aXNidWctZGlzdGFuY2UnLCBEaXN0YW5jZSlcbiIsImV4cG9ydCBjbGFzcyBPdmVybGF5IGV4dGVuZHMgSFRNTEVsZW1lbnQge1xuICBcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuICAgIHRoaXMuJHNoYWRvdyA9IHRoaXMuYXR0YWNoU2hhZG93KHttb2RlOiAnY2xvc2VkJ30pXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG4gIGRpc2Nvbm5lY3RlZENhbGxiYWNrKCkge31cblxuICBzZXQgcG9zaXRpb24oYm91bmRpbmdSZWN0KSB7XG4gICAgdGhpcy4kc2hhZG93LmlubmVySFRNTCAgPSB0aGlzLnJlbmRlcihib3VuZGluZ1JlY3QpXG4gIH1cblxuICBzZXQgdXBkYXRlKHsgdG9wLCBsZWZ0LCB3aWR0aCwgaGVpZ2h0IH0pIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJ1xuXG4gICAgY29uc3Qgc3ZnID0gdGhpcy4kc2hhZG93LmNoaWxkcmVuWzBdXG4gICAgc3ZnLnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snXG4gICAgc3ZnLnN0eWxlLnRvcCA9IHdpbmRvdy5zY3JvbGxZICsgdG9wICsgJ3B4J1xuICAgIHN2Zy5zdHlsZS5sZWZ0ID0gbGVmdCArICdweCdcblxuICAgIHN2Zy5zZXRBdHRyaWJ1dGUoJ3dpZHRoJywgd2lkdGggKyAncHgnKVxuICAgIHN2Zy5zZXRBdHRyaWJ1dGUoJ2hlaWdodCcsIGhlaWdodCArICdweCcpXG4gIH1cblxuICByZW5kZXIoe2lkLCB0b3AsIGxlZnQsIGhlaWdodCwgd2lkdGh9KSB7XG4gICAgcmV0dXJuIGBcbiAgICAgIDxzdmcgXG4gICAgICAgIGNsYXNzPVwidmlzYnVnLW92ZXJsYXlcIlxuICAgICAgICBvdmVybGF5LWlkPVwiJHtpZH1cIlxuICAgICAgICBzdHlsZT1cIlxuICAgICAgICAgIGRpc3BsYXk6bm9uZTtcbiAgICAgICAgICBwb3NpdGlvbjphYnNvbHV0ZTtcbiAgICAgICAgICB0b3A6MDtcbiAgICAgICAgICBsZWZ0OjA7XG4gICAgICAgICAgb3ZlcmZsb3c6dmlzaWJsZTtcbiAgICAgICAgICBwb2ludGVyLWV2ZW50czpub25lO1xuICAgICAgICAgIHotaW5kZXg6IDk5OTtcbiAgICAgICAgXCIgXG4gICAgICAgIHdpZHRoPVwiJHt3aWR0aH1weFwiIGhlaWdodD1cIiR7aGVpZ2h0fXB4XCIgXG4gICAgICAgIHZpZXdCb3g9XCIwIDAgJHt3aWR0aH0gJHtoZWlnaHR9XCIgXG4gICAgICAgIHZlcnNpb249XCIxLjFcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgID5cbiAgICAgICAgPHJlY3QgXG4gICAgICAgICAgZmlsbD1cImhzbGEoMzMwLCAxMDAlLCA3MSUsIDAuNSlcIlxuICAgICAgICAgIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIlxuICAgICAgICA+PC9yZWN0PlxuICAgICAgPC9zdmc+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgndmlzYnVnLW92ZXJsYXknLCBPdmVybGF5KVxuIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IHsgY3JlYXRlQ2xhc3NuYW1lIH0gZnJvbSAnLi4vLi4vdXRpbGl0aWVzLydcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi9tZXRhdGlwLmVsZW1lbnQuY3NzJ1xuXG5leHBvcnQgY2xhc3MgTWV0YXRpcCBleHRlbmRzIEhUTUxFbGVtZW50IHtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG4gICAgdGhpcy4kc2hhZG93ID0gdGhpcy5hdHRhY2hTaGFkb3coe21vZGU6ICdjbG9zZWQnfSlcbiAgfVxuXG4gIGNvbm5lY3RlZENhbGxiYWNrKCkge1xuICAgICQodGhpcy4kc2hhZG93Lmhvc3QpLm9uKCdtb3VzZWVudGVyJywgdGhpcy5vYnNlcnZlLmJpbmQodGhpcykpXG4gIH1cblxuICBkaXNjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICB0aGlzLnVub2JzZXJ2ZSgpXG4gIH1cblxuICBkaXNwYXRjaFF1ZXJ5KGUpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5kaXNwYXRjaEV2ZW50KG5ldyBDdXN0b21FdmVudCgncXVlcnknLCB7XG4gICAgICBidWJibGVzOiB0cnVlLFxuICAgICAgZGV0YWlsOiAgIHtcbiAgICAgICAgdGV4dDogICAgICAgZS50YXJnZXQudGV4dENvbnRlbnQsXG4gICAgICAgIGFjdGl2YXRvcjogIGUudHlwZSxcbiAgICAgIH1cbiAgICB9KSlcbiAgfVxuXG4gIG9ic2VydmUoKSB7XG4gICAgJCgnaDUgPiBhJywgdGhpcy4kc2hhZG93KS5vbignY2xpY2sgbW91c2VlbnRlcicsIHRoaXMuZGlzcGF0Y2hRdWVyeS5iaW5kKHRoaXMpKVxuICAgICQoJ2g1ID4gYScsIHRoaXMuJHNoYWRvdykub24oJ21vdXNlbGVhdmUnLCB0aGlzLmRpc3BhdGNoVW5RdWVyeS5iaW5kKHRoaXMpKVxuICB9XG5cbiAgdW5vYnNlcnZlKCkge1xuICAgICQoJ2g1ID4gYScsIHRoaXMuJHNoYWRvdykub2ZmKCdjbGljayBtb3VzZWVudGVyJywgdGhpcy5kaXNwYXRjaFF1ZXJ5LmJpbmQodGhpcykpXG4gICAgJCgnaDUgPiBhJywgdGhpcy4kc2hhZG93KS5vZmYoJ21vdXNlbGVhdmUnLCB0aGlzLmRpc3BhdGNoVW5RdWVyeS5iaW5kKHRoaXMpKVxuICB9XG5cbiAgZGlzcGF0Y2hVblF1ZXJ5KGUpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5kaXNwYXRjaEV2ZW50KG5ldyBDdXN0b21FdmVudCgndW5xdWVyeScsIHtcbiAgICAgIGJ1YmJsZXM6IHRydWVcbiAgICB9KSlcbiAgICB0aGlzLnVub2JzZXJ2ZSgpXG4gIH1cblxuICBzZXQgbWV0YShkYXRhKSB7XG4gICAgdGhpcy4kc2hhZG93LmlubmVySFRNTCA9IHRoaXMucmVuZGVyKGRhdGEpXG4gIH1cblxuICByZW5kZXIoe2VsLCB3aWR0aCwgaGVpZ2h0LCBsb2NhbE1vZGlmaWNhdGlvbnMsIG5vdExvY2FsTW9kaWZpY2F0aW9uc30pIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcygpfVxuICAgICAgPGZpZ3VyZT5cbiAgICAgICAgPGg1PlxuICAgICAgICAgIDxhIG5vZGU+JHtlbC5ub2RlTmFtZS50b0xvd2VyQ2FzZSgpfTwvYT5cbiAgICAgICAgICA8YT4ke2VsLmlkICYmICcjJyArIGVsLmlkfTwvYT5cbiAgICAgICAgICAke2NyZWF0ZUNsYXNzbmFtZShlbCkuc3BsaXQoJy4nKVxuICAgICAgICAgICAgLmZpbHRlcihuYW1lID0+IG5hbWUgIT0gJycpXG4gICAgICAgICAgICAucmVkdWNlKChsaW5rcywgbmFtZSkgPT4gYFxuICAgICAgICAgICAgICAke2xpbmtzfVxuICAgICAgICAgICAgICA8YT4uJHtuYW1lfTwvYT5cbiAgICAgICAgICAgIGAsICcnKVxuICAgICAgICAgIH1cbiAgICAgICAgPC9oNT5cbiAgICAgICAgPHNtYWxsPlxuICAgICAgICAgIDxzcGFuXCI+JHtNYXRoLnJvdW5kKHdpZHRoKX08L3NwYW4+cHhcbiAgICAgICAgICA8c3BhbiBkaXZpZGVyPsOXPC9zcGFuPlxuICAgICAgICAgIDxzcGFuPiR7TWF0aC5yb3VuZChoZWlnaHQpfTwvc3Bhbj5weFxuICAgICAgICA8L3NtYWxsPlxuICAgICAgICA8ZGl2PiR7bm90TG9jYWxNb2RpZmljYXRpb25zLnJlZHVjZSgoaXRlbXMsIGl0ZW0pID0+IGBcbiAgICAgICAgICAke2l0ZW1zfVxuICAgICAgICAgIDxzcGFuIHByb3A+JHtpdGVtLnByb3B9Ojwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiB2YWx1ZT4ke2l0ZW0udmFsdWV9PC9zcGFuPlxuICAgICAgICBgLCAnJyl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICAke2xvY2FsTW9kaWZpY2F0aW9ucy5sZW5ndGggPyBgXG4gICAgICAgICAgPGg2IGxvY2FsLW1vZGlmaWNhdGlvbnM+TG9jYWwgTW9kaWZpY2F0aW9uczwvaDY+XG4gICAgICAgICAgPGRpdj4ke2xvY2FsTW9kaWZpY2F0aW9ucy5yZWR1Y2UoKGl0ZW1zLCBpdGVtKSA9PiBgXG4gICAgICAgICAgICAke2l0ZW1zfVxuICAgICAgICAgICAgPHNwYW4gcHJvcD4ke2l0ZW0ucHJvcH06PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gdmFsdWU+JHtpdGVtLnZhbHVlfTwvc3Bhbj5cbiAgICAgICAgICBgLCAnJyl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIGAgOiAnJ31cbiAgICAgIDwvZmlndXJlPlxuICAgIGBcbiAgfVxuXG4gIHN0eWxlcygpIHtcbiAgICByZXR1cm4gYFxuICAgICAgPHN0eWxlPlxuICAgICAgICAke3N0eWxlc31cbiAgICAgIDwvc3R5bGU+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgndmlzYnVnLW1ldGF0aXAnLCBNZXRhdGlwKVxuIiwiaW1wb3J0IHsgTWV0YXRpcCB9IGZyb20gJy4vbWV0YXRpcC5lbGVtZW50LmpzJ1xuXG5leHBvcnQgY2xhc3MgQWxseSBleHRlbmRzIE1ldGF0aXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG4gIH1cbiAgXG4gIHJlbmRlcih7ZWwsIGFsbHlfYXR0cmlidXRlcywgY29udHJhc3RfcmVzdWx0c30pIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcygpfVxuICAgICAgPGZpZ3VyZT5cbiAgICAgICAgPGg1PiR7ZWwubm9kZU5hbWUudG9Mb3dlckNhc2UoKX0ke2VsLmlkICYmICcjJyArIGVsLmlkfTwvaDU+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgJHthbGx5X2F0dHJpYnV0ZXMucmVkdWNlKChpdGVtcywgYXR0cikgPT4gYFxuICAgICAgICAgICAgJHtpdGVtc31cbiAgICAgICAgICAgIDxzcGFuIHByb3A+JHthdHRyLnByb3B9Ojwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIHZhbHVlPiR7YXR0ci52YWx1ZX08L3NwYW4+XG4gICAgICAgICAgYCwgJycpfVxuICAgICAgICAgICR7Y29udHJhc3RfcmVzdWx0c31cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2ZpZ3VyZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCd2aXNidWctYWxseScsIEFsbHkpXG4iLCJleHBvcnQgY29uc3QgY3Vyc29yID0gYFxuICA8c3ZnIGNsYXNzPVwiaWNvbi1jdXJzb3JcIiB2ZXJzaW9uPVwiMS4xXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMzIgMzJcIj5cbiAgICA8cGF0aCBkPVwiTTE2LjY4OSAxNy42NTVsNS4zMTEgMTIuMzQ1LTQgMi00LjY0Ni0xMi42NzgtNy4zNTQgNi42Nzh2LTI2bDIwIDE2LTkuMzExIDEuNjU1elwiPjwvcGF0aD5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBtb3ZlID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk0xNSA3LjVWMkg5djUuNWwzIDMgMy0zek03LjUgOUgydjZoNS41bDMtMy0zLTN6TTkgMTYuNVYyMmg2di01LjVsLTMtMy0zIDN6TTE2LjUgOWwtMyAzIDMgM0gyMlY5aC01LjV6XCIvPlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IHNlYXJjaCA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNMTUuNSAxNGgtLjc5bC0uMjgtLjI3QzE1LjQxIDEyLjU5IDE2IDExLjExIDE2IDkuNSAxNiA1LjkxIDEzLjA5IDMgOS41IDNTMyA1LjkxIDMgOS41IDUuOTEgMTYgOS41IDE2YzEuNjEgMCAzLjA5LS41OSA0LjIzLTEuNTdsLjI3LjI4di43OWw1IDQuOTlMMjAuNDkgMTlsLTQuOTktNXptLTYgMEM3LjAxIDE0IDUgMTEuOTkgNSA5LjVTNy4wMSA1IDkuNSA1IDE0IDcuMDEgMTQgOS41IDExLjk5IDE0IDkuNSAxNHpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgbWFyZ2luID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk05IDdIN3YyaDJWN3ptMCA0SDd2Mmgydi0yem0wLThjLTEuMTEgMC0yIC45LTIgMmgyVjN6bTQgMTJoLTJ2Mmgydi0yem02LTEydjJoMmMwLTEuMS0uOS0yLTItMnptLTYgMGgtMnYyaDJWM3pNOSAxN3YtMkg3YzAgMS4xLjg5IDIgMiAyem0xMC00aDJ2LTJoLTJ2MnptMC00aDJWN2gtMnYyem0wIDhjMS4xIDAgMi0uOSAyLTJoLTJ2MnpNNSA3SDN2MTJjMCAxLjEuODkgMiAyIDJoMTJ2LTJINVY3em0xMC0yaDJWM2gtMnYyem0wIDEyaDJ2LTJoLTJ2MnpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgcGFkZGluZyA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNMyAxM2gydi0ySDN2MnptMCA0aDJ2LTJIM3Yyem0yIDR2LTJIM2MwIDEuMS44OSAyIDIgMnpNMyA5aDJWN0gzdjJ6bTEyIDEyaDJ2LTJoLTJ2MnptNC0xOEg5Yy0xLjExIDAtMiAuOS0yIDJ2MTBjMCAxLjEuODkgMiAyIDJoMTBjMS4xIDAgMi0uOSAyLTJWNWMwLTEuMS0uOS0yLTItMnptMCAxMkg5VjVoMTB2MTB6bS04IDZoMnYtMmgtMnYyem0tNCAwaDJ2LTJIN3YyelwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBmb250ID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk05IDR2M2g1djEyaDNWN2g1VjRIOXptLTYgOGgzdjdoM3YtN2gzVjlIM3YzelwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCB0ZXh0ID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk0zIDE3LjI1VjIxaDMuNzVMMTcuODEgOS45NGwtMy43NS0zLjc1TDMgMTcuMjV6TTIwLjcxIDcuMDRjLjM5LS4zOS4zOS0xLjAyIDAtMS40MWwtMi4zNC0yLjM0Yy0uMzktLjM5LTEuMDItLjM5LTEuNDEgMGwtMS44MyAxLjgzIDMuNzUgMy43NSAxLjgzLTEuODN6XCIvPlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IGFsaWduID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgc3R5bGU9XCJ0cmFuc2Zvcm06cm90YXRlWig5MGRlZyk7XCI+XG4gICAgPHBhdGggZD1cIk0xMCAyMGg0VjRoLTR2MTZ6bS02IDBoNHYtOEg0djh6TTE2IDl2MTFoNFY5aC00elwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCByZXNpemUgPSBgXG4gIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICA8cGF0aCBkPVwiTTE5IDEyaC0ydjNoLTN2Mmg1di01ek03IDloM1Y3SDV2NWgyVjl6bTE0LTZIM2MtMS4xIDAtMiAuOS0yIDJ2MTRjMCAxLjEuOSAyIDIgMmgxOGMxLjEgMCAyLS45IDItMlY1YzAtMS4xLS45LTItMi0yem0wIDE2LjAxSDNWNC45OWgxOHYxNC4wMnpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgdHJhbnNmb3JtID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk0xMiw3QzYuNDgsNywyLDkuMjQsMiwxMmMwLDIuMjQsMi45NCw0LjEzLDcsNC43N1YyMGw0LTRsLTQtNHYyLjczYy0zLjE1LTAuNTYtNS0xLjktNS0yLjczYzAtMS4wNiwzLjA0LTMsOC0zczgsMS45NCw4LDNcbiAgICBjMCwwLjczLTEuNDYsMS44OS00LDIuNTN2Mi4wNWMzLjUzLTAuNzcsNi0yLjUzLDYtNC41OEMyMiw5LjI0LDE3LjUyLDcsMTIsN3pcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgYm9yZGVyID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk0xMyA3aC0ydjJoMlY3em0wIDRoLTJ2Mmgydi0yem00IDBoLTJ2Mmgydi0yek0zIDN2MThoMThWM0gzem0xNiAxNkg1VjVoMTR2MTR6bS02LTRoLTJ2Mmgydi0yem0tNC00SDd2Mmgydi0yelwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBodWVzaGlmdCA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNMTIgM2MtNC45NyAwLTkgNC4wMy05IDlzNC4wMyA5IDkgOWMuODMgMCAxLjUtLjY3IDEuNS0xLjUgMC0uMzktLjE1LS43NC0uMzktMS4wMS0uMjMtLjI2LS4zOC0uNjEtLjM4LS45OSAwLS44My42Ny0xLjUgMS41LTEuNUgxNmMyLjc2IDAgNS0yLjI0IDUtNSAwLTQuNDItNC4wMy04LTktOHptLTUuNSA5Yy0uODMgMC0xLjUtLjY3LTEuNS0xLjVTNS42NyA5IDYuNSA5IDggOS42NyA4IDEwLjUgNy4zMyAxMiA2LjUgMTJ6bTMtNEM4LjY3IDggOCA3LjMzIDggNi41UzguNjcgNSA5LjUgNXMxLjUuNjcgMS41IDEuNVMxMC4zMyA4IDkuNSA4em01IDBjLS44MyAwLTEuNS0uNjctMS41LTEuNVMxMy42NyA1IDE0LjUgNXMxLjUuNjcgMS41IDEuNVMxNS4zMyA4IDE0LjUgOHptMyA0Yy0uODMgMC0xLjUtLjY3LTEuNS0xLjVTMTYuNjcgOSAxNy41IDlzMS41LjY3IDEuNSAxLjUtLjY3IDEuNS0xLjUgMS41elwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBib3hzaGFkb3cgPSBgXG4gIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICA8cGF0aCBkPVwiTTIwIDguNjlWNGgtNC42OUwxMiAuNjkgOC42OSA0SDR2NC42OUwuNjkgMTIgNCAxNS4zMVYyMGg0LjY5TDEyIDIzLjMxIDE1LjMxIDIwSDIwdi00LjY5TDIzLjMxIDEyIDIwIDguNjl6TTEyIDE4Yy0uODkgMC0xLjc0LS4yLTIuNS0uNTVDMTEuNTYgMTYuNSAxMyAxNC40MiAxMyAxMnMtMS40NC00LjUtMy41LTUuNDVDMTAuMjYgNi4yIDExLjExIDYgMTIgNmMzLjMxIDAgNiAyLjY5IDYgNnMtMi42OSA2LTYgNnpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgaW5zcGVjdG9yID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPGc+XG4gICAgICA8cmVjdCB4PVwiMTFcIiB5PVwiN1wiIHdpZHRoPVwiMlwiIGhlaWdodD1cIjJcIi8+XG4gICAgICA8cmVjdCB4PVwiMTFcIiB5PVwiMTFcIiB3aWR0aD1cIjJcIiBoZWlnaHQ9XCI2XCIvPlxuICAgICAgPHBhdGggZD1cIk0xMiwyQzYuNDgsMiwyLDYuNDgsMiwxMmMwLDUuNTIsNC40OCwxMCwxMCwxMHMxMC00LjQ4LDEwLTEwQzIyLDYuNDgsMTcuNTIsMiwxMiwyeiBNMTIsMjBjLTQuNDEsMC04LTMuNTktOC04XG4gICAgICAgIGMwLTQuNDEsMy41OS04LDgtOHM4LDMuNTksOCw4QzIwLDE2LjQxLDE2LjQxLDIwLDEyLDIwelwiLz5cbiAgICA8L2c+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgY2FtZXJhID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCIzLjJcIi8+XG4gICAgPHBhdGggZD1cIk05IDJMNy4xNyA0SDRjLTEuMSAwLTIgLjktMiAydjEyYzAgMS4xLjkgMiAyIDJoMTZjMS4xIDAgMi0uOSAyLTJWNmMwLTEuMS0uOS0yLTItMmgtMy4xN0wxNSAySDl6bTMgMTVjLTIuNzYgMC01LTIuMjQtNS01czIuMjQtNSA1LTUgNSAyLjI0IDUgNS0yLjI0IDUtNSA1elwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBndWlkZXMgPSBgXG4gIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICA8cGF0aCBkPVwiTTIxLDZIM0MxLjksNiwxLDYuOSwxLDh2OGMwLDEuMSwwLjksMiwyLDJoMThjMS4xLDAsMi0wLjksMi0yVjhDMjMsNi45LDIyLjEsNiwyMSw2eiBNMjEsMTZIM1Y4aDJ2NGgyVjhoMnY0aDJWOGgydjRoMlY4XG4gICAgaDJ2NGgyVjhoMlYxNnpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgY29sb3JfdGV4dCA9IGBcbiAgPHN2ZyB2aWV3Qm94PVwiMCAwIDI1IDI3XCI+XG4gICAgPHBhdGggZD1cIk0xMSAzTDUuNSAxN2gyLjI1bDEuMTItM2g2LjI1bDEuMTIgM2gyLjI1TDEzIDNoLTJ6bS0xLjM4IDlMMTIgNS42NyAxNC4zOCAxMkg5LjYyelwiLz5cbiAgICA8cmVjdCBmaWxsPVwidmFyKC0tY29udGV4dHVhbF9jb2xvcilcIiB4PVwiMVwiIHk9XCIyMVwiIHdpZHRoPVwiMjNcIiBoZWlnaHQ9XCI1XCI+PC9yZWN0PlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IGNvbG9yX2JhY2tncm91bmQgPSBgXG4gIDxzdmcgdmlld0JveD1cIjAgMCAyNSAyN1wiPlxuICAgIDxwYXRoIGQ9XCJNMTYuNTYgOC45NEw3LjYyIDAgNi4yMSAxLjQxbDIuMzggMi4zOC01LjE1IDUuMTVjLS41OS41OS0uNTkgMS41NCAwIDIuMTJsNS41IDUuNWMuMjkuMjkuNjguNDQgMS4wNi40NHMuNzctLjE1IDEuMDYtLjQ0bDUuNS01LjVjLjU5LS41OC41OS0xLjUzIDAtMi4xMnpNNS4yMSAxMEwxMCA1LjIxIDE0Ljc5IDEwSDUuMjF6TTE5IDExLjVzLTIgMi4xNy0yIDMuNWMwIDEuMS45IDIgMiAyczItLjkgMi0yYzAtMS4zMy0yLTMuNS0yLTMuNXpcIi8+XG4gICAgPHJlY3QgZmlsbD1cInZhcigtLWNvbnRleHR1YWxfY29sb3IpXCIgeD1cIjFcIiB5PVwiMjFcIiB3aWR0aD1cIjIzXCIgaGVpZ2h0PVwiNVwiPjwvcmVjdD5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBjb2xvcl9ib3JkZXIgPSBgXG4gIDxzdmcgdmlld0JveD1cIjAgMCAyNSAyN1wiPlxuICAgIDxwYXRoIGQ9XCJNMTcuNzUgN0wxNCAzLjI1bC0xMCAxMFYxN2gzLjc1bDEwLTEwem0yLjk2LTIuOTZjLjM5LS4zOS4zOS0xLjAyIDAtMS40MUwxOC4zNy4yOWMtLjM5LS4zOS0xLjAyLS4zOS0xLjQxIDBMMTUgMi4yNSAxOC43NSA2bDEuOTYtMS45NnpcIi8+XG4gICAgPHJlY3QgZmlsbD1cInZhcigtLWNvbnRleHR1YWxfY29sb3IpXCIgeD1cIjFcIiB5PVwiMjFcIiB3aWR0aD1cIjIzXCIgaGVpZ2h0PVwiNVwiPjwvcmVjdD5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBwb3NpdGlvbiA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNMTUuNTQgNS41NEwxMy43NyA3LjMgMTIgNS41NCAxMC4yMyA3LjMgOC40NiA1LjU0IDEyIDJ6bTIuOTIgMTBsLTEuNzYtMS43N0wxOC40NiAxMmwtMS43Ni0xLjc3IDEuNzYtMS43N0wyMiAxMnptLTEwIDIuOTJsMS43Ny0xLjc2TDEyIDE4LjQ2bDEuNzctMS43NiAxLjc3IDEuNzZMMTIgMjJ6bS0yLjkyLTEwbDEuNzYgMS43N0w1LjU0IDEybDEuNzYgMS43Ny0xLjc2IDEuNzdMMiAxMnpcIi8+XG4gICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCIzXCIvPlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IGFjY2Vzc2liaWxpdHkgPSBgXG4gIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICA8cGF0aCBkPVwiTTEyLDJjMS4xLDAsMiwwLjksMiwycy0wLjksMi0yLDJzLTItMC45LTItMlMxMC45LDIsMTIsMnogTTIxLDloLTZ2MTNoLTJ2LTZoLTJ2Nkg5VjlIM1Y3aDE4Vjl6XCIvPlxuICA8L3N2Zz5cbmAiLCJpbXBvcnQgJCAgICAgICAgICAgIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzICAgICAgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCBzdHlsZXMgICAgICAgZnJvbSAnLi9iYXNlLmVsZW1lbnQuY3NzJ1xuaW1wb3J0ICogYXMgSWNvbnMgICBmcm9tICcuLi92aXMtYnVnL3Zpcy1idWcuaWNvbnMnXG5pbXBvcnQgeyBtZXRhS2V5LCBhbHRLZXkgfSAgZnJvbSAnLi4vLi4vdXRpbGl0aWVzLydcblxuZXhwb3J0IGNsYXNzIEhvdGtleU1hcCBleHRlbmRzIEhUTUxFbGVtZW50IHtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLmtleWJvYXJkX21vZGVsID0ge1xuICAgICAgbnVtOiAgICBbJ2AnLCcxJywnMicsJzMnLCc0JywnNScsJzYnLCc3JywnOCcsJzknLCcwJywnLScsJz0nLCdkZWxldGUnXSxcbiAgICAgIHRhYjogICAgWyd0YWInLCdxJywndycsJ2UnLCdyJywndCcsJ3knLCd1JywnaScsJ28nLCdwJywnWycsJ10nLCdcXFxcJ10sXG4gICAgICBjYXBzOiAgIFsnY2FwcycsJ2EnLCdzJywnZCcsJ2YnLCdnJywnaCcsJ2onLCdrJywnbCcsJ1xcJycsJ3JldHVybiddLFxuICAgICAgc2hpZnQ6ICBbJ3NoaWZ0JywneicsJ3gnLCdjJywndicsJ2InLCduJywnbScsJywnLCcuJywnLycsJ3NoaWZ0J10sXG4gICAgICBzcGFjZTogIFsnY3RybCcsYWx0S2V5LCdjbWQnLCdzcGFjZWJhcicsJ2NtZCcsYWx0S2V5LCdjdHJsJ11cbiAgICB9XG5cbiAgICB0aGlzLmtleV9zaXplX21vZGVsID0ge1xuICAgICAgbnVtOiAgICB7MTI6Mn0sXG4gICAgICB0YWI6ICAgIHswOjJ9LFxuICAgICAgY2FwczogICB7MDozLDExOjN9LFxuICAgICAgc2hpZnQ6ICB7MDo2LDExOjZ9LFxuICAgICAgc3BhY2U6ICB7MzoxMH0sXG4gICAgfVxuXG4gICAgdGhpcy4kc2hhZG93ICAgID0gdGhpcy5hdHRhY2hTaGFkb3coe21vZGU6ICdjbG9zZWQnfSlcblxuICAgIHRoaXMuX2hvdGtleSAgICA9ICcnXG4gICAgdGhpcy5fdXNlZGtleXMgID0gW11cblxuICAgIHRoaXMudG9vbCAgICAgICA9ICdob3RrZXltYXAnXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICB0aGlzLiRzaGlmdCAgPSAkKCdba2V5Ym9hcmRdID4gc2VjdGlvbiA+IFtzaGlmdF0nLCB0aGlzLiRzaGFkb3cpXG4gICAgdGhpcy4kY3RybCAgID0gJCgnW2tleWJvYXJkXSA+IHNlY3Rpb24gPiBbY3RybF0nLCB0aGlzLiRzaGFkb3cpXG4gICAgdGhpcy4kYWx0ICAgID0gJChgW2tleWJvYXJkXSA+IHNlY3Rpb24gPiBbJHthbHRLZXl9XWAsIHRoaXMuJHNoYWRvdylcbiAgICB0aGlzLiRjbWQgICAgPSAkKGBba2V5Ym9hcmRdID4gc2VjdGlvbiA+IFske21ldGFLZXl9XWAsIHRoaXMuJHNoYWRvdylcbiAgICB0aGlzLiR1cCAgICAgPSAkKCdbYXJyb3dzXSBbdXBdJywgdGhpcy4kc2hhZG93KVxuICAgIHRoaXMuJGRvd24gICA9ICQoJ1thcnJvd3NdIFtkb3duXScsIHRoaXMuJHNoYWRvdylcbiAgICB0aGlzLiRsZWZ0ICAgPSAkKCdbYXJyb3dzXSBbbGVmdF0nLCB0aGlzLiRzaGFkb3cpXG4gICAgdGhpcy4kcmlnaHQgID0gJCgnW2Fycm93c10gW3JpZ2h0XScsIHRoaXMuJHNoYWRvdylcbiAgfVxuXG4gIGRpc2Nvbm5lY3RlZENhbGxiYWNrKCkge31cblxuICBzZXQgdG9vbCh0b29sKSB7XG4gICAgdGhpcy5fdG9vbCA9IHRvb2xcbiAgICB0aGlzLiRzaGFkb3cuaW5uZXJIVE1MID0gdGhpcy5yZW5kZXIoKVxuICB9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gICAgaG90a2V5cygnKicsIChlLCBoYW5kbGVyKSA9PlxuICAgICAgdGhpcy53YXRjaEtleXMoZSwgaGFuZGxlcikpXG4gIH1cblxuICBoaWRlKCkge1xuICAgIHRoaXMuJHNoYWRvdy5ob3N0LnN0eWxlLmRpc3BsYXkgPSAnbm9uZSdcbiAgICBob3RrZXlzLnVuYmluZCgnKicpXG4gIH1cblxuICB3YXRjaEtleXMoZSwgaGFuZGxlcikge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKClcblxuICAgIHRoaXMuJHNoaWZ0LmF0dHIoJ3ByZXNzZWQnLCBob3RrZXlzLnNoaWZ0KVxuICAgIHRoaXMuJGN0cmwuYXR0cigncHJlc3NlZCcsIGhvdGtleXMuY3RybClcbiAgICB0aGlzLiRhbHQuYXR0cigncHJlc3NlZCcsIGhvdGtleXMuYWx0KVxuICAgIHRoaXMuJGNtZC5hdHRyKCdwcmVzc2VkJywgaG90a2V5c1ttZXRhS2V5XSlcbiAgICB0aGlzLiR1cC5hdHRyKCdwcmVzc2VkJywgZS5jb2RlID09PSAnQXJyb3dVcCcpXG4gICAgdGhpcy4kZG93bi5hdHRyKCdwcmVzc2VkJywgZS5jb2RlID09PSAnQXJyb3dEb3duJylcbiAgICB0aGlzLiRsZWZ0LmF0dHIoJ3ByZXNzZWQnLCBlLmNvZGUgPT09ICdBcnJvd0xlZnQnKVxuICAgIHRoaXMuJHJpZ2h0LmF0dHIoJ3ByZXNzZWQnLCBlLmNvZGUgPT09ICdBcnJvd1JpZ2h0JylcblxuICAgIGNvbnN0IHsgbmVnYXRpdmUsIG5lZ2F0aXZlX21vZGlmaWVyLCBzaWRlLCBhbW91bnQgfSA9IHRoaXMuY3JlYXRlQ29tbWFuZCh7ZSwgaG90a2V5c30pXG5cbiAgICAkKCdbY29tbWFuZF0nLCB0aGlzLiRzaGFkb3cpWzBdLmlubmVySFRNTCA9IHRoaXMuZGlzcGxheUNvbW1hbmQoe1xuICAgICAgbmVnYXRpdmUsIG5lZ2F0aXZlX21vZGlmaWVyLCBzaWRlLCBhbW91bnQsXG4gICAgfSlcbiAgfVxuXG4gIGNyZWF0ZUNvbW1hbmQoe2U6e2NvZGV9LCBob3RrZXlzfSkge1xuICAgIGxldCBhbW91bnQgICAgICAgICAgICAgID0gaG90a2V5cy5zaGlmdCA/IDEwIDogMVxuICAgIGxldCBuZWdhdGl2ZSAgICAgICAgICAgID0gaG90a2V5cy5hbHQgPyAnU3VidHJhY3QnIDogJ0FkZCdcbiAgICBsZXQgbmVnYXRpdmVfbW9kaWZpZXIgICA9IGhvdGtleXMuYWx0ID8gJ2Zyb20nIDogJ3RvJ1xuXG4gICAgbGV0IHNpZGUgPSAnW2Fycm93IGtleV0nXG4gICAgaWYgKGNvZGUgPT09ICdBcnJvd1VwJykgICAgIHNpZGUgPSAndGhlIHRvcCBzaWRlJ1xuICAgIGlmIChjb2RlID09PSAnQXJyb3dEb3duJykgICBzaWRlID0gJ3RoZSBib3R0b20gc2lkZSdcbiAgICBpZiAoY29kZSA9PT0gJ0Fycm93TGVmdCcpICAgc2lkZSA9ICd0aGUgbGVmdCBzaWRlJ1xuICAgIGlmIChjb2RlID09PSAnQXJyb3dSaWdodCcpICBzaWRlID0gJ3RoZSByaWdodCBzaWRlJ1xuICAgIGlmIChob3RrZXlzW21ldGFLZXldKSAgICAgICAgICAgIHNpZGUgPSAnYWxsIHNpZGVzJ1xuXG4gICAgaWYgKGhvdGtleXNbbWV0YUtleV0gJiYgY29kZSA9PT0gJ0Fycm93RG93bicpIHtcbiAgICAgIG5lZ2F0aXZlICAgICAgICAgICAgPSAnU3VidHJhY3QnXG4gICAgICBuZWdhdGl2ZV9tb2RpZmllciAgID0gJ2Zyb20nXG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG5lZ2F0aXZlLCBuZWdhdGl2ZV9tb2RpZmllciwgYW1vdW50LCBzaWRlLFxuICAgIH1cbiAgfVxuXG4gIGRpc3BsYXlDb21tYW5kKHtuZWdhdGl2ZSwgbmVnYXRpdmVfbW9kaWZpZXIsIHNpZGUsIGFtb3VudH0pIHtcbiAgICByZXR1cm4gYFxuICAgICAgPHNwYW4gbmVnYXRpdmU+JHtuZWdhdGl2ZX0gPC9zcGFuPlxuICAgICAgPHNwYW4gdG9vbD4ke3RoaXMuX3Rvb2x9PC9zcGFuPlxuICAgICAgPHNwYW4gbGlnaHQ+ICR7bmVnYXRpdmVfbW9kaWZpZXJ9IDwvc3Bhbj5cbiAgICAgIDxzcGFuIHNpZGU+JHtzaWRlfTwvc3Bhbj5cbiAgICAgIDxzcGFuIGxpZ2h0PiBieSA8L3NwYW4+XG4gICAgICA8c3BhbiBhbW91bnQ+JHthbW91bnR9PC9zcGFuPlxuICAgIGBcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcygpfVxuICAgICAgPGFydGljbGU+XG4gICAgICAgIDxkaXYgdG9vbC1pY29uPlxuICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgJHtJY29uc1t0aGlzLl90b29sXX1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICAke3RoaXMuZGlzcGxheUNvbW1hbmQoe1xuICAgICAgICAgICAgbmVnYXRpdmU6IGDCsVske2FsdEtleX1dIGAsXG4gICAgICAgICAgICBuZWdhdGl2ZV9tb2RpZmllcjogJyB0byAnLFxuICAgICAgICAgICAgdG9vbDogdGhpcy5fdG9vbCxcbiAgICAgICAgICAgIHNpZGU6ICdbYXJyb3cga2V5XScsXG4gICAgICAgICAgICBhbW91bnQ6IDFcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2FyZD5cbiAgICAgICAgICA8ZGl2IGtleWJvYXJkPlxuICAgICAgICAgICAgJHtPYmplY3QuZW50cmllcyh0aGlzLmtleWJvYXJkX21vZGVsKS5yZWR1Y2UoKGtleWJvYXJkLCBbcm93X25hbWUsIHJvd10pID0+IGBcbiAgICAgICAgICAgICAgJHtrZXlib2FyZH1cbiAgICAgICAgICAgICAgPHNlY3Rpb24gJHtyb3dfbmFtZX0+JHtyb3cucmVkdWNlKChyb3csIGtleSwgaSkgPT4gYFxuICAgICAgICAgICAgICAgICR7cm93fVxuICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAke2tleX1cbiAgICAgICAgICAgICAgICAgICR7dGhpcy5faG90a2V5ID09IGtleSA/ICdob3RrZXkgdGl0bGU9XCJUb29sIFNob3J0Y3V0IEhvdGtleVwiJyA6ICcnfVxuICAgICAgICAgICAgICAgICAgJHt0aGlzLl91c2Vka2V5cy5pbmNsdWRlcyhrZXkpID8gJ3VzZWQnIDogJyd9XG4gICAgICAgICAgICAgICAgICBzdHlsZT1cImZsZXg6JHt0aGlzLmtleV9zaXplX21vZGVsW3Jvd19uYW1lXVtpXSB8fCAxfTtcIlxuICAgICAgICAgICAgICAgID4ke2tleX08L3NwYW4+XG4gICAgICAgICAgICAgIGAsICcnKX1cbiAgICAgICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgICAgYCwgJycpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c2VjdGlvbiBhcnJvd3M+XG4gICAgICAgICAgICAgIDxzcGFuIHVwIHVzZWQ+4oaRPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBkb3duIHVzZWQ+4oaTPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBsZWZ0IHVzZWQ+4oaQPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiByaWdodCB1c2VkPuKGkjwvc3Bhbj5cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2FydGljbGU+XG4gICAgYFxuICB9XG5cbiAgc3R5bGVzKCkge1xuICAgIHJldHVybiBgXG4gICAgICA8c3R5bGU+XG4gICAgICAgICR7c3R5bGVzfVxuICAgICAgPC9zdHlsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXktbWFwJywgSG90a2V5TWFwKVxuIiwiaW1wb3J0IHsgSG90a2V5TWFwIH0gZnJvbSAnLi9iYXNlLmVsZW1lbnQnXG5pbXBvcnQgeyBndWlkZXMgYXMgaWNvbiB9IGZyb20gJy4uL3Zpcy1idWcvdmlzLWJ1Zy5pY29ucydcblxuZXhwb3J0IGNsYXNzIEd1aWRlc0hvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICAgPSAnZydcbiAgICB0aGlzLl91c2Vka2V5cyAgPSBbXVxuICAgIHRoaXMudG9vbCAgICAgICA9ICdndWlkZXMnXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxhcnRpY2xlPlxuICAgICAgICA8ZGl2IHRvb2wtaWNvbj5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICR7aWNvbn1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICBjb21pbmcgc29vblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLWd1aWRlcycsIEd1aWRlc0hvdGtleXMpXG4iLCJpbXBvcnQgeyBIb3RrZXlNYXAgfSBmcm9tICcuL2Jhc2UuZWxlbWVudCdcbmltcG9ydCB7IGluc3BlY3RvciBhcyBpY29uIH0gZnJvbSAnLi4vdmlzLWJ1Zy92aXMtYnVnLmljb25zJ1xuaW1wb3J0IHsgYWx0S2V5IH0gZnJvbSAnLi4vLi4vdXRpbGl0aWVzJztcblxuZXhwb3J0IGNsYXNzIEluc3BlY3RvckhvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICAgPSAnaSdcbiAgICB0aGlzLl91c2Vka2V5cyAgPSBbYWx0S2V5XVxuICAgIHRoaXMudG9vbCAgICAgICA9ICdpbnNwZWN0b3InXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxhcnRpY2xlPlxuICAgICAgICA8ZGl2IHRvb2wtaWNvbj5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICR7aWNvbn1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICBjb21pbmcgc29vblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLWluc3BlY3RvcicsIEluc3BlY3RvckhvdGtleXMpXG4iLCJpbXBvcnQgeyBIb3RrZXlNYXAgfSBmcm9tICcuL2Jhc2UuZWxlbWVudCdcbmltcG9ydCB7IGFjY2Vzc2liaWxpdHkgYXMgaWNvbiB9IGZyb20gJy4uL3Zpcy1idWcvdmlzLWJ1Zy5pY29ucydcbmltcG9ydCB7IGFsdEtleSB9IGZyb20gJy4uLy4uL3V0aWxpdGllcyc7XG5cbmV4cG9ydCBjbGFzcyBBY2Nlc3NpYmlsaXR5SG90a2V5cyBleHRlbmRzIEhvdGtleU1hcCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMuX2hvdGtleSAgICA9ICdwJ1xuICAgIHRoaXMuX3VzZWRrZXlzICA9IFthbHRLZXldXG4gICAgdGhpcy50b29sICAgICAgID0gJ2FjY2Vzc2liaWxpdHknXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxhcnRpY2xlPlxuICAgICAgICA8ZGl2IHRvb2wtaWNvbj5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICR7aWNvbn1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICBjb21pbmcgc29vblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLWFjY2Vzc2liaWxpdHknLCBBY2Nlc3NpYmlsaXR5SG90a2V5cylcbiIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuXG5leHBvcnQgY2xhc3MgTW92ZUhvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgID0gJ3YnXG4gICAgdGhpcy50b29sICAgICA9ICdtb3ZlJ1xuICB9XG5cbiAgY3JlYXRlQ29tbWFuZCh7ZTp7Y29kZX0sIGhvdGtleXN9KSB7XG4gICAgbGV0IGFtb3VudCwgbmVnYXRpdmUsIG5lZ2F0aXZlX21vZGlmaWVyXG5cbiAgICBsZXQgc2lkZSA9ICdbYXJyb3cga2V5XSdcbiAgICBpZiAoY29kZSA9PT0gJ0Fycm93VXAnKSAgICAgc2lkZSA9ICd1cCAmIG91dCBvZiBkaXYnXG4gICAgaWYgKGNvZGUgPT09ICdBcnJvd0Rvd24nKSAgIHNpZGUgPSAnZG93biAmIGludG8gbmV4dCBzaWJsaW5nIC8gb3V0ICYgdW5kZXIgZGl2J1xuICAgIGlmIChjb2RlID09PSAnQXJyb3dMZWZ0JykgICBzaWRlID0gJ3Rvd2FyZHMgdGhlIGZyb250L3RvcCBvZiB0aGUgc3RhY2snXG4gICAgaWYgKGNvZGUgPT09ICdBcnJvd1JpZ2h0JykgIHNpZGUgPSAndG93YXJkcyB0aGUgYmFjay9ib3R0b20gb2YgdGhlIHN0YWNrJ1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIG5lZ2F0aXZlLCBuZWdhdGl2ZV9tb2RpZmllciwgYW1vdW50LCBzaWRlLFxuICAgIH1cbiAgfVxuXG4gIGRpc3BsYXlDb21tYW5kKHtzaWRlfSkge1xuICAgIHJldHVybiBgXG4gICAgICA8c3BhbiB0b29sPiR7dGhpcy5fdG9vbH08L3NwYW4+XG4gICAgICA8c3BhbiBzaWRlPiR7c2lkZX08L3NwYW4+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1tb3ZlJywgTW92ZUhvdGtleXMpIiwiaW1wb3J0IHsgSG90a2V5TWFwIH0gZnJvbSAnLi9iYXNlLmVsZW1lbnQnXG5pbXBvcnQgeyBtZXRhS2V5LCBhbHRLZXkgfSAgIGZyb20gJy4uLy4uL3V0aWxpdGllcy8nXG5cbmV4cG9ydCBjbGFzcyBNYXJnaW5Ib3RrZXlzIGV4dGVuZHMgSG90a2V5TWFwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5faG90a2V5ICAgID0gJ20nXG4gICAgdGhpcy5fdXNlZGtleXMgID0gWydzaGlmdCcsbWV0YUtleSxhbHRLZXldXG5cbiAgICB0aGlzLnRvb2wgICAgICAgPSAnbWFyZ2luJ1xuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1tYXJnaW4nLCBNYXJnaW5Ib3RrZXlzKVxuIiwiaW1wb3J0IHsgSG90a2V5TWFwIH0gZnJvbSAnLi9iYXNlLmVsZW1lbnQnXG5pbXBvcnQgeyBtZXRhS2V5LCBhbHRLZXkgfSAgIGZyb20gJy4uLy4uL3V0aWxpdGllcy8nXG5cbmV4cG9ydCBjbGFzcyBQYWRkaW5nSG90a2V5cyBleHRlbmRzIEhvdGtleU1hcCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMuX2hvdGtleSAgICA9ICdwJ1xuICAgIHRoaXMuX3VzZWRrZXlzICA9IFsnc2hpZnQnLG1ldGFLZXksYWx0S2V5XVxuXG4gICAgdGhpcy50b29sICAgICAgID0gJ3BhZGRpbmcnXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLXBhZGRpbmcnLCBQYWRkaW5nSG90a2V5cylcbiIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuaW1wb3J0IHsgbWV0YUtleSB9IGZyb20gJy4uLy4uL3V0aWxpdGllcyc7XG5cbmNvbnN0IGhfYWxpZ25PcHRpb25zICA9IFsnbGVmdCcsJ2NlbnRlcicsJ3JpZ2h0J11cbmNvbnN0IHZfYWxpZ25PcHRpb25zICA9IFsndG9wJywnY2VudGVyJywnYm90dG9tJ11cbmNvbnN0IGRpc3RPcHRpb25zICAgICA9IFsnZXZlbmx5Jywnbm9ybWFsJywnYmV0d2VlbiddXG5cbmV4cG9ydCBjbGFzcyBBbGlnbkhvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICA9ICdhJ1xuICAgIHRoaXMuX3VzZWRrZXlzID0gW21ldGFLZXksJ3NoaWZ0J11cblxuICAgIHRoaXMuX2h0b29sICAgPSAwXG4gICAgdGhpcy5fdnRvb2wgICA9IDBcbiAgICB0aGlzLl9kdG9vbCAgID0gMVxuXG4gICAgdGhpcy5fc2lkZSAgICAgICAgID0gJ3RvcCBsZWZ0J1xuICAgIHRoaXMuX2RpcmVjdGlvbiAgICA9ICdyb3cnXG4gICAgdGhpcy5fZGlzdHJpYnV0aW9uID0gZGlzdE9wdGlvbnNbdGhpcy5fZHRvb2xdXG5cbiAgICB0aGlzLnRvb2wgICAgID0gJ2FsaWduJ1xuICB9XG5cbiAgY3JlYXRlQ29tbWFuZCh7ZTp7Y29kZX0sIGhvdGtleXN9KSB7XG4gICAgbGV0IGFtb3VudCAgICAgICAgICAgID0gdGhpcy5fZGlzdHJpYnV0aW9uXG4gICAgICAsIG5lZ2F0aXZlX21vZGlmaWVyID0gdGhpcy5fZGlyZWN0aW9uXG4gICAgICAsIHNpZGUgICAgICAgICAgICAgID0gdGhpcy5fc2lkZVxuICAgICAgLCBuZWdhdGl2ZVxuXG4gICAgaWYgKGhvdGtleXMuY21kICYmIChjb2RlID09PSAnQXJyb3dSaWdodCcgfHwgY29kZSA9PT0gJ0Fycm93RG93bicpKSB7XG4gICAgICBuZWdhdGl2ZV9tb2RpZmllciA9IGNvZGUgPT09ICdBcnJvd0Rvd24nXG4gICAgICAgID8gJ2NvbHVtbidcbiAgICAgICAgOiAncm93J1xuICAgICAgdGhpcy5fZGlyZWN0aW9uID0gbmVnYXRpdmVfbW9kaWZpZXJcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93VXAnKSAgICAgICAgICAgc2lkZSA9IHRoaXMuY2xhbXAodl9hbGlnbk9wdGlvbnMsICdfdnRvb2wnKVxuICAgICAgZWxzZSBpZiAoY29kZSA9PT0gJ0Fycm93RG93bicpICAgIHNpZGUgPSB0aGlzLmNsYW1wKHZfYWxpZ25PcHRpb25zLCAnX3Z0b29sJywgdHJ1ZSlcbiAgICAgIGVsc2UgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaWRlID0gdl9hbGlnbk9wdGlvbnNbdGhpcy5fdnRvb2xdXG5cbiAgICAgIGlmIChjb2RlID09PSAnQXJyb3dMZWZ0JykgICAgICAgICBzaWRlICs9ICcgJyArIHRoaXMuY2xhbXAoaF9hbGlnbk9wdGlvbnMsICdfaHRvb2wnKVxuICAgICAgZWxzZSBpZiAoY29kZSA9PT0gJ0Fycm93UmlnaHQnKSAgIHNpZGUgKz0gJyAnICsgdGhpcy5jbGFtcChoX2FsaWduT3B0aW9ucywgJ19odG9vbCcsIHRydWUpXG4gICAgICBlbHNlICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2lkZSArPSAnICcgKyBoX2FsaWduT3B0aW9uc1t0aGlzLl9odG9vbF1cblxuICAgICAgdGhpcy5fc2lkZSA9IHNpZGVcblxuICAgICAgaWYgKGhvdGtleXMuc2hpZnQgJiYgKGNvZGUgPT09ICdBcnJvd1JpZ2h0JyB8fCBjb2RlID09PSAnQXJyb3dMZWZ0JykpIHtcbiAgICAgICAgYW1vdW50ID0gdGhpcy5jbGFtcChkaXN0T3B0aW9ucywgJ19kdG9vbCcsIGNvZGUgPT09ICdBcnJvd1JpZ2h0JylcbiAgICAgICAgdGhpcy5fZGlzdHJpYnV0aW9uID0gYW1vdW50XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG5lZ2F0aXZlLCBuZWdhdGl2ZV9tb2RpZmllciwgYW1vdW50LCBzaWRlLFxuICAgIH1cbiAgfVxuXG4gIGRpc3BsYXlDb21tYW5kKHtzaWRlLCBhbW91bnQsIG5lZ2F0aXZlX21vZGlmaWVyfSkge1xuICAgIGlmIChhbW91bnQgPT0gMSkgYW1vdW50ID0gdGhpcy5fZGlzdHJpYnV0aW9uXG4gICAgaWYgKG5lZ2F0aXZlX21vZGlmaWVyID09ICcgdG8gJykgbmVnYXRpdmVfbW9kaWZpZXIgPSB0aGlzLl9kaXJlY3Rpb25cblxuICAgIHJldHVybiBgXG4gICAgICA8c3BhbiB0b29sPiR7dGhpcy5fdG9vbH08L3NwYW4+XG4gICAgICA8c3BhbiBsaWdodD4gYXMgPC9zcGFuPlxuICAgICAgPHNwYW4+JHtuZWdhdGl2ZV9tb2RpZmllcn06PC9zcGFuPlxuICAgICAgPHNwYW4gc2lkZT4ke3NpZGV9PC9zcGFuPlxuICAgICAgPHNwYW4gbGlnaHQ+IGRpc3RyaWJ1dGVkIDwvc3Bhbj5cbiAgICAgIDxzcGFuIGFtb3VudD4ke2Ftb3VudH08L3NwYW4+XG4gICAgYFxuICB9XG5cbiAgY2xhbXAocmFuZ2UsIHRvb2wsIGluY3JlbWVudCA9IGZhbHNlKSB7XG4gICAgaWYgKGluY3JlbWVudCkge1xuICAgICAgaWYgKHRoaXNbdG9vbF0gPCByYW5nZS5sZW5ndGggLSAxKVxuICAgICAgICB0aGlzW3Rvb2xdID0gdGhpc1t0b29sXSArIDFcbiAgICB9XG4gICAgZWxzZSBpZiAodGhpc1t0b29sXSA+IDApXG4gICAgICB0aGlzW3Rvb2xdID0gdGhpc1t0b29sXSAtIDFcblxuICAgIHJldHVybiByYW5nZVt0aGlzW3Rvb2xdXVxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1hbGlnbicsIEFsaWduSG90a2V5cylcbiIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuaW1wb3J0IHsgaHVlc2hpZnQgYXMgaWNvbiB9IGZyb20gJy4uL3Zpcy1idWcvdmlzLWJ1Zy5pY29ucydcbmltcG9ydCB7IG1ldGFLZXksIGFsdEtleSB9IGZyb20gJy4uLy4uL3V0aWxpdGllcyc7XG5cbmV4cG9ydCBjbGFzcyBIdWVzaGlmdEhvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICAgPSAnaCdcbiAgICB0aGlzLl91c2Vka2V5cyAgPSBbJ3NoaWZ0JyxtZXRhS2V5XVxuICAgIHRoaXMudG9vbCAgICAgICA9ICdodWVzaGlmdCdcbiAgfVxuXG4gIGNyZWF0ZUNvbW1hbmQoe2U6e2NvZGV9LCBob3RrZXlzfSkge1xuICAgIGxldCBhbW91bnQgICAgICAgICAgICAgID0gaG90a2V5cy5zaGlmdCA/IDEwIDogMVxuICAgIGxldCBuZWdhdGl2ZSAgICAgICAgICAgID0gJ1tpbmNyZWFzZS9kZWNyZWFzZV0nXG4gICAgbGV0IG5lZ2F0aXZlX21vZGlmaWVyICAgPSAnYnknXG4gICAgbGV0IHNpZGUgICAgICAgICAgICAgICAgPSAnW2Fycm93IGtleV0nXG5cbiAgICAvLyBzYXR1cmF0aW9uXG4gICAgaWYgKGhvdGtleXMuY21kKSB7XG4gICAgICBzaWRlID0naHVlJ1xuXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93RG93bicpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdkZWNyZWFzZSdcbiAgICAgIGlmIChjb2RlID09PSAnQXJyb3dVcCcpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdpbmNyZWFzZSdcbiAgICB9XG4gICAgZWxzZSBpZiAoY29kZSA9PT0gJ0Fycm93TGVmdCcgfHwgY29kZSA9PT0gJ0Fycm93UmlnaHQnKSB7XG4gICAgICBzaWRlID0gJ3NhdHVyYXRpb24nXG5cbiAgICAgIGlmIChjb2RlID09PSAnQXJyb3dMZWZ0JylcbiAgICAgICAgbmVnYXRpdmUgID0gJ2RlY3JlYXNlJ1xuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd1JpZ2h0JylcbiAgICAgICAgbmVnYXRpdmUgID0gJ2luY3JlYXNlJ1xuICAgIH1cbiAgICAvLyBsaWdodG5lc3NcbiAgICBlbHNlIGlmIChjb2RlID09PSAnQXJyb3dVcCcgfHwgY29kZSA9PT0gJ0Fycm93RG93bicpIHtcbiAgICAgIHNpZGUgPSAnbGlnaHRuZXNzJ1xuXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93RG93bicpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdkZWNyZWFzZSdcbiAgICAgIGlmIChjb2RlID09PSAnQXJyb3dVcCcpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdpbmNyZWFzZSdcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgbmVnYXRpdmUsIG5lZ2F0aXZlX21vZGlmaWVyLCBhbW91bnQsIHNpZGUsXG4gICAgfVxuICB9XG5cbiAgZGlzcGxheUNvbW1hbmQoe25lZ2F0aXZlLCBuZWdhdGl2ZV9tb2RpZmllciwgc2lkZSwgYW1vdW50fSkge1xuICAgIGlmIChuZWdhdGl2ZSA9PT0gYMKxWyR7YWx0S2V5fV0gYClcbiAgICAgIG5lZ2F0aXZlID0gJ1tpbmNyZWFzZS9kZWNyZWFzZV0nXG4gICAgaWYgKG5lZ2F0aXZlX21vZGlmaWVyID09PSAnIHRvICcpXG4gICAgICBuZWdhdGl2ZV9tb2RpZmllciA9ICcgYnkgJ1xuXG4gICAgcmV0dXJuIGBcbiAgICAgIDxzcGFuIG5lZ2F0aXZlPiR7bmVnYXRpdmV9PC9zcGFuPlxuICAgICAgPHNwYW4gc2lkZSB0b29sPiR7c2lkZX08L3NwYW4+XG4gICAgICA8c3BhbiBsaWdodD4ke25lZ2F0aXZlX21vZGlmaWVyfTwvc3Bhbj5cbiAgICAgIDxzcGFuIGFtb3VudD4ke2Ftb3VudH08L3NwYW4+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1odWVzaGlmdCcsIEh1ZXNoaWZ0SG90a2V5cylcbiIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuaW1wb3J0IHsgYm94c2hhZG93IGFzIGljb24gfSBmcm9tICcuLi92aXMtYnVnL3Zpcy1idWcuaWNvbnMnXG5pbXBvcnQgeyBtZXRhS2V5IH0gZnJvbSAnLi4vLi4vdXRpbGl0aWVzJztcblxuZXhwb3J0IGNsYXNzIEJveHNoYWRvd0hvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICAgPSAnZCdcbiAgICB0aGlzLl91c2Vka2V5cyAgPSBbJ3NoaWZ0JyxtZXRhS2V5XVxuICAgIHRoaXMudG9vbCAgICAgICA9ICdib3hzaGFkb3cnXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxhcnRpY2xlPlxuICAgICAgICA8ZGl2IHRvb2wtaWNvbj5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICR7aWNvbn1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICBjb21pbmcgc29vblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLWJveHNoYWRvdycsIEJveHNoYWRvd0hvdGtleXMpXG4iLCJpbXBvcnQgeyBIb3RrZXlNYXAgfSBmcm9tICcuL2Jhc2UuZWxlbWVudCdcbmltcG9ydCB7IHBvc2l0aW9uIGFzIGljb24gfSBmcm9tICcuLi92aXMtYnVnL3Zpcy1idWcuaWNvbnMnXG5pbXBvcnQgeyBhbHRLZXkgfSBmcm9tICcuLi8uLi91dGlsaXRpZXMnO1xuXG5leHBvcnQgY2xhc3MgUG9zaXRpb25Ib3RrZXlzIGV4dGVuZHMgSG90a2V5TWFwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5faG90a2V5ICAgID0gJ2wnXG4gICAgdGhpcy5fdXNlZGtleXMgID0gWydzaGlmdCcsYWx0S2V5XVxuICAgIHRoaXMudG9vbCAgICAgICA9ICdwb3NpdGlvbidcbiAgfVxuXG4gIGNvbm5lY3RlZENhbGxiYWNrKCkge31cblxuICBzaG93KCkge1xuICAgIHRoaXMuJHNoYWRvdy5ob3N0LnN0eWxlLmRpc3BsYXkgPSAnZmxleCdcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcygpfVxuICAgICAgPGFydGljbGU+XG4gICAgICAgIDxkaXYgdG9vbC1pY29uPlxuICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgJHtpY29ufVxuICAgICAgICAgICAgJHt0aGlzLl90b29sfSBUb29sXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjb21tYW5kPlxuICAgICAgICAgIGNvbWluZyBzb29uXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9hcnRpY2xlPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ2hvdGtleXMtcG9zaXRpb24nLCBQb3NpdGlvbkhvdGtleXMpXG4iLCJpbXBvcnQgeyBIb3RrZXlNYXAgfSBmcm9tICcuL2Jhc2UuZWxlbWVudCdcbmltcG9ydCB7IG1ldGFLZXksIGFsdEtleSB9IGZyb20gJy4uLy4uL3V0aWxpdGllcyc7XG5cbmV4cG9ydCBjbGFzcyBGb250SG90a2V5cyBleHRlbmRzIEhvdGtleU1hcCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMuX2hvdGtleSAgICA9ICdmJ1xuICAgIHRoaXMuX3VzZWRrZXlzICA9IFsnc2hpZnQnLG1ldGFLZXldXG4gICAgdGhpcy50b29sICAgICAgID0gJ2ZvbnQnXG4gIH1cblxuICBjcmVhdGVDb21tYW5kKHtlOntjb2RlfSwgaG90a2V5c30pIHtcbiAgICBsZXQgYW1vdW50ICAgICAgICAgICAgICA9IGhvdGtleXMuc2hpZnQgPyAxMCA6IDFcbiAgICBsZXQgbmVnYXRpdmUgICAgICAgICAgICA9ICdbaW5jcmVhc2UvZGVjcmVhc2VdJ1xuICAgIGxldCBuZWdhdGl2ZV9tb2RpZmllciAgID0gJ2J5J1xuICAgIGxldCBzaWRlICAgICAgICAgICAgICAgID0gJ1thcnJvdyBrZXldJ1xuXG4gICAgLy8ga2VybmluZ1xuICAgIGlmIChob3RrZXlzLnNoaWZ0ICYmIChjb2RlID09PSAnQXJyb3dMZWZ0JyB8fCBjb2RlID09PSAnQXJyb3dSaWdodCcpKSB7XG4gICAgICBzaWRlICAgID0gJ2tlcm5pbmcnXG4gICAgICBhbW91bnQgID0gJzFweCdcblxuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd0xlZnQnKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnZGVjcmVhc2UnXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93UmlnaHQnKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnaW5jcmVhc2UnXG4gICAgfVxuICAgIC8vIGxlYWRpbmdcbiAgICBlbHNlIGlmIChob3RrZXlzLnNoaWZ0ICYmIChjb2RlID09PSAnQXJyb3dVcCcgfHwgY29kZSA9PT0gJ0Fycm93RG93bicpKSB7XG4gICAgICBzaWRlICAgID0gJ2xlYWRpbmcnXG4gICAgICBhbW91bnQgID0gJzFweCdcblxuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd1VwJylcbiAgICAgICAgbmVnYXRpdmUgID0gJ2luY3JlYXNlJ1xuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd0Rvd24nKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnZGVjcmVhc2UnXG4gICAgfVxuICAgIC8vIGZvbnQgd2VpZ2h0XG4gICAgZWxzZSBpZiAoaG90a2V5cy5jbWQgJiYgKGNvZGUgPT09ICdBcnJvd1VwJyB8fCBjb2RlID09PSAnQXJyb3dEb3duJykpIHtcbiAgICAgIHNpZGUgICAgICAgICAgICAgICAgPSAnZm9udCB3ZWlnaHQnXG4gICAgICBhbW91bnQgICAgICAgICAgICAgID0gJydcbiAgICAgIG5lZ2F0aXZlX21vZGlmaWVyICAgPSAnJ1xuXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93VXAnKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnaW5jcmVhc2UnXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93RG93bicpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdkZWNyZWFzZSdcbiAgICB9XG4gICAgLy8gZm9udCBzaXplXG4gICAgZWxzZSBpZiAoY29kZSA9PT0gJ0Fycm93VXAnIHx8IGNvZGUgPT09ICdBcnJvd0Rvd24nKSB7XG4gICAgICBzaWRlICAgID0gJ2ZvbnQgc2l6ZSdcbiAgICAgIGFtb3VudCAgPSAnMXB4J1xuXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93VXAnKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnaW5jcmVhc2UnXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93RG93bicpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdkZWNyZWFzZSdcbiAgICB9XG4gICAgLy8gdGV4dCBhbGlnbm1lbnRcbiAgICBlbHNlIGlmIChjb2RlID09PSAnQXJyb3dSaWdodCcgfHwgY29kZSA9PT0gJ0Fycm93TGVmdCcpIHtcbiAgICAgIHNpZGUgICAgICAgICAgICAgICAgPSAndGV4dCBhbGlnbm1lbnQnXG4gICAgICBhbW91bnQgICAgICAgICAgICAgID0gJydcbiAgICAgIG5lZ2F0aXZlICAgICAgICAgICAgPSAnYWRqdXN0J1xuICAgICAgbmVnYXRpdmVfbW9kaWZpZXIgICA9ICcnXG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG5lZ2F0aXZlLCBuZWdhdGl2ZV9tb2RpZmllciwgYW1vdW50LCBzaWRlLFxuICAgIH1cbiAgfVxuXG4gIGRpc3BsYXlDb21tYW5kKHtuZWdhdGl2ZSwgbmVnYXRpdmVfbW9kaWZpZXIsIHNpZGUsIGFtb3VudH0pIHtcbiAgICBpZiAobmVnYXRpdmUgPT09IGDCsVske2FsdEtleX1dIGApXG4gICAgICBuZWdhdGl2ZSA9ICdbaW5jcmVhc2UvZGVjcmVhc2VdJ1xuICAgIGlmIChuZWdhdGl2ZV9tb2RpZmllciA9PT0gJyB0byAnKVxuICAgICAgbmVnYXRpdmVfbW9kaWZpZXIgPSAnIGJ5ICdcblxuICAgIHJldHVybiBgXG4gICAgICA8c3BhbiBuZWdhdGl2ZT4ke25lZ2F0aXZlfTwvc3Bhbj5cbiAgICAgIDxzcGFuIHNpZGUgdG9vbD4ke3NpZGV9PC9zcGFuPlxuICAgICAgPHNwYW4gbGlnaHQ+JHtuZWdhdGl2ZV9tb2RpZmllcn08L3NwYW4+XG4gICAgICA8c3BhbiBhbW91bnQ+JHthbW91bnR9PC9zcGFuPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ2hvdGtleXMtZm9udCcsIEZvbnRIb3RrZXlzKVxuIiwiaW1wb3J0IHsgSG90a2V5TWFwIH0gZnJvbSAnLi9iYXNlLmVsZW1lbnQnXG5pbXBvcnQgeyB0ZXh0IGFzIGljb24gfSBmcm9tICcuLi92aXMtYnVnL3Zpcy1idWcuaWNvbnMnXG5cbmV4cG9ydCBjbGFzcyBUZXh0SG90a2V5cyBleHRlbmRzIEhvdGtleU1hcCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMuX2hvdGtleSAgICA9ICdlJ1xuICAgIHRoaXMuX3VzZWRrZXlzICA9IFtdXG4gICAgdGhpcy50b29sICAgICAgID0gJ3RleHQnXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxhcnRpY2xlPlxuICAgICAgICA8ZGl2IHRvb2wtaWNvbj5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICR7aWNvbn1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICBjb21pbmcgc29vblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLXRleHQnLCBUZXh0SG90a2V5cylcbiIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuaW1wb3J0IHsgc2VhcmNoIGFzIGljb24gfSBmcm9tICcuLi92aXMtYnVnL3Zpcy1idWcuaWNvbnMnXG5cbmV4cG9ydCBjbGFzcyBTZWFyY2hIb3RrZXlzIGV4dGVuZHMgSG90a2V5TWFwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5faG90a2V5ICAgID0gJ3MnXG4gICAgdGhpcy5fdXNlZGtleXMgID0gW11cbiAgICB0aGlzLnRvb2wgICAgICAgPSAnc2VhcmNoJ1xuICB9XG5cbiAgY29ubmVjdGVkQ2FsbGJhY2soKSB7fVxuXG4gIHNob3coKSB7XG4gICAgdGhpcy4kc2hhZG93Lmhvc3Quc3R5bGUuZGlzcGxheSA9ICdmbGV4J1xuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiBgXG4gICAgICAke3RoaXMuc3R5bGVzKCl9XG4gICAgICA8YXJ0aWNsZT5cbiAgICAgICAgPGRpdiB0b29sLWljb24+XG4gICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAke2ljb259XG4gICAgICAgICAgICAke3RoaXMuX3Rvb2x9IFRvb2xcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNvbW1hbmQ+XG4gICAgICAgICAgY29taW5nIHNvb25cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2FydGljbGU+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1zZWFyY2gnLCBTZWFyY2hIb3RrZXlzKVxuIiwiaW1wb3J0ICQgICAgICAgIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzICBmcm9tICdob3RrZXlzLWpzJ1xuXG5pbXBvcnQgeyBHdWlkZXNIb3RrZXlzIH0gICAgICAgIGZyb20gJy4vZ3VpZGVzLmVsZW1lbnQnXG5pbXBvcnQgeyBJbnNwZWN0b3JIb3RrZXlzIH0gICAgIGZyb20gJy4vaW5zcGVjdG9yLmVsZW1lbnQnXG5pbXBvcnQgeyBBY2Nlc3NpYmlsaXR5SG90a2V5cyB9IGZyb20gJy4vYWNjZXNzaWJpbGl0eS5lbGVtZW50J1xuaW1wb3J0IHsgTW92ZUhvdGtleXMgfSAgICAgICAgICBmcm9tICcuL21vdmUuZWxlbWVudCdcbmltcG9ydCB7IE1hcmdpbkhvdGtleXMgfSAgICAgICAgZnJvbSAnLi9tYXJnaW4uZWxlbWVudCdcbmltcG9ydCB7IFBhZGRpbmdIb3RrZXlzIH0gICAgICAgZnJvbSAnLi9wYWRkaW5nLmVsZW1lbnQnXG5pbXBvcnQgeyBBbGlnbkhvdGtleXMgfSAgICAgICAgIGZyb20gJy4vYWxpZ24uZWxlbWVudCdcbmltcG9ydCB7IEh1ZXNoaWZ0SG90a2V5cyB9ICAgICAgZnJvbSAnLi9odWVzaGlmdC5lbGVtZW50J1xuaW1wb3J0IHsgQm94c2hhZG93SG90a2V5cyB9ICAgICBmcm9tICcuL2JveHNoYWRvdy5lbGVtZW50J1xuaW1wb3J0IHsgUG9zaXRpb25Ib3RrZXlzIH0gICAgICBmcm9tICcuL3Bvc2l0aW9uLmVsZW1lbnQnXG5pbXBvcnQgeyBGb250SG90a2V5cyB9ICAgICAgICAgIGZyb20gJy4vZm9udC5lbGVtZW50J1xuaW1wb3J0IHsgVGV4dEhvdGtleXMgfSAgICAgICAgICBmcm9tICcuL3RleHQuZWxlbWVudCdcbmltcG9ydCB7IFNlYXJjaEhvdGtleXMgfSAgICAgICAgZnJvbSAnLi9zZWFyY2guZWxlbWVudCdcblxuZXhwb3J0IGNsYXNzIEhvdGtleXMgZXh0ZW5kcyBIVE1MRWxlbWVudCB7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy50b29sX21hcCA9IHtcbiAgICAgIGd1aWRlczogICAgICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdob3RrZXlzLWd1aWRlcycpLFxuICAgICAgaW5zcGVjdG9yOiAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtaW5zcGVjdG9yJyksXG4gICAgICBhY2Nlc3NpYmlsaXR5OiAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaG90a2V5cy1hY2Nlc3NpYmlsaXR5JyksXG4gICAgICBtb3ZlOiAgICAgICAgICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaG90a2V5cy1tb3ZlJyksXG4gICAgICBtYXJnaW46ICAgICAgICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaG90a2V5cy1tYXJnaW4nKSxcbiAgICAgIHBhZGRpbmc6ICAgICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdob3RrZXlzLXBhZGRpbmcnKSxcbiAgICAgIGFsaWduOiAgICAgICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdob3RrZXlzLWFsaWduJyksXG4gICAgICBodWVzaGlmdDogICAgICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaG90a2V5cy1odWVzaGlmdCcpLFxuICAgICAgYm94c2hhZG93OiAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtYm94c2hhZG93JyksXG4gICAgICBwb3NpdGlvbjogICAgICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaG90a2V5cy1wb3NpdGlvbicpLFxuICAgICAgZm9udDogICAgICAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtZm9udCcpLFxuICAgICAgdGV4dDogICAgICAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtdGV4dCcpLFxuICAgICAgc2VhcmNoOiAgICAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtc2VhcmNoJyksXG4gICAgfVxuXG4gICAgT2JqZWN0LnZhbHVlcyh0aGlzLnRvb2xfbWFwKS5mb3JFYWNoKHRvb2wgPT5cbiAgICAgIHRoaXMuYXBwZW5kQ2hpbGQodG9vbCkpXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICBob3RrZXlzKCdzaGlmdCsvJywgZSA9PlxuICAgICAgdGhpcy5jdXJfdG9vbFxuICAgICAgICA/IHRoaXMuaGlkZVRvb2woKVxuICAgICAgICA6IHRoaXMuc2hvd1Rvb2woKSlcblxuICAgIGhvdGtleXMoJ2VzYycsIGUgPT4gdGhpcy5oaWRlVG9vbCgpKVxuICB9XG5cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7fVxuXG4gIGhpZGVUb29sKCkge1xuICAgIGlmICghdGhpcy5jdXJfdG9vbCkgcmV0dXJuXG4gICAgdGhpcy5jdXJfdG9vbC5oaWRlKClcbiAgICB0aGlzLmN1cl90b29sID0gbnVsbFxuICB9XG5cbiAgc2hvd1Rvb2woKSB7XG4gICAgdGhpcy5jdXJfdG9vbCA9IHRoaXMudG9vbF9tYXBbXG4gICAgICAkKCd2aXMtYnVnJylbMF0uYWN0aXZlVG9vbF1cbiAgICB0aGlzLmN1cl90b29sLnNob3coKVxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgndmlzYnVnLWhvdGtleXMnLCBIb3RrZXlzKVxuIiwiaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCB7IG1ldGFLZXksIGdldFN0eWxlLCBnZXRTaWRlLCBzaG93SGlkZVNlbGVjdGVkIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuLy8gdG9kbzogc2hvdyBtYXJnaW4gY29sb3JcbmNvbnN0IGtleV9ldmVudHMgPSAndXAsZG93bixsZWZ0LHJpZ2h0J1xuICAuc3BsaXQoJywnKVxuICAucmVkdWNlKChldmVudHMsIGV2ZW50KSA9PlxuICAgIGAke2V2ZW50c30sJHtldmVudH0sYWx0KyR7ZXZlbnR9LHNoaWZ0KyR7ZXZlbnR9LHNoaWZ0K2FsdCske2V2ZW50fWBcbiAgLCAnJylcbiAgLnN1YnN0cmluZygxKVxuXG5jb25zdCBjb21tYW5kX2V2ZW50cyA9IGAke21ldGFLZXl9K3VwLCR7bWV0YUtleX0rc2hpZnQrdXAsJHttZXRhS2V5fStkb3duLCR7bWV0YUtleX0rc2hpZnQrZG93bmBcblxuZXhwb3J0IGZ1bmN0aW9uIE1hcmdpbih7c2VsZWN0aW9ufSkge1xuICBob3RrZXlzKGtleV9ldmVudHMsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgaWYgKGUuY2FuY2VsQnViYmxlKSByZXR1cm5cblxuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHB1c2hFbGVtZW50KHNlbGVjdGlvbigpLCBoYW5kbGVyLmtleSlcbiAgfSlcblxuICBob3RrZXlzKGNvbW1hbmRfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHB1c2hBbGxFbGVtZW50U2lkZXMoc2VsZWN0aW9uKCksIGhhbmRsZXIua2V5KVxuICB9KVxuXG4gIHJldHVybiAoKSA9PiB7XG4gICAgaG90a2V5cy51bmJpbmQoa2V5X2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZChjb21tYW5kX2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZCgndXAsZG93bixsZWZ0LHJpZ2h0JykgLy8gYnVnIGluIGxpYj9cbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcHVzaEVsZW1lbnQoZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbCA9PiBzaG93SGlkZVNlbGVjdGVkKGVsKSlcbiAgICAubWFwKGVsID0+ICh7XG4gICAgICBlbCxcbiAgICAgIHN0eWxlOiAgICAnbWFyZ2luJyArIGdldFNpZGUoZGlyZWN0aW9uKSxcbiAgICAgIGN1cnJlbnQ6ICBwYXJzZUludChnZXRTdHlsZShlbCwgJ21hcmdpbicgKyBnZXRTaWRlKGRpcmVjdGlvbikpLCAxMCksXG4gICAgICBhbW91bnQ6ICAgZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ3NoaWZ0JykgPyAxMCA6IDEsXG4gICAgICBuZWdhdGl2ZTogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ2FsdCcpLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIG1hcmdpbjogcGF5bG9hZC5uZWdhdGl2ZVxuICAgICAgICAgID8gcGF5bG9hZC5jdXJyZW50IC0gcGF5bG9hZC5hbW91bnRcbiAgICAgICAgICA6IHBheWxvYWQuY3VycmVudCArIHBheWxvYWQuYW1vdW50XG4gICAgICB9KSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgbWFyZ2lufSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IGAke21hcmdpbiA8IDAgPyAwIDogbWFyZ2lufXB4YClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHB1c2hBbGxFbGVtZW50U2lkZXMoZWxzLCBrZXljb21tYW5kKSB7XG4gIGNvbnN0IGNvbWJvID0ga2V5Y29tbWFuZC5zcGxpdCgnKycpXG4gIGxldCBzcG9vZiA9ICcnXG5cbiAgaWYgKGNvbWJvLmluY2x1ZGVzKCdzaGlmdCcpKSAgc3Bvb2YgPSAnc2hpZnQrJyArIHNwb29mXG4gIGlmIChjb21iby5pbmNsdWRlcygnZG93bicpKSAgIHNwb29mID0gJ2FsdCsnICsgc3Bvb2ZcblxuICAndXAsZG93bixsZWZ0LHJpZ2h0Jy5zcGxpdCgnLCcpXG4gICAgLmZvckVhY2goc2lkZSA9PiBwdXNoRWxlbWVudChlbHMsIHNwb29mICsgc2lkZSkpXG59XG4iLCJpbXBvcnQgaG90a2V5cyBmcm9tICdob3RrZXlzLWpzJ1xuaW1wb3J0IHsgZ2V0Tm9kZUluZGV4LCBzaG93RWRnZSB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmNvbnN0IGtleV9ldmVudHMgPSAndXAsZG93bixsZWZ0LHJpZ2h0J1xuLy8gdG9kbzogaW5kaWNhdG9yIGZvciB3aGVuIG5vZGUgY2FuIGRlc2NlbmRcbi8vIHRvZG86IGluZGljYXRvciB3aGVyZSBsZWZ0IGFuZCByaWdodCB3aWxsIGdvXG4vLyB0b2RvOiBoYXZlIGl0IHdvcmsgd2l0aCBzaGFkb3dET01cbmV4cG9ydCBmdW5jdGlvbiBNb3ZlYWJsZSh7c2VsZWN0aW9ufSkge1xuICBob3RrZXlzKGtleV9ldmVudHMsIChlLCB7a2V5fSkgPT4ge1xuICAgIGlmIChlLmNhbmNlbEJ1YmJsZSkgcmV0dXJuXG4gICAgICBcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG4gICAgXG4gICAgc2VsZWN0aW9uKCkuZm9yRWFjaChlbCA9PiB7XG4gICAgICBtb3ZlRWxlbWVudChlbCwga2V5KVxuICAgICAgdXBkYXRlRmVlZGJhY2soZWwpXG4gICAgfSlcbiAgfSlcblxuICByZXR1cm4gKCkgPT4ge1xuICAgIGhvdGtleXMudW5iaW5kKGtleV9ldmVudHMpXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG1vdmVFbGVtZW50KGVsLCBkaXJlY3Rpb24pIHtcbiAgaWYgKCFlbCkgcmV0dXJuXG5cbiAgc3dpdGNoKGRpcmVjdGlvbikge1xuICAgIGNhc2UgJ2xlZnQnOlxuICAgICAgaWYgKGNhbk1vdmVMZWZ0KGVsKSlcbiAgICAgICAgZWwucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoZWwsIGVsLnByZXZpb3VzRWxlbWVudFNpYmxpbmcpXG4gICAgICBlbHNlXG4gICAgICAgIHNob3dFZGdlKGVsLnBhcmVudE5vZGUpXG4gICAgICBicmVha1xuXG4gICAgY2FzZSAncmlnaHQnOlxuICAgICAgaWYgKGNhbk1vdmVSaWdodChlbCkgJiYgZWwubmV4dEVsZW1lbnRTaWJsaW5nLm5leHRTaWJsaW5nKVxuICAgICAgICBlbC5wYXJlbnROb2RlLmluc2VydEJlZm9yZShlbCwgZWwubmV4dEVsZW1lbnRTaWJsaW5nLm5leHRTaWJsaW5nKVxuICAgICAgZWxzZSBpZiAoY2FuTW92ZVJpZ2h0KGVsKSlcbiAgICAgICAgZWwucGFyZW50Tm9kZS5hcHBlbmRDaGlsZChlbClcbiAgICAgIGVsc2VcbiAgICAgICAgc2hvd0VkZ2UoZWwucGFyZW50Tm9kZSlcbiAgICAgIGJyZWFrXG5cbiAgICBjYXNlICd1cCc6XG4gICAgICBpZiAoY2FuTW92ZVVwKGVsKSlcbiAgICAgICAgcG9wT3V0KHtlbH0pXG4gICAgICBicmVha1xuXG4gICAgY2FzZSAnZG93bic6XG4gICAgICBpZiAoY2FuTW92ZVVuZGVyKGVsKSlcbiAgICAgICAgcG9wT3V0KHtlbCwgdW5kZXI6IHRydWV9KVxuICAgICAgZWxzZSBpZiAoY2FuTW92ZURvd24oZWwpKVxuICAgICAgICBlbC5uZXh0RWxlbWVudFNpYmxpbmcucHJlcGVuZChlbClcbiAgICAgIGJyZWFrXG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IGNhbk1vdmVMZWZ0ICAgID0gZWwgPT4gZWwucHJldmlvdXNFbGVtZW50U2libGluZ1xuZXhwb3J0IGNvbnN0IGNhbk1vdmVSaWdodCAgID0gZWwgPT4gZWwubmV4dEVsZW1lbnRTaWJsaW5nXG5leHBvcnQgY29uc3QgY2FuTW92ZURvd24gICAgPSBlbCA9PiBlbC5uZXh0RWxlbWVudFNpYmxpbmcgJiYgZWwubmV4dEVsZW1lbnRTaWJsaW5nLmNoaWxkcmVuLmxlbmd0aFxuZXhwb3J0IGNvbnN0IGNhbk1vdmVVbmRlciAgID0gZWwgPT4gIWVsLm5leHRFbGVtZW50U2libGluZyAmJiBlbC5wYXJlbnROb2RlICYmIGVsLnBhcmVudE5vZGUucGFyZW50Tm9kZVxuZXhwb3J0IGNvbnN0IGNhbk1vdmVVcCAgICAgID0gZWwgPT4gZWwucGFyZW50Tm9kZSAmJiBlbC5wYXJlbnROb2RlLnBhcmVudE5vZGVcblxuZXhwb3J0IGNvbnN0IHBvcE91dCA9ICh7ZWwsIHVuZGVyID0gZmFsc2V9KSA9PlxuICBlbC5wYXJlbnROb2RlLnBhcmVudE5vZGUuaW5zZXJ0QmVmb3JlKGVsLCBcbiAgICBlbC5wYXJlbnROb2RlLnBhcmVudE5vZGUuY2hpbGRyZW5bXG4gICAgICB1bmRlclxuICAgICAgICA/IGdldE5vZGVJbmRleChlbCkgKyAxXG4gICAgICAgIDogZ2V0Tm9kZUluZGV4KGVsKV0pIFxuXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlRmVlZGJhY2soZWwpIHtcbiAgbGV0IG9wdGlvbnMgPSAnJ1xuICAvLyBnZXQgY3VycmVudCBlbGVtZW50cyBvZmZzZXQvc2l6ZVxuICBpZiAoY2FuTW92ZUxlZnQoZWwpKSAgb3B0aW9ucyArPSAn4oegJ1xuICBpZiAoY2FuTW92ZVJpZ2h0KGVsKSkgb3B0aW9ucyArPSAn4oeiJ1xuICBpZiAoY2FuTW92ZURvd24oZWwpKSAgb3B0aW9ucyArPSAn4oejJ1xuICBpZiAoY2FuTW92ZVVwKGVsKSkgICAgb3B0aW9ucyArPSAn4oehJ1xuICAvLyBjcmVhdGUvbW92ZSBhcnJvd3MgaW4gYWJzb2x1dGUvZml4ZWQgdG8gb3ZlcmxheSBlbGVtZW50XG4gIG9wdGlvbnMgJiYgY29uc29sZS5pbmZvKCclYycrb3B0aW9ucywgXCJmb250LXNpemU6IDJyZW07XCIpXG59IiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IHsgZ2V0U3R5bGUgfSBmcm9tICcuLi91dGlsaXRpZXMvJ1xuXG5sZXQgaW1ncyAgICAgID0gW11cbiAgLCBvdmVybGF5cyAgPSBbXVxuICAsIGRyYWdJdGVtXG5cbmV4cG9ydCBmdW5jdGlvbiB3YXRjaEltYWdlc0ZvclVwbG9hZCgpIHtcbiAgaW1ncyA9ICQoW1xuICAgIC4uLmRvY3VtZW50LmltYWdlcyxcbiAgICAuLi5maW5kQmFja2dyb3VuZEltYWdlcyhkb2N1bWVudCksXG4gIF0pXG5cbiAgY2xlYXJXYXRjaGVycyhpbWdzKVxuICBpbml0V2F0Y2hlcnMoaW1ncylcbn1cblxuY29uc3QgaW5pdFdhdGNoZXJzID0gaW1ncyA9PiB7XG4gIGltZ3Mub24oJ2RyYWdvdmVyJywgb25EcmFnRW50ZXIpXG4gIGltZ3Mub24oJ2RyYWdsZWF2ZScsIG9uRHJhZ0xlYXZlKVxuICBpbWdzLm9uKCdkcm9wJywgb25Ecm9wKVxuICAkKGRvY3VtZW50LmJvZHkpLm9uKCdkcmFnb3ZlcicsIG9uRHJhZ0VudGVyKVxuICAkKGRvY3VtZW50LmJvZHkpLm9uKCdkcmFnbGVhdmUnLCBvbkRyYWdMZWF2ZSlcbiAgJChkb2N1bWVudC5ib2R5KS5vbignZHJvcCcsIG9uRHJvcClcbiAgJChkb2N1bWVudC5ib2R5KS5vbignZHJhZ3N0YXJ0Jywgb25EcmFnU3RhcnQpXG4gICQoZG9jdW1lbnQuYm9keSkub24oJ2RyYWdlbmQnLCBvbkRyYWdFbmQpXG59XG5cbmNvbnN0IGNsZWFyV2F0Y2hlcnMgPSBpbWdzID0+IHtcbiAgaW1ncy5vZmYoJ2RyYWdlbnRlcicsIG9uRHJhZ0VudGVyKVxuICBpbWdzLm9mZignZHJhZ2xlYXZlJywgb25EcmFnTGVhdmUpXG4gIGltZ3Mub2ZmKCdkcm9wJywgb25Ecm9wKVxuICAkKGRvY3VtZW50LmJvZHkpLm9mZignZHJhZ2VudGVyJywgb25EcmFnRW50ZXIpXG4gICQoZG9jdW1lbnQuYm9keSkub2ZmKCdkcmFnbGVhdmUnLCBvbkRyYWdMZWF2ZSlcbiAgJChkb2N1bWVudC5ib2R5KS5vZmYoJ2Ryb3AnLCBvbkRyb3ApXG4gICQoZG9jdW1lbnQuYm9keSkub24oJ2RyYWdzdGFydCcsIG9uRHJhZ1N0YXJ0KVxuICAkKGRvY3VtZW50LmJvZHkpLm9uKCdkcmFnZW5kJywgb25EcmFnRW5kKVxuICBpbWdzID0gW11cbn1cblxuY29uc3QgcHJldmlld0ZpbGUgPSBmaWxlID0+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBsZXQgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKVxuICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGZpbGUpXG4gICAgcmVhZGVyLm9ubG9hZGVuZCA9ICgpID0+IHJlc29sdmUocmVhZGVyLnJlc3VsdClcbiAgfSlcbn1cblxuLy8gb25seSBmaXJlZCBmb3IgaW4tcGFnZSBkcmFnIGV2ZW50cywgdHJhY2sgd2hhdCB0aGUgdXNlciBwaWNrZWQgdXBcbmNvbnN0IG9uRHJhZ1N0YXJ0ID0gKHt0YXJnZXR9KSA9PlxuICBkcmFnSXRlbSA9IHRhcmdldFxuXG5jb25zdCBvbkRyYWdFbmQgPSBlID0+XG4gIGRyYWdJdGVtID0gdW5kZWZpbmVkXG5cbmNvbnN0IG9uRHJhZ0VudGVyID0gZSA9PiB7XG4gIGUucHJldmVudERlZmF1bHQoKVxuICBjb25zdCBwcmVfc2VsZWN0ZWQgPSAkKCdpbWdbZGF0YS1zZWxlY3RlZD10cnVlXScpXG5cbiAgaWYgKCFwcmVfc2VsZWN0ZWQubGVuZ3RoKVxuICAgIHNob3dPdmVybGF5KGUuY3VycmVudFRhcmdldCwgMClcbiAgZWxzZVxuICAgIHByZV9zZWxlY3RlZC5mb3JFYWNoKChpbWcsIGkpID0+XG4gICAgICBzaG93T3ZlcmxheShpbWcsIGkpKVxufVxuXG5jb25zdCBvbkRyYWdMZWF2ZSA9IGUgPT4gXG4gIGhpZGVPdmVybGF5cygpXG5cblxuY29uc3Qgb25Ecm9wID0gYXN5bmMgZSA9PiB7XG4gIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgY29uc3Qgc2VsZWN0ZWRJbWFnZXMgPSAkKCdpbWdbZGF0YS1zZWxlY3RlZD10cnVlXScpXG4gIFxuICBjb25zdCBzcmNzID0gZS5kYXRhVHJhbnNmZXIuZmlsZXMubGVuZ3RoIFxuICAgID8gYXdhaXQgUHJvbWlzZS5hbGwoWy4uLmUuZGF0YVRyYW5zZmVyLmZpbGVzXVxuICAgICAgLmZpbHRlcihmaWxlID0+IGZpbGUudHlwZS5pbmNsdWRlcygnaW1hZ2UnKSlcbiAgICAgIC5tYXAocHJldmlld0ZpbGUpKSBcbiAgICA6IFtkcmFnSXRlbS5zcmNdXG4gIFxuICBpZiAoc3Jjcy5sZW5ndGgpIHtcbiAgICBpZiAoIXNlbGVjdGVkSW1hZ2VzLmxlbmd0aClcbiAgICAgIGlmIChlLnRhcmdldC5ub2RlTmFtZSA9PT0gJ0lNRycpXG4gICAgICAgIGUudGFyZ2V0LnNyYyA9IHNyY3NbMF1cbiAgICAgIGVsc2VcbiAgICAgICAgaW1nc1xuICAgICAgICAgIC5maWx0ZXIoaW1nID0+IGltZy5jb250YWlucyhlLnRhcmdldCkpXG4gICAgICAgICAgLmZvckVhY2goaW1nID0+IFxuICAgICAgICAgICAgaW1nLnN0eWxlLmJhY2tncm91bmRJbWFnZSA9IGB1cmwoJHtzcmNzWzBdfSlgKVxuICAgIGVsc2UgaWYgKHNlbGVjdGVkSW1hZ2VzLmxlbmd0aCkge1xuICAgICAgbGV0IGkgPSAwXG4gICAgICBzZWxlY3RlZEltYWdlcy5mb3JFYWNoKGltZyA9PiB7XG4gICAgICAgIGltZy5zcmMgPSBzcmNzW2krK11cbiAgICAgICAgaWYgKGkgPj0gc3Jjcy5sZW5ndGgpIGkgPSAwXG4gICAgICB9KVxuICAgIH1cbiAgfVxuXG4gIGhpZGVPdmVybGF5cygpXG59XG5cbmNvbnN0IHNob3dPdmVybGF5ID0gKG5vZGUsIGkpID0+IHtcbiAgY29uc3QgcmVjdCAgICA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KClcbiAgY29uc3Qgb3ZlcmxheSA9IG92ZXJsYXlzW2ldXG5cbiAgaWYgKG92ZXJsYXkpIHtcbiAgICBvdmVybGF5LnVwZGF0ZSA9IHJlY3RcbiAgfVxuICBlbHNlIHtcbiAgICBvdmVybGF5c1tpXSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3Zpc2J1Zy1vdmVybGF5JylcbiAgICBvdmVybGF5c1tpXS5wb3NpdGlvbiA9IHJlY3RcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKG92ZXJsYXlzW2ldKVxuICB9XG59XG5cbmNvbnN0IGhpZGVPdmVybGF5cyA9ICgpID0+IHtcbiAgb3ZlcmxheXMuZm9yRWFjaChvdmVybGF5ID0+XG4gICAgb3ZlcmxheS5yZW1vdmUoKSlcbiAgb3ZlcmxheXMgPSBbXVxufVxuXG5jb25zdCBmaW5kQmFja2dyb3VuZEltYWdlcyA9IGVsID0+IHtcbiAgY29uc3Qgc3JjX3JlZ2V4ID0gL3VybFxcKFxccyo/WydcIl0/XFxzKj8oXFxTKz8pXFxzKj9bXCInXT9cXHMqP1xcKS9pXG5cbiAgcmV0dXJuICQoJyonKS5yZWR1Y2UoKGNvbGxlY3Rpb24sIG5vZGUpID0+IHtcbiAgICBjb25zdCBwcm9wID0gZ2V0U3R5bGUobm9kZSwgJ2JhY2tncm91bmQtaW1hZ2UnKVxuICAgIGNvbnN0IG1hdGNoID0gc3JjX3JlZ2V4LmV4ZWMocHJvcClcblxuICAgIC8vIGlmIChtYXRjaCkgY29sbGVjdGlvbi5wdXNoKG1hdGNoWzFdKVxuICAgIGlmIChtYXRjaCkgY29sbGVjdGlvbi5wdXNoKG5vZGUpXG5cbiAgICByZXR1cm4gY29sbGVjdGlvblxuICB9LCBbXSlcbn1cbiIsIi8qKlxyXG4gKiBAYXV0aG9yIEdlb3JnZWdyaWZmQCAoR2VvcmdlIEdyaWZmaXRocylcclxuICogTGljZW5zZSBBcGFjaGUtMi4wXHJcbiAqL1xyXG5cclxuLyoqXHJcbiogRmluZHMgZmlyc3QgbWF0Y2hpbmcgZWxlbWVudHMgb24gdGhlIHBhZ2UgdGhhdCBtYXkgYmUgaW4gYSBzaGFkb3cgcm9vdCB1c2luZyBhIGNvbXBsZXggc2VsZWN0b3Igb2Ygbi1kZXB0aFxyXG4qXHJcbiogRG9uJ3QgaGF2ZSB0byBzcGVjaWZ5IGFsbCBzaGFkb3cgcm9vdHMgdG8gYnV0dG9uLCB0cmVlIGlzIHRyYXZlcmVkIHRvIGZpbmQgdGhlIGNvcnJlY3QgZWxlbWVudFxyXG4qXHJcbiogRXhhbXBsZSBxdWVyeVNlbGVjdG9yQWxsRGVlcCgnZG93bmxvYWRzLWl0ZW06bnRoLWNoaWxkKDQpICNyZW1vdmUnKTtcclxuKlxyXG4qIEV4YW1wbGUgc2hvdWxkIHdvcmsgb24gY2hyb21lOi8vZG93bmxvYWRzIG91dHB1dHRpbmcgdGhlIHJlbW92ZSBidXR0b24gaW5zaWRlIG9mIGEgZG93bmxvYWQgY2FyZCBjb21wb25lbnRcclxuKlxyXG4qIEV4YW1wbGUgZmluZCBmaXJzdCBhY3RpdmUgZG93bmxvYWQgbGluayBlbGVtZW50IHF1ZXJ5U2VsZWN0b3JEZWVwKCcjZG93bmxvYWRzLWxpc3QgLmlzLWFjdGl2ZSBhW2hyZWZePVwiaHR0cHM6Ly9cIl0nKTtcclxuKlxyXG4qIEFub3RoZXIgZXhhbXBsZSBxdWVyeVNlbGVjdG9yQWxsRGVlcCgnI2Rvd25sb2Fkcy1saXN0IGRpdiN0aXRsZS1hcmVhICsgYScpO1xyXG5lLmcuXHJcbiovXHJcbmV4cG9ydCBmdW5jdGlvbiBxdWVyeVNlbGVjdG9yQWxsRGVlcChzZWxlY3Rvciwgcm9vdCA9IGRvY3VtZW50KSB7XHJcbiAgICByZXR1cm4gX3F1ZXJ5U2VsZWN0b3JEZWVwKHNlbGVjdG9yLCB0cnVlLCByb290KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHF1ZXJ5U2VsZWN0b3JEZWVwKHNlbGVjdG9yLCByb290ID0gZG9jdW1lbnQpIHtcclxuICAgIHJldHVybiBfcXVlcnlTZWxlY3RvckRlZXAoc2VsZWN0b3IsIGZhbHNlLCByb290KTtcclxufVxyXG5cclxuZnVuY3Rpb24gX3F1ZXJ5U2VsZWN0b3JEZWVwKHNlbGVjdG9yLCBmaW5kTWFueSwgcm9vdCkge1xyXG4gICAgbGV0IGxpZ2h0RWxlbWVudCA9IHJvb3QucXVlcnlTZWxlY3RvcihzZWxlY3Rvcik7XHJcblxyXG4gICAgaWYgKGRvY3VtZW50LmhlYWQuY3JlYXRlU2hhZG93Um9vdCB8fCBkb2N1bWVudC5oZWFkLmF0dGFjaFNoYWRvdykge1xyXG4gICAgICAgIC8vIG5vIG5lZWQgdG8gZG8gYW55IHNwZWNpYWwgaWYgc2VsZWN0b3IgbWF0Y2hlcyBzb21ldGhpbmcgc3BlY2lmaWMgaW4gbGlnaHQtZG9tXHJcbiAgICAgICAgaWYgKCFmaW5kTWFueSAmJiBsaWdodEVsZW1lbnQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGxpZ2h0RWxlbWVudDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIHNwbGl0IG9uIGNvbW1hcyBiZWNhdXNlIHRob3NlIGFyZSBhIGxvZ2ljYWwgZGl2aWRlIGluIHRoZSBvcGVyYXRpb25cclxuICAgICAgICBjb25zdCBzZWxlY3Rpb25zVG9NYWtlID0gc3BsaXRCeUNoYXJhY3RlclVubGVzc1F1b3RlZChzZWxlY3RvciwgJywnKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHNlbGVjdGlvbnNUb01ha2UucmVkdWNlKChhY2MsIG1pbmltYWxTZWxlY3RvcikgPT4ge1xyXG4gICAgICAgICAgICAvLyBpZiBub3QgZmluZGluZyBtYW55IGp1c3QgcmVkdWNlIHRoZSBmaXJzdCBtYXRjaFxyXG4gICAgICAgICAgICBpZiAoIWZpbmRNYW55ICYmIGFjYykge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGFjYztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyBkbyBiZXN0IHRvIHN1cHBvcnQgY29tcGxleCBzZWxlY3RvcnMgYW5kIHNwbGl0IHRoZSBxdWVyeVxyXG4gICAgICAgICAgICBjb25zdCBzcGxpdFNlbGVjdG9yID0gc3BsaXRCeUNoYXJhY3RlclVubGVzc1F1b3RlZChtaW5pbWFsU2VsZWN0b3JcclxuICAgICAgICAgICAgICAgICAgICAvL3JlbW92ZSB3aGl0ZSBzcGFjZSBhdCBzdGFydCBvZiBzZWxlY3RvclxyXG4gICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9eXFxzKy9nLCAnJylcclxuICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxzKihbPit+XSspXFxzKi9nLCAnJDEnKSwgJyAnKVxyXG4gICAgICAgICAgICAgICAgLy8gZmlsdGVyIG91dCBlbnRyeSB3aGl0ZSBzZWxlY3RvcnNcclxuICAgICAgICAgICAgICAgIC5maWx0ZXIoKGVudHJ5KSA9PiAhIWVudHJ5KTtcclxuICAgICAgICAgICAgY29uc3QgcG9zc2libGVFbGVtZW50c0luZGV4ID0gc3BsaXRTZWxlY3Rvci5sZW5ndGggLSAxO1xyXG4gICAgICAgICAgICBjb25zdCBwb3NzaWJsZUVsZW1lbnRzID0gY29sbGVjdEFsbEVsZW1lbnRzRGVlcChzcGxpdFNlbGVjdG9yW3Bvc3NpYmxlRWxlbWVudHNJbmRleF0sIHJvb3QpO1xyXG4gICAgICAgICAgICBjb25zdCBmaW5kRWxlbWVudHMgPSBmaW5kTWF0Y2hpbmdFbGVtZW50KHNwbGl0U2VsZWN0b3IsIHBvc3NpYmxlRWxlbWVudHNJbmRleCwgcm9vdCk7XHJcbiAgICAgICAgICAgIGlmIChmaW5kTWFueSkge1xyXG4gICAgICAgICAgICAgICAgYWNjID0gYWNjLmNvbmNhdChwb3NzaWJsZUVsZW1lbnRzLmZpbHRlcihmaW5kRWxlbWVudHMpKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBhY2M7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBhY2MgPSBwb3NzaWJsZUVsZW1lbnRzLmZpbmQoZmluZEVsZW1lbnRzKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBhY2MgfHwgbnVsbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGZpbmRNYW55ID8gW10gOiBudWxsKTtcclxuXHJcblxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAoIWZpbmRNYW55KSB7XHJcbiAgICAgICAgICAgIHJldHVybiBsaWdodEVsZW1lbnQ7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIHJvb3QucXVlcnlTZWxlY3RvckFsbChzZWxlY3Rvcik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxufVxyXG5cclxuZnVuY3Rpb24gZmluZE1hdGNoaW5nRWxlbWVudChzcGxpdFNlbGVjdG9yLCBwb3NzaWJsZUVsZW1lbnRzSW5kZXgsIHJvb3QpIHtcclxuICAgIHJldHVybiAoZWxlbWVudCkgPT4ge1xyXG4gICAgICAgIGxldCBwb3NpdGlvbiA9IHBvc3NpYmxlRWxlbWVudHNJbmRleDtcclxuICAgICAgICBsZXQgcGFyZW50ID0gZWxlbWVudDtcclxuICAgICAgICBsZXQgZm91bmRFbGVtZW50ID0gZmFsc2U7XHJcbiAgICAgICAgd2hpbGUgKHBhcmVudCkge1xyXG4gICAgICAgICAgICBjb25zdCBmb3VuZE1hdGNoID0gcGFyZW50Lm1hdGNoZXMoc3BsaXRTZWxlY3Rvcltwb3NpdGlvbl0pO1xyXG4gICAgICAgICAgICBpZiAoZm91bmRNYXRjaCAmJiBwb3NpdGlvbiA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgZm91bmRFbGVtZW50ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChmb3VuZE1hdGNoKSB7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbi0tO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHBhcmVudCA9IGZpbmRQYXJlbnRPckhvc3QocGFyZW50LCByb290KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGZvdW5kRWxlbWVudDtcclxuICAgIH07XHJcblxyXG59XHJcblxyXG5mdW5jdGlvbiBzcGxpdEJ5Q2hhcmFjdGVyVW5sZXNzUXVvdGVkKHNlbGVjdG9yLCBjaGFyYWN0ZXIpIHtcclxuICAgIHJldHVybiBzZWxlY3Rvci5tYXRjaCgvXFxcXD8ufF4kL2cpLnJlZHVjZSgocCwgYykgPT4ge1xyXG4gICAgICAgIGlmIChjID09PSAnXCInICYmICFwLnNRdW90ZSkge1xyXG4gICAgICAgICAgICBwLnF1b3RlIF49IDE7XHJcbiAgICAgICAgICAgIHAuYVtwLmEubGVuZ3RoIC0gMV0gKz0gYztcclxuICAgICAgICB9IGVsc2UgaWYgKGMgPT09ICdcXCcnICYmICFwLnF1b3RlKSB7XHJcbiAgICAgICAgICAgIHAuc1F1b3RlIF49IDE7XHJcbiAgICAgICAgICAgIHAuYVtwLmEubGVuZ3RoIC0gMV0gKz0gYztcclxuXHJcbiAgICAgICAgfSBlbHNlIGlmICghcC5xdW90ZSAmJiAhcC5zUXVvdGUgJiYgYyA9PT0gY2hhcmFjdGVyKSB7XHJcbiAgICAgICAgICAgIHAuYS5wdXNoKCcnKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBwLmFbcC5hLmxlbmd0aCAtIDFdICs9IGM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBwO1xyXG4gICAgfSwgeyBhOiBbJyddIH0pLmE7XHJcbn1cclxuXHJcblxyXG5mdW5jdGlvbiBmaW5kUGFyZW50T3JIb3N0KGVsZW1lbnQsIHJvb3QpIHtcclxuICAgIGNvbnN0IHBhcmVudE5vZGUgPSBlbGVtZW50LnBhcmVudE5vZGU7XHJcbiAgICByZXR1cm4gKHBhcmVudE5vZGUgJiYgcGFyZW50Tm9kZS5ob3N0ICYmIHBhcmVudE5vZGUubm9kZVR5cGUgPT09IDExKSA/IHBhcmVudE5vZGUuaG9zdCA6IHBhcmVudE5vZGUgPT09IHJvb3QgPyBudWxsIDogcGFyZW50Tm9kZTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEZpbmRzIGFsbCBlbGVtZW50cyBvbiB0aGUgcGFnZSwgaW5jbHVzaXZlIG9mIHRob3NlIHdpdGhpbiBzaGFkb3cgcm9vdHMuXHJcbiAqIEBwYXJhbSB7c3RyaW5nPX0gc2VsZWN0b3IgU2ltcGxlIHNlbGVjdG9yIHRvIGZpbHRlciB0aGUgZWxlbWVudHMgYnkuIGUuZy4gJ2EnLCAnZGl2Lm1haW4nXHJcbiAqIEByZXR1cm4geyFBcnJheTxzdHJpbmc+fSBMaXN0IG9mIGFuY2hvciBocmVmcy5cclxuICogQGF1dGhvciBlYmlkZWxAIChFcmljIEJpZGVsbWFuKVxyXG4gKiBMaWNlbnNlIEFwYWNoZS0yLjBcclxuICovXHJcbmZ1bmN0aW9uIGNvbGxlY3RBbGxFbGVtZW50c0RlZXAoc2VsZWN0b3IgPSBudWxsLCByb290KSB7XHJcbiAgICBjb25zdCBhbGxFbGVtZW50cyA9IFtdO1xyXG5cclxuICAgIGNvbnN0IGZpbmRBbGxFbGVtZW50cyA9IGZ1bmN0aW9uKG5vZGVzKSB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIGVsOyBlbCA9IG5vZGVzW2ldOyArK2kpIHtcclxuICAgICAgICAgICAgYWxsRWxlbWVudHMucHVzaChlbCk7XHJcbiAgICAgICAgICAgIC8vIElmIHRoZSBlbGVtZW50IGhhcyBhIHNoYWRvdyByb290LCBkaWcgZGVlcGVyLlxyXG4gICAgICAgICAgICBpZiAoZWwuc2hhZG93Um9vdCkge1xyXG4gICAgICAgICAgICAgICAgZmluZEFsbEVsZW1lbnRzKGVsLnNoYWRvd1Jvb3QucXVlcnlTZWxlY3RvckFsbCgnKicpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH07XHJcbiAgICBpZihyb290LnNoYWRvd1Jvb3QpIHtcclxuICAgICAgICBmaW5kQWxsRWxlbWVudHMocm9vdC5zaGFkb3dSb290LnF1ZXJ5U2VsZWN0b3JBbGwoJyonKSk7XHJcbiAgICB9XHJcbiAgICBmaW5kQWxsRWxlbWVudHMocm9vdC5xdWVyeVNlbGVjdG9yQWxsKCcqJykpO1xyXG5cclxuICAgIHJldHVybiBzZWxlY3RvciA/IGFsbEVsZW1lbnRzLmZpbHRlcihlbCA9PiBlbC5tYXRjaGVzKHNlbGVjdG9yKSkgOiBhbGxFbGVtZW50cztcclxufSIsImV4cG9ydCBjb25zdCBjb21tYW5kcyA9IFtcbiAgJ2VtcHR5IHBhZ2UnLFxuICAnYmxhbmsgcGFnZScsXG4gICdjbGVhciBjYW52YXMnLFxuXVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbigpIHtcbiAgZG9jdW1lbnRcbiAgICAucXVlcnlTZWxlY3RvckFsbCgnYm9keSA+ICo6bm90KHZpcy1idWcpOm5vdChzY3JpcHQpJylcbiAgICAuZm9yRWFjaChub2RlID0+IG5vZGUucmVtb3ZlKCkpXG59XG4iLCJleHBvcnQgY29uc3QgY29tbWFuZHMgPSBbXG4gICdiYXJyZWwgcm9sbCcsXG4gICdkbyBhIGJhcnJlbCByb2xsJyxcbl1cblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24oKSB7XG4gIGRvY3VtZW50LmJvZHkuc3R5bGUudHJhbnNmb3JtT3JpZ2luID0gJ2NlbnRlciA1MHZoJ1xuICBcbiAgYXdhaXQgZG9jdW1lbnQuYm9keS5hbmltYXRlKFtcbiAgICB7IHRyYW5zZm9ybTogJ3JvdGF0ZVooMCknIH0sXG4gICAgeyB0cmFuc2Zvcm06ICdyb3RhdGVaKDF0dXJuKScgfSxcbiAgXSwgeyBkdXJhdGlvbjogMTUwMCB9KS5maW5pc2hlZFxuXG4gIGRvY3VtZW50LmJvZHkuc3R5bGUudHJhbnNmb3JtT3JpZ2luID0gJydcbn0iLCJpbXBvcnQgeyBsb2FkU3R5bGVzIH0gZnJvbSAnLi4vdXRpbGl0aWVzL3N0eWxlcy5qcydcblxuZXhwb3J0IGNvbnN0IGNvbW1hbmRzID0gW1xuICAncGVzdGljaWRlJyxcbl1cblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24oKSB7XG4gIGF3YWl0IGxvYWRTdHlsZXMoWydodHRwczovL3VucGtnLmNvbS9wZXN0aWNpZGVAMS4zLjEvY3NzL3Blc3RpY2lkZS5taW4uY3NzJ10pXG59IiwiaW1wb3J0IHsgbG9hZFN0eWxlcyB9IGZyb20gJy4uL3V0aWxpdGllcy9zdHlsZXMuanMnXG5cbmV4cG9ydCBjb25zdCBjb21tYW5kcyA9IFtcbiAgJ3RyYXNoeScsXG4gICdjb25zdHJ1Y3QnLFxuXVxuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbigpIHtcbiAgYXdhaXQgbG9hZFN0eWxlcyhbJ2h0dHBzOi8vY2RuLmpzZGVsaXZyLm5ldC9naC90Ny9jb25zdHJ1Y3QuY3NzQG1hc3Rlci9jc3MvY29uc3RydWN0LmJveGVzLmNzcyddKVxufSIsImltcG9ydCB7IGxvYWRTdHlsZXMgfSBmcm9tICcuLi91dGlsaXRpZXMvc3R5bGVzLmpzJ1xuXG5leHBvcnQgY29uc3QgY29tbWFuZHMgPSBbXG4gICdkZWJ1ZyB0cmFzaHknLFxuICAnZGVidWcgY29uc3RydWN0Jyxcbl1cblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24oKSB7XG4gIGF3YWl0IGxvYWRTdHlsZXMoWydodHRwczovL2Nkbi5qc2RlbGl2ci5uZXQvZ2gvdDcvY29uc3RydWN0LmNzc0BtYXN0ZXIvY3NzL2NvbnN0cnVjdC5kZWJ1Zy5jc3MnXSlcbn0iLCJleHBvcnQgY29uc3QgY29tbWFuZHMgPSBbXG4gICd3aXJlZnJhbWUnLFxuICAnYmx1ZXByaW50Jyxcbl1cblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24oKSB7XG4gIGNvbnN0IHN0eWxlcyA9IGBcbiAgICAqOm5vdChwYXRoKTpub3QoZykge1xuICAgICAgY29sb3I6IGhzbGEoMjEwLCAxMDAlLCAxMDAlLCAwLjkpICFpbXBvcnRhbnQ7XG4gICAgICBiYWNrZ3JvdW5kOiBoc2xhKDIxMCwgMTAwJSwgNTAlLCAwLjUpICFpbXBvcnRhbnQ7XG4gICAgICBvdXRsaW5lOiBzb2xpZCAwLjI1cmVtIGhzbGEoMjEwLCAxMDAlLCAxMDAlLCAwLjUpICFpbXBvcnRhbnQ7XG4gICAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG4gICAgfVxuICBgXG5cbiAgY29uc3Qgc3R5bGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzdHlsZScpXG4gIHN0eWxlLnRleHRDb250ZW50ID0gc3R5bGVzXG4gIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoc3R5bGUpXG59IiwiZXhwb3J0IGNvbnN0IGNvbW1hbmRzID0gW1xuICAnc2tlbGV0b24nLFxuICAnb3V0bGluZScsXG5dXG5cbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uKCkge1xuICBjb25zdCBzdHlsZXMgPSBgXG4gICAgKjpub3QocGF0aCk6bm90KGcpIHtcbiAgICAgIGNvbG9yOiBoc2woMCwgMCUsIDAlKSAhaW1wb3J0YW50O1xuICAgICAgdGV4dC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgICAgIGJhY2tncm91bmQ6IGhzbCgwLCAwJSwgMTAwJSkgIWltcG9ydGFudDtcbiAgICAgIG91dGxpbmU6IDFweCBzb2xpZCBoc2xhKDAsIDAlLCAwJSwgMC41KSAhaW1wb3J0YW50O1xuICAgICAgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAgICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICAgIH1cbiAgYFxuXG4gIGNvbnN0IHN0eWxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKVxuICBzdHlsZS50ZXh0Q29udGVudCA9IHN0eWxlc1xuICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHN0eWxlKVxufSIsIi8vIGh0dHBzOi8vZ2lzdC5naXRodWIuY29tL2FkZHlvc21hbmkvZmQzOTk5ZWE3ZmNlMjQyNzU2YjFcbmV4cG9ydCBjb25zdCBjb21tYW5kcyA9IFtcbiAgJ3RhZyBkZWJ1Z2dlcicsXG4gICdvc21hbmknLFxuXVxuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbigpIHtcbiAgZm9yIChpID0gMDsgQSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJyonKVtpKytdOylcbiAgICBBLnN0eWxlLm91dGxpbmUgPSBgc29saWQgaHNsKCR7KEErQSkubGVuZ3RoKjl9LDk5JSw1MCUpIDFweGBcbn0iLCIvLyBodHRwOi8vaGV5ZG9ud29ya3MuY29tL3JldmVuZ2VfY3NzX2Jvb2ttYXJrbGV0L1xuXG5pbXBvcnQgeyBsb2FkU3R5bGVzIH0gZnJvbSAnLi4vdXRpbGl0aWVzL3N0eWxlcy5qcydcblxuZXhwb3J0IGNvbnN0IGNvbW1hbmRzID0gW1xuICAncmV2ZW5nZScsXG4gICdyZXZlbmdlLmNzcycsXG4gICdoZXlkb24nLFxuXVxuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbigpIHtcbiAgYXdhaXQgbG9hZFN0eWxlcyhbJ2h0dHBzOi8vY2RuLmpzZGVsaXZyLm5ldC9naC9IZXlkb24vUkVWRU5HRS5DU1NAbWFzdGVyL3JldmVuZ2UuY3NzJ10pXG59IiwiaW1wb3J0IHsgY29tbWFuZHMgYXMgYmxhbmtfcGFnZV9jb21tYW5kcywgZGVmYXVsdCBhcyBCbGFua1BhZ2VQbHVnaW4gfSBmcm9tICcuL2JsYW5rLXBhZ2UnXG5pbXBvcnQgeyBjb21tYW5kcyBhcyBiYXJyZWxfcm9sbF9jb21tYW5kcywgZGVmYXVsdCBhcyBCYXJyZWxSb2xsUGx1Z2luIH0gZnJvbSAnLi9iYXJyZWwtcm9sbCdcbmltcG9ydCB7IGNvbW1hbmRzIGFzIHBlc3RpY2lkZV9jb21tYW5kcywgZGVmYXVsdCBhcyBQZXN0aWNpZGVQbHVnaW4gfSBmcm9tICcuL3Blc3RpY2lkZSdcbmltcG9ydCB7IGNvbW1hbmRzIGFzIGNvbnN0cnVjdF9jb21tYW5kcywgZGVmYXVsdCBhcyBDb25zdHJ1Y3RQbHVnaW4gfSBmcm9tICcuL2NvbnN0cnVjdCdcbmltcG9ydCB7IGNvbW1hbmRzIGFzIGNvbnN0cnVjdF9kZWJ1Z19jb21tYW5kcywgZGVmYXVsdCBhcyBDb25zdHJ1Y3REZWJ1Z1BsdWdpbiB9IGZyb20gJy4vY29uc3RydWN0LmRlYnVnJ1xuaW1wb3J0IHsgY29tbWFuZHMgYXMgd2lyZWZyYW1lX2NvbW1hbmRzLCBkZWZhdWx0IGFzIFdpcmVmcmFtZVBsdWdpbiB9IGZyb20gJy4vd2lyZWZyYW1lJ1xuaW1wb3J0IHsgY29tbWFuZHMgYXMgc2tlbGV0b25fY29tbWFuZHMsIGRlZmF1bHQgYXMgU2tlbGV0b25QbHVnaW4gfSBmcm9tICcuL3NrZWxldG9uJ1xuaW1wb3J0IHsgY29tbWFuZHMgYXMgdGFnX2RlYnVnZ2VyX2NvbW1hbmRzLCBkZWZhdWx0IGFzIFRhZ0RlYnVnZ2VyUGx1Z2luIH0gZnJvbSAnLi90YWctZGVidWdnZXInXG5pbXBvcnQgeyBjb21tYW5kcyBhcyByZXZlbmdlX2NvbW1hbmRzLCBkZWZhdWx0IGFzIFJldmVuZ2VQbHVnaW4gfSBmcm9tICcuL3JldmVuZ2UnXG5cbmNvbnN0IGNvbW1hbmRzVG9IYXNoID0gKHBsdWdpbl9jb21tYW5kcywgcGx1Z2luX2ZuKSA9PlxuICBwbHVnaW5fY29tbWFuZHMucmVkdWNlKChjb21tYW5kcywgY29tbWFuZCkgPT5cbiAgICBPYmplY3QuYXNzaWduKGNvbW1hbmRzLCB7W2AvJHtjb21tYW5kfWBdOnBsdWdpbl9mbn0pXG4gICwge30pXG5cbmV4cG9ydCBjb25zdCBQbHVnaW5SZWdpc3RyeSA9IG5ldyBNYXAoT2JqZWN0LmVudHJpZXMoe1xuICAuLi5jb21tYW5kc1RvSGFzaChibGFua19wYWdlX2NvbW1hbmRzLCBCbGFua1BhZ2VQbHVnaW4pLFxuICAuLi5jb21tYW5kc1RvSGFzaChiYXJyZWxfcm9sbF9jb21tYW5kcywgQmFycmVsUm9sbFBsdWdpbiksXG4gIC4uLmNvbW1hbmRzVG9IYXNoKHBlc3RpY2lkZV9jb21tYW5kcywgUGVzdGljaWRlUGx1Z2luKSxcbiAgLi4uY29tbWFuZHNUb0hhc2goY29uc3RydWN0X2NvbW1hbmRzLCBDb25zdHJ1Y3RQbHVnaW4pLFxuICAuLi5jb21tYW5kc1RvSGFzaChjb25zdHJ1Y3RfZGVidWdfY29tbWFuZHMsIENvbnN0cnVjdERlYnVnUGx1Z2luKSxcbiAgLi4uY29tbWFuZHNUb0hhc2god2lyZWZyYW1lX2NvbW1hbmRzLCBXaXJlZnJhbWVQbHVnaW4pLFxuICAuLi5jb21tYW5kc1RvSGFzaChza2VsZXRvbl9jb21tYW5kcywgU2tlbGV0b25QbHVnaW4pLFxuICAuLi5jb21tYW5kc1RvSGFzaCh0YWdfZGVidWdnZXJfY29tbWFuZHMsIFRhZ0RlYnVnZ2VyUGx1Z2luKSxcbiAgLi4uY29tbWFuZHNUb0hhc2gocmV2ZW5nZV9jb21tYW5kcywgUmV2ZW5nZVBsdWdpbiksXG59KSlcblxuZXhwb3J0IGNvbnN0IFBsdWdpbkhpbnRzID0gW1xuICBibGFua19wYWdlX2NvbW1hbmRzWzBdLFxuICBiYXJyZWxfcm9sbF9jb21tYW5kc1swXSxcbiAgcGVzdGljaWRlX2NvbW1hbmRzWzBdLFxuICBjb25zdHJ1Y3RfY29tbWFuZHNbMF0sXG4gIGNvbnN0cnVjdF9kZWJ1Z19jb21tYW5kc1swXSxcbiAgd2lyZWZyYW1lX2NvbW1hbmRzWzBdLFxuICBza2VsZXRvbl9jb21tYW5kc1swXSxcbiAgdGFnX2RlYnVnZ2VyX2NvbW1hbmRzWzBdLFxuICByZXZlbmdlX2NvbW1hbmRzWzBdLFxuXS5tYXAoY29tbWFuZCA9PiBgLyR7Y29tbWFuZH1gKVxuIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCB7IHF1ZXJ5U2VsZWN0b3JBbGxEZWVwIH0gZnJvbSAncXVlcnktc2VsZWN0b3Itc2hhZG93LWRvbSdcbmltcG9ydCB7IFBsdWdpblJlZ2lzdHJ5LCBQbHVnaW5IaW50cyB9IGZyb20gJy4uL3BsdWdpbnMvX3JlZ2lzdHJ5J1xuXG5sZXQgU2VsZWN0b3JFbmdpbmVcblxuLy8gY3JlYXRlIGlucHV0XG5jb25zdCBzZWFyY2hfYmFzZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG5zZWFyY2hfYmFzZS5jbGFzc0xpc3QuYWRkKCdzZWFyY2gnKVxuc2VhcmNoX2Jhc2UuaW5uZXJIVE1MID0gYFxuICA8aW5wdXQgbGlzdD1cInZpc2J1Zy1wbHVnaW5zXCIgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cImV4OiBpbWFnZXMsIC5idG4sIGJ1dHRvbiwgdGV4dCwgLi4uXCIvPlxuICA8ZGF0YWxpc3QgaWQ9XCJ2aXNidWctcGx1Z2luc1wiPlxuICAgICR7UGx1Z2luSGludHMucmVkdWNlKChvcHRpb25zLCBjb21tYW5kKSA9PlxuICAgICAgb3B0aW9ucyArPSBgPG9wdGlvbiB2YWx1ZT1cIiR7Y29tbWFuZH1cIj5wbHVnaW48L29wdGlvbj5gXG4gICAgLCAnJyl9XG4gICAgPG9wdGlvbiB2YWx1ZT1cImgxLCBoMiwgaDMsIC5nZXQtbXVsdGlwbGVcIj5leGFtcGxlPC9vcHRpb24+XG4gICAgPG9wdGlvbiB2YWx1ZT1cIm5hdiA+IGE6Zmlyc3QtY2hpbGRcIj5leGFtcGxlPC9vcHRpb24+XG4gICAgPG9wdGlvbiB2YWx1ZT1cIiNnZXQtYnktaWRcIj5leGFtcGxlPC9vcHRpb24+XG4gICAgPG9wdGlvbiB2YWx1ZT1cIi5nZXQtYnkuY2xhc3MtbmFtZXNcIj5leGFtcGxlPC9vcHRpb24+XG4gICAgPG9wdGlvbiB2YWx1ZT1cImltYWdlc1wiPmFsaWFzPC9vcHRpb24+XG4gICAgPG9wdGlvbiB2YWx1ZT1cInRleHRcIj5hbGlhczwvb3B0aW9uPlxuICA8L2RhdGFsaXN0PlxuYFxuXG5jb25zdCBzZWFyY2ggICAgICAgID0gJChzZWFyY2hfYmFzZSlcbmNvbnN0IHNlYXJjaElucHV0ICAgPSAkKCdpbnB1dCcsIHNlYXJjaF9iYXNlKVxuXG5jb25zdCBzaG93U2VhcmNoQmFyID0gKCkgPT4gc2VhcmNoLmF0dHIoJ3N0eWxlJywgJ2Rpc3BsYXk6YmxvY2snKVxuY29uc3QgaGlkZVNlYXJjaEJhciA9ICgpID0+IHNlYXJjaC5hdHRyKCdzdHlsZScsICdkaXNwbGF5Om5vbmUnKVxuY29uc3Qgc3RvcEJ1YmJsaW5nICA9IGUgPT4gZS5rZXkgIT0gJ0VzY2FwZScgJiYgZS5zdG9wUHJvcGFnYXRpb24oKVxuXG5leHBvcnQgZnVuY3Rpb24gU2VhcmNoKG5vZGUpIHtcbiAgaWYgKG5vZGUpIG5vZGVbMF0uYXBwZW5kQ2hpbGQoc2VhcmNoWzBdKVxuXG4gIGNvbnN0IG9uUXVlcnkgPSBlID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG5cbiAgICBjb25zdCBxdWVyeSA9IGUudGFyZ2V0LnZhbHVlXG5cbiAgICB3aW5kb3cucmVxdWVzdElkbGVDYWxsYmFjayhfID0+XG4gICAgICBxdWVyeVBhZ2UocXVlcnkpKVxuICB9XG5cbiAgc2VhcmNoSW5wdXQub24oJ2lucHV0Jywgb25RdWVyeSlcbiAgc2VhcmNoSW5wdXQub24oJ2tleWRvd24nLCBzdG9wQnViYmxpbmcpXG4gIC8vIHNlYXJjaElucHV0Lm9uKCdibHVyJywgaGlkZVNlYXJjaEJhcilcblxuICBzaG93U2VhcmNoQmFyKClcbiAgc2VhcmNoSW5wdXRbMF0uZm9jdXMoKVxuXG4gIC8vIGhvdGtleXMoJ2VzY2FwZSxlc2MnLCAoZSwgaGFuZGxlcikgPT4ge1xuICAvLyAgIGhpZGVTZWFyY2hCYXIoKVxuICAvLyAgIGhvdGtleXMudW5iaW5kKCdlc2NhcGUsZXNjJylcbiAgLy8gfSlcblxuICByZXR1cm4gKCkgPT4ge1xuICAgIGhpZGVTZWFyY2hCYXIoKVxuICAgIHNlYXJjaElucHV0Lm9mZignb25pbnB1dCcsIG9uUXVlcnkpXG4gICAgc2VhcmNoSW5wdXQub2ZmKCdrZXlkb3duJywgc3RvcEJ1YmJsaW5nKVxuICAgIHNlYXJjaElucHV0Lm9mZignYmx1cicsIGhpZGVTZWFyY2hCYXIpXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHByb3ZpZGVTZWxlY3RvckVuZ2luZShFbmdpbmUpIHtcbiAgU2VsZWN0b3JFbmdpbmUgPSBFbmdpbmVcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHF1ZXJ5UGFnZShxdWVyeSwgZm4pIHtcbiAgLy8gdG9kbzogc2hvdWxkIHN0YXNoIGEgY2xlYW51cCBtZXRob2QgdG8gYmUgY2FsbGVkIHdoZW4gcXVlcnkgZG9lc250IG1hdGNoXG4gIGlmIChQbHVnaW5SZWdpc3RyeS5oYXMocXVlcnkpKVxuICAgIHJldHVybiBQbHVnaW5SZWdpc3RyeS5nZXQocXVlcnkpKHF1ZXJ5KVxuXG4gIGlmIChxdWVyeSA9PSAnbGlua3MnKSAgICAgcXVlcnkgPSAnYSdcbiAgaWYgKHF1ZXJ5ID09ICdidXR0b25zJykgICBxdWVyeSA9ICdidXR0b24nXG4gIGlmIChxdWVyeSA9PSAnaW1hZ2VzJykgICAgcXVlcnkgPSAnaW1nJ1xuICBpZiAocXVlcnkgPT0gJ3RleHQnKSAgICAgIHF1ZXJ5ID0gJ3AsY2FwdGlvbixhLGgxLGgyLGgzLGg0LGg1LGg2LHNtYWxsLGRhdGUsdGltZSxsaSxkdCxkZCdcblxuICBpZiAoIXF1ZXJ5KSByZXR1cm4gU2VsZWN0b3JFbmdpbmUudW5zZWxlY3RfYWxsKClcbiAgaWYgKHF1ZXJ5ID09ICcuJyB8fCBxdWVyeSA9PSAnIycgfHwgcXVlcnkudHJpbSgpLmVuZHNXaXRoKCcsJykpIHJldHVyblxuXG4gIHRyeSB7XG4gICAgbGV0IG1hdGNoZXMgPSBxdWVyeVNlbGVjdG9yQWxsRGVlcChxdWVyeSArICc6bm90KHZpcy1idWcpOm5vdChzY3JpcHQpOm5vdChob3RrZXktbWFwKTpub3QoLnZpc2J1Zy1tZXRhdGlwKTpub3QodmlzYnVnLWxhYmVsKTpub3QodmlzYnVnLWhhbmRsZXMpJylcbiAgICBpZiAoIW1hdGNoZXMubGVuZ3RoKSBtYXRjaGVzID0gcXVlcnlTZWxlY3RvckFsbERlZXAocXVlcnkpXG4gICAgaWYgKCFmbikgU2VsZWN0b3JFbmdpbmUudW5zZWxlY3RfYWxsKClcbiAgICBpZiAobWF0Y2hlcy5sZW5ndGgpXG4gICAgICBtYXRjaGVzLmZvckVhY2goZWwgPT5cbiAgICAgICAgZm5cbiAgICAgICAgICA/IGZuKGVsKVxuICAgICAgICAgIDogU2VsZWN0b3JFbmdpbmUuc2VsZWN0KGVsKSlcbiAgfVxuICBjYXRjaCAoZXJyKSB7fVxufVxuIiwiY29uc3Qgc3RhdGUgPSB7XG4gIGRpc3RhbmNlczogIFtdLFxuICB0YXJnZXQ6ICAgICBudWxsLFxufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlTWVhc3VyZW1lbnRzKHskYW5jaG9yLCAkdGFyZ2V0fSkge1xuICBpZiAoc3RhdGUudGFyZ2V0ID09ICR0YXJnZXQgJiYgc3RhdGUuZGlzdGFuY2VzLmxlbmd0aCkgcmV0dXJuXG4gIGVsc2Ugc3RhdGUudGFyZ2V0ID0gJHRhcmdldFxuXG4gIGlmIChzdGF0ZS5kaXN0YW5jZXMubGVuZ3RoKSBjbGVhck1lYXN1cmVtZW50cygpXG5cbiAgY29uc3QgYW5jaG9yQm91bmRzID0gJGFuY2hvci5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKVxuICBjb25zdCB0YXJnZXRCb3VuZHMgPSAkdGFyZ2V0LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpXG5cbiAgY29uc3QgbWVhc3VyZW1lbnRzID0gW11cblxuICAvLyByaWdodFxuICBpZiAoYW5jaG9yQm91bmRzLnJpZ2h0IDwgdGFyZ2V0Qm91bmRzLmxlZnQpIHtcbiAgICBtZWFzdXJlbWVudHMucHVzaCh7XG4gICAgICB4OiBhbmNob3JCb3VuZHMucmlnaHQsXG4gICAgICB5OiBhbmNob3JCb3VuZHMudG9wICsgKGFuY2hvckJvdW5kcy5oZWlnaHQgLyAyKSxcbiAgICAgIGQ6IHRhcmdldEJvdW5kcy5sZWZ0IC0gYW5jaG9yQm91bmRzLnJpZ2h0LFxuICAgICAgcTogJ3JpZ2h0JyxcbiAgICB9KVxuICB9XG4gIGlmIChhbmNob3JCb3VuZHMucmlnaHQgPCB0YXJnZXRCb3VuZHMucmlnaHQgJiYgYW5jaG9yQm91bmRzLnJpZ2h0ID4gdGFyZ2V0Qm91bmRzLmxlZnQpIHtcbiAgICBtZWFzdXJlbWVudHMucHVzaCh7XG4gICAgICB4OiBhbmNob3JCb3VuZHMucmlnaHQsXG4gICAgICB5OiBhbmNob3JCb3VuZHMudG9wICsgKGFuY2hvckJvdW5kcy5oZWlnaHQgLyAyKSxcbiAgICAgIGQ6IHRhcmdldEJvdW5kcy5yaWdodCAtIGFuY2hvckJvdW5kcy5yaWdodCxcbiAgICAgIHE6ICdyaWdodCcsXG4gICAgfSlcbiAgfVxuXG4gIC8vIGxlZnRcbiAgaWYgKGFuY2hvckJvdW5kcy5sZWZ0ID4gdGFyZ2V0Qm91bmRzLnJpZ2h0KSB7XG4gICAgbWVhc3VyZW1lbnRzLnB1c2goe1xuICAgICAgeDogdGFyZ2V0Qm91bmRzLnJpZ2h0LFxuICAgICAgeTogYW5jaG9yQm91bmRzLnRvcCArIChhbmNob3JCb3VuZHMuaGVpZ2h0IC8gMiksXG4gICAgICBkOiBhbmNob3JCb3VuZHMubGVmdCAtIHRhcmdldEJvdW5kcy5yaWdodCxcbiAgICAgIHE6ICdsZWZ0JyxcbiAgICB9KVxuICB9XG4gIGlmIChhbmNob3JCb3VuZHMubGVmdCA+IHRhcmdldEJvdW5kcy5sZWZ0ICYmIGFuY2hvckJvdW5kcy5sZWZ0IDwgdGFyZ2V0Qm91bmRzLnJpZ2h0KSB7XG4gICAgbWVhc3VyZW1lbnRzLnB1c2goe1xuICAgICAgeDogdGFyZ2V0Qm91bmRzLmxlZnQsXG4gICAgICB5OiBhbmNob3JCb3VuZHMudG9wICsgKGFuY2hvckJvdW5kcy5oZWlnaHQgLyAyKSxcbiAgICAgIGQ6IGFuY2hvckJvdW5kcy5sZWZ0IC0gdGFyZ2V0Qm91bmRzLmxlZnQsXG4gICAgICBxOiAnbGVmdCcsXG4gICAgfSlcbiAgfVxuXG4gIC8vIHRvcFxuICBpZiAoYW5jaG9yQm91bmRzLnRvcCA+IHRhcmdldEJvdW5kcy5ib3R0b20pIHtcbiAgICBtZWFzdXJlbWVudHMucHVzaCh7XG4gICAgICB4OiBhbmNob3JCb3VuZHMubGVmdCArIChhbmNob3JCb3VuZHMud2lkdGggLyAyKSxcbiAgICAgIHk6IHRhcmdldEJvdW5kcy5ib3R0b20sXG4gICAgICBkOiBhbmNob3JCb3VuZHMudG9wIC0gdGFyZ2V0Qm91bmRzLmJvdHRvbSxcbiAgICAgIHE6ICd0b3AnLFxuICAgICAgdjogdHJ1ZSxcbiAgICB9KVxuICB9XG4gIGlmIChhbmNob3JCb3VuZHMudG9wID4gdGFyZ2V0Qm91bmRzLnRvcCAmJiBhbmNob3JCb3VuZHMudG9wIDwgdGFyZ2V0Qm91bmRzLmJvdHRvbSkge1xuICAgIG1lYXN1cmVtZW50cy5wdXNoKHtcbiAgICAgIHg6IGFuY2hvckJvdW5kcy5sZWZ0ICsgKGFuY2hvckJvdW5kcy53aWR0aCAvIDIpLFxuICAgICAgeTogdGFyZ2V0Qm91bmRzLnRvcCxcbiAgICAgIGQ6IGFuY2hvckJvdW5kcy50b3AgLSB0YXJnZXRCb3VuZHMudG9wLFxuICAgICAgcTogJ3RvcCcsXG4gICAgICB2OiB0cnVlLFxuICAgIH0pXG4gIH1cblxuICAvLyBib3R0b21cbiAgaWYgKGFuY2hvckJvdW5kcy5ib3R0b20gPCB0YXJnZXRCb3VuZHMudG9wKSB7XG4gICAgbWVhc3VyZW1lbnRzLnB1c2goe1xuICAgICAgeDogYW5jaG9yQm91bmRzLmxlZnQgKyAoYW5jaG9yQm91bmRzLndpZHRoIC8gMiksXG4gICAgICB5OiBhbmNob3JCb3VuZHMuYm90dG9tLFxuICAgICAgZDogdGFyZ2V0Qm91bmRzLnRvcCAtIGFuY2hvckJvdW5kcy5ib3R0b20sXG4gICAgICBxOiAnYm90dG9tJyxcbiAgICAgIHY6IHRydWUsXG4gICAgfSlcbiAgfVxuICBpZiAoYW5jaG9yQm91bmRzLmJvdHRvbSA8IHRhcmdldEJvdW5kcy5ib3R0b20gJiYgYW5jaG9yQm91bmRzLmJvdHRvbSA+IHRhcmdldEJvdW5kcy50b3ApIHtcbiAgICBtZWFzdXJlbWVudHMucHVzaCh7XG4gICAgICB4OiBhbmNob3JCb3VuZHMubGVmdCArIChhbmNob3JCb3VuZHMud2lkdGggLyAyKSxcbiAgICAgIHk6IGFuY2hvckJvdW5kcy5ib3R0b20sXG4gICAgICBkOiB0YXJnZXRCb3VuZHMuYm90dG9tIC0gYW5jaG9yQm91bmRzLmJvdHRvbSxcbiAgICAgIHE6ICdib3R0b20nLFxuICAgICAgdjogdHJ1ZSxcbiAgICB9KVxuICB9XG5cbiAgLy8gaW5zaWRlIGxlZnQvcmlnaHRcbiAgaWYgKGFuY2hvckJvdW5kcy5yaWdodCA+IHRhcmdldEJvdW5kcy5yaWdodCAmJiBhbmNob3JCb3VuZHMubGVmdCA8IHRhcmdldEJvdW5kcy5sZWZ0KSB7XG4gICAgbWVhc3VyZW1lbnRzLnB1c2goe1xuICAgICAgeDogdGFyZ2V0Qm91bmRzLnJpZ2h0LFxuICAgICAgeTogYW5jaG9yQm91bmRzLnRvcCArIChhbmNob3JCb3VuZHMuaGVpZ2h0IC8gMiksXG4gICAgICBkOiBhbmNob3JCb3VuZHMucmlnaHQgLSB0YXJnZXRCb3VuZHMucmlnaHQsXG4gICAgICBxOiAnbGVmdCcsXG4gICAgfSlcbiAgICBtZWFzdXJlbWVudHMucHVzaCh7XG4gICAgICB4OiBhbmNob3JCb3VuZHMubGVmdCxcbiAgICAgIHk6IGFuY2hvckJvdW5kcy50b3AgKyAoYW5jaG9yQm91bmRzLmhlaWdodCAvIDIpLFxuICAgICAgZDogdGFyZ2V0Qm91bmRzLmxlZnQgLSBhbmNob3JCb3VuZHMubGVmdCxcbiAgICAgIHE6ICdyaWdodCcsXG4gICAgfSlcbiAgfVxuXG4gIC8vIGluc2lkZSB0b3AvcmlnaHRcbiAgaWYgKGFuY2hvckJvdW5kcy50b3AgPCB0YXJnZXRCb3VuZHMudG9wICYmIGFuY2hvckJvdW5kcy5ib3R0b20gPiB0YXJnZXRCb3VuZHMuYm90dG9tKSB7XG4gICAgbWVhc3VyZW1lbnRzLnB1c2goe1xuICAgICAgeDogYW5jaG9yQm91bmRzLmxlZnQgKyAoYW5jaG9yQm91bmRzLndpZHRoIC8gMiksXG4gICAgICB5OiBhbmNob3JCb3VuZHMudG9wLFxuICAgICAgZDogdGFyZ2V0Qm91bmRzLnRvcCAtIGFuY2hvckJvdW5kcy50b3AsXG4gICAgICBxOiAnYm90dG9tJyxcbiAgICAgIHY6IHRydWUsXG4gICAgfSlcbiAgICBtZWFzdXJlbWVudHMucHVzaCh7XG4gICAgICB4OiBhbmNob3JCb3VuZHMubGVmdCArIChhbmNob3JCb3VuZHMud2lkdGggLyAyKSxcbiAgICAgIHk6IHRhcmdldEJvdW5kcy5ib3R0b20sXG4gICAgICBkOiBhbmNob3JCb3VuZHMuYm90dG9tIC0gdGFyZ2V0Qm91bmRzLmJvdHRvbSxcbiAgICAgIHE6ICd0b3AnLFxuICAgICAgdjogdHJ1ZSxcbiAgICB9KVxuICB9XG5cbiAgLy8gY3JlYXRlIGN1c3RvbSBlbGVtZW50cyBmb3IgYWxsIGNyZWF0ZWQgbWVhc3VyZW1lbnRzXG4gIG1lYXN1cmVtZW50c1xuICAgIC5tYXAobWVhc3VyZW1lbnQgPT4gT2JqZWN0LmFzc2lnbihtZWFzdXJlbWVudCwge1xuICAgICAgZDogTWF0aC5yb3VuZChtZWFzdXJlbWVudC5kLnRvRml4ZWQoMSkgKiAxMDApIC8gMTAwXG4gICAgfSkpXG4gICAgLmZvckVhY2gobWVhc3VyZW1lbnQgPT4ge1xuICAgICAgY29uc3QgJG1lYXN1cmVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndmlzYnVnLWRpc3RhbmNlJylcblxuICAgICAgJG1lYXN1cmVtZW50LnBvc2l0aW9uID0ge1xuICAgICAgICBsaW5lX21vZGVsOiAgICAgbWVhc3VyZW1lbnQsXG4gICAgICAgIG5vZGVfbGFiZWxfaWQ6ICBzdGF0ZS5kaXN0YW5jZXMubGVuZ3RoLFxuICAgICAgfVxuXG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKCRtZWFzdXJlbWVudClcbiAgICAgIHN0YXRlLmRpc3RhbmNlc1tzdGF0ZS5kaXN0YW5jZXMubGVuZ3RoXSA9ICRtZWFzdXJlbWVudFxuICAgIH0pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjbGVhck1lYXN1cmVtZW50cygpIHtcbiAgc3RhdGUuZGlzdGFuY2VzLmZvckVhY2gobm9kZSA9PiBub2RlLnJlbW92ZSgpKVxuICBzdGF0ZS5kaXN0YW5jZXMgPSBbXVxufVxuIiwiLyoqXG4gKiBUYWtlIGlucHV0IGZyb20gWzAsIG5dIGFuZCByZXR1cm4gaXQgYXMgWzAsIDFdXG4gKiBAaGlkZGVuXG4gKi9cbmZ1bmN0aW9uIGJvdW5kMDEobiwgbWF4KSB7XG4gICAgaWYgKGlzT25lUG9pbnRaZXJvKG4pKSB7XG4gICAgICAgIG4gPSAnMTAwJSc7XG4gICAgfVxuICAgIGNvbnN0IHByb2Nlc3NQZXJjZW50ID0gaXNQZXJjZW50YWdlKG4pO1xuICAgIG4gPSBtYXggPT09IDM2MCA/IG4gOiBNYXRoLm1pbihtYXgsIE1hdGgubWF4KDAsIHBhcnNlRmxvYXQobikpKTtcbiAgICAvLyBBdXRvbWF0aWNhbGx5IGNvbnZlcnQgcGVyY2VudGFnZSBpbnRvIG51bWJlclxuICAgIGlmIChwcm9jZXNzUGVyY2VudCkge1xuICAgICAgICBuID0gcGFyc2VJbnQoU3RyaW5nKG4gKiBtYXgpLCAxMCkgLyAxMDA7XG4gICAgfVxuICAgIC8vIEhhbmRsZSBmbG9hdGluZyBwb2ludCByb3VuZGluZyBlcnJvcnNcbiAgICBpZiAoTWF0aC5hYnMobiAtIG1heCkgPCAwLjAwMDAwMSkge1xuICAgICAgICByZXR1cm4gMTtcbiAgICB9XG4gICAgLy8gQ29udmVydCBpbnRvIFswLCAxXSByYW5nZSBpZiBpdCBpc24ndCBhbHJlYWR5XG4gICAgaWYgKG1heCA9PT0gMzYwKSB7XG4gICAgICAgIC8vIElmIG4gaXMgYSBodWUgZ2l2ZW4gaW4gZGVncmVlcyxcbiAgICAgICAgLy8gd3JhcCBhcm91bmQgb3V0LW9mLXJhbmdlIHZhbHVlcyBpbnRvIFswLCAzNjBdIHJhbmdlXG4gICAgICAgIC8vIHRoZW4gY29udmVydCBpbnRvIFswLCAxXS5cbiAgICAgICAgbiA9IChuIDwgMCA/IG4gJSBtYXggKyBtYXggOiBuICUgbWF4KSAvIHBhcnNlRmxvYXQoU3RyaW5nKG1heCkpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgLy8gSWYgbiBub3QgYSBodWUgZ2l2ZW4gaW4gZGVncmVlc1xuICAgICAgICAvLyBDb252ZXJ0IGludG8gWzAsIDFdIHJhbmdlIGlmIGl0IGlzbid0IGFscmVhZHkuXG4gICAgICAgIG4gPSAobiAlIG1heCkgLyBwYXJzZUZsb2F0KFN0cmluZyhtYXgpKTtcbiAgICB9XG4gICAgcmV0dXJuIG47XG59XG4vKipcbiAqIEZvcmNlIGEgbnVtYmVyIGJldHdlZW4gMCBhbmQgMVxuICogQGhpZGRlblxuICovXG5mdW5jdGlvbiBjbGFtcDAxKHZhbCkge1xuICAgIHJldHVybiBNYXRoLm1pbigxLCBNYXRoLm1heCgwLCB2YWwpKTtcbn1cbi8qKlxuICogTmVlZCB0byBoYW5kbGUgMS4wIGFzIDEwMCUsIHNpbmNlIG9uY2UgaXQgaXMgYSBudW1iZXIsIHRoZXJlIGlzIG5vIGRpZmZlcmVuY2UgYmV0d2VlbiBpdCBhbmQgMVxuICogPGh0dHA6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvNzQyMjA3Mi9qYXZhc2NyaXB0LWhvdy10by1kZXRlY3QtbnVtYmVyLWFzLWEtZGVjaW1hbC1pbmNsdWRpbmctMS0wPlxuICogQGhpZGRlblxuICovXG5mdW5jdGlvbiBpc09uZVBvaW50WmVybyhuKSB7XG4gICAgcmV0dXJuIHR5cGVvZiBuID09PSAnc3RyaW5nJyAmJiBuLmluZGV4T2YoJy4nKSAhPT0gLTEgJiYgcGFyc2VGbG9hdChuKSA9PT0gMTtcbn1cbi8qKlxuICogQ2hlY2sgdG8gc2VlIGlmIHN0cmluZyBwYXNzZWQgaW4gaXMgYSBwZXJjZW50YWdlXG4gKiBAaGlkZGVuXG4gKi9cbmZ1bmN0aW9uIGlzUGVyY2VudGFnZShuKSB7XG4gICAgcmV0dXJuIHR5cGVvZiBuID09PSAnc3RyaW5nJyAmJiBuLmluZGV4T2YoJyUnKSAhPT0gLTE7XG59XG4vKipcbiAqIFJldHVybiBhIHZhbGlkIGFscGhhIHZhbHVlIFswLDFdIHdpdGggYWxsIGludmFsaWQgdmFsdWVzIGJlaW5nIHNldCB0byAxXG4gKiBAaGlkZGVuXG4gKi9cbmZ1bmN0aW9uIGJvdW5kQWxwaGEoYSkge1xuICAgIGEgPSBwYXJzZUZsb2F0KGEpO1xuICAgIGlmIChpc05hTihhKSB8fCBhIDwgMCB8fCBhID4gMSkge1xuICAgICAgICBhID0gMTtcbiAgICB9XG4gICAgcmV0dXJuIGE7XG59XG4vKipcbiAqIFJlcGxhY2UgYSBkZWNpbWFsIHdpdGggaXQncyBwZXJjZW50YWdlIHZhbHVlXG4gKiBAaGlkZGVuXG4gKi9cbmZ1bmN0aW9uIGNvbnZlcnRUb1BlcmNlbnRhZ2Uobikge1xuICAgIGlmIChuIDw9IDEpIHtcbiAgICAgICAgcmV0dXJuICtuICogMTAwICsgJyUnO1xuICAgIH1cbiAgICByZXR1cm4gbjtcbn1cbi8qKlxuICogRm9yY2UgYSBoZXggdmFsdWUgdG8gaGF2ZSAyIGNoYXJhY3RlcnNcbiAqIEBoaWRkZW5cbiAqL1xuZnVuY3Rpb24gcGFkMihjKSB7XG4gICAgcmV0dXJuIGMubGVuZ3RoID09PSAxID8gJzAnICsgYyA6ICcnICsgYztcbn1cblxuLy8gYHJnYlRvSHNsYCwgYHJnYlRvSHN2YCwgYGhzbFRvUmdiYCwgYGhzdlRvUmdiYCBtb2RpZmllZCBmcm9tOlxuLy8gPGh0dHA6Ly9tamlqYWNrc29uLmNvbS8yMDA4LzAyL3JnYi10by1oc2wtYW5kLXJnYi10by1oc3YtY29sb3ItbW9kZWwtY29udmVyc2lvbi1hbGdvcml0aG1zLWluLWphdmFzY3JpcHQ+XG4vKipcbiAqIEhhbmRsZSBib3VuZHMgLyBwZXJjZW50YWdlIGNoZWNraW5nIHRvIGNvbmZvcm0gdG8gQ1NTIGNvbG9yIHNwZWNcbiAqIDxodHRwOi8vd3d3LnczLm9yZy9UUi9jc3MzLWNvbG9yLz5cbiAqICpBc3N1bWVzOiogciwgZywgYiBpbiBbMCwgMjU1XSBvciBbMCwgMV1cbiAqICpSZXR1cm5zOiogeyByLCBnLCBiIH0gaW4gWzAsIDI1NV1cbiAqL1xuZnVuY3Rpb24gcmdiVG9SZ2IociwgZywgYikge1xuICAgIHJldHVybiB7XG4gICAgICAgIHI6IGJvdW5kMDEociwgMjU1KSAqIDI1NSxcbiAgICAgICAgZzogYm91bmQwMShnLCAyNTUpICogMjU1LFxuICAgICAgICBiOiBib3VuZDAxKGIsIDI1NSkgKiAyNTUsXG4gICAgfTtcbn1cbi8qKlxuICogQ29udmVydHMgYW4gUkdCIGNvbG9yIHZhbHVlIHRvIEhTTC5cbiAqICpBc3N1bWVzOiogciwgZywgYW5kIGIgYXJlIGNvbnRhaW5lZCBpbiBbMCwgMjU1XSBvciBbMCwgMV1cbiAqICpSZXR1cm5zOiogeyBoLCBzLCBsIH0gaW4gWzAsMV1cbiAqL1xuZnVuY3Rpb24gcmdiVG9Ic2wociwgZywgYikge1xuICAgIHIgPSBib3VuZDAxKHIsIDI1NSk7XG4gICAgZyA9IGJvdW5kMDEoZywgMjU1KTtcbiAgICBiID0gYm91bmQwMShiLCAyNTUpO1xuICAgIGNvbnN0IG1heCA9IE1hdGgubWF4KHIsIGcsIGIpO1xuICAgIGNvbnN0IG1pbiA9IE1hdGgubWluKHIsIGcsIGIpO1xuICAgIGxldCBoID0gMDtcbiAgICBsZXQgcyA9IDA7XG4gICAgY29uc3QgbCA9IChtYXggKyBtaW4pIC8gMjtcbiAgICBpZiAobWF4ID09PSBtaW4pIHtcbiAgICAgICAgaCA9IHMgPSAwOyAvLyBhY2hyb21hdGljXG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjb25zdCBkID0gbWF4IC0gbWluO1xuICAgICAgICBzID0gbCA+IDAuNSA/IGQgLyAoMiAtIG1heCAtIG1pbikgOiBkIC8gKG1heCArIG1pbik7XG4gICAgICAgIHN3aXRjaCAobWF4KSB7XG4gICAgICAgICAgICBjYXNlIHI6XG4gICAgICAgICAgICAgICAgaCA9IChnIC0gYikgLyBkICsgKGcgPCBiID8gNiA6IDApO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBnOlxuICAgICAgICAgICAgICAgIGggPSAoYiAtIHIpIC8gZCArIDI7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGI6XG4gICAgICAgICAgICAgICAgaCA9IChyIC0gZykgLyBkICsgNDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBoIC89IDY7XG4gICAgfVxuICAgIHJldHVybiB7IGgsIHMsIGwgfTtcbn1cbi8qKlxuICogQ29udmVydHMgYW4gSFNMIGNvbG9yIHZhbHVlIHRvIFJHQi5cbiAqXG4gKiAqQXNzdW1lczoqIGggaXMgY29udGFpbmVkIGluIFswLCAxXSBvciBbMCwgMzYwXSBhbmQgcyBhbmQgbCBhcmUgY29udGFpbmVkIFswLCAxXSBvciBbMCwgMTAwXVxuICogKlJldHVybnM6KiB7IHIsIGcsIGIgfSBpbiB0aGUgc2V0IFswLCAyNTVdXG4gKi9cbmZ1bmN0aW9uIGhzbFRvUmdiKGgsIHMsIGwpIHtcbiAgICBsZXQgcjtcbiAgICBsZXQgZztcbiAgICBsZXQgYjtcbiAgICBoID0gYm91bmQwMShoLCAzNjApO1xuICAgIHMgPSBib3VuZDAxKHMsIDEwMCk7XG4gICAgbCA9IGJvdW5kMDEobCwgMTAwKTtcbiAgICBmdW5jdGlvbiBodWUycmdiKHAsIHEsIHQpIHtcbiAgICAgICAgaWYgKHQgPCAwKVxuICAgICAgICAgICAgdCArPSAxO1xuICAgICAgICBpZiAodCA+IDEpXG4gICAgICAgICAgICB0IC09IDE7XG4gICAgICAgIGlmICh0IDwgMSAvIDYpIHtcbiAgICAgICAgICAgIHJldHVybiBwICsgKHEgLSBwKSAqIDYgKiB0O1xuICAgICAgICB9XG4gICAgICAgIGlmICh0IDwgMSAvIDIpIHtcbiAgICAgICAgICAgIHJldHVybiBxO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0IDwgMiAvIDMpIHtcbiAgICAgICAgICAgIHJldHVybiBwICsgKHEgLSBwKSAqICgyIC8gMyAtIHQpICogNjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcDtcbiAgICB9XG4gICAgaWYgKHMgPT09IDApIHtcbiAgICAgICAgciA9IGcgPSBiID0gbDsgLy8gYWNocm9tYXRpY1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc3QgcSA9IGwgPCAwLjUgPyBsICogKDEgKyBzKSA6IGwgKyBzIC0gbCAqIHM7XG4gICAgICAgIGNvbnN0IHAgPSAyICogbCAtIHE7XG4gICAgICAgIHIgPSBodWUycmdiKHAsIHEsIGggKyAxIC8gMyk7XG4gICAgICAgIGcgPSBodWUycmdiKHAsIHEsIGgpO1xuICAgICAgICBiID0gaHVlMnJnYihwLCBxLCBoIC0gMSAvIDMpO1xuICAgIH1cbiAgICByZXR1cm4geyByOiByICogMjU1LCBnOiBnICogMjU1LCBiOiBiICogMjU1IH07XG59XG4vKipcbiAqIENvbnZlcnRzIGFuIFJHQiBjb2xvciB2YWx1ZSB0byBIU1ZcbiAqXG4gKiAqQXNzdW1lczoqIHIsIGcsIGFuZCBiIGFyZSBjb250YWluZWQgaW4gdGhlIHNldCBbMCwgMjU1XSBvciBbMCwgMV1cbiAqICpSZXR1cm5zOiogeyBoLCBzLCB2IH0gaW4gWzAsMV1cbiAqL1xuZnVuY3Rpb24gcmdiVG9Ic3YociwgZywgYikge1xuICAgIHIgPSBib3VuZDAxKHIsIDI1NSk7XG4gICAgZyA9IGJvdW5kMDEoZywgMjU1KTtcbiAgICBiID0gYm91bmQwMShiLCAyNTUpO1xuICAgIGNvbnN0IG1heCA9IE1hdGgubWF4KHIsIGcsIGIpO1xuICAgIGNvbnN0IG1pbiA9IE1hdGgubWluKHIsIGcsIGIpO1xuICAgIGxldCBoID0gMDtcbiAgICBjb25zdCB2ID0gbWF4O1xuICAgIGNvbnN0IGQgPSBtYXggLSBtaW47XG4gICAgY29uc3QgcyA9IG1heCA9PT0gMCA/IDAgOiBkIC8gbWF4O1xuICAgIGlmIChtYXggPT09IG1pbikge1xuICAgICAgICBoID0gMDsgLy8gYWNocm9tYXRpY1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgc3dpdGNoIChtYXgpIHtcbiAgICAgICAgICAgIGNhc2UgcjpcbiAgICAgICAgICAgICAgICBoID0gKGcgLSBiKSAvIGQgKyAoZyA8IGIgPyA2IDogMCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGc6XG4gICAgICAgICAgICAgICAgaCA9IChiIC0gcikgLyBkICsgMjtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgYjpcbiAgICAgICAgICAgICAgICBoID0gKHIgLSBnKSAvIGQgKyA0O1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGggLz0gNjtcbiAgICB9XG4gICAgcmV0dXJuIHsgaDogaCwgczogcywgdjogdiB9O1xufVxuLyoqXG4gKiBDb252ZXJ0cyBhbiBIU1YgY29sb3IgdmFsdWUgdG8gUkdCLlxuICpcbiAqICpBc3N1bWVzOiogaCBpcyBjb250YWluZWQgaW4gWzAsIDFdIG9yIFswLCAzNjBdIGFuZCBzIGFuZCB2IGFyZSBjb250YWluZWQgaW4gWzAsIDFdIG9yIFswLCAxMDBdXG4gKiAqUmV0dXJuczoqIHsgciwgZywgYiB9IGluIHRoZSBzZXQgWzAsIDI1NV1cbiAqL1xuZnVuY3Rpb24gaHN2VG9SZ2IoaCwgcywgdikge1xuICAgIGggPSBib3VuZDAxKGgsIDM2MCkgKiA2O1xuICAgIHMgPSBib3VuZDAxKHMsIDEwMCk7XG4gICAgdiA9IGJvdW5kMDEodiwgMTAwKTtcbiAgICBjb25zdCBpID0gTWF0aC5mbG9vcihoKTtcbiAgICBjb25zdCBmID0gaCAtIGk7XG4gICAgY29uc3QgcCA9IHYgKiAoMSAtIHMpO1xuICAgIGNvbnN0IHEgPSB2ICogKDEgLSBmICogcyk7XG4gICAgY29uc3QgdCA9IHYgKiAoMSAtICgxIC0gZikgKiBzKTtcbiAgICBjb25zdCBtb2QgPSBpICUgNjtcbiAgICBjb25zdCByID0gW3YsIHEsIHAsIHAsIHQsIHZdW21vZF07XG4gICAgY29uc3QgZyA9IFt0LCB2LCB2LCBxLCBwLCBwXVttb2RdO1xuICAgIGNvbnN0IGIgPSBbcCwgcCwgdCwgdiwgdiwgcV1bbW9kXTtcbiAgICByZXR1cm4geyByOiByICogMjU1LCBnOiBnICogMjU1LCBiOiBiICogMjU1IH07XG59XG4vKipcbiAqIENvbnZlcnRzIGFuIFJHQiBjb2xvciB0byBoZXhcbiAqXG4gKiBBc3N1bWVzIHIsIGcsIGFuZCBiIGFyZSBjb250YWluZWQgaW4gdGhlIHNldCBbMCwgMjU1XVxuICogUmV0dXJucyBhIDMgb3IgNiBjaGFyYWN0ZXIgaGV4XG4gKi9cbmZ1bmN0aW9uIHJnYlRvSGV4KHIsIGcsIGIsIGFsbG93M0NoYXIpIHtcbiAgICBjb25zdCBoZXggPSBbXG4gICAgICAgIHBhZDIoTWF0aC5yb3VuZChyKS50b1N0cmluZygxNikpLFxuICAgICAgICBwYWQyKE1hdGgucm91bmQoZykudG9TdHJpbmcoMTYpKSxcbiAgICAgICAgcGFkMihNYXRoLnJvdW5kKGIpLnRvU3RyaW5nKDE2KSksXG4gICAgXTtcbiAgICAvLyBSZXR1cm4gYSAzIGNoYXJhY3RlciBoZXggaWYgcG9zc2libGVcbiAgICBpZiAoYWxsb3czQ2hhciAmJlxuICAgICAgICBoZXhbMF0uY2hhckF0KDApID09PSBoZXhbMF0uY2hhckF0KDEpICYmXG4gICAgICAgIGhleFsxXS5jaGFyQXQoMCkgPT09IGhleFsxXS5jaGFyQXQoMSkgJiZcbiAgICAgICAgaGV4WzJdLmNoYXJBdCgwKSA9PT0gaGV4WzJdLmNoYXJBdCgxKSkge1xuICAgICAgICByZXR1cm4gaGV4WzBdLmNoYXJBdCgwKSArIGhleFsxXS5jaGFyQXQoMCkgKyBoZXhbMl0uY2hhckF0KDApO1xuICAgIH1cbiAgICByZXR1cm4gaGV4LmpvaW4oJycpO1xufVxuLyoqXG4gKiBDb252ZXJ0cyBhbiBSR0JBIGNvbG9yIHBsdXMgYWxwaGEgdHJhbnNwYXJlbmN5IHRvIGhleFxuICpcbiAqIEFzc3VtZXMgciwgZywgYiBhcmUgY29udGFpbmVkIGluIHRoZSBzZXQgWzAsIDI1NV0gYW5kXG4gKiBhIGluIFswLCAxXS4gUmV0dXJucyBhIDQgb3IgOCBjaGFyYWN0ZXIgcmdiYSBoZXhcbiAqL1xuZnVuY3Rpb24gcmdiYVRvSGV4KHIsIGcsIGIsIGEsIGFsbG93NENoYXIpIHtcbiAgICBjb25zdCBoZXggPSBbXG4gICAgICAgIHBhZDIoTWF0aC5yb3VuZChyKS50b1N0cmluZygxNikpLFxuICAgICAgICBwYWQyKE1hdGgucm91bmQoZykudG9TdHJpbmcoMTYpKSxcbiAgICAgICAgcGFkMihNYXRoLnJvdW5kKGIpLnRvU3RyaW5nKDE2KSksXG4gICAgICAgIHBhZDIoY29udmVydERlY2ltYWxUb0hleChhKSksXG4gICAgXTtcbiAgICAvLyBSZXR1cm4gYSA0IGNoYXJhY3RlciBoZXggaWYgcG9zc2libGVcbiAgICBpZiAoYWxsb3c0Q2hhciAmJlxuICAgICAgICBoZXhbMF0uY2hhckF0KDApID09PSBoZXhbMF0uY2hhckF0KDEpICYmXG4gICAgICAgIGhleFsxXS5jaGFyQXQoMCkgPT09IGhleFsxXS5jaGFyQXQoMSkgJiZcbiAgICAgICAgaGV4WzJdLmNoYXJBdCgwKSA9PT0gaGV4WzJdLmNoYXJBdCgxKSAmJlxuICAgICAgICBoZXhbM10uY2hhckF0KDApID09PSBoZXhbM10uY2hhckF0KDEpKSB7XG4gICAgICAgIHJldHVybiBoZXhbMF0uY2hhckF0KDApICsgaGV4WzFdLmNoYXJBdCgwKSArIGhleFsyXS5jaGFyQXQoMCkgKyBoZXhbM10uY2hhckF0KDApO1xuICAgIH1cbiAgICByZXR1cm4gaGV4LmpvaW4oJycpO1xufVxuLyoqXG4gKiBDb252ZXJ0cyBhbiBSR0JBIGNvbG9yIHRvIGFuIEFSR0IgSGV4OCBzdHJpbmdcbiAqIFJhcmVseSB1c2VkLCBidXQgcmVxdWlyZWQgZm9yIFwidG9GaWx0ZXIoKVwiXG4gKi9cbmZ1bmN0aW9uIHJnYmFUb0FyZ2JIZXgociwgZywgYiwgYSkge1xuICAgIGNvbnN0IGhleCA9IFtcbiAgICAgICAgcGFkMihjb252ZXJ0RGVjaW1hbFRvSGV4KGEpKSxcbiAgICAgICAgcGFkMihNYXRoLnJvdW5kKHIpLnRvU3RyaW5nKDE2KSksXG4gICAgICAgIHBhZDIoTWF0aC5yb3VuZChnKS50b1N0cmluZygxNikpLFxuICAgICAgICBwYWQyKE1hdGgucm91bmQoYikudG9TdHJpbmcoMTYpKSxcbiAgICBdO1xuICAgIHJldHVybiBoZXguam9pbignJyk7XG59XG4vKiogQ29udmVydHMgYSBkZWNpbWFsIHRvIGEgaGV4IHZhbHVlICovXG5mdW5jdGlvbiBjb252ZXJ0RGVjaW1hbFRvSGV4KGQpIHtcbiAgICByZXR1cm4gTWF0aC5yb3VuZChwYXJzZUZsb2F0KGQpICogMjU1KS50b1N0cmluZygxNik7XG59XG4vKiogQ29udmVydHMgYSBoZXggdmFsdWUgdG8gYSBkZWNpbWFsICovXG5mdW5jdGlvbiBjb252ZXJ0SGV4VG9EZWNpbWFsKGgpIHtcbiAgICByZXR1cm4gcGFyc2VJbnRGcm9tSGV4KGgpIC8gMjU1O1xufVxuLyoqIFBhcnNlIGEgYmFzZS0xNiBoZXggdmFsdWUgaW50byBhIGJhc2UtMTAgaW50ZWdlciAqL1xuZnVuY3Rpb24gcGFyc2VJbnRGcm9tSGV4KHZhbCkge1xuICAgIHJldHVybiBwYXJzZUludCh2YWwsIDE2KTtcbn1cblxuLy8gaHR0cHM6Ly9naXRodWIuY29tL2JhaGFtYXMxMC9jc3MtY29sb3ItbmFtZXMvYmxvYi9tYXN0ZXIvY3NzLWNvbG9yLW5hbWVzLmpzb25cbi8qKlxuICogQGhpZGRlblxuICovXG5jb25zdCBuYW1lcyA9IHtcbiAgICBhbGljZWJsdWU6ICcjZjBmOGZmJyxcbiAgICBhbnRpcXVld2hpdGU6ICcjZmFlYmQ3JyxcbiAgICBhcXVhOiAnIzAwZmZmZicsXG4gICAgYXF1YW1hcmluZTogJyM3ZmZmZDQnLFxuICAgIGF6dXJlOiAnI2YwZmZmZicsXG4gICAgYmVpZ2U6ICcjZjVmNWRjJyxcbiAgICBiaXNxdWU6ICcjZmZlNGM0JyxcbiAgICBibGFjazogJyMwMDAwMDAnLFxuICAgIGJsYW5jaGVkYWxtb25kOiAnI2ZmZWJjZCcsXG4gICAgYmx1ZTogJyMwMDAwZmYnLFxuICAgIGJsdWV2aW9sZXQ6ICcjOGEyYmUyJyxcbiAgICBicm93bjogJyNhNTJhMmEnLFxuICAgIGJ1cmx5d29vZDogJyNkZWI4ODcnLFxuICAgIGNhZGV0Ymx1ZTogJyM1ZjllYTAnLFxuICAgIGNoYXJ0cmV1c2U6ICcjN2ZmZjAwJyxcbiAgICBjaG9jb2xhdGU6ICcjZDI2OTFlJyxcbiAgICBjb3JhbDogJyNmZjdmNTAnLFxuICAgIGNvcm5mbG93ZXJibHVlOiAnIzY0OTVlZCcsXG4gICAgY29ybnNpbGs6ICcjZmZmOGRjJyxcbiAgICBjcmltc29uOiAnI2RjMTQzYycsXG4gICAgY3lhbjogJyMwMGZmZmYnLFxuICAgIGRhcmtibHVlOiAnIzAwMDA4YicsXG4gICAgZGFya2N5YW46ICcjMDA4YjhiJyxcbiAgICBkYXJrZ29sZGVucm9kOiAnI2I4ODYwYicsXG4gICAgZGFya2dyYXk6ICcjYTlhOWE5JyxcbiAgICBkYXJrZ3JlZW46ICcjMDA2NDAwJyxcbiAgICBkYXJrZ3JleTogJyNhOWE5YTknLFxuICAgIGRhcmtraGFraTogJyNiZGI3NmInLFxuICAgIGRhcmttYWdlbnRhOiAnIzhiMDA4YicsXG4gICAgZGFya29saXZlZ3JlZW46ICcjNTU2YjJmJyxcbiAgICBkYXJrb3JhbmdlOiAnI2ZmOGMwMCcsXG4gICAgZGFya29yY2hpZDogJyM5OTMyY2MnLFxuICAgIGRhcmtyZWQ6ICcjOGIwMDAwJyxcbiAgICBkYXJrc2FsbW9uOiAnI2U5OTY3YScsXG4gICAgZGFya3NlYWdyZWVuOiAnIzhmYmM4ZicsXG4gICAgZGFya3NsYXRlYmx1ZTogJyM0ODNkOGInLFxuICAgIGRhcmtzbGF0ZWdyYXk6ICcjMmY0ZjRmJyxcbiAgICBkYXJrc2xhdGVncmV5OiAnIzJmNGY0ZicsXG4gICAgZGFya3R1cnF1b2lzZTogJyMwMGNlZDEnLFxuICAgIGRhcmt2aW9sZXQ6ICcjOTQwMGQzJyxcbiAgICBkZWVwcGluazogJyNmZjE0OTMnLFxuICAgIGRlZXBza3libHVlOiAnIzAwYmZmZicsXG4gICAgZGltZ3JheTogJyM2OTY5NjknLFxuICAgIGRpbWdyZXk6ICcjNjk2OTY5JyxcbiAgICBkb2RnZXJibHVlOiAnIzFlOTBmZicsXG4gICAgZmlyZWJyaWNrOiAnI2IyMjIyMicsXG4gICAgZmxvcmFsd2hpdGU6ICcjZmZmYWYwJyxcbiAgICBmb3Jlc3RncmVlbjogJyMyMjhiMjInLFxuICAgIGZ1Y2hzaWE6ICcjZmYwMGZmJyxcbiAgICBnYWluc2Jvcm86ICcjZGNkY2RjJyxcbiAgICBnaG9zdHdoaXRlOiAnI2Y4ZjhmZicsXG4gICAgZ29sZDogJyNmZmQ3MDAnLFxuICAgIGdvbGRlbnJvZDogJyNkYWE1MjAnLFxuICAgIGdyYXk6ICcjODA4MDgwJyxcbiAgICBncmVlbjogJyMwMDgwMDAnLFxuICAgIGdyZWVueWVsbG93OiAnI2FkZmYyZicsXG4gICAgZ3JleTogJyM4MDgwODAnLFxuICAgIGhvbmV5ZGV3OiAnI2YwZmZmMCcsXG4gICAgaG90cGluazogJyNmZjY5YjQnLFxuICAgIGluZGlhbnJlZDogJyNjZDVjNWMnLFxuICAgIGluZGlnbzogJyM0YjAwODInLFxuICAgIGl2b3J5OiAnI2ZmZmZmMCcsXG4gICAga2hha2k6ICcjZjBlNjhjJyxcbiAgICBsYXZlbmRlcjogJyNlNmU2ZmEnLFxuICAgIGxhdmVuZGVyYmx1c2g6ICcjZmZmMGY1JyxcbiAgICBsYXduZ3JlZW46ICcjN2NmYzAwJyxcbiAgICBsZW1vbmNoaWZmb246ICcjZmZmYWNkJyxcbiAgICBsaWdodGJsdWU6ICcjYWRkOGU2JyxcbiAgICBsaWdodGNvcmFsOiAnI2YwODA4MCcsXG4gICAgbGlnaHRjeWFuOiAnI2UwZmZmZicsXG4gICAgbGlnaHRnb2xkZW5yb2R5ZWxsb3c6ICcjZmFmYWQyJyxcbiAgICBsaWdodGdyYXk6ICcjZDNkM2QzJyxcbiAgICBsaWdodGdyZWVuOiAnIzkwZWU5MCcsXG4gICAgbGlnaHRncmV5OiAnI2QzZDNkMycsXG4gICAgbGlnaHRwaW5rOiAnI2ZmYjZjMScsXG4gICAgbGlnaHRzYWxtb246ICcjZmZhMDdhJyxcbiAgICBsaWdodHNlYWdyZWVuOiAnIzIwYjJhYScsXG4gICAgbGlnaHRza3libHVlOiAnIzg3Y2VmYScsXG4gICAgbGlnaHRzbGF0ZWdyYXk6ICcjNzc4ODk5JyxcbiAgICBsaWdodHNsYXRlZ3JleTogJyM3Nzg4OTknLFxuICAgIGxpZ2h0c3RlZWxibHVlOiAnI2IwYzRkZScsXG4gICAgbGlnaHR5ZWxsb3c6ICcjZmZmZmUwJyxcbiAgICBsaW1lOiAnIzAwZmYwMCcsXG4gICAgbGltZWdyZWVuOiAnIzMyY2QzMicsXG4gICAgbGluZW46ICcjZmFmMGU2JyxcbiAgICBtYWdlbnRhOiAnI2ZmMDBmZicsXG4gICAgbWFyb29uOiAnIzgwMDAwMCcsXG4gICAgbWVkaXVtYXF1YW1hcmluZTogJyM2NmNkYWEnLFxuICAgIG1lZGl1bWJsdWU6ICcjMDAwMGNkJyxcbiAgICBtZWRpdW1vcmNoaWQ6ICcjYmE1NWQzJyxcbiAgICBtZWRpdW1wdXJwbGU6ICcjOTM3MGRiJyxcbiAgICBtZWRpdW1zZWFncmVlbjogJyMzY2IzNzEnLFxuICAgIG1lZGl1bXNsYXRlYmx1ZTogJyM3YjY4ZWUnLFxuICAgIG1lZGl1bXNwcmluZ2dyZWVuOiAnIzAwZmE5YScsXG4gICAgbWVkaXVtdHVycXVvaXNlOiAnIzQ4ZDFjYycsXG4gICAgbWVkaXVtdmlvbGV0cmVkOiAnI2M3MTU4NScsXG4gICAgbWlkbmlnaHRibHVlOiAnIzE5MTk3MCcsXG4gICAgbWludGNyZWFtOiAnI2Y1ZmZmYScsXG4gICAgbWlzdHlyb3NlOiAnI2ZmZTRlMScsXG4gICAgbW9jY2FzaW46ICcjZmZlNGI1JyxcbiAgICBuYXZham93aGl0ZTogJyNmZmRlYWQnLFxuICAgIG5hdnk6ICcjMDAwMDgwJyxcbiAgICBvbGRsYWNlOiAnI2ZkZjVlNicsXG4gICAgb2xpdmU6ICcjODA4MDAwJyxcbiAgICBvbGl2ZWRyYWI6ICcjNmI4ZTIzJyxcbiAgICBvcmFuZ2U6ICcjZmZhNTAwJyxcbiAgICBvcmFuZ2VyZWQ6ICcjZmY0NTAwJyxcbiAgICBvcmNoaWQ6ICcjZGE3MGQ2JyxcbiAgICBwYWxlZ29sZGVucm9kOiAnI2VlZThhYScsXG4gICAgcGFsZWdyZWVuOiAnIzk4ZmI5OCcsXG4gICAgcGFsZXR1cnF1b2lzZTogJyNhZmVlZWUnLFxuICAgIHBhbGV2aW9sZXRyZWQ6ICcjZGI3MDkzJyxcbiAgICBwYXBheWF3aGlwOiAnI2ZmZWZkNScsXG4gICAgcGVhY2hwdWZmOiAnI2ZmZGFiOScsXG4gICAgcGVydTogJyNjZDg1M2YnLFxuICAgIHBpbms6ICcjZmZjMGNiJyxcbiAgICBwbHVtOiAnI2RkYTBkZCcsXG4gICAgcG93ZGVyYmx1ZTogJyNiMGUwZTYnLFxuICAgIHB1cnBsZTogJyM4MDAwODAnLFxuICAgIHJlYmVjY2FwdXJwbGU6ICcjNjYzMzk5JyxcbiAgICByZWQ6ICcjZmYwMDAwJyxcbiAgICByb3N5YnJvd246ICcjYmM4ZjhmJyxcbiAgICByb3lhbGJsdWU6ICcjNDE2OWUxJyxcbiAgICBzYWRkbGVicm93bjogJyM4YjQ1MTMnLFxuICAgIHNhbG1vbjogJyNmYTgwNzInLFxuICAgIHNhbmR5YnJvd246ICcjZjRhNDYwJyxcbiAgICBzZWFncmVlbjogJyMyZThiNTcnLFxuICAgIHNlYXNoZWxsOiAnI2ZmZjVlZScsXG4gICAgc2llbm5hOiAnI2EwNTIyZCcsXG4gICAgc2lsdmVyOiAnI2MwYzBjMCcsXG4gICAgc2t5Ymx1ZTogJyM4N2NlZWInLFxuICAgIHNsYXRlYmx1ZTogJyM2YTVhY2QnLFxuICAgIHNsYXRlZ3JheTogJyM3MDgwOTAnLFxuICAgIHNsYXRlZ3JleTogJyM3MDgwOTAnLFxuICAgIHNub3c6ICcjZmZmYWZhJyxcbiAgICBzcHJpbmdncmVlbjogJyMwMGZmN2YnLFxuICAgIHN0ZWVsYmx1ZTogJyM0NjgyYjQnLFxuICAgIHRhbjogJyNkMmI0OGMnLFxuICAgIHRlYWw6ICcjMDA4MDgwJyxcbiAgICB0aGlzdGxlOiAnI2Q4YmZkOCcsXG4gICAgdG9tYXRvOiAnI2ZmNjM0NycsXG4gICAgdHVycXVvaXNlOiAnIzQwZTBkMCcsXG4gICAgdmlvbGV0OiAnI2VlODJlZScsXG4gICAgd2hlYXQ6ICcjZjVkZWIzJyxcbiAgICB3aGl0ZTogJyNmZmZmZmYnLFxuICAgIHdoaXRlc21va2U6ICcjZjVmNWY1JyxcbiAgICB5ZWxsb3c6ICcjZmZmZjAwJyxcbiAgICB5ZWxsb3dncmVlbjogJyM5YWNkMzInLFxufTtcblxuLyoqXG4gKiBHaXZlbiBhIHN0cmluZyBvciBvYmplY3QsIGNvbnZlcnQgdGhhdCBpbnB1dCB0byBSR0JcbiAqXG4gKiBQb3NzaWJsZSBzdHJpbmcgaW5wdXRzOlxuICogYGBgXG4gKiBcInJlZFwiXG4gKiBcIiNmMDBcIiBvciBcImYwMFwiXG4gKiBcIiNmZjAwMDBcIiBvciBcImZmMDAwMFwiXG4gKiBcIiNmZjAwMDAwMFwiIG9yIFwiZmYwMDAwMDBcIlxuICogXCJyZ2IgMjU1IDAgMFwiIG9yIFwicmdiICgyNTUsIDAsIDApXCJcbiAqIFwicmdiIDEuMCAwIDBcIiBvciBcInJnYiAoMSwgMCwgMClcIlxuICogXCJyZ2JhICgyNTUsIDAsIDAsIDEpXCIgb3IgXCJyZ2JhIDI1NSwgMCwgMCwgMVwiXG4gKiBcInJnYmEgKDEuMCwgMCwgMCwgMSlcIiBvciBcInJnYmEgMS4wLCAwLCAwLCAxXCJcbiAqIFwiaHNsKDAsIDEwMCUsIDUwJSlcIiBvciBcImhzbCAwIDEwMCUgNTAlXCJcbiAqIFwiaHNsYSgwLCAxMDAlLCA1MCUsIDEpXCIgb3IgXCJoc2xhIDAgMTAwJSA1MCUsIDFcIlxuICogXCJoc3YoMCwgMTAwJSwgMTAwJSlcIiBvciBcImhzdiAwIDEwMCUgMTAwJVwiXG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gaW5wdXRUb1JHQihjb2xvcikge1xuICAgIGxldCByZ2IgPSB7IHI6IDAsIGc6IDAsIGI6IDAgfTtcbiAgICBsZXQgYSA9IDE7XG4gICAgbGV0IHMgPSBudWxsO1xuICAgIGxldCB2ID0gbnVsbDtcbiAgICBsZXQgbCA9IG51bGw7XG4gICAgbGV0IG9rID0gZmFsc2U7XG4gICAgbGV0IGZvcm1hdCA9IGZhbHNlO1xuICAgIGlmICh0eXBlb2YgY29sb3IgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGNvbG9yID0gc3RyaW5nSW5wdXRUb09iamVjdChjb2xvcik7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgY29sb3IgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGlmIChpc1ZhbGlkQ1NTVW5pdChjb2xvci5yKSAmJiBpc1ZhbGlkQ1NTVW5pdChjb2xvci5nKSAmJiBpc1ZhbGlkQ1NTVW5pdChjb2xvci5iKSkge1xuICAgICAgICAgICAgcmdiID0gcmdiVG9SZ2IoY29sb3IuciwgY29sb3IuZywgY29sb3IuYik7XG4gICAgICAgICAgICBvayA9IHRydWU7XG4gICAgICAgICAgICBmb3JtYXQgPSBTdHJpbmcoY29sb3Iucikuc3Vic3RyKC0xKSA9PT0gJyUnID8gJ3ByZ2InIDogJ3JnYic7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaXNWYWxpZENTU1VuaXQoY29sb3IuaCkgJiYgaXNWYWxpZENTU1VuaXQoY29sb3IucykgJiYgaXNWYWxpZENTU1VuaXQoY29sb3IudikpIHtcbiAgICAgICAgICAgIHMgPSBjb252ZXJ0VG9QZXJjZW50YWdlKGNvbG9yLnMpO1xuICAgICAgICAgICAgdiA9IGNvbnZlcnRUb1BlcmNlbnRhZ2UoY29sb3Iudik7XG4gICAgICAgICAgICByZ2IgPSBoc3ZUb1JnYihjb2xvci5oLCBzLCB2KTtcbiAgICAgICAgICAgIG9rID0gdHJ1ZTtcbiAgICAgICAgICAgIGZvcm1hdCA9ICdoc3YnO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGlzVmFsaWRDU1NVbml0KGNvbG9yLmgpICYmIGlzVmFsaWRDU1NVbml0KGNvbG9yLnMpICYmIGlzVmFsaWRDU1NVbml0KGNvbG9yLmwpKSB7XG4gICAgICAgICAgICBzID0gY29udmVydFRvUGVyY2VudGFnZShjb2xvci5zKTtcbiAgICAgICAgICAgIGwgPSBjb252ZXJ0VG9QZXJjZW50YWdlKGNvbG9yLmwpO1xuICAgICAgICAgICAgcmdiID0gaHNsVG9SZ2IoY29sb3IuaCwgcywgbCk7XG4gICAgICAgICAgICBvayA9IHRydWU7XG4gICAgICAgICAgICBmb3JtYXQgPSAnaHNsJztcbiAgICAgICAgfVxuICAgICAgICBpZiAoY29sb3IuaGFzT3duUHJvcGVydHkoJ2EnKSkge1xuICAgICAgICAgICAgYSA9IGNvbG9yLmE7XG4gICAgICAgIH1cbiAgICB9XG4gICAgYSA9IGJvdW5kQWxwaGEoYSk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgb2ssXG4gICAgICAgIGZvcm1hdDogY29sb3IuZm9ybWF0IHx8IGZvcm1hdCxcbiAgICAgICAgcjogTWF0aC5taW4oMjU1LCBNYXRoLm1heChyZ2IuciwgMCkpLFxuICAgICAgICBnOiBNYXRoLm1pbigyNTUsIE1hdGgubWF4KHJnYi5nLCAwKSksXG4gICAgICAgIGI6IE1hdGgubWluKDI1NSwgTWF0aC5tYXgocmdiLmIsIDApKSxcbiAgICAgICAgYSxcbiAgICB9O1xufVxuLy8gPGh0dHA6Ly93d3cudzMub3JnL1RSL2NzczMtdmFsdWVzLyNpbnRlZ2Vycz5cbmNvbnN0IENTU19JTlRFR0VSID0gJ1stXFxcXCtdP1xcXFxkKyU/Jztcbi8vIDxodHRwOi8vd3d3LnczLm9yZy9UUi9jc3MzLXZhbHVlcy8jbnVtYmVyLXZhbHVlPlxuY29uc3QgQ1NTX05VTUJFUiA9ICdbLVxcXFwrXT9cXFxcZCpcXFxcLlxcXFxkKyU/Jztcbi8vIEFsbG93IHBvc2l0aXZlL25lZ2F0aXZlIGludGVnZXIvbnVtYmVyLiAgRG9uJ3QgY2FwdHVyZSB0aGUgZWl0aGVyL29yLCBqdXN0IHRoZSBlbnRpcmUgb3V0Y29tZS5cbmNvbnN0IENTU19VTklUID0gYCg/OiR7Q1NTX05VTUJFUn0pfCg/OiR7Q1NTX0lOVEVHRVJ9KWA7XG4vLyBBY3R1YWwgbWF0Y2hpbmcuXG4vLyBQYXJlbnRoZXNlcyBhbmQgY29tbWFzIGFyZSBvcHRpb25hbCwgYnV0IG5vdCByZXF1aXJlZC5cbi8vIFdoaXRlc3BhY2UgY2FuIHRha2UgdGhlIHBsYWNlIG9mIGNvbW1hcyBvciBvcGVuaW5nIHBhcmVuXG5jb25zdCBQRVJNSVNTSVZFX01BVENIMyA9IGBbXFxcXHN8XFxcXChdKygke0NTU19VTklUfSlbLHxcXFxcc10rKCR7Q1NTX1VOSVR9KVssfFxcXFxzXSsoJHtDU1NfVU5JVH0pXFxcXHMqXFxcXCk/YDtcbmNvbnN0IFBFUk1JU1NJVkVfTUFUQ0g0ID0gYFtcXFxcc3xcXFxcKF0rKCR7Q1NTX1VOSVR9KVssfFxcXFxzXSsoJHtDU1NfVU5JVH0pWyx8XFxcXHNdKygke0NTU19VTklUfSlbLHxcXFxcc10rKCR7Q1NTX1VOSVR9KVxcXFxzKlxcXFwpP2A7XG5jb25zdCBtYXRjaGVycyA9IHtcbiAgICBDU1NfVU5JVDogbmV3IFJlZ0V4cChDU1NfVU5JVCksXG4gICAgcmdiOiBuZXcgUmVnRXhwKCdyZ2InICsgUEVSTUlTU0lWRV9NQVRDSDMpLFxuICAgIHJnYmE6IG5ldyBSZWdFeHAoJ3JnYmEnICsgUEVSTUlTU0lWRV9NQVRDSDQpLFxuICAgIGhzbDogbmV3IFJlZ0V4cCgnaHNsJyArIFBFUk1JU1NJVkVfTUFUQ0gzKSxcbiAgICBoc2xhOiBuZXcgUmVnRXhwKCdoc2xhJyArIFBFUk1JU1NJVkVfTUFUQ0g0KSxcbiAgICBoc3Y6IG5ldyBSZWdFeHAoJ2hzdicgKyBQRVJNSVNTSVZFX01BVENIMyksXG4gICAgaHN2YTogbmV3IFJlZ0V4cCgnaHN2YScgKyBQRVJNSVNTSVZFX01BVENINCksXG4gICAgaGV4MzogL14jPyhbMC05YS1mQS1GXXsxfSkoWzAtOWEtZkEtRl17MX0pKFswLTlhLWZBLUZdezF9KSQvLFxuICAgIGhleDY6IC9eIz8oWzAtOWEtZkEtRl17Mn0pKFswLTlhLWZBLUZdezJ9KShbMC05YS1mQS1GXXsyfSkkLyxcbiAgICBoZXg0OiAvXiM/KFswLTlhLWZBLUZdezF9KShbMC05YS1mQS1GXXsxfSkoWzAtOWEtZkEtRl17MX0pKFswLTlhLWZBLUZdezF9KSQvLFxuICAgIGhleDg6IC9eIz8oWzAtOWEtZkEtRl17Mn0pKFswLTlhLWZBLUZdezJ9KShbMC05YS1mQS1GXXsyfSkoWzAtOWEtZkEtRl17Mn0pJC8sXG59O1xuLyoqXG4gKiBQZXJtaXNzaXZlIHN0cmluZyBwYXJzaW5nLiAgVGFrZSBpbiBhIG51bWJlciBvZiBmb3JtYXRzLCBhbmQgb3V0cHV0IGFuIG9iamVjdFxuICogYmFzZWQgb24gZGV0ZWN0ZWQgZm9ybWF0LiAgUmV0dXJucyBgeyByLCBnLCBiIH1gIG9yIGB7IGgsIHMsIGwgfWAgb3IgYHsgaCwgcywgdn1gXG4gKi9cbmZ1bmN0aW9uIHN0cmluZ0lucHV0VG9PYmplY3QoY29sb3IpIHtcbiAgICBjb2xvciA9IGNvbG9yLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgIGlmIChjb2xvci5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBsZXQgbmFtZWQgPSBmYWxzZTtcbiAgICBpZiAobmFtZXNbY29sb3JdKSB7XG4gICAgICAgIGNvbG9yID0gbmFtZXNbY29sb3JdO1xuICAgICAgICBuYW1lZCA9IHRydWU7XG4gICAgfVxuICAgIGVsc2UgaWYgKGNvbG9yID09PSAndHJhbnNwYXJlbnQnKSB7XG4gICAgICAgIHJldHVybiB7IHI6IDAsIGc6IDAsIGI6IDAsIGE6IDAsIGZvcm1hdDogJ25hbWUnIH07XG4gICAgfVxuICAgIC8vIFRyeSB0byBtYXRjaCBzdHJpbmcgaW5wdXQgdXNpbmcgcmVndWxhciBleHByZXNzaW9ucy5cbiAgICAvLyBLZWVwIG1vc3Qgb2YgdGhlIG51bWJlciBib3VuZGluZyBvdXQgb2YgdGhpcyBmdW5jdGlvbiAtIGRvbid0IHdvcnJ5IGFib3V0IFswLDFdIG9yIFswLDEwMF0gb3IgWzAsMzYwXVxuICAgIC8vIEp1c3QgcmV0dXJuIGFuIG9iamVjdCBhbmQgbGV0IHRoZSBjb252ZXJzaW9uIGZ1bmN0aW9ucyBoYW5kbGUgdGhhdC5cbiAgICAvLyBUaGlzIHdheSB0aGUgcmVzdWx0IHdpbGwgYmUgdGhlIHNhbWUgd2hldGhlciB0aGUgdGlueWNvbG9yIGlzIGluaXRpYWxpemVkIHdpdGggc3RyaW5nIG9yIG9iamVjdC5cbiAgICBsZXQgbWF0Y2ggPSBtYXRjaGVycy5yZ2IuZXhlYyhjb2xvcik7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICAgIHJldHVybiB7IHI6IG1hdGNoWzFdLCBnOiBtYXRjaFsyXSwgYjogbWF0Y2hbM10gfTtcbiAgICB9XG4gICAgbWF0Y2ggPSBtYXRjaGVycy5yZ2JhLmV4ZWMoY29sb3IpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgICByZXR1cm4geyByOiBtYXRjaFsxXSwgZzogbWF0Y2hbMl0sIGI6IG1hdGNoWzNdLCBhOiBtYXRjaFs0XSB9O1xuICAgIH1cbiAgICBtYXRjaCA9IG1hdGNoZXJzLmhzbC5leGVjKGNvbG9yKTtcbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgcmV0dXJuIHsgaDogbWF0Y2hbMV0sIHM6IG1hdGNoWzJdLCBsOiBtYXRjaFszXSB9O1xuICAgIH1cbiAgICBtYXRjaCA9IG1hdGNoZXJzLmhzbGEuZXhlYyhjb2xvcik7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICAgIHJldHVybiB7IGg6IG1hdGNoWzFdLCBzOiBtYXRjaFsyXSwgbDogbWF0Y2hbM10sIGE6IG1hdGNoWzRdIH07XG4gICAgfVxuICAgIG1hdGNoID0gbWF0Y2hlcnMuaHN2LmV4ZWMoY29sb3IpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgICByZXR1cm4geyBoOiBtYXRjaFsxXSwgczogbWF0Y2hbMl0sIHY6IG1hdGNoWzNdIH07XG4gICAgfVxuICAgIG1hdGNoID0gbWF0Y2hlcnMuaHN2YS5leGVjKGNvbG9yKTtcbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgcmV0dXJuIHsgaDogbWF0Y2hbMV0sIHM6IG1hdGNoWzJdLCB2OiBtYXRjaFszXSwgYTogbWF0Y2hbNF0gfTtcbiAgICB9XG4gICAgbWF0Y2ggPSBtYXRjaGVycy5oZXg4LmV4ZWMoY29sb3IpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcjogcGFyc2VJbnRGcm9tSGV4KG1hdGNoWzFdKSxcbiAgICAgICAgICAgIGc6IHBhcnNlSW50RnJvbUhleChtYXRjaFsyXSksXG4gICAgICAgICAgICBiOiBwYXJzZUludEZyb21IZXgobWF0Y2hbM10pLFxuICAgICAgICAgICAgYTogY29udmVydEhleFRvRGVjaW1hbChtYXRjaFs0XSksXG4gICAgICAgICAgICBmb3JtYXQ6IG5hbWVkID8gJ25hbWUnIDogJ2hleDgnLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBtYXRjaCA9IG1hdGNoZXJzLmhleDYuZXhlYyhjb2xvcik7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByOiBwYXJzZUludEZyb21IZXgobWF0Y2hbMV0pLFxuICAgICAgICAgICAgZzogcGFyc2VJbnRGcm9tSGV4KG1hdGNoWzJdKSxcbiAgICAgICAgICAgIGI6IHBhcnNlSW50RnJvbUhleChtYXRjaFszXSksXG4gICAgICAgICAgICBmb3JtYXQ6IG5hbWVkID8gJ25hbWUnIDogJ2hleCcsXG4gICAgICAgIH07XG4gICAgfVxuICAgIG1hdGNoID0gbWF0Y2hlcnMuaGV4NC5leGVjKGNvbG9yKTtcbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHI6IHBhcnNlSW50RnJvbUhleChtYXRjaFsxXSArIG1hdGNoWzFdKSxcbiAgICAgICAgICAgIGc6IHBhcnNlSW50RnJvbUhleChtYXRjaFsyXSArIG1hdGNoWzJdKSxcbiAgICAgICAgICAgIGI6IHBhcnNlSW50RnJvbUhleChtYXRjaFszXSArIG1hdGNoWzNdKSxcbiAgICAgICAgICAgIGE6IGNvbnZlcnRIZXhUb0RlY2ltYWwobWF0Y2hbNF0gKyBtYXRjaFs0XSksXG4gICAgICAgICAgICBmb3JtYXQ6IG5hbWVkID8gJ25hbWUnIDogJ2hleDgnLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBtYXRjaCA9IG1hdGNoZXJzLmhleDMuZXhlYyhjb2xvcik7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByOiBwYXJzZUludEZyb21IZXgobWF0Y2hbMV0gKyBtYXRjaFsxXSksXG4gICAgICAgICAgICBnOiBwYXJzZUludEZyb21IZXgobWF0Y2hbMl0gKyBtYXRjaFsyXSksXG4gICAgICAgICAgICBiOiBwYXJzZUludEZyb21IZXgobWF0Y2hbM10gKyBtYXRjaFszXSksXG4gICAgICAgICAgICBmb3JtYXQ6IG5hbWVkID8gJ25hbWUnIDogJ2hleCcsXG4gICAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn1cbi8qKlxuICogQ2hlY2sgdG8gc2VlIGlmIGl0IGxvb2tzIGxpa2UgYSBDU1MgdW5pdFxuICogKHNlZSBgbWF0Y2hlcnNgIGFib3ZlIGZvciBkZWZpbml0aW9uKS5cbiAqL1xuZnVuY3Rpb24gaXNWYWxpZENTU1VuaXQoY29sb3IpIHtcbiAgICByZXR1cm4gISFtYXRjaGVycy5DU1NfVU5JVC5leGVjKFN0cmluZyhjb2xvcikpO1xufVxuXG5jbGFzcyBUaW55Q29sb3Ige1xuICAgIGNvbnN0cnVjdG9yKGNvbG9yID0gJycsIG9wdHMgPSB7fSkge1xuICAgICAgICAvLyBJZiBpbnB1dCBpcyBhbHJlYWR5IGEgdGlueWNvbG9yLCByZXR1cm4gaXRzZWxmXG4gICAgICAgIGlmIChjb2xvciBpbnN0YW5jZW9mIFRpbnlDb2xvcikge1xuICAgICAgICAgICAgcmV0dXJuIGNvbG9yO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMub3JpZ2luYWxJbnB1dCA9IGNvbG9yO1xuICAgICAgICBjb25zdCByZ2IgPSBpbnB1dFRvUkdCKGNvbG9yKTtcbiAgICAgICAgdGhpcy5vcmlnaW5hbElucHV0ID0gY29sb3I7XG4gICAgICAgIHRoaXMuciA9IHJnYi5yO1xuICAgICAgICB0aGlzLmcgPSByZ2IuZztcbiAgICAgICAgdGhpcy5iID0gcmdiLmI7XG4gICAgICAgIHRoaXMuYSA9IHJnYi5hO1xuICAgICAgICB0aGlzLnJvdW5kQSA9IE1hdGgucm91bmQoMTAwICogdGhpcy5hKSAvIDEwMDtcbiAgICAgICAgdGhpcy5mb3JtYXQgPSBvcHRzLmZvcm1hdCB8fCByZ2IuZm9ybWF0O1xuICAgICAgICB0aGlzLmdyYWRpZW50VHlwZSA9IG9wdHMuZ3JhZGllbnRUeXBlO1xuICAgICAgICAvLyBEb24ndCBsZXQgdGhlIHJhbmdlIG9mIFswLDI1NV0gY29tZSBiYWNrIGluIFswLDFdLlxuICAgICAgICAvLyBQb3RlbnRpYWxseSBsb3NlIGEgbGl0dGxlIGJpdCBvZiBwcmVjaXNpb24gaGVyZSwgYnV0IHdpbGwgZml4IGlzc3VlcyB3aGVyZVxuICAgICAgICAvLyAuNSBnZXRzIGludGVycHJldGVkIGFzIGhhbGYgb2YgdGhlIHRvdGFsLCBpbnN0ZWFkIG9mIGhhbGYgb2YgMVxuICAgICAgICAvLyBJZiBpdCB3YXMgc3VwcG9zZWQgdG8gYmUgMTI4LCB0aGlzIHdhcyBhbHJlYWR5IHRha2VuIGNhcmUgb2YgYnkgYGlucHV0VG9SZ2JgXG4gICAgICAgIGlmICh0aGlzLnIgPCAxKSB7XG4gICAgICAgICAgICB0aGlzLnIgPSBNYXRoLnJvdW5kKHRoaXMucik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuZyA8IDEpIHtcbiAgICAgICAgICAgIHRoaXMuZyA9IE1hdGgucm91bmQodGhpcy5nKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5iIDwgMSkge1xuICAgICAgICAgICAgdGhpcy5iID0gTWF0aC5yb3VuZCh0aGlzLmIpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuaXNWYWxpZCA9IHJnYi5vaztcbiAgICB9XG4gICAgaXNEYXJrKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5nZXRCcmlnaHRuZXNzKCkgPCAxMjg7XG4gICAgfVxuICAgIGlzTGlnaHQoKSB7XG4gICAgICAgIHJldHVybiAhdGhpcy5pc0RhcmsoKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgcGVyY2VpdmVkIGJyaWdodG5lc3Mgb2YgdGhlIGNvbG9yLCBmcm9tIDAtMjU1LlxuICAgICAqL1xuICAgIGdldEJyaWdodG5lc3MoKSB7XG4gICAgICAgIC8vIGh0dHA6Ly93d3cudzMub3JnL1RSL0FFUlQjY29sb3ItY29udHJhc3RcbiAgICAgICAgY29uc3QgcmdiID0gdGhpcy50b1JnYigpO1xuICAgICAgICByZXR1cm4gKHJnYi5yICogMjk5ICsgcmdiLmcgKiA1ODcgKyByZ2IuYiAqIDExNCkgLyAxMDAwO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBwZXJjZWl2ZWQgbHVtaW5hbmNlIG9mIGEgY29sb3IsIGZyb20gMC0xLlxuICAgICAqL1xuICAgIGdldEx1bWluYW5jZSgpIHtcbiAgICAgICAgLy8gaHR0cDovL3d3dy53My5vcmcvVFIvMjAwOC9SRUMtV0NBRzIwLTIwMDgxMjExLyNyZWxhdGl2ZWx1bWluYW5jZWRlZlxuICAgICAgICBjb25zdCByZ2IgPSB0aGlzLnRvUmdiKCk7XG4gICAgICAgIGxldCBSO1xuICAgICAgICBsZXQgRztcbiAgICAgICAgbGV0IEI7XG4gICAgICAgIGNvbnN0IFJzUkdCID0gcmdiLnIgLyAyNTU7XG4gICAgICAgIGNvbnN0IEdzUkdCID0gcmdiLmcgLyAyNTU7XG4gICAgICAgIGNvbnN0IEJzUkdCID0gcmdiLmIgLyAyNTU7XG4gICAgICAgIGlmIChSc1JHQiA8PSAwLjAzOTI4KSB7XG4gICAgICAgICAgICBSID0gUnNSR0IgLyAxMi45MjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIFIgPSBNYXRoLnBvdygoUnNSR0IgKyAwLjA1NSkgLyAxLjA1NSwgMi40KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoR3NSR0IgPD0gMC4wMzkyOCkge1xuICAgICAgICAgICAgRyA9IEdzUkdCIC8gMTIuOTI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBHID0gTWF0aC5wb3coKEdzUkdCICsgMC4wNTUpIC8gMS4wNTUsIDIuNCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKEJzUkdCIDw9IDAuMDM5MjgpIHtcbiAgICAgICAgICAgIEIgPSBCc1JHQiAvIDEyLjkyO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgQiA9IE1hdGgucG93KChCc1JHQiArIDAuMDU1KSAvIDEuMDU1LCAyLjQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAwLjIxMjYgKiBSICsgMC43MTUyICogRyArIDAuMDcyMiAqIEI7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFNldHMgdGhlIGFscGhhIHZhbHVlIG9uIHRoZSBjdXJyZW50IGNvbG9yLlxuICAgICAqXG4gICAgICogQHBhcmFtIGFscGhhIC0gVGhlIG5ldyBhbHBoYSB2YWx1ZS4gVGhlIGFjY2VwdGVkIHJhbmdlIGlzIDAtMS5cbiAgICAgKi9cbiAgICBzZXRBbHBoYShhbHBoYSkge1xuICAgICAgICB0aGlzLmEgPSBib3VuZEFscGhhKGFscGhhKTtcbiAgICAgICAgdGhpcy5yb3VuZEEgPSBNYXRoLnJvdW5kKDEwMCAqIHRoaXMuYSkgLyAxMDA7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBvYmplY3QgYXMgYSBIU1ZBIG9iamVjdC5cbiAgICAgKi9cbiAgICB0b0hzdigpIHtcbiAgICAgICAgY29uc3QgaHN2ID0gcmdiVG9Ic3YodGhpcy5yLCB0aGlzLmcsIHRoaXMuYik7XG4gICAgICAgIHJldHVybiB7IGg6IGhzdi5oICogMzYwLCBzOiBoc3YucywgdjogaHN2LnYsIGE6IHRoaXMuYSB9O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBoc3ZhIHZhbHVlcyBpbnRlcnBvbGF0ZWQgaW50byBhIHN0cmluZyB3aXRoIHRoZSBmb2xsb3dpbmcgZm9ybWF0OlxuICAgICAqIFwiaHN2YSh4eHgsIHh4eCwgeHh4LCB4eClcIi5cbiAgICAgKi9cbiAgICB0b0hzdlN0cmluZygpIHtcbiAgICAgICAgY29uc3QgaHN2ID0gcmdiVG9Ic3YodGhpcy5yLCB0aGlzLmcsIHRoaXMuYik7XG4gICAgICAgIGNvbnN0IGggPSBNYXRoLnJvdW5kKGhzdi5oICogMzYwKTtcbiAgICAgICAgY29uc3QgcyA9IE1hdGgucm91bmQoaHN2LnMgKiAxMDApO1xuICAgICAgICBjb25zdCB2ID0gTWF0aC5yb3VuZChoc3YudiAqIDEwMCk7XG4gICAgICAgIHJldHVybiB0aGlzLmEgPT09IDEgPyBgaHN2KCR7aH0sICR7c30lLCAke3Z9JSlgIDogYGhzdmEoJHtofSwgJHtzfSUsICR7dn0lLCAke3RoaXMucm91bmRBfSlgO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBvYmplY3QgYXMgYSBIU0xBIG9iamVjdC5cbiAgICAgKi9cbiAgICB0b0hzbCgpIHtcbiAgICAgICAgY29uc3QgaHNsID0gcmdiVG9Ic2wodGhpcy5yLCB0aGlzLmcsIHRoaXMuYik7XG4gICAgICAgIHJldHVybiB7IGg6IGhzbC5oICogMzYwLCBzOiBoc2wucywgbDogaHNsLmwsIGE6IHRoaXMuYSB9O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBoc2xhIHZhbHVlcyBpbnRlcnBvbGF0ZWQgaW50byBhIHN0cmluZyB3aXRoIHRoZSBmb2xsb3dpbmcgZm9ybWF0OlxuICAgICAqIFwiaHNsYSh4eHgsIHh4eCwgeHh4LCB4eClcIi5cbiAgICAgKi9cbiAgICB0b0hzbFN0cmluZygpIHtcbiAgICAgICAgY29uc3QgaHNsID0gcmdiVG9Ic2wodGhpcy5yLCB0aGlzLmcsIHRoaXMuYik7XG4gICAgICAgIGNvbnN0IGggPSBNYXRoLnJvdW5kKGhzbC5oICogMzYwKTtcbiAgICAgICAgY29uc3QgcyA9IE1hdGgucm91bmQoaHNsLnMgKiAxMDApO1xuICAgICAgICBjb25zdCBsID0gTWF0aC5yb3VuZChoc2wubCAqIDEwMCk7XG4gICAgICAgIHJldHVybiB0aGlzLmEgPT09IDEgPyBgaHNsKCR7aH0sICR7c30lLCAke2x9JSlgIDogYGhzbGEoJHtofSwgJHtzfSUsICR7bH0lLCAke3RoaXMucm91bmRBfSlgO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBoZXggdmFsdWUgb2YgdGhlIGNvbG9yLlxuICAgICAqIEBwYXJhbSBhbGxvdzNDaGFyIHdpbGwgc2hvcnRlbiBoZXggdmFsdWUgdG8gMyBjaGFyIGlmIHBvc3NpYmxlXG4gICAgICovXG4gICAgdG9IZXgoYWxsb3czQ2hhciA9IGZhbHNlKSB7XG4gICAgICAgIHJldHVybiByZ2JUb0hleCh0aGlzLnIsIHRoaXMuZywgdGhpcy5iLCBhbGxvdzNDaGFyKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgaGV4IHZhbHVlIG9mIHRoZSBjb2xvciAtd2l0aCBhICMgYXBwZW5lZC5cbiAgICAgKiBAcGFyYW0gYWxsb3czQ2hhciB3aWxsIHNob3J0ZW4gaGV4IHZhbHVlIHRvIDMgY2hhciBpZiBwb3NzaWJsZVxuICAgICAqL1xuICAgIHRvSGV4U3RyaW5nKGFsbG93M0NoYXIgPSBmYWxzZSkge1xuICAgICAgICByZXR1cm4gJyMnICsgdGhpcy50b0hleChhbGxvdzNDaGFyKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgaGV4IDggdmFsdWUgb2YgdGhlIGNvbG9yLlxuICAgICAqIEBwYXJhbSBhbGxvdzRDaGFyIHdpbGwgc2hvcnRlbiBoZXggdmFsdWUgdG8gNCBjaGFyIGlmIHBvc3NpYmxlXG4gICAgICovXG4gICAgdG9IZXg4KGFsbG93NENoYXIgPSBmYWxzZSkge1xuICAgICAgICByZXR1cm4gcmdiYVRvSGV4KHRoaXMuciwgdGhpcy5nLCB0aGlzLmIsIHRoaXMuYSwgYWxsb3c0Q2hhcik7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIGhleCA4IHZhbHVlIG9mIHRoZSBjb2xvciAtd2l0aCBhICMgYXBwZW5lZC5cbiAgICAgKiBAcGFyYW0gYWxsb3c0Q2hhciB3aWxsIHNob3J0ZW4gaGV4IHZhbHVlIHRvIDQgY2hhciBpZiBwb3NzaWJsZVxuICAgICAqL1xuICAgIHRvSGV4OFN0cmluZyhhbGxvdzRDaGFyID0gZmFsc2UpIHtcbiAgICAgICAgcmV0dXJuICcjJyArIHRoaXMudG9IZXg4KGFsbG93NENoYXIpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBvYmplY3QgYXMgYSBSR0JBIG9iamVjdC5cbiAgICAgKi9cbiAgICB0b1JnYigpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHI6IE1hdGgucm91bmQodGhpcy5yKSxcbiAgICAgICAgICAgIGc6IE1hdGgucm91bmQodGhpcy5nKSxcbiAgICAgICAgICAgIGI6IE1hdGgucm91bmQodGhpcy5iKSxcbiAgICAgICAgICAgIGE6IHRoaXMuYSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgUkdCQSB2YWx1ZXMgaW50ZXJwb2xhdGVkIGludG8gYSBzdHJpbmcgd2l0aCB0aGUgZm9sbG93aW5nIGZvcm1hdDpcbiAgICAgKiBcIlJHQkEoeHh4LCB4eHgsIHh4eCwgeHgpXCIuXG4gICAgICovXG4gICAgdG9SZ2JTdHJpbmcoKSB7XG4gICAgICAgIGNvbnN0IHIgPSBNYXRoLnJvdW5kKHRoaXMucik7XG4gICAgICAgIGNvbnN0IGcgPSBNYXRoLnJvdW5kKHRoaXMuZyk7XG4gICAgICAgIGNvbnN0IGIgPSBNYXRoLnJvdW5kKHRoaXMuYik7XG4gICAgICAgIHJldHVybiB0aGlzLmEgPT09IDEgPyBgcmdiKCR7cn0sICR7Z30sICR7Yn0pYCA6IGByZ2JhKCR7cn0sICR7Z30sICR7Yn0sICR7dGhpcy5yb3VuZEF9KWA7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIG9iamVjdCBhcyBhIFJHQkEgb2JqZWN0LlxuICAgICAqL1xuICAgIHRvUGVyY2VudGFnZVJnYigpIHtcbiAgICAgICAgY29uc3QgZm10ID0gKHgpID0+IE1hdGgucm91bmQoYm91bmQwMSh4LCAyNTUpICogMTAwKSArICclJztcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHI6IGZtdCh0aGlzLnIpLFxuICAgICAgICAgICAgZzogZm10KHRoaXMuZyksXG4gICAgICAgICAgICBiOiBmbXQodGhpcy5iKSxcbiAgICAgICAgICAgIGE6IHRoaXMuYSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgUkdCQSByZWxhdGl2ZSB2YWx1ZXMgaW50ZXJwb2xhdGVkIGludG8gYSBzdHJpbmdcbiAgICAgKi9cbiAgICB0b1BlcmNlbnRhZ2VSZ2JTdHJpbmcoKSB7XG4gICAgICAgIGNvbnN0IHJuZCA9ICh4KSA9PiBNYXRoLnJvdW5kKGJvdW5kMDEoeCwgMjU1KSAqIDEwMCk7XG4gICAgICAgIHJldHVybiB0aGlzLmEgPT09IDFcbiAgICAgICAgICAgID8gYHJnYigke3JuZCh0aGlzLnIpfSUsICR7cm5kKHRoaXMuZyl9JSwgJHtybmQodGhpcy5iKX0lKWBcbiAgICAgICAgICAgIDogYHJnYmEoJHtybmQodGhpcy5yKX0lLCAke3JuZCh0aGlzLmcpfSUsICR7cm5kKHRoaXMuYil9JSwgJHt0aGlzLnJvdW5kQX0pYDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogVGhlICdyZWFsJyBuYW1lIG9mIHRoZSBjb2xvciAtaWYgdGhlcmUgaXMgb25lLlxuICAgICAqL1xuICAgIHRvTmFtZSgpIHtcbiAgICAgICAgaWYgKHRoaXMuYSA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuICd0cmFuc3BhcmVudCc7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuYSA8IDEpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBoZXggPSAnIycgKyByZ2JUb0hleCh0aGlzLnIsIHRoaXMuZywgdGhpcy5iLCBmYWxzZSk7XG4gICAgICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKG5hbWVzKSkge1xuICAgICAgICAgICAgaWYgKG5hbWVzW2tleV0gPT09IGhleCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBrZXk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBTdHJpbmcgcmVwcmVzZW50YXRpb24gb2YgdGhlIGNvbG9yLlxuICAgICAqXG4gICAgICogQHBhcmFtIGZvcm1hdCAtIFRoZSBmb3JtYXQgdG8gYmUgdXNlZCB3aGVuIGRpc3BsYXlpbmcgdGhlIHN0cmluZyByZXByZXNlbnRhdGlvbi5cbiAgICAgKi9cbiAgICB0b1N0cmluZyhmb3JtYXQpIHtcbiAgICAgICAgY29uc3QgZm9ybWF0U2V0ID0gISFmb3JtYXQ7XG4gICAgICAgIGZvcm1hdCA9IGZvcm1hdCB8fCB0aGlzLmZvcm1hdDtcbiAgICAgICAgbGV0IGZvcm1hdHRlZFN0cmluZyA9IGZhbHNlO1xuICAgICAgICBjb25zdCBoYXNBbHBoYSA9IHRoaXMuYSA8IDEgJiYgdGhpcy5hID49IDA7XG4gICAgICAgIGNvbnN0IG5lZWRzQWxwaGFGb3JtYXQgPSAhZm9ybWF0U2V0ICYmIGhhc0FscGhhICYmIChmb3JtYXQuc3RhcnRzV2l0aCgnaGV4JykgfHwgZm9ybWF0ID09PSAnbmFtZScpO1xuICAgICAgICBpZiAobmVlZHNBbHBoYUZvcm1hdCkge1xuICAgICAgICAgICAgLy8gU3BlY2lhbCBjYXNlIGZvciBcInRyYW5zcGFyZW50XCIsIGFsbCBvdGhlciBub24tYWxwaGEgZm9ybWF0c1xuICAgICAgICAgICAgLy8gd2lsbCByZXR1cm4gcmdiYSB3aGVuIHRoZXJlIGlzIHRyYW5zcGFyZW5jeS5cbiAgICAgICAgICAgIGlmIChmb3JtYXQgPT09ICduYW1lJyAmJiB0aGlzLmEgPT09IDApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy50b05hbWUoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0aGlzLnRvUmdiU3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ3JnYicpIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZFN0cmluZyA9IHRoaXMudG9SZ2JTdHJpbmcoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZm9ybWF0ID09PSAncHJnYicpIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZFN0cmluZyA9IHRoaXMudG9QZXJjZW50YWdlUmdiU3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ2hleCcgfHwgZm9ybWF0ID09PSAnaGV4NicpIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZFN0cmluZyA9IHRoaXMudG9IZXhTdHJpbmcoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZm9ybWF0ID09PSAnaGV4MycpIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZFN0cmluZyA9IHRoaXMudG9IZXhTdHJpbmcodHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ2hleDQnKSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRTdHJpbmcgPSB0aGlzLnRvSGV4OFN0cmluZyh0cnVlKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZm9ybWF0ID09PSAnaGV4OCcpIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZFN0cmluZyA9IHRoaXMudG9IZXg4U3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ25hbWUnKSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRTdHJpbmcgPSB0aGlzLnRvTmFtZSgpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChmb3JtYXQgPT09ICdoc2wnKSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRTdHJpbmcgPSB0aGlzLnRvSHNsU3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ2hzdicpIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZFN0cmluZyA9IHRoaXMudG9Ic3ZTdHJpbmcoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZm9ybWF0dGVkU3RyaW5nIHx8IHRoaXMudG9IZXhTdHJpbmcoKTtcbiAgICB9XG4gICAgY2xvbmUoKSB7XG4gICAgICAgIHJldHVybiBuZXcgVGlueUNvbG9yKHRoaXMudG9TdHJpbmcoKSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIExpZ2h0ZW4gdGhlIGNvbG9yIGEgZ2l2ZW4gYW1vdW50LiBQcm92aWRpbmcgMTAwIHdpbGwgYWx3YXlzIHJldHVybiB3aGl0ZS5cbiAgICAgKiBAcGFyYW0gYW1vdW50IC0gdmFsaWQgYmV0d2VlbiAxLTEwMFxuICAgICAqL1xuICAgIGxpZ2h0ZW4oYW1vdW50ID0gMTApIHtcbiAgICAgICAgY29uc3QgaHNsID0gdGhpcy50b0hzbCgpO1xuICAgICAgICBoc2wubCArPSBhbW91bnQgLyAxMDA7XG4gICAgICAgIGhzbC5sID0gY2xhbXAwMShoc2wubCk7XG4gICAgICAgIHJldHVybiBuZXcgVGlueUNvbG9yKGhzbCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEJyaWdodGVuIHRoZSBjb2xvciBhIGdpdmVuIGFtb3VudCwgZnJvbSAwIHRvIDEwMC5cbiAgICAgKiBAcGFyYW0gYW1vdW50IC0gdmFsaWQgYmV0d2VlbiAxLTEwMFxuICAgICAqL1xuICAgIGJyaWdodGVuKGFtb3VudCA9IDEwKSB7XG4gICAgICAgIGNvbnN0IHJnYiA9IHRoaXMudG9SZ2IoKTtcbiAgICAgICAgcmdiLnIgPSBNYXRoLm1heCgwLCBNYXRoLm1pbigyNTUsIHJnYi5yIC0gTWF0aC5yb3VuZCgyNTUgKiAtKGFtb3VudCAvIDEwMCkpKSk7XG4gICAgICAgIHJnYi5nID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oMjU1LCByZ2IuZyAtIE1hdGgucm91bmQoMjU1ICogLShhbW91bnQgLyAxMDApKSkpO1xuICAgICAgICByZ2IuYiA9IE1hdGgubWF4KDAsIE1hdGgubWluKDI1NSwgcmdiLmIgLSBNYXRoLnJvdW5kKDI1NSAqIC0oYW1vdW50IC8gMTAwKSkpKTtcbiAgICAgICAgcmV0dXJuIG5ldyBUaW55Q29sb3IocmdiKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogRGFya2VuIHRoZSBjb2xvciBhIGdpdmVuIGFtb3VudCwgZnJvbSAwIHRvIDEwMC5cbiAgICAgKiBQcm92aWRpbmcgMTAwIHdpbGwgYWx3YXlzIHJldHVybiBibGFjay5cbiAgICAgKiBAcGFyYW0gYW1vdW50IC0gdmFsaWQgYmV0d2VlbiAxLTEwMFxuICAgICAqL1xuICAgIGRhcmtlbihhbW91bnQgPSAxMCkge1xuICAgICAgICBjb25zdCBoc2wgPSB0aGlzLnRvSHNsKCk7XG4gICAgICAgIGhzbC5sIC09IGFtb3VudCAvIDEwMDtcbiAgICAgICAgaHNsLmwgPSBjbGFtcDAxKGhzbC5sKTtcbiAgICAgICAgcmV0dXJuIG5ldyBUaW55Q29sb3IoaHNsKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogTWl4IHRoZSBjb2xvciB3aXRoIHB1cmUgd2hpdGUsIGZyb20gMCB0byAxMDAuXG4gICAgICogUHJvdmlkaW5nIDAgd2lsbCBkbyBub3RoaW5nLCBwcm92aWRpbmcgMTAwIHdpbGwgYWx3YXlzIHJldHVybiB3aGl0ZS5cbiAgICAgKiBAcGFyYW0gYW1vdW50IC0gdmFsaWQgYmV0d2VlbiAxLTEwMFxuICAgICAqL1xuICAgIHRpbnQoYW1vdW50ID0gMTApIHtcbiAgICAgICAgcmV0dXJuIHRoaXMubWl4KCd3aGl0ZScsIGFtb3VudCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIE1peCB0aGUgY29sb3Igd2l0aCBwdXJlIGJsYWNrLCBmcm9tIDAgdG8gMTAwLlxuICAgICAqIFByb3ZpZGluZyAwIHdpbGwgZG8gbm90aGluZywgcHJvdmlkaW5nIDEwMCB3aWxsIGFsd2F5cyByZXR1cm4gYmxhY2suXG4gICAgICogQHBhcmFtIGFtb3VudCAtIHZhbGlkIGJldHdlZW4gMS0xMDBcbiAgICAgKi9cbiAgICBzaGFkZShhbW91bnQgPSAxMCkge1xuICAgICAgICByZXR1cm4gdGhpcy5taXgoJ2JsYWNrJywgYW1vdW50KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogRGVzYXR1cmF0ZSB0aGUgY29sb3IgYSBnaXZlbiBhbW91bnQsIGZyb20gMCB0byAxMDAuXG4gICAgICogUHJvdmlkaW5nIDEwMCB3aWxsIGlzIHRoZSBzYW1lIGFzIGNhbGxpbmcgZ3JleXNjYWxlXG4gICAgICogQHBhcmFtIGFtb3VudCAtIHZhbGlkIGJldHdlZW4gMS0xMDBcbiAgICAgKi9cbiAgICBkZXNhdHVyYXRlKGFtb3VudCA9IDEwKSB7XG4gICAgICAgIGNvbnN0IGhzbCA9IHRoaXMudG9Ic2woKTtcbiAgICAgICAgaHNsLnMgLT0gYW1vdW50IC8gMTAwO1xuICAgICAgICBoc2wucyA9IGNsYW1wMDEoaHNsLnMpO1xuICAgICAgICByZXR1cm4gbmV3IFRpbnlDb2xvcihoc2wpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBTYXR1cmF0ZSB0aGUgY29sb3IgYSBnaXZlbiBhbW91bnQsIGZyb20gMCB0byAxMDAuXG4gICAgICogQHBhcmFtIGFtb3VudCAtIHZhbGlkIGJldHdlZW4gMS0xMDBcbiAgICAgKi9cbiAgICBzYXR1cmF0ZShhbW91bnQgPSAxMCkge1xuICAgICAgICBjb25zdCBoc2wgPSB0aGlzLnRvSHNsKCk7XG4gICAgICAgIGhzbC5zICs9IGFtb3VudCAvIDEwMDtcbiAgICAgICAgaHNsLnMgPSBjbGFtcDAxKGhzbC5zKTtcbiAgICAgICAgcmV0dXJuIG5ldyBUaW55Q29sb3IoaHNsKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQ29tcGxldGVseSBkZXNhdHVyYXRlcyBhIGNvbG9yIGludG8gZ3JleXNjYWxlLlxuICAgICAqIFNhbWUgYXMgY2FsbGluZyBgZGVzYXR1cmF0ZSgxMDApYFxuICAgICAqL1xuICAgIGdyZXlzY2FsZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZGVzYXR1cmF0ZSgxMDApO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBTcGluIHRha2VzIGEgcG9zaXRpdmUgb3IgbmVnYXRpdmUgYW1vdW50IHdpdGhpbiBbLTM2MCwgMzYwXSBpbmRpY2F0aW5nIHRoZSBjaGFuZ2Ugb2YgaHVlLlxuICAgICAqIFZhbHVlcyBvdXRzaWRlIG9mIHRoaXMgcmFuZ2Ugd2lsbCBiZSB3cmFwcGVkIGludG8gdGhpcyByYW5nZS5cbiAgICAgKi9cbiAgICBzcGluKGFtb3VudCkge1xuICAgICAgICBjb25zdCBoc2wgPSB0aGlzLnRvSHNsKCk7XG4gICAgICAgIGNvbnN0IGh1ZSA9IChoc2wuaCArIGFtb3VudCkgJSAzNjA7XG4gICAgICAgIGhzbC5oID0gaHVlIDwgMCA/IDM2MCArIGh1ZSA6IGh1ZTtcbiAgICAgICAgcmV0dXJuIG5ldyBUaW55Q29sb3IoaHNsKTtcbiAgICB9XG4gICAgbWl4KGNvbG9yLCBhbW91bnQgPSA1MCkge1xuICAgICAgICBjb25zdCByZ2IxID0gdGhpcy50b1JnYigpO1xuICAgICAgICBjb25zdCByZ2IyID0gbmV3IFRpbnlDb2xvcihjb2xvcikudG9SZ2IoKTtcbiAgICAgICAgY29uc3QgcCA9IGFtb3VudCAvIDEwMDtcbiAgICAgICAgY29uc3QgcmdiYSA9IHtcbiAgICAgICAgICAgIHI6IChyZ2IyLnIgLSByZ2IxLnIpICogcCArIHJnYjEucixcbiAgICAgICAgICAgIGc6IChyZ2IyLmcgLSByZ2IxLmcpICogcCArIHJnYjEuZyxcbiAgICAgICAgICAgIGI6IChyZ2IyLmIgLSByZ2IxLmIpICogcCArIHJnYjEuYixcbiAgICAgICAgICAgIGE6IChyZ2IyLmEgLSByZ2IxLmEpICogcCArIHJnYjEuYSxcbiAgICAgICAgfTtcbiAgICAgICAgcmV0dXJuIG5ldyBUaW55Q29sb3IocmdiYSk7XG4gICAgfVxuICAgIGFuYWxvZ291cyhyZXN1bHRzID0gNiwgc2xpY2VzID0gMzApIHtcbiAgICAgICAgY29uc3QgaHNsID0gdGhpcy50b0hzbCgpO1xuICAgICAgICBjb25zdCBwYXJ0ID0gMzYwIC8gc2xpY2VzO1xuICAgICAgICBjb25zdCByZXQgPSBbdGhpc107XG4gICAgICAgIGZvciAoaHNsLmggPSAoaHNsLmggLSAoKHBhcnQgKiByZXN1bHRzKSA+PiAxKSArIDcyMCkgJSAzNjA7IC0tcmVzdWx0czspIHtcbiAgICAgICAgICAgIGhzbC5oID0gKGhzbC5oICsgcGFydCkgJSAzNjA7XG4gICAgICAgICAgICByZXQucHVzaChuZXcgVGlueUNvbG9yKGhzbCkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXQ7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIHRha2VuIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL2luZnVzaW9uL2pRdWVyeS14Y29sb3IvYmxvYi9tYXN0ZXIvanF1ZXJ5Lnhjb2xvci5qc1xuICAgICAqL1xuICAgIGNvbXBsZW1lbnQoKSB7XG4gICAgICAgIGNvbnN0IGhzbCA9IHRoaXMudG9Ic2woKTtcbiAgICAgICAgaHNsLmggPSAoaHNsLmggKyAxODApICUgMzYwO1xuICAgICAgICByZXR1cm4gbmV3IFRpbnlDb2xvcihoc2wpO1xuICAgIH1cbiAgICBtb25vY2hyb21hdGljKHJlc3VsdHMgPSA2KSB7XG4gICAgICAgIGNvbnN0IGhzdiA9IHRoaXMudG9Ic3YoKTtcbiAgICAgICAgY29uc3QgaCA9IGhzdi5oO1xuICAgICAgICBjb25zdCBzID0gaHN2LnM7XG4gICAgICAgIGxldCB2ID0gaHN2LnY7XG4gICAgICAgIGNvbnN0IHJlcyA9IFtdO1xuICAgICAgICBjb25zdCBtb2RpZmljYXRpb24gPSAxIC8gcmVzdWx0cztcbiAgICAgICAgd2hpbGUgKHJlc3VsdHMtLSkge1xuICAgICAgICAgICAgcmVzLnB1c2gobmV3IFRpbnlDb2xvcih7IGgsIHMsIHYgfSkpO1xuICAgICAgICAgICAgdiA9ICh2ICsgbW9kaWZpY2F0aW9uKSAlIDE7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlcztcbiAgICB9XG4gICAgc3BsaXRjb21wbGVtZW50KCkge1xuICAgICAgICBjb25zdCBoc2wgPSB0aGlzLnRvSHNsKCk7XG4gICAgICAgIGNvbnN0IGggPSBoc2wuaDtcbiAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgIHRoaXMsXG4gICAgICAgICAgICBuZXcgVGlueUNvbG9yKHsgaDogKGggKyA3MikgJSAzNjAsIHM6IGhzbC5zLCBsOiBoc2wubCB9KSxcbiAgICAgICAgICAgIG5ldyBUaW55Q29sb3IoeyBoOiAoaCArIDIxNikgJSAzNjAsIHM6IGhzbC5zLCBsOiBoc2wubCB9KSxcbiAgICAgICAgXTtcbiAgICB9XG4gICAgdHJpYWQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnBvbHlhZCgzKTtcbiAgICB9XG4gICAgdGV0cmFkKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5wb2x5YWQoNCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEdldCBwb2x5YWQgY29sb3JzLCBsaWtlIChmb3IgMSwgMiwgMywgNCwgNSwgNiwgNywgOCwgZXRjLi4uKVxuICAgICAqIG1vbmFkLCBkeWFkLCB0cmlhZCwgdGV0cmFkLCBwZW50YWQsIGhleGFkLCBoZXB0YWQsIG9jdGFkLCBldGMuLi5cbiAgICAgKi9cbiAgICBwb2x5YWQobikge1xuICAgICAgICBjb25zdCBoc2wgPSB0aGlzLnRvSHNsKCk7XG4gICAgICAgIGNvbnN0IGggPSBoc2wuaDtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW3RoaXNdO1xuICAgICAgICBjb25zdCBpbmNyZW1lbnQgPSAzNjAgLyBuO1xuICAgICAgICBmb3IgKGxldCBpID0gMTsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgcmVzdWx0LnB1c2gobmV3IFRpbnlDb2xvcih7IGg6IChoICsgaSAqIGluY3JlbWVudCkgJSAzNjAsIHM6IGhzbC5zLCBsOiBoc2wubCB9KSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogY29tcGFyZSBjb2xvciB2cyBjdXJyZW50IGNvbG9yXG4gICAgICovXG4gICAgZXF1YWxzKGNvbG9yKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnRvUmdiU3RyaW5nKCkgPT09IG5ldyBUaW55Q29sb3IoY29sb3IpLnRvUmdiU3RyaW5nKCk7XG4gICAgfVxufVxuXG4vLyBSZWFkYWJpbGl0eSBGdW5jdGlvbnNcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gPGh0dHA6Ly93d3cudzMub3JnL1RSLzIwMDgvUkVDLVdDQUcyMC0yMDA4MTIxMS8jY29udHJhc3QtcmF0aW9kZWYgKFdDQUcgVmVyc2lvbiAyKVxuLyoqXG4gKiBBS0EgYGNvbnRyYXN0YFxuICpcbiAqIEFuYWx5emUgdGhlIDIgY29sb3JzIGFuZCByZXR1cm5zIHRoZSBjb2xvciBjb250cmFzdCBkZWZpbmVkIGJ5IChXQ0FHIFZlcnNpb24gMilcbiAqL1xuZnVuY3Rpb24gcmVhZGFiaWxpdHkoY29sb3IxLCBjb2xvcjIpIHtcbiAgICBjb25zdCBjMSA9IG5ldyBUaW55Q29sb3IoY29sb3IxKTtcbiAgICBjb25zdCBjMiA9IG5ldyBUaW55Q29sb3IoY29sb3IyKTtcbiAgICByZXR1cm4gKChNYXRoLm1heChjMS5nZXRMdW1pbmFuY2UoKSwgYzIuZ2V0THVtaW5hbmNlKCkpICsgMC4wNSkgL1xuICAgICAgICAoTWF0aC5taW4oYzEuZ2V0THVtaW5hbmNlKCksIGMyLmdldEx1bWluYW5jZSgpKSArIDAuMDUpKTtcbn1cbi8qKlxuICogRW5zdXJlIHRoYXQgZm9yZWdyb3VuZCBhbmQgYmFja2dyb3VuZCBjb2xvciBjb21iaW5hdGlvbnMgbWVldCBXQ0FHMiBndWlkZWxpbmVzLlxuICogVGhlIHRoaXJkIGFyZ3VtZW50IGlzIGFuIG9iamVjdC5cbiAqICAgICAgdGhlICdsZXZlbCcgcHJvcGVydHkgc3RhdGVzICdBQScgb3IgJ0FBQScgLSBpZiBtaXNzaW5nIG9yIGludmFsaWQsIGl0IGRlZmF1bHRzIHRvICdBQSc7XG4gKiAgICAgIHRoZSAnc2l6ZScgcHJvcGVydHkgc3RhdGVzICdsYXJnZScgb3IgJ3NtYWxsJyAtIGlmIG1pc3Npbmcgb3IgaW52YWxpZCwgaXQgZGVmYXVsdHMgdG8gJ3NtYWxsJy5cbiAqIElmIHRoZSBlbnRpcmUgb2JqZWN0IGlzIGFic2VudCwgaXNSZWFkYWJsZSBkZWZhdWx0cyB0byB7bGV2ZWw6XCJBQVwiLHNpemU6XCJzbWFsbFwifS5cbiAqXG4gKiBFeGFtcGxlXG4gKiBgYGB0c1xuICogbmV3IFRpbnlDb2xvcigpLmlzUmVhZGFibGUoJyMwMDAnLCAnIzExMScpID0+IGZhbHNlXG4gKiBuZXcgVGlueUNvbG9yKCkuaXNSZWFkYWJsZSgnIzAwMCcsICcjMTExJywgeyBsZXZlbDogJ0FBJywgc2l6ZTogJ2xhcmdlJyB9KSA9PiBmYWxzZVxuICogYGBgXG4gKi9cbmZ1bmN0aW9uIGlzUmVhZGFibGUoY29sb3IxLCBjb2xvcjIsIHdjYWcyID0geyBsZXZlbDogJ0FBJywgc2l6ZTogJ3NtYWxsJyB9KSB7XG4gICAgY29uc3QgcmVhZGFiaWxpdHlMZXZlbCA9IHJlYWRhYmlsaXR5KGNvbG9yMSwgY29sb3IyKTtcbiAgICBzd2l0Y2ggKCh3Y2FnMi5sZXZlbCB8fCAnQUEnKSArICh3Y2FnMi5zaXplIHx8ICdzbWFsbCcpKSB7XG4gICAgICAgIGNhc2UgJ0FBc21hbGwnOlxuICAgICAgICBjYXNlICdBQUFsYXJnZSc6XG4gICAgICAgICAgICByZXR1cm4gcmVhZGFiaWxpdHlMZXZlbCA+PSA0LjU7XG4gICAgICAgIGNhc2UgJ0FBbGFyZ2UnOlxuICAgICAgICAgICAgcmV0dXJuIHJlYWRhYmlsaXR5TGV2ZWwgPj0gMztcbiAgICAgICAgY2FzZSAnQUFBc21hbGwnOlxuICAgICAgICAgICAgcmV0dXJuIHJlYWRhYmlsaXR5TGV2ZWwgPj0gNztcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xufVxuLyoqXG4gKiBHaXZlbiBhIGJhc2UgY29sb3IgYW5kIGEgbGlzdCBvZiBwb3NzaWJsZSBmb3JlZ3JvdW5kIG9yIGJhY2tncm91bmRcbiAqIGNvbG9ycyBmb3IgdGhhdCBiYXNlLCByZXR1cm5zIHRoZSBtb3N0IHJlYWRhYmxlIGNvbG9yLlxuICogT3B0aW9uYWxseSByZXR1cm5zIEJsYWNrIG9yIFdoaXRlIGlmIHRoZSBtb3N0IHJlYWRhYmxlIGNvbG9yIGlzIHVucmVhZGFibGUuXG4gKlxuICogQHBhcmFtIGJhc2VDb2xvciAtIHRoZSBiYXNlIGNvbG9yLlxuICogQHBhcmFtIGNvbG9yTGlzdCAtIGFycmF5IG9mIGNvbG9ycyB0byBwaWNrIHRoZSBtb3N0IHJlYWRhYmxlIG9uZSBmcm9tLlxuICogQHBhcmFtIGFyZ3MgLSBhbmQgb2JqZWN0IHdpdGggZXh0cmEgYXJndW1lbnRzXG4gKlxuICogRXhhbXBsZVxuICogYGBgdHNcbiAqIG5ldyBUaW55Q29sb3IoKS5tb3N0UmVhZGFibGUoJyMxMjMnLCBbJyMxMjRcIiwgXCIjMTI1J10sIHsgaW5jbHVkZUZhbGxiYWNrQ29sb3JzOiBmYWxzZSB9KS50b0hleFN0cmluZygpOyAvLyBcIiMxMTIyNTVcIlxuICogbmV3IFRpbnlDb2xvcigpLm1vc3RSZWFkYWJsZSgnIzEyMycsIFsnIzEyNFwiLCBcIiMxMjUnXSx7IGluY2x1ZGVGYWxsYmFja0NvbG9yczogdHJ1ZSB9KS50b0hleFN0cmluZygpOyAgLy8gXCIjZmZmZmZmXCJcbiAqIG5ldyBUaW55Q29sb3IoKS5tb3N0UmVhZGFibGUoJyNhODAxNWEnLCBbXCIjZmFmM2YzXCJdLCB7IGluY2x1ZGVGYWxsYmFja0NvbG9yczp0cnVlLCBsZXZlbDogJ0FBQScsIHNpemU6ICdsYXJnZScgfSkudG9IZXhTdHJpbmcoKTsgLy8gXCIjZmFmM2YzXCJcbiAqIG5ldyBUaW55Q29sb3IoKS5tb3N0UmVhZGFibGUoJyNhODAxNWEnLCBbXCIjZmFmM2YzXCJdLCB7IGluY2x1ZGVGYWxsYmFja0NvbG9yczp0cnVlLCBsZXZlbDogJ0FBQScsIHNpemU6ICdzbWFsbCcgfSkudG9IZXhTdHJpbmcoKTsgLy8gXCIjZmZmZmZmXCJcbiAqIGBgYFxuICovXG5mdW5jdGlvbiBtb3N0UmVhZGFibGUoYmFzZUNvbG9yLCBjb2xvckxpc3QsIGFyZ3MgPSB7IGluY2x1ZGVGYWxsYmFja0NvbG9yczogZmFsc2UsIGxldmVsOiAnQUEnLCBzaXplOiAnc21hbGwnIH0pIHtcbiAgICBsZXQgYmVzdENvbG9yID0gbnVsbDtcbiAgICBsZXQgYmVzdFNjb3JlID0gMDtcbiAgICBjb25zdCBpbmNsdWRlRmFsbGJhY2tDb2xvcnMgPSBhcmdzLmluY2x1ZGVGYWxsYmFja0NvbG9ycztcbiAgICBjb25zdCBsZXZlbCA9IGFyZ3MubGV2ZWw7XG4gICAgY29uc3Qgc2l6ZSA9IGFyZ3Muc2l6ZTtcbiAgICBmb3IgKGNvbnN0IGNvbG9yIG9mIGNvbG9yTGlzdCkge1xuICAgICAgICBjb25zdCBzY29yZSA9IHJlYWRhYmlsaXR5KGJhc2VDb2xvciwgY29sb3IpO1xuICAgICAgICBpZiAoc2NvcmUgPiBiZXN0U2NvcmUpIHtcbiAgICAgICAgICAgIGJlc3RTY29yZSA9IHNjb3JlO1xuICAgICAgICAgICAgYmVzdENvbG9yID0gbmV3IFRpbnlDb2xvcihjb2xvcik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKGlzUmVhZGFibGUoYmFzZUNvbG9yLCBiZXN0Q29sb3IsIHsgbGV2ZWwsIHNpemUgfSkgfHwgIWluY2x1ZGVGYWxsYmFja0NvbG9ycykge1xuICAgICAgICByZXR1cm4gYmVzdENvbG9yO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgYXJncy5pbmNsdWRlRmFsbGJhY2tDb2xvcnMgPSBmYWxzZTtcbiAgICAgICAgcmV0dXJuIG1vc3RSZWFkYWJsZShiYXNlQ29sb3IsIFsnI2ZmZicsICcjMDAwJ10sIGFyZ3MpO1xuICAgIH1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBjb2xvciByZXByZXNlbnRlZCBhcyBhIE1pY3Jvc29mdCBmaWx0ZXIgZm9yIHVzZSBpbiBvbGQgdmVyc2lvbnMgb2YgSUUuXG4gKi9cbmZ1bmN0aW9uIHRvTXNGaWx0ZXIoZmlyc3RDb2xvciwgc2Vjb25kQ29sb3IpIHtcbiAgICBjb25zdCBjb2xvciA9IG5ldyBUaW55Q29sb3IoZmlyc3RDb2xvcik7XG4gICAgY29uc3QgaGV4OFN0cmluZyA9ICcjJyArIHJnYmFUb0FyZ2JIZXgoY29sb3IuciwgY29sb3IuZywgY29sb3IuYiwgY29sb3IuYSk7XG4gICAgbGV0IHNlY29uZEhleDhTdHJpbmcgPSBoZXg4U3RyaW5nO1xuICAgIGNvbnN0IGdyYWRpZW50VHlwZSA9IGNvbG9yLmdyYWRpZW50VHlwZSA/ICdHcmFkaWVudFR5cGUgPSAxLCAnIDogJyc7XG4gICAgaWYgKHNlY29uZENvbG9yKSB7XG4gICAgICAgIGNvbnN0IHMgPSBuZXcgVGlueUNvbG9yKHNlY29uZENvbG9yKTtcbiAgICAgICAgc2Vjb25kSGV4OFN0cmluZyA9ICcjJyArIHJnYmFUb0FyZ2JIZXgocy5yLCBzLmcsIHMuYiwgcy5hKTtcbiAgICB9XG4gICAgcmV0dXJuIGBwcm9naWQ6RFhJbWFnZVRyYW5zZm9ybS5NaWNyb3NvZnQuZ3JhZGllbnQoJHtncmFkaWVudFR5cGV9c3RhcnRDb2xvcnN0cj0ke2hleDhTdHJpbmd9LGVuZENvbG9yc3RyPSR7c2Vjb25kSGV4OFN0cmluZ30pYDtcbn1cblxuLyoqXG4gKiBJZiBpbnB1dCBpcyBhbiBvYmplY3QsIGZvcmNlIDEgaW50byBcIjEuMFwiIHRvIGhhbmRsZSByYXRpb3MgcHJvcGVybHlcbiAqIFN0cmluZyBpbnB1dCByZXF1aXJlcyBcIjEuMFwiIGFzIGlucHV0LCBzbyAxIHdpbGwgYmUgdHJlYXRlZCBhcyAxXG4gKi9cbmZ1bmN0aW9uIGZyb21SYXRpbyhyYXRpbywgb3B0cykge1xuICAgIGNvbnN0IG5ld0NvbG9yID0ge1xuICAgICAgICByOiBjb252ZXJ0VG9QZXJjZW50YWdlKHJhdGlvLnIpLFxuICAgICAgICBnOiBjb252ZXJ0VG9QZXJjZW50YWdlKHJhdGlvLmcpLFxuICAgICAgICBiOiBjb252ZXJ0VG9QZXJjZW50YWdlKHJhdGlvLmIpLFxuICAgIH07XG4gICAgaWYgKHJhdGlvLmEgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBuZXdDb2xvci5hID0gK3JhdGlvLmE7XG4gICAgfVxuICAgIHJldHVybiBuZXcgVGlueUNvbG9yKG5ld0NvbG9yLCBvcHRzKTtcbn1cbi8qKiBvbGQgcmFuZG9tIGZ1bmN0aW9uICovXG5mdW5jdGlvbiBsZWdhY3lSYW5kb20oKSB7XG4gICAgcmV0dXJuIG5ldyBUaW55Q29sb3Ioe1xuICAgICAgICByOiBNYXRoLnJhbmRvbSgpLFxuICAgICAgICBnOiBNYXRoLnJhbmRvbSgpLFxuICAgICAgICBiOiBNYXRoLnJhbmRvbSgpLFxuICAgIH0pO1xufVxuXG4vLyByYW5kb21Db2xvciBieSBEYXZpZCBNZXJmaWVsZCB1bmRlciB0aGUgQ0MwIGxpY2Vuc2VcbmZ1bmN0aW9uIHJhbmRvbShvcHRpb25zID0ge30pIHtcbiAgICAvLyBDaGVjayBpZiB3ZSBuZWVkIHRvIGdlbmVyYXRlIG11bHRpcGxlIGNvbG9yc1xuICAgIGlmIChvcHRpb25zLmNvdW50ICE9PSB1bmRlZmluZWQgJiYgb3B0aW9ucy5jb3VudCAhPT0gbnVsbCkge1xuICAgICAgICBjb25zdCB0b3RhbENvbG9ycyA9IG9wdGlvbnMuY291bnQ7XG4gICAgICAgIGNvbnN0IGNvbG9ycyA9IFtdO1xuICAgICAgICBvcHRpb25zLmNvdW50ID0gdW5kZWZpbmVkO1xuICAgICAgICB3aGlsZSAodG90YWxDb2xvcnMgPiBjb2xvcnMubGVuZ3RoKSB7XG4gICAgICAgICAgICAvLyBTaW5jZSB3ZSdyZSBnZW5lcmF0aW5nIG11bHRpcGxlIGNvbG9ycyxcbiAgICAgICAgICAgIC8vIGluY3JlbWVtZW50IHRoZSBzZWVkLiBPdGhlcndpc2Ugd2UnZCBqdXN0XG4gICAgICAgICAgICAvLyBnZW5lcmF0ZSB0aGUgc2FtZSBjb2xvciBlYWNoIHRpbWUuLi5cbiAgICAgICAgICAgIG9wdGlvbnMuY291bnQgPSBudWxsO1xuICAgICAgICAgICAgaWYgKG9wdGlvbnMuc2VlZCkge1xuICAgICAgICAgICAgICAgIG9wdGlvbnMuc2VlZCArPSAxO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29sb3JzLnB1c2gocmFuZG9tKG9wdGlvbnMpKTtcbiAgICAgICAgfVxuICAgICAgICBvcHRpb25zLmNvdW50ID0gdG90YWxDb2xvcnM7XG4gICAgICAgIHJldHVybiBjb2xvcnM7XG4gICAgfVxuICAgIC8vIEZpcnN0IHdlIHBpY2sgYSBodWUgKEgpXG4gICAgY29uc3QgaCA9IHBpY2tIdWUob3B0aW9ucy5odWUsIG9wdGlvbnMuc2VlZCk7XG4gICAgLy8gVGhlbiB1c2UgSCB0byBkZXRlcm1pbmUgc2F0dXJhdGlvbiAoUylcbiAgICBjb25zdCBzID0gcGlja1NhdHVyYXRpb24oaCwgb3B0aW9ucyk7XG4gICAgLy8gVGhlbiB1c2UgUyBhbmQgSCB0byBkZXRlcm1pbmUgYnJpZ2h0bmVzcyAoQikuXG4gICAgY29uc3QgdiA9IHBpY2tCcmlnaHRuZXNzKGgsIHMsIG9wdGlvbnMpO1xuICAgIGNvbnN0IHJlcyA9IHsgaCwgcywgdiB9O1xuICAgIGlmIChvcHRpb25zLmFscGhhICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmVzLmEgPSBvcHRpb25zLmFscGhhO1xuICAgIH1cbiAgICAvLyBUaGVuIHdlIHJldHVybiB0aGUgSFNCIGNvbG9yIGluIHRoZSBkZXNpcmVkIGZvcm1hdFxuICAgIHJldHVybiBuZXcgVGlueUNvbG9yKHJlcyk7XG59XG5mdW5jdGlvbiBwaWNrSHVlKGh1ZSwgc2VlZCkge1xuICAgIGNvbnN0IGh1ZVJhbmdlID0gZ2V0SHVlUmFuZ2UoaHVlKTtcbiAgICBsZXQgcmVzID0gcmFuZG9tV2l0aGluKGh1ZVJhbmdlLCBzZWVkKTtcbiAgICAvLyBJbnN0ZWFkIG9mIHN0b3JpbmcgcmVkIGFzIHR3byBzZXBlcmF0ZSByYW5nZXMsXG4gICAgLy8gd2UgZ3JvdXAgdGhlbSwgdXNpbmcgbmVnYXRpdmUgbnVtYmVyc1xuICAgIGlmIChyZXMgPCAwKSB7XG4gICAgICAgIHJlcyA9IDM2MCArIHJlcztcbiAgICB9XG4gICAgcmV0dXJuIHJlcztcbn1cbmZ1bmN0aW9uIHBpY2tTYXR1cmF0aW9uKGh1ZSwgb3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zLmh1ZSA9PT0gJ21vbm9jaHJvbWUnKSB7XG4gICAgICAgIHJldHVybiAwO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5sdW1pbm9zaXR5ID09PSAncmFuZG9tJykge1xuICAgICAgICByZXR1cm4gcmFuZG9tV2l0aGluKFswLCAxMDBdLCBvcHRpb25zLnNlZWQpO1xuICAgIH1cbiAgICBjb25zdCBzYXR1cmF0aW9uUmFuZ2UgPSBnZXRDb2xvckluZm8oaHVlKS5zYXR1cmF0aW9uUmFuZ2U7XG4gICAgbGV0IHNNaW4gPSBzYXR1cmF0aW9uUmFuZ2VbMF07XG4gICAgbGV0IHNNYXggPSBzYXR1cmF0aW9uUmFuZ2VbMV07XG4gICAgc3dpdGNoIChvcHRpb25zLmx1bWlub3NpdHkpIHtcbiAgICAgICAgY2FzZSAnYnJpZ2h0JzpcbiAgICAgICAgICAgIHNNaW4gPSA1NTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdkYXJrJzpcbiAgICAgICAgICAgIHNNaW4gPSBzTWF4IC0gMTA7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnbGlnaHQnOlxuICAgICAgICAgICAgc01heCA9IDU1O1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgfVxuICAgIHJldHVybiByYW5kb21XaXRoaW4oW3NNaW4sIHNNYXhdLCBvcHRpb25zLnNlZWQpO1xufVxuZnVuY3Rpb24gcGlja0JyaWdodG5lc3MoSCwgUywgb3B0aW9ucykge1xuICAgIGxldCBiTWluID0gZ2V0TWluaW11bUJyaWdodG5lc3MoSCwgUyk7XG4gICAgbGV0IGJNYXggPSAxMDA7XG4gICAgc3dpdGNoIChvcHRpb25zLmx1bWlub3NpdHkpIHtcbiAgICAgICAgY2FzZSAnZGFyayc6XG4gICAgICAgICAgICBiTWF4ID0gYk1pbiArIDIwO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ2xpZ2h0JzpcbiAgICAgICAgICAgIGJNaW4gPSAoYk1heCArIGJNaW4pIC8gMjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdyYW5kb20nOlxuICAgICAgICAgICAgYk1pbiA9IDA7XG4gICAgICAgICAgICBiTWF4ID0gMTAwO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgfVxuICAgIHJldHVybiByYW5kb21XaXRoaW4oW2JNaW4sIGJNYXhdLCBvcHRpb25zLnNlZWQpO1xufVxuZnVuY3Rpb24gZ2V0TWluaW11bUJyaWdodG5lc3MoSCwgUykge1xuICAgIGNvbnN0IGxvd2VyQm91bmRzID0gZ2V0Q29sb3JJbmZvKEgpLmxvd2VyQm91bmRzO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbG93ZXJCb3VuZHMubGVuZ3RoIC0gMTsgaSsrKSB7XG4gICAgICAgIGNvbnN0IHMxID0gbG93ZXJCb3VuZHNbaV1bMF07XG4gICAgICAgIGNvbnN0IHYxID0gbG93ZXJCb3VuZHNbaV1bMV07XG4gICAgICAgIGNvbnN0IHMyID0gbG93ZXJCb3VuZHNbaSArIDFdWzBdO1xuICAgICAgICBjb25zdCB2MiA9IGxvd2VyQm91bmRzW2kgKyAxXVsxXTtcbiAgICAgICAgaWYgKFMgPj0gczEgJiYgUyA8PSBzMikge1xuICAgICAgICAgICAgY29uc3QgbSA9ICh2MiAtIHYxKSAvIChzMiAtIHMxKTtcbiAgICAgICAgICAgIGNvbnN0IGIgPSB2MSAtIG0gKiBzMTtcbiAgICAgICAgICAgIHJldHVybiBtICogUyArIGI7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIDA7XG59XG5mdW5jdGlvbiBnZXRIdWVSYW5nZShjb2xvcklucHV0KSB7XG4gICAgY29uc3QgbnVtID0gcGFyc2VJbnQoY29sb3JJbnB1dCwgMTApO1xuICAgIGlmICghTnVtYmVyLmlzTmFOKG51bSkgJiYgbnVtIDwgMzYwICYmIG51bSA+IDApIHtcbiAgICAgICAgcmV0dXJuIFtudW0sIG51bV07XG4gICAgfVxuICAgIGlmICh0eXBlb2YgY29sb3JJbnB1dCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgY29uc3QgbmFtZWRDb2xvciA9IGJvdW5kcy5maW5kKG4gPT4gbi5uYW1lID09PSBjb2xvcklucHV0KTtcbiAgICAgICAgaWYgKG5hbWVkQ29sb3IpIHtcbiAgICAgICAgICAgIGNvbnN0IGNvbG9yID0gZGVmaW5lQ29sb3IobmFtZWRDb2xvcik7XG4gICAgICAgICAgICBpZiAoY29sb3IuaHVlUmFuZ2UpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29sb3IuaHVlUmFuZ2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcGFyc2VkID0gbmV3IFRpbnlDb2xvcihjb2xvcklucHV0KTtcbiAgICAgICAgaWYgKHBhcnNlZC5pc1ZhbGlkKSB7XG4gICAgICAgICAgICBjb25zdCBodWUgPSBwYXJzZWQudG9Ic3YoKS5oO1xuICAgICAgICAgICAgcmV0dXJuIFtodWUsIGh1ZV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIFswLCAzNjBdO1xufVxuZnVuY3Rpb24gZ2V0Q29sb3JJbmZvKGh1ZSkge1xuICAgIC8vIE1hcHMgcmVkIGNvbG9ycyB0byBtYWtlIHBpY2tpbmcgaHVlIGVhc2llclxuICAgIGlmIChodWUgPj0gMzM0ICYmIGh1ZSA8PSAzNjApIHtcbiAgICAgICAgaHVlIC09IDM2MDtcbiAgICB9XG4gICAgZm9yIChjb25zdCBib3VuZCBvZiBib3VuZHMpIHtcbiAgICAgICAgY29uc3QgY29sb3IgPSBkZWZpbmVDb2xvcihib3VuZCk7XG4gICAgICAgIGlmIChjb2xvci5odWVSYW5nZSAmJiBodWUgPj0gY29sb3IuaHVlUmFuZ2VbMF0gJiYgaHVlIDw9IGNvbG9yLmh1ZVJhbmdlWzFdKSB7XG4gICAgICAgICAgICByZXR1cm4gY29sb3I7XG4gICAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgRXJyb3IoJ0NvbG9yIG5vdCBmb3VuZCcpO1xufVxuZnVuY3Rpb24gcmFuZG9tV2l0aGluKHJhbmdlLCBzZWVkKSB7XG4gICAgaWYgKHNlZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm4gTWF0aC5mbG9vcihyYW5nZVswXSArIE1hdGgucmFuZG9tKCkgKiAocmFuZ2VbMV0gKyAxIC0gcmFuZ2VbMF0pKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIFNlZWRlZCByYW5kb20gYWxnb3JpdGhtIGZyb20gaHR0cDovL2luZGllZ2Ftci5jb20vZ2VuZXJhdGUtcmVwZWF0YWJsZS1yYW5kb20tbnVtYmVycy1pbi1qcy9cbiAgICAgICAgY29uc3QgbWF4ID0gcmFuZ2VbMV0gfHwgMTtcbiAgICAgICAgY29uc3QgbWluID0gcmFuZ2VbMF0gfHwgMDtcbiAgICAgICAgc2VlZCA9IChzZWVkICogOTMwMSArIDQ5Mjk3KSAlIDIzMzI4MDtcbiAgICAgICAgY29uc3Qgcm5kID0gc2VlZCAvIDIzMzI4MC4wO1xuICAgICAgICByZXR1cm4gTWF0aC5mbG9vcihtaW4gKyBybmQgKiAobWF4IC0gbWluKSk7XG4gICAgfVxufVxuZnVuY3Rpb24gZGVmaW5lQ29sb3IoYm91bmQpIHtcbiAgICBjb25zdCBzTWluID0gYm91bmQubG93ZXJCb3VuZHNbMF1bMF07XG4gICAgY29uc3Qgc01heCA9IGJvdW5kLmxvd2VyQm91bmRzW2JvdW5kLmxvd2VyQm91bmRzLmxlbmd0aCAtIDFdWzBdO1xuICAgIGNvbnN0IGJNaW4gPSBib3VuZC5sb3dlckJvdW5kc1tib3VuZC5sb3dlckJvdW5kcy5sZW5ndGggLSAxXVsxXTtcbiAgICBjb25zdCBiTWF4ID0gYm91bmQubG93ZXJCb3VuZHNbMF1bMV07XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbmFtZTogYm91bmQubmFtZSxcbiAgICAgICAgaHVlUmFuZ2U6IGJvdW5kLmh1ZVJhbmdlLFxuICAgICAgICBsb3dlckJvdW5kczogYm91bmQubG93ZXJCb3VuZHMsXG4gICAgICAgIHNhdHVyYXRpb25SYW5nZTogW3NNaW4sIHNNYXhdLFxuICAgICAgICBicmlnaHRuZXNzUmFuZ2U6IFtiTWluLCBiTWF4XSxcbiAgICB9O1xufVxuLyoqXG4gKiBAaGlkZGVuXG4gKi9cbmNvbnN0IGJvdW5kcyA9IFtcbiAgICB7XG4gICAgICAgIG5hbWU6ICdtb25vY2hyb21lJyxcbiAgICAgICAgaHVlUmFuZ2U6IG51bGwsXG4gICAgICAgIGxvd2VyQm91bmRzOiBbWzAsIDBdLCBbMTAwLCAwXV0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6ICdyZWQnLFxuICAgICAgICBodWVSYW5nZTogWy0yNiwgMThdLFxuICAgICAgICBsb3dlckJvdW5kczogW1xuICAgICAgICAgICAgWzIwLCAxMDBdLFxuICAgICAgICAgICAgWzMwLCA5Ml0sXG4gICAgICAgICAgICBbNDAsIDg5XSxcbiAgICAgICAgICAgIFs1MCwgODVdLFxuICAgICAgICAgICAgWzYwLCA3OF0sXG4gICAgICAgICAgICBbNzAsIDcwXSxcbiAgICAgICAgICAgIFs4MCwgNjBdLFxuICAgICAgICAgICAgWzkwLCA1NV0sXG4gICAgICAgICAgICBbMTAwLCA1MF0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6ICdvcmFuZ2UnLFxuICAgICAgICBodWVSYW5nZTogWzE5LCA0Nl0sXG4gICAgICAgIGxvd2VyQm91bmRzOiBbWzIwLCAxMDBdLCBbMzAsIDkzXSwgWzQwLCA4OF0sIFs1MCwgODZdLCBbNjAsIDg1XSwgWzcwLCA3MF0sIFsxMDAsIDcwXV0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6ICd5ZWxsb3cnLFxuICAgICAgICBodWVSYW5nZTogWzQ3LCA2Ml0sXG4gICAgICAgIGxvd2VyQm91bmRzOiBbWzI1LCAxMDBdLCBbNDAsIDk0XSwgWzUwLCA4OV0sIFs2MCwgODZdLCBbNzAsIDg0XSwgWzgwLCA4Ml0sIFs5MCwgODBdLCBbMTAwLCA3NV1dLFxuICAgIH0sXG4gICAge1xuICAgICAgICBuYW1lOiAnZ3JlZW4nLFxuICAgICAgICBodWVSYW5nZTogWzYzLCAxNzhdLFxuICAgICAgICBsb3dlckJvdW5kczogW1szMCwgMTAwXSwgWzQwLCA5MF0sIFs1MCwgODVdLCBbNjAsIDgxXSwgWzcwLCA3NF0sIFs4MCwgNjRdLCBbOTAsIDUwXSwgWzEwMCwgNDBdXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgbmFtZTogJ2JsdWUnLFxuICAgICAgICBodWVSYW5nZTogWzE3OSwgMjU3XSxcbiAgICAgICAgbG93ZXJCb3VuZHM6IFtcbiAgICAgICAgICAgIFsyMCwgMTAwXSxcbiAgICAgICAgICAgIFszMCwgODZdLFxuICAgICAgICAgICAgWzQwLCA4MF0sXG4gICAgICAgICAgICBbNTAsIDc0XSxcbiAgICAgICAgICAgIFs2MCwgNjBdLFxuICAgICAgICAgICAgWzcwLCA1Ml0sXG4gICAgICAgICAgICBbODAsIDQ0XSxcbiAgICAgICAgICAgIFs5MCwgMzldLFxuICAgICAgICAgICAgWzEwMCwgMzVdLFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBuYW1lOiAncHVycGxlJyxcbiAgICAgICAgaHVlUmFuZ2U6IFsyNTgsIDI4Ml0sXG4gICAgICAgIGxvd2VyQm91bmRzOiBbXG4gICAgICAgICAgICBbMjAsIDEwMF0sXG4gICAgICAgICAgICBbMzAsIDg3XSxcbiAgICAgICAgICAgIFs0MCwgNzldLFxuICAgICAgICAgICAgWzUwLCA3MF0sXG4gICAgICAgICAgICBbNjAsIDY1XSxcbiAgICAgICAgICAgIFs3MCwgNTldLFxuICAgICAgICAgICAgWzgwLCA1Ml0sXG4gICAgICAgICAgICBbOTAsIDQ1XSxcbiAgICAgICAgICAgIFsxMDAsIDQyXSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgbmFtZTogJ3BpbmsnLFxuICAgICAgICBodWVSYW5nZTogWzI4MywgMzM0XSxcbiAgICAgICAgbG93ZXJCb3VuZHM6IFtbMjAsIDEwMF0sIFszMCwgOTBdLCBbNDAsIDg2XSwgWzYwLCA4NF0sIFs4MCwgODBdLCBbOTAsIDc1XSwgWzEwMCwgNzNdXSxcbiAgICB9LFxuXTtcblxuZXhwb3J0IHsgVGlueUNvbG9yLCBuYW1lcywgcmVhZGFiaWxpdHksIGlzUmVhZGFibGUsIG1vc3RSZWFkYWJsZSwgdG9Nc0ZpbHRlciwgZnJvbVJhdGlvLCBsZWdhY3lSYW5kb20sIGlucHV0VG9SR0IsIHN0cmluZ0lucHV0VG9PYmplY3QsIGlzVmFsaWRDU1NVbml0LCByYW5kb20sIGJvdW5kcyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dGlueWNvbG9yLmVzMjAxNS5qcy5tYXBcbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgeyBUaW55Q29sb3IgfSBmcm9tICdAY3RybC90aW55Y29sb3InXG5pbXBvcnQgeyBxdWVyeVBhZ2UgfSBmcm9tICcuL3NlYXJjaCdcbmltcG9ydCB7IGdldFN0eWxlcywgY2FtZWxUb0Rhc2gsIGlzT2ZmQm91bmRzLCBkZWVwRWxlbWVudEZyb21Qb2ludCB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmNvbnN0IHN0YXRlID0ge1xuICBhY3RpdmU6IHtcbiAgICB0aXA6ICBudWxsLFxuICAgIHRhcmdldDogbnVsbCxcbiAgfSxcbiAgdGlwczogbmV3IE1hcCgpLFxufVxuXG5jb25zdCBzZXJ2aWNlcyA9IHt9XG5cbmV4cG9ydCBmdW5jdGlvbiBNZXRhVGlwKHtzZWxlY3R9KSB7XG4gIHNlcnZpY2VzLnNlbGVjdG9ycyA9IHtzZWxlY3R9XG5cbiAgJCgnYm9keScpLm9uKCdtb3VzZW1vdmUnLCBtb3VzZU1vdmUpXG4gICQoJ2JvZHknKS5vbignY2xpY2snLCB0b2dnbGVQaW5uZWQpXG5cbiAgaG90a2V5cygnZXNjJywgXyA9PiByZW1vdmVBbGwoKSlcblxuICByZXN0b3JlUGlubmVkVGlwcygpXG5cbiAgcmV0dXJuICgpID0+IHtcbiAgICAkKCdib2R5Jykub2ZmKCdtb3VzZW1vdmUnLCBtb3VzZU1vdmUpXG4gICAgJCgnYm9keScpLm9mZignY2xpY2snLCB0b2dnbGVQaW5uZWQpXG4gICAgaG90a2V5cy51bmJpbmQoJ2VzYycpXG4gICAgaGlkZUFsbCgpXG4gIH1cbn1cblxuY29uc3QgbW91c2VNb3ZlID0gZSA9PiB7XG4gIGNvbnN0IHRhcmdldCA9IGRlZXBFbGVtZW50RnJvbVBvaW50KGUuY2xpZW50WCwgZS5jbGllbnRZKVxuXG4gIGlmIChpc09mZkJvdW5kcyh0YXJnZXQpIHx8IHRhcmdldC5ub2RlTmFtZSA9PT0gJ1ZJU0JVRy1NRVRBVElQJyB8fCB0YXJnZXQuaGFzQXR0cmlidXRlKCdkYXRhLW1ldGF0aXAnKSkgeyAvLyBha2E6IG1vdXNlIG91dFxuICAgIGlmIChzdGF0ZS5hY3RpdmUudGlwKSB7XG4gICAgICB3aXBlKHtcbiAgICAgICAgdGlwOiBzdGF0ZS5hY3RpdmUudGlwLFxuICAgICAgICBlOiB7dGFyZ2V0OiBzdGF0ZS5hY3RpdmUudGFyZ2V0fSxcbiAgICAgIH0pXG4gICAgICBjbGVhckFjdGl2ZSgpXG4gICAgfVxuICAgIHJldHVyblxuICB9XG5cbiAgdG9nZ2xlVGFyZ2V0Q3Vyc29yKGUuYWx0S2V5LCB0YXJnZXQpXG5cbiAgc2hvd1RpcCh0YXJnZXQsIGUpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzaG93VGlwKHRhcmdldCwgZSkge1xuICBpZiAoIXN0YXRlLmFjdGl2ZS50aXApIHsgLy8gY3JlYXRlXG4gICAgY29uc3QgdGlwID0gcmVuZGVyKHRhcmdldClcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHRpcClcblxuICAgIHBvc2l0aW9uVGlwKHRpcCwgZSlcbiAgICBvYnNlcnZlKHt0aXAsIHRhcmdldH0pXG5cbiAgICBzdGF0ZS5hY3RpdmUudGlwICAgID0gdGlwXG4gICAgc3RhdGUuYWN0aXZlLnRhcmdldCA9IHRhcmdldFxuICB9XG4gIGVsc2UgaWYgKHRhcmdldCA9PSBzdGF0ZS5hY3RpdmUudGFyZ2V0KSB7IC8vIHVwZGF0ZSBwb3NpdGlvblxuICAgIC8vIHVwZGF0ZSBwb3NpdGlvblxuICAgIHBvc2l0aW9uVGlwKHN0YXRlLmFjdGl2ZS50aXAsIGUpXG4gIH1cbiAgZWxzZSB7IC8vIHVwZGF0ZSBjb250ZW50XG4gICAgcmVuZGVyKHRhcmdldCwgc3RhdGUuYWN0aXZlLnRpcClcbiAgICBzdGF0ZS5hY3RpdmUudGFyZ2V0ID0gdGFyZ2V0XG4gICAgcG9zaXRpb25UaXAoc3RhdGUuYWN0aXZlLnRpcCwgZSlcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcG9zaXRpb25UaXAodGlwLCBlKSB7XG4gIGNvbnN0IHsgbm9ydGgsIHdlc3QgfSA9IG1vdXNlX3F1YWRyYW50KGUpXG4gIGNvbnN0IHsgbGVmdCwgdG9wIH0gICA9IHRpcF9wb3NpdGlvbih0aXAsIGUsIG5vcnRoLCB3ZXN0KVxuXG4gIHRpcC5zdHlsZS5sZWZ0ICA9IGxlZnRcbiAgdGlwLnN0eWxlLnRvcCAgID0gdG9wXG5cbiAgdGlwLnN0eWxlLnNldFByb3BlcnR5KCctLWFycm93Jywgbm9ydGhcbiAgICA/ICd2YXIoLS1hcnJvdy11cCknXG4gICAgOiAndmFyKC0tYXJyb3ctZG93biknKVxuXG4gIHRpcC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1zaGFkb3ctZGlyZWN0aW9uJywgbm9ydGhcbiAgICA/ICd2YXIoLS1zaGFkb3ctdXApJ1xuICAgIDogJ3ZhcigtLXNoYWRvdy1kb3duKScpXG5cbiAgdGlwLnN0eWxlLnNldFByb3BlcnR5KCctLWFycm93LXRvcCcsICFub3J0aFxuICAgID8gJy03cHgnXG4gICAgOiAnY2FsYygxMDAlIC0gMXB4KScpXG5cbiAgdGlwLnN0eWxlLnNldFByb3BlcnR5KCctLWFycm93LWxlZnQnLCB3ZXN0XG4gICAgPyAnY2FsYygxMDAlIC0gMTVweCAtIDE1cHgpJ1xuICAgIDogJzE1cHgnKVxufVxuXG5jb25zdCByZXN0b3JlUGlubmVkVGlwcyA9ICgpID0+IHtcbiAgc3RhdGUudGlwcy5mb3JFYWNoKCh7dGlwfSwgdGFyZ2V0KSA9PiB7XG4gICAgdGlwLnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snXG4gICAgcmVuZGVyKHRhcmdldCwgdGlwKVxuICAgIG9ic2VydmUoe3RpcCwgdGFyZ2V0fSlcbiAgfSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGhpZGVBbGwoKSB7XG4gIHN0YXRlLnRpcHMuZm9yRWFjaCgoe3RpcH0sIHRhcmdldCkgPT5cbiAgICB0aXAuc3R5bGUuZGlzcGxheSA9ICdub25lJylcblxuICBpZiAoc3RhdGUuYWN0aXZlLnRpcCkge1xuICAgIHN0YXRlLmFjdGl2ZS50aXAucmVtb3ZlKClcbiAgICBjbGVhckFjdGl2ZSgpXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHJlbW92ZUFsbCgpIHtcbiAgc3RhdGUudGlwcy5mb3JFYWNoKCh7dGlwfSwgdGFyZ2V0KSA9PiB7XG4gICAgdGlwLnJlbW92ZSgpXG4gICAgdW5vYnNlcnZlKHt0aXAsIHRhcmdldH0pXG4gIH0pXG5cbiAgJCgnW2RhdGEtbWV0YXRpcF0nKS5hdHRyKCdkYXRhLW1ldGF0aXAnLCBudWxsKVxuXG4gIHN0YXRlLnRpcHMuY2xlYXIoKVxufVxuXG5jb25zdCByZW5kZXIgPSAoZWwsIHRpcCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3Zpc2J1Zy1tZXRhdGlwJykpID0+IHtcbiAgY29uc3QgeyB3aWR0aCwgaGVpZ2h0IH0gPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKVxuICBjb25zdCBzdHlsZXMgPSBnZXRTdHlsZXMoZWwpXG4gICAgLm1hcChzdHlsZSA9PiBPYmplY3QuYXNzaWduKHN0eWxlLCB7XG4gICAgICBwcm9wOiBjYW1lbFRvRGFzaChzdHlsZS5wcm9wKVxuICAgIH0pKVxuICAgIC5maWx0ZXIoc3R5bGUgPT5cbiAgICAgIHN0eWxlLnByb3AuaW5jbHVkZXMoJ2ZvbnQtZmFtaWx5JylcbiAgICAgICAgPyBlbC5tYXRjaGVzKCdoMSxoMixoMyxoNCxoNSxoNixwLGEsZGF0ZSxjYXB0aW9uLGJ1dHRvbixmaWdjYXB0aW9uLG5hdixoZWFkZXIsZm9vdGVyJylcbiAgICAgICAgOiB0cnVlXG4gICAgKVxuICAgIC5tYXAoc3R5bGUgPT4ge1xuICAgICAgaWYgKHN0eWxlLnByb3AuaW5jbHVkZXMoJ2NvbG9yJykgfHwgc3R5bGUucHJvcC5pbmNsdWRlcygnQ29sb3InKSB8fCBzdHlsZS5wcm9wLmluY2x1ZGVzKCdmaWxsJykgfHwgc3R5bGUucHJvcC5pbmNsdWRlcygnc3Ryb2tlJykpXG4gICAgICAgIHN0eWxlLnZhbHVlID0gYDxzcGFuIGNvbG9yIHN0eWxlPVwiYmFja2dyb3VuZC1jb2xvcjoke3N0eWxlLnZhbHVlfTtcIj48L3NwYW4+JHtuZXcgVGlueUNvbG9yKHN0eWxlLnZhbHVlKS50b0hzbFN0cmluZygpfWBcblxuICAgICAgaWYgKHN0eWxlLnByb3AuaW5jbHVkZXMoJ2ZvbnQtZmFtaWx5JykgJiYgc3R5bGUudmFsdWUubGVuZ3RoID4gMjUpXG4gICAgICAgIHN0eWxlLnZhbHVlID0gc3R5bGUudmFsdWUuc2xpY2UoMCwyNSkgKyAnLi4uJ1xuXG4gICAgICBpZiAoc3R5bGUucHJvcC5pbmNsdWRlcygnZ3JpZC10ZW1wbGF0ZS1hcmVhcycpKVxuICAgICAgICBzdHlsZS52YWx1ZSA9IHN0eWxlLnZhbHVlLnJlcGxhY2UoL1wiIFwiL2csICdcIjxicj5cIicpXG5cbiAgICAgIGlmIChzdHlsZS5wcm9wLmluY2x1ZGVzKCdiYWNrZ3JvdW5kLWltYWdlJykpXG4gICAgICAgIHN0eWxlLnZhbHVlID0gYDxhIHRhcmdldD1cIl9ibGFua1wiIGhyZWY9XCIke3N0eWxlLnZhbHVlLnNsaWNlKHN0eWxlLnZhbHVlLmluZGV4T2YoJygnKSArIDIsIHN0eWxlLnZhbHVlLmxlbmd0aCAtIDIpfVwiPiR7c3R5bGUudmFsdWUuc2xpY2UoMCwyNSkgKyAnLi4uJ308L2E+YFxuXG4gICAgICAvLyBjaGVjayBpZiBzdHlsZSBpcyBpbmxpbmUgc3R5bGUsIHNob3cgaW5kaWNhdG9yXG4gICAgICBpZiAoZWwuZ2V0QXR0cmlidXRlKCdzdHlsZScpICYmIGVsLmdldEF0dHJpYnV0ZSgnc3R5bGUnKS5pbmNsdWRlcyhzdHlsZS5wcm9wKSlcbiAgICAgICAgc3R5bGUudmFsdWUgPSBgPHNwYW4gbG9jYWwtY2hhbmdlPiR7c3R5bGUudmFsdWV9PC9zcGFuPmBcblxuICAgICAgcmV0dXJuIHN0eWxlXG4gICAgfSlcblxuICBjb25zdCBsb2NhbE1vZGlmaWNhdGlvbnMgPSBzdHlsZXMuZmlsdGVyKHN0eWxlID0+XG4gICAgZWwuZ2V0QXR0cmlidXRlKCdzdHlsZScpICYmIGVsLmdldEF0dHJpYnV0ZSgnc3R5bGUnKS5pbmNsdWRlcyhzdHlsZS5wcm9wKVxuICAgICAgPyAxXG4gICAgICA6IDApXG5cbiAgY29uc3Qgbm90TG9jYWxNb2RpZmljYXRpb25zID0gc3R5bGVzLmZpbHRlcihzdHlsZSA9PlxuICAgIGVsLmdldEF0dHJpYnV0ZSgnc3R5bGUnKSAmJiBlbC5nZXRBdHRyaWJ1dGUoJ3N0eWxlJykuaW5jbHVkZXMoc3R5bGUucHJvcClcbiAgICAgID8gMFxuICAgICAgOiAxKVxuXG4gIHRpcC5tZXRhID0ge1xuICAgIGVsLFxuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICBsb2NhbE1vZGlmaWNhdGlvbnMsXG4gICAgbm90TG9jYWxNb2RpZmljYXRpb25zLFxuICB9XG5cbiAgcmV0dXJuIHRpcFxufVxuXG5jb25zdCBtb3VzZV9xdWFkcmFudCA9IGUgPT4gKHtcbiAgbm9ydGg6IGUuY2xpZW50WSA+IHdpbmRvdy5pbm5lckhlaWdodCAvIDIsXG4gIHdlc3Q6ICBlLmNsaWVudFggPiB3aW5kb3cuaW5uZXJXaWR0aCAvIDJcbn0pXG5cbmNvbnN0IHRpcF9wb3NpdGlvbiA9IChub2RlLCBlLCBub3J0aCwgd2VzdCkgPT4gKHtcbiAgdG9wOiBgJHtub3J0aFxuICAgID8gZS5wYWdlWSAtIG5vZGUuY2xpZW50SGVpZ2h0IC0gMjBcbiAgICA6IGUucGFnZVkgKyAyNX1weGAsXG4gIGxlZnQ6IGAke3dlc3RcbiAgICA/IGUucGFnZVggLSBub2RlLmNsaWVudFdpZHRoICsgMjNcbiAgICA6IGUucGFnZVggLSAyMX1weGAsXG59KVxuXG5jb25zdCBoYW5kbGVCbHVyID0gKHt0YXJnZXR9KSA9PiB7XG4gIGlmICghdGFyZ2V0Lmhhc0F0dHJpYnV0ZSgnZGF0YS1tZXRhdGlwJykgJiYgc3RhdGUudGlwcy5oYXModGFyZ2V0KSlcbiAgICB3aXBlKHN0YXRlLnRpcHMuZ2V0KHRhcmdldCkpXG59XG5cbmNvbnN0IHdpcGUgPSAoe3RpcCwgZTp7dGFyZ2V0fX0pID0+IHtcbiAgdGlwLnJlbW92ZSgpXG4gIHVub2JzZXJ2ZSh7dGlwLCB0YXJnZXR9KVxuICBzdGF0ZS50aXBzLmRlbGV0ZSh0YXJnZXQpXG59XG5cbmNvbnN0IHRvZ2dsZVBpbm5lZCA9IGUgPT4ge1xuICBjb25zdCB0YXJnZXQgPSBkZWVwRWxlbWVudEZyb21Qb2ludChlLmNsaWVudFgsIGUuY2xpZW50WSlcblxuICBpZiAoZS5hbHRLZXkgJiYgIXRhcmdldC5oYXNBdHRyaWJ1dGUoJ2RhdGEtbWV0YXRpcCcpKSB7XG4gICAgdGFyZ2V0LnNldEF0dHJpYnV0ZSgnZGF0YS1tZXRhdGlwJywgdHJ1ZSlcbiAgICBzdGF0ZS50aXBzLnNldCh0YXJnZXQsIHtcbiAgICAgIHRpcDogc3RhdGUuYWN0aXZlLnRpcCxcbiAgICAgIGUsXG4gICAgfSlcbiAgICBjbGVhckFjdGl2ZSgpXG4gIH1cbiAgZWxzZSBpZiAodGFyZ2V0Lmhhc0F0dHJpYnV0ZSgnZGF0YS1tZXRhdGlwJykpIHtcbiAgICB0YXJnZXQucmVtb3ZlQXR0cmlidXRlKCdkYXRhLW1ldGF0aXAnKVxuICAgIHdpcGUoc3RhdGUudGlwcy5nZXQodGFyZ2V0KSlcbiAgfVxufVxuXG5jb25zdCBsaW5rUXVlcnlDbGlja2VkID0gKHtkZXRhaWw6eyB0ZXh0LCBhY3RpdmF0b3IgfX0pID0+IHtcbiAgaWYgKCF0ZXh0KSByZXR1cm5cblxuICBxdWVyeVBhZ2UoJ1tkYXRhLXBzZXVkby1zZWxlY3RdJywgZWwgPT5cbiAgICBlbC5yZW1vdmVBdHRyaWJ1dGUoJ2RhdGEtcHNldWRvLXNlbGVjdCcpKVxuXG4gIHF1ZXJ5UGFnZSh0ZXh0ICsgJzpub3QoW2RhdGEtc2VsZWN0ZWRdKScsIGVsID0+XG4gICAgYWN0aXZhdG9yID09PSAnbW91c2VlbnRlcidcbiAgICAgID8gZWwuc2V0QXR0cmlidXRlKCdkYXRhLXBzZXVkby1zZWxlY3QnLCB0cnVlKVxuICAgICAgOiBzZXJ2aWNlcy5zZWxlY3RvcnMuc2VsZWN0KGVsKSlcbn1cblxuY29uc3QgbGlua1F1ZXJ5SG92ZXJPdXQgPSBlID0+IHtcbiAgcXVlcnlQYWdlKCdbZGF0YS1wc2V1ZG8tc2VsZWN0XScsIGVsID0+XG4gICAgZWwucmVtb3ZlQXR0cmlidXRlKCdkYXRhLXBzZXVkby1zZWxlY3QnKSlcbn1cblxuY29uc3QgdG9nZ2xlVGFyZ2V0Q3Vyc29yID0gKGtleSwgdGFyZ2V0KSA9PlxuICBrZXlcbiAgICA/IHRhcmdldC5zZXRBdHRyaWJ1dGUoJ2RhdGEtcGluaG92ZXInLCB0cnVlKVxuICAgIDogdGFyZ2V0LnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1waW5ob3ZlcicpXG5cbmNvbnN0IG9ic2VydmUgPSAoe3RpcCwgdGFyZ2V0fSkgPT4ge1xuICAkKHRpcCkub24oJ3F1ZXJ5JywgbGlua1F1ZXJ5Q2xpY2tlZClcbiAgJCh0aXApLm9uKCd1bnF1ZXJ5JywgbGlua1F1ZXJ5SG92ZXJPdXQpXG4gICQodGFyZ2V0KS5vbignRE9NTm9kZVJlbW92ZWQnLCBoYW5kbGVCbHVyKVxufVxuXG5jb25zdCB1bm9ic2VydmUgPSAoe3RpcCwgdGFyZ2V0fSkgPT4ge1xuICAkKHRpcCkub2ZmKCdxdWVyeScsIGxpbmtRdWVyeUNsaWNrZWQpXG4gICQodGlwKS5vZmYoJ3VucXVlcnknLCBsaW5rUXVlcnlIb3Zlck91dClcbiAgJCh0YXJnZXQpLm9mZignRE9NTm9kZVJlbW92ZWQnLCBoYW5kbGVCbHVyKVxufVxuXG5jb25zdCBjbGVhckFjdGl2ZSA9ICgpID0+IHtcbiAgc3RhdGUuYWN0aXZlLnRpcCAgICA9IG51bGxcbiAgc3RhdGUuYWN0aXZlLnRhcmdldCA9IG51bGxcbn1cbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgeyBUaW55Q29sb3IsIHJlYWRhYmlsaXR5LCBpc1JlYWRhYmxlIH0gZnJvbSAnQGN0cmwvdGlueWNvbG9yJ1xuaW1wb3J0IHtcbiAgZ2V0U3R5bGUsIGdldFN0eWxlcywgaXNPZmZCb3VuZHMsXG4gIGdldEExMXlzLCBnZXRXQ0FHMlRleHRTaXplLCBnZXRDb21wdXRlZEJhY2tncm91bmRDb2xvcixcbiAgZGVlcEVsZW1lbnRGcm9tUG9pbnRcbn0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuY29uc3Qgc3RhdGUgPSB7XG4gIGFjdGl2ZToge1xuICAgIHRpcDogIG51bGwsXG4gICAgdGFyZ2V0OiBudWxsLFxuICB9LFxuICB0aXBzOiBuZXcgTWFwKCksXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBBY2Nlc3NpYmlsaXR5KCkge1xuICAkKCdib2R5Jykub24oJ21vdXNlbW92ZScsIG1vdXNlTW92ZSlcbiAgJCgnYm9keScpLm9uKCdjbGljaycsIHRvZ2dsZVBpbm5lZClcblxuICBob3RrZXlzKCdlc2MnLCBfID0+IHJlbW92ZUFsbCgpKVxuXG4gIHJlc3RvcmVQaW5uZWRUaXBzKClcblxuICByZXR1cm4gKCkgPT4ge1xuICAgICQoJ2JvZHknKS5vZmYoJ21vdXNlbW92ZScsIG1vdXNlTW92ZSlcbiAgICAkKCdib2R5Jykub2ZmKCdjbGljaycsIHRvZ2dsZVBpbm5lZClcbiAgICBob3RrZXlzLnVuYmluZCgnZXNjJylcbiAgICBoaWRlQWxsKClcbiAgfVxufVxuXG5jb25zdCBtb3VzZU1vdmUgPSBlID0+IHtcbiAgY29uc3QgdGFyZ2V0ID0gZGVlcEVsZW1lbnRGcm9tUG9pbnQoZS5jbGllbnRYLCBlLmNsaWVudFkpXG5cbiAgaWYgKGlzT2ZmQm91bmRzKHRhcmdldCkgfHwgdGFyZ2V0Lm5vZGVOYW1lID09PSAnVklTQlVHLUFMTFlUSVAnIHx8IHRhcmdldC5oYXNBdHRyaWJ1dGUoJ2RhdGEtYWxseXRpcCcpKSB7IC8vIGFrYTogbW91c2Ugb3V0XG4gICAgaWYgKHN0YXRlLmFjdGl2ZS50aXApIHtcbiAgICAgIHdpcGUoe1xuICAgICAgICB0aXA6IHN0YXRlLmFjdGl2ZS50aXAsXG4gICAgICAgIGU6IHt0YXJnZXQ6IHN0YXRlLmFjdGl2ZS50YXJnZXR9LFxuICAgICAgfSlcbiAgICAgIGNsZWFyQWN0aXZlKClcbiAgICB9XG4gICAgcmV0dXJuXG4gIH1cblxuICB0b2dnbGVUYXJnZXRDdXJzb3IoZS5hbHRLZXksIHRhcmdldClcblxuICBzaG93VGlwKHRhcmdldCwgZSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNob3dUaXAodGFyZ2V0LCBlKSB7XG4gIGlmICghc3RhdGUuYWN0aXZlLnRpcCkgeyAvLyBjcmVhdGVcbiAgICBjb25zdCB0aXAgPSByZW5kZXIodGFyZ2V0KVxuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQodGlwKVxuXG4gICAgcG9zaXRpb25UaXAodGlwLCBlKVxuICAgIG9ic2VydmUoe3RpcCwgdGFyZ2V0fSlcblxuICAgIHN0YXRlLmFjdGl2ZS50aXAgICAgPSB0aXBcbiAgICBzdGF0ZS5hY3RpdmUudGFyZ2V0ID0gdGFyZ2V0XG4gIH1cbiAgZWxzZSBpZiAodGFyZ2V0ID09IHN0YXRlLmFjdGl2ZS50YXJnZXQpIHsgLy8gdXBkYXRlIHBvc2l0aW9uXG4gICAgLy8gdXBkYXRlIHBvc2l0aW9uXG4gICAgcG9zaXRpb25UaXAoc3RhdGUuYWN0aXZlLnRpcCwgZSlcbiAgfVxuICBlbHNlIHsgLy8gdXBkYXRlIGNvbnRlbnRcbiAgICByZW5kZXIodGFyZ2V0LCBzdGF0ZS5hY3RpdmUudGlwKVxuICAgIHN0YXRlLmFjdGl2ZS50YXJnZXQgPSB0YXJnZXRcbiAgICBwb3NpdGlvblRpcChzdGF0ZS5hY3RpdmUudGlwLCBlKVxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwb3NpdGlvblRpcCh0aXAsIGUpIHtcbiAgY29uc3QgeyBub3J0aCwgd2VzdCB9ID0gbW91c2VfcXVhZHJhbnQoZSlcbiAgY29uc3Qge2xlZnQsIHRvcH0gICAgID0gdGlwX3Bvc2l0aW9uKHRpcCwgZSwgbm9ydGgsIHdlc3QpXG5cbiAgdGlwLnN0eWxlLmxlZnQgID0gbGVmdFxuICB0aXAuc3R5bGUudG9wICAgPSB0b3BcblxuICB0aXAuc3R5bGUuc2V0UHJvcGVydHkoJy0tYXJyb3cnLCBub3J0aFxuICAgID8gJ3ZhcigtLWFycm93LXVwKSdcbiAgICA6ICd2YXIoLS1hcnJvdy1kb3duKScpXG5cbiAgdGlwLnN0eWxlLnNldFByb3BlcnR5KCctLXNoYWRvdy1kaXJlY3Rpb24nLCBub3J0aFxuICAgID8gJ3ZhcigtLXNoYWRvdy11cCknXG4gICAgOiAndmFyKC0tc2hhZG93LWRvd24pJylcblxuICB0aXAuc3R5bGUuc2V0UHJvcGVydHkoJy0tYXJyb3ctdG9wJywgIW5vcnRoXG4gICAgPyAnLTdweCdcbiAgICA6ICdjYWxjKDEwMCUgLSAxcHgpJylcblxuICB0aXAuc3R5bGUuc2V0UHJvcGVydHkoJy0tYXJyb3ctbGVmdCcsIHdlc3RcbiAgICA/ICdjYWxjKDEwMCUgLSAxNXB4IC0gMTVweCknXG4gICAgOiAnMTVweCcpXG59XG5cbmNvbnN0IHJlc3RvcmVQaW5uZWRUaXBzID0gKCkgPT4ge1xuICBzdGF0ZS50aXBzLmZvckVhY2goKHt0aXB9LCB0YXJnZXQpID0+IHtcbiAgICB0aXAuc3R5bGUuZGlzcGxheSA9ICdibG9jaydcbiAgICByZW5kZXIodGFyZ2V0LCB0aXApXG4gICAgb2JzZXJ2ZSh7dGlwLCB0YXJnZXR9KVxuICB9KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gaGlkZUFsbCgpIHtcbiAgc3RhdGUudGlwcy5mb3JFYWNoKCh7dGlwfSwgdGFyZ2V0KSA9PlxuICAgIHRpcC5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnKVxuXG4gIGlmIChzdGF0ZS5hY3RpdmUudGlwKSB7XG4gICAgc3RhdGUuYWN0aXZlLnRpcC5yZW1vdmUoKVxuICAgIGNsZWFyQWN0aXZlKClcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlQWxsKCkge1xuICBzdGF0ZS50aXBzLmZvckVhY2goKHt0aXB9LCB0YXJnZXQpID0+IHtcbiAgICB0aXAucmVtb3ZlKClcbiAgICB1bm9ic2VydmUoe3RpcCwgdGFyZ2V0fSlcbiAgfSlcblxuICAkKCdbZGF0YS1hbGx5dGlwXScpLmF0dHIoJ2RhdGEtYWxseXRpcCcsIG51bGwpXG5cbiAgc3RhdGUudGlwcy5jbGVhcigpXG59XG5cbmNvbnN0IHJlbmRlciA9IChlbCwgdGlwID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndmlzYnVnLWFsbHknKSkgPT4ge1xuICBjb25zdCBjb250cmFzdF9yZXN1bHRzID0gZGV0ZXJtaW5lQ29sb3JDb250cmFzdChlbClcbiAgY29uc3QgYWxseV9hdHRyaWJ1dGVzID0gZ2V0QTExeXMoZWwpXG5cbiAgYWxseV9hdHRyaWJ1dGVzLm1hcChhbGx5ID0+XG4gICAgYWxseS5wcm9wLmluY2x1ZGVzKCdhbHQnKVxuICAgICAgPyBhbGx5LnZhbHVlID0gYDxzcGFuIHRleHQ+JHthbGx5LnZhbHVlfTwvc3Bhbj5gXG4gICAgICA6IGFsbHkpXG5cbiAgYWxseV9hdHRyaWJ1dGVzLm1hcChhbGx5ID0+XG4gICAgYWxseS5wcm9wLmluY2x1ZGVzKCd0aXRsZScpXG4gICAgICA/IGFsbHkudmFsdWUgPSBgPHNwYW4gdGV4dCBsb25nZm9ybT4ke2FsbHkudmFsdWV9PC9zcGFuPmBcbiAgICAgIDogYWxseSlcblxuICB0aXAubWV0YSA9IHtcbiAgICBlbCxcbiAgICBhbGx5X2F0dHJpYnV0ZXMsXG4gICAgY29udHJhc3RfcmVzdWx0cyxcbiAgfVxuXG4gIHJldHVybiB0aXBcbn1cblxuY29uc3QgZGV0ZXJtaW5lQ29sb3JDb250cmFzdCA9IGVsID0+IHtcbiAgLy8gcXVlc3Rpb246IGhvdyB0byBrbm93IGlmIHRoZSBjdXJyZW50IG5vZGUgaXMgYWN0dWFsbHkgYSBibGFjayBiYWNrZ3JvdW5kP1xuICAvLyBxdWVzdGlvbjogaXMgdGhlcmUgYW4gYXBpIGZvciBjb21wb3NpdGVkIHZhbHVlcz9cbiAgY29uc3QgdGV4dCAgICAgID0gZ2V0U3R5bGUoZWwsICdjb2xvcicpXG4gIGNvbnN0IHRleHRTaXplICA9IGdldFdDQUcyVGV4dFNpemUoZWwpXG5cbiAgbGV0IGJhY2tncm91bmQgID0gZ2V0Q29tcHV0ZWRCYWNrZ3JvdW5kQ29sb3IoZWwpXG5cbiAgY29uc3QgWyBhYV9jb250cmFzdCwgYWFhX2NvbnRyYXN0IF0gPSBbXG4gICAgaXNSZWFkYWJsZShiYWNrZ3JvdW5kLCB0ZXh0LCB7IGxldmVsOiBcIkFBXCIsIHNpemU6IHRleHRTaXplLnRvTG93ZXJDYXNlKCkgfSksXG4gICAgaXNSZWFkYWJsZShiYWNrZ3JvdW5kLCB0ZXh0LCB7IGxldmVsOiBcIkFBQVwiLCBzaXplOiB0ZXh0U2l6ZS50b0xvd2VyQ2FzZSgpIH0pXG4gIF1cblxuICByZXR1cm4gYFxuICAgIDxzcGFuIHByb3A+Q29sb3IgY29udHJhc3Q8L3NwYW4+XG4gICAgPHNwYW4gdmFsdWUgY29udHJhc3Q+XG4gICAgICA8c3BhbiBzdHlsZT1cIlxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiR7YmFja2dyb3VuZH07XG4gICAgICAgIGNvbG9yOiR7dGV4dH07XG4gICAgICBcIj4ke01hdGguZmxvb3IocmVhZGFiaWxpdHkoYmFja2dyb3VuZCwgdGV4dCkgICogMTAwKSAvIDEwMH08L3NwYW4+XG4gICAgPC9zcGFuPlxuICAgIDxzcGFuIHByb3A+4oC6IEFBICR7dGV4dFNpemV9PC9zcGFuPlxuICAgIDxzcGFuIHZhbHVlIHN0eWxlPVwiJHthYV9jb250cmFzdCA/ICdjb2xvcjpncmVlbjsnIDogJ2NvbG9yOnJlZCd9XCI+JHthYV9jb250cmFzdCA/ICfinJMnIDogJ8OXJ308L3NwYW4+XG4gICAgPHNwYW4gcHJvcD7igLogQUFBICR7dGV4dFNpemV9PC9zcGFuPlxuICAgIDxzcGFuIHZhbHVlIHN0eWxlPVwiJHthYWFfY29udHJhc3QgPyAnY29sb3I6Z3JlZW47JyA6ICdjb2xvcjpyZWQnfVwiPiR7YWFhX2NvbnRyYXN0ID8gJ+KckycgOiAnw5cnfTwvc3Bhbj5cbiAgYFxufVxuXG5jb25zdCBtb3VzZV9xdWFkcmFudCA9IGUgPT4gKHtcbiAgbm9ydGg6IGUuY2xpZW50WSA+IHdpbmRvdy5pbm5lckhlaWdodCAvIDIsXG4gIHdlc3Q6ICBlLmNsaWVudFggPiB3aW5kb3cuaW5uZXJXaWR0aCAvIDJcbn0pXG5cbmNvbnN0IHRpcF9wb3NpdGlvbiA9IChub2RlLCBlLCBub3J0aCwgd2VzdCkgPT4gKHtcbiAgdG9wOiBgJHtub3J0aFxuICAgID8gZS5wYWdlWSAtIG5vZGUuY2xpZW50SGVpZ2h0IC0gMjBcbiAgICA6IGUucGFnZVkgKyAyNX1weGAsXG4gIGxlZnQ6IGAke3dlc3RcbiAgICA/IGUucGFnZVggLSBub2RlLmNsaWVudFdpZHRoICsgMjNcbiAgICA6IGUucGFnZVggLSAyMX1weGAsXG59KVxuXG5jb25zdCBoYW5kbGVCbHVyID0gKHt0YXJnZXR9KSA9PiB7XG4gIGlmICghdGFyZ2V0Lmhhc0F0dHJpYnV0ZSgnZGF0YS1hbGx5dGlwJykgJiYgc3RhdGUudGlwcy5oYXModGFyZ2V0KSlcbiAgICB3aXBlKHN0YXRlLnRpcHMuZ2V0KHRhcmdldCkpXG59XG5cbmNvbnN0IHdpcGUgPSAoe3RpcCwgZTp7dGFyZ2V0fX0pID0+IHtcbiAgdGlwLnJlbW92ZSgpXG4gIHVub2JzZXJ2ZSh7dGlwLCB0YXJnZXR9KVxuICBzdGF0ZS50aXBzLmRlbGV0ZSh0YXJnZXQpXG59XG5cbmNvbnN0IHRvZ2dsZVBpbm5lZCA9IGUgPT4ge1xuICBjb25zdCB0YXJnZXQgPSBkZWVwRWxlbWVudEZyb21Qb2ludChlLmNsaWVudFgsIGUuY2xpZW50WSlcblxuICBpZiAoZS5hbHRLZXkgJiYgIXRhcmdldC5oYXNBdHRyaWJ1dGUoJ2RhdGEtYWxseXRpcCcpKSB7XG4gICAgdGFyZ2V0LnNldEF0dHJpYnV0ZSgnZGF0YS1hbGx5dGlwJywgdHJ1ZSlcbiAgICBzdGF0ZS50aXBzLnNldCh0YXJnZXQsIHtcbiAgICAgIHRpcDogc3RhdGUuYWN0aXZlLnRpcCxcbiAgICAgIGUsXG4gICAgfSlcbiAgICBjbGVhckFjdGl2ZSgpXG4gIH1cbiAgZWxzZSBpZiAodGFyZ2V0Lmhhc0F0dHJpYnV0ZSgnZGF0YS1hbGx5dGlwJykpIHtcbiAgICB0YXJnZXQucmVtb3ZlQXR0cmlidXRlKCdkYXRhLWFsbHl0aXAnKVxuICAgIHdpcGUoc3RhdGUudGlwcy5nZXQodGFyZ2V0KSlcbiAgfVxufVxuXG5jb25zdCB0b2dnbGVUYXJnZXRDdXJzb3IgPSAoa2V5LCB0YXJnZXQpID0+XG4gIGtleVxuICAgID8gdGFyZ2V0LnNldEF0dHJpYnV0ZSgnZGF0YS1waW5ob3ZlcicsIHRydWUpXG4gICAgOiB0YXJnZXQucmVtb3ZlQXR0cmlidXRlKCdkYXRhLXBpbmhvdmVyJylcblxuY29uc3Qgb2JzZXJ2ZSA9ICh7dGlwLCB0YXJnZXR9KSA9PiB7XG4gICQodGFyZ2V0KS5vbignRE9NTm9kZVJlbW92ZWQnLCBoYW5kbGVCbHVyKVxufVxuXG5jb25zdCB1bm9ic2VydmUgPSAoe3RpcCwgdGFyZ2V0fSkgPT4ge1xuICAkKHRhcmdldCkub2ZmKCdET01Ob2RlUmVtb3ZlZCcsIGhhbmRsZUJsdXIpXG59XG5cbmNvbnN0IGNsZWFyQWN0aXZlID0gKCkgPT4ge1xuICBzdGF0ZS5hY3RpdmUudGlwICAgID0gbnVsbFxuICBzdGF0ZS5hY3RpdmUudGFyZ2V0ID0gbnVsbFxufVxuIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcblxuaW1wb3J0IHsgY2FuTW92ZUxlZnQsIGNhbk1vdmVSaWdodCwgY2FuTW92ZVVwIH0gZnJvbSAnLi9tb3ZlJ1xuaW1wb3J0IHsgd2F0Y2hJbWFnZXNGb3JVcGxvYWQgfSBmcm9tICcuL2ltYWdlc3dhcCdcbmltcG9ydCB7IHF1ZXJ5UGFnZSB9IGZyb20gJy4vc2VhcmNoJ1xuaW1wb3J0IHsgY3JlYXRlTWVhc3VyZW1lbnRzLCBjbGVhck1lYXN1cmVtZW50cyB9IGZyb20gJy4vbWVhc3VyZW1lbnRzJ1xuaW1wb3J0IHsgc2hvd1RpcCBhcyBzaG93TWV0YVRpcCwgcmVtb3ZlQWxsIGFzIHJlbW92ZUFsbE1ldGFUaXBzIH0gZnJvbSAnLi9tZXRhdGlwJ1xuaW1wb3J0IHsgc2hvd1RpcCBhcyBzaG93QWNjZXNzaWJpbGl0eVRpcCwgcmVtb3ZlQWxsIGFzIHJlbW92ZUFsbEFjY2Vzc2liaWxpdHlUaXBzIH0gZnJvbSAnLi9hY2Nlc3NpYmlsaXR5J1xuXG5pbXBvcnQge1xuICBtZXRhS2V5LCBodG1sU3RyaW5nVG9Eb20sIGNyZWF0ZUNsYXNzbmFtZSxcbiAgaXNPZmZCb3VuZHMsIGdldFN0eWxlcywgZGVlcEVsZW1lbnRGcm9tUG9pbnQsXG4gIGlzU2VsZWN0b3JWYWxpZCwgZmluZE5lYXJlc3RDaGlsZEVsZW1lbnQsIGZpbmROZWFyZXN0UGFyZW50RWxlbWVudFxufSBmcm9tICcuLi91dGlsaXRpZXMvJ1xuXG5leHBvcnQgZnVuY3Rpb24gU2VsZWN0YWJsZSgpIHtcbiAgY29uc3QgcGFnZSAgICAgICAgICAgICAgPSBkb2N1bWVudC5ib2R5XG4gIGxldCBzZWxlY3RlZCAgICAgICAgICAgID0gW11cbiAgbGV0IHNlbGVjdGVkQ2FsbGJhY2tzICAgPSBbXVxuICBsZXQgbGFiZWxzICAgICAgICAgICAgICA9IFtdXG4gIGxldCBoYW5kbGVzICAgICAgICAgICAgID0gW11cblxuICBjb25zdCBob3Zlcl9zdGF0ZSAgICAgICA9IHtcbiAgICB0YXJnZXQ6ICAgbnVsbCxcbiAgICBlbGVtZW50OiAgbnVsbCxcbiAgICBsYWJlbDogICAgbnVsbCxcbiAgfVxuXG4gIGNvbnN0IGxpc3RlbiA9ICgpID0+IHtcbiAgICBwYWdlLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgb25fY2xpY2ssIHRydWUpXG4gICAgcGFnZS5hZGRFdmVudExpc3RlbmVyKCdkYmxjbGljaycsIG9uX2RibGNsaWNrLCB0cnVlKVxuXG4gICAgcGFnZS5vbignc2VsZWN0c3RhcnQnLCBvbl9zZWxlY3Rpb24pXG4gICAgcGFnZS5vbignbW91c2Vtb3ZlJywgb25faG92ZXIpXG5cbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjb3B5Jywgb25fY29weSlcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjdXQnLCBvbl9jdXQpXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigncGFzdGUnLCBvbl9wYXN0ZSlcblxuICAgIHdhdGNoQ29tbWFuZEtleSgpXG5cbiAgICBob3RrZXlzKGAke21ldGFLZXl9K2FsdCtjYCwgb25fY29weV9zdHlsZXMpXG4gICAgaG90a2V5cyhgJHttZXRhS2V5fSthbHQrdmAsIGUgPT4gb25fcGFzdGVfc3R5bGVzKCkpXG4gICAgaG90a2V5cygnZXNjJywgb25fZXNjKVxuICAgIGhvdGtleXMoYCR7bWV0YUtleX0rZGAsIG9uX2R1cGxpY2F0ZSlcbiAgICBob3RrZXlzKCdiYWNrc3BhY2UsZGVsLGRlbGV0ZScsIG9uX2RlbGV0ZSlcbiAgICBob3RrZXlzKCdhbHQrZGVsLGFsdCtiYWNrc3BhY2UnLCBvbl9jbGVhcnN0eWxlcylcbiAgICBob3RrZXlzKGAke21ldGFLZXl9K2UsJHttZXRhS2V5fStzaGlmdCtlYCwgb25fZXhwYW5kX3NlbGVjdGlvbilcbiAgICBob3RrZXlzKGAke21ldGFLZXl9K2csJHttZXRhS2V5fStzaGlmdCtnYCwgb25fZ3JvdXApXG4gICAgaG90a2V5cygndGFiLHNoaWZ0K3RhYixlbnRlcixzaGlmdCtlbnRlcicsIG9uX2tleWJvYXJkX3RyYXZlcnNhbClcbiAgICBob3RrZXlzKGAke21ldGFLZXl9K3NoaWZ0K2VudGVyYCwgb25fc2VsZWN0X2NoaWxkcmVuKVxuICB9XG5cbiAgY29uc3QgdW5saXN0ZW4gPSAoKSA9PiB7XG4gICAgcGFnZS5yZW1vdmVFdmVudExpc3RlbmVyKCdjbGljaycsIG9uX2NsaWNrLCB0cnVlKVxuICAgIHBhZ2UucmVtb3ZlRXZlbnRMaXN0ZW5lcignZGJsY2xpY2snLCBvbl9kYmxjbGljaywgdHJ1ZSlcblxuICAgIHBhZ2Uub2ZmKCdzZWxlY3RzdGFydCcsIG9uX3NlbGVjdGlvbilcbiAgICBwYWdlLm9mZignbW91c2Vtb3ZlJywgb25faG92ZXIpXG5cbiAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdjb3B5Jywgb25fY29weSlcbiAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdjdXQnLCBvbl9jdXQpXG4gICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigncGFzdGUnLCBvbl9wYXN0ZSlcblxuICAgIGhvdGtleXMudW5iaW5kKGBlc2MsJHttZXRhS2V5fStkLGJhY2tzcGFjZSxkZWwsZGVsZXRlLGFsdCtkZWwsYWx0K2JhY2tzcGFjZSwke21ldGFLZXl9K2UsJHttZXRhS2V5fStzaGlmdCtlLCR7bWV0YUtleX0rZywke21ldGFLZXl9K3NoaWZ0K2csdGFiLHNoaWZ0K3RhYixlbnRlcixzaGlmdCtlbnRlcmApXG4gIH1cblxuICBjb25zdCBvbl9jbGljayA9IGUgPT4ge1xuICAgIGNvbnN0ICR0YXJnZXQgPSBkZWVwRWxlbWVudEZyb21Qb2ludChlLmNsaWVudFgsIGUuY2xpZW50WSlcblxuICAgIGlmIChpc09mZkJvdW5kcygkdGFyZ2V0KSAmJiAhc2VsZWN0ZWQuZmlsdGVyKGVsID0+IGVsID09ICR0YXJnZXQpLmxlbmd0aClcbiAgICAgIHJldHVyblxuXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgaWYgKCFlLmFsdEtleSkgZS5zdG9wUHJvcGFnYXRpb24oKVxuICAgIGlmICghZS5zaGlmdEtleSkgdW5zZWxlY3RfYWxsKClcblxuICAgIGlmKGUuc2hpZnRLZXkgJiYgJHRhcmdldC5oYXNBdHRyaWJ1dGUoJ2RhdGEtc2VsZWN0ZWQnKSlcbiAgICAgIHVuc2VsZWN0KCR0YXJnZXQuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJykpXG4gICAgZWxzZVxuICAgICAgc2VsZWN0KCR0YXJnZXQpXG4gIH1cblxuICBjb25zdCB1bnNlbGVjdCA9IGlkID0+IHtcbiAgICBbLi4ubGFiZWxzLCAuLi5oYW5kbGVzXVxuICAgICAgLmZpbHRlcihub2RlID0+XG4gICAgICAgICAgbm9kZS5nZXRBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnKSA9PT0gaWQpXG4gICAgICAgIC5mb3JFYWNoKG5vZGUgPT5cbiAgICAgICAgICBub2RlLnJlbW92ZSgpKVxuXG4gICAgc2VsZWN0ZWQuZmlsdGVyKG5vZGUgPT5cbiAgICAgIG5vZGUuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJykgPT09IGlkKVxuICAgICAgLmZvckVhY2gobm9kZSA9PlxuICAgICAgICAkKG5vZGUpLmF0dHIoe1xuICAgICAgICAgICdkYXRhLXNlbGVjdGVkJzogICAgICBudWxsLFxuICAgICAgICAgICdkYXRhLXNlbGVjdGVkLWhpZGUnOiBudWxsLFxuICAgICAgICAgICdkYXRhLWxhYmVsLWlkJzogICAgICBudWxsLFxuICAgICAgICAgICdkYXRhLXBzZXVkby1zZWxlY3QnOiAgICAgICAgIG51bGwsXG4gICAgICAgICAgJ2RhdGEtbWVhc3VyaW5nJzogICAgIG51bGwsXG4gICAgICB9KSlcblxuICAgIHNlbGVjdGVkID0gc2VsZWN0ZWQuZmlsdGVyKG5vZGUgPT4gbm9kZS5nZXRBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnKSAhPT0gaWQpXG5cbiAgICB0ZWxsV2F0Y2hlcnMoKVxuICB9XG5cbiAgY29uc3Qgb25fZGJsY2xpY2sgPSBlID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG4gICAgaWYgKGlzT2ZmQm91bmRzKGUudGFyZ2V0KSkgcmV0dXJuXG4gICAgJCgndmlzLWJ1ZycpWzBdLnRvb2xTZWxlY3RlZCgndGV4dCcpXG4gIH1cblxuICBjb25zdCB3YXRjaENvbW1hbmRLZXkgPSBlID0+IHtcbiAgICBsZXQgZGlkX2hpZGUgPSBmYWxzZVxuXG4gICAgZG9jdW1lbnQub25rZXlkb3duID0gZnVuY3Rpb24oZSkge1xuICAgICAgaWYgKGhvdGtleXMuY3RybCAmJiBzZWxlY3RlZC5sZW5ndGgpIHtcbiAgICAgICAgJCgndmlzYnVnLWhhbmRsZXMsIHZpc2J1Zy1sYWJlbCwgdmlzYnVnLWhvdmVyJykuZm9yRWFjaChlbCA9PlxuICAgICAgICAgIGVsLnN0eWxlLmRpc3BsYXkgPSAnbm9uZScpXG5cbiAgICAgICAgZGlkX2hpZGUgPSB0cnVlXG4gICAgICB9XG4gICAgfVxuXG4gICAgZG9jdW1lbnQub25rZXl1cCA9IGZ1bmN0aW9uKGUpIHtcbiAgICAgIGlmIChkaWRfaGlkZSkge1xuICAgICAgICAkKCd2aXNidWctaGFuZGxlcywgdmlzYnVnLWxhYmVsLCB2aXNidWctaG92ZXInKS5mb3JFYWNoKGVsID0+XG4gICAgICAgICAgZWwuc3R5bGUuZGlzcGxheSA9IG51bGwpXG5cbiAgICAgICAgZGlkX2hpZGUgPSBmYWxzZVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IG9uX2VzYyA9IF8gPT5cbiAgICBzZWxlY3RlZC5sZW5ndGggJiYgdW5zZWxlY3RfYWxsKClcblxuICBjb25zdCBvbl9kdXBsaWNhdGUgPSBlID0+IHtcbiAgICBjb25zdCByb290X25vZGUgPSBzZWxlY3RlZFswXVxuICAgIGlmICghcm9vdF9ub2RlKSByZXR1cm5cblxuICAgIGNvbnN0IGRlZXBfY2xvbmUgPSByb290X25vZGUuY2xvbmVOb2RlKHRydWUpXG4gICAgZGVlcF9jbG9uZS5yZW1vdmVBdHRyaWJ1dGUoJ2RhdGEtc2VsZWN0ZWQnKVxuICAgIHJvb3Rfbm9kZS5wYXJlbnROb2RlLmluc2VydEJlZm9yZShkZWVwX2Nsb25lLCByb290X25vZGUubmV4dFNpYmxpbmcpXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gIH1cblxuICBjb25zdCBvbl9kZWxldGUgPSBlID0+XG4gICAgc2VsZWN0ZWQubGVuZ3RoICYmIGRlbGV0ZV9hbGwoKVxuXG4gIGNvbnN0IG9uX2NsZWFyc3R5bGVzID0gZSA9PlxuICAgIHNlbGVjdGVkLmZvckVhY2goZWwgPT5cbiAgICAgIGVsLmF0dHIoJ3N0eWxlJywgbnVsbCkpXG5cbiAgY29uc3Qgb25fY29weSA9IGUgPT4ge1xuICAgIC8vIGlmIHVzZXIgaGFzIHNlbGVjdGVkIHRleHQsIGRvbnQgdHJ5IHRvIGNvcHkgYW4gZWxlbWVudFxuICAgIGlmICh3aW5kb3cuZ2V0U2VsZWN0aW9uKCkudG9TdHJpbmcoKS5sZW5ndGgpXG4gICAgICByZXR1cm5cblxuICAgIGlmIChzZWxlY3RlZFswXSAmJiB0aGlzLm5vZGVfY2xpcGJvYXJkICE9PSBzZWxlY3RlZFswXSkge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICBsZXQgJG5vZGUgPSBzZWxlY3RlZFswXS5jbG9uZU5vZGUodHJ1ZSlcbiAgICAgICRub2RlLnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1zZWxlY3RlZCcpXG4gICAgICB0aGlzLmNvcHlfYmFja3VwID0gJG5vZGUub3V0ZXJIVE1MXG4gICAgICBlLmNsaXBib2FyZERhdGEuc2V0RGF0YSgndGV4dC9odG1sJywgdGhpcy5jb3B5X2JhY2t1cClcbiAgICB9XG4gIH1cblxuICBjb25zdCBvbl9jdXQgPSBlID0+IHtcbiAgICBpZiAoc2VsZWN0ZWRbMF0gJiYgdGhpcy5ub2RlX2NsaXBib2FyZCAhPT0gc2VsZWN0ZWRbMF0pIHtcbiAgICAgIGxldCAkbm9kZSA9IHNlbGVjdGVkWzBdLmNsb25lTm9kZSh0cnVlKVxuICAgICAgJG5vZGUucmVtb3ZlQXR0cmlidXRlKCdkYXRhLXNlbGVjdGVkJylcbiAgICAgIHRoaXMuY29weV9iYWNrdXAgPSAkbm9kZS5vdXRlckhUTUxcbiAgICAgIGUuY2xpcGJvYXJkRGF0YS5zZXREYXRhKCd0ZXh0L2h0bWwnLCB0aGlzLmNvcHlfYmFja3VwKVxuICAgICAgc2VsZWN0ZWRbMF0ucmVtb3ZlKClcbiAgICB9XG4gIH1cblxuICBjb25zdCBvbl9wYXN0ZSA9IGUgPT4ge1xuICAgIGNvbnN0IGNsaXBEYXRhID0gZS5jbGlwYm9hcmREYXRhLmdldERhdGEoJ3RleHQvaHRtbCcpXG4gICAgY29uc3QgcG90ZW50aWFsSFRNTCA9IGNsaXBEYXRhIHx8IHRoaXMuY29weV9iYWNrdXBcbiAgICBpZiAoc2VsZWN0ZWRbMF0gJiYgcG90ZW50aWFsSFRNTCkge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICBzZWxlY3RlZFswXS5hcHBlbmRDaGlsZChcbiAgICAgICAgaHRtbFN0cmluZ1RvRG9tKHBvdGVudGlhbEhUTUwpKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IG9uX2NvcHlfc3R5bGVzID0gZSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgdGhpcy5jb3BpZWRfc3R5bGVzID0gc2VsZWN0ZWQubWFwKGVsID0+XG4gICAgICBnZXRTdHlsZXMoZWwpKVxuICB9XG5cbiAgY29uc3Qgb25fcGFzdGVfc3R5bGVzID0gKGluZGV4ID0gMCkgPT5cbiAgICBzZWxlY3RlZC5mb3JFYWNoKGVsID0+IHtcbiAgICAgIHRoaXMuY29waWVkX3N0eWxlc1tpbmRleF1cbiAgICAgICAgLm1hcCgoe3Byb3AsIHZhbHVlfSkgPT5cbiAgICAgICAgICBlbC5zdHlsZVtwcm9wXSA9IHZhbHVlKVxuXG4gICAgICBpbmRleCA+PSB0aGlzLmNvcGllZF9zdHlsZXMubGVuZ3RoIC0gMVxuICAgICAgICA/IGluZGV4ID0gMFxuICAgICAgICA6IGluZGV4KytcbiAgICB9KVxuXG4gIGNvbnN0IG9uX2V4cGFuZF9zZWxlY3Rpb24gPSAoZSwge2tleX0pID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcblxuICAgIGNvbnN0IFtyb290XSA9IHNlbGVjdGVkXG4gICAgaWYgKCFyb290KSByZXR1cm5cblxuICAgIGNvbnN0IHF1ZXJ5ID0gY29tYmluZU5vZGVOYW1lQW5kQ2xhc3Mocm9vdClcblxuICAgIGlmIChpc1NlbGVjdG9yVmFsaWQocXVlcnkpKVxuICAgICAgZXhwYW5kU2VsZWN0aW9uKHtcbiAgICAgICAgcXVlcnksXG4gICAgICAgIGFsbDoga2V5LmluY2x1ZGVzKCdzaGlmdCcpLFxuICAgICAgfSlcbiAgfVxuXG4gIGNvbnN0IG9uX2dyb3VwID0gKGUsIHtrZXl9KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICBpZiAoa2V5LnNwbGl0KCcrJykuaW5jbHVkZXMoJ3NoaWZ0JykpIHtcbiAgICAgIGxldCAkc2VsZWN0ZWQgPSBbLi4uc2VsZWN0ZWRdXG4gICAgICB1bnNlbGVjdF9hbGwoKVxuICAgICAgJHNlbGVjdGVkLnJldmVyc2UoKS5mb3JFYWNoKGVsID0+IHtcbiAgICAgICAgbGV0IGwgPSBlbC5jaGlsZHJlbi5sZW5ndGhcbiAgICAgICAgd2hpbGUgKGVsLmNoaWxkcmVuLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICB2YXIgbm9kZSA9IGVsLmNoaWxkTm9kZXNbZWwuY2hpbGRyZW4ubGVuZ3RoIC0gMV1cbiAgICAgICAgICBpZiAobm9kZS5ub2RlTmFtZSAhPT0gJyN0ZXh0JylcbiAgICAgICAgICAgIHNlbGVjdChub2RlKVxuICAgICAgICAgIGVsLnBhcmVudE5vZGUucHJlcGVuZChub2RlKVxuICAgICAgICB9XG4gICAgICAgIGVsLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoZWwpXG4gICAgICB9KVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIGxldCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICAgICAgc2VsZWN0ZWRbMF0ucGFyZW50Tm9kZS5wcmVwZW5kKFxuICAgICAgICBzZWxlY3RlZC5yZXZlcnNlKCkucmVkdWNlKChkaXYsIGVsKSA9PiB7XG4gICAgICAgICAgZGl2LmFwcGVuZENoaWxkKGVsKVxuICAgICAgICAgIHJldHVybiBkaXZcbiAgICAgICAgfSwgZGl2KVxuICAgICAgKVxuICAgICAgdW5zZWxlY3RfYWxsKClcbiAgICAgIHNlbGVjdChkaXYpXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgb25fc2VsZWN0aW9uID0gZSA9PlxuICAgICFpc09mZkJvdW5kcyhlLnRhcmdldClcbiAgICAmJiBzZWxlY3RlZC5sZW5ndGhcbiAgICAmJiBzZWxlY3RlZFswXS50ZXh0Q29udGVudCAhPSBlLnRhcmdldC50ZXh0Q29udGVudFxuICAgICYmIGUucHJldmVudERlZmF1bHQoKVxuXG4gIGNvbnN0IG9uX2tleWJvYXJkX3RyYXZlcnNhbCA9IChlLCB7a2V5fSkgPT4ge1xuICAgIGlmICghc2VsZWN0ZWQubGVuZ3RoKSByZXR1cm5cblxuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcblxuICAgIGNvbnN0IHRhcmdldHMgPSBzZWxlY3RlZC5yZWR1Y2UoKGZsYXRfbl91bmlxdWUsIG5vZGUpID0+IHtcbiAgICAgIGNvbnN0IGVsZW1lbnRfdG9fbGVmdCAgICAgPSBjYW5Nb3ZlTGVmdChub2RlKVxuICAgICAgY29uc3QgZWxlbWVudF90b19yaWdodCAgICA9IGNhbk1vdmVSaWdodChub2RlKVxuICAgICAgY29uc3QgaGFzX3BhcmVudF9lbGVtZW50ICA9IGZpbmROZWFyZXN0UGFyZW50RWxlbWVudChub2RlKVxuICAgICAgY29uc3QgaGFzX2NoaWxkX2VsZW1lbnRzICA9IGZpbmROZWFyZXN0Q2hpbGRFbGVtZW50KG5vZGUpXG5cbiAgICAgIGlmIChrZXkuaW5jbHVkZXMoJ3NoaWZ0JykpIHtcbiAgICAgICAgaWYgKGtleS5pbmNsdWRlcygndGFiJykgJiYgZWxlbWVudF90b19sZWZ0KVxuICAgICAgICAgIGZsYXRfbl91bmlxdWUuYWRkKGVsZW1lbnRfdG9fbGVmdClcbiAgICAgICAgZWxzZSBpZiAoa2V5LmluY2x1ZGVzKCdlbnRlcicpICYmIGhhc19wYXJlbnRfZWxlbWVudClcbiAgICAgICAgICBmbGF0X25fdW5pcXVlLmFkZChoYXNfcGFyZW50X2VsZW1lbnQpXG4gICAgICAgIGVsc2VcbiAgICAgICAgICBmbGF0X25fdW5pcXVlLmFkZChub2RlKVxuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgIGlmIChrZXkuaW5jbHVkZXMoJ3RhYicpICYmIGVsZW1lbnRfdG9fcmlnaHQpXG4gICAgICAgICAgZmxhdF9uX3VuaXF1ZS5hZGQoZWxlbWVudF90b19yaWdodClcbiAgICAgICAgZWxzZSBpZiAoa2V5LmluY2x1ZGVzKCdlbnRlcicpICYmIGhhc19jaGlsZF9lbGVtZW50cylcbiAgICAgICAgICBmbGF0X25fdW5pcXVlLmFkZChoYXNfY2hpbGRfZWxlbWVudHMpXG4gICAgICAgIGVsc2VcbiAgICAgICAgICBmbGF0X25fdW5pcXVlLmFkZChub2RlKVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gZmxhdF9uX3VuaXF1ZVxuICAgIH0sIG5ldyBTZXQoKSlcblxuICAgIGlmICh0YXJnZXRzLnNpemUpIHtcbiAgICAgIHVuc2VsZWN0X2FsbCgpXG4gICAgICB0YXJnZXRzLmZvckVhY2gobm9kZSA9PiB7XG4gICAgICAgIHNlbGVjdChub2RlKVxuICAgICAgICBzaG93X3RpcChub2RlKVxuICAgICAgfSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBzaG93X3RpcCA9IGVsID0+IHtcbiAgICBjb25zdCBhY3RpdmVfdG9vbCA9ICQoJ3Zpcy1idWcnKVswXS5hY3RpdmVUb29sXG4gICAgbGV0IHRpcEZhY3RvcnlcblxuICAgIGlmIChhY3RpdmVfdG9vbCA9PT0gJ2FjY2Vzc2liaWxpdHknKSB7XG4gICAgICByZW1vdmVBbGxBY2Nlc3NpYmlsaXR5VGlwcygpXG4gICAgICB0aXBGYWN0b3J5ID0gc2hvd0FjY2Vzc2liaWxpdHlUaXBcbiAgICB9XG4gICAgZWxzZSBpZiAoYWN0aXZlX3Rvb2wgPT09ICdpbnNwZWN0b3InKSB7XG4gICAgICByZW1vdmVBbGxNZXRhVGlwcygpXG4gICAgICB0aXBGYWN0b3J5ID0gc2hvd01ldGFUaXBcbiAgICB9XG5cbiAgICBpZiAoIXRpcEZhY3RvcnkpIHJldHVyblxuXG4gICAgY29uc3Qge3RvcCwgbGVmdH0gPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKVxuICAgIGNvbnN0IHsgcGFnZVlPZmZzZXQsIHBhZ2VYT2Zmc2V0IH0gPSB3aW5kb3dcblxuICAgIHRpcEZhY3RvcnkoZWwsIHtcbiAgICAgIGNsaWVudFk6ICB0b3AsXG4gICAgICBjbGllbnRYOiAgbGVmdCxcbiAgICAgIHBhZ2VZOiAgICBwYWdlWU9mZnNldCArIHRvcCAtIDEwLFxuICAgICAgcGFnZVg6ICAgIHBhZ2VYT2Zmc2V0ICsgbGVmdCArIDIwLFxuICAgIH0pXG4gIH1cblxuICBjb25zdCBvbl9ob3ZlciA9IGUgPT4ge1xuICAgIGNvbnN0ICR0YXJnZXQgPSBkZWVwRWxlbWVudEZyb21Qb2ludChlLmNsaWVudFgsIGUuY2xpZW50WSlcblxuICAgIGlmIChpc09mZkJvdW5kcygkdGFyZ2V0KSB8fCAkdGFyZ2V0Lmhhc0F0dHJpYnV0ZSgnZGF0YS1zZWxlY3RlZCcpKVxuICAgICAgcmV0dXJuIGNsZWFySG92ZXIoKVxuXG4gICAgb3ZlcmxheUhvdmVyVUkoJHRhcmdldClcblxuICAgIGlmIChlLmFsdEtleSAmJiAkKCd2aXMtYnVnJylbMF0uYWN0aXZlVG9vbCA9PT0gJ2d1aWRlcycgJiYgc2VsZWN0ZWQubGVuZ3RoID09PSAxICYmIHNlbGVjdGVkWzBdICE9ICR0YXJnZXQpIHtcbiAgICAgICR0YXJnZXQuc2V0QXR0cmlidXRlKCdkYXRhLW1lYXN1cmluZycsIHRydWUpXG4gICAgICBjb25zdCBbJGFuY2hvcl0gPSBzZWxlY3RlZFxuICAgICAgcmV0dXJuIGNyZWF0ZU1lYXN1cmVtZW50cyh7JGFuY2hvciwgJHRhcmdldH0pXG4gICAgfVxuICAgIGVsc2UgaWYgKCR0YXJnZXQuaGFzQXR0cmlidXRlKCdkYXRhLW1lYXN1cmluZycpKSB7XG4gICAgICAkdGFyZ2V0LnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1tZWFzdXJpbmcnKVxuICAgICAgY2xlYXJNZWFzdXJlbWVudHMoKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHNlbGVjdCA9IGVsID0+IHtcbiAgICBlbC5zZXRBdHRyaWJ1dGUoJ2RhdGEtc2VsZWN0ZWQnLCB0cnVlKVxuICAgIGVsLnNldEF0dHJpYnV0ZSgnZGF0YS1sYWJlbC1pZCcsIGxhYmVscy5sZW5ndGgpXG5cbiAgICBjbGVhckhvdmVyKClcblxuICAgIG92ZXJsYXlNZXRhVUkoZWwpXG4gICAgc2VsZWN0ZWQudW5zaGlmdChlbClcbiAgICB0ZWxsV2F0Y2hlcnMoKVxuICB9XG5cbiAgY29uc3Qgc2VsZWN0aW9uID0gKCkgPT5cbiAgICBzZWxlY3RlZFxuXG4gIGNvbnN0IHVuc2VsZWN0X2FsbCA9ICgpID0+IHtcbiAgICBzZWxlY3RlZFxuICAgICAgLmZvckVhY2goZWwgPT5cbiAgICAgICAgJChlbCkuYXR0cih7XG4gICAgICAgICAgJ2RhdGEtc2VsZWN0ZWQnOiAgICAgIG51bGwsXG4gICAgICAgICAgJ2RhdGEtc2VsZWN0ZWQtaGlkZSc6IG51bGwsXG4gICAgICAgICAgJ2RhdGEtbGFiZWwtaWQnOiAgICAgIG51bGwsXG4gICAgICAgICAgJ2RhdGEtcHNldWRvLXNlbGVjdCc6IG51bGwsXG4gICAgICAgIH0pKVxuXG4gICAgQXJyYXkuZnJvbShbLi4uaGFuZGxlcywgLi4ubGFiZWxzXSkuZm9yRWFjaChlbCA9PlxuICAgICAgZWwucmVtb3ZlKCkpXG5cbiAgICBsYWJlbHMgICAgPSBbXVxuICAgIGhhbmRsZXMgICA9IFtdXG4gICAgc2VsZWN0ZWQgID0gW11cbiAgfVxuXG4gIGNvbnN0IGRlbGV0ZV9hbGwgPSAoKSA9PiB7XG4gICAgY29uc3Qgc2VsZWN0ZWRfYWZ0ZXJfZGVsZXRlID0gc2VsZWN0ZWQubWFwKGVsID0+IHtcbiAgICAgIGlmIChjYW5Nb3ZlUmlnaHQoZWwpKSAgICAgcmV0dXJuIGNhbk1vdmVSaWdodChlbClcbiAgICAgIGVsc2UgaWYgKGNhbk1vdmVMZWZ0KGVsKSkgcmV0dXJuIGNhbk1vdmVMZWZ0KGVsKVxuICAgICAgZWxzZSBpZiAoZWwucGFyZW50Tm9kZSkgICByZXR1cm4gZWwucGFyZW50Tm9kZVxuICAgIH0pXG5cbiAgICBBcnJheS5mcm9tKFsuLi5zZWxlY3RlZCwgLi4ubGFiZWxzLCAuLi5oYW5kbGVzXSkuZm9yRWFjaChlbCA9PlxuICAgICAgZWwucmVtb3ZlKCkpXG5cbiAgICBsYWJlbHMgICAgPSBbXVxuICAgIGhhbmRsZXMgICA9IFtdXG4gICAgc2VsZWN0ZWQgID0gW11cblxuICAgIHNlbGVjdGVkX2FmdGVyX2RlbGV0ZS5mb3JFYWNoKGVsID0+XG4gICAgICBzZWxlY3QoZWwpKVxuICB9XG5cbiAgY29uc3QgZXhwYW5kU2VsZWN0aW9uID0gKHtxdWVyeSwgYWxsID0gZmFsc2V9KSA9PiB7XG4gICAgaWYgKGFsbCkge1xuICAgICAgY29uc3QgdW5zZWxlY3RlZHMgPSAkKHF1ZXJ5ICsgJzpub3QoW2RhdGEtc2VsZWN0ZWRdKScpXG4gICAgICB1bnNlbGVjdGVkcy5mb3JFYWNoKHNlbGVjdClcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICBjb25zdCBwb3RlbnRpYWxzID0gJChxdWVyeSlcbiAgICAgIGlmICghcG90ZW50aWFscykgcmV0dXJuXG5cbiAgICAgIGNvbnN0IFthbmNob3JdID0gc2VsZWN0ZWRcbiAgICAgIGNvbnN0IHJvb3Rfbm9kZV9pbmRleCA9IHBvdGVudGlhbHMucmVkdWNlKChpbmRleCwgbm9kZSwgaSkgPT5cbiAgICAgICAgbm9kZSA9PSBhbmNob3JcbiAgICAgICAgICA/IGluZGV4ID0gaVxuICAgICAgICAgIDogaW5kZXhcbiAgICAgICwgbnVsbClcblxuICAgICAgaWYgKHJvb3Rfbm9kZV9pbmRleCAhPT0gbnVsbCkge1xuICAgICAgICBpZiAoIXBvdGVudGlhbHNbcm9vdF9ub2RlX2luZGV4ICsgMV0pIHtcbiAgICAgICAgICBjb25zdCBwb3RlbnRpYWwgPSBwb3RlbnRpYWxzLmZpbHRlcihlbCA9PiAhZWwuYXR0cignZGF0YS1zZWxlY3RlZCcpKVswXVxuICAgICAgICAgIGlmIChwb3RlbnRpYWwpIHNlbGVjdChwb3RlbnRpYWwpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgc2VsZWN0KHBvdGVudGlhbHNbcm9vdF9ub2RlX2luZGV4ICsgMV0pXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjb25zdCBjb21iaW5lTm9kZU5hbWVBbmRDbGFzcyA9IG5vZGUgPT5cbiAgICBgJHtub2RlLm5vZGVOYW1lLnRvTG93ZXJDYXNlKCl9JHtjcmVhdGVDbGFzc25hbWUobm9kZSl9YFxuXG4gIGNvbnN0IG92ZXJsYXlIb3ZlclVJID0gZWwgPT4ge1xuICAgIGlmIChob3Zlcl9zdGF0ZS50YXJnZXQgPT09IGVsKSByZXR1cm5cblxuICAgIGhvdmVyX3N0YXRlLnRhcmdldCAgPSBlbFxuICAgIGhvdmVyX3N0YXRlLmVsZW1lbnQgPSBjcmVhdGVIb3ZlcihlbClcbiAgICBob3Zlcl9zdGF0ZS5sYWJlbCA9IGNyZWF0ZUhvdmVyTGFiZWwoZWwsIGBcbiAgICAgIDxhIG5vZGU+JHtlbC5ub2RlTmFtZS50b0xvd2VyQ2FzZSgpfTwvYT5cbiAgICAgIDxhPiR7ZWwuaWQgJiYgJyMnICsgZWwuaWR9PC9hPlxuICAgICAgJHtjcmVhdGVDbGFzc25hbWUoZWwpLnNwbGl0KCcuJylcbiAgICAgICAgLmZpbHRlcihuYW1lID0+IG5hbWUgIT0gJycpXG4gICAgICAgIC5yZWR1Y2UoKGxpbmtzLCBuYW1lKSA9PiBgXG4gICAgICAgICAgJHtsaW5rc31cbiAgICAgICAgICA8YT4uJHtuYW1lfTwvYT5cbiAgICAgICAgYCwgJycpXG4gICAgICB9XG4gICAgYClcbiAgfVxuXG4gIGNvbnN0IGNsZWFySG92ZXIgPSAoKSA9PiB7XG4gICAgaWYgKCFob3Zlcl9zdGF0ZS50YXJnZXQpIHJldHVyblxuXG4gICAgaG92ZXJfc3RhdGUuZWxlbWVudCAmJiBob3Zlcl9zdGF0ZS5lbGVtZW50LnJlbW92ZSgpXG4gICAgaG92ZXJfc3RhdGUubGFiZWwgJiYgaG92ZXJfc3RhdGUubGFiZWwucmVtb3ZlKClcblxuICAgIGhvdmVyX3N0YXRlLnRhcmdldCAgPSBudWxsXG4gICAgaG92ZXJfc3RhdGUuZWxlbWVudCA9IG51bGxcbiAgICBob3Zlcl9zdGF0ZS5sYWJlbCAgID0gbnVsbFxuICB9XG5cbiAgY29uc3Qgb3ZlcmxheU1ldGFVSSA9IGVsID0+IHtcbiAgICBsZXQgaGFuZGxlID0gY3JlYXRlSGFuZGxlKGVsKVxuICAgIGxldCBsYWJlbCAgPSBjcmVhdGVMYWJlbChlbCwgYFxuICAgICAgPGEgbm9kZT4ke2VsLm5vZGVOYW1lLnRvTG93ZXJDYXNlKCl9PC9hPlxuICAgICAgPGE+JHtlbC5pZCAmJiAnIycgKyBlbC5pZH08L2E+XG4gICAgICAke2NyZWF0ZUNsYXNzbmFtZShlbCkuc3BsaXQoJy4nKVxuICAgICAgICAuZmlsdGVyKG5hbWUgPT4gbmFtZSAhPSAnJylcbiAgICAgICAgLnJlZHVjZSgobGlua3MsIG5hbWUpID0+IGBcbiAgICAgICAgICAke2xpbmtzfVxuICAgICAgICAgIDxhPi4ke25hbWV9PC9hPlxuICAgICAgICBgLCAnJylcbiAgICAgIH1cbiAgICBgKVxuXG4gICAgbGV0IG9ic2VydmVyICAgICAgICA9IGNyZWF0ZU9ic2VydmVyKGVsLCB7aGFuZGxlLGxhYmVsfSlcbiAgICBsZXQgcGFyZW50T2JzZXJ2ZXIgID0gY3JlYXRlT2JzZXJ2ZXIoZWwsIHtoYW5kbGUsbGFiZWx9KVxuXG4gICAgb2JzZXJ2ZXIub2JzZXJ2ZShlbCwgeyBhdHRyaWJ1dGVzOiB0cnVlIH0pXG4gICAgcGFyZW50T2JzZXJ2ZXIub2JzZXJ2ZShlbC5wYXJlbnROb2RlLCB7IGNoaWxkTGlzdDp0cnVlLCBzdWJ0cmVlOnRydWUgfSlcblxuICAgICQobGFiZWwpLm9uKCdET01Ob2RlUmVtb3ZlZCcsIF8gPT4ge1xuICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpXG4gICAgICBwYXJlbnRPYnNlcnZlci5kaXNjb25uZWN0KClcbiAgICB9KVxuICB9XG5cbiAgY29uc3Qgc2V0TGFiZWwgPSAoZWwsIGxhYmVsKSA9PlxuICAgIGxhYmVsLnVwZGF0ZSA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpXG5cbiAgY29uc3QgY3JlYXRlTGFiZWwgPSAoZWwsIHRleHQpID0+IHtcbiAgICBjb25zdCBpZCA9IHBhcnNlSW50KGVsLmdldEF0dHJpYnV0ZSgnZGF0YS1sYWJlbC1pZCcpKVxuXG4gICAgaWYgKCFsYWJlbHNbaWRdKSB7XG4gICAgICBjb25zdCBsYWJlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3Zpc2J1Zy1sYWJlbCcpXG5cbiAgICAgIGxhYmVsLnRleHQgPSB0ZXh0XG4gICAgICBsYWJlbC5wb3NpdGlvbiA9IHtcbiAgICAgICAgYm91bmRpbmdSZWN0OiAgIGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgICBub2RlX2xhYmVsX2lkOiAgaWQsXG4gICAgICB9XG5cbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGFiZWwpXG5cbiAgICAgICQobGFiZWwpLm9uKCdxdWVyeScsICh7ZGV0YWlsfSkgPT4ge1xuICAgICAgICBpZiAoIWRldGFpbC50ZXh0KSByZXR1cm5cbiAgICAgICAgdGhpcy5xdWVyeV90ZXh0ID0gZGV0YWlsLnRleHRcblxuICAgICAgICBxdWVyeVBhZ2UoJ1tkYXRhLXBzZXVkby1zZWxlY3RdJywgZWwgPT5cbiAgICAgICAgICBlbC5yZW1vdmVBdHRyaWJ1dGUoJ2RhdGEtcHNldWRvLXNlbGVjdCcpKVxuXG4gICAgICAgIHF1ZXJ5UGFnZSh0aGlzLnF1ZXJ5X3RleHQgKyAnOm5vdChbZGF0YS1zZWxlY3RlZF0pJywgZWwgPT5cbiAgICAgICAgICBkZXRhaWwuYWN0aXZhdG9yID09PSAnbW91c2VlbnRlcidcbiAgICAgICAgICAgID8gZWwuc2V0QXR0cmlidXRlKCdkYXRhLXBzZXVkby1zZWxlY3QnLCB0cnVlKVxuICAgICAgICAgICAgOiBzZWxlY3QoZWwpKVxuICAgICAgfSlcblxuICAgICAgJChsYWJlbCkub24oJ21vdXNlbGVhdmUnLCBlID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgICAgICAgcXVlcnlQYWdlKCdbZGF0YS1wc2V1ZG8tc2VsZWN0XScsIGVsID0+XG4gICAgICAgICAgZWwucmVtb3ZlQXR0cmlidXRlKCdkYXRhLXBzZXVkby1zZWxlY3QnKSlcbiAgICAgIH0pXG5cbiAgICAgIGxhYmVsc1tsYWJlbHMubGVuZ3RoXSA9IGxhYmVsXG5cbiAgICAgIHJldHVybiBsYWJlbFxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGNyZWF0ZUhhbmRsZSA9IGVsID0+IHtcbiAgICBjb25zdCBpZCA9IHBhcnNlSW50KGVsLmdldEF0dHJpYnV0ZSgnZGF0YS1sYWJlbC1pZCcpKVxuXG4gICAgaWYgKCFoYW5kbGVzW2lkXSkge1xuICAgICAgY29uc3QgaGFuZGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndmlzYnVnLWhhbmRsZXMnKVxuXG4gICAgICBoYW5kbGUucG9zaXRpb24gPSB7XG4gICAgICAgIGJvdW5kaW5nUmVjdDogICBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSxcbiAgICAgICAgbm9kZV9sYWJlbF9pZDogIGlkLFxuICAgICAgfVxuXG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGhhbmRsZSlcblxuICAgICAgaGFuZGxlc1toYW5kbGVzLmxlbmd0aF0gPSBoYW5kbGVcbiAgICAgIHJldHVybiBoYW5kbGVcbiAgICB9XG4gIH1cblxuICBjb25zdCBjcmVhdGVIb3ZlciA9IGVsID0+IHtcbiAgICBpZiAoIWVsLmhhc0F0dHJpYnV0ZSgnZGF0YS1wc2V1ZG8tc2VsZWN0JykgJiYgIWVsLmhhc0F0dHJpYnV0ZSgnZGF0YS1sYWJlbC1pZCcpKSB7XG4gICAgICBpZiAoaG92ZXJfc3RhdGUuZWxlbWVudClcbiAgICAgICAgaG92ZXJfc3RhdGUuZWxlbWVudC5yZW1vdmUoKVxuXG4gICAgICBob3Zlcl9zdGF0ZS5lbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndmlzYnVnLWhvdmVyJylcblxuICAgICAgaG92ZXJfc3RhdGUuZWxlbWVudC5wb3NpdGlvbiA9IHtcbiAgICAgICAgYm91bmRpbmdSZWN0OiBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSxcbiAgICAgIH1cblxuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChob3Zlcl9zdGF0ZS5lbGVtZW50KVxuXG4gICAgICByZXR1cm4gaG92ZXJfc3RhdGUuZWxlbWVudFxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGNyZWF0ZUhvdmVyTGFiZWwgPSAoZWwsIHRleHQpID0+IHtcbiAgICBpZiAoIWVsLmhhc0F0dHJpYnV0ZSgnZGF0YS1wc2V1ZG8tc2VsZWN0JykgJiYgIWVsLmhhc0F0dHJpYnV0ZSgnZGF0YS1sYWJlbC1pZCcpKSB7XG4gICAgICBpZiAoaG92ZXJfc3RhdGUubGFiZWwpXG4gICAgICAgIGhvdmVyX3N0YXRlLmxhYmVsLnJlbW92ZSgpXG5cbiAgICAgIGhvdmVyX3N0YXRlLmxhYmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndmlzYnVnLWxhYmVsJylcblxuICAgICAgaG92ZXJfc3RhdGUubGFiZWwudGV4dCA9IHRleHRcbiAgICAgIGhvdmVyX3N0YXRlLmxhYmVsLnBvc2l0aW9uID0ge1xuICAgICAgICBib3VuZGluZ1JlY3Q6ICAgZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksXG4gICAgICAgIG5vZGVfbGFiZWxfaWQ6ICAnaG92ZXInLFxuICAgICAgfVxuXG4gICAgICBob3Zlcl9zdGF0ZS5sYWJlbC5zdHlsZSA9IGAtLWxhYmVsLWJnOiBoc2woMjY3LCAxMDAlLCA1OCUpYFxuXG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGhvdmVyX3N0YXRlLmxhYmVsKVxuXG4gICAgICByZXR1cm4gaG92ZXJfc3RhdGUubGFiZWxcbiAgICB9XG4gIH1cblxuICBjb25zdCBzZXRIYW5kbGUgPSAobm9kZSwgaGFuZGxlKSA9PiB7XG4gICAgaGFuZGxlLnBvc2l0aW9uID0ge1xuICAgICAgYm91bmRpbmdSZWN0OiAgIG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksXG4gICAgICBub2RlX2xhYmVsX2lkOiAgbm9kZS5nZXRBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnKSxcbiAgICB9XG4gIH1cblxuICBjb25zdCBjcmVhdGVPYnNlcnZlciA9IChub2RlLCB7bGFiZWwsaGFuZGxlfSkgPT5cbiAgICBuZXcgTXV0YXRpb25PYnNlcnZlcihsaXN0ID0+IHtcbiAgICAgIHNldExhYmVsKG5vZGUsIGxhYmVsKVxuICAgICAgc2V0SGFuZGxlKG5vZGUsIGhhbmRsZSlcbiAgICB9KVxuXG4gIGNvbnN0IG9uU2VsZWN0ZWRVcGRhdGUgPSAoY2IsIGltbWVkaWF0ZUNhbGxiYWNrID0gdHJ1ZSkgPT4ge1xuICAgIHNlbGVjdGVkQ2FsbGJhY2tzLnB1c2goY2IpXG4gICAgaWYgKGltbWVkaWF0ZUNhbGxiYWNrKSBjYihzZWxlY3RlZClcbiAgfVxuXG4gIGNvbnN0IHJlbW92ZVNlbGVjdGVkQ2FsbGJhY2sgPSBjYiA9PlxuICAgIHNlbGVjdGVkQ2FsbGJhY2tzID0gc2VsZWN0ZWRDYWxsYmFja3MuZmlsdGVyKGNhbGxiYWNrID0+IGNhbGxiYWNrICE9IGNiKVxuXG4gIGNvbnN0IHRlbGxXYXRjaGVycyA9ICgpID0+XG4gICAgc2VsZWN0ZWRDYWxsYmFja3MuZm9yRWFjaChjYiA9PiBjYihzZWxlY3RlZCkpXG5cbiAgY29uc3QgZGlzY29ubmVjdCA9ICgpID0+IHtcbiAgICB1bnNlbGVjdF9hbGwoKVxuICAgIHVubGlzdGVuKClcbiAgfVxuXG4gIGNvbnN0IG9uX3NlbGVjdF9jaGlsZHJlbiA9IChlLCB7a2V5fSkgPT4ge1xuICAgIGNvbnN0IHRhcmdldHMgPSBzZWxlY3RlZFxuICAgICAgLmZpbHRlcihub2RlID0+IG5vZGUuY2hpbGRyZW4ubGVuZ3RoKVxuICAgICAgLnJlZHVjZSgoZmxhdCwge2NoaWxkcmVufSkgPT5cbiAgICAgICAgWy4uLmZsYXQsIC4uLkFycmF5LmZyb20oY2hpbGRyZW4pXSwgW10pXG5cbiAgICBpZiAodGFyZ2V0cy5sZW5ndGgpIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKVxuXG4gICAgICB1bnNlbGVjdF9hbGwoKVxuICAgICAgdGFyZ2V0cy5mb3JFYWNoKG5vZGUgPT4gc2VsZWN0KG5vZGUpKVxuICAgIH1cbiAgfVxuXG4gIHdhdGNoSW1hZ2VzRm9yVXBsb2FkKClcbiAgbGlzdGVuKClcblxuICByZXR1cm4ge1xuICAgIHNlbGVjdCxcbiAgICBzZWxlY3Rpb24sXG4gICAgdW5zZWxlY3RfYWxsLFxuICAgIG9uU2VsZWN0ZWRVcGRhdGUsXG4gICAgcmVtb3ZlU2VsZWN0ZWRDYWxsYmFjayxcbiAgICBkaXNjb25uZWN0LFxuICB9XG59XG4iLCJpbXBvcnQgaG90a2V5cyBmcm9tICdob3RrZXlzLWpzJ1xuaW1wb3J0IHsgbWV0YUtleSwgZ2V0U3R5bGUsIGdldFNpZGUsIHNob3dIaWRlU2VsZWN0ZWQgfSBmcm9tICcuLi91dGlsaXRpZXMvJ1xuXG4vLyB0b2RvOiBzaG93IHBhZGRpbmcgY29sb3JcbmNvbnN0IGtleV9ldmVudHMgPSAndXAsZG93bixsZWZ0LHJpZ2h0J1xuICAuc3BsaXQoJywnKVxuICAucmVkdWNlKChldmVudHMsIGV2ZW50KSA9PlxuICAgIGAke2V2ZW50c30sJHtldmVudH0sYWx0KyR7ZXZlbnR9LHNoaWZ0KyR7ZXZlbnR9LHNoaWZ0K2FsdCske2V2ZW50fWBcbiAgLCAnJylcbiAgLnN1YnN0cmluZygxKVxuXG5jb25zdCBjb21tYW5kX2V2ZW50cyA9IGAke21ldGFLZXl9K3VwLCR7bWV0YUtleX0rc2hpZnQrdXAsJHttZXRhS2V5fStkb3duLCR7bWV0YUtleX0rc2hpZnQrZG93bmBcblxuZXhwb3J0IGZ1bmN0aW9uIFBhZGRpbmcoe3NlbGVjdGlvbn0pIHtcbiAgaG90a2V5cyhrZXlfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGlmIChlLmNhbmNlbEJ1YmJsZSkgcmV0dXJuXG5cbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBwYWRFbGVtZW50KHNlbGVjdGlvbigpLCBoYW5kbGVyLmtleSlcbiAgfSlcblxuICBob3RrZXlzKGNvbW1hbmRfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHBhZEFsbEVsZW1lbnRTaWRlcyhzZWxlY3Rpb24oKSwgaGFuZGxlci5rZXkpXG4gIH0pXG5cbiAgcmV0dXJuICgpID0+IHtcbiAgICBob3RrZXlzLnVuYmluZChrZXlfZXZlbnRzKVxuICAgIGhvdGtleXMudW5iaW5kKGNvbW1hbmRfZXZlbnRzKVxuICAgIGhvdGtleXMudW5iaW5kKCd1cCxkb3duLGxlZnQscmlnaHQnKSAvLyBidWcgaW4gbGliP1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYWRFbGVtZW50KGVscywgZGlyZWN0aW9uKSB7XG4gIGVsc1xuICAgIC5tYXAoZWwgPT4gc2hvd0hpZGVTZWxlY3RlZChlbCkpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgZWwsXG4gICAgICBzdHlsZTogICAgJ3BhZGRpbmcnICsgZ2V0U2lkZShkaXJlY3Rpb24pLFxuICAgICAgY3VycmVudDogIHBhcnNlSW50KGdldFN0eWxlKGVsLCAncGFkZGluZycgKyBnZXRTaWRlKGRpcmVjdGlvbikpLCAxMCksXG4gICAgICBhbW91bnQ6ICAgZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ3NoaWZ0JykgPyAxMCA6IDEsXG4gICAgICBuZWdhdGl2ZTogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ2FsdCcpLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIHBhZGRpbmc6IHBheWxvYWQubmVnYXRpdmVcbiAgICAgICAgICA/IHBheWxvYWQuY3VycmVudCAtIHBheWxvYWQuYW1vdW50XG4gICAgICAgICAgOiBwYXlsb2FkLmN1cnJlbnQgKyBwYXlsb2FkLmFtb3VudFxuICAgICAgfSkpXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIHBhZGRpbmd9KSA9PlxuICAgICAgZWwuc3R5bGVbc3R5bGVdID0gYCR7cGFkZGluZyA8IDAgPyAwIDogcGFkZGluZ31weGApXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYWRBbGxFbGVtZW50U2lkZXMoZWxzLCBrZXljb21tYW5kKSB7XG4gIGNvbnN0IGNvbWJvID0ga2V5Y29tbWFuZC5zcGxpdCgnKycpXG4gIGxldCBzcG9vZiA9ICcnXG5cbiAgaWYgKGNvbWJvLmluY2x1ZGVzKCdzaGlmdCcpKSAgc3Bvb2YgPSAnc2hpZnQrJyArIHNwb29mXG4gIGlmIChjb21iby5pbmNsdWRlcygnZG93bicpKSAgIHNwb29mID0gJ2FsdCsnICsgc3Bvb2ZcblxuICAndXAsZG93bixsZWZ0LHJpZ2h0Jy5zcGxpdCgnLCcpXG4gICAgLmZvckVhY2goc2lkZSA9PiBwYWRFbGVtZW50KGVscywgc3Bvb2YgKyBzaWRlKSlcbn1cbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgeyBzaG93SGlkZU5vZGVMYWJlbCB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmNvbnN0IHJlbW92ZUVkaXRhYmlsaXR5ID0gKHt0YXJnZXR9KSA9PiB7XG4gIHRhcmdldC5yZW1vdmVBdHRyaWJ1dGUoJ2NvbnRlbnRlZGl0YWJsZScpXG4gIHRhcmdldC5yZW1vdmVBdHRyaWJ1dGUoJ3NwZWxsY2hlY2snKVxuICB0YXJnZXQucmVtb3ZlRXZlbnRMaXN0ZW5lcignYmx1cicsIHJlbW92ZUVkaXRhYmlsaXR5KVxuICB0YXJnZXQucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIHN0b3BCdWJibGluZylcbiAgaG90a2V5cy51bmJpbmQoJ2VzY2FwZSxlc2MnKVxufVxuXG5jb25zdCBzdG9wQnViYmxpbmcgPSBlID0+IGUua2V5ICE9ICdFc2NhcGUnICYmIGUuc3RvcFByb3BhZ2F0aW9uKClcblxuY29uc3QgY2xlYW51cCA9IChlLCBoYW5kbGVyKSA9PiB7XG4gICQoJ1tzcGVsbGNoZWNrPVwidHJ1ZVwiXScpLmZvckVhY2godGFyZ2V0ID0+IHJlbW92ZUVkaXRhYmlsaXR5KHt0YXJnZXR9KSlcbiAgd2luZG93LmdldFNlbGVjdGlvbigpLmVtcHR5KClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEVkaXRUZXh0KGVsZW1lbnRzKSB7XG4gIGlmICghZWxlbWVudHMubGVuZ3RoKSByZXR1cm5cblxuICBlbGVtZW50cy5tYXAoZWwgPT4ge1xuICAgIGxldCAkZWwgPSAkKGVsKVxuXG4gICAgJGVsLmF0dHIoe1xuICAgICAgY29udGVudGVkaXRhYmxlOiB0cnVlLFxuICAgICAgc3BlbGxjaGVjazogdHJ1ZSxcbiAgICB9KVxuICAgIGVsLmZvY3VzKClcbiAgICBzaG93SGlkZU5vZGVMYWJlbChlbCwgdHJ1ZSlcblxuICAgICRlbC5vbigna2V5ZG93bicsIHN0b3BCdWJibGluZylcbiAgICAkZWwub24oJ2JsdXInLCByZW1vdmVFZGl0YWJpbGl0eSlcbiAgfSlcblxuICBob3RrZXlzKCdlc2NhcGUsZXNjJywgY2xlYW51cClcbn0iLCJpbXBvcnQgaG90a2V5cyBmcm9tICdob3RrZXlzLWpzJ1xuaW1wb3J0IHsgbWV0YUtleSwgZ2V0U3R5bGUsIHNob3dIaWRlU2VsZWN0ZWQgfSBmcm9tICcuLi91dGlsaXRpZXMvJ1xuXG5jb25zdCBrZXlfZXZlbnRzID0gJ3VwLGRvd24sbGVmdCxyaWdodCdcbiAgLnNwbGl0KCcsJylcbiAgLnJlZHVjZSgoZXZlbnRzLCBldmVudCkgPT5cbiAgICBgJHtldmVudHN9LCR7ZXZlbnR9LHNoaWZ0KyR7ZXZlbnR9YFxuICAsICcnKVxuICAuc3Vic3RyaW5nKDEpXG5cbmNvbnN0IGNvbW1hbmRfZXZlbnRzID0gYCR7bWV0YUtleX0rdXAsJHttZXRhS2V5fStkb3duYFxuXG5leHBvcnQgZnVuY3Rpb24gRm9udCh7c2VsZWN0aW9ufSkge1xuICBob3RrZXlzKGtleV9ldmVudHMsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgaWYgKGUuY2FuY2VsQnViYmxlKSByZXR1cm5cblxuICAgIGUucHJldmVudERlZmF1bHQoKVxuXG4gICAgbGV0IHNlbGVjdGVkTm9kZXMgPSBzZWxlY3Rpb24oKVxuICAgICAgLCBrZXlzID0gaGFuZGxlci5rZXkuc3BsaXQoJysnKVxuXG4gICAgaWYgKGtleXMuaW5jbHVkZXMoJ2xlZnQnKSB8fCBrZXlzLmluY2x1ZGVzKCdyaWdodCcpKVxuICAgICAga2V5cy5pbmNsdWRlcygnc2hpZnQnKVxuICAgICAgICA/IGNoYW5nZUtlcm5pbmcoc2VsZWN0ZWROb2RlcywgaGFuZGxlci5rZXkpXG4gICAgICAgIDogY2hhbmdlQWxpZ25tZW50KHNlbGVjdGVkTm9kZXMsIGhhbmRsZXIua2V5KVxuICAgIGVsc2VcbiAgICAgIGtleXMuaW5jbHVkZXMoJ3NoaWZ0JylcbiAgICAgICAgPyBjaGFuZ2VMZWFkaW5nKHNlbGVjdGVkTm9kZXMsIGhhbmRsZXIua2V5KVxuICAgICAgICA6IGNoYW5nZUZvbnRTaXplKHNlbGVjdGVkTm9kZXMsIGhhbmRsZXIua2V5KVxuICB9KVxuXG4gIGhvdGtleXMoY29tbWFuZF9ldmVudHMsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgbGV0IGtleXMgPSBoYW5kbGVyLmtleS5zcGxpdCgnKycpXG4gICAgY2hhbmdlRm9udFdlaWdodChzZWxlY3Rpb24oKSwga2V5cy5pbmNsdWRlcygndXAnKSA/ICd1cCcgOiAnZG93bicpXG4gIH0pXG5cbiAgaG90a2V5cygnY21kK2InLCBlID0+IHtcbiAgICBzZWxlY3Rpb24oKS5mb3JFYWNoKGVsID0+XG4gICAgICBlbC5zdHlsZS5mb250V2VpZ2h0ID1cbiAgICAgICAgZWwuc3R5bGUuZm9udFdlaWdodCA9PSAnYm9sZCdcbiAgICAgICAgICA/IG51bGxcbiAgICAgICAgICA6ICdib2xkJylcbiAgfSlcblxuICBob3RrZXlzKCdjbWQraScsIGUgPT4ge1xuICAgIHNlbGVjdGlvbigpLmZvckVhY2goZWwgPT5cbiAgICAgIGVsLnN0eWxlLmZvbnRTdHlsZSA9XG4gICAgICAgIGVsLnN0eWxlLmZvbnRTdHlsZSA9PSAnaXRhbGljJ1xuICAgICAgICAgID8gbnVsbFxuICAgICAgICAgIDogJ2l0YWxpYycpXG4gIH0pXG5cbiAgcmV0dXJuICgpID0+IHtcbiAgICBob3RrZXlzLnVuYmluZChrZXlfZXZlbnRzKVxuICAgIGhvdGtleXMudW5iaW5kKGNvbW1hbmRfZXZlbnRzKVxuICAgIGhvdGtleXMudW5iaW5kKCdjbWQrYixjbWQraScpXG4gICAgaG90a2V5cy51bmJpbmQoJ3VwLGRvd24sbGVmdCxyaWdodCcpXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZUxlYWRpbmcoZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbCA9PiBzaG93SGlkZVNlbGVjdGVkKGVsKSlcbiAgICAubWFwKGVsID0+ICh7XG4gICAgICBlbCxcbiAgICAgIHN0eWxlOiAgICAnbGluZUhlaWdodCcsXG4gICAgICBjdXJyZW50OiAgcGFyc2VJbnQoZ2V0U3R5bGUoZWwsICdsaW5lSGVpZ2h0JykpLFxuICAgICAgYW1vdW50OiAgIDEsXG4gICAgICBuZWdhdGl2ZTogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ2Rvd24nKSxcbiAgICB9KSlcbiAgICAubWFwKHBheWxvYWQgPT5cbiAgICAgIE9iamVjdC5hc3NpZ24ocGF5bG9hZCwge1xuICAgICAgICBjdXJyZW50OiBwYXlsb2FkLmN1cnJlbnQgPT0gJ25vcm1hbCcgfHwgaXNOYU4ocGF5bG9hZC5jdXJyZW50KVxuICAgICAgICAgID8gMS4xNCAqIHBhcnNlSW50KGdldFN0eWxlKHBheWxvYWQuZWwsICdmb250U2l6ZScpKSAvLyBkb2N1bWVudCB0aGlzIGNob2ljZVxuICAgICAgICAgIDogcGF5bG9hZC5jdXJyZW50XG4gICAgICB9KSlcbiAgICAubWFwKHBheWxvYWQgPT5cbiAgICAgIE9iamVjdC5hc3NpZ24ocGF5bG9hZCwge1xuICAgICAgICB2YWx1ZTogcGF5bG9hZC5uZWdhdGl2ZVxuICAgICAgICAgID8gcGF5bG9hZC5jdXJyZW50IC0gcGF5bG9hZC5hbW91bnRcbiAgICAgICAgICA6IHBheWxvYWQuY3VycmVudCArIHBheWxvYWQuYW1vdW50XG4gICAgICB9KSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgdmFsdWV9KSA9PlxuICAgICAgZWwuc3R5bGVbc3R5bGVdID0gYCR7dmFsdWV9cHhgKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY2hhbmdlS2VybmluZyhlbHMsIGRpcmVjdGlvbikge1xuICBlbHNcbiAgICAubWFwKGVsID0+IHNob3dIaWRlU2VsZWN0ZWQoZWwpKVxuICAgIC5tYXAoZWwgPT4gKHtcbiAgICAgIGVsLFxuICAgICAgc3R5bGU6ICAgICdsZXR0ZXJTcGFjaW5nJyxcbiAgICAgIGN1cnJlbnQ6ICBwYXJzZUZsb2F0KGdldFN0eWxlKGVsLCAnbGV0dGVyU3BhY2luZycpKSxcbiAgICAgIGFtb3VudDogICAuMSxcbiAgICAgIG5lZ2F0aXZlOiBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygnbGVmdCcpLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIGN1cnJlbnQ6IHBheWxvYWQuY3VycmVudCA9PSAnbm9ybWFsJyB8fCBpc05hTihwYXlsb2FkLmN1cnJlbnQpXG4gICAgICAgICAgPyAwXG4gICAgICAgICAgOiBwYXlsb2FkLmN1cnJlbnRcbiAgICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIHZhbHVlOiBwYXlsb2FkLm5lZ2F0aXZlXG4gICAgICAgICAgPyAocGF5bG9hZC5jdXJyZW50IC0gcGF5bG9hZC5hbW91bnQpLnRvRml4ZWQoMilcbiAgICAgICAgICA6IChwYXlsb2FkLmN1cnJlbnQgKyBwYXlsb2FkLmFtb3VudCkudG9GaXhlZCgyKVxuICAgICAgfSkpXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIHZhbHVlfSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IGAke3ZhbHVlIDw9IC0yID8gLTIgOiB2YWx1ZX1weGApXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjaGFuZ2VGb250U2l6ZShlbHMsIGRpcmVjdGlvbikge1xuICBlbHNcbiAgICAubWFwKGVsID0+IHNob3dIaWRlU2VsZWN0ZWQoZWwpKVxuICAgIC5tYXAoZWwgPT4gKHtcbiAgICAgIGVsLFxuICAgICAgc3R5bGU6ICAgICdmb250U2l6ZScsXG4gICAgICBjdXJyZW50OiAgcGFyc2VJbnQoZ2V0U3R5bGUoZWwsICdmb250U2l6ZScpKSxcbiAgICAgIGFtb3VudDogICBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygnc2hpZnQnKSA/IDEwIDogMSxcbiAgICAgIG5lZ2F0aXZlOiBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygnZG93bicpLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIGZvbnRfc2l6ZTogcGF5bG9hZC5uZWdhdGl2ZVxuICAgICAgICAgID8gcGF5bG9hZC5jdXJyZW50IC0gcGF5bG9hZC5hbW91bnRcbiAgICAgICAgICA6IHBheWxvYWQuY3VycmVudCArIHBheWxvYWQuYW1vdW50XG4gICAgICB9KSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgZm9udF9zaXplfSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IGAke2ZvbnRfc2l6ZSA8PSA2ID8gNiA6IGZvbnRfc2l6ZX1weGApXG59XG5cbmNvbnN0IHdlaWdodE1hcCA9IHtcbiAgbm9ybWFsOiAyLFxuICBib2xkOiAgIDUsXG4gIGxpZ2h0OiAgMCxcbiAgXCJcIjogMixcbiAgXCIxMDBcIjowLFwiMjAwXCI6MSxcIjMwMFwiOjIsXCI0MDBcIjozLFwiNTAwXCI6NCxcIjYwMFwiOjUsXCI3MDBcIjo2LFwiODAwXCI6NyxcIjkwMFwiOjhcbn1cbmNvbnN0IHdlaWdodE9wdGlvbnMgPSBbMTAwLDIwMCwzMDAsNDAwLDUwMCw2MDAsNzAwLDgwMCw5MDBdXG5cbmV4cG9ydCBmdW5jdGlvbiBjaGFuZ2VGb250V2VpZ2h0KGVscywgZGlyZWN0aW9uKSB7XG4gIGVsc1xuICAgIC5tYXAoZWwgPT4gc2hvd0hpZGVTZWxlY3RlZChlbCkpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgZWwsXG4gICAgICBzdHlsZTogICAgJ2ZvbnRXZWlnaHQnLFxuICAgICAgY3VycmVudDogIGdldFN0eWxlKGVsLCAnZm9udFdlaWdodCcpLFxuICAgICAgZGlyZWN0aW9uOiBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygnZG93bicpLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIHZhbHVlOiBwYXlsb2FkLmRpcmVjdGlvblxuICAgICAgICAgID8gd2VpZ2h0TWFwW3BheWxvYWQuY3VycmVudF0gLSAxXG4gICAgICAgICAgOiB3ZWlnaHRNYXBbcGF5bG9hZC5jdXJyZW50XSArIDFcbiAgICAgIH0pKVxuICAgIC5mb3JFYWNoKCh7ZWwsIHN0eWxlLCB2YWx1ZX0pID0+XG4gICAgICBlbC5zdHlsZVtzdHlsZV0gPSB3ZWlnaHRPcHRpb25zW3ZhbHVlIDwgMCA/IDAgOiB2YWx1ZSA+PSB3ZWlnaHRPcHRpb25zLmxlbmd0aFxuICAgICAgICA/IHdlaWdodE9wdGlvbnMubGVuZ3RoXG4gICAgICAgIDogdmFsdWVcbiAgICAgIF0pXG59XG5cbmNvbnN0IGFsaWduTWFwID0ge1xuICBzdGFydDogMCxcbiAgbGVmdDogMCxcbiAgY2VudGVyOiAxLFxuICByaWdodDogMixcbn1cbmNvbnN0IGFsaWduT3B0aW9ucyA9IFsnbGVmdCcsJ2NlbnRlcicsJ3JpZ2h0J11cblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZUFsaWdubWVudChlbHMsIGRpcmVjdGlvbikge1xuICBlbHNcbiAgICAubWFwKGVsID0+IHNob3dIaWRlU2VsZWN0ZWQoZWwpKVxuICAgIC5tYXAoZWwgPT4gKHtcbiAgICAgIGVsLFxuICAgICAgc3R5bGU6ICAgICd0ZXh0QWxpZ24nLFxuICAgICAgY3VycmVudDogIGdldFN0eWxlKGVsLCAndGV4dEFsaWduJyksXG4gICAgICBkaXJlY3Rpb246IGRpcmVjdGlvbi5zcGxpdCgnKycpLmluY2x1ZGVzKCdsZWZ0JyksXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgdmFsdWU6IHBheWxvYWQuZGlyZWN0aW9uXG4gICAgICAgICAgPyBhbGlnbk1hcFtwYXlsb2FkLmN1cnJlbnRdIC0gMVxuICAgICAgICAgIDogYWxpZ25NYXBbcGF5bG9hZC5jdXJyZW50XSArIDFcbiAgICAgIH0pKVxuICAgIC5mb3JFYWNoKCh7ZWwsIHN0eWxlLCB2YWx1ZX0pID0+XG4gICAgICBlbC5zdHlsZVtzdHlsZV0gPSBhbGlnbk9wdGlvbnNbdmFsdWUgPCAwID8gMCA6IHZhbHVlID49IDIgPyAyOiB2YWx1ZV0pXG59XG4iLCJpbXBvcnQgaG90a2V5cyBmcm9tICdob3RrZXlzLWpzJ1xuaW1wb3J0IHsgbWV0YUtleSwgZ2V0U3R5bGUgfSBmcm9tICcuLi91dGlsaXRpZXMvJ1xuXG5jb25zdCBrZXlfZXZlbnRzID0gJ3VwLGRvd24sbGVmdCxyaWdodCdcbiAgLnNwbGl0KCcsJylcbiAgLnJlZHVjZSgoZXZlbnRzLCBldmVudCkgPT5cbiAgICBgJHtldmVudHN9LCR7ZXZlbnR9LHNoaWZ0KyR7ZXZlbnR9YFxuICAsICcnKVxuICAuc3Vic3RyaW5nKDEpXG5cbmNvbnN0IGNvbW1hbmRfZXZlbnRzID0gYCR7bWV0YUtleX0rdXAsJHttZXRhS2V5fStkb3duLCR7bWV0YUtleX0rbGVmdCwke21ldGFLZXl9K3JpZ2h0YFxuXG5leHBvcnQgZnVuY3Rpb24gRmxleCh7c2VsZWN0aW9ufSkge1xuICBob3RrZXlzKGtleV9ldmVudHMsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgaWYgKGUuY2FuY2VsQnViYmxlKSByZXR1cm5cblxuICAgIGUucHJldmVudERlZmF1bHQoKVxuXG4gICAgbGV0IHNlbGVjdGVkTm9kZXMgPSBzZWxlY3Rpb24oKVxuICAgICAgLCBrZXlzID0gaGFuZGxlci5rZXkuc3BsaXQoJysnKVxuXG4gICAgaWYgKGtleXMuaW5jbHVkZXMoJ2xlZnQnKSB8fCBrZXlzLmluY2x1ZGVzKCdyaWdodCcpKVxuICAgICAga2V5cy5pbmNsdWRlcygnc2hpZnQnKVxuICAgICAgICA/IGNoYW5nZUhEaXN0cmlidXRpb24oc2VsZWN0ZWROb2RlcywgaGFuZGxlci5rZXkpXG4gICAgICAgIDogY2hhbmdlSEFsaWdubWVudChzZWxlY3RlZE5vZGVzLCBoYW5kbGVyLmtleSlcbiAgICBlbHNlXG4gICAgICBrZXlzLmluY2x1ZGVzKCdzaGlmdCcpXG4gICAgICAgID8gY2hhbmdlVkRpc3RyaWJ1dGlvbihzZWxlY3RlZE5vZGVzLCBoYW5kbGVyLmtleSlcbiAgICAgICAgOiBjaGFuZ2VWQWxpZ25tZW50KHNlbGVjdGVkTm9kZXMsIGhhbmRsZXIua2V5KVxuICB9KVxuXG4gIGhvdGtleXMoY29tbWFuZF9ldmVudHMsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICBsZXQgc2VsZWN0ZWROb2RlcyA9IHNlbGVjdGlvbigpXG4gICAgICAsIGtleXMgPSBoYW5kbGVyLmtleS5zcGxpdCgnKycpXG5cbiAgICBjaGFuZ2VEaXJlY3Rpb24oc2VsZWN0ZWROb2Rlcywga2V5cy5pbmNsdWRlcygnbGVmdCcpID8gJ3JvdycgOiAnY29sdW1uJylcbiAgfSlcblxuICByZXR1cm4gKCkgPT4ge1xuICAgIGhvdGtleXMudW5iaW5kKGtleV9ldmVudHMpXG4gICAgaG90a2V5cy51bmJpbmQoY29tbWFuZF9ldmVudHMpXG4gICAgaG90a2V5cy51bmJpbmQoJ3VwLGRvd24sbGVmdCxyaWdodCcpXG4gIH1cbn1cblxuY29uc3QgZW5zdXJlRmxleCA9IGVsID0+IHtcbiAgZWwuc3R5bGUuZGlzcGxheSA9ICdmbGV4J1xuICByZXR1cm4gZWxcbn1cblxuY29uc3QgYWNjb3VudEZvck90aGVySnVzdGlmeUNvbnRlbnQgPSAoY3VyLCB3YW50KSA9PiB7XG4gIGlmICh3YW50ID09ICdhbGlnbicgJiYgKGN1ciAhPSAnZmxleC1zdGFydCcgJiYgY3VyICE9ICdjZW50ZXInICYmIGN1ciAhPSAnZmxleC1lbmQnKSlcbiAgICBjdXIgPSAnbm9ybWFsJ1xuICBlbHNlIGlmICh3YW50ID09ICdkaXN0cmlidXRlJyAmJiAoY3VyICE9ICdzcGFjZS1hcm91bmQnICYmIGN1ciAhPSAnc3BhY2UtYmV0d2VlbicpKVxuICAgIGN1ciA9ICdub3JtYWwnXG5cbiAgcmV0dXJuIGN1clxufVxuXG4vLyB0b2RvOiBzdXBwb3J0IHJldmVyc2luZyBkaXJlY3Rpb25cbmV4cG9ydCBmdW5jdGlvbiBjaGFuZ2VEaXJlY3Rpb24oZWxzLCB2YWx1ZSkge1xuICBlbHNcbiAgICAubWFwKGVuc3VyZUZsZXgpXG4gICAgLm1hcChlbCA9PiB7XG4gICAgICBlbC5zdHlsZS5mbGV4RGlyZWN0aW9uID0gdmFsdWVcbiAgICB9KVxufVxuXG5jb25zdCBoX2FsaWduTWFwICAgICAgPSB7bm9ybWFsOiAwLCdmbGV4LXN0YXJ0JzogMCwnY2VudGVyJzogMSwnZmxleC1lbmQnOiAyLH1cbmNvbnN0IGhfYWxpZ25PcHRpb25zICA9IFsnZmxleC1zdGFydCcsJ2NlbnRlcicsJ2ZsZXgtZW5kJ11cblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZUhBbGlnbm1lbnQoZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbnN1cmVGbGV4KVxuICAgIC5tYXAoZWwgPT4gKHtcbiAgICAgIGVsLFxuICAgICAgc3R5bGU6ICAgICdqdXN0aWZ5Q29udGVudCcsXG4gICAgICBjdXJyZW50OiAgYWNjb3VudEZvck90aGVySnVzdGlmeUNvbnRlbnQoZ2V0U3R5bGUoZWwsICdqdXN0aWZ5Q29udGVudCcpLCAnYWxpZ24nKSxcbiAgICAgIGRpcmVjdGlvbjogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ2xlZnQnKSxcbiAgICB9KSlcbiAgICAubWFwKHBheWxvYWQgPT5cbiAgICAgIE9iamVjdC5hc3NpZ24ocGF5bG9hZCwge1xuICAgICAgICB2YWx1ZTogcGF5bG9hZC5kaXJlY3Rpb25cbiAgICAgICAgICA/IGhfYWxpZ25NYXBbcGF5bG9hZC5jdXJyZW50XSAtIDFcbiAgICAgICAgICA6IGhfYWxpZ25NYXBbcGF5bG9hZC5jdXJyZW50XSArIDFcbiAgICAgIH0pKVxuICAgIC5mb3JFYWNoKCh7ZWwsIHN0eWxlLCB2YWx1ZX0pID0+XG4gICAgICBlbC5zdHlsZVtzdHlsZV0gPSBoX2FsaWduT3B0aW9uc1t2YWx1ZSA8IDAgPyAwIDogdmFsdWUgPj0gMiA/IDI6IHZhbHVlXSlcbn1cblxuY29uc3Qgdl9hbGlnbk1hcCAgICAgID0ge25vcm1hbDogMCwnZmxleC1zdGFydCc6IDAsJ2NlbnRlcic6IDEsJ2ZsZXgtZW5kJzogMix9XG5jb25zdCB2X2FsaWduT3B0aW9ucyAgPSBbJ2ZsZXgtc3RhcnQnLCdjZW50ZXInLCdmbGV4LWVuZCddXG5cbmV4cG9ydCBmdW5jdGlvbiBjaGFuZ2VWQWxpZ25tZW50KGVscywgZGlyZWN0aW9uKSB7XG4gIGVsc1xuICAgIC5tYXAoZW5zdXJlRmxleClcbiAgICAubWFwKGVsID0+ICh7XG4gICAgICBlbCxcbiAgICAgIHN0eWxlOiAgICAnYWxpZ25JdGVtcycsXG4gICAgICBjdXJyZW50OiAgZ2V0U3R5bGUoZWwsICdhbGlnbkl0ZW1zJyksXG4gICAgICBkaXJlY3Rpb246IGRpcmVjdGlvbi5zcGxpdCgnKycpLmluY2x1ZGVzKCd1cCcpLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIHZhbHVlOiBwYXlsb2FkLmRpcmVjdGlvblxuICAgICAgICAgID8gaF9hbGlnbk1hcFtwYXlsb2FkLmN1cnJlbnRdIC0gMVxuICAgICAgICAgIDogaF9hbGlnbk1hcFtwYXlsb2FkLmN1cnJlbnRdICsgMVxuICAgICAgfSkpXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIHZhbHVlfSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IHZfYWxpZ25PcHRpb25zW3ZhbHVlIDwgMCA/IDAgOiB2YWx1ZSA+PSAyID8gMjogdmFsdWVdKVxufVxuXG5jb25zdCBoX2Rpc3RyaWJ1dGlvbk1hcCAgICAgID0ge25vcm1hbDogMSwnc3BhY2UtYXJvdW5kJzogMCwnJzogMSwnc3BhY2UtYmV0d2Vlbic6IDIsfVxuY29uc3QgaF9kaXN0cmlidXRpb25PcHRpb25zICA9IFsnc3BhY2UtYXJvdW5kJywnJywnc3BhY2UtYmV0d2VlbiddXG5cbmV4cG9ydCBmdW5jdGlvbiBjaGFuZ2VIRGlzdHJpYnV0aW9uKGVscywgZGlyZWN0aW9uKSB7XG4gIGVsc1xuICAgIC5tYXAoZW5zdXJlRmxleClcbiAgICAubWFwKGVsID0+ICh7XG4gICAgICBlbCxcbiAgICAgIHN0eWxlOiAgICAnanVzdGlmeUNvbnRlbnQnLFxuICAgICAgY3VycmVudDogIGFjY291bnRGb3JPdGhlckp1c3RpZnlDb250ZW50KGdldFN0eWxlKGVsLCAnanVzdGlmeUNvbnRlbnQnKSwgJ2Rpc3RyaWJ1dGUnKSxcbiAgICAgIGRpcmVjdGlvbjogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ2xlZnQnKSxcbiAgICB9KSlcbiAgICAubWFwKHBheWxvYWQgPT5cbiAgICAgIE9iamVjdC5hc3NpZ24ocGF5bG9hZCwge1xuICAgICAgICB2YWx1ZTogcGF5bG9hZC5kaXJlY3Rpb25cbiAgICAgICAgICA/IGhfZGlzdHJpYnV0aW9uTWFwW3BheWxvYWQuY3VycmVudF0gLSAxXG4gICAgICAgICAgOiBoX2Rpc3RyaWJ1dGlvbk1hcFtwYXlsb2FkLmN1cnJlbnRdICsgMVxuICAgICAgfSkpXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIHZhbHVlfSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IGhfZGlzdHJpYnV0aW9uT3B0aW9uc1t2YWx1ZSA8IDAgPyAwIDogdmFsdWUgPj0gMiA/IDI6IHZhbHVlXSlcbn1cblxuY29uc3Qgdl9kaXN0cmlidXRpb25NYXAgICAgICA9IHtub3JtYWw6IDEsJ3NwYWNlLWFyb3VuZCc6IDAsJyc6IDEsJ3NwYWNlLWJldHdlZW4nOiAyLH1cbmNvbnN0IHZfZGlzdHJpYnV0aW9uT3B0aW9ucyAgPSBbJ3NwYWNlLWFyb3VuZCcsJycsJ3NwYWNlLWJldHdlZW4nXVxuXG5leHBvcnQgZnVuY3Rpb24gY2hhbmdlVkRpc3RyaWJ1dGlvbihlbHMsIGRpcmVjdGlvbikge1xuICBlbHNcbiAgICAubWFwKGVuc3VyZUZsZXgpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgZWwsXG4gICAgICBzdHlsZTogICAgJ2FsaWduQ29udGVudCcsXG4gICAgICBjdXJyZW50OiAgZ2V0U3R5bGUoZWwsICdhbGlnbkNvbnRlbnQnKSxcbiAgICAgIGRpcmVjdGlvbjogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ3VwJyksXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgdmFsdWU6IHBheWxvYWQuZGlyZWN0aW9uXG4gICAgICAgICAgPyB2X2Rpc3RyaWJ1dGlvbk1hcFtwYXlsb2FkLmN1cnJlbnRdIC0gMVxuICAgICAgICAgIDogdl9kaXN0cmlidXRpb25NYXBbcGF5bG9hZC5jdXJyZW50XSArIDFcbiAgICAgIH0pKVxuICAgIC5mb3JFYWNoKCh7ZWwsIHN0eWxlLCB2YWx1ZX0pID0+XG4gICAgICBlbC5zdHlsZVtzdHlsZV0gPSB2X2Rpc3RyaWJ1dGlvbk9wdGlvbnNbdmFsdWUgPCAwID8gMCA6IHZhbHVlID49IDIgPyAyOiB2YWx1ZV0pXG59XG4iLCJpbXBvcnQgJCBmcm9tICdibGluZ2JsaW5nanMnXG5pbXBvcnQgeyBUaW55Q29sb3IgfSBmcm9tICdAY3RybC90aW55Y29sb3InXG5pbXBvcnQgeyBnZXRTdHlsZSB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmV4cG9ydCBmdW5jdGlvbiBDb2xvclBpY2tlcihwYWxsZXRlLCBzZWxlY3RvckVuZ2luZSkge1xuICBjb25zdCBmb3JlZ3JvdW5kUGlja2VyICA9ICQoJyNmb3JlZ3JvdW5kJywgcGFsbGV0ZSlcbiAgY29uc3QgYmFja2dyb3VuZFBpY2tlciAgPSAkKCcjYmFja2dyb3VuZCcsIHBhbGxldGUpXG4gIGNvbnN0IGJvcmRlclBpY2tlciAgICAgID0gJCgnI2JvcmRlcicsIHBhbGxldGUpXG4gIGNvbnN0IGZnSW5wdXQgICAgICAgICAgID0gJCgnaW5wdXQnLCBmb3JlZ3JvdW5kUGlja2VyWzBdKVxuICBjb25zdCBiZ0lucHV0ICAgICAgICAgICA9ICQoJ2lucHV0JywgYmFja2dyb3VuZFBpY2tlclswXSlcbiAgY29uc3QgYm9JbnB1dCAgICAgICAgICAgPSAkKCdpbnB1dCcsIGJvcmRlclBpY2tlclswXSlcblxuICBjb25zdCBzaGFkb3dzID0ge1xuICAgIGFjdGl2ZTogICAncmdiYSgwLCAwLCAwLCAwLjEpIDBweCAwLjI1ZW0gMC41ZW0sIDAgMCAwIDJweCBob3RwaW5rJyxcbiAgICBpbmFjdGl2ZTogJ3JnYmEoMCwgMCwgMCwgMC4xKSAwcHggMC4yNWVtIDAuNWVtJyxcbiAgfVxuXG4gIHRoaXMuYWN0aXZlX2NvbG9yICAgICAgID0gJ2JhY2tncm91bmQnXG4gIHRoaXMuZWxlbWVudHMgICAgICAgICAgID0gW11cblxuICAvLyBzZXQgY29sb3JzXG4gIGZnSW5wdXQub24oJ2lucHV0JywgZSA9PlxuICAgIHRoaXMuZWxlbWVudHMubWFwKGVsID0+XG4gICAgICBlbC5zdHlsZVsnY29sb3InXSA9IGUudGFyZ2V0LnZhbHVlKSlcblxuICBiZ0lucHV0Lm9uKCdpbnB1dCcsIGUgPT5cbiAgICB0aGlzLmVsZW1lbnRzLm1hcChlbCA9PlxuICAgICAgZWwuc3R5bGVbZWwgaW5zdGFuY2VvZiBTVkdFbGVtZW50XG4gICAgICAgID8gJ2ZpbGwnXG4gICAgICAgIDogJ2JhY2tncm91bmRDb2xvcidcbiAgICAgIF0gPSBlLnRhcmdldC52YWx1ZSkpXG5cbiAgYm9JbnB1dC5vbignaW5wdXQnLCBlID0+XG4gICAgdGhpcy5lbGVtZW50cy5tYXAoZWwgPT5cbiAgICAgIGVsLnN0eWxlW2VsIGluc3RhbmNlb2YgU1ZHRWxlbWVudFxuICAgICAgICA/ICdzdHJva2UnXG4gICAgICAgIDogJ2JvcmRlci1jb2xvcidcbiAgICAgIF0gPSBlLnRhcmdldC52YWx1ZSkpXG5cbiAgLy8gcmVhZCBjb2xvcnNcbiAgc2VsZWN0b3JFbmdpbmUub25TZWxlY3RlZFVwZGF0ZShlbGVtZW50cyA9PiB7XG4gICAgaWYgKCFlbGVtZW50cy5sZW5ndGgpIHJldHVyblxuICAgIHRoaXMuZWxlbWVudHMgPSBlbGVtZW50c1xuXG4gICAgbGV0IGlzTWVhbmluZ2Z1bEZvcmVncm91bmQgID0gZmFsc2VcbiAgICBsZXQgaXNNZWFuaW5nZnVsQmFja2dyb3VuZCAgPSBmYWxzZVxuICAgIGxldCBpc01lYW5pbmdmdWxCb3JkZXIgICAgICA9IGZhbHNlXG4gICAgbGV0IEZHLCBCRywgQk9cblxuICAgIGlmICh0aGlzLmVsZW1lbnRzLmxlbmd0aCA9PSAxKSB7XG4gICAgICBjb25zdCBlbCA9IHRoaXMuZWxlbWVudHNbMF1cbiAgICAgIGNvbnN0IG1lYW5pbmdmdWxEb250TWF0dGVyID0gcGFsbGV0ZS5ob3N0LmFjdGl2ZV90b29sLmRhdGFzZXQudG9vbCA9PT0gJ2h1ZXNoaWZ0J1xuXG4gICAgICBpZiAoZWwgaW5zdGFuY2VvZiBTVkdFbGVtZW50KSB7XG4gICAgICAgIEZHID0gbmV3IFRpbnlDb2xvcigncmdiKDAsIDAsIDApJylcbiAgICAgICAgdmFyIGJvX3RlbXAgPSBnZXRTdHlsZShlbCwgJ3N0cm9rZScpXG4gICAgICAgIEJPID0gbmV3IFRpbnlDb2xvcihib190ZW1wID09PSAnbm9uZSdcbiAgICAgICAgICA/ICdyZ2IoMCwgMCwgMCknXG4gICAgICAgICAgOiBib190ZW1wKVxuICAgICAgICBCRyA9IG5ldyBUaW55Q29sb3IoZ2V0U3R5bGUoZWwsICdmaWxsJykpXG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgRkcgPSBuZXcgVGlueUNvbG9yKGdldFN0eWxlKGVsLCAnY29sb3InKSlcbiAgICAgICAgQkcgPSBuZXcgVGlueUNvbG9yKGdldFN0eWxlKGVsLCAnYmFja2dyb3VuZENvbG9yJykpXG4gICAgICAgIEJPID0gZ2V0U3R5bGUoZWwsICdib3JkZXJXaWR0aCcpID09PSAnMHB4J1xuICAgICAgICAgID8gbmV3IFRpbnlDb2xvcigncmdiKDAsIDAsIDApJylcbiAgICAgICAgICA6IG5ldyBUaW55Q29sb3IoZ2V0U3R5bGUoZWwsICdib3JkZXJDb2xvcicpKVxuICAgICAgfVxuXG4gICAgICBsZXQgZmcgPSBGRy50b0hleFN0cmluZygpXG4gICAgICBsZXQgYmcgPSBCRy50b0hleFN0cmluZygpXG4gICAgICBsZXQgYm8gPSBCTy50b0hleFN0cmluZygpXG5cbiAgICAgIGlzTWVhbmluZ2Z1bEZvcmVncm91bmQgPSBGRy5vcmlnaW5hbElucHV0ICE9PSAncmdiKDAsIDAsIDApJyB8fCAoZWwuY2hpbGRyZW4ubGVuZ3RoID09PSAwICYmIGVsLnRleHRDb250ZW50ICE9PSAnJylcbiAgICAgIGlzTWVhbmluZ2Z1bEJhY2tncm91bmQgPSBCRy5vcmlnaW5hbElucHV0ICE9PSAncmdiYSgwLCAwLCAwLCAwKSdcbiAgICAgIGlzTWVhbmluZ2Z1bEJvcmRlciAgICAgPSBCTy5vcmlnaW5hbElucHV0ICE9PSAncmdiKDAsIDAsIDApJ1xuXG4gICAgICBpZiAoaXNNZWFuaW5nZnVsRm9yZWdyb3VuZCAmJiAhaXNNZWFuaW5nZnVsQmFja2dyb3VuZClcbiAgICAgICAgc2V0QWN0aXZlKCdmb3JlZ3JvdW5kJylcbiAgICAgIGVsc2UgaWYgKGlzTWVhbmluZ2Z1bEJhY2tncm91bmQgJiYgIWlzTWVhbmluZ2Z1bEZvcmVncm91bmQpXG4gICAgICAgIHNldEFjdGl2ZSgnYmFja2dyb3VuZCcpXG5cbiAgICAgIGNvbnN0IG5ld19mZyA9IGlzTWVhbmluZ2Z1bEZvcmVncm91bmQgPyBmZyA6ICcnXG4gICAgICBjb25zdCBuZXdfYmcgPSBpc01lYW5pbmdmdWxCYWNrZ3JvdW5kID8gYmcgOiAnJ1xuICAgICAgY29uc3QgbmV3X2JvID0gaXNNZWFuaW5nZnVsQm9yZGVyID8gYm8gOiAnJ1xuXG4gICAgICBmZ0lucHV0LmF0dHIoJ3ZhbHVlJywgbmV3X2ZnKVxuICAgICAgYmdJbnB1dC5hdHRyKCd2YWx1ZScsIG5ld19iZylcbiAgICAgIGJvSW5wdXQuYXR0cigndmFsdWUnLCBuZXdfYm8pXG5cbiAgICAgIGZvcmVncm91bmRQaWNrZXIuYXR0cignc3R5bGUnLCBgXG4gICAgICAgIC0tY29udGV4dHVhbF9jb2xvcjogJHtuZXdfZmd9O1xuICAgICAgICBkaXNwbGF5OiAke2lzTWVhbmluZ2Z1bEZvcmVncm91bmQgfHwgbWVhbmluZ2Z1bERvbnRNYXR0ZXIgPyAnaW5saW5lLWZsZXgnIDogJ25vbmUnfTtcbiAgICAgIGApXG5cbiAgICAgIGJhY2tncm91bmRQaWNrZXIuYXR0cignc3R5bGUnLCBgXG4gICAgICAgIC0tY29udGV4dHVhbF9jb2xvcjogJHtuZXdfYmd9O1xuICAgICAgICBkaXNwbGF5OiAke2lzTWVhbmluZ2Z1bEJhY2tncm91bmQgfHwgbWVhbmluZ2Z1bERvbnRNYXR0ZXIgPyAnaW5saW5lLWZsZXgnIDogJ25vbmUnfTtcbiAgICAgIGApXG5cbiAgICAgIGJvcmRlclBpY2tlci5hdHRyKCdzdHlsZScsIGBcbiAgICAgICAgLS1jb250ZXh0dWFsX2NvbG9yOiAke25ld19ib307XG4gICAgICAgIGRpc3BsYXk6ICR7aXNNZWFuaW5nZnVsQm9yZGVyIHx8IG1lYW5pbmdmdWxEb250TWF0dGVyID8gJ2lubGluZS1mbGV4JyA6ICdub25lJ307XG4gICAgICBgKVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIC8vIHNob3cgYWxsIDMgaWYgdGhleSd2ZSBzZWxlY3RlZCBtb3JlIHRoYW4gMSBub2RlXG4gICAgICAvLyB0b2RvOiB0aGlzIGlzIGdpdmluZyB1cCwgYW5kIGNhbiBiZSBzb2x2ZWRcbiAgICAgIGZvcmVncm91bmRQaWNrZXIuYXR0cignc3R5bGUnLCBgXG4gICAgICAgIGJveC1zaGFkb3c6ICR7dGhpcy5hY3RpdmVfY29sb3IgPT0gJ2ZvcmVncm91bmQnID8gc2hhZG93cy5hY3RpdmUgOiBzaGFkb3dzLmluYWN0aXZlfTtcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgICBgKVxuXG4gICAgICBiYWNrZ3JvdW5kUGlja2VyLmF0dHIoJ3N0eWxlJywgYFxuICAgICAgICBib3gtc2hhZG93OiAke3RoaXMuYWN0aXZlX2NvbG9yID09ICdiYWNrZ3JvdW5kJyA/IHNoYWRvd3MuYWN0aXZlIDogc2hhZG93cy5pbmFjdGl2ZX07XG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICAgICAgYClcblxuICAgICAgYm9yZGVyUGlja2VyLmF0dHIoJ3N0eWxlJywgYFxuICAgICAgICBib3gtc2hhZG93OiAke3RoaXMuYWN0aXZlX2NvbG9yID09ICdib3JkZXInID8gc2hhZG93cy5hY3RpdmUgOiBzaGFkb3dzLmluYWN0aXZlfTtcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgICBgKVxuICAgIH1cbiAgfSlcblxuICBjb25zdCBnZXRBY3RpdmUgPSAoKSA9PlxuICAgIHRoaXMuYWN0aXZlX2NvbG9yXG5cbiAgY29uc3Qgc2V0QWN0aXZlID0ga2V5ID0+IHtcbiAgICByZW1vdmVBY3RpdmUoKVxuICAgIHRoaXMuYWN0aXZlX2NvbG9yID0ga2V5XG5cbiAgICBpZiAoa2V5ID09PSAnZm9yZWdyb3VuZCcpXG4gICAgICBmb3JlZ3JvdW5kUGlja2VyWzBdLnN0eWxlLmJveFNoYWRvdyA9IHNoYWRvd3MuYWN0aXZlXG4gICAgaWYgKGtleSA9PT0gJ2JhY2tncm91bmQnKVxuICAgICAgYmFja2dyb3VuZFBpY2tlclswXS5zdHlsZS5ib3hTaGFkb3cgPSBzaGFkb3dzLmFjdGl2ZVxuICAgIGlmIChrZXkgPT09ICdib3JkZXInKVxuICAgICAgYm9yZGVyUGlja2VyWzBdLnN0eWxlLmJveFNoYWRvdyA9IHNoYWRvd3MuYWN0aXZlXG4gIH1cblxuICBjb25zdCByZW1vdmVBY3RpdmUgPSAoKSA9PlxuICAgIFtmb3JlZ3JvdW5kUGlja2VyLCBiYWNrZ3JvdW5kUGlja2VyLCBib3JkZXJQaWNrZXJdLmZvckVhY2goKFtwaWNrZXJdKSA9PlxuICAgICAgcGlja2VyLnN0eWxlLmJveFNoYWRvdyA9IHNoYWRvd3MuaW5hY3RpdmUpXG5cbiAgcmV0dXJuIHtcbiAgICBnZXRBY3RpdmUsXG4gICAgc2V0QWN0aXZlLFxuICAgIGZvcmVncm91bmQ6IHsgY29sb3I6IGNvbG9yID0+XG4gICAgICBmb3JlZ3JvdW5kUGlja2VyWzBdLnN0eWxlLnNldFByb3BlcnR5KCctLWNvbnRleHR1YWxfY29sb3InLCBjb2xvcil9LFxuICAgIGJhY2tncm91bmQ6IHsgY29sb3I6IGNvbG9yID0+XG4gICAgICBiYWNrZ3JvdW5kUGlja2VyWzBdLnN0eWxlLnNldFByb3BlcnR5KCctLWNvbnRleHR1YWxfY29sb3InLCBjb2xvcil9XG4gIH1cbn1cbiIsImltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgeyBtZXRhS2V5LCBnZXRTdHlsZSwgc2hvd0hpZGVTZWxlY3RlZCB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmNvbnN0IGtleV9ldmVudHMgPSAndXAsZG93bixsZWZ0LHJpZ2h0J1xuICAuc3BsaXQoJywnKVxuICAucmVkdWNlKChldmVudHMsIGV2ZW50KSA9PlxuICAgIGAke2V2ZW50c30sJHtldmVudH0sc2hpZnQrJHtldmVudH1gXG4gICwgJycpXG4gIC5zdWJzdHJpbmcoMSlcblxuY29uc3QgY29tbWFuZF9ldmVudHMgPSBgJHttZXRhS2V5fSt1cCwke21ldGFLZXl9K3NoaWZ0K3VwLCR7bWV0YUtleX0rZG93biwke21ldGFLZXl9K3NoaWZ0K2Rvd24sJHttZXRhS2V5fStsZWZ0LCR7bWV0YUtleX0rc2hpZnQrbGVmdCwke21ldGFLZXl9K3JpZ2h0LCR7bWV0YUtleX0rc2hpZnQrcmlnaHRgXG5cbmV4cG9ydCBmdW5jdGlvbiBCb3hTaGFkb3coe3NlbGVjdGlvbn0pIHtcbiAgaG90a2V5cyhrZXlfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGlmIChlLmNhbmNlbEJ1YmJsZSkgcmV0dXJuXG5cbiAgICBlLnByZXZlbnREZWZhdWx0KClcblxuICAgIGxldCBzZWxlY3RlZE5vZGVzID0gc2VsZWN0aW9uKClcbiAgICAgICwga2V5cyA9IGhhbmRsZXIua2V5LnNwbGl0KCcrJylcblxuICAgIGlmIChrZXlzLmluY2x1ZGVzKCdsZWZ0JykgfHwga2V5cy5pbmNsdWRlcygncmlnaHQnKSlcbiAgICAgIGtleXMuaW5jbHVkZXMoJ3NoaWZ0JylcbiAgICAgICAgPyBjaGFuZ2VCb3hTaGFkb3coc2VsZWN0ZWROb2Rlcywga2V5cywgJ3NpemUnKVxuICAgICAgICA6IGNoYW5nZUJveFNoYWRvdyhzZWxlY3RlZE5vZGVzLCBrZXlzLCAneCcpXG4gICAgZWxzZVxuICAgICAga2V5cy5pbmNsdWRlcygnc2hpZnQnKVxuICAgICAgICA/IGNoYW5nZUJveFNoYWRvdyhzZWxlY3RlZE5vZGVzLCBrZXlzLCAnYmx1cicpXG4gICAgICAgIDogY2hhbmdlQm94U2hhZG93KHNlbGVjdGVkTm9kZXMsIGtleXMsICd5JylcbiAgfSlcblxuICBob3RrZXlzKGNvbW1hbmRfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGxldCBrZXlzID0gaGFuZGxlci5rZXkuc3BsaXQoJysnKVxuICAgIGtleXMuaW5jbHVkZXMoJ2xlZnQnKSB8fCBrZXlzLmluY2x1ZGVzKCdyaWdodCcpXG4gICAgICA/IGNoYW5nZUJveFNoYWRvdyhzZWxlY3Rpb24oKSwga2V5cywgJ29wYWNpdHknKVxuICAgICAgOiBjaGFuZ2VCb3hTaGFkb3coc2VsZWN0aW9uKCksIGtleXMsICdpbnNldCcpXG4gIH0pXG5cbiAgcmV0dXJuICgpID0+IHtcbiAgICBob3RrZXlzLnVuYmluZChrZXlfZXZlbnRzKVxuICAgIGhvdGtleXMudW5iaW5kKGNvbW1hbmRfZXZlbnRzKVxuICAgIGhvdGtleXMudW5iaW5kKCd1cCxkb3duLGxlZnQscmlnaHQnKVxuICB9XG59XG5cbmNvbnN0IGVuc3VyZUhhc1NoYWRvdyA9IGVsID0+IHtcbiAgaWYgKGVsLnN0eWxlLmJveFNoYWRvdyA9PSAnJyB8fCBlbC5zdHlsZS5ib3hTaGFkb3cgPT0gJ25vbmUnKVxuICAgIGVsLnN0eWxlLmJveFNoYWRvdyA9ICdoc2xhKDAsMCUsMCUsMzAlKSAwIDAgMCAwJ1xuICByZXR1cm4gZWxcbn1cblxuLy8gdG9kbzogd29yayBhcm91bmQgdGhpcyBwcm9wTWFwIHdpdGggYSBiZXR0ZXIgc3BsaXRcbmNvbnN0IHByb3BNYXAgPSB7XG4gICdvcGFjaXR5JzogIDMsXG4gICd4JzogICAgICAgIDQsXG4gICd5JzogICAgICAgIDUsXG4gICdibHVyJzogICAgIDYsXG4gICdzaXplJzogICAgIDcsXG4gICdpbnNldCc6ICAgIDgsXG59XG5cbmNvbnN0IHBhcnNlQ3VycmVudFNoYWRvdyA9IGVsID0+IGdldFN0eWxlKGVsLCAnYm94U2hhZG93Jykuc3BsaXQoJyAnKVxuXG5leHBvcnQgZnVuY3Rpb24gY2hhbmdlQm94U2hhZG93KGVscywgZGlyZWN0aW9uLCBwcm9wKSB7XG4gIGVsc1xuICAgIC5tYXAoZW5zdXJlSGFzU2hhZG93KVxuICAgIC5tYXAoZWwgPT4gc2hvd0hpZGVTZWxlY3RlZChlbCwgMTUwMCkpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgZWwsXG4gICAgICBzdHlsZTogICAgICdib3hTaGFkb3cnLFxuICAgICAgY3VycmVudDogICBwYXJzZUN1cnJlbnRTaGFkb3coZWwpLCAvLyBbXCJyZ2IoMjU1LFwiLCBcIjAsXCIsIFwiMClcIiwgXCIwcHhcIiwgXCIwcHhcIiwgXCIxcHhcIiwgXCIwcHhcIl1cbiAgICAgIHByb3BJbmRleDogcGFyc2VDdXJyZW50U2hhZG93KGVsKVswXS5pbmNsdWRlcygncmdiYScpID8gcHJvcE1hcFtwcm9wXSA6IHByb3BNYXBbcHJvcF0gLSAxXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+IHtcbiAgICAgIGxldCB1cGRhdGVkID0gWy4uLnBheWxvYWQuY3VycmVudF1cbiAgICAgIGxldCBjdXIgICAgID0gcHJvcCA9PT0gJ29wYWNpdHknXG4gICAgICAgID8gcGF5bG9hZC5jdXJyZW50W3BheWxvYWQucHJvcEluZGV4XVxuICAgICAgICA6IHBhcnNlSW50KHBheWxvYWQuY3VycmVudFtwYXlsb2FkLnByb3BJbmRleF0pXG5cbiAgICAgIHN3aXRjaChwcm9wKSB7XG4gICAgICAgIGNhc2UgJ2JsdXInOlxuICAgICAgICAgIHZhciBhbW91bnQgPSBkaXJlY3Rpb24uaW5jbHVkZXMoJ3NoaWZ0JykgPyAxMCA6IDFcbiAgICAgICAgICB1cGRhdGVkW3BheWxvYWQucHJvcEluZGV4XSA9IGRpcmVjdGlvbi5pbmNsdWRlcygnZG93bicpXG4gICAgICAgICAgICA/IGAke2N1ciAtIGFtb3VudH1weGBcbiAgICAgICAgICAgIDogYCR7Y3VyICsgYW1vdW50fXB4YFxuICAgICAgICAgIGJyZWFrXG4gICAgICAgIGNhc2UgJ2luc2V0JzpcbiAgICAgICAgICB1cGRhdGVkW3BheWxvYWQucHJvcEluZGV4XSA9IGRpcmVjdGlvbi5pbmNsdWRlcygnZG93bicpXG4gICAgICAgICAgICA/ICdpbnNldCdcbiAgICAgICAgICAgIDogJydcbiAgICAgICAgICBicmVha1xuICAgICAgICBjYXNlICdvcGFjaXR5JzpcbiAgICAgICAgICBsZXQgY3VyX29wYWNpdHkgPSBwYXJzZUZsb2F0KGN1ci5zbGljZSgwLCBjdXIuaW5kZXhPZignKScpKSlcbiAgICAgICAgICB2YXIgYW1vdW50ID0gZGlyZWN0aW9uLmluY2x1ZGVzKCdzaGlmdCcpID8gMC4xMCA6IDAuMDFcbiAgICAgICAgICB1cGRhdGVkW3BheWxvYWQucHJvcEluZGV4XSA9IGRpcmVjdGlvbi5pbmNsdWRlcygnbGVmdCcpXG4gICAgICAgICAgICA/IGN1cl9vcGFjaXR5IC0gYW1vdW50ICsgJyknXG4gICAgICAgICAgICA6IGN1cl9vcGFjaXR5ICsgYW1vdW50ICsgJyknXG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICB1cGRhdGVkW3BheWxvYWQucHJvcEluZGV4XSA9IGRpcmVjdGlvbi5pbmNsdWRlcygnbGVmdCcpIHx8IGRpcmVjdGlvbi5pbmNsdWRlcygndXAnKVxuICAgICAgICAgICAgPyBgJHtjdXIgLSAxfXB4YFxuICAgICAgICAgICAgOiBgJHtjdXIgKyAxfXB4YFxuICAgICAgICAgIGJyZWFrXG4gICAgICB9XG5cbiAgICAgIHBheWxvYWQudmFsdWUgPSB1cGRhdGVkXG4gICAgICByZXR1cm4gcGF5bG9hZFxuICAgIH0pXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIHZhbHVlfSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IHZhbHVlLmpvaW4oJyAnKSlcbn1cbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgeyBUaW55Q29sb3IgfSBmcm9tICdAY3RybC90aW55Y29sb3InXG5cbmltcG9ydCB7IG1ldGFLZXksIGdldFN0eWxlLCBzaG93SGlkZVNlbGVjdGVkIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuY29uc3Qga2V5X2V2ZW50cyA9ICd1cCxkb3duLGxlZnQscmlnaHQnXG4gIC5zcGxpdCgnLCcpXG4gIC5yZWR1Y2UoKGV2ZW50cywgZXZlbnQpID0+XG4gICAgYCR7ZXZlbnRzfSwke2V2ZW50fSxzaGlmdCske2V2ZW50fWBcbiAgLCAnJylcbiAgLnN1YnN0cmluZygxKVxuXG5jb25zdCBjb21tYW5kX2V2ZW50cyA9IGAke21ldGFLZXl9K3VwLCR7bWV0YUtleX0rc2hpZnQrdXAsJHttZXRhS2V5fStkb3duLCR7bWV0YUtleX0rc2hpZnQrZG93biwke21ldGFLZXl9K2xlZnQsJHttZXRhS2V5fStzaGlmdCtsZWZ0LCR7bWV0YUtleX0rcmlnaHQsJHttZXRhS2V5fStzaGlmdCtyaWdodGBcblxuZXhwb3J0IGZ1bmN0aW9uIEh1ZVNoaWZ0KENvbG9yKSB7XG4gIHRoaXMuYWN0aXZlX2NvbG9yICAgPSBDb2xvci5nZXRBY3RpdmUoKVxuICB0aGlzLmVsZW1lbnRzICAgICAgID0gW11cblxuICBob3RrZXlzKGtleV9ldmVudHMsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgaWYgKGUuY2FuY2VsQnViYmxlKSByZXR1cm5cblxuICAgIGUucHJldmVudERlZmF1bHQoKVxuXG4gICAgbGV0IHNlbGVjdGVkTm9kZXMgPSB0aGlzLmVsZW1lbnRzXG4gICAgICAsIGtleXMgPSBoYW5kbGVyLmtleS5zcGxpdCgnKycpXG5cbiAgICBrZXlzLmluY2x1ZGVzKCdsZWZ0JykgfHwga2V5cy5pbmNsdWRlcygncmlnaHQnKVxuICAgICAgPyBjaGFuZ2VIdWUoc2VsZWN0ZWROb2Rlcywga2V5cywgJ3MnLCBDb2xvcilcbiAgICAgIDogY2hhbmdlSHVlKHNlbGVjdGVkTm9kZXMsIGtleXMsICdsJywgQ29sb3IpXG4gIH0pXG5cbiAgaG90a2V5cyhjb21tYW5kX2V2ZW50cywgKGUsIGhhbmRsZXIpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBsZXQga2V5cyA9IGhhbmRsZXIua2V5LnNwbGl0KCcrJylcbiAgICBrZXlzLmluY2x1ZGVzKCdsZWZ0JykgfHwga2V5cy5pbmNsdWRlcygncmlnaHQnKVxuICAgICAgPyBjaGFuZ2VIdWUodGhpcy5lbGVtZW50cywga2V5cywgJ2EnLCBDb2xvcilcbiAgICAgIDogY2hhbmdlSHVlKHRoaXMuZWxlbWVudHMsIGtleXMsICdoJywgQ29sb3IpXG4gIH0pXG5cbiAgaG90a2V5cygnXScsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICBpZiAodGhpcy5hY3RpdmVfY29sb3IgPT0gJ2ZvcmVncm91bmQnKVxuICAgICAgdGhpcy5hY3RpdmVfY29sb3IgPSAnYmFja2dyb3VuZCdcbiAgICBlbHNlIGlmICh0aGlzLmFjdGl2ZV9jb2xvciA9PSAnYmFja2dyb3VuZCcpXG4gICAgICB0aGlzLmFjdGl2ZV9jb2xvciA9ICdib3JkZXInXG5cbiAgICBDb2xvci5zZXRBY3RpdmUodGhpcy5hY3RpdmVfY29sb3IpXG4gIH0pXG5cbiAgaG90a2V5cygnWycsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICBpZiAodGhpcy5hY3RpdmVfY29sb3IgPT0gJ2JhY2tncm91bmQnKVxuICAgICAgdGhpcy5hY3RpdmVfY29sb3IgPSAnZm9yZWdyb3VuZCdcbiAgICBlbHNlIGlmICh0aGlzLmFjdGl2ZV9jb2xvciA9PSAnYm9yZGVyJylcbiAgICAgIHRoaXMuYWN0aXZlX2NvbG9yID0gJ2JhY2tncm91bmQnXG5cbiAgICBDb2xvci5zZXRBY3RpdmUodGhpcy5hY3RpdmVfY29sb3IpXG4gIH0pXG5cbiAgY29uc3Qgb25Ob2Rlc1NlbGVjdGVkID0gZWxzID0+IHtcbiAgICB0aGlzLmVsZW1lbnRzID0gZWxzXG4gICAgQ29sb3Iuc2V0QWN0aXZlKHRoaXMuYWN0aXZlX2NvbG9yKVxuICB9XG5cbiAgY29uc3QgZGlzY29ubmVjdCA9ICgpID0+IHtcbiAgICBob3RrZXlzLnVuYmluZChrZXlfZXZlbnRzKVxuICAgIGhvdGtleXMudW5iaW5kKGNvbW1hbmRfZXZlbnRzKVxuICAgIGhvdGtleXMudW5iaW5kKCd1cCxkb3duLGxlZnQscmlnaHQnKVxuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBvbk5vZGVzU2VsZWN0ZWQsXG4gICAgZGlzY29ubmVjdCxcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY2hhbmdlSHVlKGVscywgZGlyZWN0aW9uLCBwcm9wLCBDb2xvcikge1xuICBlbHNcbiAgICAubWFwKGVsID0+IHNob3dIaWRlU2VsZWN0ZWQoZWwpKVxuICAgIC5tYXAoZWwgPT4ge1xuICAgICAgY29uc3QgeyBmb3JlZ3JvdW5kLCBiYWNrZ3JvdW5kLCBib3JkZXIgfSA9IGV4dHJhY3RQYWxsZXRlQ29sb3JzKGVsKVxuXG4gICAgICAvLyB0b2RvOiB0ZWFjaCBodWVzaGlmdCB0byBkbyBoYW5kbGUgY29sb3JcbiAgICAgIHN3aXRjaChDb2xvci5nZXRBY3RpdmUoKSkge1xuICAgICAgICBjYXNlICdiYWNrZ3JvdW5kJzpcbiAgICAgICAgICByZXR1cm4geyBlbCwgY3VycmVudDogYmFja2dyb3VuZC5jb2xvci50b0hzbCgpLCBzdHlsZTogYmFja2dyb3VuZC5zdHlsZSB9XG4gICAgICAgIGNhc2UgJ2ZvcmVncm91bmQnOlxuICAgICAgICAgIHJldHVybiB7IGVsLCBjdXJyZW50OiBmb3JlZ3JvdW5kLmNvbG9yLnRvSHNsKCksIHN0eWxlOiBmb3JlZ3JvdW5kLnN0eWxlIH1cbiAgICAgICAgY2FzZSAnYm9yZGVyJzoge1xuICAgICAgICAgIGlmIChlbC5zdHlsZS5ib3JkZXIgPT09ICcnKSBlbC5zdHlsZS5ib3JkZXIgPSAnMXB4IHNvbGlkIGJsYWNrJ1xuICAgICAgICAgIHJldHVybiB7IGVsLCBjdXJyZW50OiBib3JkZXIuY29sb3IudG9Ic2woKSwgc3R5bGU6IGJvcmRlci5zdHlsZSB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIGFtb3VudDogICBkaXJlY3Rpb24uaW5jbHVkZXMoJ3NoaWZ0JykgPyAxMCA6IDEsXG4gICAgICAgIG5lZ2F0aXZlOiBkaXJlY3Rpb24uaW5jbHVkZXMoJ2Rvd24nKSB8fCBkaXJlY3Rpb24uaW5jbHVkZXMoJ2xlZnQnKSxcbiAgICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PiB7XG4gICAgICBpZiAocHJvcCA9PT0gJ3MnIHx8IHByb3AgPT09ICdsJyB8fCBwcm9wID09PSAnYScpXG4gICAgICAgIHBheWxvYWQuYW1vdW50ID0gcGF5bG9hZC5hbW91bnQgKiAwLjAxXG5cbiAgICAgIHBheWxvYWQuY3VycmVudFtwcm9wXSA9IHBheWxvYWQubmVnYXRpdmVcbiAgICAgICAgPyBwYXlsb2FkLmN1cnJlbnRbcHJvcF0gLSBwYXlsb2FkLmFtb3VudFxuICAgICAgICA6IHBheWxvYWQuY3VycmVudFtwcm9wXSArIHBheWxvYWQuYW1vdW50XG5cbiAgICAgIGlmIChwcm9wID09PSAncycgfHwgcHJvcCA9PT0gJ2wnIHx8IHByb3AgPT09ICdhJykge1xuICAgICAgICBpZiAocGF5bG9hZC5jdXJyZW50W3Byb3BdID4gMSkgcGF5bG9hZC5jdXJyZW50W3Byb3BdID0gMVxuICAgICAgICBpZiAocGF5bG9hZC5jdXJyZW50W3Byb3BdIDwgMCkgcGF5bG9hZC5jdXJyZW50W3Byb3BdID0gMFxuICAgICAgfVxuXG4gICAgICByZXR1cm4gcGF5bG9hZFxuICAgIH0pXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIGN1cnJlbnR9KSA9PiB7XG4gICAgICBsZXQgY29sb3IgPSBuZXcgVGlueUNvbG9yKGN1cnJlbnQpLnNldEFscGhhKGN1cnJlbnQuYSlcbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IGNvbG9yLnRvSHNsU3RyaW5nKClcblxuICAgICAgaWYgKHN0eWxlID09ICdjb2xvcicpIENvbG9yLmZvcmVncm91bmQuY29sb3IoY29sb3IudG9IZXhTdHJpbmcoKSlcbiAgICAgIGlmIChzdHlsZSA9PSAnYmFja2dyb3VuZENvbG9yJykgQ29sb3IuYmFja2dyb3VuZC5jb2xvcihjb2xvci50b0hleFN0cmluZygpKVxuICAgIH0pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBleHRyYWN0UGFsbGV0ZUNvbG9ycyhlbCkge1xuICBpZiAoZWwgaW5zdGFuY2VvZiBTVkdFbGVtZW50KSB7XG4gICAgY29uc3QgIGZnX3RlbXAgPSBnZXRTdHlsZShlbCwgJ3N0cm9rZScpXG5cbiAgICByZXR1cm4ge1xuICAgICAgZm9yZWdyb3VuZDoge1xuICAgICAgICBzdHlsZTogJ3N0cm9rZScsXG4gICAgICAgIGNvbG9yOiBuZXcgVGlueUNvbG9yKGZnX3RlbXAgPT09ICdub25lJ1xuICAgICAgICAgID8gJ3JnYigwLCAwLCAwKSdcbiAgICAgICAgICA6IGZnX3RlbXApLFxuICAgICAgfSxcbiAgICAgIGJhY2tncm91bmQ6IHtcbiAgICAgICAgc3R5bGU6ICdmaWxsJyxcbiAgICAgICAgY29sb3I6IG5ldyBUaW55Q29sb3IoZ2V0U3R5bGUoZWwsICdmaWxsJykpLFxuICAgICAgfSxcbiAgICAgIGJvcmRlcjoge1xuICAgICAgICBzdHlsZTogJ291dGxpbmUnLFxuICAgICAgICBjb2xvcjogbmV3IFRpbnlDb2xvcihnZXRTdHlsZShlbCwgJ291dGxpbmUnKSksXG4gICAgICB9XG4gICAgfVxuICB9XG4gIGVsc2VcbiAgICByZXR1cm4ge1xuICAgICAgZm9yZWdyb3VuZDoge1xuICAgICAgICBzdHlsZTogJ2NvbG9yJyxcbiAgICAgICAgY29sb3I6IG5ldyBUaW55Q29sb3IoZ2V0U3R5bGUoZWwsICdjb2xvcicpKSxcbiAgICAgIH0sXG4gICAgICBiYWNrZ3JvdW5kOiB7XG4gICAgICAgIHN0eWxlOiAnYmFja2dyb3VuZENvbG9yJyxcbiAgICAgICAgY29sb3I6IG5ldyBUaW55Q29sb3IoZ2V0U3R5bGUoZWwsICdiYWNrZ3JvdW5kQ29sb3InKSksXG4gICAgICB9LFxuICAgICAgYm9yZGVyOiB7XG4gICAgICAgIHN0eWxlOiAnYm9yZGVyQ29sb3InLFxuICAgICAgICBjb2xvcjogbmV3IFRpbnlDb2xvcihnZXRTdHlsZShlbCwgJ2JvcmRlckNvbG9yJykpLFxuICAgICAgfVxuICAgIH1cbn1cbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCB7IGlzT2ZmQm91bmRzLCBkZWVwRWxlbWVudEZyb21Qb2ludCB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmxldCBncmlkbGluZXNcblxuZXhwb3J0IGZ1bmN0aW9uIEd1aWRlcygpIHtcbiAgJCgnYm9keScpLm9uKCdtb3VzZW1vdmUnLCBvbl9ob3ZlcilcbiAgJCgnYm9keScpLm9uKCdtb3VzZW91dCcsIG9uX2hvdmVyb3V0KVxuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgaGlkZUdyaWRsaW5lcylcblxuICByZXR1cm4gKCkgPT4ge1xuICAgICQoJ2JvZHknKS5vZmYoJ21vdXNlbW92ZScsIG9uX2hvdmVyKVxuICAgICQoJ2JvZHknKS5vZmYoJ21vdXNlb3V0Jywgb25faG92ZXJvdXQpXG4gICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIGhpZGVHcmlkbGluZXMpXG4gICAgaGlkZUdyaWRsaW5lcygpXG4gIH1cbn1cblxuY29uc3Qgb25faG92ZXIgPSBlID0+IHtcbiAgY29uc3QgdGFyZ2V0ID0gZGVlcEVsZW1lbnRGcm9tUG9pbnQoZS5jbGllbnRYLCBlLmNsaWVudFkpXG4gIGlmIChpc09mZkJvdW5kcyh0YXJnZXQpKSByZXR1cm5cbiAgc2hvd0dyaWRsaW5lcyh0YXJnZXQpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVHdWlkZSh2ZXJ0ID0gdHJ1ZSkge1xuICBsZXQgZ3VpZGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICBsZXQgc3R5bGVzID0gYFxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDA7XG4gICAgbGVmdDogMDtcbiAgICBiYWNrZ3JvdW5kOiBoc2xhKDMzMCwgMTAwJSwgNzElLCA3MCUpO1xuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgIHotaW5kZXg6IDIxNDc0ODM2NDM7XG4gIGBcblxuICB2ZXJ0IFxuICAgID8gc3R5bGVzICs9IGBcbiAgICAgICAgd2lkdGg6IDFweDtcbiAgICAgICAgaGVpZ2h0OiAxMDB2aDtcbiAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMTgwZGVnKTtcbiAgICAgIGBcbiAgICA6IHN0eWxlcyArPSBgXG4gICAgICAgIGhlaWdodDogMXB4O1xuICAgICAgICB3aWR0aDogMTAwdnc7XG4gICAgICBgXG5cbiAgZ3VpZGUuc3R5bGUgPSBzdHlsZXNcblxuICByZXR1cm4gZ3VpZGVcbn1cblxuY29uc3Qgb25faG92ZXJvdXQgPSAoe3RhcmdldH0pID0+XG4gIGhpZGVHcmlkbGluZXMoKVxuXG5jb25zdCBzaG93R3JpZGxpbmVzID0gbm9kZSA9PiB7XG4gIGlmIChncmlkbGluZXMpIHtcbiAgICBncmlkbGluZXMuc3R5bGUuZGlzcGxheSA9IG51bGxcbiAgICBncmlkbGluZXMudXBkYXRlID0gbm9kZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKVxuICB9XG4gIGVsc2Uge1xuICAgIGdyaWRsaW5lcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3Zpc2J1Zy1ncmlkbGluZXMnKVxuICAgIGdyaWRsaW5lcy5wb3NpdGlvbiA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KClcblxuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZ3JpZGxpbmVzKVxuICB9XG59XG5cbmNvbnN0IGhpZGVHcmlkbGluZXMgPSBub2RlID0+IHtcbiAgaWYgKCFncmlkbGluZXMpIHJldHVyblxuICBncmlkbGluZXMuc3R5bGUuZGlzcGxheSA9ICdub25lJ1xufVxuIiwiZXhwb3J0IGZ1bmN0aW9uIFNjcmVlbnNob3Qobm9kZSwgcGFnZSkge1xuICBhbGVydCgnQ29taW5nIFNvb24hJylcblxuICByZXR1cm4gKCkgPT4ge31cbn0iLCJpbXBvcnQgJCBmcm9tICdibGluZ2JsaW5nanMnXG5pbXBvcnQgaG90a2V5cyBmcm9tICdob3RrZXlzLWpzJ1xuaW1wb3J0IHsgbWV0YUtleSwgZ2V0U3R5bGUsIGdldFNpZGUsIHNob3dIaWRlU2VsZWN0ZWQgfSBmcm9tICcuLi91dGlsaXRpZXMvJ1xuXG5jb25zdCBrZXlfZXZlbnRzID0gJ3VwLGRvd24sbGVmdCxyaWdodCdcbiAgLnNwbGl0KCcsJylcbiAgLnJlZHVjZSgoZXZlbnRzLCBldmVudCkgPT5cbiAgICBgJHtldmVudHN9LCR7ZXZlbnR9LGFsdCske2V2ZW50fSxzaGlmdCske2V2ZW50fSxzaGlmdCthbHQrJHtldmVudH1gXG4gICwgJycpXG4gIC5zdWJzdHJpbmcoMSlcblxuY29uc3QgY29tbWFuZF9ldmVudHMgPSBgJHttZXRhS2V5fSt1cCwke21ldGFLZXl9K3NoaWZ0K3VwLCR7bWV0YUtleX0rZG93biwke21ldGFLZXl9K3NoaWZ0K2Rvd25gXG5cbmV4cG9ydCBmdW5jdGlvbiBQb3NpdGlvbigpIHtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgZWxlbWVudHM6IFtdXG4gIH1cblxuICBob3RrZXlzKGtleV9ldmVudHMsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgaWYgKGUuY2FuY2VsQnViYmxlKSByZXR1cm5cblxuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHBvc2l0aW9uRWxlbWVudChzdGF0ZS5lbGVtZW50cywgaGFuZGxlci5rZXkpXG4gIH0pXG5cbiAgY29uc3Qgb25Ob2Rlc1NlbGVjdGVkID0gZWxzID0+IHtcbiAgICBzdGF0ZS5lbGVtZW50cy5mb3JFYWNoKGVsID0+XG4gICAgICBlbC50ZWFyZG93bigpKVxuXG4gICAgc3RhdGUuZWxlbWVudHMgPSBlbHMubWFwKGVsID0+XG4gICAgICBkcmFnZ2FibGUoZWwpKVxuICB9XG5cbiAgY29uc3QgZGlzY29ubmVjdCA9ICgpID0+IHtcbiAgICBzdGF0ZS5lbGVtZW50cy5mb3JFYWNoKGVsID0+IGVsLnRlYXJkb3duKCkpXG4gICAgaG90a2V5cy51bmJpbmQoa2V5X2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZCgndXAsZG93bixsZWZ0LHJpZ2h0JylcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgb25Ob2Rlc1NlbGVjdGVkLFxuICAgIGRpc2Nvbm5lY3QsXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRyYWdnYWJsZShlbCkge1xuICB0aGlzLnN0YXRlID0ge1xuICAgIG1vdXNlOiB7XG4gICAgICBkb3duOiBmYWxzZSxcbiAgICAgIHg6IDAsXG4gICAgICB5OiAwLFxuICAgIH0sXG4gICAgZWxlbWVudDoge1xuICAgICAgeDogMCxcbiAgICAgIHk6IDAsXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgc2V0dXAgPSAoKSA9PiB7XG4gICAgZWwuc3R5bGUudHJhbnNpdGlvbiAgID0gJ25vbmUnXG4gICAgZWwuc3R5bGUuY3Vyc29yICAgICAgID0gJ21vdmUnXG5cbiAgICBlbC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBvbk1vdXNlRG93biwgdHJ1ZSlcbiAgICBlbC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZXVwJywgb25Nb3VzZVVwLCB0cnVlKVxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlbW92ZScsIG9uTW91c2VNb3ZlLCB0cnVlKVxuICB9XG5cbiAgY29uc3QgdGVhcmRvd24gPSAoKSA9PiB7XG4gICAgZWwuc3R5bGUudHJhbnNpdGlvbiAgID0gbnVsbFxuICAgIGVsLnN0eWxlLmN1cnNvciAgICAgICA9IG51bGxcblxuICAgIGVsLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIG9uTW91c2VEb3duLCB0cnVlKVxuICAgIGVsLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNldXAnLCBvbk1vdXNlVXAsIHRydWUpXG4gICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vtb3ZlJywgb25Nb3VzZU1vdmUsIHRydWUpXG4gIH1cblxuICBjb25zdCBvbk1vdXNlRG93biA9IGUgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuXG4gICAgY29uc3QgZWwgPSBlLnRhcmdldFxuXG4gICAgZWwuc3R5bGUucG9zaXRpb24gPSAncmVsYXRpdmUnXG4gICAgZWwuc3R5bGUud2lsbENoYW5nZSA9ICd0b3AsbGVmdCdcblxuICAgIGlmIChlbCBpbnN0YW5jZW9mIFNWR0VsZW1lbnQpIHtcbiAgICAgIGNvbnN0IHRyYW5zbGF0ZSA9IGVsLmdldEF0dHJpYnV0ZSgndHJhbnNmb3JtJylcblxuICAgICAgY29uc3QgWyB4LCB5IF0gPSB0cmFuc2xhdGVcbiAgICAgICAgPyBleHRyYWN0U1ZHVHJhbnNsYXRlKHRyYW5zbGF0ZSlcbiAgICAgICAgOiBbMCwwXVxuXG4gICAgICB0aGlzLnN0YXRlLmVsZW1lbnQueCAgPSB4XG4gICAgICB0aGlzLnN0YXRlLmVsZW1lbnQueSAgPSB5XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgdGhpcy5zdGF0ZS5lbGVtZW50LnggID0gcGFyc2VJbnQoZ2V0U3R5bGUoZWwsICdsZWZ0JykpXG4gICAgICB0aGlzLnN0YXRlLmVsZW1lbnQueSAgPSBwYXJzZUludChnZXRTdHlsZShlbCwgJ3RvcCcpKVxuICAgIH1cblxuICAgIHRoaXMuc3RhdGUubW91c2UueCAgICAgID0gZS5jbGllbnRYXG4gICAgdGhpcy5zdGF0ZS5tb3VzZS55ICAgICAgPSBlLmNsaWVudFlcbiAgICB0aGlzLnN0YXRlLm1vdXNlLmRvd24gICA9IHRydWVcbiAgfVxuXG4gIGNvbnN0IG9uTW91c2VVcCA9IGUgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcblxuICAgIHRoaXMuc3RhdGUubW91c2UuZG93biA9IGZhbHNlXG4gICAgZWwuc3R5bGUud2lsbENoYW5nZSA9IG51bGxcblxuICAgIGlmIChlbCBpbnN0YW5jZW9mIFNWR0VsZW1lbnQpIHtcbiAgICAgIGNvbnN0IHRyYW5zbGF0ZSA9IGVsLmdldEF0dHJpYnV0ZSgndHJhbnNmb3JtJylcblxuICAgICAgY29uc3QgWyB4LCB5IF0gPSB0cmFuc2xhdGVcbiAgICAgICAgPyBleHRyYWN0U1ZHVHJhbnNsYXRlKHRyYW5zbGF0ZSlcbiAgICAgICAgOiBbMCwwXVxuXG4gICAgICB0aGlzLnN0YXRlLmVsZW1lbnQueCAgICA9IHhcbiAgICAgIHRoaXMuc3RhdGUuZWxlbWVudC55ICAgID0geVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIHRoaXMuc3RhdGUuZWxlbWVudC54ICAgID0gcGFyc2VJbnQoZWwuc3R5bGUubGVmdCkgfHwgMFxuICAgICAgdGhpcy5zdGF0ZS5lbGVtZW50LnkgICAgPSBwYXJzZUludChlbC5zdHlsZS50b3ApIHx8IDBcbiAgICB9XG4gIH1cblxuICBjb25zdCBvbk1vdXNlTW92ZSA9IGUgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcblxuICAgIGlmICghdGhpcy5zdGF0ZS5tb3VzZS5kb3duKSByZXR1cm5cblxuICAgIGlmIChlbCBpbnN0YW5jZW9mIFNWR0VsZW1lbnQpIHtcbiAgICAgIGVsLnNldEF0dHJpYnV0ZSgndHJhbnNmb3JtJywgYHRyYW5zbGF0ZShcbiAgICAgICAgJHt0aGlzLnN0YXRlLmVsZW1lbnQueCArIGUuY2xpZW50WCAtIHRoaXMuc3RhdGUubW91c2UueH0sXG4gICAgICAgICR7dGhpcy5zdGF0ZS5lbGVtZW50LnkgKyBlLmNsaWVudFkgLSB0aGlzLnN0YXRlLm1vdXNlLnl9XG4gICAgICApYClcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICBlbC5zdHlsZS5sZWZ0ID0gdGhpcy5zdGF0ZS5lbGVtZW50LnggKyBlLmNsaWVudFggLSB0aGlzLnN0YXRlLm1vdXNlLnggKyAncHgnXG4gICAgICBlbC5zdHlsZS50b3AgID0gdGhpcy5zdGF0ZS5lbGVtZW50LnkgKyBlLmNsaWVudFkgLSB0aGlzLnN0YXRlLm1vdXNlLnkgKyAncHgnXG4gICAgfVxuICB9XG5cbiAgc2V0dXAoKVxuICBlbC50ZWFyZG93biA9IHRlYXJkb3duXG5cbiAgcmV0dXJuIGVsXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwb3NpdGlvbkVsZW1lbnQoZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbCA9PiBlbnN1cmVQb3NpdGlvbmFibGUoZWwpKVxuICAgIC5tYXAoZWwgPT4gc2hvd0hpZGVTZWxlY3RlZChlbCkpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgICBlbCxcbiAgICAgICAgLi4uZXh0cmFjdEN1cnJlbnRWYWx1ZUFuZFNpZGUoZWwsIGRpcmVjdGlvbiksXG4gICAgICAgIGFtb3VudDogICBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygnc2hpZnQnKSA/IDEwIDogMSxcbiAgICAgICAgbmVnYXRpdmU6IGRldGVybWluZU5lZ2F0aXZpdHkoZWwsIGRpcmVjdGlvbiksXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgcG9zaXRpb246IHBheWxvYWQubmVnYXRpdmVcbiAgICAgICAgICA/IHBheWxvYWQuY3VycmVudCArIHBheWxvYWQuYW1vdW50XG4gICAgICAgICAgOiBwYXlsb2FkLmN1cnJlbnQgLSBwYXlsb2FkLmFtb3VudFxuICAgICAgfSkpXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIHBvc2l0aW9ufSkgPT5cbiAgICAgIGVsIGluc3RhbmNlb2YgU1ZHRWxlbWVudFxuICAgICAgICA/IHNldFRyYW5zbGF0ZU9uU1ZHKGVsLCBkaXJlY3Rpb24sIHBvc2l0aW9uKVxuICAgICAgICA6IGVsLnN0eWxlW3N0eWxlXSA9IHBvc2l0aW9uICsgJ3B4Jylcbn1cblxuY29uc3QgZXh0cmFjdEN1cnJlbnRWYWx1ZUFuZFNpZGUgPSAoZWwsIGRpcmVjdGlvbikgPT4ge1xuICBsZXQgc3R5bGUsIGN1cnJlbnRcblxuICBpZiAoZWwgaW5zdGFuY2VvZiBTVkdFbGVtZW50KSB7XG4gICAgY29uc3QgdHJhbnNsYXRlID0gZWwuYXR0cigndHJhbnNmb3JtJylcblxuICAgIGNvbnN0IFsgeCwgeSBdID0gdHJhbnNsYXRlXG4gICAgICA/IGV4dHJhY3RTVkdUcmFuc2xhdGUodHJhbnNsYXRlKVxuICAgICAgOiBbMCwwXVxuXG4gICAgc3R5bGUgICA9ICd0cmFuc2Zvcm0nXG4gICAgY3VycmVudCA9IGRpcmVjdGlvbi5pbmNsdWRlcygnZG93bicpIHx8IGRpcmVjdGlvbi5pbmNsdWRlcygndXAnKVxuICAgICAgPyB5XG4gICAgICA6IHhcbiAgfVxuICBlbHNlIHtcbiAgICBjb25zdCBzaWRlID0gZ2V0U2lkZShkaXJlY3Rpb24pLnRvTG93ZXJDYXNlKClcbiAgICBzdHlsZSA9IChzaWRlID09PSAndG9wJyB8fCBzaWRlID09PSAnYm90dG9tJykgPyAndG9wJyA6ICdsZWZ0J1xuICAgIGN1cnJlbnQgPSBnZXRTdHlsZShlbCwgc3R5bGUpXG5cbiAgICBjdXJyZW50ID09PSAnYXV0bydcbiAgICAgID8gY3VycmVudCA9IDBcbiAgICAgIDogY3VycmVudCA9IHBhcnNlSW50KGN1cnJlbnQsIDEwKVxuICB9XG5cbiAgcmV0dXJuIHsgc3R5bGUsIGN1cnJlbnQgfVxufVxuXG5jb25zdCBleHRyYWN0U1ZHVHJhbnNsYXRlID0gdHJhbnNsYXRlID0+XG4gIHRyYW5zbGF0ZS5zdWJzdHJpbmcoXG4gICAgdHJhbnNsYXRlLmluZGV4T2YoJygnKSArIDEsXG4gICAgdHJhbnNsYXRlLmluZGV4T2YoJyknKVxuICApLnNwbGl0KCcsJylcbiAgLm1hcCh2YWwgPT4gcGFyc2VGbG9hdCh2YWwpKVxuXG5jb25zdCBzZXRUcmFuc2xhdGVPblNWRyA9IChlbCwgZGlyZWN0aW9uLCBwb3NpdGlvbikgPT4ge1xuICBjb25zdCB0cmFuc2Zvcm0gPSBlbC5hdHRyKCd0cmFuc2Zvcm0nKVxuICBjb25zdCBbIHgsIHkgXSA9IHRyYW5zZm9ybVxuICAgID8gZXh0cmFjdFNWR1RyYW5zbGF0ZSh0cmFuc2Zvcm0pXG4gICAgOiBbMCwwXVxuXG4gIGNvbnN0IHBvcyA9IGRpcmVjdGlvbi5pbmNsdWRlcygnZG93bicpIHx8IGRpcmVjdGlvbi5pbmNsdWRlcygndXAnKVxuICAgID8gYCR7eH0sJHtwb3NpdGlvbn1gXG4gICAgOiBgJHtwb3NpdGlvbn0sJHt5fWBcblxuICBlbC5hdHRyKCd0cmFuc2Zvcm0nLCBgdHJhbnNsYXRlKCR7cG9zfSlgKVxufVxuXG5jb25zdCBkZXRlcm1pbmVOZWdhdGl2aXR5ID0gKGVsLCBkaXJlY3Rpb24pID0+XG4gIGRpcmVjdGlvbi5pbmNsdWRlcygncmlnaHQnKSB8fCBkaXJlY3Rpb24uaW5jbHVkZXMoJ2Rvd24nKVxuXG5jb25zdCBlbnN1cmVQb3NpdGlvbmFibGUgPSBlbCA9PiB7XG4gIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxFbGVtZW50KVxuICAgIGVsLnN0eWxlLnBvc2l0aW9uID0gJ3JlbGF0aXZlJ1xuICByZXR1cm4gZWxcbn1cbiIsImltcG9ydCAqIGFzIEljb25zIGZyb20gJy4vdmlzLWJ1Zy5pY29ucydcbmltcG9ydCB7IG1ldGFLZXksIGFsdEtleSB9IGZyb20gJy4uLy4uL3V0aWxpdGllcy8nXG5cbmV4cG9ydCBjb25zdCBWaXNCdWdNb2RlbCA9IHtcbiAgZzoge1xuICAgIHRvb2w6ICAgICAgICAnZ3VpZGVzJyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMuZ3VpZGVzLFxuICAgIGxhYmVsOiAgICAgICAnR3VpZGVzJyxcbiAgICBkZXNjcmlwdGlvbjogJ1ZlcmlmeSBhbGlnbm1lbnQgJiBjaGVjayB5b3VyIGdyaWQnLFxuICAgIGluc3RydWN0aW9uOiBgPGRpdiB0YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5NZWFzdXJlOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4ke2FsdEtleX0gKyBob3Zlcjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5gLFxuICB9LFxuICBpOiB7XG4gICAgdG9vbDogICAgICAgICdpbnNwZWN0b3InLFxuICAgIGljb246ICAgICAgICBJY29ucy5pbnNwZWN0b3IsXG4gICAgbGFiZWw6ICAgICAgICdJbnNwZWN0JyxcbiAgICBkZXNjcmlwdGlvbjogJ1BlZWsgaW50byBjb21tb24gJiBjdXJyZW50IHN0eWxlcyBvZiBhbiBlbGVtZW50JyxcbiAgICBpbnN0cnVjdGlvbjogYDxkaXYgdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+UGluIGl0OjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4ke2FsdEtleX0gKyBjbGljazwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5gLFxuICB9LFxuICB4OiB7XG4gICAgdG9vbDogICAgICAgICdhY2Nlc3NpYmlsaXR5JyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMuYWNjZXNzaWJpbGl0eSxcbiAgICBsYWJlbDogICAgICAgJ0FjY2Vzc2liaWxpdHknLFxuICAgIGRlc2NyaXB0aW9uOiAnUGVlayBpbnRvIEExMXkgYXR0cmlidXRlcyAmIGNvbXBsaWFuY2Ugc3RhdHVzJyxcbiAgICBpbnN0cnVjdGlvbjogYDxkaXYgdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+UGluIGl0OjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4ke2FsdEtleX0gKyBjbGljazwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5gLFxuICB9LFxuICB2OiB7XG4gICAgdG9vbDogICAgICAgICdtb3ZlJyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMubW92ZSxcbiAgICBsYWJlbDogICAgICAgJ01vdmUnLFxuICAgIGRlc2NyaXB0aW9uOiAnUHVzaCBlbGVtZW50cyBpbiAmIG91dCBvZiB0aGVpciBjb250YWluZXIsIG9yIHNodWZmbGUgdGhlbSB3aXRoaW4gaXQnLFxuICAgIGluc3RydWN0aW9uOiBgPGRpdiB0YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5MYXRlcmFsOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7il4Ag4pa2PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5PdXQgYW5kIGFib3ZlOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7ilrI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPkRvd24gYW5kIGluOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7ilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+YCxcbiAgfSxcbiAgLy8gcjoge1xuICAvLyAgIHRvb2w6ICAgICAgICAncmVzaXplJyxcbiAgLy8gICBpY29uOiAgICAgICAgSWNvbnMucmVzaXplLFxuICAvLyAgIGxhYmVsOiAgICAgICAnUmVzaXplJyxcbiAgLy8gICBkZXNjcmlwdGlvbjogJydcbiAgLy8gfSxcbiAgbToge1xuICAgIHRvb2w6ICAgICAgICAnbWFyZ2luJyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMubWFyZ2luLFxuICAgIGxhYmVsOiAgICAgICAnTWFyZ2luJyxcbiAgICBkZXNjcmlwdGlvbjogJ0FkZCBvciBzdWJ0cmFjdCBvdXRlciBzcGFjZSBmcm9tIGFueSBvciBhbGwgc2lkZXMgb2YgdGhlIHNlbGVjdGVkIGVsZW1lbnQocyknLFxuICAgIGluc3RydWN0aW9uOiBgPGRpdiB0YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj4rIE1hcmdpbjo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4peAIOKWtiDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj4tIE1hcmdpbjo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+JHthbHRLZXl9ICsg4peAIOKWtiDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5BbGwgU2lkZXM6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiR7bWV0YUtleX0gKyAg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5gLFxuICB9LFxuICBwOiB7XG4gICAgdG9vbDogICAgICAgICdwYWRkaW5nJyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMucGFkZGluZyxcbiAgICBsYWJlbDogICAgICAgJ1BhZGRpbmcnLFxuICAgIGRlc2NyaXB0aW9uOiBgQWRkIG9yIHN1YnRyYWN0IGlubmVyIHNwYWNlIGZyb20gYW55IG9yIGFsbCBzaWRlcyBvZiB0aGUgc2VsZWN0ZWQgZWxlbWVudChzKWAsXG4gICAgaW5zdHJ1Y3Rpb246IGA8ZGl2IHRhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPisgUGFkZGluZzo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4peAIOKWtiDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj4tIFBhZGRpbmc6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiR7YWx0S2V5fSArIOKXgCDilrYg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+QWxsIFNpZGVzOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4ke21ldGFLZXl9ICsgIOKWsiDilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+YFxuICB9LFxuICAvLyBiOiB7XG4gIC8vICAgdG9vbDogICAgICAgICdib3JkZXInLFxuICAvLyAgIGljb246ICAgICAgICBJY29ucy5ib3JkZXIsXG4gIC8vICAgbGFiZWw6ICAgICAgICdCb3JkZXInLFxuICAvLyAgIGRlc2NyaXB0aW9uOiAnJ1xuICAvLyB9LFxuICBhOiB7XG4gICAgdG9vbDogICAgICAgICdhbGlnbicsXG4gICAgaWNvbjogICAgICAgIEljb25zLmFsaWduLFxuICAgIGxhYmVsOiAgICAgICAnRmxleGJveCBBbGlnbicsXG4gICAgZGVzY3JpcHRpb246IGBDcmVhdGUgb3IgbW9kaWZ5IGZsZXhib3ggZGlyZWN0aW9uLCBkaXN0cmlidXRpb24gJiBhbGlnbm1lbnRgLFxuICAgIGluc3RydWN0aW9uOiBgPGRpdiB0YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5BbGlnbm1lbnQ6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKXgCDilrYg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+RGlzdHJpYnV0aW9uOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TaGlmdCArIOKXgCDilrY8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPkRpcmVjdGlvbjo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+JHttZXRhS2V5fSArICDil4Ag4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PmAsXG4gIH0sXG4gIGg6IHtcbiAgICB0b29sOiAgICAgICAgJ2h1ZXNoaWZ0JyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMuaHVlc2hpZnQsXG4gICAgbGFiZWw6ICAgICAgICdIdWUgU2hpZnQnLFxuICAgIGRlc2NyaXB0aW9uOiBgQ2hhbmdlIGZvcmVncm91bmQvYmFja2dyb3VuZCBodWUsIGJyaWdodG5lc3MsIHNhdHVyYXRpb24gJiBvcGFjaXR5YCxcbiAgICBpbnN0cnVjdGlvbjogYDxkaXYgdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+U2F0dXJhdGlvbjo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4peAIOKWtjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+QnJpZ2h0bmVzczo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+SHVlOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4ke21ldGFLZXl9ICsgIOKWsiDilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPk9wYWNpdHk6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiR7bWV0YUtleX0gKyAg4peAIOKWtjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5gLFxuICB9LFxuICBkOiB7XG4gICAgdG9vbDogICAgICAgICdib3hzaGFkb3cnLFxuICAgIGljb246ICAgICAgICBJY29ucy5ib3hzaGFkb3csXG4gICAgbGFiZWw6ICAgICAgICdTaGFkb3cnLFxuICAgIGRlc2NyaXB0aW9uOiBgQ3JlYXRlICYgYWRqdXN0IHBvc2l0aW9uLCBibHVyICYgb3BhY2l0eSBvZiBhIGJveCBzaGFkb3dgLFxuICAgIGluc3RydWN0aW9uOiBgPGRpdiB0YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5YL1kgUG9zaXRpb246PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKXgCDilrYg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+Qmx1cjo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2hpZnQgKyDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5TcHJlYWQ6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlNoaWZ0ICsg4peAIOKWtjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+T3BhY2l0eTo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+JHttZXRhS2V5fSArIOKXgCDilrY8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+YCxcbiAgfSxcbiAgLy8gdDoge1xuICAvLyAgIHRvb2w6ICAgICAgICAndHJhbnNmb3JtJyxcbiAgLy8gICBpY29uOiAgICAgICAgSWNvbnMudHJhbnNmb3JtLFxuICAvLyAgIGxhYmVsOiAgICAgICAnM0QgVHJhbnNmb3JtJyxcbiAgLy8gICBkZXNjcmlwdGlvbjogJydcbiAgLy8gfSxcbiAgbDoge1xuICAgIHRvb2w6ICAgICAgICAncG9zaXRpb24nLFxuICAgIGljb246ICAgICAgICBJY29ucy5wb3NpdGlvbixcbiAgICBsYWJlbDogICAgICAgJ1Bvc2l0aW9uJyxcbiAgICBkZXNjcmlwdGlvbjogJ01vdmUgc3ZnICh4LHkpIGFuZCBlbGVtZW50cyAodG9wLGxlZnQsYm90dG9tLHJpZ2h0KScsXG4gICAgaW5zdHJ1Y3Rpb246IGA8ZGl2IHRhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPk51ZGdlOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7il4Ag4pa2IOKWsiDilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPk1vdmU6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkNsaWNrICYgZHJhZzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5gLFxuICB9LFxuICBmOiB7XG4gICAgdG9vbDogICAgICAgICdmb250JyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMuZm9udCxcbiAgICBsYWJlbDogICAgICAgJ0ZvbnQgU3R5bGVzJyxcbiAgICBkZXNjcmlwdGlvbjogJ0NoYW5nZSBzaXplLCBhbGlnbm1lbnQsIGxlYWRpbmcsIGxldHRlci1zcGFjaW5nLCAmIHdlaWdodCcsXG4gICAgaW5zdHJ1Y3Rpb246IGA8ZGl2IHRhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPlNpemU6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKWsiDilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPkFsaWdubWVudDo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4peAIOKWtjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+TGVhZGluZzo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2hpZnQgKyDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5MZXR0ZXItc3BhY2luZzo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2hpZnQgKyDil4Ag4pa2PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5XZWlnaHQ6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiR7bWV0YUtleX0gKyDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PmAsXG4gIH0sXG4gIGU6IHtcbiAgICB0b29sOiAgICAgICAgJ3RleHQnLFxuICAgIGljb246ICAgICAgICBJY29ucy50ZXh0LFxuICAgIGxhYmVsOiAgICAgICAnRWRpdCBUZXh0JyxcbiAgICBkZXNjcmlwdGlvbjogJ0NoYW5nZSBhbnkgdGV4dCBvbiB0aGUgcGFnZSB3aXRoIGEgPGI+ZG91YmxlIGNsaWNrPC9iPicsXG4gICAgaW5zdHJ1Y3Rpb246ICcnLFxuICB9LFxuICAvLyBjOiB7XG4gIC8vICAgdG9vbDogICAgICAgICdzY3JlZW5zaG90JyxcbiAgLy8gICBpY29uOiAgICAgICAgSWNvbnMuY2FtZXJhLFxuICAvLyAgIGxhYmVsOiAgICAgICAnU2NyZWVuc2hvdCcsXG4gIC8vICAgZGVzY3JpcHRpb246ICdTY3JlZW5zaG90IHNlbGVjdGVkIGVsZW1lbnRzIG9yIHRoZSBlbnRpcmUgcGFnZSdcbiAgLy8gfSxcbiAgczoge1xuICAgIHRvb2w6ICAgICAgICAnc2VhcmNoJyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMuc2VhcmNoLFxuICAgIGxhYmVsOiAgICAgICAnU2VhcmNoJyxcbiAgICBkZXNjcmlwdGlvbjogJ1NlbGVjdCBlbGVtZW50cyBwcm9ncmFtYXRpY2FsbHkgYnkgc2VhcmNoaW5nIGZvciB0aGVtIG9yIHVzZSBidWlsdCBpbiBwbHVnaW5zIHdpdGggc3BlY2lhbCBjb21tYW5kcycsXG4gICAgaW5zdHJ1Y3Rpb246ICcnLFxuICB9LFxufVxuIiwiaW1wb3J0ICQgICAgICAgICAgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IGhvdGtleXMgICAgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCBzdHlsZXMgICAgIGZyb20gJy4vdmlzLWJ1Zy5lbGVtZW50LmNzcydcblxuaW1wb3J0IHtcbiAgSGFuZGxlcywgTGFiZWwsIE92ZXJsYXksIEdyaWRsaW5lcyxcbiAgSG90a2V5cywgTWV0YXRpcCwgQWxseSwgRGlzdGFuY2UsXG59IGZyb20gJy4uLydcblxuaW1wb3J0IHtcbiAgU2VsZWN0YWJsZSwgTW92ZWFibGUsIFBhZGRpbmcsIE1hcmdpbiwgRWRpdFRleHQsIEZvbnQsXG4gIEZsZXgsIFNlYXJjaCwgQ29sb3JQaWNrZXIsIEJveFNoYWRvdywgSHVlU2hpZnQsIE1ldGFUaXAsXG4gIEd1aWRlcywgU2NyZWVuc2hvdCwgUG9zaXRpb24sIEFjY2Vzc2liaWxpdHlcbn0gZnJvbSAnLi4vLi4vZmVhdHVyZXMvJ1xuXG5pbXBvcnQgeyBWaXNCdWdNb2RlbCB9ICAgICAgICAgICAgICBmcm9tICcuL21vZGVsJ1xuaW1wb3J0ICogYXMgSWNvbnMgICAgICAgICAgICAgICAgIGZyb20gJy4vdmlzLWJ1Zy5pY29ucydcbmltcG9ydCB7IHByb3ZpZGVTZWxlY3RvckVuZ2luZSB9ICBmcm9tICcuLi8uLi9mZWF0dXJlcy9zZWFyY2gnXG5pbXBvcnQgeyBtZXRhS2V5IH0gICAgICAgICAgICAgICAgZnJvbSAnLi4vLi4vdXRpbGl0aWVzLydcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgVmlzQnVnIGV4dGVuZHMgSFRNTEVsZW1lbnQge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLnRvb2xiYXJfbW9kZWwgID0gVmlzQnVnTW9kZWxcbiAgICB0aGlzLl90dXRzQmFzZVVSTCAgID0gJ3R1dHMnIC8vIGNhbiBiZSBzZXQgYnkgY29udGVudCBzY3JpcHRcbiAgICB0aGlzLiRzaGFkb3cgICAgICAgID0gdGhpcy5hdHRhY2hTaGFkb3coe21vZGU6ICdjbG9zZWQnfSlcbiAgfVxuXG4gIGNvbm5lY3RlZENhbGxiYWNrKCkge1xuICAgIGlmICghdGhpcy4kc2hhZG93LmlubmVySFRNTClcbiAgICAgIHRoaXMuc2V0dXAoKVxuXG4gICAgdGhpcy5zZWxlY3RvckVuZ2luZSA9IFNlbGVjdGFibGUoKVxuICAgIHRoaXMuY29sb3JQaWNrZXIgICAgPSBDb2xvclBpY2tlcih0aGlzLiRzaGFkb3csIHRoaXMuc2VsZWN0b3JFbmdpbmUpXG4gICAgcHJvdmlkZVNlbGVjdG9yRW5naW5lKHRoaXMuc2VsZWN0b3JFbmdpbmUpXG4gIH1cblxuICBkaXNjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSgpXG4gICAgdGhpcy5zZWxlY3RvckVuZ2luZS5kaXNjb25uZWN0KClcbiAgICBob3RrZXlzLnVuYmluZChcbiAgICAgIE9iamVjdC5rZXlzKHRoaXMudG9vbGJhcl9tb2RlbCkucmVkdWNlKChldmVudHMsIGtleSkgPT5cbiAgICAgICAgZXZlbnRzICs9ICcsJyArIGtleSwgJycpKVxuICAgIGhvdGtleXMudW5iaW5kKGAke21ldGFLZXl9Ky9gKVxuICB9XG5cbiAgc2V0dXAoKSB7XG4gICAgdGhpcy4kc2hhZG93LmlubmVySFRNTCA9IHRoaXMucmVuZGVyKClcblxuICAgICQoJ2xpW2RhdGEtdG9vbF0nLCB0aGlzLiRzaGFkb3cpLm9uKCdjbGljaycsIGUgPT5cbiAgICAgIHRoaXMudG9vbFNlbGVjdGVkKGUuY3VycmVudFRhcmdldCkgJiYgZS5zdG9wUHJvcGFnYXRpb24oKSlcblxuICAgIE9iamVjdC5lbnRyaWVzKHRoaXMudG9vbGJhcl9tb2RlbCkuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PlxuICAgICAgaG90a2V5cyhrZXksIGUgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgdGhpcy50b29sU2VsZWN0ZWQoXG4gICAgICAgICAgJChgW2RhdGEtdG9vbD1cIiR7dmFsdWUudG9vbH1cIl1gLCB0aGlzLiRzaGFkb3cpWzBdXG4gICAgICAgIClcbiAgICAgIH0pXG4gICAgKVxuXG4gICAgaG90a2V5cyhgJHttZXRhS2V5fSsvLCR7bWV0YUtleX0rLmAsIGUgPT5cbiAgICAgIHRoaXMuJHNoYWRvdy5ob3N0LnN0eWxlLmRpc3BsYXkgPVxuICAgICAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID09PSAnbm9uZSdcbiAgICAgICAgICA/ICdibG9jaydcbiAgICAgICAgICA6ICdub25lJylcblxuICAgIHRoaXMudG9vbFNlbGVjdGVkKCQoJ1tkYXRhLXRvb2w9XCJndWlkZXNcIl0nLCB0aGlzLiRzaGFkb3cpWzBdKVxuICB9XG5cbiAgdG9vbFNlbGVjdGVkKGVsKSB7XG4gICAgaWYgKHR5cGVvZiBlbCA9PT0gJ3N0cmluZycpXG4gICAgICBlbCA9ICQoYFtkYXRhLXRvb2w9XCIke2VsfVwiXWAsIHRoaXMuJHNoYWRvdylbMF1cblxuICAgIGlmICh0aGlzLmFjdGl2ZV90b29sICYmIHRoaXMuYWN0aXZlX3Rvb2wuZGF0YXNldC50b29sID09PSBlbC5kYXRhc2V0LnRvb2wpIHJldHVyblxuXG4gICAgaWYgKHRoaXMuYWN0aXZlX3Rvb2wpIHtcbiAgICAgIHRoaXMuYWN0aXZlX3Rvb2wuYXR0cignZGF0YS1hY3RpdmUnLCBudWxsKVxuICAgICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUoKVxuICAgIH1cblxuICAgIGVsLmF0dHIoJ2RhdGEtYWN0aXZlJywgdHJ1ZSlcbiAgICB0aGlzLmFjdGl2ZV90b29sID0gZWxcbiAgICB0aGlzW2VsLmRhdGFzZXQudG9vbF0oKVxuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiBgXG4gICAgICAke3RoaXMuc3R5bGVzKCl9XG4gICAgICA8dmlzYnVnLWhvdGtleXM+PC92aXNidWctaG90a2V5cz5cbiAgICAgIDxvbD5cbiAgICAgICAgJHtPYmplY3QuZW50cmllcyh0aGlzLnRvb2xiYXJfbW9kZWwpLnJlZHVjZSgobGlzdCwgW2tleSwgdG9vbF0pID0+IGBcbiAgICAgICAgICAke2xpc3R9XG4gICAgICAgICAgPGxpIGFyaWEtbGFiZWw9XCIke3Rvb2wubGFiZWx9IFRvb2xcIiBhcmlhLWRlc2NyaXB0aW9uPVwiJHt0b29sLmRlc2NyaXB0aW9ufVwiIGFyaWEtaG90a2V5PVwiJHtrZXl9XCIgZGF0YS10b29sPVwiJHt0b29sLnRvb2x9XCIgZGF0YS1hY3RpdmU9XCIke2tleSA9PSAnZyd9XCI+XG4gICAgICAgICAgICAke3Rvb2wuaWNvbn1cbiAgICAgICAgICAgICR7dGhpcy5kZW1vVGlwKHtrZXksIC4uLnRvb2x9KX1cbiAgICAgICAgICA8L2xpPlxuICAgICAgICBgLCcnKX1cbiAgICAgIDwvb2w+XG4gICAgICA8b2wgY29sb3JzPlxuICAgICAgICA8bGkgc3R5bGU9XCJkaXNwbGF5OiBub25lO1wiIGNsYXNzPVwiY29sb3JcIiBpZD1cImZvcmVncm91bmRcIiBhcmlhLWxhYmVsPVwiVGV4dFwiIGFyaWEtZGVzY3JpcHRpb249XCJDaGFuZ2UgdGhlIHRleHQgY29sb3JcIj5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cImNvbG9yXCIgdmFsdWU9XCJcIj5cbiAgICAgICAgICAke0ljb25zLmNvbG9yX3RleHR9XG4gICAgICAgIDwvbGk+XG4gICAgICAgIDxsaSBzdHlsZT1cImRpc3BsYXk6IG5vbmU7XCIgY2xhc3M9XCJjb2xvclwiIGlkPVwiYmFja2dyb3VuZFwiIGFyaWEtbGFiZWw9XCJCYWNrZ3JvdW5kIG9yIEZpbGxcIiBhcmlhLWRlc2NyaXB0aW9uPVwiQ2hhbmdlIHRoZSBiYWNrZ3JvdW5kIGNvbG9yIG9yIGZpbGwgb2Ygc3ZnXCI+XG4gICAgICAgICAgPGlucHV0IHR5cGU9XCJjb2xvclwiIHZhbHVlPVwiXCI+XG4gICAgICAgICAgJHtJY29ucy5jb2xvcl9iYWNrZ3JvdW5kfVxuICAgICAgICA8L2xpPlxuICAgICAgICA8bGkgc3R5bGU9XCJkaXNwbGF5OiBub25lO1wiIGNsYXNzPVwiY29sb3JcIiBpZD1cImJvcmRlclwiIGFyaWEtbGFiZWw9XCJCb3JkZXIgb3IgU3Ryb2tlXCIgYXJpYS1kZXNjcmlwdGlvbj1cIkNoYW5nZSB0aGUgYm9yZGVyIGNvbG9yIG9yIHN0cm9rZSBvZiBzdmdcIj5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cImNvbG9yXCIgdmFsdWU9XCJcIj5cbiAgICAgICAgICAke0ljb25zLmNvbG9yX2JvcmRlcn1cbiAgICAgICAgPC9saT5cbiAgICAgIDwvb2w+XG4gICAgYFxuICB9XG5cbiAgc3R5bGVzKCkge1xuICAgIHJldHVybiBgXG4gICAgICA8c3R5bGU+XG4gICAgICAgICR7c3R5bGVzfVxuICAgICAgPC9zdHlsZT5cbiAgICBgXG4gIH1cblxuICBkZW1vVGlwKHtrZXksIHRvb2wsIGxhYmVsLCBkZXNjcmlwdGlvbiwgaW5zdHJ1Y3Rpb259KSB7XG4gICAgcmV0dXJuIGBcbiAgICAgIDxhc2lkZSAke3Rvb2x9PlxuICAgICAgICA8ZmlndXJlPlxuICAgICAgICAgIDxpbWcgc3JjPVwiJHt0aGlzLl90dXRzQmFzZVVSTH0vJHt0b29sfS5naWZcIiBhbHQ9XCIke2Rlc2NyaXB0aW9ufVwiIC8+XG4gICAgICAgICAgPGZpZ2NhcHRpb24+XG4gICAgICAgICAgICA8aDI+XG4gICAgICAgICAgICAgICR7bGFiZWx9XG4gICAgICAgICAgICAgIDxzcGFuIGhvdGtleT4ke2tleX08L3NwYW4+XG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPHA+JHtkZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgICAke2luc3RydWN0aW9ufVxuICAgICAgICAgIDwvZmlnY2FwdGlvbj5cbiAgICAgICAgPC9maWd1cmU+XG4gICAgICA8L2FzaWRlPlxuICAgIGBcbiAgfVxuXG4gIG1vdmUoKSB7XG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSBNb3ZlYWJsZSh0aGlzLnNlbGVjdG9yRW5naW5lKVxuICB9XG5cbiAgbWFyZ2luKCkge1xuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gTWFyZ2luKHRoaXMuc2VsZWN0b3JFbmdpbmUpXG4gIH1cblxuICBwYWRkaW5nKCkge1xuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gUGFkZGluZyh0aGlzLnNlbGVjdG9yRW5naW5lKVxuICB9XG5cbiAgZm9udCgpIHtcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9IEZvbnQodGhpcy5zZWxlY3RvckVuZ2luZSlcbiAgfVxuXG4gIHRleHQoKSB7XG4gICAgdGhpcy5zZWxlY3RvckVuZ2luZS5vblNlbGVjdGVkVXBkYXRlKEVkaXRUZXh0KVxuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gKCkgPT5cbiAgICAgIHRoaXMuc2VsZWN0b3JFbmdpbmUucmVtb3ZlU2VsZWN0ZWRDYWxsYmFjayhFZGl0VGV4dClcbiAgfVxuXG4gIGFsaWduKCkge1xuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gRmxleCh0aGlzLnNlbGVjdG9yRW5naW5lKVxuICB9XG5cbiAgc2VhcmNoKCkge1xuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gU2VhcmNoKCQoJ1tkYXRhLXRvb2w9XCJzZWFyY2hcIl0nLCB0aGlzLiRzaGFkb3cpKVxuICB9XG5cbiAgYm94c2hhZG93KCkge1xuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gQm94U2hhZG93KHRoaXMuc2VsZWN0b3JFbmdpbmUpXG4gIH1cblxuICBodWVzaGlmdCgpIHtcbiAgICBsZXQgZmVhdHVyZSA9IEh1ZVNoaWZ0KHRoaXMuY29sb3JQaWNrZXIpXG4gICAgdGhpcy5zZWxlY3RvckVuZ2luZS5vblNlbGVjdGVkVXBkYXRlKGZlYXR1cmUub25Ob2Rlc1NlbGVjdGVkKVxuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gKCkgPT4ge1xuICAgICAgdGhpcy5zZWxlY3RvckVuZ2luZS5yZW1vdmVTZWxlY3RlZENhbGxiYWNrKGZlYXR1cmUub25Ob2Rlc1NlbGVjdGVkKVxuICAgICAgZmVhdHVyZS5kaXNjb25uZWN0KClcbiAgICB9XG4gIH1cblxuICBpbnNwZWN0b3IoKSB7XG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSBNZXRhVGlwKHRoaXMuc2VsZWN0b3JFbmdpbmUpXG4gIH1cblxuICBhY2Nlc3NpYmlsaXR5KCkge1xuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gQWNjZXNzaWJpbGl0eSgpXG4gIH1cblxuICBndWlkZXMoKSB7XG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSBHdWlkZXMoKVxuICB9XG5cbiAgc2NyZWVuc2hvdCgpIHtcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9IFNjcmVlbnNob3QoKVxuICB9XG5cbiAgcG9zaXRpb24oKSB7XG4gICAgbGV0IGZlYXR1cmUgPSBQb3NpdGlvbigpXG4gICAgdGhpcy5zZWxlY3RvckVuZ2luZS5vblNlbGVjdGVkVXBkYXRlKGZlYXR1cmUub25Ob2Rlc1NlbGVjdGVkKVxuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gKCkgPT4ge1xuICAgICAgdGhpcy5zZWxlY3RvckVuZ2luZS5yZW1vdmVTZWxlY3RlZENhbGxiYWNrKGZlYXR1cmUub25Ob2Rlc1NlbGVjdGVkKVxuICAgICAgZmVhdHVyZS5kaXNjb25uZWN0KClcbiAgICB9XG4gIH1cblxuICBnZXQgYWN0aXZlVG9vbCgpIHtcbiAgICByZXR1cm4gdGhpcy5hY3RpdmVfdG9vbC5kYXRhc2V0LnRvb2xcbiAgfVxuXG4gIHNldCB0dXRzQmFzZVVSTCh1cmwpIHtcbiAgICB0aGlzLl90dXRzQmFzZVVSTCA9IHVybFxuICAgIHRoaXMuc2V0dXAoKVxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgndmlzLWJ1ZycsIFZpc0J1ZylcbiIsImltcG9ydCBWaXNCdWcgZnJvbSAnLi9jb21wb25lbnRzL3Zpcy1idWcvdmlzLWJ1Zy5lbGVtZW50J1xuaW1wb3J0IHsgbWV0YUtleSB9IGZyb20gJy4vdXRpbGl0aWVzJ1xuXG5pZiAoJ29udG91Y2hzdGFydCcgaW4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KVxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbW9iaWxlLWluZm8nKS5zdHlsZS5kaXNwbGF5ID0gJydcblxuaWYgKG1ldGFLZXkgPT09ICdjdHJsJylcbiAgWy4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ2tiZCcpXVxuICAgIC5mb3JFYWNoKG5vZGUgPT4ge1xuICAgICAgbm9kZS50ZXh0Q29udGVudCA9IG5vZGUudGV4dENvbnRlbnQucmVwbGFjZSgnY21kJywnY3RybCcpXG4gICAgICBub2RlLnRleHRDb250ZW50ID0gbm9kZS50ZXh0Q29udGVudC5yZXBsYWNlKCdvcHQnLCdhbHQnKVxuICAgIH0pXG4iXSwibmFtZXMiOlsic3R5bGVzIiwiaG90a2V5cyIsImljb24iLCJrZXlfZXZlbnRzIiwiY29tbWFuZHMiLCJibGFua19wYWdlX2NvbW1hbmRzIiwiYmFycmVsX3JvbGxfY29tbWFuZHMiLCJwZXN0aWNpZGVfY29tbWFuZHMiLCJjb25zdHJ1Y3RfY29tbWFuZHMiLCJjb25zdHJ1Y3RfZGVidWdfY29tbWFuZHMiLCJ3aXJlZnJhbWVfY29tbWFuZHMiLCJza2VsZXRvbl9jb21tYW5kcyIsInRhZ19kZWJ1Z2dlcl9jb21tYW5kcyIsInJldmVuZ2VfY29tbWFuZHMiLCJzZWFyY2giLCJzdGF0ZSIsIm1vdXNlTW92ZSIsInRvZ2dsZVBpbm5lZCIsInJlbW92ZUFsbCIsInJlc3RvcmVQaW5uZWRUaXBzIiwiaGlkZUFsbCIsIndpcGUiLCJjbGVhckFjdGl2ZSIsInRvZ2dsZVRhcmdldEN1cnNvciIsInNob3dUaXAiLCJyZW5kZXIiLCJwb3NpdGlvblRpcCIsIm9ic2VydmUiLCJtb3VzZV9xdWFkcmFudCIsInRpcF9wb3NpdGlvbiIsInVub2JzZXJ2ZSIsImhhbmRsZUJsdXIiLCJyZW1vdmVBbGxBY2Nlc3NpYmlsaXR5VGlwcyIsInNob3dBY2Nlc3NpYmlsaXR5VGlwIiwicmVtb3ZlQWxsTWV0YVRpcHMiLCJzaG93TWV0YVRpcCIsImNvbW1hbmRfZXZlbnRzIiwic3RvcEJ1YmJsaW5nIiwiaF9hbGlnbk9wdGlvbnMiLCJ2X2FsaWduT3B0aW9ucyIsIkljb25zLmd1aWRlcyIsIkljb25zLmluc3BlY3RvciIsIkljb25zLmFjY2Vzc2liaWxpdHkiLCJJY29ucy5tb3ZlIiwiSWNvbnMubWFyZ2luIiwiSWNvbnMucGFkZGluZyIsIkljb25zLmFsaWduIiwiSWNvbnMuaHVlc2hpZnQiLCJJY29ucy5ib3hzaGFkb3ciLCJJY29ucy5wb3NpdGlvbiIsIkljb25zLmZvbnQiLCJJY29ucy50ZXh0IiwiSWNvbnMuc2VhcmNoIiwiSWNvbnMuY29sb3JfdGV4dCIsIkljb25zLmNvbG9yX2JhY2tncm91bmQiLCJJY29ucy5jb2xvcl9ib3JkZXIiXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sS0FBSyxHQUFHO0VBQ1osRUFBRSxFQUFFLFNBQVMsS0FBSyxFQUFFLEVBQUUsRUFBRTtJQUN0QixLQUFLO09BQ0YsS0FBSyxDQUFDLEdBQUcsQ0FBQztPQUNWLE9BQU8sQ0FBQyxJQUFJO1FBQ1gsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsRUFBQztJQUNwQyxPQUFPLElBQUk7R0FDWjtFQUNELEdBQUcsRUFBRSxTQUFTLEtBQUssRUFBRSxFQUFFLEVBQUU7SUFDdkIsS0FBSztPQUNGLEtBQUssQ0FBQyxHQUFHLENBQUM7T0FDVixPQUFPLENBQUMsSUFBSTtRQUNYLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLEVBQUM7SUFDdkMsT0FBTyxJQUFJO0dBQ1o7RUFDRCxJQUFJLEVBQUUsU0FBUyxJQUFJLEVBQUUsR0FBRyxFQUFFO0lBQ3hCLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDOztJQUVyRCxHQUFHLElBQUksSUFBSTtRQUNQLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDO1FBQzFCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLEdBQUcsSUFBSSxFQUFFLEVBQUM7O0lBRXRDLE9BQU8sSUFBSTtHQUNaO0VBQ0Y7O0FBRUQsQUFBZSxTQUFTLENBQUMsQ0FBQyxLQUFLLEVBQUUsUUFBUSxHQUFHLFFBQVEsRUFBRTtFQUNwRCxJQUFJLE1BQU0sR0FBRyxLQUFLLFlBQVksUUFBUSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO01BQzFELEtBQUs7TUFDTCxLQUFLLFlBQVksV0FBVyxJQUFJLEtBQUssWUFBWSxVQUFVO1FBQ3pELENBQUMsS0FBSyxDQUFDO1FBQ1AsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEtBQUssRUFBQzs7RUFFdEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsTUFBTSxHQUFHLEdBQUU7O0VBRS9CLE9BQU8sTUFBTSxDQUFDLE1BQU07SUFDbEIsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDakQ7TUFDRSxFQUFFLEVBQUUsU0FBUyxLQUFLLEVBQUUsRUFBRSxFQUFFO1FBQ3RCLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxFQUFDO1FBQ3RDLE9BQU8sSUFBSTtPQUNaO01BQ0QsR0FBRyxFQUFFLFNBQVMsS0FBSyxFQUFFLEVBQUUsRUFBRTtRQUN2QixJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsRUFBQztRQUN2QyxPQUFPLElBQUk7T0FDWjtNQUNELElBQUksRUFBRSxTQUFTLEtBQUssRUFBRSxHQUFHLEVBQUU7UUFDekIsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLElBQUksR0FBRyxLQUFLLFNBQVM7VUFDaEQsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQzs7YUFFdkIsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRO1VBQ2hDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRztZQUNkLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO2VBQ2xCLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztnQkFDbEIsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBQzs7YUFFdkIsSUFBSSxPQUFPLEtBQUssSUFBSSxRQUFRLEtBQUssR0FBRyxJQUFJLEdBQUcsSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsQ0FBQztVQUNwRSxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsRUFBQzs7UUFFM0MsT0FBTyxJQUFJO09BQ1o7S0FDRjtHQUNGOzs7QUM5REg7Ozs7Ozs7Ozs7QUFVQSxJQUFJLElBQUksR0FBRyxPQUFPLFNBQVMsS0FBSyxXQUFXLEdBQUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQzs7O0FBRy9HLFNBQVMsUUFBUSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFO0VBQ3ZDLElBQUksTUFBTSxDQUFDLGdCQUFnQixFQUFFO0lBQzNCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO0dBQy9DLE1BQU0sSUFBSSxNQUFNLENBQUMsV0FBVyxFQUFFO0lBQzdCLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLEtBQUssRUFBRSxZQUFZO01BQzNDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDdEIsQ0FBQyxDQUFDO0dBQ0o7Q0FDRjs7O0FBR0QsU0FBUyxPQUFPLENBQUMsUUFBUSxFQUFFLEdBQUcsRUFBRTtFQUM5QixJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQ3hDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO0lBQ3BDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7R0FDM0MsT0FBTyxJQUFJLENBQUM7Q0FDZDs7O0FBR0QsU0FBUyxPQUFPLENBQUMsR0FBRyxFQUFFO0VBQ3BCLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxHQUFHLEVBQUUsQ0FBQzs7RUFFbkIsR0FBRyxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0VBQzdCLElBQUksSUFBSSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDMUIsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQzs7O0VBR2pDLE9BQU8sS0FBSyxJQUFJLENBQUMsR0FBRztJQUNsQixJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQztJQUN2QixJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztJQUN0QixLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztHQUM5Qjs7RUFFRCxPQUFPLElBQUksQ0FBQztDQUNiOzs7QUFHRCxTQUFTLFlBQVksQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFO0VBQzVCLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDLE1BQU0sR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO0VBQzVDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDLE1BQU0sR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO0VBQzVDLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQzs7RUFFbkIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7SUFDcEMsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLE9BQU8sR0FBRyxLQUFLLENBQUM7R0FDbkQ7RUFDRCxPQUFPLE9BQU8sQ0FBQztDQUNoQjs7QUFFRCxJQUFJLE9BQU8sR0FBRztFQUNaLFNBQVMsRUFBRSxDQUFDO0VBQ1osR0FBRyxFQUFFLENBQUM7RUFDTixLQUFLLEVBQUUsRUFBRTtFQUNULEtBQUssRUFBRSxFQUFFO0VBQ1QsTUFBTSxFQUFFLEVBQUU7RUFDVixHQUFHLEVBQUUsRUFBRTtFQUNQLE1BQU0sRUFBRSxFQUFFO0VBQ1YsS0FBSyxFQUFFLEVBQUU7RUFDVCxJQUFJLEVBQUUsRUFBRTtFQUNSLEVBQUUsRUFBRSxFQUFFO0VBQ04sS0FBSyxFQUFFLEVBQUU7RUFDVCxJQUFJLEVBQUUsRUFBRTtFQUNSLEdBQUcsRUFBRSxFQUFFO0VBQ1AsTUFBTSxFQUFFLEVBQUU7RUFDVixHQUFHLEVBQUUsRUFBRTtFQUNQLE1BQU0sRUFBRSxFQUFFO0VBQ1YsSUFBSSxFQUFFLEVBQUU7RUFDUixHQUFHLEVBQUUsRUFBRTtFQUNQLE1BQU0sRUFBRSxFQUFFO0VBQ1YsUUFBUSxFQUFFLEVBQUU7RUFDWixRQUFRLEVBQUUsRUFBRTtFQUNaLEdBQUcsRUFBRSxFQUFFO0VBQ1AsR0FBRyxFQUFFLEdBQUc7RUFDUixHQUFHLEVBQUUsR0FBRztFQUNSLEdBQUcsRUFBRSxHQUFHO0VBQ1IsR0FBRyxFQUFFLEdBQUc7RUFDUixHQUFHLEVBQUUsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHO0VBQ3JCLEdBQUcsRUFBRSxJQUFJLEdBQUcsRUFBRSxHQUFHLEdBQUc7RUFDcEIsR0FBRyxFQUFFLElBQUksR0FBRyxFQUFFLEdBQUcsR0FBRztFQUNwQixJQUFJLEVBQUUsR0FBRztFQUNULEdBQUcsRUFBRSxHQUFHO0VBQ1IsR0FBRyxFQUFFLEdBQUc7RUFDUixJQUFJLEVBQUUsR0FBRztDQUNWLENBQUM7O0FBRUYsSUFBSSxTQUFTLEdBQUc7RUFDZCxHQUFHLEVBQUUsRUFBRTtFQUNQLEtBQUssRUFBRSxFQUFFO0VBQ1QsR0FBRyxFQUFFLEVBQUU7RUFDUCxHQUFHLEVBQUUsRUFBRTtFQUNQLE1BQU0sRUFBRSxFQUFFO0VBQ1YsR0FBRyxFQUFFLEVBQUU7RUFDUCxJQUFJLEVBQUUsRUFBRTtFQUNSLE9BQU8sRUFBRSxFQUFFO0VBQ1gsR0FBRyxFQUFFLElBQUksR0FBRyxHQUFHLEdBQUcsRUFBRTtFQUNwQixHQUFHLEVBQUUsSUFBSSxHQUFHLEdBQUcsR0FBRyxFQUFFO0VBQ3BCLE9BQU8sRUFBRSxJQUFJLEdBQUcsR0FBRyxHQUFHLEVBQUU7Q0FDekIsQ0FBQztBQUNGLElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQztBQUNuQixJQUFJLFdBQVcsR0FBRztFQUNoQixFQUFFLEVBQUUsVUFBVTtFQUNkLEVBQUUsRUFBRSxRQUFRO0VBQ1osRUFBRSxFQUFFLFNBQVM7Q0FDZCxDQUFDO0FBQ0YsSUFBSSxLQUFLLEdBQUcsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDO0FBQ2hELElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQzs7O0FBR25CLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUU7RUFDM0IsT0FBTyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0NBQzVCOzs7QUFHRCxXQUFXLENBQUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUM7QUFDekMsS0FBSyxDQUFDLElBQUksR0FBRyxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDOztBQUUvQixJQUFJLE1BQU0sR0FBRyxLQUFLLENBQUM7QUFDbkIsSUFBSSxhQUFhLEdBQUcsS0FBSyxDQUFDOzs7QUFHMUIsSUFBSSxJQUFJLEdBQUcsU0FBUyxJQUFJLENBQUMsQ0FBQyxFQUFFO0VBQzFCLE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7Q0FDbEUsQ0FBQzs7O0FBR0YsU0FBUyxRQUFRLENBQUMsS0FBSyxFQUFFO0VBQ3ZCLE1BQU0sR0FBRyxLQUFLLElBQUksS0FBSyxDQUFDO0NBQ3pCOztBQUVELFNBQVMsUUFBUSxHQUFHO0VBQ2xCLE9BQU8sTUFBTSxJQUFJLEtBQUssQ0FBQztDQUN4Qjs7QUFFRCxTQUFTLGtCQUFrQixHQUFHO0VBQzVCLE9BQU8sU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztDQUMzQjs7O0FBR0QsU0FBUyxNQUFNLENBQUMsS0FBSyxFQUFFO0VBQ3JCLElBQUksT0FBTyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxJQUFJLEtBQUssQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDOztFQUUvRCxPQUFPLEVBQUUsT0FBTyxLQUFLLE9BQU8sSUFBSSxPQUFPLEtBQUssUUFBUSxJQUFJLE9BQU8sS0FBSyxVQUFVLENBQUMsQ0FBQztDQUNqRjs7O0FBR0QsU0FBUyxTQUFTLENBQUMsT0FBTyxFQUFFO0VBQzFCLElBQUksT0FBTyxPQUFPLEtBQUssUUFBUSxFQUFFO0lBQy9CLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7R0FDekI7RUFDRCxPQUFPLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7Q0FDMUM7OztBQUdELFNBQVMsV0FBVyxDQUFDLEtBQUssRUFBRSxRQUFRLEVBQUU7RUFDcEMsSUFBSSxRQUFRLEdBQUcsS0FBSyxDQUFDLENBQUM7RUFDdEIsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7OztFQUdmLElBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSyxHQUFHLFFBQVEsRUFBRSxDQUFDOztFQUUvQixLQUFLLElBQUksR0FBRyxJQUFJLFNBQVMsRUFBRTtJQUN6QixJQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLEVBQUU7TUFDeEQsUUFBUSxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztNQUMxQixLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEdBQUc7UUFDaEMsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEtBQUssRUFBRSxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO09BQ2pFO0tBQ0Y7R0FDRjs7O0VBR0QsSUFBSSxRQUFRLEVBQUUsS0FBSyxLQUFLLEVBQUUsUUFBUSxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsQ0FBQztDQUN2RDs7O0FBR0QsU0FBUyxhQUFhLENBQUMsS0FBSyxFQUFFO0VBQzVCLElBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxPQUFPLElBQUksS0FBSyxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDO0VBQ3pELElBQUksQ0FBQyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7OztFQUcvQixJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7OztFQUduQyxJQUFJLEdBQUcsS0FBSyxFQUFFLElBQUksR0FBRyxLQUFLLEdBQUcsRUFBRSxHQUFHLEdBQUcsRUFBRSxDQUFDO0VBQ3hDLElBQUksR0FBRyxJQUFJLEtBQUssRUFBRTtJQUNoQixLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDOzs7SUFHbkIsS0FBSyxJQUFJLENBQUMsSUFBSSxTQUFTLEVBQUU7TUFDdkIsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUM7S0FDOUM7R0FDRjtDQUNGOzs7QUFHRCxTQUFTLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFO0VBQzFCLElBQUksWUFBWSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUNoQyxJQUFJLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQztFQUNsQixJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7RUFDZCxJQUFJLEdBQUcsR0FBRyxLQUFLLENBQUMsQ0FBQzs7RUFFakIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7O0lBRTVDLElBQUksR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7SUFHbEMsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxJQUFJLEdBQUcsT0FBTyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQzs7O0lBR3JELEdBQUcsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztJQUM1QixHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7SUFHcEMsSUFBSSxDQUFDLEtBQUssRUFBRSxLQUFLLEdBQUcsUUFBUSxFQUFFLENBQUM7OztJQUcvQixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFLE9BQU87Ozs7SUFJNUIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7TUFDOUMsR0FBRyxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7TUFFeEIsSUFBSSxHQUFHLENBQUMsS0FBSyxLQUFLLEtBQUssSUFBSSxZQUFZLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsRUFBRTtRQUN2RCxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO09BQ3hCO0tBQ0Y7R0FDRjtDQUNGOzs7QUFHRCxTQUFTLFlBQVksQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRTtFQUMzQyxJQUFJLGNBQWMsR0FBRyxLQUFLLENBQUMsQ0FBQzs7O0VBRzVCLElBQUksT0FBTyxDQUFDLEtBQUssS0FBSyxLQUFLLElBQUksT0FBTyxDQUFDLEtBQUssS0FBSyxLQUFLLEVBQUU7O0lBRXRELGNBQWMsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7O0lBRXpDLEtBQUssSUFBSSxDQUFDLElBQUksS0FBSyxFQUFFO01BQ25CLElBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRTtRQUNsRCxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsY0FBYyxHQUFHLEtBQUssQ0FBQztPQUN2SDtLQUNGOzs7SUFHRCxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxjQUFjLElBQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxHQUFHLEVBQUU7TUFDbkksSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSyxLQUFLLEVBQUU7UUFDNUMsSUFBSSxLQUFLLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQyxLQUFLLEtBQUssQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1FBQ2hGLElBQUksS0FBSyxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDbkQsSUFBSSxLQUFLLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO09BQ25EO0tBQ0Y7R0FDRjtDQUNGOzs7QUFHRCxTQUFTLFFBQVEsQ0FBQyxLQUFLLEVBQUU7RUFDdkIsSUFBSSxRQUFRLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQzlCLElBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxPQUFPLElBQUksS0FBSyxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDOzs7RUFHekQsSUFBSSxTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Ozs7RUFJdkQsSUFBSSxHQUFHLEtBQUssRUFBRSxJQUFJLEdBQUcsS0FBSyxHQUFHLEVBQUUsR0FBRyxHQUFHLEVBQUUsQ0FBQzs7RUFFeEMsSUFBSSxHQUFHLElBQUksS0FBSyxFQUFFO0lBQ2hCLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUM7OztJQUdsQixLQUFLLElBQUksQ0FBQyxJQUFJLFNBQVMsRUFBRTtNQUN2QixJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztLQUM3Qzs7SUFFRCxJQUFJLENBQUMsUUFBUSxFQUFFLE9BQU87R0FDdkI7OztFQUdELEtBQUssSUFBSSxDQUFDLElBQUksS0FBSyxFQUFFO0lBQ25CLElBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRTtNQUNsRCxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ2xDO0dBQ0Y7OztFQUdELElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEVBQUUsT0FBTzs7O0VBRzlDLElBQUksS0FBSyxHQUFHLFFBQVEsRUFBRSxDQUFDOzs7RUFHdkIsSUFBSSxRQUFRLEVBQUU7SUFDWixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtNQUN4QyxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssS0FBSyxFQUFFLFlBQVksQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQzFFO0dBQ0Y7O0VBRUQsSUFBSSxFQUFFLEdBQUcsSUFBSSxTQUFTLENBQUMsRUFBRSxPQUFPOztFQUVoQyxLQUFLLElBQUksRUFBRSxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLEVBQUUsRUFBRTs7SUFFakQsWUFBWSxDQUFDLEtBQUssRUFBRSxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7R0FDaEQ7Q0FDRjs7QUFFRCxTQUFTLE9BQU8sQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRTtFQUNwQyxJQUFJLElBQUksR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDeEIsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO0VBQ2QsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDO0VBQ2xCLElBQUksT0FBTyxHQUFHLFFBQVEsQ0FBQztFQUN2QixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7OztFQUdWLElBQUksTUFBTSxLQUFLLFNBQVMsSUFBSSxPQUFPLE1BQU0sS0FBSyxVQUFVLEVBQUU7SUFDeEQsTUFBTSxHQUFHLE1BQU0sQ0FBQztHQUNqQjs7RUFFRCxJQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxpQkFBaUIsRUFBRTtJQUNoRSxJQUFJLE1BQU0sQ0FBQyxLQUFLLEVBQUUsS0FBSyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUM7SUFDdkMsSUFBSSxNQUFNLENBQUMsT0FBTyxFQUFFLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDO0dBQzlDOztFQUVELElBQUksT0FBTyxNQUFNLEtBQUssUUFBUSxFQUFFLEtBQUssR0FBRyxNQUFNLENBQUM7OztFQUcvQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO0lBQzNCLEdBQUcsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3pCLElBQUksR0FBRyxFQUFFLENBQUM7OztJQUdWLElBQUksR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsSUFBSSxHQUFHLE9BQU8sQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7OztJQUduRCxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDMUIsR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O0lBR3BDLElBQUksRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQzs7SUFFN0MsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztNQUNsQixLQUFLLEVBQUUsS0FBSztNQUNaLElBQUksRUFBRSxJQUFJO01BQ1YsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7TUFDakIsTUFBTSxFQUFFLE1BQU07TUFDZCxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztLQUNiLENBQUMsQ0FBQztHQUNKOztFQUVELElBQUksT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLENBQUMsYUFBYSxFQUFFO0lBQ3BELGFBQWEsR0FBRyxJQUFJLENBQUM7SUFDckIsUUFBUSxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsVUFBVSxDQUFDLEVBQUU7TUFDeEMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ2IsQ0FBQyxDQUFDO0lBQ0gsUUFBUSxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDLEVBQUU7TUFDdEMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ2xCLENBQUMsQ0FBQztHQUNKO0NBQ0Y7O0FBRUQsSUFBSSxJQUFJLEdBQUc7RUFDVCxRQUFRLEVBQUUsUUFBUTtFQUNsQixRQUFRLEVBQUUsUUFBUTtFQUNsQixXQUFXLEVBQUUsV0FBVztFQUN4QixrQkFBa0IsRUFBRSxrQkFBa0I7RUFDdEMsU0FBUyxFQUFFLFNBQVM7RUFDcEIsTUFBTSxFQUFFLE1BQU07RUFDZCxNQUFNLEVBQUUsTUFBTTtDQUNmLENBQUM7QUFDRixLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksRUFBRTtFQUNsQixJQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUU7SUFDakQsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztHQUN0QjtDQUNGOztBQUVELElBQUksT0FBTyxNQUFNLEtBQUssV0FBVyxFQUFFO0VBQ2pDLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUM7RUFDOUIsT0FBTyxDQUFDLFVBQVUsR0FBRyxVQUFVLElBQUksRUFBRTtJQUNuQyxJQUFJLElBQUksSUFBSSxNQUFNLENBQUMsT0FBTyxLQUFLLE9BQU8sRUFBRTtNQUN0QyxNQUFNLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQztLQUMzQjtJQUNELE9BQU8sT0FBTyxDQUFDO0dBQ2hCLENBQUM7RUFDRixNQUFNLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztDQUMxQjs7OztBQzFZTSxNQUFNLE9BQU8sU0FBUyxXQUFXLENBQUM7O0VBRXZDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTtJQUNQLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsRUFBQztHQUNuRDs7RUFFRCxpQkFBaUIsR0FBRztJQUNsQixNQUFNLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDO0dBQzdEO0VBQ0Qsb0JBQW9CLEdBQUc7SUFDckIsTUFBTSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFDO0dBQ3JEOztFQUVELFNBQVMsR0FBRztJQUNWLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNO01BQ2pDLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLEVBQUM7TUFDckUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixFQUFFLGFBQWEsQ0FBQyxFQUFFLENBQUMsRUFBQzs7TUFFM0QsSUFBSSxDQUFDLFNBQVMsRUFBRSxNQUFNOztNQUV0QixJQUFJLENBQUMsUUFBUSxHQUFHO1FBQ2QsYUFBYTtRQUNiLFlBQVksRUFBRSxTQUFTLENBQUMscUJBQXFCLEVBQUU7UUFDaEQ7S0FDRixFQUFDO0dBQ0g7O0VBRUQsSUFBSSxRQUFRLENBQUMsQ0FBQyxZQUFZLEVBQUUsYUFBYSxDQUFDLEVBQUU7SUFDMUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsYUFBYSxFQUFDO0dBQ25FOztFQUVELE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUUsYUFBYSxFQUFFO0lBQ3hELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLEVBQUUsYUFBYSxFQUFDO0lBQzlELE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDOzs7ZUFHakIsRUFBRSxLQUFLLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQztxQkFDckIsRUFBRSxLQUFLLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQzs7Ozs7Ozs7bUNBUUosRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDOzBDQUNILEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQzttQ0FDbEIsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUM7bUNBQ3pCLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDOztJQUV4RCxDQUFDO0dBQ0Y7O0VBRUQsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQ2pCLE9BQU8sQ0FBQzs7OztlQUlHLEVBQUUsR0FBRyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUM7Z0JBQ3RCLEVBQUUsSUFBSSxDQUFDOzs7Ozs7SUFNbkIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxPQUFPLENBQUM7O0FDdEV6QyxNQUFNLEtBQUssU0FBUyxPQUFPLENBQUM7O0VBRWpDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTtHQUNSOztFQUVELE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7SUFDekMsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7OztrQkFlZCxFQUFFLEtBQUssQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDOzs7SUFHekMsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDOztBQy9CckMsTUFBTSxLQUFLLFNBQVMsV0FBVyxDQUFDOztFQUVyQyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7SUFDUCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLEVBQUM7R0FDbkQ7O0VBRUQsaUJBQWlCLEdBQUc7SUFDbEIsQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDO0lBQzFFLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUM7R0FDN0Q7O0VBRUQsb0JBQW9CLEdBQUc7SUFDckIsQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFDO0lBQ3JELE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBQztHQUNyRDs7RUFFRCxTQUFTLEdBQUc7SUFDVixNQUFNLENBQUMscUJBQXFCLENBQUMsTUFBTTtNQUNqQyxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFDO01BQ3JFLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhLENBQUMsRUFBRSxDQUFDLEVBQUM7O01BRTdELElBQUksQ0FBQyxTQUFTLEVBQUUsTUFBTTs7TUFFdEIsSUFBSSxDQUFDLFFBQVEsR0FBRztRQUNkLGFBQWE7UUFDYixZQUFZLEVBQUUsU0FBUyxDQUFDLHFCQUFxQixFQUFFO1FBQ2hEO0tBQ0YsRUFBQztHQUNIOztFQUVELGFBQWEsQ0FBQyxDQUFDLEVBQUU7SUFDZixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxXQUFXLENBQUMsT0FBTyxFQUFFO01BQ3ZELE9BQU8sRUFBRSxJQUFJO01BQ2IsTUFBTSxJQUFJO1FBQ1IsSUFBSSxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVztRQUNoQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUk7T0FDbkI7S0FDRixDQUFDLEVBQUM7R0FDSjs7RUFFRCxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUU7SUFDaEIsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFPO0dBQ3JCOztFQUVELElBQUksUUFBUSxDQUFDLENBQUMsWUFBWSxFQUFFLGFBQWEsQ0FBQyxFQUFFO0lBQzFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLGFBQWEsRUFBQztHQUNuRTs7RUFFRCxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtJQUNoQixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUM7SUFDdEMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxPQUFPLEdBQUcsS0FBSTtJQUM1QyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUk7R0FDaEM7O0VBRUQsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRSxhQUFhLEVBQUU7SUFDeEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsRUFBRSxhQUFhLEVBQUM7O0lBRTlELE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQzs7UUFFOUIsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOztJQUVqQixDQUFDO0dBQ0Y7O0VBRUQsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtJQUN2QixPQUFPLENBQUM7Ozs7Ozs7O2VBUUcsRUFBRSxHQUFHLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFDdEIsRUFBRSxJQUFJLEdBQUcsQ0FBQyxDQUFDO3FCQUNOLEVBQUUsS0FBSyxJQUFJLE1BQU0sQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLEtBQUssR0FBRyxFQUFFLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUFzQ25FLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQzs7QUN6SHJDLE1BQU0sY0FBYyxHQUFHO0VBQzVCLEtBQUssZ0JBQWdCLGNBQWM7RUFDbkMsZUFBZSxNQUFNLGtCQUFrQjtFQUN2QyxlQUFlLE1BQU0sTUFBTTtFQUMzQixjQUFjLE9BQU8sTUFBTTtFQUMzQixrQkFBa0IsR0FBRyxPQUFPOztFQUU1QixXQUFXLFVBQVUsS0FBSztFQUMxQixZQUFZLFNBQVMsS0FBSztFQUMxQixTQUFTLFlBQVksTUFBTTtFQUMzQixPQUFPLGNBQWMsS0FBSztFQUMxQixNQUFNLGVBQWUsS0FBSztFQUMxQixVQUFVLFdBQVcsRUFBRTtFQUN2QixRQUFRLGFBQWEsTUFBTTtFQUMzQixVQUFVLFdBQVcsS0FBSztFQUMxQixTQUFTLFlBQVksT0FBTztFQUM1QixVQUFVLFdBQVcsTUFBTTtFQUMzQixhQUFhLFFBQVEsTUFBTTtFQUMzQixVQUFVLFdBQVcsUUFBUTtFQUM3QixhQUFhLFFBQVEsUUFBUTtFQUM3QixPQUFPLGNBQWMsT0FBTztFQUM1QixVQUFVLFdBQVcsUUFBUTtFQUM3QixjQUFjLE9BQU8sUUFBUTtFQUM3QixhQUFhLFFBQVEsS0FBSztFQUMxQixRQUFRLGFBQWEsUUFBUTtFQUM3QixTQUFTLFlBQVksTUFBTTs7RUFFM0IsSUFBSSxpQkFBaUIsY0FBYztFQUNuQyxNQUFNLGVBQWUsTUFBTTtFQUMzQixtQkFBbUIsRUFBRSxNQUFNO0VBQzNCLGVBQWUsTUFBTSxNQUFNO0VBQzNCLGdCQUFnQixLQUFLLE1BQU07RUFDM0IsWUFBWSxTQUFTLE1BQU07RUFDM0IsaUJBQWlCLElBQUksTUFBTTtFQUMzQixRQUFRLGFBQWEsMkJBQTJCO0VBQ2hELEdBQUcsa0JBQWtCLGVBQWU7RUFDcEMsWUFBWSxTQUFTLEtBQUs7RUFDM0I7O0FBRUQsQUFBTyxNQUFNLHVCQUF1QixHQUFHO0VBQ3JDLE1BQU07RUFDTixVQUFVO0VBQ1YsUUFBUTtFQUNSLEtBQUs7RUFDTCxLQUFLO0VBQ0wsT0FBTztFQUNQLE1BQU07RUFDUDs7QUFFRCxBQUFPLE1BQU0saUJBQWlCLEdBQUc7RUFDL0I7SUFDRSxRQUFRLEVBQUUsTUFBTTtJQUNoQixVQUFVLEVBQUUsR0FBRztHQUNoQjtFQUNEO0lBQ0UsUUFBUSxFQUFFLFFBQVE7SUFDbEIsVUFBVSxFQUFFLEtBQUs7R0FDbEI7Q0FDRjs7QUN4RE0sTUFBTSxRQUFRLEdBQUcsQ0FBQyxFQUFFLEVBQUUsSUFBSSxLQUFLO0VBQ3BDLElBQUksUUFBUSxDQUFDLFdBQVcsSUFBSSxRQUFRLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFO0lBQ2pFLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxLQUFLLEVBQUM7SUFDdEMsSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFXLEdBQUU7SUFDekIsSUFBSSxDQUFDLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFDO0lBQ3JELE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUM7R0FDckM7RUFDRjs7QUFFRCxBQUFPLE1BQU0sU0FBUyxHQUFHLEVBQUUsSUFBSTtFQUM3QixNQUFNLGFBQWEsR0FBRyxFQUFFLENBQUMsTUFBSztFQUM5QixNQUFNLGFBQWEsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxFQUFFLElBQUksRUFBQzs7RUFFdkQsSUFBSSxhQUFhLEdBQUcsR0FBRTs7RUFFdEIsS0FBSyxJQUFJLElBQUksRUFBRSxDQUFDLEtBQUs7SUFDbkIsSUFBSSxJQUFJLElBQUksY0FBYyxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxhQUFhLENBQUMsSUFBSSxDQUFDO01BQ3ZFLGFBQWEsQ0FBQyxJQUFJLENBQUM7UUFDakIsSUFBSTtRQUNKLEtBQUssRUFBRSxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUM7T0FDeEQsRUFBQzs7RUFFTixPQUFPLGFBQWE7RUFDckI7O0FBRUQsQUFBTyxNQUFNLDBCQUEwQixHQUFHLEVBQUUsSUFBSTtFQUM5QyxJQUFJLFVBQVUsR0FBRyxRQUFRLENBQUMsRUFBRSxFQUFFLGtCQUFrQixFQUFDOztFQUVqRCxJQUFJLFVBQVUsS0FBSyxrQkFBa0IsRUFBRTtJQUNyQyxJQUFJLElBQUksSUFBSSx3QkFBd0IsQ0FBQyxFQUFFLENBQUM7UUFDcEMsS0FBSyxHQUFHLE1BQUs7O0lBRWpCLE1BQU0sQ0FBQyxLQUFLLEVBQUU7TUFDWixJQUFJLEVBQUUsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLGtCQUFrQixFQUFDOztNQUU1QyxJQUFJLEVBQUUsS0FBSyxrQkFBa0IsRUFBRTtRQUM3QixLQUFLLEdBQUcsS0FBSTtRQUNaLFVBQVUsR0FBRyxHQUFFO09BQ2hCOztNQUVELElBQUksR0FBRyx3QkFBd0IsQ0FBQyxJQUFJLEVBQUM7O01BRXJDLElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxNQUFNLEVBQUU7UUFDNUIsS0FBSyxHQUFHLEtBQUk7UUFDWixVQUFVLEdBQUcsUUFBTztPQUNyQjtLQUNGO0dBQ0Y7O0VBRUQsT0FBTyxVQUFVO0VBQ2xCOztBQUVELEFBQU8sTUFBTSx3QkFBd0IsR0FBRyxFQUFFO0VBQ3hDLEVBQUUsQ0FBQyxVQUFVLElBQUksRUFBRSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEtBQUssQ0FBQztNQUN6QyxFQUFFLENBQUMsVUFBVTtNQUNiLEVBQUUsQ0FBQyxVQUFVLENBQUMsUUFBUSxLQUFLLG9CQUFvQjtRQUM3QyxFQUFFLENBQUMsVUFBVSxDQUFDLElBQUk7UUFDbEIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsS0FBSTs7QUFFckMsQUFBTyxNQUFNLHVCQUF1QixHQUFHLEVBQUUsSUFBSTtFQUMzQyxJQUFJLEVBQUUsQ0FBQyxVQUFVLElBQUksRUFBRSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFO0lBQ2xELE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO09BQy9CLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO1FBQ2pCLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQztPQUM1RCxDQUFDLENBQUMsQ0FBQztHQUNQO09BQ0ksSUFBSSxFQUFFLENBQUMsUUFBUSxDQUFDLE1BQU07SUFDekIsT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztFQUN4Qjs7QUFFRCxBQUFPLE1BQU0sVUFBVSxHQUFHLE1BQU0sV0FBVyxJQUFJO0VBQzdDLE1BQU0sT0FBTyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQztFQUNyRSxNQUFNLEtBQUssS0FBSyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLEVBQUM7RUFDakUsTUFBTSxLQUFLLEtBQUssUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUM7O0VBRS9DLEtBQUssQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxZQUFZO0lBQ3BELE1BQU0sR0FBRyxZQUFZO0lBQ3JCLEVBQUUsRUFBQzs7RUFFTCxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUM7Q0FDakM7O0FDL0VNLE1BQU0sUUFBUSxHQUFHLEVBQUUsSUFBSTtFQUM1QixNQUFNLFlBQVksR0FBRyxFQUFFLENBQUMsaUJBQWlCLEdBQUU7O0VBRTNDLE9BQU8sdUJBQXVCLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLFNBQVMsS0FBSztJQUN4RCxJQUFJLFlBQVksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDO01BQ2xDLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDUCxJQUFJLElBQUksU0FBUztRQUNqQixLQUFLLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUM7T0FDbkMsRUFBQzs7SUFFSixJQUFJLFNBQVMsS0FBSyxRQUFRO01BQ3hCLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJO1FBQzNCLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7VUFDdkIsR0FBRyxDQUFDLElBQUksQ0FBQztZQUNQLElBQUksSUFBSSxJQUFJO1lBQ1osS0FBSyxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDO1dBQzlCLEVBQUM7T0FDTCxFQUFDOztJQUVKLE9BQU8sR0FBRztHQUNYLEVBQUUsRUFBRSxDQUFDO0VBQ1A7O0FBRUQsQUFBTyxNQUFNLGdCQUFnQixHQUFHLEVBQUUsSUFBSTs7RUFFcEMsTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsRUFBRSxLQUFLLEtBQUs7TUFDckQsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBSztNQUNsQyxPQUFPLFFBQVE7R0FDbEIsRUFBRSxFQUFFLEVBQUM7O0VBRU4sTUFBTSxFQUFFLFFBQVEsS0FBSyxjQUFjLENBQUMsUUFBUTtVQUNwQyxVQUFVLEdBQUcsY0FBYyxDQUFDLFVBQVU7T0FDekMsR0FBRyxPQUFNOztFQUVkLE1BQU0sT0FBTyxHQUFHLGlCQUFpQixDQUFDLElBQUk7SUFDcEMsQ0FBQyxlQUFlLEtBQUssVUFBVSxDQUFDLFFBQVEsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDO1VBQzNFLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxVQUFVLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQztJQUN2RTs7RUFFRCxRQUFRLE9BQU8sR0FBRyxPQUFPLEdBQUcsT0FBTzs7O0NBQ3BDLERDM0NNLE1BQU0sV0FBVyxHQUFHLENBQUMsV0FBVyxHQUFHLEVBQUU7RUFDMUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxFQUFFO0lBQ2pDLEdBQUcsQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLEVBQUM7O0FBRXpCLEFBQU8sTUFBTSxPQUFPLEdBQUcsSUFBSSxJQUFJO0VBQzdCLElBQUksSUFBSSxHQUFHLEdBQUU7RUFDYixJQUFJLGFBQWEsR0FBRyxLQUFJOztFQUV4QixPQUFPLGFBQWEsRUFBRTtJQUNwQixJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBQztJQUN4QixhQUFhLEdBQUcsYUFBYSxDQUFDLFVBQVU7UUFDcEMsYUFBYSxDQUFDLFVBQVU7UUFDeEIsTUFBSztHQUNWOztFQUVELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksRUFBRSxNQUFNLEtBQUssQ0FBQztJQUNwQyxFQUFFLElBQUksQ0FBQyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7RUFDckgsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUNQOztBQUVELEFBQU8sTUFBTSxlQUFlLEdBQUcsQ0FBQyxFQUFFLEVBQUUsT0FBTyxHQUFHLEtBQUssS0FBSztFQUN0RCxJQUFJLENBQUMsRUFBRSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUU7O0VBRTVCLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFVBQVUsRUFBRSxTQUFTO0lBQ3JFLFVBQVUsSUFBSSxHQUFHLEdBQUcsU0FBUztJQUM3QixFQUFFLEVBQUM7O0VBRUwsT0FBTyxPQUFPLElBQUksUUFBUSxDQUFDLE1BQU0sR0FBRyxFQUFFO01BQ2xDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUs7TUFDaEMsUUFBUTtFQUNiOztBQUVELEFBQU8sTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztJQUM1RCxLQUFLO0lBQ0wsT0FBTTs7QUFFVixBQUFPLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7SUFDM0QsS0FBSztJQUNMLEtBQUs7O0FDbkNGLE1BQU0sb0JBQW9CLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLO0VBQzVDLE1BQU0sRUFBRSxHQUFHLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFDOztFQUUxQyxNQUFNLFlBQVksR0FBRyxJQUFJLElBQUk7SUFDM0IsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO01BQ25CLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBQzs7TUFFeEQsSUFBSSxTQUFTLElBQUksSUFBSSxXQUFXLE9BQU8sSUFBSTtXQUN0QyxJQUFJLFNBQVMsQ0FBQyxVQUFVLEdBQUcsT0FBTyxZQUFZLENBQUMsU0FBUyxDQUFDO3NDQUM5QixPQUFPLFNBQVM7S0FDakQ7U0FDSSxPQUFPLElBQUk7SUFDakI7O0VBRUQsTUFBTSxhQUFhLEdBQUcsWUFBWSxDQUFDLEVBQUUsRUFBQzs7RUFFdEMsT0FBTyxhQUFhLElBQUksRUFBRTtFQUMzQjs7QUFFRCxBQUFPLE1BQU0sT0FBTyxHQUFHLFNBQVMsSUFBSTtFQUNsQyxJQUFJLEtBQUssR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsRUFBQztFQUMzRSxJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUUsS0FBSyxHQUFHLE1BQUs7RUFDaEMsSUFBSSxLQUFLLElBQUksTUFBTSxFQUFFLEtBQUssR0FBRyxTQUFRO0VBQ3JDLE9BQU8sS0FBSztFQUNiOztBQUVELEFBQU8sTUFBTSxZQUFZLEdBQUcsRUFBRSxJQUFJO0VBQ2hDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQztLQUNoRCxPQUFPLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQztFQUM3Qjs7QUFFRCxBQUFPLFNBQVMsUUFBUSxDQUFDLEVBQUUsRUFBRTtFQUMzQixPQUFPLEVBQUUsQ0FBQyxPQUFPLENBQUM7SUFDaEIsRUFBRSxPQUFPLEVBQUUsdUJBQXVCLEVBQUU7SUFDcEMsRUFBRSxPQUFPLEVBQUUscUNBQXFDLEVBQUU7SUFDbEQsRUFBRSxPQUFPLEVBQUUsdUJBQXVCLEVBQUU7R0FDckMsRUFBRSxHQUFHLENBQUM7Q0FDUjs7QUFFRCxJQUFJLFVBQVUsR0FBRyxHQUFFO0FBQ25CLEFBQU8sTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLEVBQUUsRUFBRSxRQUFRLEdBQUcsR0FBRyxLQUFLO0VBQ3RELEVBQUUsQ0FBQyxZQUFZLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxFQUFDO0VBQzNDLGlCQUFpQixDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUM7O0VBRTNCLElBQUksVUFBVSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUN6QixZQUFZLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDOztFQUV2QyxVQUFVLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUMsSUFBSTtJQUN4QyxFQUFFLENBQUMsZUFBZSxDQUFDLG9CQUFvQixFQUFDO0lBQ3hDLGlCQUFpQixDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUM7R0FDN0IsRUFBRSxRQUFRLEVBQUM7O0VBRVosT0FBTyxFQUFFO0VBQ1Y7O0FBRUQsQUFBTyxNQUFNLGlCQUFpQixHQUFHLENBQUMsRUFBRSxFQUFFLElBQUksR0FBRyxLQUFLLEtBQUs7RUFDckQsSUFBSSxDQUFDLEVBQUUsQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDO0lBQ25DLE1BQU07O0VBRVIsTUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxlQUFlLEVBQUM7O0VBRWpELE1BQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dDQUNhLEVBQUUsUUFBUSxDQUFDO2tDQUNULEVBQUUsUUFBUSxDQUFDO0VBQzNDLENBQUMsRUFBQzs7RUFFRixLQUFLLENBQUMsTUFBTSxJQUFJLElBQUk7TUFDaEIsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQ2hCLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztNQUMxQixLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUU7TUFDaEIsRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsSUFBSSxFQUFDO0VBQzdCOztBQUVELEFBQU8sTUFBTSxlQUFlLEdBQUcsQ0FBQyxVQUFVLEdBQUcsRUFBRTtFQUM3QyxDQUFDLElBQUksU0FBUyxFQUFFLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRSxXQUFXLENBQUM7S0FDdEQsSUFBSSxDQUFDLFdBQVU7O0FBRXBCLEFBQU8sTUFBTSxXQUFXLEdBQUcsSUFBSTtFQUM3QixJQUFJLENBQUMsT0FBTztPQUNQLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO09BQ3ZCLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDO09BQzFCLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUM7T0FDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUM7T0FDM0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUM7T0FDNUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQztPQUM5QixJQUFJLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDO0lBQ3BDOztBQUVILEFBQU8sTUFBTSxlQUFlLEdBQUcsQ0FBQyxFQUFFO0VBQ2hDLFFBQVEsSUFBSTtJQUNWLElBQUksRUFBRSxFQUFFLENBQUMsUUFBUSxFQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLE9BQU8sS0FBSyxFQUFFO0lBQy9DLE9BQU8sSUFBSTtHQUNaO0NBQ0YsRUFBRSxDQUFDLElBQUksUUFBUSxDQUFDLHNCQUFzQixFQUFFLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQ2hHcEQsU0FBUyxZQUFZLEdBQUc7RUFDN0IsTUFBTSxNQUFNLElBQUksTUFBTSxDQUFDLFlBQVc7RUFDbEMsTUFBTSxLQUFLLEtBQUssTUFBTSxDQUFDLFdBQVU7RUFDakMsTUFBTSxJQUFJLE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFXOztFQUV6QyxNQUFNLFNBQVMsR0FBRyxJQUFJLElBQUksS0FBSztNQUMzQixJQUFJO01BQ0osTUFBSzs7RUFFVCxPQUFPO0lBQ0wsU0FBUyxFQUFFLE1BQU07SUFDakIsUUFBUSxHQUFHLFNBQVM7R0FDckI7Q0FDRjs7QUNYTSxNQUFNLFNBQVMsU0FBUyxXQUFXLENBQUM7O0VBRXpDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTtJQUNQLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsRUFBQztHQUNuRDs7RUFFRCxpQkFBaUIsR0FBRyxFQUFFO0VBQ3RCLG9CQUFvQixHQUFHLEVBQUU7O0VBRXpCLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRTtJQUN6QixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBQztHQUNwRDs7RUFFRCxJQUFJLE1BQU0sQ0FBQyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFO0lBQ3ZDLE1BQU0sRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLEdBQUcsWUFBWSxHQUFFOztJQUU5QyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLFFBQU87SUFDekMsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFDOztJQUVwQyxHQUFHLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEVBQUM7SUFDM0QsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLEtBQUssR0FBRyxJQUFJLEVBQUM7SUFDbkQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLE1BQU0sR0FBRyxJQUFJLEVBQUM7SUFDckQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLElBQUksRUFBQztJQUN2QyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFDO0lBQ3RDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUM7SUFDeEMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLElBQUksRUFBQztJQUN4QyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsSUFBSSxHQUFHLEtBQUssRUFBQztJQUNoRCxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsSUFBSSxHQUFHLEtBQUssRUFBQztJQUNoRCxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFDO0lBQ3ZDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUM7SUFDdkMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztJQUM1QyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsR0FBRyxHQUFHLE1BQU0sRUFBQztJQUNoRCxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsR0FBRyxHQUFHLE1BQU0sRUFBQztJQUNoRCxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFDO0dBQzdDOztFQUVELE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7SUFDekMsTUFBTSxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsR0FBRyxZQUFZLEdBQUU7O0lBRTlDLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDOzs7cUJBR1gsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQzs7Ozs7aUJBSzVCLEVBQUUsS0FBSyxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUM7YUFDL0IsRUFBRSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQzs7O2tCQUdSLEVBQUUsQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQztrQkFDdkMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7eUJBQ2hELEVBQUUsQ0FBQyxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQzt5QkFDL0IsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUM7O0lBRXRFLENBQUM7R0FDRjs7RUFFRCxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7SUFDakIsT0FBTyxDQUFDOzs7Ozs7Ozs7OztJQVdSLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQUUsU0FBUyxDQUFDOztBQy9FN0MsTUFBTSxRQUFRLFNBQVMsV0FBVyxDQUFDOztFQUV4QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7SUFDUCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUM7R0FDakQ7O0VBRUQsaUJBQWlCLEdBQUcsRUFBRTtFQUN0QixvQkFBb0IsR0FBRyxFQUFFOztFQUV6QixJQUFJLFFBQVEsQ0FBQyxDQUFDLFVBQVUsRUFBRSxhQUFhLENBQUMsRUFBRTtJQUN4QyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxhQUFhLEVBQUM7R0FDakU7O0VBRUQsTUFBTSxDQUFDLFlBQVksRUFBRSxhQUFhLEVBQUU7SUFDbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsRUFBRSxhQUFhLEVBQUM7SUFDOUQsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDOzs7dUJBR1gsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDOzs7SUFHcEMsQ0FBQztHQUNGOztFQUVELE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLEVBQUU7SUFDMUIsT0FBTyxDQUFDOzs7Ozs7Ozs7OztVQVdGLEVBQUUsQ0FBQztjQUNDLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUM7Y0FDN0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUM7ZUFDN0IsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFDcEIsRUFBRSxDQUFDLENBQUM7cUJBQ0MsRUFBRSxDQUFDO2NBQ1Ysa0JBQWtCO2NBQ2xCLGtCQUFrQixDQUFDOzs7Ozs7OzBCQU9QLEVBQUUsQ0FBQyxHQUFHLFFBQVEsR0FBRyxLQUFLLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7OztVQWtCdkMsRUFBRSxDQUFDO2NBQ0Msd0NBQXdDO2NBQ3hDLHdDQUF3QyxDQUFDOzs7Ozs7VUFNN0MsRUFBRSxDQUFDO2NBQ0MsMkJBQTJCO2NBQzNCLDRCQUE0QixDQUFDOzs7MEJBR2pCLEVBQUUsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLEtBQUssTUFBTSxHQUFHLGVBQWUsR0FBRyxnQkFBZ0IsQ0FBQzt5Q0FDcEQsRUFBRSxDQUFDLENBQUM7OztJQUd6QyxDQUFDO0dBQ0Y7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLFFBQVEsQ0FBQzs7QUMzRjNDLE1BQU0sT0FBTyxTQUFTLFdBQVcsQ0FBQzs7RUFFdkMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFO0lBQ1AsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxFQUFDO0dBQ25EOztFQUVELGlCQUFpQixHQUFHLEVBQUU7RUFDdEIsb0JBQW9CLEdBQUcsRUFBRTs7RUFFekIsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFO0lBQ3pCLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFDO0dBQ3BEOztFQUVELElBQUksTUFBTSxDQUFDLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEVBQUU7SUFDdkMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxRQUFPOztJQUV6QyxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUM7SUFDcEMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsUUFBTztJQUMzQixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUMsT0FBTyxHQUFHLEdBQUcsR0FBRyxLQUFJO0lBQzNDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxLQUFJOztJQUU1QixHQUFHLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxLQUFLLEdBQUcsSUFBSSxFQUFDO0lBQ3ZDLEdBQUcsQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLE1BQU0sR0FBRyxJQUFJLEVBQUM7R0FDMUM7O0VBRUQsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFO0lBQ3JDLE9BQU8sQ0FBQzs7O29CQUdRLEVBQUUsRUFBRSxDQUFDOzs7Ozs7Ozs7O2VBVVYsRUFBRSxLQUFLLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQztxQkFDdkIsRUFBRSxLQUFLLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQzs7Ozs7Ozs7SUFRbkMsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxPQUFPLENBQUM7Ozs7QUNqRHpDLE1BQU0sT0FBTyxTQUFTLFdBQVcsQ0FBQzs7RUFFdkMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFO0lBQ1AsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxFQUFDO0dBQ25EOztFQUVELGlCQUFpQixHQUFHO0lBQ2xCLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUM7R0FDL0Q7O0VBRUQsb0JBQW9CLEdBQUc7SUFDckIsSUFBSSxDQUFDLFNBQVMsR0FBRTtHQUNqQjs7RUFFRCxhQUFhLENBQUMsQ0FBQyxFQUFFO0lBQ2YsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksV0FBVyxDQUFDLE9BQU8sRUFBRTtNQUN2RCxPQUFPLEVBQUUsSUFBSTtNQUNiLE1BQU0sSUFBSTtRQUNSLElBQUksUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVc7UUFDaEMsU0FBUyxHQUFHLENBQUMsQ0FBQyxJQUFJO09BQ25CO0tBQ0YsQ0FBQyxFQUFDO0dBQ0o7O0VBRUQsT0FBTyxHQUFHO0lBQ1IsQ0FBQyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDO0lBQy9FLENBQUMsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUM7R0FDNUU7O0VBRUQsU0FBUyxHQUFHO0lBQ1YsQ0FBQyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDO0lBQ2hGLENBQUMsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUM7R0FDN0U7O0VBRUQsZUFBZSxDQUFDLENBQUMsRUFBRTtJQUNqQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxXQUFXLENBQUMsU0FBUyxFQUFFO01BQ3pELE9BQU8sRUFBRSxJQUFJO0tBQ2QsQ0FBQyxFQUFDO0lBQ0gsSUFBSSxDQUFDLFNBQVMsR0FBRTtHQUNqQjs7RUFFRCxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUU7SUFDYixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBQztHQUMzQzs7RUFFRCxNQUFNLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxrQkFBa0IsRUFBRSxxQkFBcUIsQ0FBQyxFQUFFO0lBQ3JFLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDOzs7a0JBR0osRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ2pDLEVBQUUsRUFBRSxDQUFDLEVBQUUsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQztVQUMxQixFQUFFLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO2FBQzdCLE1BQU0sQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUUsQ0FBQzthQUMxQixNQUFNLENBQUMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxLQUFLLENBQUM7Y0FDeEIsRUFBRSxLQUFLLENBQUM7a0JBQ0osRUFBRSxJQUFJLENBQUM7WUFDYixDQUFDLEVBQUUsRUFBRSxDQUFDO1dBQ1A7OztpQkFHTSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7O2dCQUVyQixFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7O2FBRXhCLEVBQUUscUJBQXFCLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLElBQUksS0FBSyxDQUFDO1VBQ3BELEVBQUUsS0FBSyxDQUFDO3FCQUNHLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQztzQkFDWCxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDM0IsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDOztRQUVQLEVBQUUsa0JBQWtCLENBQUMsTUFBTSxHQUFHLENBQUM7O2VBRXhCLEVBQUUsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLElBQUksS0FBSyxDQUFDO1lBQ2pELEVBQUUsS0FBSyxDQUFDO3VCQUNHLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQzt3QkFDWCxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7VUFDM0IsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDOztRQUVULENBQUMsR0FBRyxFQUFFLENBQUM7O0lBRVgsQ0FBQztHQUNGOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQzs7UUFFSixFQUFFQSxLQUFNLENBQUM7O0lBRWIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxPQUFPLENBQUM7O0FDaEd6QyxNQUFNLElBQUksU0FBUyxPQUFPLENBQUM7RUFDaEMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFO0dBQ1I7O0VBRUQsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFFLGVBQWUsRUFBRSxnQkFBZ0IsQ0FBQyxFQUFFO0lBQzlDLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDOztZQUVWLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7O1VBRXJELEVBQUUsZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLEtBQUssQ0FBQztZQUN6QyxFQUFFLEtBQUssQ0FBQzt1QkFDRyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUM7d0JBQ1gsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO1VBQzNCLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztVQUNQLEVBQUUsZ0JBQWdCLENBQUM7OztJQUd6QixDQUFDO0dBQ0Y7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUM7Ozs7QUN6Qm5DLE1BQU0sTUFBTSxHQUFHLENBQUM7Ozs7QUFJdkIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sSUFBSSxHQUFHLENBQUM7Ozs7QUFJckIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sTUFBTSxHQUFHLENBQUM7Ozs7QUFJdkIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sTUFBTSxHQUFHLENBQUM7Ozs7QUFJdkIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sT0FBTyxHQUFHLENBQUM7Ozs7QUFJeEIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sSUFBSSxHQUFHLENBQUM7Ozs7QUFJckIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sSUFBSSxHQUFHLENBQUM7Ozs7QUFJckIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sS0FBSyxHQUFHLENBQUM7Ozs7QUFJdEIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sTUFBTSxHQUFHLENBQUM7Ozs7QUFJdkIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sU0FBUyxHQUFHLENBQUM7Ozs7O0FBSzFCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLE1BQU0sR0FBRyxDQUFDOzs7O0FBSXZCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLFFBQVEsR0FBRyxDQUFDOzs7O0FBSXpCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLFNBQVMsR0FBRyxDQUFDOzs7O0FBSTFCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLFNBQVMsR0FBRyxDQUFDOzs7Ozs7Ozs7QUFTMUIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sTUFBTSxHQUFHLENBQUM7Ozs7O0FBS3ZCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLE1BQU0sR0FBRyxDQUFDOzs7OztBQUt2QixFQUFDOztBQUVELEFBQU8sTUFBTSxVQUFVLEdBQUcsQ0FBQzs7Ozs7QUFLM0IsRUFBQzs7QUFFRCxBQUFPLE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQzs7Ozs7QUFLakMsRUFBQzs7QUFFRCxBQUFPLE1BQU0sWUFBWSxHQUFHLENBQUM7Ozs7O0FBSzdCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLFFBQVEsR0FBRyxDQUFDOzs7OztBQUt6QixFQUFDOztBQUVELEFBQU8sTUFBTSxhQUFhLEdBQUcsQ0FBQzs7OztBQUk5Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FBQyxEQ2xJTSxNQUFNLFNBQVMsU0FBUyxXQUFXLENBQUM7O0VBRXpDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTs7SUFFUCxJQUFJLENBQUMsY0FBYyxHQUFHO01BQ3BCLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7TUFDdEUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztNQUNwRSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztNQUNsRSxLQUFLLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztNQUNqRSxLQUFLLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7TUFDN0Q7O0lBRUQsSUFBSSxDQUFDLGNBQWMsR0FBRztNQUNwQixHQUFHLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO01BQ2QsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUNiLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztNQUNsQixLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7TUFDbEIsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztNQUNmOztJQUVELElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsRUFBQzs7SUFFckQsSUFBSSxDQUFDLE9BQU8sTUFBTSxHQUFFO0lBQ3BCLElBQUksQ0FBQyxTQUFTLElBQUksR0FBRTs7SUFFcEIsSUFBSSxDQUFDLElBQUksU0FBUyxZQUFXO0dBQzlCOztFQUVELGlCQUFpQixHQUFHO0lBQ2xCLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLGdDQUFnQyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUM7SUFDaEUsSUFBSSxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUMsK0JBQStCLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBQztJQUMvRCxJQUFJLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFDO0lBQ3BFLElBQUksQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsd0JBQXdCLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUM7SUFDckUsSUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUM7SUFDL0MsSUFBSSxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBQztJQUNqRCxJQUFJLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFDO0lBQ2pELElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUM7R0FDbkQ7O0VBRUQsb0JBQW9CLEdBQUcsRUFBRTs7RUFFekIsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFO0lBQ2IsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFJO0lBQ2pCLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUU7R0FDdkM7O0VBRUQsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFNO0lBQ3hDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTztNQUN0QixJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsRUFBQztHQUM5Qjs7RUFFRCxJQUFJLEdBQUc7SUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU07SUFDeEMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUM7R0FDcEI7O0VBRUQsU0FBUyxDQUFDLENBQUMsRUFBRSxPQUFPLEVBQUU7SUFDcEIsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixDQUFDLENBQUMsd0JBQXdCLEdBQUU7O0lBRTVCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsS0FBSyxFQUFDO0lBQzFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFDO0lBQ3hDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFDO0lBQ3RDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUM7SUFDM0MsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxJQUFJLEtBQUssU0FBUyxFQUFDO0lBQzlDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBQztJQUNsRCxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUM7SUFDbEQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxJQUFJLEtBQUssWUFBWSxFQUFDOztJQUVwRCxNQUFNLEVBQUUsUUFBUSxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFDOztJQUV0RixDQUFDLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztNQUM5RCxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLE1BQU07S0FDMUMsRUFBQztHQUNIOztFQUVELGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFFQyxVQUFPLENBQUMsRUFBRTtJQUNqQyxJQUFJLE1BQU0sZ0JBQWdCQSxVQUFPLENBQUMsS0FBSyxHQUFHLEVBQUUsR0FBRyxFQUFDO0lBQ2hELElBQUksUUFBUSxjQUFjQSxVQUFPLENBQUMsR0FBRyxHQUFHLFVBQVUsR0FBRyxNQUFLO0lBQzFELElBQUksaUJBQWlCLEtBQUtBLFVBQU8sQ0FBQyxHQUFHLEdBQUcsTUFBTSxHQUFHLEtBQUk7O0lBRXJELElBQUksSUFBSSxHQUFHLGNBQWE7SUFDeEIsSUFBSSxJQUFJLEtBQUssU0FBUyxNQUFNLElBQUksR0FBRyxlQUFjO0lBQ2pELElBQUksSUFBSSxLQUFLLFdBQVcsSUFBSSxJQUFJLEdBQUcsa0JBQWlCO0lBQ3BELElBQUksSUFBSSxLQUFLLFdBQVcsSUFBSSxJQUFJLEdBQUcsZ0JBQWU7SUFDbEQsSUFBSSxJQUFJLEtBQUssWUFBWSxHQUFHLElBQUksR0FBRyxpQkFBZ0I7SUFDbkQsSUFBSUEsVUFBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLElBQUksR0FBRyxZQUFXOztJQUVuRCxJQUFJQSxVQUFPLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSSxLQUFLLFdBQVcsRUFBRTtNQUM1QyxRQUFRLGNBQWMsV0FBVTtNQUNoQyxpQkFBaUIsS0FBSyxPQUFNO0tBQzdCOztJQUVELE9BQU87TUFDTCxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxFQUFFLElBQUk7S0FDMUM7R0FDRjs7RUFFRCxjQUFjLENBQUMsQ0FBQyxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLE1BQU0sQ0FBQyxFQUFFO0lBQzFELE9BQU8sQ0FBQztxQkFDUyxFQUFFLFFBQVEsQ0FBQztpQkFDZixFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7bUJBQ1gsRUFBRSxpQkFBaUIsQ0FBQztpQkFDdEIsRUFBRSxJQUFJLENBQUM7O21CQUVMLEVBQUUsTUFBTSxDQUFDO0lBQ3hCLENBQUM7R0FDRjs7RUFFRCxNQUFNLEdBQUc7SUFDUCxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzs7OztZQUlWLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNwQixFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7Ozs7VUFJZixFQUFFLElBQUksQ0FBQyxjQUFjLENBQUM7WUFDcEIsUUFBUSxFQUFFLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUM7WUFDekIsaUJBQWlCLEVBQUUsTUFBTTtZQUN6QixJQUFJLEVBQUUsSUFBSSxDQUFDLEtBQUs7WUFDaEIsSUFBSSxFQUFFLGFBQWE7WUFDbkIsTUFBTSxFQUFFLENBQUM7V0FDVixDQUFDLENBQUM7Ozs7WUFJRCxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDO2NBQzNFLEVBQUUsUUFBUSxDQUFDO3VCQUNGLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQztnQkFDbEQsRUFBRSxHQUFHLENBQUM7O2tCQUVKLEVBQUUsR0FBRyxDQUFDO2tCQUNOLEVBQUUsSUFBSSxDQUFDLE9BQU8sSUFBSSxHQUFHLEdBQUcscUNBQXFDLEdBQUcsRUFBRSxDQUFDO2tCQUNuRSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sR0FBRyxFQUFFLENBQUM7OEJBQ2pDLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ3JELEVBQUUsR0FBRyxDQUFDO2NBQ1QsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDOztZQUVULENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7O0lBWWYsQ0FBQztHQUNGOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQzs7UUFFSixFQUFFRCxLQUFNLENBQUM7O0lBRWIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDOztBQzNLdkMsTUFBTSxhQUFhLFNBQVMsU0FBUyxDQUFDO0VBQzNDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTs7SUFFUCxJQUFJLENBQUMsT0FBTyxNQUFNLElBQUc7SUFDckIsSUFBSSxDQUFDLFNBQVMsSUFBSSxHQUFFO0lBQ3BCLElBQUksQ0FBQyxJQUFJLFNBQVMsU0FBUTtHQUMzQjs7RUFFRCxpQkFBaUIsR0FBRyxFQUFFOztFQUV0QixJQUFJLEdBQUc7SUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU07R0FDekM7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Ozs7WUFJVixFQUFFRSxNQUFJLENBQUM7WUFDUCxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7Ozs7Ozs7SUFPckIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhLENBQUM7O0FDaEMvQyxNQUFNLGdCQUFnQixTQUFTLFNBQVMsQ0FBQztFQUM5QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUM7SUFDMUIsSUFBSSxDQUFDLElBQUksU0FBUyxZQUFXO0dBQzlCOztFQUVELGlCQUFpQixHQUFHLEVBQUU7O0VBRXRCLElBQUksR0FBRztJQUNMLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTTtHQUN6Qzs7RUFFRCxNQUFNLEdBQUc7SUFDUCxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzs7OztZQUlWLEVBQUVBLFNBQUksQ0FBQztZQUNQLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQzs7Ozs7OztJQU9yQixDQUFDO0dBQ0Y7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLG1CQUFtQixFQUFFLGdCQUFnQixDQUFDOztBQ2pDckQsTUFBTSxvQkFBb0IsU0FBUyxTQUFTLENBQUM7RUFDbEQsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFDO0lBQzFCLElBQUksQ0FBQyxJQUFJLFNBQVMsZ0JBQWU7R0FDbEM7O0VBRUQsaUJBQWlCLEdBQUcsRUFBRTs7RUFFdEIsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFNO0dBQ3pDOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDOzs7O1lBSVYsRUFBRUEsYUFBSSxDQUFDO1lBQ1AsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzs7Ozs7O0lBT3JCLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsdUJBQXVCLEVBQUUsb0JBQW9CLENBQUM7O0FDbkM3RCxNQUFNLFdBQVcsU0FBUyxTQUFTLENBQUM7RUFDekMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLElBQUksSUFBRztJQUNuQixJQUFJLENBQUMsSUFBSSxPQUFPLE9BQU07R0FDdkI7O0VBRUQsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUU7SUFDakMsSUFBSSxNQUFNLEVBQUUsUUFBUSxFQUFFLGtCQUFpQjs7SUFFdkMsSUFBSSxJQUFJLEdBQUcsY0FBYTtJQUN4QixJQUFJLElBQUksS0FBSyxTQUFTLE1BQU0sSUFBSSxHQUFHLGtCQUFpQjtJQUNwRCxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxHQUFHLDZDQUE0QztJQUMvRSxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxHQUFHLHFDQUFvQztJQUN2RSxJQUFJLElBQUksS0FBSyxZQUFZLEdBQUcsSUFBSSxHQUFHLHVDQUFzQzs7SUFFekUsT0FBTztNQUNMLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxNQUFNLEVBQUUsSUFBSTtLQUMxQztHQUNGOztFQUVELGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQ3JCLE9BQU8sQ0FBQztpQkFDSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7aUJBQ2IsRUFBRSxJQUFJLENBQUM7SUFDcEIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsV0FBVzs7a0RBQUMsbERDN0IzQyxNQUFNLGFBQWEsU0FBUyxTQUFTLENBQUM7RUFDM0MsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUM7O0lBRTFDLElBQUksQ0FBQyxJQUFJLFNBQVMsU0FBUTtHQUMzQjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsYUFBYSxDQUFDOztBQ1gvQyxNQUFNLGNBQWMsU0FBUyxTQUFTLENBQUM7RUFDNUMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUM7O0lBRTFDLElBQUksQ0FBQyxJQUFJLFNBQVMsVUFBUztHQUM1QjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUsY0FBYyxDQUFDOztBQ1h4RCxNQUFNLGNBQWMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFDO0FBQ2pELE1BQU0sY0FBYyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUM7QUFDakQsTUFBTSxXQUFXLE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBQzs7QUFFckQsQUFBTyxNQUFNLFlBQVksU0FBUyxTQUFTLENBQUM7RUFDMUMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLEtBQUssSUFBRztJQUNwQixJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBQzs7SUFFbEMsSUFBSSxDQUFDLE1BQU0sS0FBSyxFQUFDO0lBQ2pCLElBQUksQ0FBQyxNQUFNLEtBQUssRUFBQztJQUNqQixJQUFJLENBQUMsTUFBTSxLQUFLLEVBQUM7O0lBRWpCLElBQUksQ0FBQyxLQUFLLFdBQVcsV0FBVTtJQUMvQixJQUFJLENBQUMsVUFBVSxNQUFNLE1BQUs7SUFDMUIsSUFBSSxDQUFDLGFBQWEsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBQzs7SUFFN0MsSUFBSSxDQUFDLElBQUksT0FBTyxRQUFPO0dBQ3hCOztFQUVELGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFO0lBQ2pDLElBQUksTUFBTSxjQUFjLElBQUksQ0FBQyxhQUFhO1FBQ3RDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxVQUFVO1FBQ25DLElBQUksZ0JBQWdCLElBQUksQ0FBQyxLQUFLO1FBQzlCLFNBQVE7O0lBRVosSUFBSSxPQUFPLENBQUMsR0FBRyxLQUFLLElBQUksS0FBSyxZQUFZLElBQUksSUFBSSxLQUFLLFdBQVcsQ0FBQyxFQUFFO01BQ2xFLGlCQUFpQixHQUFHLElBQUksS0FBSyxXQUFXO1VBQ3BDLFFBQVE7VUFDUixNQUFLO01BQ1QsSUFBSSxDQUFDLFVBQVUsR0FBRyxrQkFBaUI7S0FDcEM7U0FDSTtNQUNILElBQUksSUFBSSxLQUFLLFNBQVMsWUFBWSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFDO1dBQ3hFLElBQUksSUFBSSxLQUFLLFdBQVcsS0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBQzt3Q0FDakQsSUFBSSxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFDOztNQUVwRSxJQUFJLElBQUksS0FBSyxXQUFXLFVBQVUsSUFBSSxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxRQUFRLEVBQUM7V0FDL0UsSUFBSSxJQUFJLEtBQUssWUFBWSxJQUFJLElBQUksSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBQzt3Q0FDeEQsSUFBSSxJQUFJLEdBQUcsR0FBRyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBQzs7TUFFM0UsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFJOztNQUVqQixJQUFJLE9BQU8sQ0FBQyxLQUFLLEtBQUssSUFBSSxLQUFLLFlBQVksSUFBSSxJQUFJLEtBQUssV0FBVyxDQUFDLEVBQUU7UUFDcEUsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLFFBQVEsRUFBRSxJQUFJLEtBQUssWUFBWSxFQUFDO1FBQ2pFLElBQUksQ0FBQyxhQUFhLEdBQUcsT0FBTTtPQUM1QjtLQUNGOztJQUVELE9BQU87TUFDTCxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxFQUFFLElBQUk7S0FDMUM7R0FDRjs7RUFFRCxjQUFjLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLGlCQUFpQixDQUFDLEVBQUU7SUFDaEQsSUFBSSxNQUFNLElBQUksQ0FBQyxFQUFFLE1BQU0sR0FBRyxJQUFJLENBQUMsY0FBYTtJQUM1QyxJQUFJLGlCQUFpQixJQUFJLE1BQU0sRUFBRSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsV0FBVTs7SUFFcEUsT0FBTyxDQUFDO2lCQUNLLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQzs7WUFFbEIsRUFBRSxpQkFBaUIsQ0FBQztpQkFDZixFQUFFLElBQUksQ0FBQzs7bUJBRUwsRUFBRSxNQUFNLENBQUM7SUFDeEIsQ0FBQztHQUNGOztFQUVELEtBQUssQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLFNBQVMsR0FBRyxLQUFLLEVBQUU7SUFDcEMsSUFBSSxTQUFTLEVBQUU7TUFDYixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUM7UUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFDO0tBQzlCO1NBQ0ksSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztNQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUM7O0lBRTdCLE9BQU8sS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztHQUN6QjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLFlBQVksQ0FBQzs7QUNqRjdDLE1BQU0sZUFBZSxTQUFTLFNBQVMsQ0FBQztFQUM3QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFDO0lBQ25DLElBQUksQ0FBQyxJQUFJLFNBQVMsV0FBVTtHQUM3Qjs7RUFFRCxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLENBQUMsRUFBRTtJQUNqQyxJQUFJLE1BQU0sZ0JBQWdCLE9BQU8sQ0FBQyxLQUFLLEdBQUcsRUFBRSxHQUFHLEVBQUM7SUFDaEQsSUFBSSxRQUFRLGNBQWMsc0JBQXFCO0lBQy9DLElBQUksaUJBQWlCLEtBQUssS0FBSTtJQUM5QixJQUFJLElBQUksa0JBQWtCLGNBQWE7OztJQUd2QyxJQUFJLE9BQU8sQ0FBQyxHQUFHLEVBQUU7TUFDZixJQUFJLEVBQUUsTUFBSzs7TUFFWCxJQUFJLElBQUksS0FBSyxXQUFXO1FBQ3RCLFFBQVEsSUFBSSxXQUFVO01BQ3hCLElBQUksSUFBSSxLQUFLLFNBQVM7UUFDcEIsUUFBUSxJQUFJLFdBQVU7S0FDekI7U0FDSSxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxLQUFLLFlBQVksRUFBRTtNQUN0RCxJQUFJLEdBQUcsYUFBWTs7TUFFbkIsSUFBSSxJQUFJLEtBQUssV0FBVztRQUN0QixRQUFRLElBQUksV0FBVTtNQUN4QixJQUFJLElBQUksS0FBSyxZQUFZO1FBQ3ZCLFFBQVEsSUFBSSxXQUFVO0tBQ3pCOztTQUVJLElBQUksSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssV0FBVyxFQUFFO01BQ25ELElBQUksR0FBRyxZQUFXOztNQUVsQixJQUFJLElBQUksS0FBSyxXQUFXO1FBQ3RCLFFBQVEsSUFBSSxXQUFVO01BQ3hCLElBQUksSUFBSSxLQUFLLFNBQVM7UUFDcEIsUUFBUSxJQUFJLFdBQVU7S0FDekI7O0lBRUQsT0FBTztNQUNMLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxNQUFNLEVBQUUsSUFBSTtLQUMxQztHQUNGOztFQUVELGNBQWMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUU7SUFDMUQsSUFBSSxRQUFRLEtBQUssQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQztNQUM5QixRQUFRLEdBQUcsc0JBQXFCO0lBQ2xDLElBQUksaUJBQWlCLEtBQUssTUFBTTtNQUM5QixpQkFBaUIsR0FBRyxPQUFNOztJQUU1QixPQUFPLENBQUM7cUJBQ1MsRUFBRSxRQUFRLENBQUM7c0JBQ1YsRUFBRSxJQUFJLENBQUM7a0JBQ1gsRUFBRSxpQkFBaUIsQ0FBQzttQkFDbkIsRUFBRSxNQUFNLENBQUM7SUFDeEIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxlQUFlLENBQUM7O0FDOURuRCxNQUFNLGdCQUFnQixTQUFTLFNBQVMsQ0FBQztFQUM5QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFDO0lBQ25DLElBQUksQ0FBQyxJQUFJLFNBQVMsWUFBVztHQUM5Qjs7RUFFRCxpQkFBaUIsR0FBRyxFQUFFOztFQUV0QixJQUFJLEdBQUc7SUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU07R0FDekM7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Ozs7WUFJVixFQUFFQSxTQUFJLENBQUM7WUFDUCxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7Ozs7Ozs7SUFPckIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRSxnQkFBZ0IsQ0FBQzs7QUNqQ3JELE1BQU0sZUFBZSxTQUFTLFNBQVMsQ0FBQztFQUM3QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFDO0lBQ2xDLElBQUksQ0FBQyxJQUFJLFNBQVMsV0FBVTtHQUM3Qjs7RUFFRCxpQkFBaUIsR0FBRyxFQUFFOztFQUV0QixJQUFJLEdBQUc7SUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU07R0FDekM7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Ozs7WUFJVixFQUFFQSxRQUFJLENBQUM7WUFDUCxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7Ozs7Ozs7SUFPckIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxlQUFlLENBQUM7O0FDbENuRCxNQUFNLFdBQVcsU0FBUyxTQUFTLENBQUM7RUFDekMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBQztJQUNuQyxJQUFJLENBQUMsSUFBSSxTQUFTLE9BQU07R0FDekI7O0VBRUQsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUU7SUFDakMsSUFBSSxNQUFNLGdCQUFnQixPQUFPLENBQUMsS0FBSyxHQUFHLEVBQUUsR0FBRyxFQUFDO0lBQ2hELElBQUksUUFBUSxjQUFjLHNCQUFxQjtJQUMvQyxJQUFJLGlCQUFpQixLQUFLLEtBQUk7SUFDOUIsSUFBSSxJQUFJLGtCQUFrQixjQUFhOzs7SUFHdkMsSUFBSSxPQUFPLENBQUMsS0FBSyxLQUFLLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxLQUFLLFlBQVksQ0FBQyxFQUFFO01BQ3BFLElBQUksTUFBTSxVQUFTO01BQ25CLE1BQU0sSUFBSSxNQUFLOztNQUVmLElBQUksSUFBSSxLQUFLLFdBQVc7UUFDdEIsUUFBUSxJQUFJLFdBQVU7TUFDeEIsSUFBSSxJQUFJLEtBQUssWUFBWTtRQUN2QixRQUFRLElBQUksV0FBVTtLQUN6Qjs7U0FFSSxJQUFJLE9BQU8sQ0FBQyxLQUFLLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssV0FBVyxDQUFDLEVBQUU7TUFDdEUsSUFBSSxNQUFNLFVBQVM7TUFDbkIsTUFBTSxJQUFJLE1BQUs7O01BRWYsSUFBSSxJQUFJLEtBQUssU0FBUztRQUNwQixRQUFRLElBQUksV0FBVTtNQUN4QixJQUFJLElBQUksS0FBSyxXQUFXO1FBQ3RCLFFBQVEsSUFBSSxXQUFVO0tBQ3pCOztTQUVJLElBQUksT0FBTyxDQUFDLEdBQUcsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLElBQUksS0FBSyxXQUFXLENBQUMsRUFBRTtNQUNwRSxJQUFJLGtCQUFrQixjQUFhO01BQ25DLE1BQU0sZ0JBQWdCLEdBQUU7TUFDeEIsaUJBQWlCLEtBQUssR0FBRTs7TUFFeEIsSUFBSSxJQUFJLEtBQUssU0FBUztRQUNwQixRQUFRLElBQUksV0FBVTtNQUN4QixJQUFJLElBQUksS0FBSyxXQUFXO1FBQ3RCLFFBQVEsSUFBSSxXQUFVO0tBQ3pCOztTQUVJLElBQUksSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssV0FBVyxFQUFFO01BQ25ELElBQUksTUFBTSxZQUFXO01BQ3JCLE1BQU0sSUFBSSxNQUFLOztNQUVmLElBQUksSUFBSSxLQUFLLFNBQVM7UUFDcEIsUUFBUSxJQUFJLFdBQVU7TUFDeEIsSUFBSSxJQUFJLEtBQUssV0FBVztRQUN0QixRQUFRLElBQUksV0FBVTtLQUN6Qjs7U0FFSSxJQUFJLElBQUksS0FBSyxZQUFZLElBQUksSUFBSSxLQUFLLFdBQVcsRUFBRTtNQUN0RCxJQUFJLGtCQUFrQixpQkFBZ0I7TUFDdEMsTUFBTSxnQkFBZ0IsR0FBRTtNQUN4QixRQUFRLGNBQWMsU0FBUTtNQUM5QixpQkFBaUIsS0FBSyxHQUFFO0tBQ3pCOztJQUVELE9BQU87TUFDTCxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxFQUFFLElBQUk7S0FDMUM7R0FDRjs7RUFFRCxjQUFjLENBQUMsQ0FBQyxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLE1BQU0sQ0FBQyxFQUFFO0lBQzFELElBQUksUUFBUSxLQUFLLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUM7TUFDOUIsUUFBUSxHQUFHLHNCQUFxQjtJQUNsQyxJQUFJLGlCQUFpQixLQUFLLE1BQU07TUFDOUIsaUJBQWlCLEdBQUcsT0FBTTs7SUFFNUIsT0FBTyxDQUFDO3FCQUNTLEVBQUUsUUFBUSxDQUFDO3NCQUNWLEVBQUUsSUFBSSxDQUFDO2tCQUNYLEVBQUUsaUJBQWlCLENBQUM7bUJBQ25CLEVBQUUsTUFBTSxDQUFDO0lBQ3hCLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLFdBQVcsQ0FBQzs7QUNwRjNDLE1BQU0sV0FBVyxTQUFTLFNBQVMsQ0FBQztFQUN6QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLElBQUksR0FBRTtJQUNwQixJQUFJLENBQUMsSUFBSSxTQUFTLE9BQU07R0FDekI7O0VBRUQsaUJBQWlCLEdBQUcsRUFBRTs7RUFFdEIsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFNO0dBQ3pDOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDOzs7O1lBSVYsRUFBRUEsSUFBSSxDQUFDO1lBQ1AsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzs7Ozs7O0lBT3JCLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLFdBQVcsQ0FBQzs7QUNqQzNDLE1BQU0sYUFBYSxTQUFTLFNBQVMsQ0FBQztFQUMzQyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLElBQUksR0FBRTtJQUNwQixJQUFJLENBQUMsSUFBSSxTQUFTLFNBQVE7R0FDM0I7O0VBRUQsaUJBQWlCLEdBQUcsRUFBRTs7RUFFdEIsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFNO0dBQ3pDOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDOzs7O1lBSVYsRUFBRUEsTUFBSSxDQUFDO1lBQ1AsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzs7Ozs7O0lBT3JCLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsYUFBYSxDQUFDOztBQ25CL0MsTUFBTSxPQUFPLFNBQVMsV0FBVyxDQUFDOztFQUV2QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLFFBQVEsR0FBRztNQUNkLE1BQU0sVUFBVSxRQUFRLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDO01BQ3hELFNBQVMsT0FBTyxRQUFRLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDO01BQzNELGFBQWEsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLHVCQUF1QixDQUFDO01BQy9ELElBQUksWUFBWSxRQUFRLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQztNQUN0RCxNQUFNLFVBQVUsUUFBUSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQztNQUN4RCxPQUFPLFNBQVMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQztNQUN6RCxLQUFLLFdBQVcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxlQUFlLENBQUM7TUFDdkQsUUFBUSxRQUFRLFFBQVEsQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUM7TUFDMUQsU0FBUyxPQUFPLFFBQVEsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUM7TUFDM0QsUUFBUSxRQUFRLFFBQVEsQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUM7TUFDMUQsSUFBSSxZQUFZLFFBQVEsQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDO01BQ3RELElBQUksWUFBWSxRQUFRLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQztNQUN0RCxNQUFNLFVBQVUsUUFBUSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQztNQUN6RDs7SUFFRCxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSTtNQUN2QyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFDO0dBQzFCOztFQUVELGlCQUFpQixHQUFHO0lBQ2xCLE9BQU8sQ0FBQyxTQUFTLEVBQUUsQ0FBQztNQUNsQixJQUFJLENBQUMsUUFBUTtVQUNULElBQUksQ0FBQyxRQUFRLEVBQUU7VUFDZixJQUFJLENBQUMsUUFBUSxFQUFFLEVBQUM7O0lBRXRCLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUUsRUFBQztHQUNyQzs7RUFFRCxvQkFBb0IsR0FBRyxFQUFFOztFQUV6QixRQUFRLEdBQUc7SUFDVCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxNQUFNO0lBQzFCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFFO0lBQ3BCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSTtHQUNyQjs7RUFFRCxRQUFRLEdBQUc7SUFDVCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRO01BQzNCLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUM7SUFDN0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEdBQUU7R0FDckI7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLE9BQU8sQ0FBQzs7QUMvRGhEO0FBQ0EsTUFBTSxVQUFVLEdBQUcsb0JBQW9CO0dBQ3BDLEtBQUssQ0FBQyxHQUFHLENBQUM7R0FDVixNQUFNLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSztJQUNwQixDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuRSxFQUFFLENBQUM7R0FDSixTQUFTLENBQUMsQ0FBQyxFQUFDOztBQUVmLE1BQU0sY0FBYyxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsV0FBVyxFQUFDOztBQUVoRyxBQUFPLFNBQVMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUU7RUFDbEMsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDbEMsSUFBSSxDQUFDLENBQUMsWUFBWSxFQUFFLE1BQU07O0lBRTFCLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsV0FBVyxDQUFDLFNBQVMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUM7R0FDdEMsRUFBQzs7RUFFRixPQUFPLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUN0QyxDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLG1CQUFtQixDQUFDLFNBQVMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUM7R0FDOUMsRUFBQzs7RUFFRixPQUFPLE1BQU07SUFDWCxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBQztJQUMxQixPQUFPLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBQztJQUM5QixPQUFPLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUFDO0dBQ3JDO0NBQ0Y7O0FBRUQsQUFBTyxTQUFTLFdBQVcsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFO0VBQzFDLEdBQUc7S0FDQSxHQUFHLENBQUMsRUFBRSxJQUFJLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0tBQy9CLEdBQUcsQ0FBQyxFQUFFLEtBQUs7TUFDVixFQUFFO01BQ0YsS0FBSyxLQUFLLFFBQVEsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDO01BQ3ZDLE9BQU8sR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxRQUFRLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO01BQ25FLE1BQU0sSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztNQUN6RCxRQUFRLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDO0tBQy9DLENBQUMsQ0FBQztLQUNGLEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsTUFBTSxFQUFFLE9BQU8sQ0FBQyxRQUFRO1lBQ3BCLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU07WUFDaEMsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTTtPQUNyQyxDQUFDLENBQUM7S0FDSixPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDO01BQzNCLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLE1BQU0sR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBQztDQUN0RDs7QUFFRCxBQUFPLFNBQVMsbUJBQW1CLENBQUMsR0FBRyxFQUFFLFVBQVUsRUFBRTtFQUNuRCxNQUFNLEtBQUssR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBQztFQUNuQyxJQUFJLEtBQUssR0FBRyxHQUFFOztFQUVkLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxLQUFLLEdBQUcsUUFBUSxHQUFHLE1BQUs7RUFDdEQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLEdBQUcsTUFBSzs7RUFFcEQsb0JBQW9CLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztLQUM1QixPQUFPLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQyxHQUFHLEVBQUUsS0FBSyxHQUFHLElBQUksQ0FBQyxFQUFDO0NBQ25EOztBQzNERCxNQUFNQyxZQUFVLEdBQUcscUJBQW9COzs7O0FBSXZDLEFBQU8sU0FBUyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRTtFQUNwQyxPQUFPLENBQUNBLFlBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLO0lBQ2hDLElBQUksQ0FBQyxDQUFDLFlBQVksRUFBRSxNQUFNOztJQUUxQixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLENBQUMsQ0FBQyxlQUFlLEdBQUU7O0lBRW5CLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUk7TUFDeEIsV0FBVyxDQUFDLEVBQUUsRUFBRSxHQUFHLEVBQUM7TUFDcEIsY0FBYyxDQUFDLEVBQUUsRUFBQztLQUNuQixFQUFDO0dBQ0gsRUFBQzs7RUFFRixPQUFPLE1BQU07SUFDWCxPQUFPLENBQUMsTUFBTSxDQUFDQSxZQUFVLEVBQUM7R0FDM0I7Q0FDRjs7QUFFRCxBQUFPLFNBQVMsV0FBVyxDQUFDLEVBQUUsRUFBRSxTQUFTLEVBQUU7RUFDekMsSUFBSSxDQUFDLEVBQUUsRUFBRSxNQUFNOztFQUVmLE9BQU8sU0FBUztJQUNkLEtBQUssTUFBTTtNQUNULElBQUksV0FBVyxDQUFDLEVBQUUsQ0FBQztRQUNqQixFQUFFLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLHNCQUFzQixFQUFDOztRQUV6RCxRQUFRLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBQztNQUN6QixLQUFLOztJQUVQLEtBQUssT0FBTztNQUNWLElBQUksWUFBWSxDQUFDLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXO1FBQ3ZELEVBQUUsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsa0JBQWtCLENBQUMsV0FBVyxFQUFDO1dBQzlELElBQUksWUFBWSxDQUFDLEVBQUUsQ0FBQztRQUN2QixFQUFFLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxFQUFFLEVBQUM7O1FBRTdCLFFBQVEsQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFDO01BQ3pCLEtBQUs7O0lBRVAsS0FBSyxJQUFJO01BQ1AsSUFBSSxTQUFTLENBQUMsRUFBRSxDQUFDO1FBQ2YsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUM7TUFDZCxLQUFLOztJQUVQLEtBQUssTUFBTTtNQUNULElBQUksWUFBWSxDQUFDLEVBQUUsQ0FBQztRQUNsQixNQUFNLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFDO1dBQ3RCLElBQUksV0FBVyxDQUFDLEVBQUUsQ0FBQztRQUN0QixFQUFFLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBQztNQUNuQyxLQUFLO0dBQ1I7Q0FDRjs7QUFFRCxBQUFPLE1BQU0sV0FBVyxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUMsdUJBQXNCO0FBQzdELEFBQU8sTUFBTSxZQUFZLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxtQkFBa0I7QUFDekQsQUFBTyxNQUFNLFdBQVcsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDLGtCQUFrQixJQUFJLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsT0FBTTtBQUNsRyxBQUFPLE1BQU0sWUFBWSxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsSUFBSSxFQUFFLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsV0FBVTtBQUN2RyxBQUFPLE1BQU0sU0FBUyxRQUFRLEVBQUUsSUFBSSxFQUFFLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsV0FBVTs7QUFFN0UsQUFBTyxNQUFNLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssR0FBRyxLQUFLLENBQUM7RUFDeEMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEVBQUU7SUFDdEMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsUUFBUTtNQUMvQixLQUFLO1VBQ0QsWUFBWSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUM7VUFDcEIsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUM7O0FBRTVCLEFBQU8sU0FBUyxjQUFjLENBQUMsRUFBRSxFQUFFO0VBQ2pDLElBQUksT0FBTyxHQUFHLEdBQUU7O0VBRWhCLElBQUksV0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sSUFBSSxJQUFHO0VBQ3BDLElBQUksWUFBWSxDQUFDLEVBQUUsQ0FBQyxFQUFFLE9BQU8sSUFBSSxJQUFHO0VBQ3BDLElBQUksV0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sSUFBSSxJQUFHO0VBQ3BDLElBQUksU0FBUyxDQUFDLEVBQUUsQ0FBQyxLQUFLLE9BQU8sSUFBSSxJQUFHOztFQUVwQyxPQUFPLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLGtCQUFrQixFQUFDOzs7Q0FDMUQsREM5RUQsSUFBSSxJQUFJLFFBQVEsRUFBRTtJQUNkLFFBQVEsSUFBSSxFQUFFO0lBQ2QsU0FBUTs7QUFFWixBQUFPLFNBQVMsb0JBQW9CLEdBQUc7RUFDckMsSUFBSSxHQUFHLENBQUMsQ0FBQztJQUNQLEdBQUcsUUFBUSxDQUFDLE1BQU07SUFDbEIsR0FBRyxvQkFBb0IsQ0FBQyxRQUFRLENBQUM7R0FDbEMsRUFBQzs7RUFFRixhQUFhLENBQUMsSUFBSSxFQUFDO0VBQ25CLFlBQVksQ0FBQyxJQUFJLEVBQUM7Q0FDbkI7O0FBRUQsTUFBTSxZQUFZLEdBQUcsSUFBSSxJQUFJO0VBQzNCLElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBQztFQUNoQyxJQUFJLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUM7RUFDakMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFDO0VBQ3ZCLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRSxXQUFXLEVBQUM7RUFDNUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBQztFQUM3QyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFDO0VBQ25DLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUM7RUFDN0MsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBQztFQUMxQzs7QUFFRCxNQUFNLGFBQWEsR0FBRyxJQUFJLElBQUk7RUFDNUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFDO0VBQ2xDLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBQztFQUNsQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUM7RUFDeEIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBQztFQUM5QyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFDO0VBQzlDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUM7RUFDcEMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBQztFQUM3QyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFDO0VBQ3pDLElBQUksR0FBRyxHQUFFO0VBQ1Y7O0FBRUQsTUFBTSxXQUFXLEdBQUcsSUFBSSxJQUFJO0VBQzFCLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxLQUFLO0lBQ3RDLElBQUksTUFBTSxHQUFHLElBQUksVUFBVSxHQUFFO0lBQzdCLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFDO0lBQzFCLE1BQU0sQ0FBQyxTQUFTLEdBQUcsTUFBTSxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBQztHQUNoRCxDQUFDO0VBQ0g7OztBQUdELE1BQU0sV0FBVyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUM7RUFDM0IsUUFBUSxHQUFHLE9BQU07O0FBRW5CLE1BQU0sU0FBUyxHQUFHLENBQUM7RUFDakIsUUFBUSxHQUFHLFVBQVM7O0FBRXRCLE1BQU0sV0FBVyxHQUFHLENBQUMsSUFBSTtFQUN2QixDQUFDLENBQUMsY0FBYyxHQUFFO0VBQ2xCLE1BQU0sWUFBWSxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsRUFBQzs7RUFFakQsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNO0lBQ3RCLFdBQVcsQ0FBQyxDQUFDLENBQUMsYUFBYSxFQUFFLENBQUMsRUFBQzs7SUFFL0IsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO01BQzFCLFdBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUM7RUFDekI7O0FBRUQsTUFBTSxXQUFXLEdBQUcsQ0FBQztFQUNuQixZQUFZLEdBQUU7OztBQUdoQixNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsSUFBSTtFQUN4QixDQUFDLENBQUMsZUFBZSxHQUFFO0VBQ25CLENBQUMsQ0FBQyxjQUFjLEdBQUU7O0VBRWxCLE1BQU0sY0FBYyxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsRUFBQzs7RUFFbkQsTUFBTSxJQUFJLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsTUFBTTtNQUNwQyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO09BQzFDLE1BQU0sQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7T0FDM0MsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO01BQ2xCLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBQzs7RUFFbEIsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO0lBQ2YsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNO01BQ3hCLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssS0FBSztRQUM3QixDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsQ0FBQyxFQUFDOztRQUV0QixJQUFJO1dBQ0QsTUFBTSxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztXQUNyQyxPQUFPLENBQUMsR0FBRztZQUNWLEdBQUcsQ0FBQyxLQUFLLENBQUMsZUFBZSxHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQztTQUNqRCxJQUFJLGNBQWMsQ0FBQyxNQUFNLEVBQUU7TUFDOUIsSUFBSSxDQUFDLEdBQUcsRUFBQztNQUNULGNBQWMsQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJO1FBQzVCLEdBQUcsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMsRUFBRSxFQUFDO1FBQ25CLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLEVBQUM7T0FDNUIsRUFBQztLQUNIO0dBQ0Y7O0VBRUQsWUFBWSxHQUFFO0VBQ2Y7O0FBRUQsTUFBTSxXQUFXLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLO0VBQy9CLE1BQU0sSUFBSSxNQUFNLElBQUksQ0FBQyxxQkFBcUIsR0FBRTtFQUM1QyxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUFDOztFQUUzQixJQUFJLE9BQU8sRUFBRTtJQUNYLE9BQU8sQ0FBQyxNQUFNLEdBQUcsS0FBSTtHQUN0QjtPQUNJO0lBQ0gsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLEVBQUM7SUFDdEQsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxLQUFJO0lBQzNCLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBQztHQUN2QztFQUNGOztBQUVELE1BQU0sWUFBWSxHQUFHLE1BQU07RUFDekIsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPO0lBQ3RCLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBQztFQUNuQixRQUFRLEdBQUcsR0FBRTtFQUNkOztBQUVELE1BQU0sb0JBQW9CLEdBQUcsRUFBRSxJQUFJO0VBQ2pDLE1BQU0sU0FBUyxHQUFHLDJDQUEwQzs7RUFFNUQsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxFQUFFLElBQUksS0FBSztJQUN6QyxNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSSxFQUFFLGtCQUFrQixFQUFDO0lBQy9DLE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDOzs7SUFHbEMsSUFBSSxLQUFLLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUM7O0lBRWhDLE9BQU8sVUFBVTtHQUNsQixFQUFFLEVBQUUsQ0FBQztDQUNQOztBQ3ZJRDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxBQUFPLFNBQVMsb0JBQW9CLENBQUMsUUFBUSxFQUFFLElBQUksR0FBRyxRQUFRLEVBQUU7SUFDNUQsT0FBTyxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO0NBQ25EO0FBQ0QsQUFJQTtBQUNBLFNBQVMsa0JBQWtCLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7SUFDbEQsSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQzs7SUFFaEQsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLGdCQUFnQixJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFOztRQUU5RCxJQUFJLENBQUMsUUFBUSxJQUFJLFlBQVksRUFBRTtZQUMzQixPQUFPLFlBQVksQ0FBQztTQUN2Qjs7O1FBR0QsTUFBTSxnQkFBZ0IsR0FBRyw0QkFBNEIsQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUM7O1FBRXJFLE9BQU8sZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLGVBQWUsS0FBSzs7WUFFckQsSUFBSSxDQUFDLFFBQVEsSUFBSSxHQUFHLEVBQUU7Z0JBQ2xCLE9BQU8sR0FBRyxDQUFDO2FBQ2Q7O1lBRUQsTUFBTSxhQUFhLEdBQUcsNEJBQTRCLENBQUMsZUFBZTs7cUJBRXpELE9BQU8sQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDO3FCQUNwQixPQUFPLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDOztpQkFFMUMsTUFBTSxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNoQyxNQUFNLHFCQUFxQixHQUFHLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1lBQ3ZELE1BQU0sZ0JBQWdCLEdBQUcsc0JBQXNCLENBQUMsYUFBYSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDNUYsTUFBTSxZQUFZLEdBQUcsbUJBQW1CLENBQUMsYUFBYSxFQUFFLHFCQUFxQixFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3JGLElBQUksUUFBUSxFQUFFO2dCQUNWLEdBQUcsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO2dCQUN4RCxPQUFPLEdBQUcsQ0FBQzthQUNkLE1BQU07Z0JBQ0gsR0FBRyxHQUFHLGdCQUFnQixDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDMUMsT0FBTyxHQUFHLElBQUksSUFBSSxDQUFDO2FBQ3RCO1NBQ0osRUFBRSxRQUFRLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDOzs7S0FHNUIsTUFBTTtRQUNILElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDWCxPQUFPLFlBQVksQ0FBQztTQUN2QixNQUFNO1lBQ0gsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDMUM7S0FDSjs7Q0FFSjs7QUFFRCxTQUFTLG1CQUFtQixDQUFDLGFBQWEsRUFBRSxxQkFBcUIsRUFBRSxJQUFJLEVBQUU7SUFDckUsT0FBTyxDQUFDLE9BQU8sS0FBSztRQUNoQixJQUFJLFFBQVEsR0FBRyxxQkFBcUIsQ0FBQztRQUNyQyxJQUFJLE1BQU0sR0FBRyxPQUFPLENBQUM7UUFDckIsSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDO1FBQ3pCLE9BQU8sTUFBTSxFQUFFO1lBQ1gsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUMzRCxJQUFJLFVBQVUsSUFBSSxRQUFRLEtBQUssQ0FBQyxFQUFFO2dCQUM5QixZQUFZLEdBQUcsSUFBSSxDQUFDO2dCQUNwQixNQUFNO2FBQ1Q7WUFDRCxJQUFJLFVBQVUsRUFBRTtnQkFDWixRQUFRLEVBQUUsQ0FBQzthQUNkO1lBQ0QsTUFBTSxHQUFHLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztTQUMzQztRQUNELE9BQU8sWUFBWSxDQUFDO0tBQ3ZCLENBQUM7O0NBRUw7O0FBRUQsU0FBUyw0QkFBNEIsQ0FBQyxRQUFRLEVBQUUsU0FBUyxFQUFFO0lBQ3ZELE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLO1FBQy9DLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUU7WUFDeEIsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUM7WUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM1QixNQUFNLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7WUFDL0IsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7WUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs7U0FFNUIsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxLQUFLLFNBQVMsRUFBRTtZQUNqRCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUNoQixNQUFNO1lBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDNUI7UUFDRCxPQUFPLENBQUMsQ0FBQztLQUNaLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0NBQ3JCOzs7QUFHRCxTQUFTLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUU7SUFDckMsTUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQztJQUN0QyxPQUFPLENBQUMsVUFBVSxJQUFJLFVBQVUsQ0FBQyxJQUFJLElBQUksVUFBVSxDQUFDLFFBQVEsS0FBSyxFQUFFLElBQUksVUFBVSxDQUFDLElBQUksR0FBRyxVQUFVLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxVQUFVLENBQUM7Q0FDcEk7Ozs7Ozs7OztBQVNELFNBQVMsc0JBQXNCLENBQUMsUUFBUSxHQUFHLElBQUksRUFBRSxJQUFJLEVBQUU7SUFDbkQsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDOztJQUV2QixNQUFNLGVBQWUsR0FBRyxTQUFTLEtBQUssRUFBRTtRQUNwQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUNwQyxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDOztZQUVyQixJQUFJLEVBQUUsQ0FBQyxVQUFVLEVBQUU7Z0JBQ2YsZUFBZSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQzthQUN4RDtTQUNKO0tBQ0osQ0FBQztJQUNGLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRTtRQUNoQixlQUFlLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0tBQzFEO0lBQ0QsZUFBZSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDOztJQUU1QyxPQUFPLFFBQVEsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsV0FBVyxDQUFDOzs7Q0FDbEYsRENoSk0sTUFBTSxRQUFRLEdBQUc7RUFDdEIsWUFBWTtFQUNaLFlBQVk7RUFDWixjQUFjO0VBQ2Y7O0FBRUQsQUFBZSx3QkFBUSxHQUFHO0VBQ3hCLFFBQVE7S0FDTCxnQkFBZ0IsQ0FBQyxtQ0FBbUMsQ0FBQztLQUNyRCxPQUFPLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBQztDQUNsQzs7QUNWTSxNQUFNQyxVQUFRLEdBQUc7RUFDdEIsYUFBYTtFQUNiLGtCQUFrQjtFQUNuQjs7QUFFRCxBQUFlLCtCQUFjLEdBQUc7RUFDOUIsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxHQUFHLGNBQWE7O0VBRW5ELE1BQU0sUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDMUIsRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFO0lBQzNCLEVBQUUsU0FBUyxFQUFFLGdCQUFnQixFQUFFO0dBQ2hDLEVBQUUsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxTQUFROztFQUUvQixRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxlQUFlLEdBQUcsR0FBRTs7O0NBQ3pDLERDWk0sTUFBTUEsVUFBUSxHQUFHO0VBQ3RCLFdBQVc7RUFDWjs7QUFFRCxBQUFlLDhCQUFjLEdBQUc7RUFDOUIsTUFBTSxVQUFVLENBQUMsQ0FBQyx5REFBeUQsQ0FBQyxFQUFDOzs7Q0FDOUUsRENOTSxNQUFNQSxVQUFRLEdBQUc7RUFDdEIsUUFBUTtFQUNSLFdBQVc7RUFDWjs7QUFFRCxBQUFlLDhCQUFjLEdBQUc7RUFDOUIsTUFBTSxVQUFVLENBQUMsQ0FBQyw2RUFBNkUsQ0FBQyxFQUFDOzs7Q0FDbEcsRENQTSxNQUFNQSxVQUFRLEdBQUc7RUFDdEIsY0FBYztFQUNkLGlCQUFpQjtFQUNsQjs7QUFFRCxBQUFlLG1DQUFjLEdBQUc7RUFDOUIsTUFBTSxVQUFVLENBQUMsQ0FBQyw2RUFBNkUsQ0FBQyxFQUFDOzs7Q0FDbEcsRENUTSxNQUFNQSxVQUFRLEdBQUc7RUFDdEIsV0FBVztFQUNYLFdBQVc7RUFDWjs7QUFFRCxBQUFlLDhCQUFjLEdBQUc7RUFDOUIsTUFBTSxNQUFNLEdBQUcsQ0FBQzs7Ozs7OztFQU9oQixFQUFDOztFQUVELE1BQU0sS0FBSyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFDO0VBQzdDLEtBQUssQ0FBQyxXQUFXLEdBQUcsT0FBTTtFQUMxQixRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUM7OztDQUNqQyxEQ2xCTSxNQUFNQSxVQUFRLEdBQUc7RUFDdEIsVUFBVTtFQUNWLFNBQVM7RUFDVjs7QUFFRCxBQUFlLDZCQUFjLEdBQUc7RUFDOUIsTUFBTSxNQUFNLEdBQUcsQ0FBQzs7Ozs7Ozs7O0VBU2hCLEVBQUM7O0VBRUQsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUM7RUFDN0MsS0FBSyxDQUFDLFdBQVcsR0FBRyxPQUFNO0VBQzFCLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBQzs7O0FDbkJsQztBQUNBLEFBQU8sTUFBTUEsVUFBUSxHQUFHO0VBQ3RCLGNBQWM7RUFDZCxRQUFRO0VBQ1Q7O0FBRUQsQUFBZSxnQ0FBYyxHQUFHO0VBQzlCLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQ2pELENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBQzs7O0FDUmhFO0FBQ0EsQUFFQTtBQUNBLEFBQU8sTUFBTUEsVUFBUSxHQUFHO0VBQ3RCLFNBQVM7RUFDVCxhQUFhO0VBQ2IsUUFBUTtFQUNUOztBQUVELEFBQWUsNEJBQWMsR0FBRztFQUM5QixNQUFNLFVBQVUsQ0FBQyxDQUFDLG1FQUFtRSxDQUFDLEVBQUM7OztDQUN4RixEQ0ZELE1BQU0sY0FBYyxHQUFHLENBQUMsZUFBZSxFQUFFLFNBQVM7RUFDaEQsZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDQSxXQUFRLEVBQUUsT0FBTztJQUN2QyxNQUFNLENBQUMsTUFBTSxDQUFDQSxXQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDcEQsRUFBRSxFQUFDOztBQUVQLEFBQU8sTUFBTSxjQUFjLEdBQUcsSUFBSSxHQUFHLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztFQUNuRCxHQUFHLGNBQWMsQ0FBQ0MsUUFBbUIsRUFBRSxlQUFlLENBQUM7RUFDdkQsR0FBRyxjQUFjLENBQUNDLFVBQW9CLEVBQUUsZ0JBQWdCLENBQUM7RUFDekQsR0FBRyxjQUFjLENBQUNDLFVBQWtCLEVBQUUsZUFBZSxDQUFDO0VBQ3RELEdBQUcsY0FBYyxDQUFDQyxVQUFrQixFQUFFLGVBQWUsQ0FBQztFQUN0RCxHQUFHLGNBQWMsQ0FBQ0MsVUFBd0IsRUFBRSxvQkFBb0IsQ0FBQztFQUNqRSxHQUFHLGNBQWMsQ0FBQ0MsVUFBa0IsRUFBRSxlQUFlLENBQUM7RUFDdEQsR0FBRyxjQUFjLENBQUNDLFVBQWlCLEVBQUUsY0FBYyxDQUFDO0VBQ3BELEdBQUcsY0FBYyxDQUFDQyxVQUFxQixFQUFFLGlCQUFpQixDQUFDO0VBQzNELEdBQUcsY0FBYyxDQUFDQyxVQUFnQixFQUFFLGFBQWEsQ0FBQztDQUNuRCxDQUFDLEVBQUM7O0FBRUgsQUFBTyxNQUFNLFdBQVcsR0FBRztFQUN6QlIsUUFBbUIsQ0FBQyxDQUFDLENBQUM7RUFDdEJDLFVBQW9CLENBQUMsQ0FBQyxDQUFDO0VBQ3ZCQyxVQUFrQixDQUFDLENBQUMsQ0FBQztFQUNyQkMsVUFBa0IsQ0FBQyxDQUFDLENBQUM7RUFDckJDLFVBQXdCLENBQUMsQ0FBQyxDQUFDO0VBQzNCQyxVQUFrQixDQUFDLENBQUMsQ0FBQztFQUNyQkMsVUFBaUIsQ0FBQyxDQUFDLENBQUM7RUFDcEJDLFVBQXFCLENBQUMsQ0FBQyxDQUFDO0VBQ3hCQyxVQUFnQixDQUFDLENBQUMsQ0FBQztDQUNwQixDQUFDLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQzs7QUNoQy9CLElBQUksZUFBYzs7O0FBR2xCLE1BQU0sV0FBVyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFDO0FBQ2pELFdBQVcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBQztBQUNuQyxXQUFXLENBQUMsU0FBUyxHQUFHLENBQUM7OztJQUdyQixFQUFFLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsT0FBTztNQUNwQyxPQUFPLElBQUksQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDLGlCQUFpQixDQUFDO01BQ3ZELEVBQUUsQ0FBQyxDQUFDOzs7Ozs7OztBQVFWLEVBQUM7O0FBRUQsTUFBTUMsUUFBTSxVQUFVLENBQUMsQ0FBQyxXQUFXLEVBQUM7QUFDcEMsTUFBTSxXQUFXLEtBQUssQ0FBQyxDQUFDLE9BQU8sRUFBRSxXQUFXLEVBQUM7O0FBRTdDLE1BQU0sYUFBYSxHQUFHLE1BQU1BLFFBQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLGVBQWUsRUFBQztBQUNqRSxNQUFNLGFBQWEsR0FBRyxNQUFNQSxRQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxjQUFjLEVBQUM7QUFDaEUsTUFBTSxZQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksUUFBUSxJQUFJLENBQUMsQ0FBQyxlQUFlLEdBQUU7O0FBRW5FLEFBQU8sU0FBUyxNQUFNLENBQUMsSUFBSSxFQUFFO0VBQzNCLElBQUksSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUNBLFFBQU0sQ0FBQyxDQUFDLENBQUMsRUFBQzs7RUFFeEMsTUFBTSxPQUFPLEdBQUcsQ0FBQyxJQUFJO0lBQ25CLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsQ0FBQyxDQUFDLGVBQWUsR0FBRTs7SUFFbkIsTUFBTSxLQUFLLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFLOztJQUU1QixNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQztNQUMxQixTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUM7SUFDcEI7O0VBRUQsV0FBVyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsT0FBTyxFQUFDO0VBQ2hDLFdBQVcsQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFLFlBQVksRUFBQzs7O0VBR3ZDLGFBQWEsR0FBRTtFQUNmLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUU7Ozs7Ozs7RUFPdEIsT0FBTyxNQUFNO0lBQ1gsYUFBYSxHQUFFO0lBQ2YsV0FBVyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFDO0lBQ25DLFdBQVcsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLFlBQVksRUFBQztJQUN4QyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxhQUFhLEVBQUM7R0FDdkM7Q0FDRjs7QUFFRCxBQUFPLFNBQVMscUJBQXFCLENBQUMsTUFBTSxFQUFFO0VBQzVDLGNBQWMsR0FBRyxPQUFNO0NBQ3hCOztBQUVELEFBQU8sU0FBUyxTQUFTLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTs7RUFFbkMsSUFBSSxjQUFjLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztJQUMzQixPQUFPLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDOztFQUV6QyxJQUFJLEtBQUssSUFBSSxPQUFPLE1BQU0sS0FBSyxHQUFHLElBQUc7RUFDckMsSUFBSSxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssR0FBRyxTQUFRO0VBQzFDLElBQUksS0FBSyxJQUFJLFFBQVEsS0FBSyxLQUFLLEdBQUcsTUFBSztFQUN2QyxJQUFJLEtBQUssSUFBSSxNQUFNLE9BQU8sS0FBSyxHQUFHLHlEQUF3RDs7RUFFMUYsSUFBSSxDQUFDLEtBQUssRUFBRSxPQUFPLGNBQWMsQ0FBQyxZQUFZLEVBQUU7RUFDaEQsSUFBSSxLQUFLLElBQUksR0FBRyxJQUFJLEtBQUssSUFBSSxHQUFHLElBQUksS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxNQUFNOztFQUV0RSxJQUFJO0lBQ0YsSUFBSSxPQUFPLEdBQUcsb0JBQW9CLENBQUMsS0FBSyxHQUFHLHNHQUFzRyxFQUFDO0lBQ2xKLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sR0FBRyxvQkFBb0IsQ0FBQyxLQUFLLEVBQUM7SUFDMUQsSUFBSSxDQUFDLEVBQUUsRUFBRSxjQUFjLENBQUMsWUFBWSxHQUFFO0lBQ3RDLElBQUksT0FBTyxDQUFDLE1BQU07TUFDaEIsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQ2hCLEVBQUU7WUFDRSxFQUFFLENBQUMsRUFBRSxDQUFDO1lBQ04sY0FBYyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBQztHQUNuQztFQUNELE9BQU8sR0FBRyxFQUFFLEVBQUU7Q0FDZjs7QUM3RkQsTUFBTSxLQUFLLEdBQUc7RUFDWixTQUFTLEdBQUcsRUFBRTtFQUNkLE1BQU0sTUFBTSxJQUFJO0VBQ2pCOztBQUVELEFBQU8sU0FBUyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsRUFBRTtFQUNyRCxJQUFJLEtBQUssQ0FBQyxNQUFNLElBQUksT0FBTyxJQUFJLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLE1BQU07T0FDeEQsS0FBSyxDQUFDLE1BQU0sR0FBRyxRQUFPOztFQUUzQixJQUFJLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLGlCQUFpQixHQUFFOztFQUUvQyxNQUFNLFlBQVksR0FBRyxPQUFPLENBQUMscUJBQXFCLEdBQUU7RUFDcEQsTUFBTSxZQUFZLEdBQUcsT0FBTyxDQUFDLHFCQUFxQixHQUFFOztFQUVwRCxNQUFNLFlBQVksR0FBRyxHQUFFOzs7RUFHdkIsSUFBSSxZQUFZLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxJQUFJLEVBQUU7SUFDMUMsWUFBWSxDQUFDLElBQUksQ0FBQztNQUNoQixDQUFDLEVBQUUsWUFBWSxDQUFDLEtBQUs7TUFDckIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxHQUFHLElBQUksWUFBWSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7TUFDL0MsQ0FBQyxFQUFFLFlBQVksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLEtBQUs7TUFDekMsQ0FBQyxFQUFFLE9BQU87S0FDWCxFQUFDO0dBQ0g7RUFDRCxJQUFJLFlBQVksQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDLEtBQUssSUFBSSxZQUFZLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxJQUFJLEVBQUU7SUFDckYsWUFBWSxDQUFDLElBQUksQ0FBQztNQUNoQixDQUFDLEVBQUUsWUFBWSxDQUFDLEtBQUs7TUFDckIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxHQUFHLElBQUksWUFBWSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7TUFDL0MsQ0FBQyxFQUFFLFlBQVksQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDLEtBQUs7TUFDMUMsQ0FBQyxFQUFFLE9BQU87S0FDWCxFQUFDO0dBQ0g7OztFQUdELElBQUksWUFBWSxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsS0FBSyxFQUFFO0lBQzFDLFlBQVksQ0FBQyxJQUFJLENBQUM7TUFDaEIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxLQUFLO01BQ3JCLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFJLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO01BQy9DLENBQUMsRUFBRSxZQUFZLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxLQUFLO01BQ3pDLENBQUMsRUFBRSxNQUFNO0tBQ1YsRUFBQztHQUNIO0VBQ0QsSUFBSSxZQUFZLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxJQUFJLElBQUksWUFBWSxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsS0FBSyxFQUFFO0lBQ25GLFlBQVksQ0FBQyxJQUFJLENBQUM7TUFDaEIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxJQUFJO01BQ3BCLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFJLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO01BQy9DLENBQUMsRUFBRSxZQUFZLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxJQUFJO01BQ3hDLENBQUMsRUFBRSxNQUFNO0tBQ1YsRUFBQztHQUNIOzs7RUFHRCxJQUFJLFlBQVksQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRTtJQUMxQyxZQUFZLENBQUMsSUFBSSxDQUFDO01BQ2hCLENBQUMsRUFBRSxZQUFZLENBQUMsSUFBSSxJQUFJLFlBQVksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO01BQy9DLENBQUMsRUFBRSxZQUFZLENBQUMsTUFBTTtNQUN0QixDQUFDLEVBQUUsWUFBWSxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUMsTUFBTTtNQUN6QyxDQUFDLEVBQUUsS0FBSztNQUNSLENBQUMsRUFBRSxJQUFJO0tBQ1IsRUFBQztHQUNIO0VBQ0QsSUFBSSxZQUFZLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQyxHQUFHLElBQUksWUFBWSxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFO0lBQ2pGLFlBQVksQ0FBQyxJQUFJLENBQUM7TUFDaEIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxJQUFJLElBQUksWUFBWSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7TUFDL0MsQ0FBQyxFQUFFLFlBQVksQ0FBQyxHQUFHO01BQ25CLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQyxHQUFHO01BQ3RDLENBQUMsRUFBRSxLQUFLO01BQ1IsQ0FBQyxFQUFFLElBQUk7S0FDUixFQUFDO0dBQ0g7OztFQUdELElBQUksWUFBWSxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUMsR0FBRyxFQUFFO0lBQzFDLFlBQVksQ0FBQyxJQUFJLENBQUM7TUFDaEIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxJQUFJLElBQUksWUFBWSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7TUFDL0MsQ0FBQyxFQUFFLFlBQVksQ0FBQyxNQUFNO01BQ3RCLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQyxNQUFNO01BQ3pDLENBQUMsRUFBRSxRQUFRO01BQ1gsQ0FBQyxFQUFFLElBQUk7S0FDUixFQUFDO0dBQ0g7RUFDRCxJQUFJLFlBQVksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDLE1BQU0sSUFBSSxZQUFZLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQyxHQUFHLEVBQUU7SUFDdkYsWUFBWSxDQUFDLElBQUksQ0FBQztNQUNoQixDQUFDLEVBQUUsWUFBWSxDQUFDLElBQUksSUFBSSxZQUFZLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztNQUMvQyxDQUFDLEVBQUUsWUFBWSxDQUFDLE1BQU07TUFDdEIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDLE1BQU07TUFDNUMsQ0FBQyxFQUFFLFFBQVE7TUFDWCxDQUFDLEVBQUUsSUFBSTtLQUNSLEVBQUM7R0FDSDs7O0VBR0QsSUFBSSxZQUFZLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxLQUFLLElBQUksWUFBWSxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsSUFBSSxFQUFFO0lBQ3BGLFlBQVksQ0FBQyxJQUFJLENBQUM7TUFDaEIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxLQUFLO01BQ3JCLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFJLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO01BQy9DLENBQUMsRUFBRSxZQUFZLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxLQUFLO01BQzFDLENBQUMsRUFBRSxNQUFNO0tBQ1YsRUFBQztJQUNGLFlBQVksQ0FBQyxJQUFJLENBQUM7TUFDaEIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxJQUFJO01BQ3BCLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFJLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO01BQy9DLENBQUMsRUFBRSxZQUFZLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxJQUFJO01BQ3hDLENBQUMsRUFBRSxPQUFPO0tBQ1gsRUFBQztHQUNIOzs7RUFHRCxJQUFJLFlBQVksQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDLEdBQUcsSUFBSSxZQUFZLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUU7SUFDcEYsWUFBWSxDQUFDLElBQUksQ0FBQztNQUNoQixDQUFDLEVBQUUsWUFBWSxDQUFDLElBQUksSUFBSSxZQUFZLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztNQUMvQyxDQUFDLEVBQUUsWUFBWSxDQUFDLEdBQUc7TUFDbkIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDLEdBQUc7TUFDdEMsQ0FBQyxFQUFFLFFBQVE7TUFDWCxDQUFDLEVBQUUsSUFBSTtLQUNSLEVBQUM7SUFDRixZQUFZLENBQUMsSUFBSSxDQUFDO01BQ2hCLENBQUMsRUFBRSxZQUFZLENBQUMsSUFBSSxJQUFJLFlBQVksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO01BQy9DLENBQUMsRUFBRSxZQUFZLENBQUMsTUFBTTtNQUN0QixDQUFDLEVBQUUsWUFBWSxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUMsTUFBTTtNQUM1QyxDQUFDLEVBQUUsS0FBSztNQUNSLENBQUMsRUFBRSxJQUFJO0tBQ1IsRUFBQztHQUNIOzs7RUFHRCxZQUFZO0tBQ1QsR0FBRyxDQUFDLFdBQVcsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRTtNQUM3QyxDQUFDLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHO0tBQ3BELENBQUMsQ0FBQztLQUNGLE9BQU8sQ0FBQyxXQUFXLElBQUk7TUFDdEIsTUFBTSxZQUFZLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsRUFBQzs7TUFFOUQsWUFBWSxDQUFDLFFBQVEsR0FBRztRQUN0QixVQUFVLE1BQU0sV0FBVztRQUMzQixhQUFhLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNO1FBQ3ZDOztNQUVELFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBQztNQUN2QyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEdBQUcsYUFBWTtLQUN2RCxFQUFDO0NBQ0w7O0FBRUQsQUFBTyxTQUFTLGlCQUFpQixHQUFHO0VBQ2xDLEtBQUssQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUM7RUFDOUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxHQUFFO0NBQ3JCOztBQ25KRDs7OztBQUlBLFNBQVMsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUU7SUFDckIsSUFBSSxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7UUFDbkIsQ0FBQyxHQUFHLE1BQU0sQ0FBQztLQUNkO0lBQ0QsTUFBTSxjQUFjLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3ZDLENBQUMsR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztJQUVoRSxJQUFJLGNBQWMsRUFBRTtRQUNoQixDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDO0tBQzNDOztJQUVELElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsUUFBUSxFQUFFO1FBQzlCLE9BQU8sQ0FBQyxDQUFDO0tBQ1o7O0lBRUQsSUFBSSxHQUFHLEtBQUssR0FBRyxFQUFFOzs7O1FBSWIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxJQUFJLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztLQUNuRTtTQUNJOzs7UUFHRCxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztLQUMzQztJQUNELE9BQU8sQ0FBQyxDQUFDO0NBQ1o7Ozs7O0FBS0QsU0FBUyxPQUFPLENBQUMsR0FBRyxFQUFFO0lBQ2xCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztDQUN4Qzs7Ozs7O0FBTUQsU0FBUyxjQUFjLENBQUMsQ0FBQyxFQUFFO0lBQ3ZCLE9BQU8sT0FBTyxDQUFDLEtBQUssUUFBUSxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztDQUNoRjs7Ozs7QUFLRCxTQUFTLFlBQVksQ0FBQyxDQUFDLEVBQUU7SUFDckIsT0FBTyxPQUFPLENBQUMsS0FBSyxRQUFRLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztDQUN6RDs7Ozs7QUFLRCxTQUFTLFVBQVUsQ0FBQyxDQUFDLEVBQUU7SUFDbkIsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNsQixJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDNUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUNUO0lBQ0QsT0FBTyxDQUFDLENBQUM7Q0FDWjs7Ozs7QUFLRCxTQUFTLG1CQUFtQixDQUFDLENBQUMsRUFBRTtJQUM1QixJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDUixPQUFPLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7S0FDekI7SUFDRCxPQUFPLENBQUMsQ0FBQztDQUNaOzs7OztBQUtELFNBQVMsSUFBSSxDQUFDLENBQUMsRUFBRTtJQUNiLE9BQU8sQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0NBQzVDOzs7Ozs7Ozs7O0FBVUQsU0FBUyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUU7SUFDdkIsT0FBTztRQUNILENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLEdBQUc7UUFDeEIsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRztRQUN4QixDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsR0FBRyxHQUFHO0tBQzNCLENBQUM7Q0FDTDs7Ozs7O0FBTUQsU0FBUyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUU7SUFDdkIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDcEIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDcEIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDcEIsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzlCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUM5QixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDVixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDVixNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDO0lBQzFCLElBQUksR0FBRyxLQUFLLEdBQUcsRUFBRTtRQUNiLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQ2I7U0FDSTtRQUNELE1BQU0sQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7UUFDcEIsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUNwRCxRQUFRLEdBQUc7WUFDUCxLQUFLLENBQUM7Z0JBQ0YsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xDLE1BQU07WUFDVixLQUFLLENBQUM7Z0JBQ0YsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNwQixNQUFNO1lBQ1YsS0FBSyxDQUFDO2dCQUNGLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDcEIsTUFBTTtTQUNiO1FBQ0QsQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUNWO0lBQ0QsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7Q0FDdEI7Ozs7Ozs7QUFPRCxTQUFTLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRTtJQUN2QixJQUFJLENBQUMsQ0FBQztJQUNOLElBQUksQ0FBQyxDQUFDO0lBQ04sSUFBSSxDQUFDLENBQUM7SUFDTixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNwQixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNwQixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNwQixTQUFTLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRTtRQUN0QixJQUFJLENBQUMsR0FBRyxDQUFDO1lBQ0wsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNYLElBQUksQ0FBQyxHQUFHLENBQUM7WUFDTCxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ1gsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQzlCO1FBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNYLE9BQU8sQ0FBQyxDQUFDO1NBQ1o7UUFDRCxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ1gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3hDO1FBQ0QsT0FBTyxDQUFDLENBQUM7S0FDWjtJQUNELElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUNULENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUNqQjtTQUNJO1FBQ0QsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNoRCxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNwQixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUM3QixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDckIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7S0FDaEM7SUFDRCxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQztDQUNqRDs7Ozs7OztBQU9ELFNBQVMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFO0lBQ3ZCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUM5QixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDOUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ1YsTUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDO0lBQ2QsTUFBTSxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztJQUNwQixNQUFNLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDO0lBQ2xDLElBQUksR0FBRyxLQUFLLEdBQUcsRUFBRTtRQUNiLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDVDtTQUNJO1FBQ0QsUUFBUSxHQUFHO1lBQ1AsS0FBSyxDQUFDO2dCQUNGLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNsQyxNQUFNO1lBQ1YsS0FBSyxDQUFDO2dCQUNGLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDcEIsTUFBTTtZQUNWLEtBQUssQ0FBQztnQkFDRixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3BCLE1BQU07U0FDYjtRQUNELENBQUMsSUFBSSxDQUFDLENBQUM7S0FDVjtJQUNELE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDO0NBQy9COzs7Ozs7O0FBT0QsU0FBUyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUU7SUFDdkIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3hCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDeEIsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNoQixNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3RCLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQzFCLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ2hDLE1BQU0sR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbEIsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2xDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNsQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbEMsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7Q0FDakQ7Ozs7Ozs7QUFPRCxTQUFTLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxVQUFVLEVBQUU7SUFDbkMsTUFBTSxHQUFHLEdBQUc7UUFDUixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUNuQyxDQUFDOztJQUVGLElBQUksVUFBVTtRQUNWLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDckMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNyQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUU7UUFDdkMsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNqRTtJQUNELE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztDQUN2Qjs7Ozs7OztBQU9ELFNBQVMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxVQUFVLEVBQUU7SUFDdkMsTUFBTSxHQUFHLEdBQUc7UUFDUixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNoQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDL0IsQ0FBQzs7SUFFRixJQUFJLFVBQVU7UUFDVixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3JDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDckMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNyQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUU7UUFDdkMsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ3BGO0lBQ0QsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0NBQ3ZCO0FBQ0QsQUFhQTtBQUNBLFNBQVMsbUJBQW1CLENBQUMsQ0FBQyxFQUFFO0lBQzVCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0NBQ3ZEOztBQUVELFNBQVMsbUJBQW1CLENBQUMsQ0FBQyxFQUFFO0lBQzVCLE9BQU8sZUFBZSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztDQUNuQzs7QUFFRCxTQUFTLGVBQWUsQ0FBQyxHQUFHLEVBQUU7SUFDMUIsT0FBTyxRQUFRLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0NBQzVCOzs7Ozs7QUFNRCxNQUFNLEtBQUssR0FBRztJQUNWLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFlBQVksRUFBRSxTQUFTO0lBQ3ZCLElBQUksRUFBRSxTQUFTO0lBQ2YsVUFBVSxFQUFFLFNBQVM7SUFDckIsS0FBSyxFQUFFLFNBQVM7SUFDaEIsS0FBSyxFQUFFLFNBQVM7SUFDaEIsTUFBTSxFQUFFLFNBQVM7SUFDakIsS0FBSyxFQUFFLFNBQVM7SUFDaEIsY0FBYyxFQUFFLFNBQVM7SUFDekIsSUFBSSxFQUFFLFNBQVM7SUFDZixVQUFVLEVBQUUsU0FBUztJQUNyQixLQUFLLEVBQUUsU0FBUztJQUNoQixTQUFTLEVBQUUsU0FBUztJQUNwQixTQUFTLEVBQUUsU0FBUztJQUNwQixVQUFVLEVBQUUsU0FBUztJQUNyQixTQUFTLEVBQUUsU0FBUztJQUNwQixLQUFLLEVBQUUsU0FBUztJQUNoQixjQUFjLEVBQUUsU0FBUztJQUN6QixRQUFRLEVBQUUsU0FBUztJQUNuQixPQUFPLEVBQUUsU0FBUztJQUNsQixJQUFJLEVBQUUsU0FBUztJQUNmLFFBQVEsRUFBRSxTQUFTO0lBQ25CLFFBQVEsRUFBRSxTQUFTO0lBQ25CLGFBQWEsRUFBRSxTQUFTO0lBQ3hCLFFBQVEsRUFBRSxTQUFTO0lBQ25CLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFFBQVEsRUFBRSxTQUFTO0lBQ25CLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLGNBQWMsRUFBRSxTQUFTO0lBQ3pCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFlBQVksRUFBRSxTQUFTO0lBQ3ZCLGFBQWEsRUFBRSxTQUFTO0lBQ3hCLGFBQWEsRUFBRSxTQUFTO0lBQ3hCLGFBQWEsRUFBRSxTQUFTO0lBQ3hCLGFBQWEsRUFBRSxTQUFTO0lBQ3hCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFFBQVEsRUFBRSxTQUFTO0lBQ25CLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLElBQUksRUFBRSxTQUFTO0lBQ2YsU0FBUyxFQUFFLFNBQVM7SUFDcEIsSUFBSSxFQUFFLFNBQVM7SUFDZixLQUFLLEVBQUUsU0FBUztJQUNoQixXQUFXLEVBQUUsU0FBUztJQUN0QixJQUFJLEVBQUUsU0FBUztJQUNmLFFBQVEsRUFBRSxTQUFTO0lBQ25CLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLEtBQUssRUFBRSxTQUFTO0lBQ2hCLEtBQUssRUFBRSxTQUFTO0lBQ2hCLFFBQVEsRUFBRSxTQUFTO0lBQ25CLGFBQWEsRUFBRSxTQUFTO0lBQ3hCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFlBQVksRUFBRSxTQUFTO0lBQ3ZCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLG9CQUFvQixFQUFFLFNBQVM7SUFDL0IsU0FBUyxFQUFFLFNBQVM7SUFDcEIsVUFBVSxFQUFFLFNBQVM7SUFDckIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsV0FBVyxFQUFFLFNBQVM7SUFDdEIsYUFBYSxFQUFFLFNBQVM7SUFDeEIsWUFBWSxFQUFFLFNBQVM7SUFDdkIsY0FBYyxFQUFFLFNBQVM7SUFDekIsY0FBYyxFQUFFLFNBQVM7SUFDekIsY0FBYyxFQUFFLFNBQVM7SUFDekIsV0FBVyxFQUFFLFNBQVM7SUFDdEIsSUFBSSxFQUFFLFNBQVM7SUFDZixTQUFTLEVBQUUsU0FBUztJQUNwQixLQUFLLEVBQUUsU0FBUztJQUNoQixPQUFPLEVBQUUsU0FBUztJQUNsQixNQUFNLEVBQUUsU0FBUztJQUNqQixnQkFBZ0IsRUFBRSxTQUFTO0lBQzNCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFlBQVksRUFBRSxTQUFTO0lBQ3ZCLFlBQVksRUFBRSxTQUFTO0lBQ3ZCLGNBQWMsRUFBRSxTQUFTO0lBQ3pCLGVBQWUsRUFBRSxTQUFTO0lBQzFCLGlCQUFpQixFQUFFLFNBQVM7SUFDNUIsZUFBZSxFQUFFLFNBQVM7SUFDMUIsZUFBZSxFQUFFLFNBQVM7SUFDMUIsWUFBWSxFQUFFLFNBQVM7SUFDdkIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsUUFBUSxFQUFFLFNBQVM7SUFDbkIsV0FBVyxFQUFFLFNBQVM7SUFDdEIsSUFBSSxFQUFFLFNBQVM7SUFDZixPQUFPLEVBQUUsU0FBUztJQUNsQixLQUFLLEVBQUUsU0FBUztJQUNoQixTQUFTLEVBQUUsU0FBUztJQUNwQixNQUFNLEVBQUUsU0FBUztJQUNqQixTQUFTLEVBQUUsU0FBUztJQUNwQixNQUFNLEVBQUUsU0FBUztJQUNqQixhQUFhLEVBQUUsU0FBUztJQUN4QixTQUFTLEVBQUUsU0FBUztJQUNwQixhQUFhLEVBQUUsU0FBUztJQUN4QixhQUFhLEVBQUUsU0FBUztJQUN4QixVQUFVLEVBQUUsU0FBUztJQUNyQixTQUFTLEVBQUUsU0FBUztJQUNwQixJQUFJLEVBQUUsU0FBUztJQUNmLElBQUksRUFBRSxTQUFTO0lBQ2YsSUFBSSxFQUFFLFNBQVM7SUFDZixVQUFVLEVBQUUsU0FBUztJQUNyQixNQUFNLEVBQUUsU0FBUztJQUNqQixhQUFhLEVBQUUsU0FBUztJQUN4QixHQUFHLEVBQUUsU0FBUztJQUNkLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFFBQVEsRUFBRSxTQUFTO0lBQ25CLFFBQVEsRUFBRSxTQUFTO0lBQ25CLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLElBQUksRUFBRSxTQUFTO0lBQ2YsV0FBVyxFQUFFLFNBQVM7SUFDdEIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsR0FBRyxFQUFFLFNBQVM7SUFDZCxJQUFJLEVBQUUsU0FBUztJQUNmLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLEtBQUssRUFBRSxTQUFTO0lBQ2hCLEtBQUssRUFBRSxTQUFTO0lBQ2hCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLFdBQVcsRUFBRSxTQUFTO0NBQ3pCLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBb0JGLFNBQVMsVUFBVSxDQUFDLEtBQUssRUFBRTtJQUN2QixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7SUFDL0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ1YsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO0lBQ2IsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO0lBQ2IsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO0lBQ2IsSUFBSSxFQUFFLEdBQUcsS0FBSyxDQUFDO0lBQ2YsSUFBSSxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQ25CLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFO1FBQzNCLEtBQUssR0FBRyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztLQUN0QztJQUNELElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFO1FBQzNCLElBQUksY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDL0UsR0FBRyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFDLEVBQUUsR0FBRyxJQUFJLENBQUM7WUFDVixNQUFNLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsTUFBTSxHQUFHLEtBQUssQ0FBQztTQUNoRTthQUNJLElBQUksY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDcEYsQ0FBQyxHQUFHLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNqQyxDQUFDLEdBQUcsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2pDLEdBQUcsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDOUIsRUFBRSxHQUFHLElBQUksQ0FBQztZQUNWLE1BQU0sR0FBRyxLQUFLLENBQUM7U0FDbEI7YUFDSSxJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3BGLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakMsQ0FBQyxHQUFHLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNqQyxHQUFHLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzlCLEVBQUUsR0FBRyxJQUFJLENBQUM7WUFDVixNQUFNLEdBQUcsS0FBSyxDQUFDO1NBQ2xCO1FBQ0QsSUFBSSxLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQzNCLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDO1NBQ2Y7S0FDSjtJQUNELENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbEIsT0FBTztRQUNILEVBQUU7UUFDRixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU0sSUFBSSxNQUFNO1FBQzlCLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNwQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BDLENBQUM7S0FDSixDQUFDO0NBQ0w7O0FBRUQsTUFBTSxXQUFXLEdBQUcsZUFBZSxDQUFDOztBQUVwQyxNQUFNLFVBQVUsR0FBRyxzQkFBc0IsQ0FBQzs7QUFFMUMsTUFBTSxRQUFRLEdBQUcsQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7QUFJeEQsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLFdBQVcsRUFBRSxRQUFRLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3RHLE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxXQUFXLEVBQUUsUUFBUSxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQzNILE1BQU0sUUFBUSxHQUFHO0lBQ2IsUUFBUSxFQUFFLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQztJQUM5QixHQUFHLEVBQUUsSUFBSSxNQUFNLENBQUMsS0FBSyxHQUFHLGlCQUFpQixDQUFDO0lBQzFDLElBQUksRUFBRSxJQUFJLE1BQU0sQ0FBQyxNQUFNLEdBQUcsaUJBQWlCLENBQUM7SUFDNUMsR0FBRyxFQUFFLElBQUksTUFBTSxDQUFDLEtBQUssR0FBRyxpQkFBaUIsQ0FBQztJQUMxQyxJQUFJLEVBQUUsSUFBSSxNQUFNLENBQUMsTUFBTSxHQUFHLGlCQUFpQixDQUFDO0lBQzVDLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQyxLQUFLLEdBQUcsaUJBQWlCLENBQUM7SUFDMUMsSUFBSSxFQUFFLElBQUksTUFBTSxDQUFDLE1BQU0sR0FBRyxpQkFBaUIsQ0FBQztJQUM1QyxJQUFJLEVBQUUsc0RBQXNEO0lBQzVELElBQUksRUFBRSxzREFBc0Q7SUFDNUQsSUFBSSxFQUFFLHNFQUFzRTtJQUM1RSxJQUFJLEVBQUUsc0VBQXNFO0NBQy9FLENBQUM7Ozs7O0FBS0YsU0FBUyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUU7SUFDaEMsS0FBSyxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUNuQyxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1FBQ3BCLE9BQU8sS0FBSyxDQUFDO0tBQ2hCO0lBQ0QsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDO0lBQ2xCLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1FBQ2QsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyQixLQUFLLEdBQUcsSUFBSSxDQUFDO0tBQ2hCO1NBQ0ksSUFBSSxLQUFLLEtBQUssYUFBYSxFQUFFO1FBQzlCLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsQ0FBQztLQUNyRDs7Ozs7SUFLRCxJQUFJLEtBQUssR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNyQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0tBQ3BEO0lBQ0QsS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2xDLElBQUksS0FBSyxFQUFFO1FBQ1AsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUNqRTtJQUNELEtBQUssR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNqQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0tBQ3BEO0lBQ0QsS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2xDLElBQUksS0FBSyxFQUFFO1FBQ1AsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUNqRTtJQUNELEtBQUssR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNqQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0tBQ3BEO0lBQ0QsS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2xDLElBQUksS0FBSyxFQUFFO1FBQ1AsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUNqRTtJQUNELEtBQUssR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNsQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU87WUFDSCxDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QixDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QixDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QixDQUFDLEVBQUUsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2hDLE1BQU0sRUFBRSxLQUFLLEdBQUcsTUFBTSxHQUFHLE1BQU07U0FDbEMsQ0FBQztLQUNMO0lBQ0QsS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2xDLElBQUksS0FBSyxFQUFFO1FBQ1AsT0FBTztZQUNILENBQUMsRUFBRSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVCLENBQUMsRUFBRSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVCLENBQUMsRUFBRSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVCLE1BQU0sRUFBRSxLQUFLLEdBQUcsTUFBTSxHQUFHLEtBQUs7U0FDakMsQ0FBQztLQUNMO0lBQ0QsS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2xDLElBQUksS0FBSyxFQUFFO1FBQ1AsT0FBTztZQUNILENBQUMsRUFBRSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2QyxDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdkMsQ0FBQyxFQUFFLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZDLENBQUMsRUFBRSxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNDLE1BQU0sRUFBRSxLQUFLLEdBQUcsTUFBTSxHQUFHLE1BQU07U0FDbEMsQ0FBQztLQUNMO0lBQ0QsS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2xDLElBQUksS0FBSyxFQUFFO1FBQ1AsT0FBTztZQUNILENBQUMsRUFBRSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2QyxDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdkMsQ0FBQyxFQUFFLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZDLE1BQU0sRUFBRSxLQUFLLEdBQUcsTUFBTSxHQUFHLEtBQUs7U0FDakMsQ0FBQztLQUNMO0lBQ0QsT0FBTyxLQUFLLENBQUM7Q0FDaEI7Ozs7O0FBS0QsU0FBUyxjQUFjLENBQUMsS0FBSyxFQUFFO0lBQzNCLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0NBQ2xEOztBQUVELE1BQU0sU0FBUyxDQUFDO0lBQ1osV0FBVyxDQUFDLEtBQUssR0FBRyxFQUFFLEVBQUUsSUFBSSxHQUFHLEVBQUUsRUFBRTs7UUFFL0IsSUFBSSxLQUFLLFlBQVksU0FBUyxFQUFFO1lBQzVCLE9BQU8sS0FBSyxDQUFDO1NBQ2hCO1FBQ0QsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7UUFDM0IsTUFBTSxHQUFHLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzlCLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBQzNCLElBQUksQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNmLElBQUksQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNmLElBQUksQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNmLElBQUksQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNmLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUM3QyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQztRQUN4QyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7Ozs7O1FBS3RDLElBQUksSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDWixJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQy9CO1FBQ0QsSUFBSSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNaLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDL0I7UUFDRCxJQUFJLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ1osSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUMvQjtRQUNELElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDLEVBQUUsQ0FBQztLQUN6QjtJQUNELE1BQU0sR0FBRztRQUNMLE9BQU8sSUFBSSxDQUFDLGFBQWEsRUFBRSxHQUFHLEdBQUcsQ0FBQztLQUNyQztJQUNELE9BQU8sR0FBRztRQUNOLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7S0FDekI7Ozs7SUFJRCxhQUFhLEdBQUc7O1FBRVosTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxJQUFJLENBQUM7S0FDM0Q7Ozs7SUFJRCxZQUFZLEdBQUc7O1FBRVgsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxDQUFDO1FBQ04sSUFBSSxDQUFDLENBQUM7UUFDTixJQUFJLENBQUMsQ0FBQztRQUNOLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1FBQzFCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1FBQzFCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1FBQzFCLElBQUksS0FBSyxJQUFJLE9BQU8sRUFBRTtZQUNsQixDQUFDLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztTQUNyQjthQUNJO1lBQ0QsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxJQUFJLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztTQUM5QztRQUNELElBQUksS0FBSyxJQUFJLE9BQU8sRUFBRTtZQUNsQixDQUFDLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztTQUNyQjthQUNJO1lBQ0QsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxJQUFJLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztTQUM5QztRQUNELElBQUksS0FBSyxJQUFJLE9BQU8sRUFBRTtZQUNsQixDQUFDLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztTQUNyQjthQUNJO1lBQ0QsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxJQUFJLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztTQUM5QztRQUNELE9BQU8sTUFBTSxHQUFHLENBQUMsR0FBRyxNQUFNLEdBQUcsQ0FBQyxHQUFHLE1BQU0sR0FBRyxDQUFDLENBQUM7S0FDL0M7Ozs7OztJQU1ELFFBQVEsQ0FBQyxLQUFLLEVBQUU7UUFDWixJQUFJLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMzQixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7UUFDN0MsT0FBTyxJQUFJLENBQUM7S0FDZjs7OztJQUlELEtBQUssR0FBRztRQUNKLE1BQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzdDLE9BQU8sRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUM1RDs7Ozs7SUFLRCxXQUFXLEdBQUc7UUFDVixNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDbEMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ2xDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUNsQyxPQUFPLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNoRzs7OztJQUlELEtBQUssR0FBRztRQUNKLE1BQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzdDLE9BQU8sRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUM1RDs7Ozs7SUFLRCxXQUFXLEdBQUc7UUFDVixNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDbEMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ2xDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUNsQyxPQUFPLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNoRzs7Ozs7SUFLRCxLQUFLLENBQUMsVUFBVSxHQUFHLEtBQUssRUFBRTtRQUN0QixPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztLQUN2RDs7Ozs7SUFLRCxXQUFXLENBQUMsVUFBVSxHQUFHLEtBQUssRUFBRTtRQUM1QixPQUFPLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0tBQ3ZDOzs7OztJQUtELE1BQU0sQ0FBQyxVQUFVLEdBQUcsS0FBSyxFQUFFO1FBQ3ZCLE9BQU8sU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7S0FDaEU7Ozs7O0lBS0QsWUFBWSxDQUFDLFVBQVUsR0FBRyxLQUFLLEVBQUU7UUFDN0IsT0FBTyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztLQUN4Qzs7OztJQUlELEtBQUssR0FBRztRQUNKLE9BQU87WUFDSCxDQUFDLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ3JCLENBQUMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDckIsQ0FBQyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUNyQixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDWixDQUFDO0tBQ0w7Ozs7O0lBS0QsV0FBVyxHQUFHO1FBQ1YsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0IsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0IsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0IsT0FBTyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDNUY7Ozs7SUFJRCxlQUFlLEdBQUc7UUFDZCxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDO1FBQzNELE9BQU87WUFDSCxDQUFDLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDZCxDQUFDLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDZCxDQUFDLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDZCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDWixDQUFDO0tBQ0w7Ozs7SUFJRCxxQkFBcUIsR0FBRztRQUNwQixNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDckQsT0FBTyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUM7Y0FDYixDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztjQUN4RCxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ25GOzs7O0lBSUQsTUFBTSxHQUFHO1FBQ0wsSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNkLE9BQU8sYUFBYSxDQUFDO1NBQ3hCO1FBQ0QsSUFBSSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNaLE9BQU8sS0FBSyxDQUFDO1NBQ2hCO1FBQ0QsTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUMxRCxLQUFLLE1BQU0sR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDbEMsSUFBSSxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRyxFQUFFO2dCQUNwQixPQUFPLEdBQUcsQ0FBQzthQUNkO1NBQ0o7UUFDRCxPQUFPLEtBQUssQ0FBQztLQUNoQjs7Ozs7O0lBTUQsUUFBUSxDQUFDLE1BQU0sRUFBRTtRQUNiLE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFDM0IsTUFBTSxHQUFHLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQy9CLElBQUksZUFBZSxHQUFHLEtBQUssQ0FBQztRQUM1QixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMzQyxNQUFNLGdCQUFnQixHQUFHLENBQUMsU0FBUyxJQUFJLFFBQVEsS0FBSyxNQUFNLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLE1BQU0sS0FBSyxNQUFNLENBQUMsQ0FBQztRQUNuRyxJQUFJLGdCQUFnQixFQUFFOzs7WUFHbEIsSUFBSSxNQUFNLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNuQyxPQUFPLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzthQUN4QjtZQUNELE9BQU8sSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQzdCO1FBQ0QsSUFBSSxNQUFNLEtBQUssS0FBSyxFQUFFO1lBQ2xCLGVBQWUsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDeEM7UUFDRCxJQUFJLE1BQU0sS0FBSyxNQUFNLEVBQUU7WUFDbkIsZUFBZSxHQUFHLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1NBQ2xEO1FBQ0QsSUFBSSxNQUFNLEtBQUssS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNLEVBQUU7WUFDdkMsZUFBZSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUN4QztRQUNELElBQUksTUFBTSxLQUFLLE1BQU0sRUFBRTtZQUNuQixlQUFlLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM1QztRQUNELElBQUksTUFBTSxLQUFLLE1BQU0sRUFBRTtZQUNuQixlQUFlLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM3QztRQUNELElBQUksTUFBTSxLQUFLLE1BQU0sRUFBRTtZQUNuQixlQUFlLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ3pDO1FBQ0QsSUFBSSxNQUFNLEtBQUssTUFBTSxFQUFFO1lBQ25CLGVBQWUsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7U0FDbkM7UUFDRCxJQUFJLE1BQU0sS0FBSyxLQUFLLEVBQUU7WUFDbEIsZUFBZSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUN4QztRQUNELElBQUksTUFBTSxLQUFLLEtBQUssRUFBRTtZQUNsQixlQUFlLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3hDO1FBQ0QsT0FBTyxlQUFlLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0tBQ2hEO0lBQ0QsS0FBSyxHQUFHO1FBQ0osT0FBTyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztLQUN6Qzs7Ozs7SUFLRCxPQUFPLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRTtRQUNqQixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDekIsR0FBRyxDQUFDLENBQUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxDQUFDO1FBQ3RCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QixPQUFPLElBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQzdCOzs7OztJQUtELFFBQVEsQ0FBQyxNQUFNLEdBQUcsRUFBRSxFQUFFO1FBQ2xCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN6QixHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsRUFBRSxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDOUUsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEVBQUUsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzlFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxFQUFFLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM5RSxPQUFPLElBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQzdCOzs7Ozs7SUFNRCxNQUFNLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRTtRQUNoQixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDekIsR0FBRyxDQUFDLENBQUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxDQUFDO1FBQ3RCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QixPQUFPLElBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQzdCOzs7Ozs7SUFNRCxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRTtRQUNkLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUM7S0FDcEM7Ozs7OztJQU1ELEtBQUssQ0FBQyxNQUFNLEdBQUcsRUFBRSxFQUFFO1FBQ2YsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztLQUNwQzs7Ozs7O0lBTUQsVUFBVSxDQUFDLE1BQU0sR0FBRyxFQUFFLEVBQUU7UUFDcEIsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLEdBQUcsQ0FBQyxDQUFDLElBQUksTUFBTSxHQUFHLEdBQUcsQ0FBQztRQUN0QixHQUFHLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdkIsT0FBTyxJQUFJLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUM3Qjs7Ozs7SUFLRCxRQUFRLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRTtRQUNsQixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDekIsR0FBRyxDQUFDLENBQUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxDQUFDO1FBQ3RCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QixPQUFPLElBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQzdCOzs7OztJQUtELFNBQVMsR0FBRztRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUMvQjs7Ozs7SUFLRCxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ1QsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLE1BQU0sR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxNQUFNLElBQUksR0FBRyxDQUFDO1FBQ25DLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztRQUNsQyxPQUFPLElBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQzdCO0lBQ0QsR0FBRyxDQUFDLEtBQUssRUFBRSxNQUFNLEdBQUcsRUFBRSxFQUFFO1FBQ3BCLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUMxQixNQUFNLElBQUksR0FBRyxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUMxQyxNQUFNLENBQUMsR0FBRyxNQUFNLEdBQUcsR0FBRyxDQUFDO1FBQ3ZCLE1BQU0sSUFBSSxHQUFHO1lBQ1QsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztZQUNqQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1lBQ2pDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7WUFDakMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUNwQyxDQUFDO1FBQ0YsT0FBTyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUM5QjtJQUNELFNBQVMsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxFQUFFLE1BQU0sR0FBRyxFQUFFLEVBQUU7UUFDaEMsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLE1BQU0sSUFBSSxHQUFHLEdBQUcsR0FBRyxNQUFNLENBQUM7UUFDMUIsTUFBTSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNuQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLE9BQU8sS0FBSyxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksR0FBRyxFQUFFLEVBQUUsT0FBTyxHQUFHO1lBQ3BFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksSUFBSSxHQUFHLENBQUM7WUFDN0IsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQ2hDO1FBQ0QsT0FBTyxHQUFHLENBQUM7S0FDZDs7OztJQUlELFVBQVUsR0FBRztRQUNULE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN6QixHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksR0FBRyxDQUFDO1FBQzVCLE9BQU8sSUFBSSxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDN0I7SUFDRCxhQUFhLENBQUMsT0FBTyxHQUFHLENBQUMsRUFBRTtRQUN2QixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDekIsTUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNoQixNQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ2hCLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDZCxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7UUFDZixNQUFNLFlBQVksR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDO1FBQ2pDLE9BQU8sT0FBTyxFQUFFLEVBQUU7WUFDZCxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDckMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLFlBQVksSUFBSSxDQUFDLENBQUM7U0FDOUI7UUFDRCxPQUFPLEdBQUcsQ0FBQztLQUNkO0lBQ0QsZUFBZSxHQUFHO1FBQ2QsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDaEIsT0FBTztZQUNILElBQUk7WUFDSixJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksR0FBRyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDeEQsSUFBSSxTQUFTLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDO1NBQzVELENBQUM7S0FDTDtJQUNELEtBQUssR0FBRztRQUNKLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUN6QjtJQUNELE1BQU0sR0FBRztRQUNMLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUN6Qjs7Ozs7SUFLRCxNQUFNLENBQUMsQ0FBQyxFQUFFO1FBQ04sTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDaEIsTUFBTSxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN0QixNQUFNLFNBQVMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQzFCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDeEIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsU0FBUyxJQUFJLEdBQUcsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUNwRjtRQUNELE9BQU8sTUFBTSxDQUFDO0tBQ2pCOzs7O0lBSUQsTUFBTSxDQUFDLEtBQUssRUFBRTtRQUNWLE9BQU8sSUFBSSxDQUFDLFdBQVcsRUFBRSxLQUFLLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO0tBQ3BFO0NBQ0o7Ozs7Ozs7Ozs7QUFVRCxTQUFTLFdBQVcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFO0lBQ2pDLE1BQU0sRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2pDLE1BQU0sRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2pDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxZQUFZLEVBQUUsRUFBRSxFQUFFLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxJQUFJO1NBQ3pELElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFlBQVksRUFBRSxFQUFFLEVBQUUsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxFQUFFO0NBQ2hFOzs7Ozs7Ozs7Ozs7OztBQWNELFNBQVMsVUFBVSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsS0FBSyxHQUFHLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLEVBQUU7SUFDeEUsTUFBTSxnQkFBZ0IsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ3JELFFBQVEsQ0FBQyxLQUFLLENBQUMsS0FBSyxJQUFJLElBQUksS0FBSyxLQUFLLENBQUMsSUFBSSxJQUFJLE9BQU8sQ0FBQztRQUNuRCxLQUFLLFNBQVMsQ0FBQztRQUNmLEtBQUssVUFBVTtZQUNYLE9BQU8sZ0JBQWdCLElBQUksR0FBRyxDQUFDO1FBQ25DLEtBQUssU0FBUztZQUNWLE9BQU8sZ0JBQWdCLElBQUksQ0FBQyxDQUFDO1FBQ2pDLEtBQUssVUFBVTtZQUNYLE9BQU8sZ0JBQWdCLElBQUksQ0FBQyxDQUFDO0tBQ3BDO0lBQ0QsT0FBTyxLQUFLLENBQUM7Q0FDaEI7O0FDeGtDRCxNQUFNQyxPQUFLLEdBQUc7RUFDWixNQUFNLEVBQUU7SUFDTixHQUFHLEdBQUcsSUFBSTtJQUNWLE1BQU0sRUFBRSxJQUFJO0dBQ2I7RUFDRCxJQUFJLEVBQUUsSUFBSSxHQUFHLEVBQUU7RUFDaEI7O0FBRUQsTUFBTSxRQUFRLEdBQUcsR0FBRTs7QUFFbkIsQUFBTyxTQUFTLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFO0VBQ2hDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxNQUFNLEVBQUM7O0VBRTdCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBQztFQUNwQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUM7O0VBRW5DLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxJQUFJLFNBQVMsRUFBRSxFQUFDOztFQUVoQyxpQkFBaUIsR0FBRTs7RUFFbkIsT0FBTyxNQUFNO0lBQ1gsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFDO0lBQ3JDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBQztJQUNwQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBQztJQUNyQixPQUFPLEdBQUU7R0FDVjtDQUNGOztBQUVELE1BQU0sU0FBUyxHQUFHLENBQUMsSUFBSTtFQUNyQixNQUFNLE1BQU0sR0FBRyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUM7O0VBRXpELElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxRQUFRLEtBQUssZ0JBQWdCLElBQUksTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsRUFBRTtJQUN0RyxJQUFJQSxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRTtNQUNwQixJQUFJLENBQUM7UUFDSCxHQUFHLEVBQUVBLE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRztRQUNyQixDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUVBLE9BQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO09BQ2pDLEVBQUM7TUFDRixXQUFXLEdBQUU7S0FDZDtJQUNELE1BQU07R0FDUDs7RUFFRCxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBQzs7RUFFcEMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUM7RUFDbkI7O0FBRUQsQUFBTyxTQUFTLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFO0VBQ2pDLElBQUksQ0FBQ0EsT0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUU7SUFDckIsTUFBTSxHQUFHLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBQztJQUMxQixRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUM7O0lBRTlCLFdBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFDO0lBQ25CLE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsRUFBQzs7SUFFdEJBLE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLElBQUc7SUFDekJBLE9BQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLE9BQU07R0FDN0I7T0FDSSxJQUFJLE1BQU0sSUFBSUEsT0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7O0lBRXRDLFdBQVcsQ0FBQ0EsT0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFDO0dBQ2pDO09BQ0k7SUFDSCxNQUFNLENBQUMsTUFBTSxFQUFFQSxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBQztJQUNoQ0EsT0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsT0FBTTtJQUM1QixXQUFXLENBQUNBLE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBQztHQUNqQztDQUNGOztBQUVELEFBQU8sU0FBUyxXQUFXLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRTtFQUNsQyxNQUFNLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLGNBQWMsQ0FBQyxDQUFDLEVBQUM7RUFDekMsTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxZQUFZLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFDOztFQUV6RCxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksSUFBSSxLQUFJO0VBQ3RCLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxLQUFLLElBQUc7O0VBRXJCLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxLQUFLO01BQ2xDLGlCQUFpQjtNQUNqQixtQkFBbUIsRUFBQzs7RUFFeEIsR0FBRyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsb0JBQW9CLEVBQUUsS0FBSztNQUM3QyxrQkFBa0I7TUFDbEIsb0JBQW9CLEVBQUM7O0VBRXpCLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLGFBQWEsRUFBRSxDQUFDLEtBQUs7TUFDdkMsTUFBTTtNQUNOLGtCQUFrQixFQUFDOztFQUV2QixHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxjQUFjLEVBQUUsSUFBSTtNQUN0QywwQkFBMEI7TUFDMUIsTUFBTSxFQUFDO0NBQ1o7O0FBRUQsTUFBTSxpQkFBaUIsR0FBRyxNQUFNO0VBQzlCQSxPQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTSxLQUFLO0lBQ3BDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLFFBQU87SUFDM0IsTUFBTSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUM7SUFDbkIsT0FBTyxDQUFDLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFDO0dBQ3ZCLEVBQUM7RUFDSDs7QUFFRCxBQUFPLFNBQVMsT0FBTyxHQUFHO0VBQ3hCQSxPQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTTtJQUMvQixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLEVBQUM7O0VBRTdCLElBQUlBLE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFO0lBQ3BCQSxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUU7SUFDekIsV0FBVyxHQUFFO0dBQ2Q7Q0FDRjs7QUFFRCxBQUFPLFNBQVMsU0FBUyxHQUFHO0VBQzFCQSxPQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTSxLQUFLO0lBQ3BDLEdBQUcsQ0FBQyxNQUFNLEdBQUU7SUFDWixTQUFTLENBQUMsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLEVBQUM7R0FDekIsRUFBQzs7RUFFRixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksRUFBQzs7RUFFOUNBLE9BQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFFO0NBQ25COztBQUVELE1BQU0sTUFBTSxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLEtBQUs7RUFDckUsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLENBQUMscUJBQXFCLEdBQUU7RUFDcEQsTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQztLQUN6QixHQUFHLENBQUMsS0FBSyxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO01BQ2pDLElBQUksRUFBRSxXQUFXLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztLQUM5QixDQUFDLENBQUM7S0FDRixNQUFNLENBQUMsS0FBSztNQUNYLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQztVQUM5QixFQUFFLENBQUMsT0FBTyxDQUFDLHdFQUF3RSxDQUFDO1VBQ3BGLElBQUk7S0FDVDtLQUNBLEdBQUcsQ0FBQyxLQUFLLElBQUk7TUFDWixJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQztRQUM5SCxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsb0NBQW9DLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUM7O01BRXpILElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsRUFBRTtRQUMvRCxLQUFLLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFLOztNQUUvQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDO1FBQzVDLEtBQUssQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBQzs7TUFFckQsSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQztRQUN6QyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMseUJBQXlCLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBQzs7O01BRzdKLElBQUksRUFBRSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO1FBQzNFLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBQzs7TUFFMUQsT0FBTyxLQUFLO0tBQ2IsRUFBQzs7RUFFSixNQUFNLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSztJQUM1QyxFQUFFLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7UUFDckUsQ0FBQztRQUNELENBQUMsRUFBQzs7RUFFUixNQUFNLHFCQUFxQixHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSztJQUMvQyxFQUFFLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7UUFDckUsQ0FBQztRQUNELENBQUMsRUFBQzs7RUFFUixHQUFHLENBQUMsSUFBSSxHQUFHO0lBQ1QsRUFBRTtJQUNGLEtBQUs7SUFDTCxNQUFNO0lBQ04sa0JBQWtCO0lBQ2xCLHFCQUFxQjtJQUN0Qjs7RUFFRCxPQUFPLEdBQUc7RUFDWDs7QUFFRCxNQUFNLGNBQWMsR0FBRyxDQUFDLEtBQUs7RUFDM0IsS0FBSyxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLFdBQVcsR0FBRyxDQUFDO0VBQ3pDLElBQUksR0FBRyxDQUFDLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxVQUFVLEdBQUcsQ0FBQztDQUN6QyxFQUFDOztBQUVGLE1BQU0sWUFBWSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsSUFBSSxNQUFNO0VBQzlDLEdBQUcsRUFBRSxDQUFDLEVBQUUsS0FBSztNQUNULENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFO01BQ2hDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQztFQUNwQixJQUFJLEVBQUUsQ0FBQyxFQUFFLElBQUk7TUFDVCxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRTtNQUMvQixDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7Q0FDckIsRUFBQzs7QUFFRixNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7RUFDL0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLElBQUlBLE9BQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztJQUNoRSxJQUFJLENBQUNBLE9BQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFDO0VBQy9COztBQUVELE1BQU0sSUFBSSxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSztFQUNsQyxHQUFHLENBQUMsTUFBTSxHQUFFO0VBQ1osU0FBUyxDQUFDLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFDO0VBQ3hCQSxPQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUM7RUFDMUI7O0FBRUQsTUFBTSxZQUFZLEdBQUcsQ0FBQyxJQUFJO0VBQ3hCLE1BQU0sTUFBTSxHQUFHLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLE9BQU8sRUFBQzs7RUFFekQsSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsRUFBRTtJQUNwRCxNQUFNLENBQUMsWUFBWSxDQUFDLGNBQWMsRUFBRSxJQUFJLEVBQUM7SUFDekNBLE9BQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRTtNQUNyQixHQUFHLEVBQUVBLE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRztNQUNyQixDQUFDO0tBQ0YsRUFBQztJQUNGLFdBQVcsR0FBRTtHQUNkO09BQ0ksSUFBSSxNQUFNLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxFQUFFO0lBQzVDLE1BQU0sQ0FBQyxlQUFlLENBQUMsY0FBYyxFQUFDO0lBQ3RDLElBQUksQ0FBQ0EsT0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUM7R0FDN0I7RUFDRjs7QUFFRCxNQUFNLGdCQUFnQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLENBQUMsS0FBSztFQUN6RCxJQUFJLENBQUMsSUFBSSxFQUFFLE1BQU07O0VBRWpCLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxFQUFFO0lBQ2xDLEVBQUUsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUMsRUFBQzs7RUFFM0MsU0FBUyxDQUFDLElBQUksR0FBRyx1QkFBdUIsRUFBRSxFQUFFO0lBQzFDLFNBQVMsS0FBSyxZQUFZO1FBQ3RCLEVBQUUsQ0FBQyxZQUFZLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDO1FBQzNDLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFDO0VBQ3JDOztBQUVELE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxJQUFJO0VBQzdCLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxFQUFFO0lBQ2xDLEVBQUUsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUMsRUFBQztFQUM1Qzs7QUFFRCxNQUFNLGtCQUFrQixHQUFHLENBQUMsR0FBRyxFQUFFLE1BQU07RUFDckMsR0FBRztNQUNDLE1BQU0sQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztNQUMxQyxNQUFNLENBQUMsZUFBZSxDQUFDLGVBQWUsRUFBQzs7QUFFN0MsTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsS0FBSztFQUNqQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsRUFBQztFQUNwQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLFNBQVMsRUFBRSxpQkFBaUIsRUFBQztFQUN2QyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLGdCQUFnQixFQUFFLFVBQVUsRUFBQztFQUMzQzs7QUFFRCxNQUFNLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0VBQ25DLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLGdCQUFnQixFQUFDO0VBQ3JDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLGlCQUFpQixFQUFDO0VBQ3hDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsVUFBVSxFQUFDO0VBQzVDOztBQUVELE1BQU0sV0FBVyxHQUFHLE1BQU07RUFDeEJBLE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLEtBQUk7RUFDMUJBLE9BQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLEtBQUk7Q0FDM0I7O0FDMVBELE1BQU1BLE9BQUssR0FBRztFQUNaLE1BQU0sRUFBRTtJQUNOLEdBQUcsR0FBRyxJQUFJO0lBQ1YsTUFBTSxFQUFFLElBQUk7R0FDYjtFQUNELElBQUksRUFBRSxJQUFJLEdBQUcsRUFBRTtFQUNoQjs7QUFFRCxBQUFPLFNBQVMsYUFBYSxHQUFHO0VBQzlCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFQyxXQUFTLEVBQUM7RUFDcEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUVDLGNBQVksRUFBQzs7RUFFbkMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDLElBQUlDLFdBQVMsRUFBRSxFQUFDOztFQUVoQ0MsbUJBQWlCLEdBQUU7O0VBRW5CLE9BQU8sTUFBTTtJQUNYLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFSCxXQUFTLEVBQUM7SUFDckMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUVDLGNBQVksRUFBQztJQUNwQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBQztJQUNyQkcsU0FBTyxHQUFFO0dBQ1Y7Q0FDRjs7QUFFRCxNQUFNSixXQUFTLEdBQUcsQ0FBQyxJQUFJO0VBQ3JCLE1BQU0sTUFBTSxHQUFHLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLE9BQU8sRUFBQzs7RUFFekQsSUFBSSxXQUFXLENBQUMsTUFBTSxDQUFDLElBQUksTUFBTSxDQUFDLFFBQVEsS0FBSyxnQkFBZ0IsSUFBSSxNQUFNLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxFQUFFO0lBQ3RHLElBQUlELE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFO01BQ3BCTSxNQUFJLENBQUM7UUFDSCxHQUFHLEVBQUVOLE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRztRQUNyQixDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUVBLE9BQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO09BQ2pDLEVBQUM7TUFDRk8sYUFBVyxHQUFFO0tBQ2Q7SUFDRCxNQUFNO0dBQ1A7O0VBRURDLG9CQUFrQixDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFDOztFQUVwQ0MsU0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUM7RUFDbkI7O0FBRUQsQUFBTyxTQUFTQSxTQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRTtFQUNqQyxJQUFJLENBQUNULE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFO0lBQ3JCLE1BQU0sR0FBRyxHQUFHVSxRQUFNLENBQUMsTUFBTSxFQUFDO0lBQzFCLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBQzs7SUFFOUJDLGFBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFDO0lBQ25CQyxTQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLEVBQUM7O0lBRXRCWixPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsTUFBTSxJQUFHO0lBQ3pCQSxPQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxPQUFNO0dBQzdCO09BQ0ksSUFBSSxNQUFNLElBQUlBLE9BQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFOztJQUV0Q1csYUFBVyxDQUFDWCxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUM7R0FDakM7T0FDSTtJQUNIVSxRQUFNLENBQUMsTUFBTSxFQUFFVixPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBQztJQUNoQ0EsT0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsT0FBTTtJQUM1QlcsYUFBVyxDQUFDWCxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUM7R0FDakM7Q0FDRjs7QUFFRCxBQUFPLFNBQVNXLGFBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFO0VBQ2xDLE1BQU0sRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUdFLGdCQUFjLENBQUMsQ0FBQyxFQUFDO0VBQ3pDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLE9BQU9DLGNBQVksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUM7O0VBRXpELEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxJQUFJLEtBQUk7RUFDdEIsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssSUFBRzs7RUFFckIsR0FBRyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLEtBQUs7TUFDbEMsaUJBQWlCO01BQ2pCLG1CQUFtQixFQUFDOztFQUV4QixHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLO01BQzdDLGtCQUFrQjtNQUNsQixvQkFBb0IsRUFBQzs7RUFFekIsR0FBRyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsYUFBYSxFQUFFLENBQUMsS0FBSztNQUN2QyxNQUFNO01BQ04sa0JBQWtCLEVBQUM7O0VBRXZCLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLGNBQWMsRUFBRSxJQUFJO01BQ3RDLDBCQUEwQjtNQUMxQixNQUFNLEVBQUM7Q0FDWjs7QUFFRCxNQUFNVixtQkFBaUIsR0FBRyxNQUFNO0VBQzlCSixPQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTSxLQUFLO0lBQ3BDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLFFBQU87SUFDM0JVLFFBQU0sQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFDO0lBQ25CRSxTQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLEVBQUM7R0FDdkIsRUFBQztFQUNIOztBQUVELEFBQU8sU0FBU1AsU0FBTyxHQUFHO0VBQ3hCTCxPQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTTtJQUMvQixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLEVBQUM7O0VBRTdCLElBQUlBLE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFO0lBQ3BCQSxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUU7SUFDekJPLGFBQVcsR0FBRTtHQUNkO0NBQ0Y7O0FBRUQsQUFBTyxTQUFTSixXQUFTLEdBQUc7RUFDMUJILE9BQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxNQUFNLEtBQUs7SUFDcEMsR0FBRyxDQUFDLE1BQU0sR0FBRTtJQUNaZSxXQUFTLENBQUMsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLEVBQUM7R0FDekIsRUFBQzs7RUFFRixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksRUFBQzs7RUFFOUNmLE9BQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFFO0NBQ25COztBQUVELE1BQU1VLFFBQU0sR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsS0FBSztFQUNsRSxNQUFNLGdCQUFnQixHQUFHLHNCQUFzQixDQUFDLEVBQUUsRUFBQztFQUNuRCxNQUFNLGVBQWUsR0FBRyxRQUFRLENBQUMsRUFBRSxFQUFDOztFQUVwQyxlQUFlLENBQUMsR0FBRyxDQUFDLElBQUk7SUFDdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDOUMsSUFBSSxFQUFDOztFQUVYLGVBQWUsQ0FBQyxHQUFHLENBQUMsSUFBSTtJQUN0QixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7UUFDdkIsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLG9CQUFvQixFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1FBQ3ZELElBQUksRUFBQzs7RUFFWCxHQUFHLENBQUMsSUFBSSxHQUFHO0lBQ1QsRUFBRTtJQUNGLGVBQWU7SUFDZixnQkFBZ0I7SUFDakI7O0VBRUQsT0FBTyxHQUFHO0VBQ1g7O0FBRUQsTUFBTSxzQkFBc0IsR0FBRyxFQUFFLElBQUk7OztFQUduQyxNQUFNLElBQUksUUFBUSxRQUFRLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBQztFQUN2QyxNQUFNLFFBQVEsSUFBSSxnQkFBZ0IsQ0FBQyxFQUFFLEVBQUM7O0VBRXRDLElBQUksVUFBVSxJQUFJLDBCQUEwQixDQUFDLEVBQUUsRUFBQzs7RUFFaEQsTUFBTSxFQUFFLFdBQVcsRUFBRSxZQUFZLEVBQUUsR0FBRztJQUNwQyxVQUFVLENBQUMsVUFBVSxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDO0lBQzNFLFVBQVUsQ0FBQyxVQUFVLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUM7SUFDN0U7O0VBRUQsT0FBTyxDQUFDOzs7O3lCQUllLEVBQUUsVUFBVSxDQUFDO2NBQ3hCLEVBQUUsSUFBSSxDQUFDO1FBQ2IsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDOztvQkFFN0MsRUFBRSxRQUFRLENBQUM7dUJBQ1IsRUFBRSxXQUFXLEdBQUcsY0FBYyxHQUFHLFdBQVcsQ0FBQyxFQUFFLEVBQUUsV0FBVyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7cUJBQzNFLEVBQUUsUUFBUSxDQUFDO3VCQUNULEVBQUUsWUFBWSxHQUFHLGNBQWMsR0FBRyxXQUFXLENBQUMsRUFBRSxFQUFFLFlBQVksR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ2hHLENBQUM7RUFDRjs7QUFFRCxNQUFNRyxnQkFBYyxHQUFHLENBQUMsS0FBSztFQUMzQixLQUFLLEVBQUUsQ0FBQyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMsV0FBVyxHQUFHLENBQUM7RUFDekMsSUFBSSxHQUFHLENBQUMsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLFVBQVUsR0FBRyxDQUFDO0NBQ3pDLEVBQUM7O0FBRUYsTUFBTUMsY0FBWSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsSUFBSSxNQUFNO0VBQzlDLEdBQUcsRUFBRSxDQUFDLEVBQUUsS0FBSztNQUNULENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFO01BQ2hDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQztFQUNwQixJQUFJLEVBQUUsQ0FBQyxFQUFFLElBQUk7TUFDVCxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRTtNQUMvQixDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7Q0FDckIsRUFBQzs7QUFFRixNQUFNRSxZQUFVLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0VBQy9CLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxJQUFJaEIsT0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO0lBQ2hFTSxNQUFJLENBQUNOLE9BQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFDO0VBQy9COztBQUVELE1BQU1NLE1BQUksR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUs7RUFDbEMsR0FBRyxDQUFDLE1BQU0sR0FBRTtFQUNaUyxXQUFTLENBQUMsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLEVBQUM7RUFDeEJmLE9BQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBQztFQUMxQjs7QUFFRCxNQUFNRSxjQUFZLEdBQUcsQ0FBQyxJQUFJO0VBQ3hCLE1BQU0sTUFBTSxHQUFHLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLE9BQU8sRUFBQzs7RUFFekQsSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsRUFBRTtJQUNwRCxNQUFNLENBQUMsWUFBWSxDQUFDLGNBQWMsRUFBRSxJQUFJLEVBQUM7SUFDekNGLE9BQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRTtNQUNyQixHQUFHLEVBQUVBLE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRztNQUNyQixDQUFDO0tBQ0YsRUFBQztJQUNGTyxhQUFXLEdBQUU7R0FDZDtPQUNJLElBQUksTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsRUFBRTtJQUM1QyxNQUFNLENBQUMsZUFBZSxDQUFDLGNBQWMsRUFBQztJQUN0Q0QsTUFBSSxDQUFDTixPQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBQztHQUM3QjtFQUNGOztBQUVELE1BQU1RLG9CQUFrQixHQUFHLENBQUMsR0FBRyxFQUFFLE1BQU07RUFDckMsR0FBRztNQUNDLE1BQU0sQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztNQUMxQyxNQUFNLENBQUMsZUFBZSxDQUFDLGVBQWUsRUFBQzs7QUFFN0MsTUFBTUksU0FBTyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLEtBQUs7RUFDakMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRUksWUFBVSxFQUFDO0VBQzNDOztBQUVELE1BQU1ELFdBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0VBQ25DLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUVDLFlBQVUsRUFBQztFQUM1Qzs7QUFFRCxNQUFNVCxhQUFXLEdBQUcsTUFBTTtFQUN4QlAsT0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sS0FBSTtFQUMxQkEsT0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsS0FBSTtDQUMzQjs7QUM1Tk0sU0FBUyxVQUFVLEdBQUc7RUFDM0IsTUFBTSxJQUFJLGdCQUFnQixRQUFRLENBQUMsS0FBSTtFQUN2QyxJQUFJLFFBQVEsY0FBYyxHQUFFO0VBQzVCLElBQUksaUJBQWlCLEtBQUssR0FBRTtFQUM1QixJQUFJLE1BQU0sZ0JBQWdCLEdBQUU7RUFDNUIsSUFBSSxPQUFPLGVBQWUsR0FBRTs7RUFFNUIsTUFBTSxXQUFXLFNBQVM7SUFDeEIsTUFBTSxJQUFJLElBQUk7SUFDZCxPQUFPLEdBQUcsSUFBSTtJQUNkLEtBQUssS0FBSyxJQUFJO0lBQ2Y7O0VBRUQsTUFBTSxNQUFNLEdBQUcsTUFBTTtJQUNuQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUM7SUFDOUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFDOztJQUVwRCxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsRUFBRSxZQUFZLEVBQUM7SUFDcEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsUUFBUSxFQUFDOztJQUU5QixRQUFRLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBQztJQUMxQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBQztJQUN4QyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBQzs7SUFFNUMsZUFBZSxHQUFFOztJQUVqQixPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxjQUFjLEVBQUM7SUFDM0MsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLGVBQWUsRUFBRSxFQUFDO0lBQ25ELE9BQU8sQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFDO0lBQ3RCLE9BQU8sQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFLFlBQVksRUFBQztJQUNyQyxPQUFPLENBQUMsc0JBQXNCLEVBQUUsU0FBUyxFQUFDO0lBQzFDLE9BQU8sQ0FBQyx1QkFBdUIsRUFBRSxjQUFjLEVBQUM7SUFDaEQsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRSxtQkFBbUIsRUFBQztJQUMvRCxPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFLFFBQVEsRUFBQztJQUNwRCxPQUFPLENBQUMsaUNBQWlDLEVBQUUscUJBQXFCLEVBQUM7SUFDakUsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQUUsa0JBQWtCLEVBQUM7SUFDdEQ7O0VBRUQsTUFBTSxRQUFRLEdBQUcsTUFBTTtJQUNyQixJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUM7SUFDakQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFVBQVUsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFDOztJQUV2RCxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxZQUFZLEVBQUM7SUFDckMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsUUFBUSxFQUFDOztJQUUvQixRQUFRLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBQztJQUM3QyxRQUFRLENBQUMsbUJBQW1CLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBQztJQUMzQyxRQUFRLENBQUMsbUJBQW1CLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBQzs7SUFFL0MsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsOENBQThDLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLHdDQUF3QyxDQUFDLEVBQUM7SUFDOUs7O0VBRUQsTUFBTSxRQUFRLEdBQUcsQ0FBQyxJQUFJO0lBQ3BCLE1BQU0sT0FBTyxHQUFHLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLE9BQU8sRUFBQzs7SUFFMUQsSUFBSSxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksT0FBTyxDQUFDLENBQUMsTUFBTTtNQUN0RSxNQUFNOztJQUVSLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLGVBQWUsR0FBRTtJQUNsQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxZQUFZLEdBQUU7O0lBRS9CLEdBQUcsQ0FBQyxDQUFDLFFBQVEsSUFBSSxPQUFPLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQztNQUNwRCxRQUFRLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsRUFBQzs7TUFFL0MsTUFBTSxDQUFDLE9BQU8sRUFBQztJQUNsQjs7RUFFRCxNQUFNLFFBQVEsR0FBRyxFQUFFLElBQUk7SUFDckIsQ0FBQyxHQUFHLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQztPQUNwQixNQUFNLENBQUMsSUFBSTtVQUNSLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQzNDLE9BQU8sQ0FBQyxJQUFJO1VBQ1gsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFDOztJQUVwQixRQUFRLENBQUMsTUFBTSxDQUFDLElBQUk7TUFDbEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLENBQUM7T0FDekMsT0FBTyxDQUFDLElBQUk7UUFDWCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDO1VBQ1gsZUFBZSxPQUFPLElBQUk7VUFDMUIsb0JBQW9CLEVBQUUsSUFBSTtVQUMxQixlQUFlLE9BQU8sSUFBSTtVQUMxQixvQkFBb0IsVUFBVSxJQUFJO1VBQ2xDLGdCQUFnQixNQUFNLElBQUk7T0FDN0IsQ0FBQyxFQUFDOztJQUVMLFFBQVEsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUUsRUFBQzs7SUFFN0UsWUFBWSxHQUFFO0lBQ2Y7O0VBRUQsTUFBTSxXQUFXLEdBQUcsQ0FBQyxJQUFJO0lBQ3ZCLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsQ0FBQyxDQUFDLGVBQWUsR0FBRTtJQUNuQixJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsTUFBTTtJQUNqQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBQztJQUNyQzs7RUFFRCxNQUFNLGVBQWUsR0FBRyxDQUFDLElBQUk7SUFDM0IsSUFBSSxRQUFRLEdBQUcsTUFBSzs7SUFFcEIsUUFBUSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsRUFBRTtNQUMvQixJQUFJLE9BQU8sQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLE1BQU0sRUFBRTtRQUNuQyxDQUFDLENBQUMsNENBQTRDLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRTtVQUN4RCxFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLEVBQUM7O1FBRTVCLFFBQVEsR0FBRyxLQUFJO09BQ2hCO01BQ0Y7O0lBRUQsUUFBUSxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUMsRUFBRTtNQUM3QixJQUFJLFFBQVEsRUFBRTtRQUNaLENBQUMsQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1VBQ3hELEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLElBQUksRUFBQzs7UUFFMUIsUUFBUSxHQUFHLE1BQUs7T0FDakI7TUFDRjtJQUNGOztFQUVELE1BQU0sTUFBTSxHQUFHLENBQUM7SUFDZCxRQUFRLENBQUMsTUFBTSxJQUFJLFlBQVksR0FBRTs7RUFFbkMsTUFBTSxZQUFZLEdBQUcsQ0FBQyxJQUFJO0lBQ3hCLE1BQU0sU0FBUyxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQUM7SUFDN0IsSUFBSSxDQUFDLFNBQVMsRUFBRSxNQUFNOztJQUV0QixNQUFNLFVBQVUsR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLElBQUksRUFBQztJQUM1QyxVQUFVLENBQUMsZUFBZSxDQUFDLGVBQWUsRUFBQztJQUMzQyxTQUFTLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxVQUFVLEVBQUUsU0FBUyxDQUFDLFdBQVcsRUFBQztJQUNwRSxDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ25COztFQUVELE1BQU0sU0FBUyxHQUFHLENBQUM7SUFDakIsUUFBUSxDQUFDLE1BQU0sSUFBSSxVQUFVLEdBQUU7O0VBRWpDLE1BQU0sY0FBYyxHQUFHLENBQUM7SUFDdEIsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQ2pCLEVBQUUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxFQUFDOztFQUUzQixNQUFNLE9BQU8sR0FBRyxDQUFDLElBQUk7O0lBRW5CLElBQUksTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLE1BQU07TUFDekMsTUFBTTs7SUFFUixJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsY0FBYyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRTtNQUN0RCxDQUFDLENBQUMsY0FBYyxHQUFFO01BQ2xCLElBQUksS0FBSyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFDO01BQ3ZDLEtBQUssQ0FBQyxlQUFlLENBQUMsZUFBZSxFQUFDO01BQ3RDLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDLFVBQVM7TUFDbEMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUM7S0FDdkQ7SUFDRjs7RUFFRCxNQUFNLE1BQU0sR0FBRyxDQUFDLElBQUk7SUFDbEIsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUU7TUFDdEQsSUFBSSxLQUFLLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUM7TUFDdkMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxlQUFlLEVBQUM7TUFDdEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsVUFBUztNQUNsQyxDQUFDLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBQztNQUN0RCxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFFO0tBQ3JCO0lBQ0Y7O0VBRUQsTUFBTSxRQUFRLEdBQUcsQ0FBQyxJQUFJO0lBQ3BCLE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBQztJQUNyRCxNQUFNLGFBQWEsR0FBRyxRQUFRLElBQUksSUFBSSxDQUFDLFlBQVc7SUFDbEQsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksYUFBYSxFQUFFO01BQ2hDLENBQUMsQ0FBQyxjQUFjLEdBQUU7TUFDbEIsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVc7UUFDckIsZUFBZSxDQUFDLGFBQWEsQ0FBQyxFQUFDO0tBQ2xDO0lBQ0Y7O0VBRUQsTUFBTSxjQUFjLEdBQUcsQ0FBQyxJQUFJO0lBQzFCLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7TUFDbEMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFDO0lBQ2pCOztFQUVELE1BQU0sZUFBZSxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUM7SUFDaEMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUk7TUFDckIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7U0FDdEIsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDO1VBQ2pCLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsS0FBSyxFQUFDOztNQUUzQixLQUFLLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQztVQUNsQyxLQUFLLEdBQUcsQ0FBQztVQUNULEtBQUssR0FBRTtLQUNaLEVBQUM7O0VBRUosTUFBTSxtQkFBbUIsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLO0lBQ3hDLENBQUMsQ0FBQyxjQUFjLEdBQUU7O0lBRWxCLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxTQUFRO0lBQ3ZCLElBQUksQ0FBQyxJQUFJLEVBQUUsTUFBTTs7SUFFakIsTUFBTSxLQUFLLEdBQUcsdUJBQXVCLENBQUMsSUFBSSxFQUFDOztJQUUzQyxJQUFJLGVBQWUsQ0FBQyxLQUFLLENBQUM7TUFDeEIsZUFBZSxDQUFDO1FBQ2QsS0FBSztRQUNMLEdBQUcsRUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztPQUMzQixFQUFDO0lBQ0w7O0VBRUQsTUFBTSxRQUFRLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSztJQUM3QixDQUFDLENBQUMsY0FBYyxHQUFFOztJQUVsQixJQUFJLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQ3BDLElBQUksU0FBUyxHQUFHLENBQUMsR0FBRyxRQUFRLEVBQUM7TUFDN0IsWUFBWSxHQUFFO01BQ2QsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUk7UUFDaEMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxPQUFNO1FBQzFCLE9BQU8sRUFBRSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1VBQzdCLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFDO1VBQ2hELElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxPQUFPO1lBQzNCLE1BQU0sQ0FBQyxJQUFJLEVBQUM7VUFDZCxFQUFFLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUM7U0FDNUI7UUFDRCxFQUFFLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxFQUFFLEVBQUM7T0FDOUIsRUFBQztLQUNIO1NBQ0k7TUFDSCxJQUFJLEdBQUcsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBQztNQUN2QyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE9BQU87UUFDNUIsUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLEtBQUs7VUFDckMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLEVBQUM7VUFDbkIsT0FBTyxHQUFHO1NBQ1gsRUFBRSxHQUFHLENBQUM7UUFDUjtNQUNELFlBQVksR0FBRTtNQUNkLE1BQU0sQ0FBQyxHQUFHLEVBQUM7S0FDWjtJQUNGOztFQUVELE1BQU0sWUFBWSxHQUFHLENBQUM7SUFDcEIsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztPQUNuQixRQUFRLENBQUMsTUFBTTtPQUNmLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXO09BQy9DLENBQUMsQ0FBQyxjQUFjLEdBQUU7O0VBRXZCLE1BQU0scUJBQXFCLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSztJQUMxQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxNQUFNOztJQUU1QixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLENBQUMsQ0FBQyxlQUFlLEdBQUU7O0lBRW5CLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxhQUFhLEVBQUUsSUFBSSxLQUFLO01BQ3ZELE1BQU0sZUFBZSxPQUFPLFdBQVcsQ0FBQyxJQUFJLEVBQUM7TUFDN0MsTUFBTSxnQkFBZ0IsTUFBTSxZQUFZLENBQUMsSUFBSSxFQUFDO01BQzlDLE1BQU0sa0JBQWtCLElBQUksd0JBQXdCLENBQUMsSUFBSSxFQUFDO01BQzFELE1BQU0sa0JBQWtCLElBQUksdUJBQXVCLENBQUMsSUFBSSxFQUFDOztNQUV6RCxJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUU7UUFDekIsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLGVBQWU7VUFDeEMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUM7YUFDL0IsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLGtCQUFrQjtVQUNsRCxhQUFhLENBQUMsR0FBRyxDQUFDLGtCQUFrQixFQUFDOztVQUVyQyxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksRUFBQztPQUMxQjtXQUNJO1FBQ0gsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLGdCQUFnQjtVQUN6QyxhQUFhLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFDO2FBQ2hDLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxrQkFBa0I7VUFDbEQsYUFBYSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBQzs7VUFFckMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUM7T0FDMUI7O01BRUQsT0FBTyxhQUFhO0tBQ3JCLEVBQUUsSUFBSSxHQUFHLEVBQUUsRUFBQzs7SUFFYixJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQUU7TUFDaEIsWUFBWSxHQUFFO01BQ2QsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLElBQUk7UUFDdEIsTUFBTSxDQUFDLElBQUksRUFBQztRQUNaLFFBQVEsQ0FBQyxJQUFJLEVBQUM7T0FDZixFQUFDO0tBQ0g7SUFDRjs7RUFFRCxNQUFNLFFBQVEsR0FBRyxFQUFFLElBQUk7SUFDckIsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVU7SUFDOUMsSUFBSSxXQUFVOztJQUVkLElBQUksV0FBVyxLQUFLLGVBQWUsRUFBRTtNQUNuQ2lCLFdBQTBCLEdBQUU7TUFDNUIsVUFBVSxHQUFHQyxVQUFvQjtLQUNsQztTQUNJLElBQUksV0FBVyxLQUFLLFdBQVcsRUFBRTtNQUNwQ0MsU0FBaUIsR0FBRTtNQUNuQixVQUFVLEdBQUdDLFFBQVc7S0FDekI7O0lBRUQsSUFBSSxDQUFDLFVBQVUsRUFBRSxNQUFNOztJQUV2QixNQUFNLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxxQkFBcUIsR0FBRTtJQUM5QyxNQUFNLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxHQUFHLE9BQU07O0lBRTNDLFVBQVUsQ0FBQyxFQUFFLEVBQUU7TUFDYixPQUFPLEdBQUcsR0FBRztNQUNiLE9BQU8sR0FBRyxJQUFJO01BQ2QsS0FBSyxLQUFLLFdBQVcsR0FBRyxHQUFHLEdBQUcsRUFBRTtNQUNoQyxLQUFLLEtBQUssV0FBVyxHQUFHLElBQUksR0FBRyxFQUFFO0tBQ2xDLEVBQUM7SUFDSDs7RUFFRCxNQUFNLFFBQVEsR0FBRyxDQUFDLElBQUk7SUFDcEIsTUFBTSxPQUFPLEdBQUcsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsT0FBTyxFQUFDOztJQUUxRCxJQUFJLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxPQUFPLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQztNQUMvRCxPQUFPLFVBQVUsRUFBRTs7SUFFckIsY0FBYyxDQUFDLE9BQU8sRUFBQzs7SUFFdkIsSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLEtBQUssUUFBUSxJQUFJLFFBQVEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxPQUFPLEVBQUU7TUFDMUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLEVBQUM7TUFDNUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLFNBQVE7TUFDMUIsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztLQUM5QztTQUNJLElBQUksT0FBTyxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO01BQy9DLE9BQU8sQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLEVBQUM7TUFDekMsaUJBQWlCLEdBQUU7S0FDcEI7SUFDRjs7RUFFRCxNQUFNLE1BQU0sR0FBRyxFQUFFLElBQUk7SUFDbkIsRUFBRSxDQUFDLFlBQVksQ0FBQyxlQUFlLEVBQUUsSUFBSSxFQUFDO0lBQ3RDLEVBQUUsQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxNQUFNLEVBQUM7O0lBRS9DLFVBQVUsR0FBRTs7SUFFWixhQUFhLENBQUMsRUFBRSxFQUFDO0lBQ2pCLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFDO0lBQ3BCLFlBQVksR0FBRTtJQUNmOztFQUVELE1BQU0sU0FBUyxHQUFHO0lBQ2hCLFNBQVE7O0VBRVYsTUFBTSxZQUFZLEdBQUcsTUFBTTtJQUN6QixRQUFRO09BQ0wsT0FBTyxDQUFDLEVBQUU7UUFDVCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDO1VBQ1QsZUFBZSxPQUFPLElBQUk7VUFDMUIsb0JBQW9CLEVBQUUsSUFBSTtVQUMxQixlQUFlLE9BQU8sSUFBSTtVQUMxQixvQkFBb0IsRUFBRSxJQUFJO1NBQzNCLENBQUMsRUFBQzs7SUFFUCxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxPQUFPLEVBQUUsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQzVDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsRUFBQzs7SUFFZCxNQUFNLE1BQU0sR0FBRTtJQUNkLE9BQU8sS0FBSyxHQUFFO0lBQ2QsUUFBUSxJQUFJLEdBQUU7SUFDZjs7RUFFRCxNQUFNLFVBQVUsR0FBRyxNQUFNO0lBQ3ZCLE1BQU0scUJBQXFCLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLElBQUk7TUFDL0MsSUFBSSxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sT0FBTyxZQUFZLENBQUMsRUFBRSxDQUFDO1dBQzVDLElBQUksV0FBVyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE9BQU8sV0FBVyxDQUFDLEVBQUUsQ0FBQztXQUMzQyxJQUFJLEVBQUUsQ0FBQyxVQUFVLElBQUksT0FBTyxFQUFFLENBQUMsVUFBVTtLQUMvQyxFQUFDOztJQUVGLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLFFBQVEsRUFBRSxHQUFHLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUU7TUFDekQsRUFBRSxDQUFDLE1BQU0sRUFBRSxFQUFDOztJQUVkLE1BQU0sTUFBTSxHQUFFO0lBQ2QsT0FBTyxLQUFLLEdBQUU7SUFDZCxRQUFRLElBQUksR0FBRTs7SUFFZCxxQkFBcUIsQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUM5QixNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUM7SUFDZDs7RUFFRCxNQUFNLGVBQWUsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEdBQUcsR0FBRyxLQUFLLENBQUMsS0FBSztJQUNoRCxJQUFJLEdBQUcsRUFBRTtNQUNQLE1BQU0sV0FBVyxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsdUJBQXVCLEVBQUM7TUFDdEQsV0FBVyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUM7S0FDNUI7U0FDSTtNQUNILE1BQU0sVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUM7TUFDM0IsSUFBSSxDQUFDLFVBQVUsRUFBRSxNQUFNOztNQUV2QixNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsU0FBUTtNQUN6QixNQUFNLGVBQWUsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDO1FBQ3ZELElBQUksSUFBSSxNQUFNO1lBQ1YsS0FBSyxHQUFHLENBQUM7WUFDVCxLQUFLO1FBQ1QsSUFBSSxFQUFDOztNQUVQLElBQUksZUFBZSxLQUFLLElBQUksRUFBRTtRQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsR0FBRyxDQUFDLENBQUMsRUFBRTtVQUNwQyxNQUFNLFNBQVMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUM7VUFDdkUsSUFBSSxTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVMsRUFBQztTQUNqQzthQUNJO1VBQ0gsTUFBTSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxDQUFDLEVBQUM7U0FDeEM7T0FDRjtLQUNGO0lBQ0Y7O0VBRUQsTUFBTSx1QkFBdUIsR0FBRyxJQUFJO0lBQ2xDLENBQUMsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUUsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUM7O0VBRTFELE1BQU0sY0FBYyxHQUFHLEVBQUUsSUFBSTtJQUMzQixJQUFJLFdBQVcsQ0FBQyxNQUFNLEtBQUssRUFBRSxFQUFFLE1BQU07O0lBRXJDLFdBQVcsQ0FBQyxNQUFNLElBQUksR0FBRTtJQUN4QixXQUFXLENBQUMsT0FBTyxHQUFHLFdBQVcsQ0FBQyxFQUFFLEVBQUM7SUFDckMsV0FBVyxDQUFDLEtBQUssR0FBRyxnQkFBZ0IsQ0FBQyxFQUFFLEVBQUUsQ0FBQztjQUNoQyxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDakMsRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDO01BQzFCLEVBQUUsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7U0FDN0IsTUFBTSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO1NBQzFCLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLEtBQUssQ0FBQztVQUN4QixFQUFFLEtBQUssQ0FBQztjQUNKLEVBQUUsSUFBSSxDQUFDO1FBQ2IsQ0FBQyxFQUFFLEVBQUUsQ0FBQztPQUNQO0lBQ0gsQ0FBQyxFQUFDO0lBQ0g7O0VBRUQsTUFBTSxVQUFVLEdBQUcsTUFBTTtJQUN2QixJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxNQUFNOztJQUUvQixXQUFXLENBQUMsT0FBTyxJQUFJLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFFO0lBQ25ELFdBQVcsQ0FBQyxLQUFLLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUU7O0lBRS9DLFdBQVcsQ0FBQyxNQUFNLElBQUksS0FBSTtJQUMxQixXQUFXLENBQUMsT0FBTyxHQUFHLEtBQUk7SUFDMUIsV0FBVyxDQUFDLEtBQUssS0FBSyxLQUFJO0lBQzNCOztFQUVELE1BQU0sYUFBYSxHQUFHLEVBQUUsSUFBSTtJQUMxQixJQUFJLE1BQU0sR0FBRyxZQUFZLENBQUMsRUFBRSxFQUFDO0lBQzdCLElBQUksS0FBSyxJQUFJLFdBQVcsQ0FBQyxFQUFFLEVBQUUsQ0FBQztjQUNwQixFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDakMsRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDO01BQzFCLEVBQUUsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7U0FDN0IsTUFBTSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO1NBQzFCLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLEtBQUssQ0FBQztVQUN4QixFQUFFLEtBQUssQ0FBQztjQUNKLEVBQUUsSUFBSSxDQUFDO1FBQ2IsQ0FBQyxFQUFFLEVBQUUsQ0FBQztPQUNQO0lBQ0gsQ0FBQyxFQUFDOztJQUVGLElBQUksUUFBUSxVQUFVLGNBQWMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUM7SUFDeEQsSUFBSSxjQUFjLElBQUksY0FBYyxDQUFDLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBQzs7SUFFeEQsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUUsRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFLEVBQUM7SUFDMUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLEVBQUUsU0FBUyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLEVBQUM7O0lBRXZFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxJQUFJO01BQ2pDLFFBQVEsQ0FBQyxVQUFVLEdBQUU7TUFDckIsY0FBYyxDQUFDLFVBQVUsR0FBRTtLQUM1QixFQUFDO0lBQ0g7O0VBRUQsTUFBTSxRQUFRLEdBQUcsQ0FBQyxFQUFFLEVBQUUsS0FBSztJQUN6QixLQUFLLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxxQkFBcUIsR0FBRTs7RUFFM0MsTUFBTSxXQUFXLEdBQUcsQ0FBQyxFQUFFLEVBQUUsSUFBSSxLQUFLO0lBQ2hDLE1BQU0sRUFBRSxHQUFHLFFBQVEsQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQyxFQUFDOztJQUVyRCxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFO01BQ2YsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLEVBQUM7O01BRXBELEtBQUssQ0FBQyxJQUFJLEdBQUcsS0FBSTtNQUNqQixLQUFLLENBQUMsUUFBUSxHQUFHO1FBQ2YsWUFBWSxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRTtRQUMxQyxhQUFhLEdBQUcsRUFBRTtRQUNuQjs7TUFFRCxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUM7O01BRWhDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztRQUNqQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxNQUFNO1FBQ3hCLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLEtBQUk7O1FBRTdCLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxFQUFFO1VBQ2xDLEVBQUUsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUMsRUFBQzs7UUFFM0MsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsdUJBQXVCLEVBQUUsRUFBRTtVQUNyRCxNQUFNLENBQUMsU0FBUyxLQUFLLFlBQVk7Y0FDN0IsRUFBRSxDQUFDLFlBQVksQ0FBQyxvQkFBb0IsRUFBRSxJQUFJLENBQUM7Y0FDM0MsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFDO09BQ2xCLEVBQUM7O01BRUYsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxJQUFJO1FBQzdCLENBQUMsQ0FBQyxjQUFjLEdBQUU7UUFDbEIsQ0FBQyxDQUFDLGVBQWUsR0FBRTtRQUNuQixTQUFTLENBQUMsc0JBQXNCLEVBQUUsRUFBRTtVQUNsQyxFQUFFLENBQUMsZUFBZSxDQUFDLG9CQUFvQixDQUFDLEVBQUM7T0FDNUMsRUFBQzs7TUFFRixNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQUs7O01BRTdCLE9BQU8sS0FBSztLQUNiO0lBQ0Y7O0VBRUQsTUFBTSxZQUFZLEdBQUcsRUFBRSxJQUFJO0lBQ3pCLE1BQU0sRUFBRSxHQUFHLFFBQVEsQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQyxFQUFDOztJQUVyRCxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFO01BQ2hCLE1BQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLEVBQUM7O01BRXZELE1BQU0sQ0FBQyxRQUFRLEdBQUc7UUFDaEIsWUFBWSxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRTtRQUMxQyxhQUFhLEdBQUcsRUFBRTtRQUNuQjs7TUFFRCxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUM7O01BRWpDLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsT0FBTTtNQUNoQyxPQUFPLE1BQU07S0FDZDtJQUNGOztFQUVELE1BQU0sV0FBVyxHQUFHLEVBQUUsSUFBSTtJQUN4QixJQUFJLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsRUFBRTtNQUMvRSxJQUFJLFdBQVcsQ0FBQyxPQUFPO1FBQ3JCLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFFOztNQUU5QixXQUFXLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsY0FBYyxFQUFDOztNQUU1RCxXQUFXLENBQUMsT0FBTyxDQUFDLFFBQVEsR0FBRztRQUM3QixZQUFZLEVBQUUsRUFBRSxDQUFDLHFCQUFxQixFQUFFO1FBQ3pDOztNQUVELFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUM7O01BRTlDLE9BQU8sV0FBVyxDQUFDLE9BQU87S0FDM0I7SUFDRjs7RUFFRCxNQUFNLGdCQUFnQixHQUFHLENBQUMsRUFBRSxFQUFFLElBQUksS0FBSztJQUNyQyxJQUFJLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsRUFBRTtNQUMvRSxJQUFJLFdBQVcsQ0FBQyxLQUFLO1FBQ25CLFdBQVcsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFFOztNQUU1QixXQUFXLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsY0FBYyxFQUFDOztNQUUxRCxXQUFXLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxLQUFJO01BQzdCLFdBQVcsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHO1FBQzNCLFlBQVksSUFBSSxFQUFFLENBQUMscUJBQXFCLEVBQUU7UUFDMUMsYUFBYSxHQUFHLE9BQU87UUFDeEI7O01BRUQsV0FBVyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQywrQkFBK0IsRUFBQzs7TUFFM0QsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBQzs7TUFFNUMsT0FBTyxXQUFXLENBQUMsS0FBSztLQUN6QjtJQUNGOztFQUVELE1BQU0sU0FBUyxHQUFHLENBQUMsSUFBSSxFQUFFLE1BQU0sS0FBSztJQUNsQyxNQUFNLENBQUMsUUFBUSxHQUFHO01BQ2hCLFlBQVksSUFBSSxJQUFJLENBQUMscUJBQXFCLEVBQUU7TUFDNUMsYUFBYSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDO01BQ25EO0lBQ0Y7O0VBRUQsTUFBTSxjQUFjLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO0lBQzFDLElBQUksZ0JBQWdCLENBQUMsSUFBSSxJQUFJO01BQzNCLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFDO01BQ3JCLFNBQVMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFDO0tBQ3hCLEVBQUM7O0VBRUosTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLEVBQUUsRUFBRSxpQkFBaUIsR0FBRyxJQUFJLEtBQUs7SUFDekQsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBQztJQUMxQixJQUFJLGlCQUFpQixFQUFFLEVBQUUsQ0FBQyxRQUFRLEVBQUM7SUFDcEM7O0VBRUQsTUFBTSxzQkFBc0IsR0FBRyxFQUFFO0lBQy9CLGlCQUFpQixHQUFHLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxRQUFRLElBQUksUUFBUSxJQUFJLEVBQUUsRUFBQzs7RUFFMUUsTUFBTSxZQUFZLEdBQUc7SUFDbkIsaUJBQWlCLENBQUMsT0FBTyxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUM7O0VBRS9DLE1BQU0sVUFBVSxHQUFHLE1BQU07SUFDdkIsWUFBWSxHQUFFO0lBQ2QsUUFBUSxHQUFFO0lBQ1g7O0VBRUQsTUFBTSxrQkFBa0IsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLO0lBQ3ZDLE1BQU0sT0FBTyxHQUFHLFFBQVE7T0FDckIsTUFBTSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztPQUNwQyxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUM7UUFDdkIsQ0FBQyxHQUFHLElBQUksRUFBRSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUM7O0lBRTNDLElBQUksT0FBTyxDQUFDLE1BQU0sRUFBRTtNQUNsQixDQUFDLENBQUMsY0FBYyxHQUFFO01BQ2xCLENBQUMsQ0FBQyxlQUFlLEdBQUU7O01BRW5CLFlBQVksR0FBRTtNQUNkLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBQztLQUN0QztJQUNGOztFQUVELG9CQUFvQixHQUFFO0VBQ3RCLE1BQU0sR0FBRTs7RUFFUixPQUFPO0lBQ0wsTUFBTTtJQUNOLFNBQVM7SUFDVCxZQUFZO0lBQ1osZ0JBQWdCO0lBQ2hCLHNCQUFzQjtJQUN0QixVQUFVO0dBQ1g7Q0FDRjs7QUN2bkJEO0FBQ0EsTUFBTWhDLFlBQVUsR0FBRyxvQkFBb0I7R0FDcEMsS0FBSyxDQUFDLEdBQUcsQ0FBQztHQUNWLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLO0lBQ3BCLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25FLEVBQUUsQ0FBQztHQUNKLFNBQVMsQ0FBQyxDQUFDLEVBQUM7O0FBRWYsTUFBTWlDLGdCQUFjLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxXQUFXLEVBQUM7O0FBRWhHLEFBQU8sU0FBUyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRTtFQUNuQyxPQUFPLENBQUNqQyxZQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ2xDLElBQUksQ0FBQyxDQUFDLFlBQVksRUFBRSxNQUFNOztJQUUxQixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLFVBQVUsQ0FBQyxTQUFTLEVBQUUsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFDO0dBQ3JDLEVBQUM7O0VBRUYsT0FBTyxDQUFDaUMsZ0JBQWMsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDdEMsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixrQkFBa0IsQ0FBQyxTQUFTLEVBQUUsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFDO0dBQzdDLEVBQUM7O0VBRUYsT0FBTyxNQUFNO0lBQ1gsT0FBTyxDQUFDLE1BQU0sQ0FBQ2pDLFlBQVUsRUFBQztJQUMxQixPQUFPLENBQUMsTUFBTSxDQUFDaUMsZ0JBQWMsRUFBQztJQUM5QixPQUFPLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUFDO0dBQ3JDO0NBQ0Y7O0FBRUQsQUFBTyxTQUFTLFVBQVUsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFO0VBQ3pDLEdBQUc7S0FDQSxHQUFHLENBQUMsRUFBRSxJQUFJLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0tBQy9CLEdBQUcsQ0FBQyxFQUFFLEtBQUs7TUFDVixFQUFFO01BQ0YsS0FBSyxLQUFLLFNBQVMsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDO01BQ3hDLE9BQU8sR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxTQUFTLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO01BQ3BFLE1BQU0sSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztNQUN6RCxRQUFRLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDO0tBQy9DLENBQUMsQ0FBQztLQUNGLEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxRQUFRO1lBQ3JCLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU07WUFDaEMsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTTtPQUNyQyxDQUFDLENBQUM7S0FDSixPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDO01BQzVCLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLE9BQU8sR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBQztDQUN4RDs7QUFFRCxBQUFPLFNBQVMsa0JBQWtCLENBQUMsR0FBRyxFQUFFLFVBQVUsRUFBRTtFQUNsRCxNQUFNLEtBQUssR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBQztFQUNuQyxJQUFJLEtBQUssR0FBRyxHQUFFOztFQUVkLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxLQUFLLEdBQUcsUUFBUSxHQUFHLE1BQUs7RUFDdEQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssR0FBRyxNQUFNLEdBQUcsTUFBSzs7RUFFcEQsb0JBQW9CLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztLQUM1QixPQUFPLENBQUMsSUFBSSxJQUFJLFVBQVUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxHQUFHLElBQUksQ0FBQyxFQUFDO0NBQ2xEOztBQzFERCxNQUFNLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztFQUN0QyxNQUFNLENBQUMsZUFBZSxDQUFDLGlCQUFpQixFQUFDO0VBQ3pDLE1BQU0sQ0FBQyxlQUFlLENBQUMsWUFBWSxFQUFDO0VBQ3BDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsaUJBQWlCLEVBQUM7RUFDckQsTUFBTSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsRUFBRUMsY0FBWSxFQUFDO0VBQ25ELE9BQU8sQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFDO0VBQzdCOztBQUVELE1BQU1BLGNBQVksR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxRQUFRLElBQUksQ0FBQyxDQUFDLGVBQWUsR0FBRTs7QUFFbEUsTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0VBQzlCLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLElBQUksaUJBQWlCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFDO0VBQ3ZFLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQyxLQUFLLEdBQUU7RUFDOUI7O0FBRUQsQUFBTyxTQUFTLFFBQVEsQ0FBQyxRQUFRLEVBQUU7RUFDakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsTUFBTTs7RUFFNUIsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLElBQUk7SUFDakIsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBQzs7SUFFZixHQUFHLENBQUMsSUFBSSxDQUFDO01BQ1AsZUFBZSxFQUFFLElBQUk7TUFDckIsVUFBVSxFQUFFLElBQUk7S0FDakIsRUFBQztJQUNGLEVBQUUsQ0FBQyxLQUFLLEdBQUU7SUFDVixpQkFBaUIsQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFDOztJQUUzQixHQUFHLENBQUMsRUFBRSxDQUFDLFNBQVMsRUFBRUEsY0FBWSxFQUFDO0lBQy9CLEdBQUcsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLGlCQUFpQixFQUFDO0dBQ2xDLEVBQUM7O0VBRUYsT0FBTyxDQUFDLFlBQVksRUFBRSxPQUFPLEVBQUM7OztDQUMvQixEQ2xDRCxNQUFNbEMsWUFBVSxHQUFHLG9CQUFvQjtHQUNwQyxLQUFLLENBQUMsR0FBRyxDQUFDO0dBQ1YsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUs7SUFDcEIsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuQyxFQUFFLENBQUM7R0FDSixTQUFTLENBQUMsQ0FBQyxFQUFDOztBQUVmLE1BQU1pQyxnQkFBYyxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxLQUFLLEVBQUM7O0FBRXRELEFBQU8sU0FBUyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRTtFQUNoQyxPQUFPLENBQUNqQyxZQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ2xDLElBQUksQ0FBQyxDQUFDLFlBQVksRUFBRSxNQUFNOztJQUUxQixDQUFDLENBQUMsY0FBYyxHQUFFOztJQUVsQixJQUFJLGFBQWEsR0FBRyxTQUFTLEVBQUU7UUFDM0IsSUFBSSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBQzs7SUFFakMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO01BQ2pELElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO1VBQ2xCLGFBQWEsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQztVQUN6QyxlQUFlLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUM7O01BRS9DLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO1VBQ2xCLGFBQWEsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQztVQUN6QyxjQUFjLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUM7R0FDakQsRUFBQzs7RUFFRixPQUFPLENBQUNpQyxnQkFBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUN0QyxDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLElBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBQztJQUNqQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksR0FBRyxNQUFNLEVBQUM7R0FDbkUsRUFBQzs7RUFFRixPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSTtJQUNwQixTQUFTLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUNwQixFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVU7UUFDakIsRUFBRSxDQUFDLEtBQUssQ0FBQyxVQUFVLElBQUksTUFBTTtZQUN6QixJQUFJO1lBQ0osTUFBTSxFQUFDO0dBQ2hCLEVBQUM7O0VBRUYsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUk7SUFDcEIsU0FBUyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUU7TUFDcEIsRUFBRSxDQUFDLEtBQUssQ0FBQyxTQUFTO1FBQ2hCLEVBQUUsQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFJLFFBQVE7WUFDMUIsSUFBSTtZQUNKLFFBQVEsRUFBQztHQUNsQixFQUFDOztFQUVGLE9BQU8sTUFBTTtJQUNYLE9BQU8sQ0FBQyxNQUFNLENBQUNqQyxZQUFVLEVBQUM7SUFDMUIsT0FBTyxDQUFDLE1BQU0sQ0FBQ2lDLGdCQUFjLEVBQUM7SUFDOUIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUM7SUFDN0IsT0FBTyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsRUFBQztHQUNyQztDQUNGOztBQUVELEFBQU8sU0FBUyxhQUFhLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRTtFQUM1QyxHQUFHO0tBQ0EsR0FBRyxDQUFDLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUMvQixHQUFHLENBQUMsRUFBRSxLQUFLO01BQ1YsRUFBRTtNQUNGLEtBQUssS0FBSyxZQUFZO01BQ3RCLE9BQU8sR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxZQUFZLENBQUMsQ0FBQztNQUM5QyxNQUFNLElBQUksQ0FBQztNQUNYLFFBQVEsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7S0FDaEQsQ0FBQyxDQUFDO0tBQ0YsR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU8sSUFBSSxRQUFRLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDMUQsSUFBSSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxVQUFVLENBQUMsQ0FBQztZQUNqRCxPQUFPLENBQUMsT0FBTztPQUNwQixDQUFDLENBQUM7S0FDSixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLEtBQUssRUFBRSxPQUFPLENBQUMsUUFBUTtZQUNuQixPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxNQUFNO1lBQ2hDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU07T0FDckMsQ0FBQyxDQUFDO0tBQ0osT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztNQUMxQixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLEVBQUM7Q0FDcEM7O0FBRUQsQUFBTyxTQUFTLGFBQWEsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFO0VBQzVDLEdBQUc7S0FDQSxHQUFHLENBQUMsRUFBRSxJQUFJLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0tBQy9CLEdBQUcsQ0FBQyxFQUFFLEtBQUs7TUFDVixFQUFFO01BQ0YsS0FBSyxLQUFLLGVBQWU7TUFDekIsT0FBTyxHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLGVBQWUsQ0FBQyxDQUFDO01BQ25ELE1BQU0sSUFBSSxFQUFFO01BQ1osUUFBUSxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztLQUNoRCxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTyxJQUFJLFFBQVEsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztZQUMxRCxDQUFDO1lBQ0QsT0FBTyxDQUFDLE9BQU87T0FDcEIsQ0FBQyxDQUFDO0tBQ0osR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixLQUFLLEVBQUUsT0FBTyxDQUFDLFFBQVE7WUFDbkIsQ0FBQyxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztZQUM3QyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO09BQ2xELENBQUMsQ0FBQztLQUNKLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7TUFDMUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxFQUFFLENBQUMsRUFBQztDQUN2RDs7QUFFRCxBQUFPLFNBQVMsY0FBYyxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDN0MsR0FBRztLQUNBLEdBQUcsQ0FBQyxFQUFFLElBQUksZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDL0IsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLEtBQUssVUFBVTtNQUNwQixPQUFPLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsVUFBVSxDQUFDLENBQUM7TUFDNUMsTUFBTSxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDO01BQ3pELFFBQVEsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7S0FDaEQsQ0FBQyxDQUFDO0tBQ0YsR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixTQUFTLEVBQUUsT0FBTyxDQUFDLFFBQVE7WUFDdkIsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTTtZQUNoQyxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxNQUFNO09BQ3JDLENBQUMsQ0FBQztLQUNKLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxTQUFTLENBQUM7TUFDOUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsU0FBUyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFDO0NBQzdEOztBQUVELE1BQU0sU0FBUyxHQUFHO0VBQ2hCLE1BQU0sRUFBRSxDQUFDO0VBQ1QsSUFBSSxJQUFJLENBQUM7RUFDVCxLQUFLLEdBQUcsQ0FBQztFQUNULEVBQUUsRUFBRSxDQUFDO0VBQ0wsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0VBQ3hFO0FBQ0QsTUFBTSxhQUFhLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBQzs7QUFFM0QsQUFBTyxTQUFTLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDL0MsR0FBRztLQUNBLEdBQUcsQ0FBQyxFQUFFLElBQUksZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDL0IsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLEtBQUssWUFBWTtNQUN0QixPQUFPLEdBQUcsUUFBUSxDQUFDLEVBQUUsRUFBRSxZQUFZLENBQUM7TUFDcEMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztLQUNqRCxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLEtBQUssRUFBRSxPQUFPLENBQUMsU0FBUztZQUNwQixTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7WUFDOUIsU0FBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO09BQ25DLENBQUMsQ0FBQztLQUNKLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7TUFDMUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxhQUFhLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxJQUFJLGFBQWEsQ0FBQyxNQUFNO1VBQ3pFLGFBQWEsQ0FBQyxNQUFNO1VBQ3BCLEtBQUs7T0FDUixFQUFDO0NBQ1A7O0FBRUQsTUFBTSxRQUFRLEdBQUc7RUFDZixLQUFLLEVBQUUsQ0FBQztFQUNSLElBQUksRUFBRSxDQUFDO0VBQ1AsTUFBTSxFQUFFLENBQUM7RUFDVCxLQUFLLEVBQUUsQ0FBQztFQUNUO0FBQ0QsTUFBTSxZQUFZLEdBQUcsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBQzs7QUFFOUMsQUFBTyxTQUFTLGVBQWUsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFO0VBQzlDLEdBQUc7S0FDQSxHQUFHLENBQUMsRUFBRSxJQUFJLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0tBQy9CLEdBQUcsQ0FBQyxFQUFFLEtBQUs7TUFDVixFQUFFO01BQ0YsS0FBSyxLQUFLLFdBQVc7TUFDckIsT0FBTyxHQUFHLFFBQVEsQ0FBQyxFQUFFLEVBQUUsV0FBVyxDQUFDO01BQ25DLFNBQVMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7S0FDakQsQ0FBQyxDQUFDO0tBQ0YsR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixLQUFLLEVBQUUsT0FBTyxDQUFDLFNBQVM7WUFDcEIsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO1lBQzdCLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztPQUNsQyxDQUFDLENBQUM7S0FDSixPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO01BQzFCLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsWUFBWSxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFDO0NBQzNFOztBQzFMRCxNQUFNakMsWUFBVSxHQUFHLG9CQUFvQjtHQUNwQyxLQUFLLENBQUMsR0FBRyxDQUFDO0dBQ1YsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUs7SUFDcEIsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuQyxFQUFFLENBQUM7R0FDSixTQUFTLENBQUMsQ0FBQyxFQUFDOztBQUVmLE1BQU1pQyxnQkFBYyxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFDOztBQUV2RixBQUFPLFNBQVMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUU7RUFDaEMsT0FBTyxDQUFDakMsWUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUNsQyxJQUFJLENBQUMsQ0FBQyxZQUFZLEVBQUUsTUFBTTs7SUFFMUIsQ0FBQyxDQUFDLGNBQWMsR0FBRTs7SUFFbEIsSUFBSSxhQUFhLEdBQUcsU0FBUyxFQUFFO1FBQzNCLElBQUksR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUM7O0lBRWpDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztNQUNqRCxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztVQUNsQixtQkFBbUIsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQztVQUMvQyxnQkFBZ0IsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBQzs7TUFFaEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7VUFDbEIsbUJBQW1CLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUM7VUFDL0MsZ0JBQWdCLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUM7R0FDbkQsRUFBQzs7RUFFRixPQUFPLENBQUNpQyxnQkFBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUN0QyxDQUFDLENBQUMsY0FBYyxHQUFFOztJQUVsQixJQUFJLGFBQWEsR0FBRyxTQUFTLEVBQUU7UUFDM0IsSUFBSSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBQzs7SUFFakMsZUFBZSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEtBQUssR0FBRyxRQUFRLEVBQUM7R0FDekUsRUFBQzs7RUFFRixPQUFPLE1BQU07SUFDWCxPQUFPLENBQUMsTUFBTSxDQUFDakMsWUFBVSxFQUFDO0lBQzFCLE9BQU8sQ0FBQyxNQUFNLENBQUNpQyxnQkFBYyxFQUFDO0lBQzlCLE9BQU8sQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUM7R0FDckM7Q0FDRjs7QUFFRCxNQUFNLFVBQVUsR0FBRyxFQUFFLElBQUk7RUFDdkIsRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTTtFQUN6QixPQUFPLEVBQUU7RUFDVjs7QUFFRCxNQUFNLDZCQUE2QixHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksS0FBSztFQUNuRCxJQUFJLElBQUksSUFBSSxPQUFPLEtBQUssR0FBRyxJQUFJLFlBQVksSUFBSSxHQUFHLElBQUksUUFBUSxJQUFJLEdBQUcsSUFBSSxVQUFVLENBQUM7SUFDbEYsR0FBRyxHQUFHLFNBQVE7T0FDWCxJQUFJLElBQUksSUFBSSxZQUFZLEtBQUssR0FBRyxJQUFJLGNBQWMsSUFBSSxHQUFHLElBQUksZUFBZSxDQUFDO0lBQ2hGLEdBQUcsR0FBRyxTQUFROztFQUVoQixPQUFPLEdBQUc7RUFDWDs7O0FBR0QsQUFBTyxTQUFTLGVBQWUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFO0VBQzFDLEdBQUc7S0FDQSxHQUFHLENBQUMsVUFBVSxDQUFDO0tBQ2YsR0FBRyxDQUFDLEVBQUUsSUFBSTtNQUNULEVBQUUsQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLE1BQUs7S0FDL0IsRUFBQztDQUNMOztBQUVELE1BQU0sVUFBVSxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUMsR0FBRTtBQUM5RSxNQUFNRSxnQkFBYyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUM7O0FBRTFELEFBQU8sU0FBUyxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFO0VBQy9DLEdBQUc7S0FDQSxHQUFHLENBQUMsVUFBVSxDQUFDO0tBQ2YsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLEtBQUssZ0JBQWdCO01BQzFCLE9BQU8sR0FBRyw2QkFBNkIsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLGdCQUFnQixDQUFDLEVBQUUsT0FBTyxDQUFDO01BQ2hGLFNBQVMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7S0FDakQsQ0FBQyxDQUFDO0tBQ0YsR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixLQUFLLEVBQUUsT0FBTyxDQUFDLFNBQVM7WUFDcEIsVUFBVSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO1lBQy9CLFVBQVUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztPQUNwQyxDQUFDLENBQUM7S0FDSixPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO01BQzFCLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUdBLGdCQUFjLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUM7Q0FDN0U7QUFDRCxBQUVBLE1BQU1DLGdCQUFjLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBQzs7QUFFMUQsQUFBTyxTQUFTLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDL0MsR0FBRztLQUNBLEdBQUcsQ0FBQyxVQUFVLENBQUM7S0FDZixHQUFHLENBQUMsRUFBRSxLQUFLO01BQ1YsRUFBRTtNQUNGLEtBQUssS0FBSyxZQUFZO01BQ3RCLE9BQU8sR0FBRyxRQUFRLENBQUMsRUFBRSxFQUFFLFlBQVksQ0FBQztNQUNwQyxTQUFTLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO0tBQy9DLENBQUMsQ0FBQztLQUNGLEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxTQUFTO1lBQ3BCLFVBQVUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztZQUMvQixVQUFVLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7T0FDcEMsQ0FBQyxDQUFDO0tBQ0osT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztNQUMxQixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHQSxnQkFBYyxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFDO0NBQzdFOztBQUVELE1BQU0saUJBQWlCLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFFO0FBQ3RGLE1BQU0scUJBQXFCLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLGVBQWUsRUFBQzs7QUFFbEUsQUFBTyxTQUFTLG1CQUFtQixDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDbEQsR0FBRztLQUNBLEdBQUcsQ0FBQyxVQUFVLENBQUM7S0FDZixHQUFHLENBQUMsRUFBRSxLQUFLO01BQ1YsRUFBRTtNQUNGLEtBQUssS0FBSyxnQkFBZ0I7TUFDMUIsT0FBTyxHQUFHLDZCQUE2QixDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsZ0JBQWdCLENBQUMsRUFBRSxZQUFZLENBQUM7TUFDckYsU0FBUyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztLQUNqRCxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLEtBQUssRUFBRSxPQUFPLENBQUMsU0FBUztZQUNwQixpQkFBaUIsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztZQUN0QyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztPQUMzQyxDQUFDLENBQUM7S0FDSixPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO01BQzFCLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcscUJBQXFCLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUM7Q0FDcEY7O0FBRUQsTUFBTSxpQkFBaUIsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUU7QUFDdEYsTUFBTSxxQkFBcUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsZUFBZSxFQUFDOztBQUVsRSxBQUFPLFNBQVMsbUJBQW1CLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRTtFQUNsRCxHQUFHO0tBQ0EsR0FBRyxDQUFDLFVBQVUsQ0FBQztLQUNmLEdBQUcsQ0FBQyxFQUFFLEtBQUs7TUFDVixFQUFFO01BQ0YsS0FBSyxLQUFLLGNBQWM7TUFDeEIsT0FBTyxHQUFHLFFBQVEsQ0FBQyxFQUFFLEVBQUUsY0FBYyxDQUFDO01BQ3RDLFNBQVMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7S0FDL0MsQ0FBQyxDQUFDO0tBQ0YsR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixLQUFLLEVBQUUsT0FBTyxDQUFDLFNBQVM7WUFDcEIsaUJBQWlCLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7WUFDdEMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7T0FDM0MsQ0FBQyxDQUFDO0tBQ0osT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztNQUMxQixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLHFCQUFxQixDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFDO0NBQ3BGOztBQ3hKTSxTQUFTLFdBQVcsQ0FBQyxPQUFPLEVBQUUsY0FBYyxFQUFFO0VBQ25ELE1BQU0sZ0JBQWdCLElBQUksQ0FBQyxDQUFDLGFBQWEsRUFBRSxPQUFPLEVBQUM7RUFDbkQsTUFBTSxnQkFBZ0IsSUFBSSxDQUFDLENBQUMsYUFBYSxFQUFFLE9BQU8sRUFBQztFQUNuRCxNQUFNLFlBQVksUUFBUSxDQUFDLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBQztFQUMvQyxNQUFNLE9BQU8sYUFBYSxDQUFDLENBQUMsT0FBTyxFQUFFLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxFQUFDO0VBQ3pELE1BQU0sT0FBTyxhQUFhLENBQUMsQ0FBQyxPQUFPLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLEVBQUM7RUFDekQsTUFBTSxPQUFPLGFBQWEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLEVBQUM7O0VBRXJELE1BQU0sT0FBTyxHQUFHO0lBQ2QsTUFBTSxJQUFJLHdEQUF3RDtJQUNsRSxRQUFRLEVBQUUscUNBQXFDO0lBQ2hEOztFQUVELElBQUksQ0FBQyxZQUFZLFNBQVMsYUFBWTtFQUN0QyxJQUFJLENBQUMsUUFBUSxhQUFhLEdBQUU7OztFQUc1QixPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQ25CLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7TUFDbEIsRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFDOztFQUV4QyxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQ25CLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7TUFDbEIsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLFlBQVksVUFBVTtVQUM3QixNQUFNO1VBQ04saUJBQWlCO09BQ3BCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBQzs7RUFFeEIsT0FBTyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUNuQixJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFO01BQ2xCLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxZQUFZLFVBQVU7VUFDN0IsUUFBUTtVQUNSLGNBQWM7T0FDakIsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFDOzs7RUFHeEIsY0FBYyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsSUFBSTtJQUMxQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxNQUFNO0lBQzVCLElBQUksQ0FBQyxRQUFRLEdBQUcsU0FBUTs7SUFFeEIsSUFBSSxzQkFBc0IsSUFBSSxNQUFLO0lBQ25DLElBQUksc0JBQXNCLElBQUksTUFBSztJQUNuQyxJQUFJLGtCQUFrQixRQUFRLE1BQUs7SUFDbkMsSUFBSSxFQUFFLEVBQUUsRUFBRSxFQUFFLEdBQUU7O0lBRWQsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7TUFDN0IsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUM7TUFDM0IsTUFBTSxvQkFBb0IsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxLQUFLLFdBQVU7O01BRWpGLElBQUksRUFBRSxZQUFZLFVBQVUsRUFBRTtRQUM1QixFQUFFLEdBQUcsSUFBSSxTQUFTLENBQUMsY0FBYyxFQUFDO1FBQ2xDLElBQUksT0FBTyxHQUFHLFFBQVEsQ0FBQyxFQUFFLEVBQUUsUUFBUSxFQUFDO1FBQ3BDLEVBQUUsR0FBRyxJQUFJLFNBQVMsQ0FBQyxPQUFPLEtBQUssTUFBTTtZQUNqQyxjQUFjO1lBQ2QsT0FBTyxFQUFDO1FBQ1osRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQUM7T0FDekM7V0FDSTtRQUNILEVBQUUsR0FBRyxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxFQUFDO1FBQ3pDLEVBQUUsR0FBRyxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLGlCQUFpQixDQUFDLEVBQUM7UUFDbkQsRUFBRSxHQUFHLFFBQVEsQ0FBQyxFQUFFLEVBQUUsYUFBYSxDQUFDLEtBQUssS0FBSztZQUN0QyxJQUFJLFNBQVMsQ0FBQyxjQUFjLENBQUM7WUFDN0IsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxhQUFhLENBQUMsRUFBQztPQUMvQzs7TUFFRCxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUMsV0FBVyxHQUFFO01BQ3pCLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQyxXQUFXLEdBQUU7TUFDekIsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDLFdBQVcsR0FBRTs7TUFFekIsc0JBQXNCLEdBQUcsRUFBRSxDQUFDLGFBQWEsS0FBSyxjQUFjLEtBQUssRUFBRSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxXQUFXLEtBQUssRUFBRSxFQUFDO01BQ25ILHNCQUFzQixHQUFHLEVBQUUsQ0FBQyxhQUFhLEtBQUssbUJBQWtCO01BQ2hFLGtCQUFrQixPQUFPLEVBQUUsQ0FBQyxhQUFhLEtBQUssZUFBYzs7TUFFNUQsSUFBSSxzQkFBc0IsSUFBSSxDQUFDLHNCQUFzQjtRQUNuRCxTQUFTLENBQUMsWUFBWSxFQUFDO1dBQ3BCLElBQUksc0JBQXNCLElBQUksQ0FBQyxzQkFBc0I7UUFDeEQsU0FBUyxDQUFDLFlBQVksRUFBQzs7TUFFekIsTUFBTSxNQUFNLEdBQUcsc0JBQXNCLEdBQUcsRUFBRSxHQUFHLEdBQUU7TUFDL0MsTUFBTSxNQUFNLEdBQUcsc0JBQXNCLEdBQUcsRUFBRSxHQUFHLEdBQUU7TUFDL0MsTUFBTSxNQUFNLEdBQUcsa0JBQWtCLEdBQUcsRUFBRSxHQUFHLEdBQUU7O01BRTNDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBQztNQUM3QixPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUM7TUFDN0IsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFDOztNQUU3QixnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7NEJBQ1YsRUFBRSxNQUFNLENBQUM7aUJBQ3BCLEVBQUUsc0JBQXNCLElBQUksb0JBQW9CLEdBQUcsYUFBYSxHQUFHLE1BQU0sQ0FBQztNQUNyRixDQUFDLEVBQUM7O01BRUYsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDOzRCQUNWLEVBQUUsTUFBTSxDQUFDO2lCQUNwQixFQUFFLHNCQUFzQixJQUFJLG9CQUFvQixHQUFHLGFBQWEsR0FBRyxNQUFNLENBQUM7TUFDckYsQ0FBQyxFQUFDOztNQUVGLFlBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7NEJBQ04sRUFBRSxNQUFNLENBQUM7aUJBQ3BCLEVBQUUsa0JBQWtCLElBQUksb0JBQW9CLEdBQUcsYUFBYSxHQUFHLE1BQU0sQ0FBQztNQUNqRixDQUFDLEVBQUM7S0FDSDtTQUNJOzs7TUFHSCxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBQ2xCLEVBQUUsSUFBSSxDQUFDLFlBQVksSUFBSSxZQUFZLEdBQUcsT0FBTyxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDOztNQUV0RixDQUFDLEVBQUM7O01BRUYsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO29CQUNsQixFQUFFLElBQUksQ0FBQyxZQUFZLElBQUksWUFBWSxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQzs7TUFFdEYsQ0FBQyxFQUFDOztNQUVGLFlBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBQ2QsRUFBRSxJQUFJLENBQUMsWUFBWSxJQUFJLFFBQVEsR0FBRyxPQUFPLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUM7O01BRWxGLENBQUMsRUFBQztLQUNIO0dBQ0YsRUFBQzs7RUFFRixNQUFNLFNBQVMsR0FBRztJQUNoQixJQUFJLENBQUMsYUFBWTs7RUFFbkIsTUFBTSxTQUFTLEdBQUcsR0FBRyxJQUFJO0lBQ3ZCLFlBQVksR0FBRTtJQUNkLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBRzs7SUFFdkIsSUFBSSxHQUFHLEtBQUssWUFBWTtNQUN0QixnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxPQUFNO0lBQ3RELElBQUksR0FBRyxLQUFLLFlBQVk7TUFDdEIsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsT0FBTTtJQUN0RCxJQUFJLEdBQUcsS0FBSyxRQUFRO01BQ2xCLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxPQUFNO0lBQ25EOztFQUVELE1BQU0sWUFBWSxHQUFHO0lBQ25CLENBQUMsZ0JBQWdCLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7TUFDbEUsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLFFBQVEsRUFBQzs7RUFFOUMsT0FBTztJQUNMLFNBQVM7SUFDVCxTQUFTO0lBQ1QsVUFBVSxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUs7TUFDeEIsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNyRSxVQUFVLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSztNQUN4QixnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO0dBQ3RFO0NBQ0Y7O0FDckpELE1BQU1wQyxZQUFVLEdBQUcsb0JBQW9CO0dBQ3BDLEtBQUssQ0FBQyxHQUFHLENBQUM7R0FDVixNQUFNLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSztJQUNwQixDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25DLEVBQUUsQ0FBQztHQUNKLFNBQVMsQ0FBQyxDQUFDLEVBQUM7O0FBRWYsTUFBTWlDLGdCQUFjLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLFlBQVksRUFBQzs7QUFFOUssQUFBTyxTQUFTLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUFFO0VBQ3JDLE9BQU8sQ0FBQ2pDLFlBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDbEMsSUFBSSxDQUFDLENBQUMsWUFBWSxFQUFFLE1BQU07O0lBRTFCLENBQUMsQ0FBQyxjQUFjLEdBQUU7O0lBRWxCLElBQUksYUFBYSxHQUFHLFNBQVMsRUFBRTtRQUMzQixJQUFJLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFDOztJQUVqQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7TUFDakQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7VUFDbEIsZUFBZSxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsTUFBTSxDQUFDO1VBQzVDLGVBQWUsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBQzs7TUFFN0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7VUFDbEIsZUFBZSxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsTUFBTSxDQUFDO1VBQzVDLGVBQWUsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBQztHQUNoRCxFQUFDOztFQUVGLE9BQU8sQ0FBQ2lDLGdCQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ3RDLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsSUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFDO0lBQ2pDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7UUFDM0MsZUFBZSxDQUFDLFNBQVMsRUFBRSxFQUFFLElBQUksRUFBRSxTQUFTLENBQUM7UUFDN0MsZUFBZSxDQUFDLFNBQVMsRUFBRSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUM7R0FDaEQsRUFBQzs7RUFFRixPQUFPLE1BQU07SUFDWCxPQUFPLENBQUMsTUFBTSxDQUFDakMsWUFBVSxFQUFDO0lBQzFCLE9BQU8sQ0FBQyxNQUFNLENBQUNpQyxnQkFBYyxFQUFDO0lBQzlCLE9BQU8sQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUM7R0FDckM7Q0FDRjs7QUFFRCxNQUFNLGVBQWUsR0FBRyxFQUFFLElBQUk7RUFDNUIsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxTQUFTLElBQUksTUFBTTtJQUMxRCxFQUFFLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyw0QkFBMkI7RUFDbEQsT0FBTyxFQUFFO0VBQ1Y7OztBQUdELE1BQU0sT0FBTyxHQUFHO0VBQ2QsU0FBUyxHQUFHLENBQUM7RUFDYixHQUFHLFNBQVMsQ0FBQztFQUNiLEdBQUcsU0FBUyxDQUFDO0VBQ2IsTUFBTSxNQUFNLENBQUM7RUFDYixNQUFNLE1BQU0sQ0FBQztFQUNiLE9BQU8sS0FBSyxDQUFDO0VBQ2Q7O0FBRUQsTUFBTSxrQkFBa0IsR0FBRyxFQUFFLElBQUksUUFBUSxDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFDOztBQUVyRSxBQUFPLFNBQVMsZUFBZSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFO0VBQ3BELEdBQUc7S0FDQSxHQUFHLENBQUMsZUFBZSxDQUFDO0tBQ3BCLEdBQUcsQ0FBQyxFQUFFLElBQUksZ0JBQWdCLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO0tBQ3JDLEdBQUcsQ0FBQyxFQUFFLEtBQUs7TUFDVixFQUFFO01BQ0YsS0FBSyxNQUFNLFdBQVc7TUFDdEIsT0FBTyxJQUFJLGtCQUFrQixDQUFDLEVBQUUsQ0FBQztNQUNqQyxTQUFTLEVBQUUsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztLQUMxRixDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTyxJQUFJO01BQ2QsSUFBSSxPQUFPLEdBQUcsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxPQUFPLEVBQUM7TUFDbEMsSUFBSSxHQUFHLE9BQU8sSUFBSSxLQUFLLFNBQVM7VUFDNUIsT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO1VBQ2xDLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBQzs7TUFFaEQsT0FBTyxJQUFJO1FBQ1QsS0FBSyxNQUFNO1VBQ1QsSUFBSSxNQUFNLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBQztVQUNqRCxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO2NBQ25ELENBQUMsRUFBRSxHQUFHLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQztjQUNuQixDQUFDLEVBQUUsR0FBRyxHQUFHLE1BQU0sQ0FBQyxFQUFFLEVBQUM7VUFDdkIsS0FBSztRQUNQLEtBQUssT0FBTztVQUNWLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7Y0FDbkQsT0FBTztjQUNQLEdBQUU7VUFDTixLQUFLO1FBQ1AsS0FBSyxTQUFTO1VBQ1osSUFBSSxXQUFXLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQztVQUM1RCxJQUFJLE1BQU0sR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksR0FBRyxLQUFJO1VBQ3RELE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7Y0FDbkQsV0FBVyxHQUFHLE1BQU0sR0FBRyxHQUFHO2NBQzFCLFdBQVcsR0FBRyxNQUFNLEdBQUcsSUFBRztVQUM5QixLQUFLO1FBQ1A7VUFDRSxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7Y0FDL0UsQ0FBQyxFQUFFLEdBQUcsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDO2NBQ2QsQ0FBQyxFQUFFLEdBQUcsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFDO1VBQ2xCLEtBQUs7T0FDUjs7TUFFRCxPQUFPLENBQUMsS0FBSyxHQUFHLFFBQU87TUFDdkIsT0FBTyxPQUFPO0tBQ2YsQ0FBQztLQUNELE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7TUFDMUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFDO0NBQ3ZDOztBQ3pHRCxNQUFNakMsWUFBVSxHQUFHLG9CQUFvQjtHQUNwQyxLQUFLLENBQUMsR0FBRyxDQUFDO0dBQ1YsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUs7SUFDcEIsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuQyxFQUFFLENBQUM7R0FDSixTQUFTLENBQUMsQ0FBQyxFQUFDOztBQUVmLE1BQU1pQyxnQkFBYyxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxZQUFZLEVBQUM7O0FBRTlLLEFBQU8sU0FBUyxRQUFRLENBQUMsS0FBSyxFQUFFO0VBQzlCLElBQUksQ0FBQyxZQUFZLEtBQUssS0FBSyxDQUFDLFNBQVMsR0FBRTtFQUN2QyxJQUFJLENBQUMsUUFBUSxTQUFTLEdBQUU7O0VBRXhCLE9BQU8sQ0FBQ2pDLFlBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDbEMsSUFBSSxDQUFDLENBQUMsWUFBWSxFQUFFLE1BQU07O0lBRTFCLENBQUMsQ0FBQyxjQUFjLEdBQUU7O0lBRWxCLElBQUksYUFBYSxHQUFHLElBQUksQ0FBQyxRQUFRO1FBQzdCLElBQUksR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUM7O0lBRWpDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7UUFDM0MsU0FBUyxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQztRQUMxQyxTQUFTLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFDO0dBQy9DLEVBQUM7O0VBRUYsT0FBTyxDQUFDaUMsZ0JBQWMsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDdEMsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixJQUFJLElBQUksR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUM7SUFDakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztRQUMzQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQztRQUMxQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBQztHQUMvQyxFQUFDOztFQUVGLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQzNCLENBQUMsQ0FBQyxjQUFjLEdBQUU7O0lBRWxCLElBQUksSUFBSSxDQUFDLFlBQVksSUFBSSxZQUFZO01BQ25DLElBQUksQ0FBQyxZQUFZLEdBQUcsYUFBWTtTQUM3QixJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksWUFBWTtNQUN4QyxJQUFJLENBQUMsWUFBWSxHQUFHLFNBQVE7O0lBRTlCLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBQztHQUNuQyxFQUFDOztFQUVGLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQzNCLENBQUMsQ0FBQyxjQUFjLEdBQUU7O0lBRWxCLElBQUksSUFBSSxDQUFDLFlBQVksSUFBSSxZQUFZO01BQ25DLElBQUksQ0FBQyxZQUFZLEdBQUcsYUFBWTtTQUM3QixJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksUUFBUTtNQUNwQyxJQUFJLENBQUMsWUFBWSxHQUFHLGFBQVk7O0lBRWxDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBQztHQUNuQyxFQUFDOztFQUVGLE1BQU0sZUFBZSxHQUFHLEdBQUcsSUFBSTtJQUM3QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUc7SUFDbkIsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFDO0lBQ25DOztFQUVELE1BQU0sVUFBVSxHQUFHLE1BQU07SUFDdkIsT0FBTyxDQUFDLE1BQU0sQ0FBQ2pDLFlBQVUsRUFBQztJQUMxQixPQUFPLENBQUMsTUFBTSxDQUFDaUMsZ0JBQWMsRUFBQztJQUM5QixPQUFPLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUFDO0lBQ3JDOztFQUVELE9BQU87SUFDTCxlQUFlO0lBQ2YsVUFBVTtHQUNYO0NBQ0Y7O0FBRUQsQUFBTyxTQUFTLFNBQVMsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUU7RUFDckQsR0FBRztLQUNBLEdBQUcsQ0FBQyxFQUFFLElBQUksZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDL0IsR0FBRyxDQUFDLEVBQUUsSUFBSTtNQUNULE1BQU0sRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxHQUFHLG9CQUFvQixDQUFDLEVBQUUsRUFBQzs7O01BR25FLE9BQU8sS0FBSyxDQUFDLFNBQVMsRUFBRTtRQUN0QixLQUFLLFlBQVk7VUFDZixPQUFPLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEtBQUssRUFBRSxVQUFVLENBQUMsS0FBSyxFQUFFO1FBQzNFLEtBQUssWUFBWTtVQUNmLE9BQU8sRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsS0FBSyxFQUFFLFVBQVUsQ0FBQyxLQUFLLEVBQUU7UUFDM0UsS0FBSyxRQUFRLEVBQUU7VUFDYixJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxrQkFBaUI7VUFDL0QsT0FBTyxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRTtTQUNsRTtPQUNGO0tBQ0YsQ0FBQztLQUNELEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsTUFBTSxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDOUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7T0FDbkUsQ0FBQyxDQUFDO0tBQ0osR0FBRyxDQUFDLE9BQU8sSUFBSTtNQUNkLElBQUksSUFBSSxLQUFLLEdBQUcsSUFBSSxJQUFJLEtBQUssR0FBRyxJQUFJLElBQUksS0FBSyxHQUFHO1FBQzlDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLE1BQU0sR0FBRyxLQUFJOztNQUV4QyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRO1VBQ3BDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU07VUFDdEMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxPQUFPLENBQUMsT0FBTTs7TUFFMUMsSUFBSSxJQUFJLEtBQUssR0FBRyxJQUFJLElBQUksS0FBSyxHQUFHLElBQUksSUFBSSxLQUFLLEdBQUcsRUFBRTtRQUNoRCxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBQztRQUN4RCxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBQztPQUN6RDs7TUFFRCxPQUFPLE9BQU87S0FDZixDQUFDO0tBQ0QsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO01BQ2pDLElBQUksS0FBSyxHQUFHLElBQUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDO01BQ3RELEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLFdBQVcsR0FBRTs7TUFFckMsSUFBSSxLQUFLLElBQUksT0FBTyxFQUFFLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsRUFBQztNQUNqRSxJQUFJLEtBQUssSUFBSSxpQkFBaUIsRUFBRSxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLEVBQUM7S0FDNUUsRUFBQztDQUNMOztBQUVELEFBQU8sU0FBUyxvQkFBb0IsQ0FBQyxFQUFFLEVBQUU7RUFDdkMsSUFBSSxFQUFFLFlBQVksVUFBVSxFQUFFO0lBQzVCLE9BQU8sT0FBTyxHQUFHLFFBQVEsQ0FBQyxFQUFFLEVBQUUsUUFBUSxFQUFDOztJQUV2QyxPQUFPO01BQ0wsVUFBVSxFQUFFO1FBQ1YsS0FBSyxFQUFFLFFBQVE7UUFDZixLQUFLLEVBQUUsSUFBSSxTQUFTLENBQUMsT0FBTyxLQUFLLE1BQU07WUFDbkMsY0FBYztZQUNkLE9BQU8sQ0FBQztPQUNiO01BQ0QsVUFBVSxFQUFFO1FBQ1YsS0FBSyxFQUFFLE1BQU07UUFDYixLQUFLLEVBQUUsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQztPQUMzQztNQUNELE1BQU0sRUFBRTtRQUNOLEtBQUssRUFBRSxTQUFTO1FBQ2hCLEtBQUssRUFBRSxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLFNBQVMsQ0FBQyxDQUFDO09BQzlDO0tBQ0Y7R0FDRjs7SUFFQyxPQUFPO01BQ0wsVUFBVSxFQUFFO1FBQ1YsS0FBSyxFQUFFLE9BQU87UUFDZCxLQUFLLEVBQUUsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztPQUM1QztNQUNELFVBQVUsRUFBRTtRQUNWLEtBQUssRUFBRSxpQkFBaUI7UUFDeEIsS0FBSyxFQUFFLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztPQUN0RDtNQUNELE1BQU0sRUFBRTtRQUNOLEtBQUssRUFBRSxhQUFhO1FBQ3BCLEtBQUssRUFBRSxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO09BQ2xEO0tBQ0Y7Q0FDSjs7QUMvSkQsSUFBSSxVQUFTOztBQUViLEFBQU8sU0FBUyxNQUFNLEdBQUc7RUFDdkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsUUFBUSxFQUFDO0VBQ25DLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBQztFQUNyQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLGFBQWEsRUFBQzs7RUFFaEQsT0FBTyxNQUFNO0lBQ1gsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsUUFBUSxFQUFDO0lBQ3BDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBQztJQUN0QyxNQUFNLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLGFBQWEsRUFBQztJQUNuRCxhQUFhLEdBQUU7R0FDaEI7Q0FDRjs7QUFFRCxNQUFNLFFBQVEsR0FBRyxDQUFDLElBQUk7RUFDcEIsTUFBTSxNQUFNLEdBQUcsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsT0FBTyxFQUFDO0VBQ3pELElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxFQUFFLE1BQU07RUFDL0IsYUFBYSxDQUFDLE1BQU0sRUFBQztFQUN0QjtBQUNELEFBMkJBO0FBQ0EsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQztFQUMzQixhQUFhLEdBQUU7O0FBRWpCLE1BQU0sYUFBYSxHQUFHLElBQUksSUFBSTtFQUM1QixJQUFJLFNBQVMsRUFBRTtJQUNiLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLEtBQUk7SUFDOUIsU0FBUyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMscUJBQXFCLEdBQUU7R0FDaEQ7T0FDSTtJQUNILFNBQVMsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLGtCQUFrQixFQUFDO0lBQ3RELFNBQVMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixHQUFFOztJQUVqRCxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUM7R0FDckM7RUFDRjs7QUFFRCxNQUFNLGFBQWEsR0FBRyxJQUFJLElBQUk7RUFDNUIsSUFBSSxDQUFDLFNBQVMsRUFBRSxNQUFNO0VBQ3RCLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU07Q0FDakM7O0FDdEVNLFNBQVMsVUFBVSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUU7RUFDckMsS0FBSyxDQUFDLGNBQWMsRUFBQzs7RUFFckIsT0FBTyxNQUFNLEVBQUU7OztDQUNoQixEQ0FELE1BQU1qQyxZQUFVLEdBQUcsb0JBQW9CO0dBQ3BDLEtBQUssQ0FBQyxHQUFHLENBQUM7R0FDVixNQUFNLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSztJQUNwQixDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNuRSxFQUFFLENBQUM7R0FDSixTQUFTLENBQUMsQ0FBQyxFQUFDO0FBQ2YsQUFFQTtBQUNBLEFBQU8sU0FBUyxRQUFRLEdBQUc7RUFDekIsTUFBTSxLQUFLLEdBQUc7SUFDWixRQUFRLEVBQUUsRUFBRTtJQUNiOztFQUVELE9BQU8sQ0FBQ0EsWUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUNsQyxJQUFJLENBQUMsQ0FBQyxZQUFZLEVBQUUsTUFBTTs7SUFFMUIsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixlQUFlLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFDO0dBQzdDLEVBQUM7O0VBRUYsTUFBTSxlQUFlLEdBQUcsR0FBRyxJQUFJO0lBQzdCLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUU7TUFDdkIsRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFDOztJQUVoQixLQUFLLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtNQUN6QixTQUFTLENBQUMsRUFBRSxDQUFDLEVBQUM7SUFDakI7O0VBRUQsTUFBTSxVQUFVLEdBQUcsTUFBTTtJQUN2QixLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFDO0lBQzNDLE9BQU8sQ0FBQyxNQUFNLENBQUNBLFlBQVUsRUFBQztJQUMxQixPQUFPLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUFDO0lBQ3JDOztFQUVELE9BQU87SUFDTCxlQUFlO0lBQ2YsVUFBVTtHQUNYO0NBQ0Y7O0FBRUQsQUFBTyxTQUFTLFNBQVMsQ0FBQyxFQUFFLEVBQUU7RUFDNUIsSUFBSSxDQUFDLEtBQUssR0FBRztJQUNYLEtBQUssRUFBRTtNQUNMLElBQUksRUFBRSxLQUFLO01BQ1gsQ0FBQyxFQUFFLENBQUM7TUFDSixDQUFDLEVBQUUsQ0FBQztLQUNMO0lBQ0QsT0FBTyxFQUFFO01BQ1AsQ0FBQyxFQUFFLENBQUM7TUFDSixDQUFDLEVBQUUsQ0FBQztLQUNMO0lBQ0Y7O0VBRUQsTUFBTSxLQUFLLEdBQUcsTUFBTTtJQUNsQixFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsS0FBSyxPQUFNO0lBQzlCLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxTQUFTLE9BQU07O0lBRTlCLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBQztJQUNuRCxFQUFFLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUM7SUFDL0MsUUFBUSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFDO0lBQzFEOztFQUVELE1BQU0sUUFBUSxHQUFHLE1BQU07SUFDckIsRUFBRSxDQUFDLEtBQUssQ0FBQyxVQUFVLEtBQUssS0FBSTtJQUM1QixFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sU0FBUyxLQUFJOztJQUU1QixFQUFFLENBQUMsbUJBQW1CLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUM7SUFDdEQsRUFBRSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFDO0lBQ2xELFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBQztJQUM3RDs7RUFFRCxNQUFNLFdBQVcsR0FBRyxDQUFDLElBQUk7SUFDdkIsQ0FBQyxDQUFDLGNBQWMsR0FBRTs7SUFFbEIsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDLE9BQU07O0lBRW5CLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLFdBQVU7SUFDOUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsV0FBVTs7SUFFaEMsSUFBSSxFQUFFLFlBQVksVUFBVSxFQUFFO01BQzVCLE1BQU0sU0FBUyxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFDOztNQUU5QyxNQUFNLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLFNBQVM7VUFDdEIsbUJBQW1CLENBQUMsU0FBUyxDQUFDO1VBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQzs7TUFFVCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBQztNQUN6QixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBQztLQUMxQjtTQUNJO01BQ0gsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFDO01BQ3RELElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBQztLQUN0RDs7SUFFRCxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQU87SUFDbkMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFPO0lBQ25DLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxLQUFJO0lBQy9COztFQUVELE1BQU0sU0FBUyxHQUFHLENBQUMsSUFBSTtJQUNyQixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLENBQUMsQ0FBQyxlQUFlLEdBQUU7O0lBRW5CLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxNQUFLO0lBQzdCLEVBQUUsQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLEtBQUk7O0lBRTFCLElBQUksRUFBRSxZQUFZLFVBQVUsRUFBRTtNQUM1QixNQUFNLFNBQVMsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBQzs7TUFFOUMsTUFBTSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxTQUFTO1VBQ3RCLG1CQUFtQixDQUFDLFNBQVMsQ0FBQztVQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUM7O01BRVQsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUM7TUFDM0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUM7S0FDNUI7U0FDSTtNQUNILElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDO01BQ3RELElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFDO0tBQ3REO0lBQ0Y7O0VBRUQsTUFBTSxXQUFXLEdBQUcsQ0FBQyxJQUFJO0lBQ3ZCLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsQ0FBQyxDQUFDLGVBQWUsR0FBRTs7SUFFbkIsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxNQUFNOztJQUVsQyxJQUFJLEVBQUUsWUFBWSxVQUFVLEVBQUU7TUFDNUIsRUFBRSxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUM1QixFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUN4RCxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztPQUN6RCxDQUFDLEVBQUM7S0FDSjtTQUNJO01BQ0gsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLEtBQUk7TUFDNUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLEtBQUk7S0FDN0U7SUFDRjs7RUFFRCxLQUFLLEdBQUU7RUFDUCxFQUFFLENBQUMsUUFBUSxHQUFHLFNBQVE7O0VBRXRCLE9BQU8sRUFBRTtDQUNWOztBQUVELEFBQU8sU0FBUyxlQUFlLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRTtFQUM5QyxHQUFHO0tBQ0EsR0FBRyxDQUFDLEVBQUUsSUFBSSxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUNqQyxHQUFHLENBQUMsRUFBRSxJQUFJLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0tBQy9CLEdBQUcsQ0FBQyxFQUFFLEtBQUs7UUFDUixFQUFFO1FBQ0YsR0FBRywwQkFBMEIsQ0FBQyxFQUFFLEVBQUUsU0FBUyxDQUFDO1FBQzVDLE1BQU0sSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztRQUN6RCxRQUFRLEVBQUUsbUJBQW1CLENBQUMsRUFBRSxFQUFFLFNBQVMsQ0FBQztLQUMvQyxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLFFBQVEsRUFBRSxPQUFPLENBQUMsUUFBUTtZQUN0QixPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxNQUFNO1lBQ2hDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU07T0FDckMsQ0FBQyxDQUFDO0tBQ0osT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLFFBQVEsQ0FBQztNQUM3QixFQUFFLFlBQVksVUFBVTtVQUNwQixpQkFBaUIsQ0FBQyxFQUFFLEVBQUUsU0FBUyxFQUFFLFFBQVEsQ0FBQztVQUMxQyxFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLFFBQVEsR0FBRyxJQUFJLEVBQUM7Q0FDM0M7O0FBRUQsTUFBTSwwQkFBMEIsR0FBRyxDQUFDLEVBQUUsRUFBRSxTQUFTLEtBQUs7RUFDcEQsSUFBSSxLQUFLLEVBQUUsUUFBTzs7RUFFbEIsSUFBSSxFQUFFLFlBQVksVUFBVSxFQUFFO0lBQzVCLE1BQU0sU0FBUyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFDOztJQUV0QyxNQUFNLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLFNBQVM7UUFDdEIsbUJBQW1CLENBQUMsU0FBUyxDQUFDO1FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQzs7SUFFVCxLQUFLLEtBQUssWUFBVztJQUNyQixPQUFPLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztRQUM1RCxDQUFDO1FBQ0QsRUFBQztHQUNOO09BQ0k7SUFDSCxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxHQUFFO0lBQzdDLEtBQUssR0FBRyxDQUFDLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLFFBQVEsSUFBSSxLQUFLLEdBQUcsT0FBTTtJQUM5RCxPQUFPLEdBQUcsUUFBUSxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUM7O0lBRTdCLE9BQU8sS0FBSyxNQUFNO1FBQ2QsT0FBTyxHQUFHLENBQUM7UUFDWCxPQUFPLEdBQUcsUUFBUSxDQUFDLE9BQU8sRUFBRSxFQUFFLEVBQUM7R0FDcEM7O0VBRUQsT0FBTyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUU7RUFDMUI7O0FBRUQsTUFBTSxtQkFBbUIsR0FBRyxTQUFTO0VBQ25DLFNBQVMsQ0FBQyxTQUFTO0lBQ2pCLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUMxQixTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztHQUN2QixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7R0FDWCxHQUFHLENBQUMsR0FBRyxJQUFJLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBQzs7QUFFOUIsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLEVBQUUsRUFBRSxTQUFTLEVBQUUsUUFBUSxLQUFLO0VBQ3JELE1BQU0sU0FBUyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFDO0VBQ3RDLE1BQU0sRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsU0FBUztNQUN0QixtQkFBbUIsQ0FBQyxTQUFTLENBQUM7TUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDOztFQUVULE1BQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7TUFDOUQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUM7TUFDbEIsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUM7O0VBRXRCLEVBQUUsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBQztFQUMxQzs7QUFFRCxNQUFNLG1CQUFtQixHQUFHLENBQUMsRUFBRSxFQUFFLFNBQVM7RUFDeEMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBQzs7QUFFM0QsTUFBTSxrQkFBa0IsR0FBRyxFQUFFLElBQUk7RUFDL0IsSUFBSSxFQUFFLFlBQVksV0FBVztJQUMzQixFQUFFLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxXQUFVO0VBQ2hDLE9BQU8sRUFBRTtDQUNWOztBQ2pPTSxNQUFNLFdBQVcsR0FBRztFQUN6QixDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsUUFBUTtJQUNyQixJQUFJLFNBQVNxQyxNQUFZO0lBQ3pCLEtBQUssUUFBUSxRQUFRO0lBQ3JCLFdBQVcsRUFBRSxvQ0FBb0M7SUFDakQsV0FBVyxFQUFFLENBQUM7Ozs0QkFHVSxFQUFFLE1BQU0sQ0FBQzs7d0JBRWIsQ0FBQztHQUN0QjtFQUNELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxXQUFXO0lBQ3hCLElBQUksU0FBU0MsU0FBZTtJQUM1QixLQUFLLFFBQVEsU0FBUztJQUN0QixXQUFXLEVBQUUsaURBQWlEO0lBQzlELFdBQVcsRUFBRSxDQUFDOzs7NEJBR1UsRUFBRSxNQUFNLENBQUM7O3dCQUViLENBQUM7R0FDdEI7RUFDRCxDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsZUFBZTtJQUM1QixJQUFJLFNBQVNDLGFBQW1CO0lBQ2hDLEtBQUssUUFBUSxlQUFlO0lBQzVCLFdBQVcsRUFBRSwrQ0FBK0M7SUFDNUQsV0FBVyxFQUFFLENBQUM7Ozs0QkFHVSxFQUFFLE1BQU0sQ0FBQzs7d0JBRWIsQ0FBQztHQUN0QjtFQUNELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxNQUFNO0lBQ25CLElBQUksU0FBU0MsSUFBVTtJQUN2QixLQUFLLFFBQVEsTUFBTTtJQUNuQixXQUFXLEVBQUUsc0VBQXNFO0lBQ25GLFdBQVcsRUFBRSxDQUFDOzs7Ozs7Ozs7Ozs7O3dCQWFNLENBQUM7R0FDdEI7Ozs7Ozs7RUFPRCxDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsUUFBUTtJQUNyQixJQUFJLFNBQVNDLE1BQVk7SUFDekIsS0FBSyxRQUFRLFFBQVE7SUFDckIsV0FBVyxFQUFFLDhFQUE4RTtJQUMzRixXQUFXLEVBQUUsQ0FBQzs7Ozs7Ozs0QkFPVSxFQUFFLE1BQU0sQ0FBQzs7Ozs0QkFJVCxFQUFFLE9BQU8sQ0FBQzs7d0JBRWQsQ0FBQztHQUN0QjtFQUNELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxTQUFTO0lBQ3RCLElBQUksU0FBU0MsT0FBYTtJQUMxQixLQUFLLFFBQVEsU0FBUztJQUN0QixXQUFXLEVBQUUsQ0FBQyw0RUFBNEUsQ0FBQztJQUMzRixXQUFXLEVBQUUsQ0FBQzs7Ozs7Ozs0QkFPVSxFQUFFLE1BQU0sQ0FBQzs7Ozs0QkFJVCxFQUFFLE9BQU8sQ0FBQzs7d0JBRWQsQ0FBQztHQUN0Qjs7Ozs7OztFQU9ELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxPQUFPO0lBQ3BCLElBQUksU0FBU0MsS0FBVztJQUN4QixLQUFLLFFBQVEsZUFBZTtJQUM1QixXQUFXLEVBQUUsQ0FBQyw0REFBNEQsQ0FBQztJQUMzRSxXQUFXLEVBQUUsQ0FBQzs7Ozs7Ozs7Ozs7NEJBV1UsRUFBRSxPQUFPLENBQUM7O3dCQUVkLENBQUM7R0FDdEI7RUFDRCxDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsVUFBVTtJQUN2QixJQUFJLFNBQVNDLFFBQWM7SUFDM0IsS0FBSyxRQUFRLFdBQVc7SUFDeEIsV0FBVyxFQUFFLENBQUMsa0VBQWtFLENBQUM7SUFDakYsV0FBVyxFQUFFLENBQUM7Ozs7Ozs7Ozs7OzRCQVdVLEVBQUUsT0FBTyxDQUFDOzs7OzRCQUlWLEVBQUUsT0FBTyxDQUFDOzt3QkFFZCxDQUFDO0dBQ3RCO0VBQ0QsQ0FBQyxFQUFFO0lBQ0QsSUFBSSxTQUFTLFdBQVc7SUFDeEIsSUFBSSxTQUFTQyxTQUFlO0lBQzVCLEtBQUssUUFBUSxRQUFRO0lBQ3JCLFdBQVcsRUFBRSxDQUFDLHdEQUF3RCxDQUFDO0lBQ3ZFLFdBQVcsRUFBRSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7NEJBZVUsRUFBRSxPQUFPLENBQUM7O3dCQUVkLENBQUM7R0FDdEI7Ozs7Ozs7RUFPRCxDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsVUFBVTtJQUN2QixJQUFJLFNBQVNDLFFBQWM7SUFDM0IsS0FBSyxRQUFRLFVBQVU7SUFDdkIsV0FBVyxFQUFFLHFEQUFxRDtJQUNsRSxXQUFXLEVBQUUsQ0FBQzs7Ozs7Ozs7O3dCQVNNLENBQUM7R0FDdEI7RUFDRCxDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsTUFBTTtJQUNuQixJQUFJLFNBQVNDLElBQVU7SUFDdkIsS0FBSyxRQUFRLGFBQWE7SUFDMUIsV0FBVyxFQUFFLDJEQUEyRDtJQUN4RSxXQUFXLEVBQUUsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0QkFtQlUsRUFBRSxPQUFPLENBQUM7O3dCQUVkLENBQUM7R0FDdEI7RUFDRCxDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsTUFBTTtJQUNuQixJQUFJLFNBQVNDLElBQVU7SUFDdkIsS0FBSyxRQUFRLFdBQVc7SUFDeEIsV0FBVyxFQUFFLHdEQUF3RDtJQUNyRSxXQUFXLEVBQUUsRUFBRTtHQUNoQjs7Ozs7OztFQU9ELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxRQUFRO0lBQ3JCLElBQUksU0FBU0MsTUFBWTtJQUN6QixLQUFLLFFBQVEsUUFBUTtJQUNyQixXQUFXLEVBQUUscUdBQXFHO0lBQ2xILFdBQVcsRUFBRSxFQUFFO0dBQ2hCO0NBQ0Y7O0FDdE9jLE1BQU0sTUFBTSxTQUFTLFdBQVcsQ0FBQztFQUM5QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLGFBQWEsSUFBSSxZQUFXO0lBQ2pDLElBQUksQ0FBQyxZQUFZLEtBQUssT0FBTTtJQUM1QixJQUFJLENBQUMsT0FBTyxVQUFVLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLEVBQUM7R0FDMUQ7O0VBRUQsaUJBQWlCLEdBQUc7SUFDbEIsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUztNQUN6QixJQUFJLENBQUMsS0FBSyxHQUFFOztJQUVkLElBQUksQ0FBQyxjQUFjLEdBQUcsVUFBVSxHQUFFO0lBQ2xDLElBQUksQ0FBQyxXQUFXLE1BQU0sV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBQztJQUNwRSxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFDO0dBQzNDOztFQUVELG9CQUFvQixHQUFHO0lBQ3JCLElBQUksQ0FBQyxrQkFBa0IsR0FBRTtJQUN6QixJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsR0FBRTtJQUNoQyxPQUFPLENBQUMsTUFBTTtNQUNaLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxHQUFHO1FBQ2pELE1BQU0sSUFBSSxHQUFHLEdBQUcsR0FBRyxFQUFFLEVBQUUsQ0FBQyxFQUFDO0lBQzdCLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBQztHQUMvQjs7RUFFRCxLQUFLLEdBQUc7SUFDTixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFFOztJQUV0QyxDQUFDLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7TUFDNUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLGVBQWUsRUFBRSxFQUFDOztJQUU1RCxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUM7TUFDdEQsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUk7UUFDaEIsQ0FBQyxDQUFDLGNBQWMsR0FBRTtRQUNsQixJQUFJLENBQUMsWUFBWTtVQUNmLENBQUMsQ0FBQyxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7VUFDbEQ7T0FDRixDQUFDO01BQ0g7O0lBRUQsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDO01BQ3BDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPO1FBQzdCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEtBQUssTUFBTTtZQUN0QyxPQUFPO1lBQ1AsTUFBTSxFQUFDOztJQUVmLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQztHQUM5RDs7RUFFRCxZQUFZLENBQUMsRUFBRSxFQUFFO0lBQ2YsSUFBSSxPQUFPLEVBQUUsS0FBSyxRQUFRO01BQ3hCLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUM7O0lBRWhELElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssRUFBRSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsTUFBTTs7SUFFakYsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO01BQ3BCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUM7TUFDMUMsSUFBSSxDQUFDLGtCQUFrQixHQUFFO0tBQzFCOztJQUVELEVBQUUsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksRUFBQztJQUM1QixJQUFJLENBQUMsV0FBVyxHQUFHLEdBQUU7SUFDckIsSUFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUU7R0FDeEI7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7OztRQUdkLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7VUFDbEUsRUFBRSxJQUFJLENBQUM7MEJBQ1MsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLHlCQUF5QixFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxFQUFFLEdBQUcsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsR0FBRyxJQUFJLEdBQUcsQ0FBQztZQUNqSixFQUFFLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDWixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDOztRQUVuQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7Ozs7O1VBS0osRUFBRUMsVUFBZ0IsQ0FBQzs7OztVQUluQixFQUFFQyxnQkFBc0IsQ0FBQzs7OztVQUl6QixFQUFFQyxZQUFrQixDQUFDOzs7SUFHM0IsQ0FBQztHQUNGOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQzs7UUFFSixFQUFFdkQsR0FBTSxDQUFDOztJQUViLENBQUM7R0FDRjs7RUFFRCxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsV0FBVyxDQUFDLEVBQUU7SUFDcEQsT0FBTyxDQUFDO2FBQ0MsRUFBRSxJQUFJLENBQUM7O29CQUVBLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUM7OztjQUczRCxFQUFFLEtBQUssQ0FBQzsyQkFDSyxFQUFFLEdBQUcsQ0FBQzs7ZUFFbEIsRUFBRSxXQUFXLENBQUM7WUFDakIsRUFBRSxXQUFXLENBQUM7Ozs7SUFJdEIsQ0FBQztHQUNGOztFQUVELElBQUksR0FBRztJQUNMLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBQztHQUN4RDs7RUFFRCxNQUFNLEdBQUc7SUFDUCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUM7R0FDdEQ7O0VBRUQsT0FBTyxHQUFHO0lBQ1IsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFDO0dBQ3ZEOztFQUVELElBQUksR0FBRztJQUNMLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBQztHQUNwRDs7RUFFRCxJQUFJLEdBQUc7SUFDTCxJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBQztJQUM5QyxJQUFJLENBQUMsa0JBQWtCLEdBQUc7TUFDeEIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxzQkFBc0IsQ0FBQyxRQUFRLEVBQUM7R0FDdkQ7O0VBRUQsS0FBSyxHQUFHO0lBQ04sSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFDO0dBQ3BEOztFQUVELE1BQU0sR0FBRztJQUNQLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBQztHQUMxRTs7RUFFRCxTQUFTLEdBQUc7SUFDVixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUM7R0FDekQ7O0VBRUQsUUFBUSxHQUFHO0lBQ1QsSUFBSSxPQUFPLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUM7SUFDeEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFDO0lBQzdELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNO01BQzlCLElBQUksQ0FBQyxjQUFjLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBQztNQUNuRSxPQUFPLENBQUMsVUFBVSxHQUFFO01BQ3JCO0dBQ0Y7O0VBRUQsU0FBUyxHQUFHO0lBQ1YsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFDO0dBQ3ZEOztFQUVELGFBQWEsR0FBRztJQUNkLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxhQUFhLEdBQUU7R0FDMUM7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU0sR0FBRTtHQUNuQzs7RUFFRCxVQUFVLEdBQUc7SUFDWCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsVUFBVSxHQUFFO0dBQ3ZDOztFQUVELFFBQVEsR0FBRztJQUNULElBQUksT0FBTyxHQUFHLFFBQVEsR0FBRTtJQUN4QixJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUM7SUFDN0QsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU07TUFDOUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFDO01BQ25FLE9BQU8sQ0FBQyxVQUFVLEdBQUU7TUFDckI7R0FDRjs7RUFFRCxJQUFJLFVBQVUsR0FBRztJQUNmLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSTtHQUNyQzs7RUFFRCxJQUFJLFdBQVcsQ0FBQyxHQUFHLEVBQUU7SUFDbkIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFHO0lBQ3ZCLElBQUksQ0FBQyxLQUFLLEdBQUU7R0FDYjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQzs7QUMxTnhDLElBQUksY0FBYyxJQUFJLFFBQVEsQ0FBQyxlQUFlO0VBQzVDLFFBQVEsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxHQUFFOztBQUUzRCxJQUFJLE9BQU8sS0FBSyxNQUFNO0VBQ3BCLENBQUMsR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDbEMsT0FBTyxDQUFDLElBQUksSUFBSTtNQUNmLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBQztNQUN6RCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUM7S0FDekQsQ0FBQyJ9
