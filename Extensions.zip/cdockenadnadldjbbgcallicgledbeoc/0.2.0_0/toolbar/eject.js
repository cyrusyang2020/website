[
  ...document.getElementsByTagName('vis-bug'),
  ...document.getElementsByTagName('visbug-hover'),
  ...document.getElementsByTagName('visbug-label'),
].forEach(el => el.remove())
