const sugar = {
  on: function(names, fn) {
    names
      .split(' ')
      .forEach(name =>
        this.addEventListener(name, fn));
    return this
  },
  off: function(names, fn) {
    names
      .split(' ')
      .forEach(name =>
        this.removeEventListener(name, fn));
    return this
  },
  attr: function(attr, val) {
    if (val === undefined) return this.getAttribute(attr)

    val == null
      ? this.removeAttribute(attr)
      : this.setAttribute(attr, val || '');
      
    return this
  }
};

function $(query, $context = document) {
  let $nodes = query instanceof NodeList || Array.isArray(query)
    ? query
    : query instanceof HTMLElement || query instanceof SVGElement
      ? [query]
      : $context.querySelectorAll(query);

  if (!$nodes.length) $nodes = [];

  return Object.assign(
    [...$nodes].map($el => Object.assign($el, sugar)), 
    {
      on: function(names, fn) {
        this.forEach($el => $el.on(names, fn));
        return this
      },
      off: function(names, fn) {
        this.forEach($el => $el.off(names, fn));
        return this
      },
      attr: function(attrs, val) {
        if (typeof attrs === 'string' && val === undefined)
          return this[0].attr(attrs)

        else if (typeof attrs === 'object') 
          this.forEach($el =>
            Object.entries(attrs)
              .forEach(([key, val]) =>
                $el.attr(key, val)));

        else if (typeof attrs == 'string' && (val || val == null || val == ''))
          this.forEach($el => $el.attr(attrs, val));

        return this
      }
    }
  )
}

/*!
 * hotkeys-js v3.3.5
 * A simple micro-library for defining and dispatching keyboard shortcuts. It has no dependencies.
 * 
 * Copyright (c) 2018 kenny wong <wowohoo@qq.com>
 * http://jaywcjlove.github.io/hotkeys
 * 
 * Licensed under the MIT license.
 */

var isff = typeof navigator !== 'undefined' ? navigator.userAgent.toLowerCase().indexOf('firefox') > 0 : false;

// 绑定事件
function addEvent(object, event, method) {
  if (object.addEventListener) {
    object.addEventListener(event, method, false);
  } else if (object.attachEvent) {
    object.attachEvent('on' + event, function () {
      method(window.event);
    });
  }
}

// 修饰键转换成对应的键码
function getMods(modifier, key) {
  var mods = key.slice(0, key.length - 1);
  for (var i = 0; i < mods.length; i++) {
    mods[i] = modifier[mods[i].toLowerCase()];
  }return mods;
}

// 处理传的key字符串转换成数组
function getKeys(key) {
  if (!key) key = '';

  key = key.replace(/\s/g, ''); // 匹配任何空白字符,包括空格、制表符、换页符等等
  var keys = key.split(','); // 同时设置多个快捷键，以','分割
  var index = keys.lastIndexOf('');

  // 快捷键可能包含','，需特殊处理
  for (; index >= 0;) {
    keys[index - 1] += ',';
    keys.splice(index, 1);
    index = keys.lastIndexOf('');
  }

  return keys;
}

// 比较修饰键的数组
function compareArray(a1, a2) {
  var arr1 = a1.length >= a2.length ? a1 : a2;
  var arr2 = a1.length >= a2.length ? a2 : a1;
  var isIndex = true;

  for (var i = 0; i < arr1.length; i++) {
    if (arr2.indexOf(arr1[i]) === -1) isIndex = false;
  }
  return isIndex;
}

var _keyMap = { // 特殊键
  backspace: 8,
  tab: 9,
  clear: 12,
  enter: 13,
  return: 13,
  esc: 27,
  escape: 27,
  space: 32,
  left: 37,
  up: 38,
  right: 39,
  down: 40,
  del: 46,
  delete: 46,
  ins: 45,
  insert: 45,
  home: 36,
  end: 35,
  pageup: 33,
  pagedown: 34,
  capslock: 20,
  '⇪': 20,
  ',': 188,
  '.': 190,
  '/': 191,
  '`': 192,
  '-': isff ? 173 : 189,
  '=': isff ? 61 : 187,
  ';': isff ? 59 : 186,
  '\'': 222,
  '[': 219,
  ']': 221,
  '\\': 220
};

var _modifier = { // 修饰键
  '⇧': 16,
  shift: 16,
  '⌥': 18,
  alt: 18,
  option: 18,
  '⌃': 17,
  ctrl: 17,
  control: 17,
  '⌘': isff ? 224 : 91,
  cmd: isff ? 224 : 91,
  command: isff ? 224 : 91
};
var _downKeys = []; // 记录摁下的绑定键
var modifierMap = {
  16: 'shiftKey',
  18: 'altKey',
  17: 'ctrlKey'
};
var _mods = { 16: false, 18: false, 17: false };
var _handlers = {};

// F1~F12 特殊键
for (var k = 1; k < 20; k++) {
  _keyMap['f' + k] = 111 + k;
}

// 兼容Firefox处理
modifierMap[isff ? 224 : 91] = 'metaKey';
_mods[isff ? 224 : 91] = false;

var _scope = 'all'; // 默认热键范围
var isBindElement = false; // 是否绑定节点

// 返回键码
var code = function code(x) {
  return _keyMap[x.toLowerCase()] || x.toUpperCase().charCodeAt(0);
};

// 设置获取当前范围（默认为'所有'）
function setScope(scope) {
  _scope = scope || 'all';
}
// 获取当前范围
function getScope() {
  return _scope || 'all';
}
// 获取摁下绑定键的键值
function getPressedKeyCodes() {
  return _downKeys.slice(0);
}

// 表单控件控件判断 返回 Boolean
function filter(event) {
  var tagName = event.target.tagName || event.srcElement.tagName;
  // 忽略这些标签情况下快捷键无效
  return !(tagName === 'INPUT' || tagName === 'SELECT' || tagName === 'TEXTAREA');
}

// 判断摁下的键是否为某个键，返回true或者false
function isPressed(keyCode) {
  if (typeof keyCode === 'string') {
    keyCode = code(keyCode); // 转换成键码
  }
  return _downKeys.indexOf(keyCode) !== -1;
}

// 循环删除handlers中的所有 scope(范围)
function deleteScope(scope, newScope) {
  var handlers = void 0;
  var i = void 0;

  // 没有指定scope，获取scope
  if (!scope) scope = getScope();

  for (var key in _handlers) {
    if (Object.prototype.hasOwnProperty.call(_handlers, key)) {
      handlers = _handlers[key];
      for (i = 0; i < handlers.length;) {
        if (handlers[i].scope === scope) handlers.splice(i, 1);else i++;
      }
    }
  }

  // 如果scope被删除，将scope重置为all
  if (getScope() === scope) setScope(newScope || 'all');
}

// 清除修饰键
function clearModifier(event) {
  var key = event.keyCode || event.which || event.charCode;
  var i = _downKeys.indexOf(key);

  // 从列表中清除按压过的键
  if (i >= 0) _downKeys.splice(i, 1);

  // 修饰键 shiftKey altKey ctrlKey (command||metaKey) 清除
  if (key === 93 || key === 224) key = 91;
  if (key in _mods) {
    _mods[key] = false;

    // 将修饰键重置为false
    for (var k in _modifier) {
      if (_modifier[k] === key) hotkeys[k] = false;
    }
  }
}

// 解除绑定某个范围的快捷键
function unbind(key, scope) {
  var multipleKeys = getKeys(key);
  var keys = void 0;
  var mods = [];
  var obj = void 0;

  for (var i = 0; i < multipleKeys.length; i++) {
    // 将组合快捷键拆分为数组
    keys = multipleKeys[i].split('+');

    // 记录每个组合键中的修饰键的键码 返回数组
    if (keys.length > 1) mods = getMods(_modifier, keys);

    // 获取除修饰键外的键值key
    key = keys[keys.length - 1];
    key = key === '*' ? '*' : code(key);

    // 判断是否传入范围，没有就获取范围
    if (!scope) scope = getScope();

    // 如何key不在 _handlers 中返回不做处理
    if (!_handlers[key]) return;

    // 清空 handlers 中数据，
    // 让触发快捷键键之后没有事件执行到达解除快捷键绑定的目的
    for (var r = 0; r < _handlers[key].length; r++) {
      obj = _handlers[key][r];
      // 判断是否在范围内并且键值相同
      if (obj.scope === scope && compareArray(obj.mods, mods)) {
        _handlers[key][r] = {};
      }
    }
  }
}

// 对监听对应快捷键的回调函数进行处理
function eventHandler(event, handler, scope) {
  var modifiersMatch = void 0;

  // 看它是否在当前范围
  if (handler.scope === scope || handler.scope === 'all') {
    // 检查是否匹配修饰符（如果有返回true）
    modifiersMatch = handler.mods.length > 0;

    for (var y in _mods) {
      if (Object.prototype.hasOwnProperty.call(_mods, y)) {
        if (!_mods[y] && handler.mods.indexOf(+y) > -1 || _mods[y] && handler.mods.indexOf(+y) === -1) modifiersMatch = false;
      }
    }

    // 调用处理程序，如果是修饰键不做处理
    if (handler.mods.length === 0 && !_mods[16] && !_mods[18] && !_mods[17] && !_mods[91] || modifiersMatch || handler.shortcut === '*') {
      if (handler.method(event, handler) === false) {
        if (event.preventDefault) event.preventDefault();else event.returnValue = false;
        if (event.stopPropagation) event.stopPropagation();
        if (event.cancelBubble) event.cancelBubble = true;
      }
    }
  }
}

// 处理keydown事件
function dispatch(event) {
  var asterisk = _handlers['*'];
  var key = event.keyCode || event.which || event.charCode;

  // 搜集绑定的键
  if (_downKeys.indexOf(key) === -1) _downKeys.push(key);

  // Gecko(Firefox)的command键值224，在Webkit(Chrome)中保持一致
  // Webkit左右command键值不一样
  if (key === 93 || key === 224) key = 91;

  if (key in _mods) {
    _mods[key] = true;

    // 将特殊字符的key注册到 hotkeys 上
    for (var k in _modifier) {
      if (_modifier[k] === key) hotkeys[k] = true;
    }

    if (!asterisk) return;
  }

  // 将modifierMap里面的修饰键绑定到event中
  for (var e in _mods) {
    if (Object.prototype.hasOwnProperty.call(_mods, e)) {
      _mods[e] = event[modifierMap[e]];
    }
  }

  // 表单控件过滤 默认表单控件不触发快捷键
  if (!hotkeys.filter.call(this, event)) return;

  // 获取范围 默认为all
  var scope = getScope();

  // 对任何快捷键都需要做的处理
  if (asterisk) {
    for (var i = 0; i < asterisk.length; i++) {
      if (asterisk[i].scope === scope) eventHandler(event, asterisk[i], scope);
    }
  }
  // key 不在_handlers中返回
  if (!(key in _handlers)) return;

  for (var _i = 0; _i < _handlers[key].length; _i++) {
    // 找到处理内容
    eventHandler(event, _handlers[key][_i], scope);
  }
}

function hotkeys(key, option, method) {
  var keys = getKeys(key); // 需要处理的快捷键列表
  var mods = [];
  var scope = 'all'; // scope默认为all，所有范围都有效
  var element = document; // 快捷键事件绑定节点
  var i = 0;

  // 对为设定范围的判断
  if (method === undefined && typeof option === 'function') {
    method = option;
  }

  if (Object.prototype.toString.call(option) === '[object Object]') {
    if (option.scope) scope = option.scope; // eslint-disable-line
    if (option.element) element = option.element; // eslint-disable-line
  }

  if (typeof option === 'string') scope = option;

  // 对于每个快捷键进行处理
  for (; i < keys.length; i++) {
    key = keys[i].split('+'); // 按键列表
    mods = [];

    // 如果是组合快捷键取得组合快捷键
    if (key.length > 1) mods = getMods(_modifier, key);

    // 将非修饰键转化为键码
    key = key[key.length - 1];
    key = key === '*' ? '*' : code(key); // *表示匹配所有快捷键

    // 判断key是否在_handlers中，不在就赋一个空数组
    if (!(key in _handlers)) _handlers[key] = [];

    _handlers[key].push({
      scope: scope,
      mods: mods,
      shortcut: keys[i],
      method: method,
      key: keys[i]
    });
  }
  // 在全局document上设置快捷键
  if (typeof element !== 'undefined' && !isBindElement) {
    isBindElement = true;
    addEvent(element, 'keydown', function (e) {
      dispatch(e);
    });
    addEvent(element, 'keyup', function (e) {
      clearModifier(e);
    });
  }
}

var _api = {
  setScope: setScope,
  getScope: getScope,
  deleteScope: deleteScope,
  getPressedKeyCodes: getPressedKeyCodes,
  isPressed: isPressed,
  filter: filter,
  unbind: unbind
};
for (var a in _api) {
  if (Object.prototype.hasOwnProperty.call(_api, a)) {
    hotkeys[a] = _api[a];
  }
}

if (typeof window !== 'undefined') {
  var _hotkeys = window.hotkeys;
  hotkeys.noConflict = function (deep) {
    if (deep && window.hotkeys === hotkeys) {
      window.hotkeys = _hotkeys;
    }
    return hotkeys;
  };
  window.hotkeys = hotkeys;
}

var css = ":host {\n  --theme-bg: hsl(0,0%,100%);\n  --theme-color: hotpink;\n  --theme-blue: hsl(188, 90%, 45%);\n  --theme-purple: hsl(267, 100%, 58%);\n  --theme-icon_color: hsl(0,0%,20%);\n  --theme-icon_hover-bg: hsl(0,0%,95%);\n}\n\n:host {\n  position: fixed;\n  top: 0;\n  left: 0;\n  z-index: 2147483646;\n  font-size: 16px;\n  font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;\n}\n\n:host > ol {\n  display: flex;\n  flex-direction: column;\n  margin: 1em 0 0.5em 1em;\n  padding: 0;\n  list-style-type: none;\n  border-radius: 2em\n}\n\n:host > ol:not([colors]) {\n    box-shadow: 0 0.25em 0.5em hsla(0,0%,0%,10%);\n    background: var(--theme-bg);\n  }\n\n:host li {\n  height: 2.25em;\n  width: 2.25em;\n  margin: 0.05em 0.25em;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  position: relative;\n  border-radius: 50%\n}\n\n:host li:first-child { margin-top: 0.25em; }\n\n:host li:last-child { margin-bottom: 0.25em; }\n\n:host li[data-tool]:hover {\n      cursor: pointer;\n      background-color: var(--theme-icon_hover-bg);\n    }\n\n:host li[data-tool]:active {\n      background-color: hsl(0,0%,90%);\n    }\n\n:host li[data-active=true] > svg:not(.icon-cursor) {\n    fill: var(--theme-color);\n  }\n\n:host li[data-active=true] > .icon-cursor {\n    stroke: var(--theme-color);\n  }\n\n@media (max-height: 768px) {\n    :host li:nth-of-type(10) > aside, :host li:nth-of-type(11) > aside, :host li:nth-of-type(12) > aside, :host li:nth-of-type(13) > aside {\n      top: auto;\n    }\n  }\n\n:host li > aside {\n    overflow: hidden;\n    position: absolute;\n    direction: ltr;\n    text-align: left;\n    left: 3em;\n    top: 0;\n    z-index: -2;\n    pointer-events: none;\n    background: white;\n    color: hsl(0,0%,30%);\n    box-shadow: 0 0.1em 4.5em hsla(0,0%,0%,15%);\n    border-radius: 1em;\n\n    transition: opacity 0.3s ease, -webkit-transform 0.2s ease;\n\n    transition: opacity 0.3s ease, transform 0.2s ease;\n\n    transition: opacity 0.3s ease, transform 0.2s ease, -webkit-transform 0.2s ease;\n    opacity: 0;\n    -webkit-transform: translateX(-1em);\n            transform: translateX(-1em);\n    will-change: transform, opacity\n  }\n\n:host li > aside > figure {\n      margin: 0;\n      display: grid;\n    }\n\n:host li > aside figcaption {\n      padding: 1em;\n      display: grid;\n      grid-gap: 0.5em\n    }\n\n:host li > aside figcaption > h2, :host li > aside figcaption > p {\n        margin: 0;\n      }\n\n:host li > aside figcaption > h2 {\n        font-size: 1.5em;\n        line-height: 1.1;\n        margin-bottom: 0.5em;\n        display: grid;\n        grid-auto-flow: column;\n        justify-content: space-between;\n        align-items: center;\n      }\n\n:host li > aside figcaption > p {\n        font-size: 1em;\n        line-height: 1.5;\n        padding-right: 3em;\n      }\n\n:host li > aside figcaption [table] {\n        display: grid;\n        grid-gap: 0.5em\n      }\n\n:host li > aside figcaption [table] > div {\n          display: grid;\n          grid-auto-flow: column;\n          grid-template-columns: 1fr auto;\n          justify-content: space-between;\n        }\n\n:host li > aside [hotkey] {\n      border-radius: 5em;\n      height: 1.5em;\n      width: 1.5em;\n      display: inline-flex;\n      align-items: center;\n      justify-content: center;\n      border: 1px solid var(--theme-color);\n      color: var(--theme-color);\n      font-weight: 300;\n      font-size: 0.5em;\n      text-transform: uppercase;\n    }\n\n:host li:hover:not([data-tool=\"search\"]) > aside,\n  :host li[data-tool=\"search\"] > svg:hover + aside {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n            transform: translateX(0);\n    transition-delay: 0.75s;\n  }\n\n:host li input::-webkit-calendar-picker-indicator {\n    background: inherit;\n    color: var(--theme-color);\n  }\n\n:host [colors] {\n  margin-top: 0;\n}\n\n:host [colors] > li {\n  overflow: hidden;\n  border-radius: 50%;\n  box-shadow: 0 0.25em 0.5em hsla(0,0%,0%,10%);\n  background: var(--theme-bg);\n  margin-bottom: 0.5em\n}\n\n:host [colors] > li:first-child {\n    margin-top: 0;\n  }\n\n:host [colors] li:hover:after {\n  top: 0;\n}\n\n:host li > svg {\n  width: 50%;\n  fill: var(--theme-icon_color);\n}\n\n:host li > svg.icon-cursor {\n  width: 35%;\n  fill: white;\n  stroke: var(--theme-icon_color);\n  stroke-width: 2px;\n}\n\n:host li[data-tool=\"search\"][data-active=\"true\"]:before {\n    -webkit-transform: translateX(-1em);\n            transform: translateX(-1em);\n    opacity: 0;\n  }\n\n:host li[data-tool=\"search\"] > .search {\n  position: absolute;\n  left: calc(100% - 1.25em);\n  top: 0;\n  height: 100%;\n  z-index: -1;\n  box-shadow: 0 0.25em 0.5em hsla(0,0%,0%,10%);\n  border-radius: 0 2em 2em 0;\n  overflow: hidden;\n}\n\n:host li[data-tool=\"search\"] > .search > input {\n  direction: ltr;\n  border: none;\n  font-size: 1em;\n  padding: 0.4em 0.4em 0.4em 2em;\n  outline: none;\n  height: 100%;\n  width: 250px;\n  box-sizing: border-box;\n  caret-color: hotpink\n}\n\n:host li[data-tool=\"search\"] > .search > input::-webkit-input-placeholder {\n    font-weight: lighter;\n    font-size: 0.8em;\n  }\n\n:host li[data-tool=\"search\"] > .search > input::-ms-input-placeholder {\n    font-weight: lighter;\n    font-size: 0.8em;\n  }\n\n:host li[data-tool=\"search\"] > .search > input::placeholder {\n    font-weight: lighter;\n    font-size: 0.8em;\n  }\n\n:host [colors] > li > svg {\n  position: relative;\n  top: -2px;\n}\n\n:host [colors] > li > svg > rect:last-child {\n  stroke: hsla(0,0%,0%,20%);\n  stroke-width: 0.5px;\n}\n\n:host input[type='color'] {\n  opacity: 0.01;\n  position: absolute;\n  top: 0; left: 0;\n  width: 100%; height: 100%;\n  z-index: 1;\n  box-sizing: border-box;\n  border: white;\n  padding: 0;\n  cursor: pointer;\n}\n\n:host input[type='color']:focus {\n  outline: none;\n}\n\n:host input[type='color']::-webkit-color-swatch-wrapper {\n  padding: 0;\n}\n\n:host input[type='color']::-webkit-color-swatch {\n  border: none;\n}\n\n:host input[type='color'][value='']::-webkit-color-swatch {\n  background-color: transparent !important;\n  background-image: linear-gradient(155deg, #ffffff 0%,#ffffff 46%,#ff0000 46%,#ff0000 54%,#ffffff 55%,#ffffff 100%);\n}\n";

class Handles extends HTMLElement {

  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'closed'});
  }

  connectedCallback() {
    window.addEventListener('resize', this.on_resize.bind(this));
  }
  disconnectedCallback() {
    window.removeEventListener('resize', this.on_resize);
  }

  on_resize() {
    window.requestAnimationFrame(() => {
      const node_label_id = this.$shadow.host.getAttribute('data-label-id');
      const [source_el] = $(`[data-label-id="${node_label_id}"]`);

      if (!source_el) return

      this.position = {
        node_label_id,
        boundingRect: source_el.getBoundingClientRect(),
      };
    });
  }

  set position({boundingRect, node_label_id}) {
    this.$shadow.innerHTML  = this.render(boundingRect, node_label_id);
  }

  render({ x, y, width, height, top, left }, node_label_id) {
    this.$shadow.host.setAttribute('data-label-id', node_label_id);
    return `
      ${this.styles({top,left})}
      <svg
        class="visbug-handles"
        width="${width}" height="${height}"
        viewBox="0 0 ${width} ${height}"
        version="1.1" xmlns="http://www.w3.org/2000/svg"
      >
        <rect stroke="hotpink" fill="none" width="100%" height="100%"></rect>
        <circle stroke="hotpink" fill="white" cx="0" cy="0" r="2"></circle>
        <circle stroke="hotpink" fill="white" cx="100%" cy="0" r="2"></circle>
        <circle stroke="hotpink" fill="white" cx="100%" cy="100%" r="2"></circle>
        <circle stroke="hotpink" fill="white" cx="0" cy="100%" r="2"></circle>
        <circle fill="hotpink" cx="${width/2}" cy="0" r="2"></circle>
        <circle fill="hotpink" cx="0" cy="${height/2}" r="2"></circle>
        <circle fill="hotpink" cx="${width/2}" cy="${height}" r="2"></circle>
        <circle fill="hotpink" cx="${width}" cy="${height/2}" r="2"></circle>
      </svg>
    `
  }

  styles({top,left}) {
    return `
      <style>
        :host > svg {
          position: absolute;
          top: ${top + window.scrollY}px;
          left: ${left}px;
          overflow: visible;
          pointer-events: none;
          z-index: 2147483644;
        }
      </style>
    `
  }
}

customElements.define('visbug-handles', Handles);

class Hover extends Handles {

  constructor() {
    super();
  }

  render({ x, y, width, height, top, left }) {
    return `
      ${this.styles({top,left})}
      <style>
        :host rect {
          width: 100%;
          height: 100%;
          vector-effect: non-scaling-stroke;
          stroke: hsl(267, 100%, 58%);
          stroke-width: 1px;
          fill: none;
        }

        :host > svg {
          z-index: 2147483642;
        }
      </style>
      <svg width="${width}" height="${height}">
        <rect></rect>
      </svg>
    `
  }
}

customElements.define('visbug-hover', Hover);

class Label extends HTMLElement {

  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'closed'});
  }

  connectedCallback() {
    $('a', this.$shadow).on('click mouseenter', this.dispatchQuery.bind(this));
    window.addEventListener('resize', this.on_resize.bind(this));
  }

  disconnectedCallback() {
    $('a', this.$shadow).off('click', this.dispatchQuery);
    window.removeEventListener('resize', this.on_resize);
  }

  on_resize() {
    window.requestAnimationFrame(() => {
      const node_label_id = this.$shadow.host.getAttribute('data-label-id');
      const [source_el]   = $(`[data-label-id="${node_label_id}"]`);

      if (!source_el) return

      this.position = {
        node_label_id,
        boundingRect: source_el.getBoundingClientRect(),
      };
    });
  }

  dispatchQuery(e) {
    this.$shadow.host.dispatchEvent(new CustomEvent('query', {
      bubbles: true,
      detail:   {
        text:       e.target.textContent,
        activator:  e.type,
      }
    }));
  }

  set text(content) {
    this._text = content;
  }

  set position({boundingRect, node_label_id}) {
    this.$shadow.innerHTML  = this.render(boundingRect, node_label_id);
  }

  set update({x,y}) {
    const label = this.$shadow.children[1];
    label.style.top  = y + window.scrollY + 'px';
    label.style.left = x - 1 + 'px';
  }

  render({ x, y, width, height, top, left }, node_label_id) {
    this.$shadow.host.setAttribute('data-label-id', node_label_id);

    return `
      ${this.styles({top,left,width})}
      <span>
        ${this._text}
      </span>
    `
  }

  styles({top,left,width}) {
    return `
      <style>
        :host {
          font-size: 16px;
        }

        :host > span {
          position: absolute;
          top: ${top + window.scrollY}px;
          left: ${left - 1}px;
          max-width: ${width + (window.innerWidth - left - width - 20)}px;
          z-index: 2147483643;
          transform: translateY(-100%);
          background: var(--label-bg, hotpink);
          border-radius: 0.2em 0.2em 0 0;
          text-shadow: 0 0.5px 0 hsla(0, 0%, 0%, 0.4);
          color: white;
          display: inline-flex;
          justify-content: center;
          font-size: 0.8em;
          font-weight: normal;
          font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;
          white-space: nowrap;
          padding: 0.25em 0.4em 0.15em;
          line-height: 1.1;
        }

        :host a {
          text-decoration: none;
          color: inherit;
          cursor: pointer;
          text-overflow: ellipsis;
          overflow: hidden;
        }

        :host a:hover {
          text-decoration: underline;
          color: white;
        }

        :host a[node]:before {
          content: "\\003c";
        }

        :host a[node]:after {
          content: "\\003e";
        }
      </style>
    `
  }
}

customElements.define('visbug-label', Label);

const desiredPropMap = {
  color:               'rgb(0, 0, 0)',
  backgroundColor:     'rgba(0, 0, 0, 0)',
  backgroundImage:     'none',
  backgroundSize:      'auto',
  backgroundPosition:  '0% 0%',
  // borderColor:      'rgb(0, 0, 0)',
  borderWidth:         '0px',
  borderRadius:        '0px',
  boxShadow:           'none',
  padding:             '0px',
  margin:              '0px',
  fontFamily:          '',
  fontSize:            '16px',
  fontWeight:          '400',
  textAlign:           'start',
  textShadow:          'none',
  textTransform:       'none',
  lineHeight:          'normal',
  letterSpacing:       'normal',
  display:             'block',
  alignItems:          'normal',
  justifyContent:      'normal',
  flexDirection:       'row',
  flexWrap:            'nowrap',
  flexBasis:           'auto',
  // flexFlow:         'none',
  fill:                'rgb(0, 0, 0)',
  stroke:              'none',
  gridTemplateColumns: 'none',
  gridAutoColumns:     'auto',
  gridTemplateRows:    'none',
  gridAutoRows:        'auto',
  gridTemplateAreas:   'none',
  gridArea:            'auto / auto / auto / auto',
  gap:                 'normal normal',
  gridAutoFlow:        'row',
};

const desiredAccessibilityMap = [
  'role',
  'tabindex',
  'aria-*',
  'for',
  'alt',
  'title',
  'type',
];

const largeWCAG2TextMap = [
  {
    fontSize: '24px',
    fontWeight: '0'
  },
  {
    fontSize: '18.5px',
    fontWeight: '700'
  }
];

const getStyle = (el, name) => {
  if (document.defaultView && document.defaultView.getComputedStyle) {
    name = name.replace(/([A-Z])/g, '-$1');
    name = name.toLowerCase();
    let s = document.defaultView.getComputedStyle(el, '');
    return s && s.getPropertyValue(name)
  } 
};

const getStyles = el => {
  const elStyleObject = el.style;
  const computedStyle = window.getComputedStyle(el, null);

  let desiredValues = [];

  for (prop in el.style)
    if (prop in desiredPropMap && desiredPropMap[prop] != computedStyle[prop])
      desiredValues.push({
        prop,
        value: computedStyle[prop].replace(/, rgba/g, '\rrgba')
      });

  return desiredValues
};

const getComputedBackgroundColor = el => {
  let background = getStyle(el, 'background-color');

  if (background === 'rgba(0, 0, 0, 0)') {
    let node  = findNearestParentElement(el)
      , found = false;

    while(!found) {
      let bg  = getStyle(node, 'background-color');

      if (bg !== 'rgba(0, 0, 0, 0)') {
        found = true;
        background = bg;
      }

      node = findNearestParentElement(node);

      if (node.nodeName === 'HTML') {
        found = true;
        background = 'white';
      }
    }
  }

  return background
};

const findNearestParentElement = el =>
  el.parentNode && el.parentNode.nodeType === 1
    ? el.parentNode
    : el.parentNode.nodeName === '#document-fragment'
      ? el.parentNode.host
      : el.parentNode.parentNode.host;

const findNearestChildElement = el => {
  if (el.shadowRoot && el.shadowRoot.children.length) {
    return [...el.shadowRoot.children]
      .filter(({nodeName}) => 
        !['LINK','STYLE','SCRIPT','HTML','HEAD'].includes(nodeName)
      )[0]
  }
  else if (el.children.length)
    return el.children[0]
};

const loadStyles = async stylesheets => {
  const fetches = await Promise.all(stylesheets.map(url => fetch(url)));
  const texts   = await Promise.all(fetches.map(url => url.text()));
  const style   = document.createElement('style');

  style.textContent = texts.reduce((styles, fileContents) => 
    styles + fileContents
  , '');

  document.head.appendChild(style);
};

const getA11ys = el => {
  const elAttributes = el.getAttributeNames();

  return desiredAccessibilityMap.reduce((acc, attribute) => {
    if (elAttributes.includes(attribute))
      acc.push({
        prop:   attribute,
        value:  el.getAttribute(attribute)
      });

    if (attribute === 'aria-*')
      elAttributes.forEach(attr => {
        if (attr.includes('aria'))
          acc.push({
            prop:   attr,
            value:  el.getAttribute(attr)
          });
      });

    return acc
  }, [])
};

const getWCAG2TextSize = el => {
  
  const styles = getStyles(el).reduce((styleMap, style) => {
      styleMap[style.prop] = style.value;
      return styleMap
  }, {});

  const { fontSize   = desiredPropMap.fontSize,
          fontWeight = desiredPropMap.fontWeight
      } = styles;
  
  const isLarge = largeWCAG2TextMap.some(
    (largeProperties) => parseFloat(fontSize) >= parseFloat(largeProperties.fontSize) 
       && parseFloat(fontWeight) >= parseFloat(largeProperties.fontWeight) 
  );

  return  isLarge ? 'Large' : 'Small'
};

const camelToDash = (camelString = "") =>
  camelString.replace(/([A-Z])/g, ($1) =>
    "-"+$1.toLowerCase());

const nodeKey = node => {
  let tree = [];
  let furthest_leaf = node;

  while (furthest_leaf) {
    tree.push(furthest_leaf);
    furthest_leaf = furthest_leaf.parentNode
      ? furthest_leaf.parentNode
      : false;
  }

  return tree.reduce((path, branch) => `
    ${path}${branch.tagName}_${branch.className}_${[...node.parentNode.children].indexOf(node)}_${node.children.length}
  `, '')
};

const createClassname = (el, ellipse = false) => {
  if (!el.className) return ''
  
  const combined = Array.from(el.classList).reduce((classnames, classname) =>
    classnames += '.' + classname
  , '');

  return ellipse && combined.length > 30
    ? combined.substring(0,30) + '...'
    : combined
};

const metaKey = window.navigator.platform.includes('Mac')
  ? 'cmd'
  : 'ctrl';

const altKey = window.navigator.platform.includes('Mac')
  ? 'opt'
  : 'alt';

const deepElementFromPoint = (x, y) => {
  const el = document.elementFromPoint(x, y);

  const crawlShadows = node => {
    if (node.shadowRoot) {
      const potential = node.shadowRoot.elementFromPoint(x, y);

      if (potential == node)          return node
      else if (potential.shadowRoot)  return crawlShadows(potential)
      else                            return potential
    }
    else return node
  };

  const nested_shadow = crawlShadows(el);

  return nested_shadow || el
};

const getSide = direction => {
  let start = direction.split('+').pop().replace(/^\w/, c => c.toUpperCase());
  if (start == 'Up') start = 'Top';
  if (start == 'Down') start = 'Bottom';
  return start
};

const getNodeIndex = el => {
  return [...el.parentElement.parentElement.children]
    .indexOf(el.parentElement)
};

function showEdge(el) {
  return el.animate([
    { outline: '1px solid transparent' },
    { outline: '1px solid hsla(330, 100%, 71%, 80%)' },
    { outline: '1px solid transparent' },
  ], 600)
}

let timeoutMap = {};
const showHideSelected = (el, duration = 750) => {
  el.setAttribute('data-selected-hide', true);
  showHideNodeLabel(el, true);

  if (timeoutMap[nodeKey(el)])
    clearTimeout(timeoutMap[nodeKey(el)]);

  timeoutMap[nodeKey(el)] = setTimeout(_ => {
    el.removeAttribute('data-selected-hide');
    showHideNodeLabel(el, false);
  }, duration);

  return el
};

const showHideNodeLabel = (el, show = false) => {
  if (!el.hasAttribute('data-label-id'))
    return

  const label_id = el.getAttribute('data-label-id');

  const nodes = $(`
    visbug-label[data-label-id="${label_id}"],
    visbug-handles[data-label-id="${label_id}"]
  `);

  nodes.length && show
    ? nodes.forEach(el =>
      el.style.display = 'none')
    : nodes.forEach(el =>
      el.style.display = null);
};

const htmlStringToDom = (htmlString = "") =>
  (new DOMParser().parseFromString(htmlString, 'text/html'))
    .body.firstChild;

const isOffBounds = node =>
  node.closest && (
       node.closest('vis-bug')
    || node.closest('hotkey-map')
    || node.closest('visbug-metatip')
    || node.closest('visbug-ally')
    || node.closest('visbug-label')
    || node.closest('visbug-handles')
    || node.closest('visbug-gridlines')
  );

const isSelectorValid = (qs => (
  selector => {
    try { qs(selector); } catch (e) { return false }
    return true
  }
))(s => document.createDocumentFragment().querySelector(s));

function windowBounds() {
  const height  = window.innerHeight;
  const width   = window.innerWidth;
  const body    = document.body.clientWidth;

  const calcWidth = body <= width
    ? body
    : width;

  return {
    winHeight: height,
    winWidth:  calcWidth,
  }
}

class Gridlines extends HTMLElement {

  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'closed'});
  }

  connectedCallback() {}
  disconnectedCallback() {}

  set position(boundingRect) {
    this.$shadow.innerHTML  = this.render(boundingRect);
  }

  set update({ width, height, top, left }) {
    const { winHeight, winWidth } = windowBounds();

    this.$shadow.host.style.display = 'block';
    const svg = this.$shadow.children[1];

    svg.setAttribute('viewBox', `0 0 ${winWidth} ${winHeight}`);
    svg.children[0].setAttribute('width', width + 'px');
    svg.children[0].setAttribute('height', height + 'px');
    svg.children[0].setAttribute('x', left);
    svg.children[0].setAttribute('y', top);
    svg.children[1].setAttribute('x1', left);
    svg.children[1].setAttribute('x2', left);
    svg.children[2].setAttribute('x1', left + width);
    svg.children[2].setAttribute('x2', left + width);
    svg.children[3].setAttribute('y1', top);
    svg.children[3].setAttribute('y2', top);
    svg.children[3].setAttribute('x2', winWidth);
    svg.children[4].setAttribute('y1', top + height);
    svg.children[4].setAttribute('y2', top + height);
    svg.children[4].setAttribute('x2', winWidth);
  }

  render({ x, y, width, height, top, left }) {
    const { winHeight, winWidth } = windowBounds();

    return `
      ${this.styles({top,left})}
      <svg
        width="100%" height="100%"
        viewBox="0 0 ${winWidth} ${winHeight}"
        version="1.1" xmlns="http://www.w3.org/2000/svg"
      >
        <rect
          stroke="hotpink" fill="none"
          width="${width}" height="${height}"
          x="${x}" y="${y}"
          style="display:none;"
        ></rect>
        <line x1="${x}" y1="0" x2="${x}" y2="${winHeight}" stroke="hotpink" stroke-dasharray="2" stroke-dashoffset="3"></line>
        <line x1="${x + width}" y1="0" x2="${x + width}" y2="${winHeight}" stroke="hotpink" stroke-dasharray="2" stroke-dashoffset="3"></line>
        <line x1="0" y1="${y}" x2="${winWidth}" y2="${y}" stroke="hotpink" stroke-dasharray="2" stroke-dashoffset="3"></line>
        <line x1="0" y1="${y + height}" x2="${winWidth}" y2="${y + height}" stroke="hotpink" stroke-dasharray="2" stroke-dashoffset="3"></line>
      </svg>
    `
  }

  styles({top,left}) {
    return `
      <style>
        :host > svg {
          position:fixed;
          top:0;
          left:0;
          overflow:visible;
          pointer-events:none;
          z-index:2147483642;
        }
      </style>
    `
  }
}

customElements.define('visbug-gridlines', Gridlines);

class Distance extends HTMLElement {

  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'open'});
  }

  connectedCallback() {}
  disconnectedCallback() {}

  set position({line_model, node_label_id}) {
    this.$shadow.innerHTML  = this.render(line_model, node_label_id);
  }

  render(measurements, node_label_id) {
    this.$shadow.host.setAttribute('data-label-id', node_label_id);
    return `
      ${this.styles(measurements)}
      <figure quadrant="measurements.q">
        <div></div>
        <figcaption><b>${measurements.d}</b>px</figcaption>
        <div></div>
      </figure>
    `
  }

  styles({y,x,d,q,v = false}) {
    return `
      <style>
        :host {
          --line-color: hsl(267, 100%, 58%);
          --line-width: 1px;
          font-size: 16px;
        }

        :host > figure {
          margin: 0;
          position: absolute;
          ${v
            ? `height: ${d}px; width: 5px;`
            : `width: ${d}px; height: 5px;`}
          top: ${y + window.scrollY}px;
          left: ${x}px;
          transform: ${v
            ? 'translateX(-50%)'
            : 'translateY(-50%)'};
          overflow: visible;
          pointer-events: none;
          z-index: 2147483646;

          display: flex;
          align-items: center;
          flex-direction: ${v ? 'column' : 'row'};
        }

        :host > figure figcaption {
          color: white;
          text-shadow: 0 0.5px 0 hsla(0, 0%, 0%, 0.4);
          background: var(--line-color);
          border-radius: 1em;
          text-align: center;
          line-height: 1.1;
          font-size: 0.7em;
          font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;
          padding: 0.25em 0.5em 0.275em;
          font-variant-numeric: proportional-num oldstyle-nums stacked-fractions slashed-zero;
        }

        :host > figure span {
          background: var(--line-color);
          ${v
            ? 'height: var(--line-width); width: 5px;'
            : 'width: var(--line-width); height: 5px;'}
        }

        :host > figure div {
          flex: 2;
          background: var(--line-color);
          ${v
            ? 'width: var(--line-width);'
            : 'height: var(--line-width);'}
        }

        :host figure > div${q === 'top' || q === 'left' ? ':last-of-type' : ':first-of-type'} {
          background: linear-gradient(to ${q}, hotpink 0%, var(--line-color) 100%);
        }
      </style>
    `
  }
}

customElements.define('visbug-distance', Distance);

class Overlay extends HTMLElement {
  
  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'closed'});
  }

  connectedCallback() {}
  disconnectedCallback() {}

  set position(boundingRect) {
    this.$shadow.innerHTML  = this.render(boundingRect);
  }

  set update({ top, left, width, height }) {
    this.$shadow.host.style.display = 'block';

    const svg = this.$shadow.children[0];
    svg.style.display = 'block';
    svg.style.top = window.scrollY + top + 'px';
    svg.style.left = left + 'px';

    svg.setAttribute('width', width + 'px');
    svg.setAttribute('height', height + 'px');
  }

  render({id, top, left, height, width}) {
    return `
      <svg 
        class="visbug-overlay"
        overlay-id="${id}"
        style="
          display:none;
          position:absolute;
          top:0;
          left:0;
          overflow:visible;
          pointer-events:none;
          z-index: 999;
        " 
        width="${width}px" height="${height}px" 
        viewBox="0 0 ${width} ${height}" 
        version="1.1" xmlns="http://www.w3.org/2000/svg"
      >
        <rect 
          fill="hsla(330, 100%, 71%, 0.5)"
          width="100%" height="100%"
        ></rect>
      </svg>
    `
  }
}

customElements.define('visbug-overlay', Overlay);

var css$1 = ":host {\n  --theme-bg: hsl(0,0%,100%);\n  --theme-color: hotpink;\n  --theme-blue: hsl(188, 90%, 45%);\n  --theme-purple: hsl(267, 100%, 58%);\n  --theme-icon_color: hsl(0,0%,20%);\n  --theme-icon_hover-bg: hsl(0,0%,95%);\n}\n\n:host {\n  position: absolute;\n  z-index: 2147483647;\n  direction: ltr;\n  font-size: 16px;\n  font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;\n\n  --arrow-width: 15px;\n  --arrow-height: 8px;\n\n  --shadow-up: 5px;\n  --shadow-down: -5px;\n  --shadow-direction: var(--shadow-up);\n\n  --arrow-up: polygon(0 0, 100% 0, 50% 100%);\n  --arrow-down: polygon(50% 0, 0 100%, 100% 100%);\n  --arrow: var(--arrow-up);\n}\n\n:host figure {\n  max-width: 50vw;\n  background: white;\n  color: var(--theme-icon_color);\n  line-height: normal;\n  line-height: initial;\n  padding: 0.5em;\n  margin: 0;\n  display: flex;\n  flex-direction: column;\n  flex-wrap: nowrap;\n  border-radius: 0.25em;\n  line-height: initial;\n  -webkit-filter: drop-shadow(0 var(--shadow-direction) 0.5em hsla(0,0%,0%,35%));\n          filter: drop-shadow(0 var(--shadow-direction) 0.5em hsla(0,0%,0%,35%))\n}\n\n:host figure:after {\n    content: \"\";\n    background: white;\n    width: var(--arrow-width);\n    height: var(--arrow-height);\n    -webkit-clip-path: var(--arrow);\n            clip-path: var(--arrow);\n    position: absolute;\n    top: var(--arrow-top);\n    left: var(--arrow-left);\n  }\n\n:host figure a {\n    text-decoration: none;\n    color: inherit;\n    text-overflow: ellipsis;\n    overflow: hidden;\n    cursor: pointer\n  }\n\n:host figure a:hover {\n      color: var(--theme-color);\n      text-decoration: underline;\n    }\n\n:host figure a:empty {\n      display: none;\n    }\n\n:host figure a[node]:before {\n      content: \"\\003c\";\n    }\n\n:host figure a[node]:after {\n      content: \"\\003e\";\n    }\n\n:host h5 {\n  display: flex;\n  font-size: 1em;\n  font-weight: bolder;\n  margin: 0;\n  overflow: hidden;\n  white-space: nowrap;\n}\n\n:host h6 {\n  margin-top: 1em;\n  margin-bottom: 0;\n  font-weight: normal;\n}\n\n:host small {\n  font-size: 0.7em;\n  color: hsl(0,0%,60%)\n}\n\n:host small > span {\n    color: hsl(0,0%,20%);\n  }\n\n:host a:not(:hover) {\n  text-decoration: none;\n}\n\n:host [brand],\n:host [divider] {\n  color: var(--theme-color);\n}\n\n:host div {\n  display: grid;\n  grid-template-columns: auto auto;\n  grid-gap: 0.25em 0.5em;\n  margin: 0.5em 0 0;\n  padding: 0;\n  list-style-type: none;\n  color: hsl(0,0%,40%);\n  font-size: 0.8em;\n  font-family: 'Dank Mono', 'Operator Mono', 'Inconsolata', 'Fira Mono', 'SF Mono', 'Monaco', 'Droid Sans Mono', 'Source Code Pro', monospace;\n}\n\n:host [value] {\n  color: var(--theme-icon_color);\n  display: inline-flex;\n  align-items: center;\n  justify-content: flex-end;\n  text-align: right;\n  /* white-space: pre; */\n}\n\n:host [text] {\n  white-space: normal;\n}\n\n:host [longform] {\n  background: var(--theme-icon_hover-bg);\n  padding: 0.5em 0.75em;\n  border-radius: 0.25em;\n  font-family: sans-serif;\n  text-align: left;\n  line-height: 1.5;\n}\n\n:host [color] {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  width: 0.6em;\n  height: 0.6em;\n  border-radius: 50%;\n  margin-right: 0.25em;\n}\n\n:host [local-modifications] {\n  margin-top: 1rem;\n  color: var(--theme-color);\n  font-weight: bold;\n}\n\n:host [contrast] > span {\n  padding: 0 0.5em 0.1em;\n  border-radius: 1em;\n  box-shadow: 0 0 0 1px hsl(0,0%,90%);\n}\n";

class Metatip extends HTMLElement {

  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'closed'});
  }

  connectedCallback() {
    $(this.$shadow.host).on('mouseenter', this.observe.bind(this));
  }

  disconnectedCallback() {
    this.unobserve();
  }

  dispatchQuery(e) {
    this.$shadow.host.dispatchEvent(new CustomEvent('query', {
      bubbles: true,
      detail:   {
        text:       e.target.textContent,
        activator:  e.type,
      }
    }));
  }

  observe() {
    $('h5 > a', this.$shadow).on('click mouseenter', this.dispatchQuery.bind(this));
    $('h5 > a', this.$shadow).on('mouseleave', this.dispatchUnQuery.bind(this));
  }

  unobserve() {
    $('h5 > a', this.$shadow).off('click mouseenter', this.dispatchQuery.bind(this));
    $('h5 > a', this.$shadow).off('mouseleave', this.dispatchUnQuery.bind(this));
  }

  dispatchUnQuery(e) {
    this.$shadow.host.dispatchEvent(new CustomEvent('unquery', {
      bubbles: true
    }));
    this.unobserve();
  }

  set meta(data) {
    this.$shadow.innerHTML = this.render(data);
  }

  render({el, width, height, localModifications, notLocalModifications}) {
    return `
      ${this.styles()}
      <figure>
        <h5>
          <a node>${el.nodeName.toLowerCase()}</a>
          <a>${el.id && '#' + el.id}</a>
          ${createClassname(el).split('.')
            .filter(name => name != '')
            .reduce((links, name) => `
              ${links}
              <a>.${name}</a>
            `, '')
          }
        </h5>
        <small>
          <span">${Math.round(width)}</span>px
          <span divider>×</span>
          <span>${Math.round(height)}</span>px
        </small>
        <div>${notLocalModifications.reduce((items, item) => `
          ${items}
          <span prop>${item.prop}:</span>
          <span value>${item.value}</span>
        `, '')}
        </div>
        ${localModifications.length ? `
          <h6 local-modifications>Local Modifications</h6>
          <div>${localModifications.reduce((items, item) => `
            ${items}
            <span prop>${item.prop}:</span>
            <span value>${item.value}</span>
          `, '')}
          </div>
        ` : ''}
      </figure>
    `
  }

  styles() {
    return `
      <style>
        ${css$1}
      </style>
    `
  }
}

customElements.define('visbug-metatip', Metatip);

class Ally extends Metatip {
  constructor() {
    super();
  }
  
  render({el, ally_attributes, contrast_results}) {
    return `
      ${this.styles()}
      <figure>
        <h5>${el.nodeName.toLowerCase()}${el.id && '#' + el.id}</h5>
        <div>
          ${ally_attributes.reduce((items, attr) => `
            ${items}
            <span prop>${attr.prop}:</span>
            <span value>${attr.value}</span>
          `, '')}
          ${contrast_results}
        </div>
      </figure>
    `
  }
}

customElements.define('visbug-ally', Ally);

var css$2 = ":host {\n  --theme-bg: hsl(0,0%,100%);\n  --theme-color: hotpink;\n  --theme-blue: hsl(188, 90%, 45%);\n  --theme-purple: hsl(267, 100%, 58%);\n  --theme-icon_color: hsl(0,0%,20%);\n  --theme-icon_hover-bg: hsl(0,0%,95%);\n}\n\n:host {\n  display: none;\n  position: fixed;\n  z-index: 99998;\n  align-items: center;\n  justify-content: center;\n  width: 100vw;\n  height: 100vh;\n  background: hsl(0,0%,95%);\n  font-size: 16px;\n  font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;\n\n  --light-grey: hsl(0,0%,90%);\n  --grey: hsl(0,0%,60%);\n  --dark-grey: hsl(0,0%,40%);\n}\n\n:host [command] {\n  padding: 1em;\n  text-align: center;\n  font-size: 3vw;\n  font-weight: lighter;\n  letter-spacing: 0.1em;\n  color: var(--dark-grey)\n}\n\n:host [command] > [light] {\n    color: var(--grey);\n  }\n\n:host [command] > [tool] {\n    text-decoration: underline;\n    -webkit-text-decoration-color: var(--theme-color);\n            text-decoration-color: var(--theme-color);\n  }\n\n:host [command] > [negative], :host [command] > [side], :host [command] > [amount] {\n    font-weight: normal;\n  }\n\n:host [card] {\n  padding: 1em;\n  background: white;\n  box-shadow: 0 0.5em 3em hsla(0,0%,0%,20%);\n  border-radius: 0.5em;\n  color: var(--dark-grey);\n  display: flex;\n  justify-content: space-evenly\n}\n\n:host [card] > div:not([keyboard]) {\n    display: flex;\n    align-items: flex-end;\n    margin-left: 1em;\n  }\n\n:host [tool-icon] {\n  position: absolute;\n  top: 1em;\n  left: 0;\n  width: 100%;\n  padding: 0 1rem;\n  display: flex;\n  justify-content: center\n}\n\n:host [tool-icon] > span {\n    color: var(--dark-grey);\n    display: grid;\n    grid-template-columns: 5vmax auto;\n    grid-gap: 0.5em;\n    align-items: center;\n    text-transform: capitalize;\n    font-size: 4vmax;\n    font-weight: lighter;\n  }\n\n:host [tool-icon] svg {\n    width: 100%;\n    fill: var(--theme-color);\n  }\n\n:host section {\n  display: flex;\n  justify-content: center;\n}\n\n:host section > span, \n:host [arrows] > span {\n  border: 1px solid transparent;\n  border-radius: 0.5em;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  margin: 2px;\n  padding: 1.5vw;\n  font-size: 0.75em;\n  white-space: nowrap;\n}\n\n:host section > span:not([pressed=\"true\"]), \n:host [arrows] > span:not([pressed=\"true\"]) {\n  border: 1px solid var(--light-grey)\n}\n\n:host section > span:not([pressed=\"true\"]):hover, :host [arrows] > span:not([pressed=\"true\"]):hover {\n    border-color: var(--grey);\n  }\n\n:host span[pressed=\"true\"] {\n  background: var(--theme-color);\n  color: white;\n}\n\n:host span:not([pressed=\"true\"])[used] {\n  background: var(--light-grey);\n}\n\n:host span[hotkey] {\n  color: var(--theme-color);\n  font-weight: bold;\n  cursor: pointer;\n}\n\n:host section > span[hotkey]:not([pressed=\"true\"]) {\n  border-color: var(--theme-color);\n}\n\n:host [arrows] {\n  display: grid;\n  grid-template-columns: 1fr 1fr 1fr;\n  grid-template-rows: 1fr 1fr\n}\n\n:host [arrows] > span:nth-child(1) {\n    grid-row: 1;\n    grid-column: 2;\n  }\n\n:host [arrows] > span:nth-child(2) {\n    grid-row: 2;\n    grid-column: 2;\n  }\n\n:host [arrows] > span:nth-child(3) {\n    grid-row: 2;\n    grid-column: 1;\n  }\n\n:host [arrows] > span:nth-child(4) {\n    grid-row: 2;\n    grid-column: 3;\n  }\n\n:host [caps] > span:nth-child(1),\n:host [shift] > span:nth-child(1)  { justify-content: flex-start; }\n\n:host [shift] > span:nth-child(12) { justify-content: flex-end; }";

const cursor = `
  <svg class="icon-cursor" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
    <path d="M16.689 17.655l5.311 12.345-4 2-4.646-12.678-7.354 6.678v-26l20 16-9.311 1.655z"></path>
  </svg>
`;

const move = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M15 7.5V2H9v5.5l3 3 3-3zM7.5 9H2v6h5.5l3-3-3-3zM9 16.5V22h6v-5.5l-3-3-3 3zM16.5 9l-3 3 3 3H22V9h-5.5z"/>
  </svg>
`;

const search = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
  </svg>
`;

const margin = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M9 7H7v2h2V7zm0 4H7v2h2v-2zm0-8c-1.11 0-2 .9-2 2h2V3zm4 12h-2v2h2v-2zm6-12v2h2c0-1.1-.9-2-2-2zm-6 0h-2v2h2V3zM9 17v-2H7c0 1.1.89 2 2 2zm10-4h2v-2h-2v2zm0-4h2V7h-2v2zm0 8c1.1 0 2-.9 2-2h-2v2zM5 7H3v12c0 1.1.89 2 2 2h12v-2H5V7zm10-2h2V3h-2v2zm0 12h2v-2h-2v2z"/>
  </svg>
`;

const padding = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm2 4v-2H3c0 1.1.89 2 2 2zM3 9h2V7H3v2zm12 12h2v-2h-2v2zm4-18H9c-1.11 0-2 .9-2 2v10c0 1.1.89 2 2 2h10c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 12H9V5h10v10zm-8 6h2v-2h-2v2zm-4 0h2v-2H7v2z"/>
  </svg>
`;

const font = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M9 4v3h5v12h3V7h5V4H9zm-6 8h3v7h3v-7h3V9H3v3z"/>
  </svg>
`;

const text = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
  </svg>
`;

const align = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="transform:rotateZ(90deg);">
    <path d="M10 20h4V4h-4v16zm-6 0h4v-8H4v8zM16 9v11h4V9h-4z"/>
  </svg>
`;

const resize = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M19 12h-2v3h-3v2h5v-5zM7 9h3V7H5v5h2V9zm14-6H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16.01H3V4.99h18v14.02z"/>
  </svg>
`;

const transform = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M12,7C6.48,7,2,9.24,2,12c0,2.24,2.94,4.13,7,4.77V20l4-4l-4-4v2.73c-3.15-0.56-5-1.9-5-2.73c0-1.06,3.04-3,8-3s8,1.94,8,3
    c0,0.73-1.46,1.89-4,2.53v2.05c3.53-0.77,6-2.53,6-4.58C22,9.24,17.52,7,12,7z"/>
  </svg>
`;

const border = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M13 7h-2v2h2V7zm0 4h-2v2h2v-2zm4 0h-2v2h2v-2zM3 3v18h18V3H3zm16 16H5V5h14v14zm-6-4h-2v2h2v-2zm-4-4H7v2h2v-2z"/>
  </svg>
`;

const hueshift = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-5.5 9c-.83 0-1.5-.67-1.5-1.5S5.67 9 6.5 9 8 9.67 8 10.5 7.33 12 6.5 12zm3-4C8.67 8 8 7.33 8 6.5S8.67 5 9.5 5s1.5.67 1.5 1.5S10.33 8 9.5 8zm5 0c-.83 0-1.5-.67-1.5-1.5S13.67 5 14.5 5s1.5.67 1.5 1.5S15.33 8 14.5 8zm3 4c-.83 0-1.5-.67-1.5-1.5S16.67 9 17.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>
  </svg>
`;

const boxshadow = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M20 8.69V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69L23.31 12 20 8.69zM12 18c-.89 0-1.74-.2-2.5-.55C11.56 16.5 13 14.42 13 12s-1.44-4.5-3.5-5.45C10.26 6.2 11.11 6 12 6c3.31 0 6 2.69 6 6s-2.69 6-6 6z"/>
  </svg>
`;

const inspector = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <g>
      <rect x="11" y="7" width="2" height="2"/>
      <rect x="11" y="11" width="2" height="6"/>
      <path d="M12,2C6.48,2,2,6.48,2,12c0,5.52,4.48,10,10,10s10-4.48,10-10C22,6.48,17.52,2,12,2z M12,20c-4.41,0-8-3.59-8-8
        c0-4.41,3.59-8,8-8s8,3.59,8,8C20,16.41,16.41,20,12,20z"/>
    </g>
  </svg>
`;

const camera = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="3.2"/>
    <path d="M9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"/>
  </svg>
`;

const guides = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M21,6H3C1.9,6,1,6.9,1,8v8c0,1.1,0.9,2,2,2h18c1.1,0,2-0.9,2-2V8C23,6.9,22.1,6,21,6z M21,16H3V8h2v4h2V8h2v4h2V8h2v4h2V8
    h2v4h2V8h2V16z"/>
  </svg>
`;

const color_text = `
  <svg viewBox="0 0 25 27">
    <path d="M11 3L5.5 17h2.25l1.12-3h6.25l1.12 3h2.25L13 3h-2zm-1.38 9L12 5.67 14.38 12H9.62z"/>
    <rect fill="var(--contextual_color)" x="1" y="21" width="23" height="5"></rect>
  </svg>
`;

const color_background = `
  <svg viewBox="0 0 25 27">
    <path d="M16.56 8.94L7.62 0 6.21 1.41l2.38 2.38-5.15 5.15c-.59.59-.59 1.54 0 2.12l5.5 5.5c.29.29.68.44 1.06.44s.77-.15 1.06-.44l5.5-5.5c.59-.58.59-1.53 0-2.12zM5.21 10L10 5.21 14.79 10H5.21zM19 11.5s-2 2.17-2 3.5c0 1.1.9 2 2 2s2-.9 2-2c0-1.33-2-3.5-2-3.5z"/>
    <rect fill="var(--contextual_color)" x="1" y="21" width="23" height="5"></rect>
  </svg>
`;

const color_border = `
  <svg viewBox="0 0 25 27">
    <path d="M17.75 7L14 3.25l-10 10V17h3.75l10-10zm2.96-2.96c.39-.39.39-1.02 0-1.41L18.37.29c-.39-.39-1.02-.39-1.41 0L15 2.25 18.75 6l1.96-1.96z"/>
    <rect fill="var(--contextual_color)" x="1" y="21" width="23" height="5"></rect>
  </svg>
`;

const position = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M15.54 5.54L13.77 7.3 12 5.54 10.23 7.3 8.46 5.54 12 2zm2.92 10l-1.76-1.77L18.46 12l-1.76-1.77 1.76-1.77L22 12zm-10 2.92l1.77-1.76L12 18.46l1.77-1.76 1.77 1.76L12 22zm-2.92-10l1.76 1.77L5.54 12l1.76 1.77-1.76 1.77L2 12z"/>
    <circle cx="12" cy="12" r="3"/>
  </svg>
`;

const accessibility = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M12,2c1.1,0,2,0.9,2,2s-0.9,2-2,2s-2-0.9-2-2S10.9,2,12,2z M21,9h-6v13h-2v-6h-2v6H9V9H3V7h18V9z"/>
  </svg>
`;

var Icons = /*#__PURE__*/Object.freeze({
  cursor: cursor,
  move: move,
  search: search,
  margin: margin,
  padding: padding,
  font: font,
  text: text,
  align: align,
  resize: resize,
  transform: transform,
  border: border,
  hueshift: hueshift,
  boxshadow: boxshadow,
  inspector: inspector,
  camera: camera,
  guides: guides,
  color_text: color_text,
  color_background: color_background,
  color_border: color_border,
  position: position,
  accessibility: accessibility
});

class HotkeyMap extends HTMLElement {

  constructor() {
    super();

    this.keyboard_model = {
      num:    ['`','1','2','3','4','5','6','7','8','9','0','-','=','delete'],
      tab:    ['tab','q','w','e','r','t','y','u','i','o','p','[',']','\\'],
      caps:   ['caps','a','s','d','f','g','h','j','k','l','\'','return'],
      shift:  ['shift','z','x','c','v','b','n','m',',','.','/','shift'],
      space:  ['ctrl',altKey,'cmd','spacebar','cmd',altKey,'ctrl']
    };

    this.key_size_model = {
      num:    {12:2},
      tab:    {0:2},
      caps:   {0:3,11:3},
      shift:  {0:6,11:6},
      space:  {3:10},
    };

    this.$shadow    = this.attachShadow({mode: 'closed'});

    this._hotkey    = '';
    this._usedkeys  = [];

    this.tool       = 'hotkeymap';
  }

  connectedCallback() {
    this.$shift  = $('[keyboard] > section > [shift]', this.$shadow);
    this.$ctrl   = $('[keyboard] > section > [ctrl]', this.$shadow);
    this.$alt    = $(`[keyboard] > section > [${altKey}]`, this.$shadow);
    this.$cmd    = $(`[keyboard] > section > [${metaKey}]`, this.$shadow);
    this.$up     = $('[arrows] [up]', this.$shadow);
    this.$down   = $('[arrows] [down]', this.$shadow);
    this.$left   = $('[arrows] [left]', this.$shadow);
    this.$right  = $('[arrows] [right]', this.$shadow);
  }

  disconnectedCallback() {}

  set tool(tool) {
    this._tool = tool;
    this.$shadow.innerHTML = this.render();
  }

  show() {
    this.$shadow.host.style.display = 'flex';
    hotkeys('*', (e, handler) =>
      this.watchKeys(e, handler));
  }

  hide() {
    this.$shadow.host.style.display = 'none';
    hotkeys.unbind('*');
  }

  watchKeys(e, handler) {
    e.preventDefault();
    e.stopImmediatePropagation();

    this.$shift.attr('pressed', hotkeys.shift);
    this.$ctrl.attr('pressed', hotkeys.ctrl);
    this.$alt.attr('pressed', hotkeys.alt);
    this.$cmd.attr('pressed', hotkeys[metaKey]);
    this.$up.attr('pressed', e.code === 'ArrowUp');
    this.$down.attr('pressed', e.code === 'ArrowDown');
    this.$left.attr('pressed', e.code === 'ArrowLeft');
    this.$right.attr('pressed', e.code === 'ArrowRight');

    const { negative, negative_modifier, side, amount } = this.createCommand({e, hotkeys});

    $('[command]', this.$shadow)[0].innerHTML = this.displayCommand({
      negative, negative_modifier, side, amount,
    });
  }

  createCommand({e:{code}, hotkeys: hotkeys$$1}) {
    let amount              = hotkeys$$1.shift ? 10 : 1;
    let negative            = hotkeys$$1.alt ? 'Subtract' : 'Add';
    let negative_modifier   = hotkeys$$1.alt ? 'from' : 'to';

    let side = '[arrow key]';
    if (code === 'ArrowUp')     side = 'the top side';
    if (code === 'ArrowDown')   side = 'the bottom side';
    if (code === 'ArrowLeft')   side = 'the left side';
    if (code === 'ArrowRight')  side = 'the right side';
    if (hotkeys$$1[metaKey])            side = 'all sides';

    if (hotkeys$$1[metaKey] && code === 'ArrowDown') {
      negative            = 'Subtract';
      negative_modifier   = 'from';
    }

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({negative, negative_modifier, side, amount}) {
    return `
      <span negative>${negative} </span>
      <span tool>${this._tool}</span>
      <span light> ${negative_modifier} </span>
      <span side>${side}</span>
      <span light> by </span>
      <span amount>${amount}</span>
    `
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${Icons[this._tool]}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          ${this.displayCommand({
            negative: `±[${altKey}] `,
            negative_modifier: ' to ',
            tool: this._tool,
            side: '[arrow key]',
            amount: 1
          })}
        </div>
        <div card>
          <div keyboard>
            ${Object.entries(this.keyboard_model).reduce((keyboard, [row_name, row]) => `
              ${keyboard}
              <section ${row_name}>${row.reduce((row, key, i) => `
                ${row}
                <span
                  ${key}
                  ${this._hotkey == key ? 'hotkey title="Tool Shortcut Hotkey"' : ''}
                  ${this._usedkeys.includes(key) ? 'used' : ''}
                  style="flex:${this.key_size_model[row_name][i] || 1};"
                >${key}</span>
              `, '')}
              </section>
            `, '')}
          </div>
          <div>
            <section arrows>
              <span up used>↑</span>
              <span down used>↓</span>
              <span left used>←</span>
              <span right used>→</span>
            </section>
          </div>
        </div>
      </article>
    `
  }

  styles() {
    return `
      <style>
        ${css$2}
      </style>
    `
  }
}

customElements.define('hotkey-map', HotkeyMap);

class GuidesHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'g';
    this._usedkeys  = [];
    this.tool       = 'guides';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${guides}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-guides', GuidesHotkeys);

class InspectorHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'i';
    this._usedkeys  = [altKey];
    this.tool       = 'inspector';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${inspector}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-inspector', InspectorHotkeys);

class AccessibilityHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'p';
    this._usedkeys  = [altKey];
    this.tool       = 'accessibility';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${accessibility}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-accessibility', AccessibilityHotkeys);

class MoveHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey  = 'v';
    this.tool     = 'move';
  }

  createCommand({e:{code}, hotkeys}) {
    let amount, negative, negative_modifier;

    let side = '[arrow key]';
    if (code === 'ArrowUp')     side = 'up & out of div';
    if (code === 'ArrowDown')   side = 'down & into next sibling / out & under div';
    if (code === 'ArrowLeft')   side = 'towards the front/top of the stack';
    if (code === 'ArrowRight')  side = 'towards the back/bottom of the stack';

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({side}) {
    return `
      <span tool>${this._tool}</span>
      <span side>${side}</span>
    `
  }
}

customElements.define('hotkeys-move', MoveHotkeys);

class MarginHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'm';
    this._usedkeys  = ['shift',metaKey,altKey];

    this.tool       = 'margin';
  }
}

customElements.define('hotkeys-margin', MarginHotkeys);

class PaddingHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'p';
    this._usedkeys  = ['shift',metaKey,altKey];

    this.tool       = 'padding';
  }
}

customElements.define('hotkeys-padding', PaddingHotkeys);

const h_alignOptions  = ['left','center','right'];
const v_alignOptions  = ['top','center','bottom'];
const distOptions     = ['evenly','normal','between'];

class AlignHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey   = 'a';
    this._usedkeys = [metaKey,'shift'];

    this._htool   = 0;
    this._vtool   = 0;
    this._dtool   = 1;

    this._side         = 'top left';
    this._direction    = 'row';
    this._distribution = distOptions[this._dtool];

    this.tool     = 'align';
  }

  createCommand({e:{code}, hotkeys}) {
    let amount            = this._distribution
      , negative_modifier = this._direction
      , side              = this._side
      , negative;

    if (hotkeys.cmd && (code === 'ArrowRight' || code === 'ArrowDown')) {
      negative_modifier = code === 'ArrowDown'
        ? 'column'
        : 'row';
      this._direction = negative_modifier;
    }
    else {
      if (code === 'ArrowUp')           side = this.clamp(v_alignOptions, '_vtool');
      else if (code === 'ArrowDown')    side = this.clamp(v_alignOptions, '_vtool', true);
      else                              side = v_alignOptions[this._vtool];

      if (code === 'ArrowLeft')         side += ' ' + this.clamp(h_alignOptions, '_htool');
      else if (code === 'ArrowRight')   side += ' ' + this.clamp(h_alignOptions, '_htool', true);
      else                              side += ' ' + h_alignOptions[this._htool];

      this._side = side;

      if (hotkeys.shift && (code === 'ArrowRight' || code === 'ArrowLeft')) {
        amount = this.clamp(distOptions, '_dtool', code === 'ArrowRight');
        this._distribution = amount;
      }
    }

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({side, amount, negative_modifier}) {
    if (amount == 1) amount = this._distribution;
    if (negative_modifier == ' to ') negative_modifier = this._direction;

    return `
      <span tool>${this._tool}</span>
      <span light> as </span>
      <span>${negative_modifier}:</span>
      <span side>${side}</span>
      <span light> distributed </span>
      <span amount>${amount}</span>
    `
  }

  clamp(range, tool, increment = false) {
    if (increment) {
      if (this[tool] < range.length - 1)
        this[tool] = this[tool] + 1;
    }
    else if (this[tool] > 0)
      this[tool] = this[tool] - 1;

    return range[this[tool]]
  }
}

customElements.define('hotkeys-align', AlignHotkeys);

class HueshiftHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'h';
    this._usedkeys  = ['shift',metaKey];
    this.tool       = 'hueshift';
  }

  createCommand({e:{code}, hotkeys}) {
    let amount              = hotkeys.shift ? 10 : 1;
    let negative            = '[increase/decrease]';
    let negative_modifier   = 'by';
    let side                = '[arrow key]';

    // saturation
    if (hotkeys.cmd) {
      side ='hue';

      if (code === 'ArrowDown')
        negative  = 'decrease';
      if (code === 'ArrowUp')
        negative  = 'increase';
    }
    else if (code === 'ArrowLeft' || code === 'ArrowRight') {
      side = 'saturation';

      if (code === 'ArrowLeft')
        negative  = 'decrease';
      if (code === 'ArrowRight')
        negative  = 'increase';
    }
    // lightness
    else if (code === 'ArrowUp' || code === 'ArrowDown') {
      side = 'lightness';

      if (code === 'ArrowDown')
        negative  = 'decrease';
      if (code === 'ArrowUp')
        negative  = 'increase';
    }

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({negative, negative_modifier, side, amount}) {
    if (negative === `±[${altKey}] `)
      negative = '[increase/decrease]';
    if (negative_modifier === ' to ')
      negative_modifier = ' by ';

    return `
      <span negative>${negative}</span>
      <span side tool>${side}</span>
      <span light>${negative_modifier}</span>
      <span amount>${amount}</span>
    `
  }
}

customElements.define('hotkeys-hueshift', HueshiftHotkeys);

class BoxshadowHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'd';
    this._usedkeys  = ['shift',metaKey];
    this.tool       = 'boxshadow';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${boxshadow}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-boxshadow', BoxshadowHotkeys);

class PositionHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'l';
    this._usedkeys  = ['shift',altKey];
    this.tool       = 'position';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${position}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-position', PositionHotkeys);

class FontHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'f';
    this._usedkeys  = ['shift',metaKey];
    this.tool       = 'font';
  }

  createCommand({e:{code}, hotkeys}) {
    let amount              = hotkeys.shift ? 10 : 1;
    let negative            = '[increase/decrease]';
    let negative_modifier   = 'by';
    let side                = '[arrow key]';

    // kerning
    if (hotkeys.shift && (code === 'ArrowLeft' || code === 'ArrowRight')) {
      side    = 'kerning';
      amount  = '1px';

      if (code === 'ArrowLeft')
        negative  = 'decrease';
      if (code === 'ArrowRight')
        negative  = 'increase';
    }
    // leading
    else if (hotkeys.shift && (code === 'ArrowUp' || code === 'ArrowDown')) {
      side    = 'leading';
      amount  = '1px';

      if (code === 'ArrowUp')
        negative  = 'increase';
      if (code === 'ArrowDown')
        negative  = 'decrease';
    }
    // font weight
    else if (hotkeys.cmd && (code === 'ArrowUp' || code === 'ArrowDown')) {
      side                = 'font weight';
      amount              = '';
      negative_modifier   = '';

      if (code === 'ArrowUp')
        negative  = 'increase';
      if (code === 'ArrowDown')
        negative  = 'decrease';
    }
    // font size
    else if (code === 'ArrowUp' || code === 'ArrowDown') {
      side    = 'font size';
      amount  = '1px';

      if (code === 'ArrowUp')
        negative  = 'increase';
      if (code === 'ArrowDown')
        negative  = 'decrease';
    }
    // text alignment
    else if (code === 'ArrowRight' || code === 'ArrowLeft') {
      side                = 'text alignment';
      amount              = '';
      negative            = 'adjust';
      negative_modifier   = '';
    }

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({negative, negative_modifier, side, amount}) {
    if (negative === `±[${altKey}] `)
      negative = '[increase/decrease]';
    if (negative_modifier === ' to ')
      negative_modifier = ' by ';

    return `
      <span negative>${negative}</span>
      <span side tool>${side}</span>
      <span light>${negative_modifier}</span>
      <span amount>${amount}</span>
    `
  }
}

customElements.define('hotkeys-font', FontHotkeys);

class TextHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'e';
    this._usedkeys  = [];
    this.tool       = 'text';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${text}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-text', TextHotkeys);

class SearchHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 's';
    this._usedkeys  = [];
    this.tool       = 'search';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${search}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-search', SearchHotkeys);

class Hotkeys extends HTMLElement {

  constructor() {
    super();

    this.tool_map = {
      guides:         document.createElement('hotkeys-guides'),
      inspector:      document.createElement('hotkeys-inspector'),
      accessibility:  document.createElement('hotkeys-accessibility'),
      move:           document.createElement('hotkeys-move'),
      margin:         document.createElement('hotkeys-margin'),
      padding:        document.createElement('hotkeys-padding'),
      align:          document.createElement('hotkeys-align'),
      hueshift:       document.createElement('hotkeys-hueshift'),
      boxshadow:      document.createElement('hotkeys-boxshadow'),
      position:       document.createElement('hotkeys-position'),
      font:           document.createElement('hotkeys-font'),
      text:           document.createElement('hotkeys-text'),
      search:         document.createElement('hotkeys-search'),
    };

    Object.values(this.tool_map).forEach(tool =>
      this.appendChild(tool));
  }

  connectedCallback() {
    hotkeys('shift+/', e =>
      this.cur_tool
        ? this.hideTool()
        : this.showTool());

    hotkeys('esc', e => this.hideTool());
  }

  disconnectedCallback() {}

  hideTool() {
    if (!this.cur_tool) return
    this.cur_tool.hide();
    this.cur_tool = null;
  }

  showTool() {
    this.cur_tool = this.tool_map[
      $('vis-bug')[0].activeTool];
    this.cur_tool.show();
  }
}

customElements.define('visbug-hotkeys', Hotkeys);

// todo: show margin color
const key_events = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},alt+${event},shift+${event},shift+alt+${event}`
  , '')
  .substring(1);

const command_events = `${metaKey}+up,${metaKey}+shift+up,${metaKey}+down,${metaKey}+shift+down`;

function Margin({selection}) {
  hotkeys(key_events, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();
    pushElement(selection(), handler.key);
  });

  hotkeys(command_events, (e, handler) => {
    e.preventDefault();
    pushAllElementSides(selection(), handler.key);
  });

  return () => {
    hotkeys.unbind(key_events);
    hotkeys.unbind(command_events);
    hotkeys.unbind('up,down,left,right'); // bug in lib?
  }
}

function pushElement(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'margin' + getSide(direction),
      current:  parseInt(getStyle(el, 'margin' + getSide(direction)), 10),
      amount:   direction.split('+').includes('shift') ? 10 : 1,
      negative: direction.split('+').includes('alt'),
    }))
    .map(payload =>
      Object.assign(payload, {
        margin: payload.negative
          ? payload.current - payload.amount
          : payload.current + payload.amount
      }))
    .forEach(({el, style, margin}) =>
      el.style[style] = `${margin < 0 ? 0 : margin}px`);
}

function pushAllElementSides(els, keycommand) {
  const combo = keycommand.split('+');
  let spoof = '';

  if (combo.includes('shift'))  spoof = 'shift+' + spoof;
  if (combo.includes('down'))   spoof = 'alt+' + spoof;

  'up,down,left,right'.split(',')
    .forEach(side => pushElement(els, spoof + side));
}

const key_events$1 = 'up,down,left,right';
// todo: indicator for when node can descend
// todo: indicator where left and right will go
// todo: have it work with shadowDOM
function Moveable({selection}) {
  hotkeys(key_events$1, (e, {key}) => {
    if (e.cancelBubble) return
      
    e.preventDefault();
    e.stopPropagation();
    
    selection().forEach(el => {
      moveElement(el, key);
      updateFeedback(el);
    });
  });

  return () => {
    hotkeys.unbind(key_events$1);
  }
}

function moveElement(el, direction) {
  if (!el) return

  switch(direction) {
    case 'left':
      if (canMoveLeft(el))
        el.parentNode.insertBefore(el, el.previousElementSibling);
      else
        showEdge(el.parentNode);
      break

    case 'right':
      if (canMoveRight(el) && el.nextElementSibling.nextSibling)
        el.parentNode.insertBefore(el, el.nextElementSibling.nextSibling);
      else if (canMoveRight(el))
        el.parentNode.appendChild(el);
      else
        showEdge(el.parentNode);
      break

    case 'up':
      if (canMoveUp(el))
        popOut({el});
      break

    case 'down':
      if (canMoveUnder(el))
        popOut({el, under: true});
      else if (canMoveDown(el))
        el.nextElementSibling.prepend(el);
      break
  }
}

const canMoveLeft    = el => el.previousElementSibling;
const canMoveRight   = el => el.nextElementSibling;
const canMoveDown    = el => el.nextElementSibling && el.nextElementSibling.children.length;
const canMoveUnder   = el => !el.nextElementSibling && el.parentNode && el.parentNode.parentNode;
const canMoveUp      = el => el.parentNode && el.parentNode.parentNode;

const popOut = ({el, under = false}) =>
  el.parentNode.parentNode.insertBefore(el, 
    el.parentNode.parentNode.children[
      under
        ? getNodeIndex(el) + 1
        : getNodeIndex(el)]); 

function updateFeedback(el) {
  let options = '';
  // get current elements offset/size
  if (canMoveLeft(el))  options += '⇠';
  if (canMoveRight(el)) options += '⇢';
  if (canMoveDown(el))  options += '⇣';
  if (canMoveUp(el))    options += '⇡';
  // create/move arrows in absolute/fixed to overlay element
  options && console.info('%c'+options, "font-size: 2rem;");
}

let imgs      = []
  , overlays  = []
  , dragItem;

function watchImagesForUpload() {
  imgs = $([
    ...document.images,
    ...findBackgroundImages(document),
  ]);

  clearWatchers(imgs);
  initWatchers(imgs);
}

const initWatchers = imgs => {
  imgs.on('dragover', onDragEnter);
  imgs.on('dragleave', onDragLeave);
  imgs.on('drop', onDrop);
  $(document.body).on('dragover', onDragEnter);
  $(document.body).on('dragleave', onDragLeave);
  $(document.body).on('drop', onDrop);
  $(document.body).on('dragstart', onDragStart);
  $(document.body).on('dragend', onDragEnd);
};

const clearWatchers = imgs => {
  imgs.off('dragenter', onDragEnter);
  imgs.off('dragleave', onDragLeave);
  imgs.off('drop', onDrop);
  $(document.body).off('dragenter', onDragEnter);
  $(document.body).off('dragleave', onDragLeave);
  $(document.body).off('drop', onDrop);
  $(document.body).on('dragstart', onDragStart);
  $(document.body).on('dragend', onDragEnd);
  imgs = [];
};

const previewFile = file => {
  return new Promise((resolve, reject) => {
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = () => resolve(reader.result);
  })
};

// only fired for in-page drag events, track what the user picked up
const onDragStart = ({target}) =>
  dragItem = target;

const onDragEnd = e =>
  dragItem = undefined;

const onDragEnter = e => {
  e.preventDefault();
  const pre_selected = $('img[data-selected=true]');

  if (!pre_selected.length)
    showOverlay(e.currentTarget, 0);
  else
    pre_selected.forEach((img, i) =>
      showOverlay(img, i));
};

const onDragLeave = e => 
  hideOverlays();


const onDrop = async e => {
  e.stopPropagation();
  e.preventDefault();

  const selectedImages = $('img[data-selected=true]');
  
  const srcs = e.dataTransfer.files.length 
    ? await Promise.all([...e.dataTransfer.files]
      .filter(file => file.type.includes('image'))
      .map(previewFile)) 
    : [dragItem.src];
  
  if (srcs.length) {
    if (!selectedImages.length)
      if (e.target.nodeName === 'IMG')
        e.target.src = srcs[0];
      else
        imgs
          .filter(img => img.contains(e.target))
          .forEach(img => 
            img.style.backgroundImage = `url(${srcs[0]})`);
    else if (selectedImages.length) {
      let i = 0;
      selectedImages.forEach(img => {
        img.src = srcs[i++];
        if (i >= srcs.length) i = 0;
      });
    }
  }

  hideOverlays();
};

const showOverlay = (node, i) => {
  const rect    = node.getBoundingClientRect();
  const overlay = overlays[i];

  if (overlay) {
    overlay.update = rect;
  }
  else {
    overlays[i] = document.createElement('visbug-overlay');
    overlays[i].position = rect;
    document.body.appendChild(overlays[i]);
  }
};

const hideOverlays = () => {
  overlays.forEach(overlay =>
    overlay.remove());
  overlays = [];
};

const findBackgroundImages = el => {
  const src_regex = /url\(\s*?['"]?\s*?(\S+?)\s*?["']?\s*?\)/i;

  return $('*').reduce((collection, node) => {
    const prop = getStyle(node, 'background-image');
    const match = src_regex.exec(prop);

    // if (match) collection.push(match[1])
    if (match) collection.push(node);

    return collection
  }, [])
};

/**
 * @author Georgegriff@ (George Griffiths)
 * License Apache-2.0
 */

/**
* Finds first matching elements on the page that may be in a shadow root using a complex selector of n-depth
*
* Don't have to specify all shadow roots to button, tree is travered to find the correct element
*
* Example querySelectorAllDeep('downloads-item:nth-child(4) #remove');
*
* Example should work on chrome://downloads outputting the remove button inside of a download card component
*
* Example find first active download link element querySelectorDeep('#downloads-list .is-active a[href^="https://"]');
*
* Another example querySelectorAllDeep('#downloads-list div#title-area + a');
e.g.
*/
function querySelectorAllDeep(selector, root = document) {
    return _querySelectorDeep(selector, true, root);
}

function _querySelectorDeep(selector, findMany, root) {
    let lightElement = root.querySelector(selector);

    if (document.head.createShadowRoot || document.head.attachShadow) {
        // no need to do any special if selector matches something specific in light-dom
        if (!findMany && lightElement) {
            return lightElement;
        }

        // split on commas because those are a logical divide in the operation
        const selectionsToMake = splitByCharacterUnlessQuoted(selector, ',');

        return selectionsToMake.reduce((acc, minimalSelector) => {
            // if not finding many just reduce the first match
            if (!findMany && acc) {
                return acc;
            }
            // do best to support complex selectors and split the query
            const splitSelector = splitByCharacterUnlessQuoted(minimalSelector
                    //remove white space at start of selector
                    .replace(/^\s+/g, '')
                    .replace(/\s*([>+~]+)\s*/g, '$1'), ' ')
                // filter out entry white selectors
                .filter((entry) => !!entry);
            const possibleElementsIndex = splitSelector.length - 1;
            const possibleElements = collectAllElementsDeep(splitSelector[possibleElementsIndex], root);
            const findElements = findMatchingElement(splitSelector, possibleElementsIndex, root);
            if (findMany) {
                acc = acc.concat(possibleElements.filter(findElements));
                return acc;
            } else {
                acc = possibleElements.find(findElements);
                return acc || null;
            }
        }, findMany ? [] : null);


    } else {
        if (!findMany) {
            return lightElement;
        } else {
            return root.querySelectorAll(selector);
        }
    }

}

function findMatchingElement(splitSelector, possibleElementsIndex, root) {
    return (element) => {
        let position = possibleElementsIndex;
        let parent = element;
        let foundElement = false;
        while (parent) {
            const foundMatch = parent.matches(splitSelector[position]);
            if (foundMatch && position === 0) {
                foundElement = true;
                break;
            }
            if (foundMatch) {
                position--;
            }
            parent = findParentOrHost(parent, root);
        }
        return foundElement;
    };

}

function splitByCharacterUnlessQuoted(selector, character) {
    return selector.match(/\\?.|^$/g).reduce((p, c) => {
        if (c === '"' && !p.sQuote) {
            p.quote ^= 1;
            p.a[p.a.length - 1] += c;
        } else if (c === '\'' && !p.quote) {
            p.sQuote ^= 1;
            p.a[p.a.length - 1] += c;

        } else if (!p.quote && !p.sQuote && c === character) {
            p.a.push('');
        } else {
            p.a[p.a.length - 1] += c;
        }
        return p;
    }, { a: [''] }).a;
}


function findParentOrHost(element, root) {
    const parentNode = element.parentNode;
    return (parentNode && parentNode.host && parentNode.nodeType === 11) ? parentNode.host : parentNode === root ? null : parentNode;
}

/**
 * Finds all elements on the page, inclusive of those within shadow roots.
 * @param {string=} selector Simple selector to filter the elements by. e.g. 'a', 'div.main'
 * @return {!Array<string>} List of anchor hrefs.
 * @author ebidel@ (Eric Bidelman)
 * License Apache-2.0
 */
function collectAllElementsDeep(selector = null, root) {
    const allElements = [];

    const findAllElements = function(nodes) {
        for (let i = 0, el; el = nodes[i]; ++i) {
            allElements.push(el);
            // If the element has a shadow root, dig deeper.
            if (el.shadowRoot) {
                findAllElements(el.shadowRoot.querySelectorAll('*'));
            }
        }
    };
    if(root.shadowRoot) {
        findAllElements(root.shadowRoot.querySelectorAll('*'));
    }
    findAllElements(root.querySelectorAll('*'));

    return selector ? allElements.filter(el => el.matches(selector)) : allElements;
}

const commands = [
  'empty page',
  'blank page',
  'clear canvas',
];

function BlankPagePlugin() {
  document
    .querySelectorAll('body > *:not(vis-bug):not(script)')
    .forEach(node => node.remove());
}

const commands$1 = [
  'barrel roll',
  'do a barrel roll',
];

async function BarrelRollPlugin() {
  document.body.style.transformOrigin = 'center 50vh';
  
  await document.body.animate([
    { transform: 'rotateZ(0)' },
    { transform: 'rotateZ(1turn)' },
  ], { duration: 1500 }).finished;

  document.body.style.transformOrigin = '';
}

const commands$2 = [
  'pesticide',
];

async function PesticidePlugin() {
  await loadStyles(['https://unpkg.com/pesticide@1.3.1/css/pesticide.min.css']);
}

const commands$3 = [
  'trashy',
  'construct',
];

async function ConstructPlugin() {
  await loadStyles(['https://cdn.jsdelivr.net/gh/t7/construct.css@master/css/construct.boxes.css']);
}

const commands$4 = [
  'debug trashy',
  'debug construct',
];

async function ConstructDebugPlugin() {
  await loadStyles(['https://cdn.jsdelivr.net/gh/t7/construct.css@master/css/construct.debug.css']);
}

const commands$5 = [
  'wireframe',
  'blueprint',
];

async function WireframePlugin() {
  const styles = `
    *:not(path):not(g) {
      color: hsla(210, 100%, 100%, 0.9) !important;
      background: hsla(210, 100%, 50%, 0.5) !important;
      outline: solid 0.25rem hsla(210, 100%, 100%, 0.5) !important;
      box-shadow: none !important;
    }
  `;

  const style = document.createElement('style');
  style.textContent = styles;
  document.head.appendChild(style);
}

const commands$6 = [
  'skeleton',
  'outline',
];

async function SkeletonPlugin() {
  const styles = `
    *:not(path):not(g) {
      color: hsl(0, 0%, 0%) !important;
      text-shadow: none !important;
      background: hsl(0, 0%, 100%) !important;
      outline: 1px solid hsla(0, 0%, 0%, 0.5) !important;
      border-color: transparent !important;
      box-shadow: none !important;
    }
  `;

  const style = document.createElement('style');
  style.textContent = styles;
  document.head.appendChild(style);
}

// https://gist.github.com/addyosmani/fd3999ea7fce242756b1
const commands$7 = [
  'tag debugger',
  'osmani',
];

async function TagDebuggerPlugin() {
  for (i = 0; A = document.querySelectorAll('*')[i++];)
    A.style.outline = `solid hsl(${(A+A).length*9},99%,50%) 1px`;
}

// http://heydonworks.com/revenge_css_bookmarklet/

const commands$8 = [
  'revenge',
  'revenge.css',
  'heydon',
];

async function RevengePlugin() {
  await loadStyles(['https://cdn.jsdelivr.net/gh/Heydon/REVENGE.CSS@master/revenge.css']);
}

const commandsToHash = (plugin_commands, plugin_fn) =>
  plugin_commands.reduce((commands$$1, command) =>
    Object.assign(commands$$1, {[`/${command}`]:plugin_fn})
  , {});

const PluginRegistry = new Map(Object.entries({
  ...commandsToHash(commands, BlankPagePlugin),
  ...commandsToHash(commands$1, BarrelRollPlugin),
  ...commandsToHash(commands$2, PesticidePlugin),
  ...commandsToHash(commands$3, ConstructPlugin),
  ...commandsToHash(commands$4, ConstructDebugPlugin),
  ...commandsToHash(commands$5, WireframePlugin),
  ...commandsToHash(commands$6, SkeletonPlugin),
  ...commandsToHash(commands$7, TagDebuggerPlugin),
  ...commandsToHash(commands$8, RevengePlugin),
}));

const PluginHints = [
  commands[0],
  commands$1[0],
  commands$2[0],
  commands$3[0],
  commands$4[0],
  commands$5[0],
  commands$6[0],
  commands$7[0],
  commands$8[0],
].map(command => `/${command}`);

let SelectorEngine;

// create input
const search_base = document.createElement('div');
search_base.classList.add('search');
search_base.innerHTML = `
  <input list="visbug-plugins" type="text" placeholder="ex: images, .btn, button, text, ..."/>
  <datalist id="visbug-plugins">
    ${PluginHints.reduce((options, command) =>
      options += `<option value="${command}">plugin</option>`
    , '')}
    <option value="h1, h2, h3, .get-multiple">example</option>
    <option value="nav > a:first-child">example</option>
    <option value="#get-by-id">example</option>
    <option value=".get-by.class-names">example</option>
    <option value="images">alias</option>
    <option value="text">alias</option>
  </datalist>
`;

const search$1        = $(search_base);
const searchInput   = $('input', search_base);

const showSearchBar = () => search$1.attr('style', 'display:block');
const hideSearchBar = () => search$1.attr('style', 'display:none');
const stopBubbling  = e => e.key != 'Escape' && e.stopPropagation();

function Search(node) {
  if (node) node[0].appendChild(search$1[0]);

  const onQuery = e => {
    e.preventDefault();
    e.stopPropagation();

    const query = e.target.value;

    window.requestIdleCallback(_ =>
      queryPage(query));
  };

  searchInput.on('input', onQuery);
  searchInput.on('keydown', stopBubbling);
  // searchInput.on('blur', hideSearchBar)

  showSearchBar();
  searchInput[0].focus();

  // hotkeys('escape,esc', (e, handler) => {
  //   hideSearchBar()
  //   hotkeys.unbind('escape,esc')
  // })

  return () => {
    hideSearchBar();
    searchInput.off('oninput', onQuery);
    searchInput.off('keydown', stopBubbling);
    searchInput.off('blur', hideSearchBar);
  }
}

function provideSelectorEngine(Engine) {
  SelectorEngine = Engine;
}

function queryPage(query, fn) {
  // todo: should stash a cleanup method to be called when query doesnt match
  if (PluginRegistry.has(query))
    return PluginRegistry.get(query)(query)

  if (query == 'links')     query = 'a';
  if (query == 'buttons')   query = 'button';
  if (query == 'images')    query = 'img';
  if (query == 'text')      query = 'p,caption,a,h1,h2,h3,h4,h5,h6,small,date,time,li,dt,dd';

  if (!query) return SelectorEngine.unselect_all()
  if (query == '.' || query == '#' || query.trim().endsWith(',')) return

  try {
    let matches = querySelectorAllDeep(query + ':not(vis-bug):not(script):not(hotkey-map):not(.visbug-metatip):not(visbug-label):not(visbug-handles)');
    if (!matches.length) matches = querySelectorAllDeep(query);
    if (!fn) SelectorEngine.unselect_all();
    if (matches.length)
      matches.forEach(el =>
        fn
          ? fn(el)
          : SelectorEngine.select(el));
  }
  catch (err) {}
}

const state = {
  distances:  [],
  target:     null,
};

function createMeasurements({$anchor, $target}) {
  if (state.target == $target && state.distances.length) return
  else state.target = $target;

  if (state.distances.length) clearMeasurements();

  const anchorBounds = $anchor.getBoundingClientRect();
  const targetBounds = $target.getBoundingClientRect();

  const measurements = [];

  // right
  if (anchorBounds.right < targetBounds.left) {
    measurements.push({
      x: anchorBounds.right,
      y: anchorBounds.top + (anchorBounds.height / 2),
      d: targetBounds.left - anchorBounds.right,
      q: 'right',
    });
  }
  if (anchorBounds.right < targetBounds.right && anchorBounds.right > targetBounds.left) {
    measurements.push({
      x: anchorBounds.right,
      y: anchorBounds.top + (anchorBounds.height / 2),
      d: targetBounds.right - anchorBounds.right,
      q: 'right',
    });
  }

  // left
  if (anchorBounds.left > targetBounds.right) {
    measurements.push({
      x: targetBounds.right,
      y: anchorBounds.top + (anchorBounds.height / 2),
      d: anchorBounds.left - targetBounds.right,
      q: 'left',
    });
  }
  if (anchorBounds.left > targetBounds.left && anchorBounds.left < targetBounds.right) {
    measurements.push({
      x: targetBounds.left,
      y: anchorBounds.top + (anchorBounds.height / 2),
      d: anchorBounds.left - targetBounds.left,
      q: 'left',
    });
  }

  // top
  if (anchorBounds.top > targetBounds.bottom) {
    measurements.push({
      x: anchorBounds.left + (anchorBounds.width / 2),
      y: targetBounds.bottom,
      d: anchorBounds.top - targetBounds.bottom,
      q: 'top',
      v: true,
    });
  }
  if (anchorBounds.top > targetBounds.top && anchorBounds.top < targetBounds.bottom) {
    measurements.push({
      x: anchorBounds.left + (anchorBounds.width / 2),
      y: targetBounds.top,
      d: anchorBounds.top - targetBounds.top,
      q: 'top',
      v: true,
    });
  }

  // bottom
  if (anchorBounds.bottom < targetBounds.top) {
    measurements.push({
      x: anchorBounds.left + (anchorBounds.width / 2),
      y: anchorBounds.bottom,
      d: targetBounds.top - anchorBounds.bottom,
      q: 'bottom',
      v: true,
    });
  }
  if (anchorBounds.bottom < targetBounds.bottom && anchorBounds.bottom > targetBounds.top) {
    measurements.push({
      x: anchorBounds.left + (anchorBounds.width / 2),
      y: anchorBounds.bottom,
      d: targetBounds.bottom - anchorBounds.bottom,
      q: 'bottom',
      v: true,
    });
  }

  // inside left/right
  if (anchorBounds.right > targetBounds.right && anchorBounds.left < targetBounds.left) {
    measurements.push({
      x: targetBounds.right,
      y: anchorBounds.top + (anchorBounds.height / 2),
      d: anchorBounds.right - targetBounds.right,
      q: 'left',
    });
    measurements.push({
      x: anchorBounds.left,
      y: anchorBounds.top + (anchorBounds.height / 2),
      d: targetBounds.left - anchorBounds.left,
      q: 'right',
    });
  }

  // inside top/right
  if (anchorBounds.top < targetBounds.top && anchorBounds.bottom > targetBounds.bottom) {
    measurements.push({
      x: anchorBounds.left + (anchorBounds.width / 2),
      y: anchorBounds.top,
      d: targetBounds.top - anchorBounds.top,
      q: 'bottom',
      v: true,
    });
    measurements.push({
      x: anchorBounds.left + (anchorBounds.width / 2),
      y: targetBounds.bottom,
      d: anchorBounds.bottom - targetBounds.bottom,
      q: 'top',
      v: true,
    });
  }

  // create custom elements for all created measurements
  measurements
    .map(measurement => Object.assign(measurement, {
      d: Math.round(measurement.d.toFixed(1) * 100) / 100
    }))
    .forEach(measurement => {
      const $measurement = document.createElement('visbug-distance');

      $measurement.position = {
        line_model:     measurement,
        node_label_id:  state.distances.length,
      };

      document.body.appendChild($measurement);
      state.distances[state.distances.length] = $measurement;
    });
}

function clearMeasurements() {
  state.distances.forEach(node => node.remove());
  state.distances = [];
}

/**
 * Take input from [0, n] and return it as [0, 1]
 * @hidden
 */
function bound01(n, max) {
    if (isOnePointZero(n)) {
        n = '100%';
    }
    const processPercent = isPercentage(n);
    n = max === 360 ? n : Math.min(max, Math.max(0, parseFloat(n)));
    // Automatically convert percentage into number
    if (processPercent) {
        n = parseInt(String(n * max), 10) / 100;
    }
    // Handle floating point rounding errors
    if (Math.abs(n - max) < 0.000001) {
        return 1;
    }
    // Convert into [0, 1] range if it isn't already
    if (max === 360) {
        // If n is a hue given in degrees,
        // wrap around out-of-range values into [0, 360] range
        // then convert into [0, 1].
        n = (n < 0 ? n % max + max : n % max) / parseFloat(String(max));
    }
    else {
        // If n not a hue given in degrees
        // Convert into [0, 1] range if it isn't already.
        n = (n % max) / parseFloat(String(max));
    }
    return n;
}
/**
 * Force a number between 0 and 1
 * @hidden
 */
function clamp01(val) {
    return Math.min(1, Math.max(0, val));
}
/**
 * Need to handle 1.0 as 100%, since once it is a number, there is no difference between it and 1
 * <http://stackoverflow.com/questions/7422072/javascript-how-to-detect-number-as-a-decimal-including-1-0>
 * @hidden
 */
function isOnePointZero(n) {
    return typeof n === 'string' && n.indexOf('.') !== -1 && parseFloat(n) === 1;
}
/**
 * Check to see if string passed in is a percentage
 * @hidden
 */
function isPercentage(n) {
    return typeof n === 'string' && n.indexOf('%') !== -1;
}
/**
 * Return a valid alpha value [0,1] with all invalid values being set to 1
 * @hidden
 */
function boundAlpha(a) {
    a = parseFloat(a);
    if (isNaN(a) || a < 0 || a > 1) {
        a = 1;
    }
    return a;
}
/**
 * Replace a decimal with it's percentage value
 * @hidden
 */
function convertToPercentage(n) {
    if (n <= 1) {
        return +n * 100 + '%';
    }
    return n;
}
/**
 * Force a hex value to have 2 characters
 * @hidden
 */
function pad2(c) {
    return c.length === 1 ? '0' + c : '' + c;
}

// `rgbToHsl`, `rgbToHsv`, `hslToRgb`, `hsvToRgb` modified from:
// <http://mjijackson.com/2008/02/rgb-to-hsl-and-rgb-to-hsv-color-model-conversion-algorithms-in-javascript>
/**
 * Handle bounds / percentage checking to conform to CSS color spec
 * <http://www.w3.org/TR/css3-color/>
 * *Assumes:* r, g, b in [0, 255] or [0, 1]
 * *Returns:* { r, g, b } in [0, 255]
 */
function rgbToRgb(r, g, b) {
    return {
        r: bound01(r, 255) * 255,
        g: bound01(g, 255) * 255,
        b: bound01(b, 255) * 255,
    };
}
/**
 * Converts an RGB color value to HSL.
 * *Assumes:* r, g, and b are contained in [0, 255] or [0, 1]
 * *Returns:* { h, s, l } in [0,1]
 */
function rgbToHsl(r, g, b) {
    r = bound01(r, 255);
    g = bound01(g, 255);
    b = bound01(b, 255);
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0;
    let s = 0;
    const l = (max + min) / 2;
    if (max === min) {
        h = s = 0; // achromatic
    }
    else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r:
                h = (g - b) / d + (g < b ? 6 : 0);
                break;
            case g:
                h = (b - r) / d + 2;
                break;
            case b:
                h = (r - g) / d + 4;
                break;
        }
        h /= 6;
    }
    return { h, s, l };
}
/**
 * Converts an HSL color value to RGB.
 *
 * *Assumes:* h is contained in [0, 1] or [0, 360] and s and l are contained [0, 1] or [0, 100]
 * *Returns:* { r, g, b } in the set [0, 255]
 */
function hslToRgb(h, s, l) {
    let r;
    let g;
    let b;
    h = bound01(h, 360);
    s = bound01(s, 100);
    l = bound01(l, 100);
    function hue2rgb(p, q, t) {
        if (t < 0)
            t += 1;
        if (t > 1)
            t -= 1;
        if (t < 1 / 6) {
            return p + (q - p) * 6 * t;
        }
        if (t < 1 / 2) {
            return q;
        }
        if (t < 2 / 3) {
            return p + (q - p) * (2 / 3 - t) * 6;
        }
        return p;
    }
    if (s === 0) {
        r = g = b = l; // achromatic
    }
    else {
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        r = hue2rgb(p, q, h + 1 / 3);
        g = hue2rgb(p, q, h);
        b = hue2rgb(p, q, h - 1 / 3);
    }
    return { r: r * 255, g: g * 255, b: b * 255 };
}
/**
 * Converts an RGB color value to HSV
 *
 * *Assumes:* r, g, and b are contained in the set [0, 255] or [0, 1]
 * *Returns:* { h, s, v } in [0,1]
 */
function rgbToHsv(r, g, b) {
    r = bound01(r, 255);
    g = bound01(g, 255);
    b = bound01(b, 255);
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0;
    const v = max;
    const d = max - min;
    const s = max === 0 ? 0 : d / max;
    if (max === min) {
        h = 0; // achromatic
    }
    else {
        switch (max) {
            case r:
                h = (g - b) / d + (g < b ? 6 : 0);
                break;
            case g:
                h = (b - r) / d + 2;
                break;
            case b:
                h = (r - g) / d + 4;
                break;
        }
        h /= 6;
    }
    return { h: h, s: s, v: v };
}
/**
 * Converts an HSV color value to RGB.
 *
 * *Assumes:* h is contained in [0, 1] or [0, 360] and s and v are contained in [0, 1] or [0, 100]
 * *Returns:* { r, g, b } in the set [0, 255]
 */
function hsvToRgb(h, s, v) {
    h = bound01(h, 360) * 6;
    s = bound01(s, 100);
    v = bound01(v, 100);
    const i = Math.floor(h);
    const f = h - i;
    const p = v * (1 - s);
    const q = v * (1 - f * s);
    const t = v * (1 - (1 - f) * s);
    const mod = i % 6;
    const r = [v, q, p, p, t, v][mod];
    const g = [t, v, v, q, p, p][mod];
    const b = [p, p, t, v, v, q][mod];
    return { r: r * 255, g: g * 255, b: b * 255 };
}
/**
 * Converts an RGB color to hex
 *
 * Assumes r, g, and b are contained in the set [0, 255]
 * Returns a 3 or 6 character hex
 */
function rgbToHex(r, g, b, allow3Char) {
    const hex = [
        pad2(Math.round(r).toString(16)),
        pad2(Math.round(g).toString(16)),
        pad2(Math.round(b).toString(16)),
    ];
    // Return a 3 character hex if possible
    if (allow3Char &&
        hex[0].charAt(0) === hex[0].charAt(1) &&
        hex[1].charAt(0) === hex[1].charAt(1) &&
        hex[2].charAt(0) === hex[2].charAt(1)) {
        return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0);
    }
    return hex.join('');
}
/**
 * Converts an RGBA color plus alpha transparency to hex
 *
 * Assumes r, g, b are contained in the set [0, 255] and
 * a in [0, 1]. Returns a 4 or 8 character rgba hex
 */
function rgbaToHex(r, g, b, a, allow4Char) {
    const hex = [
        pad2(Math.round(r).toString(16)),
        pad2(Math.round(g).toString(16)),
        pad2(Math.round(b).toString(16)),
        pad2(convertDecimalToHex(a)),
    ];
    // Return a 4 character hex if possible
    if (allow4Char &&
        hex[0].charAt(0) === hex[0].charAt(1) &&
        hex[1].charAt(0) === hex[1].charAt(1) &&
        hex[2].charAt(0) === hex[2].charAt(1) &&
        hex[3].charAt(0) === hex[3].charAt(1)) {
        return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0) + hex[3].charAt(0);
    }
    return hex.join('');
}
/** Converts a decimal to a hex value */
function convertDecimalToHex(d) {
    return Math.round(parseFloat(d) * 255).toString(16);
}
/** Converts a hex value to a decimal */
function convertHexToDecimal(h) {
    return parseIntFromHex(h) / 255;
}
/** Parse a base-16 hex value into a base-10 integer */
function parseIntFromHex(val) {
    return parseInt(val, 16);
}

// https://github.com/bahamas10/css-color-names/blob/master/css-color-names.json
/**
 * @hidden
 */
const names = {
    aliceblue: '#f0f8ff',
    antiquewhite: '#faebd7',
    aqua: '#00ffff',
    aquamarine: '#7fffd4',
    azure: '#f0ffff',
    beige: '#f5f5dc',
    bisque: '#ffe4c4',
    black: '#000000',
    blanchedalmond: '#ffebcd',
    blue: '#0000ff',
    blueviolet: '#8a2be2',
    brown: '#a52a2a',
    burlywood: '#deb887',
    cadetblue: '#5f9ea0',
    chartreuse: '#7fff00',
    chocolate: '#d2691e',
    coral: '#ff7f50',
    cornflowerblue: '#6495ed',
    cornsilk: '#fff8dc',
    crimson: '#dc143c',
    cyan: '#00ffff',
    darkblue: '#00008b',
    darkcyan: '#008b8b',
    darkgoldenrod: '#b8860b',
    darkgray: '#a9a9a9',
    darkgreen: '#006400',
    darkgrey: '#a9a9a9',
    darkkhaki: '#bdb76b',
    darkmagenta: '#8b008b',
    darkolivegreen: '#556b2f',
    darkorange: '#ff8c00',
    darkorchid: '#9932cc',
    darkred: '#8b0000',
    darksalmon: '#e9967a',
    darkseagreen: '#8fbc8f',
    darkslateblue: '#483d8b',
    darkslategray: '#2f4f4f',
    darkslategrey: '#2f4f4f',
    darkturquoise: '#00ced1',
    darkviolet: '#9400d3',
    deeppink: '#ff1493',
    deepskyblue: '#00bfff',
    dimgray: '#696969',
    dimgrey: '#696969',
    dodgerblue: '#1e90ff',
    firebrick: '#b22222',
    floralwhite: '#fffaf0',
    forestgreen: '#228b22',
    fuchsia: '#ff00ff',
    gainsboro: '#dcdcdc',
    ghostwhite: '#f8f8ff',
    gold: '#ffd700',
    goldenrod: '#daa520',
    gray: '#808080',
    green: '#008000',
    greenyellow: '#adff2f',
    grey: '#808080',
    honeydew: '#f0fff0',
    hotpink: '#ff69b4',
    indianred: '#cd5c5c',
    indigo: '#4b0082',
    ivory: '#fffff0',
    khaki: '#f0e68c',
    lavender: '#e6e6fa',
    lavenderblush: '#fff0f5',
    lawngreen: '#7cfc00',
    lemonchiffon: '#fffacd',
    lightblue: '#add8e6',
    lightcoral: '#f08080',
    lightcyan: '#e0ffff',
    lightgoldenrodyellow: '#fafad2',
    lightgray: '#d3d3d3',
    lightgreen: '#90ee90',
    lightgrey: '#d3d3d3',
    lightpink: '#ffb6c1',
    lightsalmon: '#ffa07a',
    lightseagreen: '#20b2aa',
    lightskyblue: '#87cefa',
    lightslategray: '#778899',
    lightslategrey: '#778899',
    lightsteelblue: '#b0c4de',
    lightyellow: '#ffffe0',
    lime: '#00ff00',
    limegreen: '#32cd32',
    linen: '#faf0e6',
    magenta: '#ff00ff',
    maroon: '#800000',
    mediumaquamarine: '#66cdaa',
    mediumblue: '#0000cd',
    mediumorchid: '#ba55d3',
    mediumpurple: '#9370db',
    mediumseagreen: '#3cb371',
    mediumslateblue: '#7b68ee',
    mediumspringgreen: '#00fa9a',
    mediumturquoise: '#48d1cc',
    mediumvioletred: '#c71585',
    midnightblue: '#191970',
    mintcream: '#f5fffa',
    mistyrose: '#ffe4e1',
    moccasin: '#ffe4b5',
    navajowhite: '#ffdead',
    navy: '#000080',
    oldlace: '#fdf5e6',
    olive: '#808000',
    olivedrab: '#6b8e23',
    orange: '#ffa500',
    orangered: '#ff4500',
    orchid: '#da70d6',
    palegoldenrod: '#eee8aa',
    palegreen: '#98fb98',
    paleturquoise: '#afeeee',
    palevioletred: '#db7093',
    papayawhip: '#ffefd5',
    peachpuff: '#ffdab9',
    peru: '#cd853f',
    pink: '#ffc0cb',
    plum: '#dda0dd',
    powderblue: '#b0e0e6',
    purple: '#800080',
    rebeccapurple: '#663399',
    red: '#ff0000',
    rosybrown: '#bc8f8f',
    royalblue: '#4169e1',
    saddlebrown: '#8b4513',
    salmon: '#fa8072',
    sandybrown: '#f4a460',
    seagreen: '#2e8b57',
    seashell: '#fff5ee',
    sienna: '#a0522d',
    silver: '#c0c0c0',
    skyblue: '#87ceeb',
    slateblue: '#6a5acd',
    slategray: '#708090',
    slategrey: '#708090',
    snow: '#fffafa',
    springgreen: '#00ff7f',
    steelblue: '#4682b4',
    tan: '#d2b48c',
    teal: '#008080',
    thistle: '#d8bfd8',
    tomato: '#ff6347',
    turquoise: '#40e0d0',
    violet: '#ee82ee',
    wheat: '#f5deb3',
    white: '#ffffff',
    whitesmoke: '#f5f5f5',
    yellow: '#ffff00',
    yellowgreen: '#9acd32',
};

/**
 * Given a string or object, convert that input to RGB
 *
 * Possible string inputs:
 * ```
 * "red"
 * "#f00" or "f00"
 * "#ff0000" or "ff0000"
 * "#ff000000" or "ff000000"
 * "rgb 255 0 0" or "rgb (255, 0, 0)"
 * "rgb 1.0 0 0" or "rgb (1, 0, 0)"
 * "rgba (255, 0, 0, 1)" or "rgba 255, 0, 0, 1"
 * "rgba (1.0, 0, 0, 1)" or "rgba 1.0, 0, 0, 1"
 * "hsl(0, 100%, 50%)" or "hsl 0 100% 50%"
 * "hsla(0, 100%, 50%, 1)" or "hsla 0 100% 50%, 1"
 * "hsv(0, 100%, 100%)" or "hsv 0 100% 100%"
 * ```
 */
function inputToRGB(color) {
    let rgb = { r: 0, g: 0, b: 0 };
    let a = 1;
    let s = null;
    let v = null;
    let l = null;
    let ok = false;
    let format = false;
    if (typeof color === 'string') {
        color = stringInputToObject(color);
    }
    if (typeof color === 'object') {
        if (isValidCSSUnit(color.r) && isValidCSSUnit(color.g) && isValidCSSUnit(color.b)) {
            rgb = rgbToRgb(color.r, color.g, color.b);
            ok = true;
            format = String(color.r).substr(-1) === '%' ? 'prgb' : 'rgb';
        }
        else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.v)) {
            s = convertToPercentage(color.s);
            v = convertToPercentage(color.v);
            rgb = hsvToRgb(color.h, s, v);
            ok = true;
            format = 'hsv';
        }
        else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.l)) {
            s = convertToPercentage(color.s);
            l = convertToPercentage(color.l);
            rgb = hslToRgb(color.h, s, l);
            ok = true;
            format = 'hsl';
        }
        if (color.hasOwnProperty('a')) {
            a = color.a;
        }
    }
    a = boundAlpha(a);
    return {
        ok,
        format: color.format || format,
        r: Math.min(255, Math.max(rgb.r, 0)),
        g: Math.min(255, Math.max(rgb.g, 0)),
        b: Math.min(255, Math.max(rgb.b, 0)),
        a,
    };
}
// <http://www.w3.org/TR/css3-values/#integers>
const CSS_INTEGER = '[-\\+]?\\d+%?';
// <http://www.w3.org/TR/css3-values/#number-value>
const CSS_NUMBER = '[-\\+]?\\d*\\.\\d+%?';
// Allow positive/negative integer/number.  Don't capture the either/or, just the entire outcome.
const CSS_UNIT = `(?:${CSS_NUMBER})|(?:${CSS_INTEGER})`;
// Actual matching.
// Parentheses and commas are optional, but not required.
// Whitespace can take the place of commas or opening paren
const PERMISSIVE_MATCH3 = `[\\s|\\(]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})\\s*\\)?`;
const PERMISSIVE_MATCH4 = `[\\s|\\(]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})\\s*\\)?`;
const matchers = {
    CSS_UNIT: new RegExp(CSS_UNIT),
    rgb: new RegExp('rgb' + PERMISSIVE_MATCH3),
    rgba: new RegExp('rgba' + PERMISSIVE_MATCH4),
    hsl: new RegExp('hsl' + PERMISSIVE_MATCH3),
    hsla: new RegExp('hsla' + PERMISSIVE_MATCH4),
    hsv: new RegExp('hsv' + PERMISSIVE_MATCH3),
    hsva: new RegExp('hsva' + PERMISSIVE_MATCH4),
    hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
    hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
};
/**
 * Permissive string parsing.  Take in a number of formats, and output an object
 * based on detected format.  Returns `{ r, g, b }` or `{ h, s, l }` or `{ h, s, v}`
 */
function stringInputToObject(color) {
    color = color.trim().toLowerCase();
    if (color.length === 0) {
        return false;
    }
    let named = false;
    if (names[color]) {
        color = names[color];
        named = true;
    }
    else if (color === 'transparent') {
        return { r: 0, g: 0, b: 0, a: 0, format: 'name' };
    }
    // Try to match string input using regular expressions.
    // Keep most of the number bounding out of this function - don't worry about [0,1] or [0,100] or [0,360]
    // Just return an object and let the conversion functions handle that.
    // This way the result will be the same whether the tinycolor is initialized with string or object.
    let match = matchers.rgb.exec(color);
    if (match) {
        return { r: match[1], g: match[2], b: match[3] };
    }
    match = matchers.rgba.exec(color);
    if (match) {
        return { r: match[1], g: match[2], b: match[3], a: match[4] };
    }
    match = matchers.hsl.exec(color);
    if (match) {
        return { h: match[1], s: match[2], l: match[3] };
    }
    match = matchers.hsla.exec(color);
    if (match) {
        return { h: match[1], s: match[2], l: match[3], a: match[4] };
    }
    match = matchers.hsv.exec(color);
    if (match) {
        return { h: match[1], s: match[2], v: match[3] };
    }
    match = matchers.hsva.exec(color);
    if (match) {
        return { h: match[1], s: match[2], v: match[3], a: match[4] };
    }
    match = matchers.hex8.exec(color);
    if (match) {
        return {
            r: parseIntFromHex(match[1]),
            g: parseIntFromHex(match[2]),
            b: parseIntFromHex(match[3]),
            a: convertHexToDecimal(match[4]),
            format: named ? 'name' : 'hex8',
        };
    }
    match = matchers.hex6.exec(color);
    if (match) {
        return {
            r: parseIntFromHex(match[1]),
            g: parseIntFromHex(match[2]),
            b: parseIntFromHex(match[3]),
            format: named ? 'name' : 'hex',
        };
    }
    match = matchers.hex4.exec(color);
    if (match) {
        return {
            r: parseIntFromHex(match[1] + match[1]),
            g: parseIntFromHex(match[2] + match[2]),
            b: parseIntFromHex(match[3] + match[3]),
            a: convertHexToDecimal(match[4] + match[4]),
            format: named ? 'name' : 'hex8',
        };
    }
    match = matchers.hex3.exec(color);
    if (match) {
        return {
            r: parseIntFromHex(match[1] + match[1]),
            g: parseIntFromHex(match[2] + match[2]),
            b: parseIntFromHex(match[3] + match[3]),
            format: named ? 'name' : 'hex',
        };
    }
    return false;
}
/**
 * Check to see if it looks like a CSS unit
 * (see `matchers` above for definition).
 */
function isValidCSSUnit(color) {
    return !!matchers.CSS_UNIT.exec(String(color));
}

class TinyColor {
    constructor(color = '', opts = {}) {
        // If input is already a tinycolor, return itself
        if (color instanceof TinyColor) {
            return color;
        }
        this.originalInput = color;
        const rgb = inputToRGB(color);
        this.originalInput = color;
        this.r = rgb.r;
        this.g = rgb.g;
        this.b = rgb.b;
        this.a = rgb.a;
        this.roundA = Math.round(100 * this.a) / 100;
        this.format = opts.format || rgb.format;
        this.gradientType = opts.gradientType;
        // Don't let the range of [0,255] come back in [0,1].
        // Potentially lose a little bit of precision here, but will fix issues where
        // .5 gets interpreted as half of the total, instead of half of 1
        // If it was supposed to be 128, this was already taken care of by `inputToRgb`
        if (this.r < 1) {
            this.r = Math.round(this.r);
        }
        if (this.g < 1) {
            this.g = Math.round(this.g);
        }
        if (this.b < 1) {
            this.b = Math.round(this.b);
        }
        this.isValid = rgb.ok;
    }
    isDark() {
        return this.getBrightness() < 128;
    }
    isLight() {
        return !this.isDark();
    }
    /**
     * Returns the perceived brightness of the color, from 0-255.
     */
    getBrightness() {
        // http://www.w3.org/TR/AERT#color-contrast
        const rgb = this.toRgb();
        return (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1000;
    }
    /**
     * Returns the perceived luminance of a color, from 0-1.
     */
    getLuminance() {
        // http://www.w3.org/TR/2008/REC-WCAG20-20081211/#relativeluminancedef
        const rgb = this.toRgb();
        let R;
        let G;
        let B;
        const RsRGB = rgb.r / 255;
        const GsRGB = rgb.g / 255;
        const BsRGB = rgb.b / 255;
        if (RsRGB <= 0.03928) {
            R = RsRGB / 12.92;
        }
        else {
            R = Math.pow((RsRGB + 0.055) / 1.055, 2.4);
        }
        if (GsRGB <= 0.03928) {
            G = GsRGB / 12.92;
        }
        else {
            G = Math.pow((GsRGB + 0.055) / 1.055, 2.4);
        }
        if (BsRGB <= 0.03928) {
            B = BsRGB / 12.92;
        }
        else {
            B = Math.pow((BsRGB + 0.055) / 1.055, 2.4);
        }
        return 0.2126 * R + 0.7152 * G + 0.0722 * B;
    }
    /**
     * Sets the alpha value on the current color.
     *
     * @param alpha - The new alpha value. The accepted range is 0-1.
     */
    setAlpha(alpha) {
        this.a = boundAlpha(alpha);
        this.roundA = Math.round(100 * this.a) / 100;
        return this;
    }
    /**
     * Returns the object as a HSVA object.
     */
    toHsv() {
        const hsv = rgbToHsv(this.r, this.g, this.b);
        return { h: hsv.h * 360, s: hsv.s, v: hsv.v, a: this.a };
    }
    /**
     * Returns the hsva values interpolated into a string with the following format:
     * "hsva(xxx, xxx, xxx, xx)".
     */
    toHsvString() {
        const hsv = rgbToHsv(this.r, this.g, this.b);
        const h = Math.round(hsv.h * 360);
        const s = Math.round(hsv.s * 100);
        const v = Math.round(hsv.v * 100);
        return this.a === 1 ? `hsv(${h}, ${s}%, ${v}%)` : `hsva(${h}, ${s}%, ${v}%, ${this.roundA})`;
    }
    /**
     * Returns the object as a HSLA object.
     */
    toHsl() {
        const hsl = rgbToHsl(this.r, this.g, this.b);
        return { h: hsl.h * 360, s: hsl.s, l: hsl.l, a: this.a };
    }
    /**
     * Returns the hsla values interpolated into a string with the following format:
     * "hsla(xxx, xxx, xxx, xx)".
     */
    toHslString() {
        const hsl = rgbToHsl(this.r, this.g, this.b);
        const h = Math.round(hsl.h * 360);
        const s = Math.round(hsl.s * 100);
        const l = Math.round(hsl.l * 100);
        return this.a === 1 ? `hsl(${h}, ${s}%, ${l}%)` : `hsla(${h}, ${s}%, ${l}%, ${this.roundA})`;
    }
    /**
     * Returns the hex value of the color.
     * @param allow3Char will shorten hex value to 3 char if possible
     */
    toHex(allow3Char = false) {
        return rgbToHex(this.r, this.g, this.b, allow3Char);
    }
    /**
     * Returns the hex value of the color -with a # appened.
     * @param allow3Char will shorten hex value to 3 char if possible
     */
    toHexString(allow3Char = false) {
        return '#' + this.toHex(allow3Char);
    }
    /**
     * Returns the hex 8 value of the color.
     * @param allow4Char will shorten hex value to 4 char if possible
     */
    toHex8(allow4Char = false) {
        return rgbaToHex(this.r, this.g, this.b, this.a, allow4Char);
    }
    /**
     * Returns the hex 8 value of the color -with a # appened.
     * @param allow4Char will shorten hex value to 4 char if possible
     */
    toHex8String(allow4Char = false) {
        return '#' + this.toHex8(allow4Char);
    }
    /**
     * Returns the object as a RGBA object.
     */
    toRgb() {
        return {
            r: Math.round(this.r),
            g: Math.round(this.g),
            b: Math.round(this.b),
            a: this.a,
        };
    }
    /**
     * Returns the RGBA values interpolated into a string with the following format:
     * "RGBA(xxx, xxx, xxx, xx)".
     */
    toRgbString() {
        const r = Math.round(this.r);
        const g = Math.round(this.g);
        const b = Math.round(this.b);
        return this.a === 1 ? `rgb(${r}, ${g}, ${b})` : `rgba(${r}, ${g}, ${b}, ${this.roundA})`;
    }
    /**
     * Returns the object as a RGBA object.
     */
    toPercentageRgb() {
        const fmt = (x) => Math.round(bound01(x, 255) * 100) + '%';
        return {
            r: fmt(this.r),
            g: fmt(this.g),
            b: fmt(this.b),
            a: this.a,
        };
    }
    /**
     * Returns the RGBA relative values interpolated into a string
     */
    toPercentageRgbString() {
        const rnd = (x) => Math.round(bound01(x, 255) * 100);
        return this.a === 1
            ? `rgb(${rnd(this.r)}%, ${rnd(this.g)}%, ${rnd(this.b)}%)`
            : `rgba(${rnd(this.r)}%, ${rnd(this.g)}%, ${rnd(this.b)}%, ${this.roundA})`;
    }
    /**
     * The 'real' name of the color -if there is one.
     */
    toName() {
        if (this.a === 0) {
            return 'transparent';
        }
        if (this.a < 1) {
            return false;
        }
        const hex = '#' + rgbToHex(this.r, this.g, this.b, false);
        for (const key of Object.keys(names)) {
            if (names[key] === hex) {
                return key;
            }
        }
        return false;
    }
    /**
     * String representation of the color.
     *
     * @param format - The format to be used when displaying the string representation.
     */
    toString(format) {
        const formatSet = !!format;
        format = format || this.format;
        let formattedString = false;
        const hasAlpha = this.a < 1 && this.a >= 0;
        const needsAlphaFormat = !formatSet && hasAlpha && (format.startsWith('hex') || format === 'name');
        if (needsAlphaFormat) {
            // Special case for "transparent", all other non-alpha formats
            // will return rgba when there is transparency.
            if (format === 'name' && this.a === 0) {
                return this.toName();
            }
            return this.toRgbString();
        }
        if (format === 'rgb') {
            formattedString = this.toRgbString();
        }
        if (format === 'prgb') {
            formattedString = this.toPercentageRgbString();
        }
        if (format === 'hex' || format === 'hex6') {
            formattedString = this.toHexString();
        }
        if (format === 'hex3') {
            formattedString = this.toHexString(true);
        }
        if (format === 'hex4') {
            formattedString = this.toHex8String(true);
        }
        if (format === 'hex8') {
            formattedString = this.toHex8String();
        }
        if (format === 'name') {
            formattedString = this.toName();
        }
        if (format === 'hsl') {
            formattedString = this.toHslString();
        }
        if (format === 'hsv') {
            formattedString = this.toHsvString();
        }
        return formattedString || this.toHexString();
    }
    clone() {
        return new TinyColor(this.toString());
    }
    /**
     * Lighten the color a given amount. Providing 100 will always return white.
     * @param amount - valid between 1-100
     */
    lighten(amount = 10) {
        const hsl = this.toHsl();
        hsl.l += amount / 100;
        hsl.l = clamp01(hsl.l);
        return new TinyColor(hsl);
    }
    /**
     * Brighten the color a given amount, from 0 to 100.
     * @param amount - valid between 1-100
     */
    brighten(amount = 10) {
        const rgb = this.toRgb();
        rgb.r = Math.max(0, Math.min(255, rgb.r - Math.round(255 * -(amount / 100))));
        rgb.g = Math.max(0, Math.min(255, rgb.g - Math.round(255 * -(amount / 100))));
        rgb.b = Math.max(0, Math.min(255, rgb.b - Math.round(255 * -(amount / 100))));
        return new TinyColor(rgb);
    }
    /**
     * Darken the color a given amount, from 0 to 100.
     * Providing 100 will always return black.
     * @param amount - valid between 1-100
     */
    darken(amount = 10) {
        const hsl = this.toHsl();
        hsl.l -= amount / 100;
        hsl.l = clamp01(hsl.l);
        return new TinyColor(hsl);
    }
    /**
     * Mix the color with pure white, from 0 to 100.
     * Providing 0 will do nothing, providing 100 will always return white.
     * @param amount - valid between 1-100
     */
    tint(amount = 10) {
        return this.mix('white', amount);
    }
    /**
     * Mix the color with pure black, from 0 to 100.
     * Providing 0 will do nothing, providing 100 will always return black.
     * @param amount - valid between 1-100
     */
    shade(amount = 10) {
        return this.mix('black', amount);
    }
    /**
     * Desaturate the color a given amount, from 0 to 100.
     * Providing 100 will is the same as calling greyscale
     * @param amount - valid between 1-100
     */
    desaturate(amount = 10) {
        const hsl = this.toHsl();
        hsl.s -= amount / 100;
        hsl.s = clamp01(hsl.s);
        return new TinyColor(hsl);
    }
    /**
     * Saturate the color a given amount, from 0 to 100.
     * @param amount - valid between 1-100
     */
    saturate(amount = 10) {
        const hsl = this.toHsl();
        hsl.s += amount / 100;
        hsl.s = clamp01(hsl.s);
        return new TinyColor(hsl);
    }
    /**
     * Completely desaturates a color into greyscale.
     * Same as calling `desaturate(100)`
     */
    greyscale() {
        return this.desaturate(100);
    }
    /**
     * Spin takes a positive or negative amount within [-360, 360] indicating the change of hue.
     * Values outside of this range will be wrapped into this range.
     */
    spin(amount) {
        const hsl = this.toHsl();
        const hue = (hsl.h + amount) % 360;
        hsl.h = hue < 0 ? 360 + hue : hue;
        return new TinyColor(hsl);
    }
    mix(color, amount = 50) {
        const rgb1 = this.toRgb();
        const rgb2 = new TinyColor(color).toRgb();
        const p = amount / 100;
        const rgba = {
            r: (rgb2.r - rgb1.r) * p + rgb1.r,
            g: (rgb2.g - rgb1.g) * p + rgb1.g,
            b: (rgb2.b - rgb1.b) * p + rgb1.b,
            a: (rgb2.a - rgb1.a) * p + rgb1.a,
        };
        return new TinyColor(rgba);
    }
    analogous(results = 6, slices = 30) {
        const hsl = this.toHsl();
        const part = 360 / slices;
        const ret = [this];
        for (hsl.h = (hsl.h - ((part * results) >> 1) + 720) % 360; --results;) {
            hsl.h = (hsl.h + part) % 360;
            ret.push(new TinyColor(hsl));
        }
        return ret;
    }
    /**
     * taken from https://github.com/infusion/jQuery-xcolor/blob/master/jquery.xcolor.js
     */
    complement() {
        const hsl = this.toHsl();
        hsl.h = (hsl.h + 180) % 360;
        return new TinyColor(hsl);
    }
    monochromatic(results = 6) {
        const hsv = this.toHsv();
        const h = hsv.h;
        const s = hsv.s;
        let v = hsv.v;
        const res = [];
        const modification = 1 / results;
        while (results--) {
            res.push(new TinyColor({ h, s, v }));
            v = (v + modification) % 1;
        }
        return res;
    }
    splitcomplement() {
        const hsl = this.toHsl();
        const h = hsl.h;
        return [
            this,
            new TinyColor({ h: (h + 72) % 360, s: hsl.s, l: hsl.l }),
            new TinyColor({ h: (h + 216) % 360, s: hsl.s, l: hsl.l }),
        ];
    }
    triad() {
        return this.polyad(3);
    }
    tetrad() {
        return this.polyad(4);
    }
    /**
     * Get polyad colors, like (for 1, 2, 3, 4, 5, 6, 7, 8, etc...)
     * monad, dyad, triad, tetrad, pentad, hexad, heptad, octad, etc...
     */
    polyad(n) {
        const hsl = this.toHsl();
        const h = hsl.h;
        const result = [this];
        const increment = 360 / n;
        for (let i = 1; i < n; i++) {
            result.push(new TinyColor({ h: (h + i * increment) % 360, s: hsl.s, l: hsl.l }));
        }
        return result;
    }
    /**
     * compare color vs current color
     */
    equals(color) {
        return this.toRgbString() === new TinyColor(color).toRgbString();
    }
}

// Readability Functions
// ---------------------
// <http://www.w3.org/TR/2008/REC-WCAG20-20081211/#contrast-ratiodef (WCAG Version 2)
/**
 * AKA `contrast`
 *
 * Analyze the 2 colors and returns the color contrast defined by (WCAG Version 2)
 */
function readability(color1, color2) {
    const c1 = new TinyColor(color1);
    const c2 = new TinyColor(color2);
    return ((Math.max(c1.getLuminance(), c2.getLuminance()) + 0.05) /
        (Math.min(c1.getLuminance(), c2.getLuminance()) + 0.05));
}
/**
 * Ensure that foreground and background color combinations meet WCAG2 guidelines.
 * The third argument is an object.
 *      the 'level' property states 'AA' or 'AAA' - if missing or invalid, it defaults to 'AA';
 *      the 'size' property states 'large' or 'small' - if missing or invalid, it defaults to 'small'.
 * If the entire object is absent, isReadable defaults to {level:"AA",size:"small"}.
 *
 * Example
 * ```ts
 * new TinyColor().isReadable('#000', '#111') => false
 * new TinyColor().isReadable('#000', '#111', { level: 'AA', size: 'large' }) => false
 * ```
 */
function isReadable(color1, color2, wcag2 = { level: 'AA', size: 'small' }) {
    const readabilityLevel = readability(color1, color2);
    switch ((wcag2.level || 'AA') + (wcag2.size || 'small')) {
        case 'AAsmall':
        case 'AAAlarge':
            return readabilityLevel >= 4.5;
        case 'AAlarge':
            return readabilityLevel >= 3;
        case 'AAAsmall':
            return readabilityLevel >= 7;
    }
    return false;
}

const state$1 = {
  active: {
    tip:  null,
    target: null,
  },
  tips: new Map(),
};

const services = {};

function MetaTip({select}) {
  services.selectors = {select};

  $('body').on('mousemove', mouseMove);
  $('body').on('click', togglePinned);

  hotkeys('esc', _ => removeAll());

  restorePinnedTips();

  return () => {
    $('body').off('mousemove', mouseMove);
    $('body').off('click', togglePinned);
    hotkeys.unbind('esc');
    hideAll();
  }
}

const mouseMove = e => {
  const target = deepElementFromPoint(e.clientX, e.clientY);

  if (isOffBounds(target) || target.nodeName === 'VISBUG-METATIP' || target.hasAttribute('data-metatip')) { // aka: mouse out
    if (state$1.active.tip) {
      wipe({
        tip: state$1.active.tip,
        e: {target: state$1.active.target},
      });
      clearActive();
    }
    return
  }

  toggleTargetCursor(e.altKey, target);

  showTip(target, e);
};

function showTip(target, e) {
  if (!state$1.active.tip) { // create
    const tip = render(target);
    document.body.appendChild(tip);

    positionTip(tip, e);
    observe({tip, target});

    state$1.active.tip    = tip;
    state$1.active.target = target;
  }
  else if (target == state$1.active.target) { // update position
    // update position
    positionTip(state$1.active.tip, e);
  }
  else { // update content
    render(target, state$1.active.tip);
    state$1.active.target = target;
    positionTip(state$1.active.tip, e);
  }
}

function positionTip(tip, e) {
  const { north, west } = mouse_quadrant(e);
  const { left, top }   = tip_position(tip, e, north, west);

  tip.style.left  = left;
  tip.style.top   = top;

  tip.style.setProperty('--arrow', north
    ? 'var(--arrow-up)'
    : 'var(--arrow-down)');

  tip.style.setProperty('--shadow-direction', north
    ? 'var(--shadow-up)'
    : 'var(--shadow-down)');

  tip.style.setProperty('--arrow-top', !north
    ? '-7px'
    : 'calc(100% - 1px)');

  tip.style.setProperty('--arrow-left', west
    ? 'calc(100% - 15px - 15px)'
    : '15px');
}

const restorePinnedTips = () => {
  state$1.tips.forEach(({tip}, target) => {
    tip.style.display = 'block';
    render(target, tip);
    observe({tip, target});
  });
};

function hideAll() {
  state$1.tips.forEach(({tip}, target) =>
    tip.style.display = 'none');

  if (state$1.active.tip) {
    state$1.active.tip.remove();
    clearActive();
  }
}

function removeAll() {
  state$1.tips.forEach(({tip}, target) => {
    tip.remove();
    unobserve({tip, target});
  });

  $('[data-metatip]').attr('data-metatip', null);

  state$1.tips.clear();
}

const render = (el, tip = document.createElement('visbug-metatip')) => {
  const { width, height } = el.getBoundingClientRect();
  const styles = getStyles(el)
    .map(style => Object.assign(style, {
      prop: camelToDash(style.prop)
    }))
    .filter(style =>
      style.prop.includes('font-family')
        ? el.matches('h1,h2,h3,h4,h5,h6,p,a,date,caption,button,figcaption,nav,header,footer')
        : true
    )
    .map(style => {
      if (style.prop.includes('color') || style.prop.includes('Color') || style.prop.includes('fill') || style.prop.includes('stroke'))
        style.value = `<span color style="background-color:${style.value};"></span>${new TinyColor(style.value).toHslString()}`;

      if (style.prop.includes('font-family') && style.value.length > 25)
        style.value = style.value.slice(0,25) + '...';

      if (style.prop.includes('grid-template-areas'))
        style.value = style.value.replace(/" "/g, '"<br>"');

      if (style.prop.includes('background-image'))
        style.value = `<a target="_blank" href="${style.value.slice(style.value.indexOf('(') + 2, style.value.length - 2)}">${style.value.slice(0,25) + '...'}</a>`;

      // check if style is inline style, show indicator
      if (el.getAttribute('style') && el.getAttribute('style').includes(style.prop))
        style.value = `<span local-change>${style.value}</span>`;

      return style
    });

  const localModifications = styles.filter(style =>
    el.getAttribute('style') && el.getAttribute('style').includes(style.prop)
      ? 1
      : 0);

  const notLocalModifications = styles.filter(style =>
    el.getAttribute('style') && el.getAttribute('style').includes(style.prop)
      ? 0
      : 1);

  tip.meta = {
    el,
    width,
    height,
    localModifications,
    notLocalModifications,
  };

  return tip
};

const mouse_quadrant = e => ({
  north: e.clientY > window.innerHeight / 2,
  west:  e.clientX > window.innerWidth / 2
});

const tip_position = (node, e, north, west) => ({
  top: `${north
    ? e.pageY - node.clientHeight - 20
    : e.pageY + 25}px`,
  left: `${west
    ? e.pageX - node.clientWidth + 23
    : e.pageX - 21}px`,
});

const handleBlur = ({target}) => {
  if (!target.hasAttribute('data-metatip') && state$1.tips.has(target))
    wipe(state$1.tips.get(target));
};

const wipe = ({tip, e:{target}}) => {
  tip.remove();
  unobserve({tip, target});
  state$1.tips.delete(target);
};

const togglePinned = e => {
  const target = deepElementFromPoint(e.clientX, e.clientY);

  if (e.altKey && !target.hasAttribute('data-metatip')) {
    target.setAttribute('data-metatip', true);
    state$1.tips.set(target, {
      tip: state$1.active.tip,
      e,
    });
    clearActive();
  }
  else if (target.hasAttribute('data-metatip')) {
    target.removeAttribute('data-metatip');
    wipe(state$1.tips.get(target));
  }
};

const linkQueryClicked = ({detail:{ text, activator }}) => {
  if (!text) return

  queryPage('[data-pseudo-select]', el =>
    el.removeAttribute('data-pseudo-select'));

  queryPage(text + ':not([data-selected])', el =>
    activator === 'mouseenter'
      ? el.setAttribute('data-pseudo-select', true)
      : services.selectors.select(el));
};

const linkQueryHoverOut = e => {
  queryPage('[data-pseudo-select]', el =>
    el.removeAttribute('data-pseudo-select'));
};

const toggleTargetCursor = (key, target) =>
  key
    ? target.setAttribute('data-pinhover', true)
    : target.removeAttribute('data-pinhover');

const observe = ({tip, target}) => {
  $(tip).on('query', linkQueryClicked);
  $(tip).on('unquery', linkQueryHoverOut);
  $(target).on('DOMNodeRemoved', handleBlur);
};

const unobserve = ({tip, target}) => {
  $(tip).off('query', linkQueryClicked);
  $(tip).off('unquery', linkQueryHoverOut);
  $(target).off('DOMNodeRemoved', handleBlur);
};

const clearActive = () => {
  state$1.active.tip    = null;
  state$1.active.target = null;
};

const state$2 = {
  active: {
    tip:  null,
    target: null,
  },
  tips: new Map(),
};

function Accessibility() {
  $('body').on('mousemove', mouseMove$1);
  $('body').on('click', togglePinned$1);

  hotkeys('esc', _ => removeAll$1());

  restorePinnedTips$1();

  return () => {
    $('body').off('mousemove', mouseMove$1);
    $('body').off('click', togglePinned$1);
    hotkeys.unbind('esc');
    hideAll$1();
  }
}

const mouseMove$1 = e => {
  const target = deepElementFromPoint(e.clientX, e.clientY);

  if (isOffBounds(target) || target.nodeName === 'VISBUG-ALLYTIP' || target.hasAttribute('data-allytip')) { // aka: mouse out
    if (state$2.active.tip) {
      wipe$1({
        tip: state$2.active.tip,
        e: {target: state$2.active.target},
      });
      clearActive$1();
    }
    return
  }

  toggleTargetCursor$1(e.altKey, target);

  showTip$1(target, e);
};

function showTip$1(target, e) {
  if (!state$2.active.tip) { // create
    const tip = render$1(target);
    document.body.appendChild(tip);

    positionTip$1(tip, e);
    observe$1({tip, target});

    state$2.active.tip    = tip;
    state$2.active.target = target;
  }
  else if (target == state$2.active.target) { // update position
    // update position
    positionTip$1(state$2.active.tip, e);
  }
  else { // update content
    render$1(target, state$2.active.tip);
    state$2.active.target = target;
    positionTip$1(state$2.active.tip, e);
  }
}

function positionTip$1(tip, e) {
  const { north, west } = mouse_quadrant$1(e);
  const {left, top}     = tip_position$1(tip, e, north, west);

  tip.style.left  = left;
  tip.style.top   = top;

  tip.style.setProperty('--arrow', north
    ? 'var(--arrow-up)'
    : 'var(--arrow-down)');

  tip.style.setProperty('--shadow-direction', north
    ? 'var(--shadow-up)'
    : 'var(--shadow-down)');

  tip.style.setProperty('--arrow-top', !north
    ? '-7px'
    : 'calc(100% - 1px)');

  tip.style.setProperty('--arrow-left', west
    ? 'calc(100% - 15px - 15px)'
    : '15px');
}

const restorePinnedTips$1 = () => {
  state$2.tips.forEach(({tip}, target) => {
    tip.style.display = 'block';
    render$1(target, tip);
    observe$1({tip, target});
  });
};

function hideAll$1() {
  state$2.tips.forEach(({tip}, target) =>
    tip.style.display = 'none');

  if (state$2.active.tip) {
    state$2.active.tip.remove();
    clearActive$1();
  }
}

function removeAll$1() {
  state$2.tips.forEach(({tip}, target) => {
    tip.remove();
    unobserve$1({tip, target});
  });

  $('[data-allytip]').attr('data-allytip', null);

  state$2.tips.clear();
}

const render$1 = (el, tip = document.createElement('visbug-ally')) => {
  const contrast_results = determineColorContrast(el);
  const ally_attributes = getA11ys(el);

  ally_attributes.map(ally =>
    ally.prop.includes('alt')
      ? ally.value = `<span text>${ally.value}</span>`
      : ally);

  ally_attributes.map(ally =>
    ally.prop.includes('title')
      ? ally.value = `<span text longform>${ally.value}</span>`
      : ally);

  tip.meta = {
    el,
    ally_attributes,
    contrast_results,
  };

  return tip
};

const determineColorContrast = el => {
  // question: how to know if the current node is actually a black background?
  // question: is there an api for composited values?
  const text      = getStyle(el, 'color');
  const textSize  = getWCAG2TextSize(el);

  let background  = getComputedBackgroundColor(el);

  const [ aa_contrast, aaa_contrast ] = [
    isReadable(background, text, { level: "AA", size: textSize.toLowerCase() }),
    isReadable(background, text, { level: "AAA", size: textSize.toLowerCase() })
  ];

  return `
    <span prop>Color contrast</span>
    <span value contrast>
      <span style="
        background-color:${background};
        color:${text};
      ">${Math.floor(readability(background, text)  * 100) / 100}</span>
    </span>
    <span prop>› AA ${textSize}</span>
    <span value style="${aa_contrast ? 'color:green;' : 'color:red'}">${aa_contrast ? '✓' : '×'}</span>
    <span prop>› AAA ${textSize}</span>
    <span value style="${aaa_contrast ? 'color:green;' : 'color:red'}">${aaa_contrast ? '✓' : '×'}</span>
  `
};

const mouse_quadrant$1 = e => ({
  north: e.clientY > window.innerHeight / 2,
  west:  e.clientX > window.innerWidth / 2
});

const tip_position$1 = (node, e, north, west) => ({
  top: `${north
    ? e.pageY - node.clientHeight - 20
    : e.pageY + 25}px`,
  left: `${west
    ? e.pageX - node.clientWidth + 23
    : e.pageX - 21}px`,
});

const handleBlur$1 = ({target}) => {
  if (!target.hasAttribute('data-allytip') && state$2.tips.has(target))
    wipe$1(state$2.tips.get(target));
};

const wipe$1 = ({tip, e:{target}}) => {
  tip.remove();
  unobserve$1({tip, target});
  state$2.tips.delete(target);
};

const togglePinned$1 = e => {
  const target = deepElementFromPoint(e.clientX, e.clientY);

  if (e.altKey && !target.hasAttribute('data-allytip')) {
    target.setAttribute('data-allytip', true);
    state$2.tips.set(target, {
      tip: state$2.active.tip,
      e,
    });
    clearActive$1();
  }
  else if (target.hasAttribute('data-allytip')) {
    target.removeAttribute('data-allytip');
    wipe$1(state$2.tips.get(target));
  }
};

const toggleTargetCursor$1 = (key, target) =>
  key
    ? target.setAttribute('data-pinhover', true)
    : target.removeAttribute('data-pinhover');

const observe$1 = ({tip, target}) => {
  $(target).on('DOMNodeRemoved', handleBlur$1);
};

const unobserve$1 = ({tip, target}) => {
  $(target).off('DOMNodeRemoved', handleBlur$1);
};

const clearActive$1 = () => {
  state$2.active.tip    = null;
  state$2.active.target = null;
};

function Selectable() {
  const page              = document.body;
  let selected            = [];
  let selectedCallbacks   = [];
  let labels              = [];
  let handles             = [];

  const hover_state       = {
    target:   null,
    element:  null,
    label:    null,
  };

  const listen = () => {
    page.addEventListener('click', on_click, true);
    page.addEventListener('dblclick', on_dblclick, true);

    page.on('selectstart', on_selection);
    page.on('mousemove', on_hover);

    document.addEventListener('copy', on_copy);
    document.addEventListener('cut', on_cut);
    document.addEventListener('paste', on_paste);

    watchCommandKey();

    hotkeys(`${metaKey}+alt+c`, on_copy_styles);
    hotkeys(`${metaKey}+alt+v`, e => on_paste_styles());
    hotkeys('esc', on_esc);
    hotkeys(`${metaKey}+d`, on_duplicate);
    hotkeys('backspace,del,delete', on_delete);
    hotkeys('alt+del,alt+backspace', on_clearstyles);
    hotkeys(`${metaKey}+e,${metaKey}+shift+e`, on_expand_selection);
    hotkeys(`${metaKey}+g,${metaKey}+shift+g`, on_group);
    hotkeys('tab,shift+tab,enter,shift+enter', on_keyboard_traversal);
    hotkeys(`${metaKey}+shift+enter`, on_select_children);
  };

  const unlisten = () => {
    page.removeEventListener('click', on_click, true);
    page.removeEventListener('dblclick', on_dblclick, true);

    page.off('selectstart', on_selection);
    page.off('mousemove', on_hover);

    document.removeEventListener('copy', on_copy);
    document.removeEventListener('cut', on_cut);
    document.removeEventListener('paste', on_paste);

    hotkeys.unbind(`esc,${metaKey}+d,backspace,del,delete,alt+del,alt+backspace,${metaKey}+e,${metaKey}+shift+e,${metaKey}+g,${metaKey}+shift+g,tab,shift+tab,enter,shift+enter`);
  };

  const on_click = e => {
    const $target = deepElementFromPoint(e.clientX, e.clientY);

    if (isOffBounds($target) && !selected.filter(el => el == $target).length)
      return

    e.preventDefault();
    if (!e.altKey) e.stopPropagation();
    if (!e.shiftKey) unselect_all();

    if(e.shiftKey && $target.hasAttribute('data-selected'))
      unselect($target.getAttribute('data-label-id'));
    else
      select($target);
  };

  const unselect = id => {
    [...labels, ...handles]
      .filter(node =>
          node.getAttribute('data-label-id') === id)
        .forEach(node =>
          node.remove());

    selected.filter(node =>
      node.getAttribute('data-label-id') === id)
      .forEach(node =>
        $(node).attr({
          'data-selected':      null,
          'data-selected-hide': null,
          'data-label-id':      null,
          'data-pseudo-select':         null,
          'data-measuring':     null,
      }));

    selected = selected.filter(node => node.getAttribute('data-label-id') !== id);

    tellWatchers();
  };

  const on_dblclick = e => {
    e.preventDefault();
    e.stopPropagation();
    if (isOffBounds(e.target)) return
    $('vis-bug')[0].toolSelected('text');
  };

  const watchCommandKey = e => {
    let did_hide = false;

    document.onkeydown = function(e) {
      if (hotkeys.ctrl && selected.length) {
        $('visbug-handles, visbug-label, visbug-hover').forEach(el =>
          el.style.display = 'none');

        did_hide = true;
      }
    };

    document.onkeyup = function(e) {
      if (did_hide) {
        $('visbug-handles, visbug-label, visbug-hover').forEach(el =>
          el.style.display = null);

        did_hide = false;
      }
    };
  };

  const on_esc = _ =>
    selected.length && unselect_all();

  const on_duplicate = e => {
    const root_node = selected[0];
    if (!root_node) return

    const deep_clone = root_node.cloneNode(true);
    deep_clone.removeAttribute('data-selected');
    root_node.parentNode.insertBefore(deep_clone, root_node.nextSibling);
    e.preventDefault();
  };

  const on_delete = e =>
    selected.length && delete_all();

  const on_clearstyles = e =>
    selected.forEach(el =>
      el.attr('style', null));

  const on_copy = e => {
    // if user has selected text, dont try to copy an element
    if (window.getSelection().toString().length)
      return

    if (selected[0] && this.node_clipboard !== selected[0]) {
      e.preventDefault();
      let $node = selected[0].cloneNode(true);
      $node.removeAttribute('data-selected');
      this.copy_backup = $node.outerHTML;
      e.clipboardData.setData('text/html', this.copy_backup);
    }
  };

  const on_cut = e => {
    if (selected[0] && this.node_clipboard !== selected[0]) {
      let $node = selected[0].cloneNode(true);
      $node.removeAttribute('data-selected');
      this.copy_backup = $node.outerHTML;
      e.clipboardData.setData('text/html', this.copy_backup);
      selected[0].remove();
    }
  };

  const on_paste = e => {
    const clipData = e.clipboardData.getData('text/html');
    const potentialHTML = clipData || this.copy_backup;
    if (selected[0] && potentialHTML) {
      e.preventDefault();
      selected[0].appendChild(
        htmlStringToDom(potentialHTML));
    }
  };

  const on_copy_styles = e => {
    e.preventDefault();
    this.copied_styles = selected.map(el =>
      getStyles(el));
  };

  const on_paste_styles = (index = 0) =>
    selected.forEach(el => {
      this.copied_styles[index]
        .map(({prop, value}) =>
          el.style[prop] = value);

      index >= this.copied_styles.length - 1
        ? index = 0
        : index++;
    });

  const on_expand_selection = (e, {key}) => {
    e.preventDefault();

    const [root] = selected;
    if (!root) return

    const query = combineNodeNameAndClass(root);

    if (isSelectorValid(query))
      expandSelection({
        query,
        all: key.includes('shift'),
      });
  };

  const on_group = (e, {key}) => {
    e.preventDefault();

    if (key.split('+').includes('shift')) {
      let $selected = [...selected];
      unselect_all();
      $selected.reverse().forEach(el => {
        let l = el.children.length;
        while (el.children.length > 0) {
          var node = el.childNodes[el.children.length - 1];
          if (node.nodeName !== '#text')
            select(node);
          el.parentNode.prepend(node);
        }
        el.parentNode.removeChild(el);
      });
    }
    else {
      let div = document.createElement('div');
      selected[0].parentNode.prepend(
        selected.reverse().reduce((div, el) => {
          div.appendChild(el);
          return div
        }, div)
      );
      unselect_all();
      select(div);
    }
  };

  const on_selection = e =>
    !isOffBounds(e.target)
    && selected.length
    && selected[0].textContent != e.target.textContent
    && e.preventDefault();

  const on_keyboard_traversal = (e, {key}) => {
    if (!selected.length) return

    e.preventDefault();
    e.stopPropagation();

    const targets = selected.reduce((flat_n_unique, node) => {
      const element_to_left     = canMoveLeft(node);
      const element_to_right    = canMoveRight(node);
      const has_parent_element  = canMoveUp(node);
      const has_child_elements  = findNearestChildElement(node);

      if (key.includes('shift')) {
        if (key.includes('tab') && element_to_left)
          flat_n_unique.add(element_to_left);
        else if (key.includes('enter') && has_parent_element)
          flat_n_unique.add(has_parent_element);
        else
          flat_n_unique.add(node);
      }
      else {
        if (key.includes('tab') && element_to_right)
          flat_n_unique.add(element_to_right);
        else if (key.includes('enter') && has_child_elements)
          flat_n_unique.add(has_child_elements);
        else
          flat_n_unique.add(node);
      }

      return flat_n_unique
    }, new Set());

    if (targets.size) {
      unselect_all();
      targets.forEach(node => {
        select(node);
        show_tip(node);
      });
    }
  };

  const show_tip = el => {
    const active_tool = $('vis-bug')[0].activeTool;
    let tipFactory;

    if (active_tool === 'accessibility') {
      removeAll$1();
      tipFactory = showTip$1;
    }
    else if (active_tool === 'inspector') {
      removeAll();
      tipFactory = showTip;
    }

    if (!tipFactory) return

    const {top, left} = el.getBoundingClientRect();
    const { pageYOffset, pageXOffset } = window;

    tipFactory(el, {
      clientY:  top,
      clientX:  left,
      pageY:    pageYOffset + top - 10,
      pageX:    pageXOffset + left + 20,
    });
  };

  const on_hover = e => {
    const $target = deepElementFromPoint(e.clientX, e.clientY);

    if (isOffBounds($target) || $target.hasAttribute('data-selected'))
      return clearHover()

    overlayHoverUI($target);

    if (e.altKey && $('vis-bug')[0].activeTool === 'guides' && selected.length === 1 && selected[0] != $target) {
      $target.setAttribute('data-measuring', true);
      const [$anchor] = selected;
      return createMeasurements({$anchor, $target})
    }
    else if ($target.hasAttribute('data-measuring')) {
      $target.removeAttribute('data-measuring');
      clearMeasurements();
    }
  };

  const select = el => {
    el.setAttribute('data-selected', true);
    el.setAttribute('data-label-id', labels.length);

    clearHover();

    overlayMetaUI(el);
    selected.unshift(el);
    tellWatchers();
  };

  const selection = () =>
    selected;

  const unselect_all = () => {
    selected
      .forEach(el =>
        $(el).attr({
          'data-selected':      null,
          'data-selected-hide': null,
          'data-label-id':      null,
          'data-pseudo-select': null,
        }));

    Array.from([...handles, ...labels]).forEach(el =>
      el.remove());

    labels    = [];
    handles   = [];
    selected  = [];
  };

  const delete_all = () => {
    const selected_after_delete = selected.map(el => {
      if (canMoveRight(el))     return canMoveRight(el)
      else if (canMoveLeft(el)) return canMoveLeft(el)
      else if (el.parentNode)   return el.parentNode
    });

    Array.from([...selected, ...labels, ...handles]).forEach(el =>
      el.remove());

    labels    = [];
    handles   = [];
    selected  = [];

    selected_after_delete.forEach(el =>
      select(el));
  };

  const expandSelection = ({query, all = false}) => {
    if (all) {
      const unselecteds = $(query + ':not([data-selected])');
      unselecteds.forEach(select);
    }
    else {
      const potentials = $(query);
      if (!potentials) return

      const [anchor] = selected;
      const root_node_index = potentials.reduce((index, node, i) =>
        node == anchor
          ? index = i
          : index
      , null);

      if (root_node_index !== null) {
        if (!potentials[root_node_index + 1]) {
          const potential = potentials.filter(el => !el.attr('data-selected'))[0];
          if (potential) select(potential);
        }
        else {
          select(potentials[root_node_index + 1]);
        }
      }
    }
  };

  const combineNodeNameAndClass = node =>
    `${node.nodeName.toLowerCase()}${createClassname(node)}`;

  const overlayHoverUI = el => {
    if (hover_state.target === el) return

    hover_state.target  = el;
    hover_state.element = createHover(el);
    hover_state.label = createHoverLabel(el, `
      <a node>${el.nodeName.toLowerCase()}</a>
      <a>${el.id && '#' + el.id}</a>
      ${createClassname(el).split('.')
        .filter(name => name != '')
        .reduce((links, name) => `
          ${links}
          <a>.${name}</a>
        `, '')
      }
    `);
  };

  const clearHover = () => {
    if (!hover_state.target) return

    hover_state.element && hover_state.element.remove();
    hover_state.label && hover_state.label.remove();

    hover_state.target  = null;
    hover_state.element = null;
    hover_state.label   = null;
  };

  const overlayMetaUI = el => {
    let handle = createHandle(el);
    let label  = createLabel(el, `
      <a node>${el.nodeName.toLowerCase()}</a>
      <a>${el.id && '#' + el.id}</a>
      ${createClassname(el).split('.')
        .filter(name => name != '')
        .reduce((links, name) => `
          ${links}
          <a>.${name}</a>
        `, '')
      }
    `);

    let observer        = createObserver(el, {handle,label});
    let parentObserver  = createObserver(el, {handle,label});

    observer.observe(el, { attributes: true });
    parentObserver.observe(el.parentNode, { childList:true, subtree:true });

    $(label).on('DOMNodeRemoved', _ => {
      observer.disconnect();
      parentObserver.disconnect();
    });
  };

  const setLabel = (el, label) =>
    label.update = el.getBoundingClientRect();

  const createLabel = (el, text) => {
    const id = parseInt(el.getAttribute('data-label-id'));

    if (!labels[id]) {
      const label = document.createElement('visbug-label');

      label.text = text;
      label.position = {
        boundingRect:   el.getBoundingClientRect(),
        node_label_id:  id,
      };

      document.body.appendChild(label);

      $(label).on('query', ({detail}) => {
        if (!detail.text) return
        this.query_text = detail.text;

        queryPage('[data-pseudo-select]', el =>
          el.removeAttribute('data-pseudo-select'));

        queryPage(this.query_text + ':not([data-selected])', el =>
          detail.activator === 'mouseenter'
            ? el.setAttribute('data-pseudo-select', true)
            : select(el));
      });

      $(label).on('mouseleave', e => {
        e.preventDefault();
        e.stopPropagation();
        queryPage('[data-pseudo-select]', el =>
          el.removeAttribute('data-pseudo-select'));
      });

      labels[labels.length] = label;

      return label
    }
  };

  const createHandle = el => {
    const id = parseInt(el.getAttribute('data-label-id'));

    if (!handles[id]) {
      const handle = document.createElement('visbug-handles');

      handle.position = {
        boundingRect:   el.getBoundingClientRect(),
        node_label_id:  id,
      };

      document.body.appendChild(handle);

      handles[handles.length] = handle;
      return handle
    }
  };

  const createHover = el => {
    if (!el.hasAttribute('data-pseudo-select') && !el.hasAttribute('data-label-id')) {
      if (hover_state.element)
        hover_state.element.remove();

      hover_state.element = document.createElement('visbug-hover');

      hover_state.element.position = {
        boundingRect: el.getBoundingClientRect(),
      };

      document.body.appendChild(hover_state.element);

      return hover_state.element
    }
  };

  const createHoverLabel = (el, text) => {
    if (!el.hasAttribute('data-pseudo-select') && !el.hasAttribute('data-label-id')) {
      if (hover_state.label)
        hover_state.label.remove();

      hover_state.label = document.createElement('visbug-label');

      hover_state.label.text = text;
      hover_state.label.position = {
        boundingRect:   el.getBoundingClientRect(),
        node_label_id:  'hover',
      };

      hover_state.label.style = `--label-bg: hsl(267, 100%, 58%)`;

      document.body.appendChild(hover_state.label);

      return hover_state.label
    }
  };

  const setHandle = (node, handle) => {
    handle.position = {
      boundingRect:   node.getBoundingClientRect(),
      node_label_id:  node.getAttribute('data-label-id'),
    };
  };

  const createObserver = (node, {label,handle}) =>
    new MutationObserver(list => {
      setLabel(node, label);
      setHandle(node, handle);
    });

  const onSelectedUpdate = (cb, immediateCallback = true) => {
    selectedCallbacks.push(cb);
    if (immediateCallback) cb(selected);
  };

  const removeSelectedCallback = cb =>
    selectedCallbacks = selectedCallbacks.filter(callback => callback != cb);

  const tellWatchers = () =>
    selectedCallbacks.forEach(cb => cb(selected));

  const disconnect = () => {
    unselect_all();
    unlisten();
  };

  const on_select_children = (e, {key}) => {
    const targets = selected
      .filter(node => node.children.length)
      .reduce((flat, {children}) =>
        [...flat, ...Array.from(children)], []);

    if (targets.length) {
      e.preventDefault();
      e.stopPropagation();

      unselect_all();
      targets.forEach(node => select(node));
    }
  };

  watchImagesForUpload();
  listen();

  return {
    select,
    selection,
    unselect_all,
    onSelectedUpdate,
    removeSelectedCallback,
    disconnect,
  }
}

// todo: show padding color
const key_events$2 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},alt+${event},shift+${event},shift+alt+${event}`
  , '')
  .substring(1);

const command_events$1 = `${metaKey}+up,${metaKey}+shift+up,${metaKey}+down,${metaKey}+shift+down`;

function Padding({selection}) {
  hotkeys(key_events$2, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();
    padElement(selection(), handler.key);
  });

  hotkeys(command_events$1, (e, handler) => {
    e.preventDefault();
    padAllElementSides(selection(), handler.key);
  });

  return () => {
    hotkeys.unbind(key_events$2);
    hotkeys.unbind(command_events$1);
    hotkeys.unbind('up,down,left,right'); // bug in lib?
  }
}

function padElement(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'padding' + getSide(direction),
      current:  parseInt(getStyle(el, 'padding' + getSide(direction)), 10),
      amount:   direction.split('+').includes('shift') ? 10 : 1,
      negative: direction.split('+').includes('alt'),
    }))
    .map(payload =>
      Object.assign(payload, {
        padding: payload.negative
          ? payload.current - payload.amount
          : payload.current + payload.amount
      }))
    .forEach(({el, style, padding}) =>
      el.style[style] = `${padding < 0 ? 0 : padding}px`);
}

function padAllElementSides(els, keycommand) {
  const combo = keycommand.split('+');
  let spoof = '';

  if (combo.includes('shift'))  spoof = 'shift+' + spoof;
  if (combo.includes('down'))   spoof = 'alt+' + spoof;

  'up,down,left,right'.split(',')
    .forEach(side => padElement(els, spoof + side));
}

const removeEditability = ({target}) => {
  target.removeAttribute('contenteditable');
  target.removeAttribute('spellcheck');
  target.removeEventListener('blur', removeEditability);
  target.removeEventListener('keydown', stopBubbling$1);
  hotkeys.unbind('escape,esc');
};

const stopBubbling$1 = e => e.key != 'Escape' && e.stopPropagation();

const cleanup = (e, handler) => {
  $('[spellcheck="true"]').forEach(target => removeEditability({target}));
  window.getSelection().empty();
};

function EditText(elements) {
  if (!elements.length) return

  elements.map(el => {
    let $el = $(el);

    $el.attr({
      contenteditable: true,
      spellcheck: true,
    });
    el.focus();
    showHideNodeLabel(el, true);

    $el.on('keydown', stopBubbling$1);
    $el.on('blur', removeEditability);
  });

  hotkeys('escape,esc', cleanup);
}

const key_events$3 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},shift+${event}`
  , '')
  .substring(1);

const command_events$2 = `${metaKey}+up,${metaKey}+down`;

function Font({selection}) {
  hotkeys(key_events$3, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();

    let selectedNodes = selection()
      , keys = handler.key.split('+');

    if (keys.includes('left') || keys.includes('right'))
      keys.includes('shift')
        ? changeKerning(selectedNodes, handler.key)
        : changeAlignment(selectedNodes, handler.key);
    else
      keys.includes('shift')
        ? changeLeading(selectedNodes, handler.key)
        : changeFontSize(selectedNodes, handler.key);
  });

  hotkeys(command_events$2, (e, handler) => {
    e.preventDefault();
    let keys = handler.key.split('+');
    changeFontWeight(selection(), keys.includes('up') ? 'up' : 'down');
  });

  hotkeys('cmd+b', e => {
    selection().forEach(el =>
      el.style.fontWeight =
        el.style.fontWeight == 'bold'
          ? null
          : 'bold');
  });

  hotkeys('cmd+i', e => {
    selection().forEach(el =>
      el.style.fontStyle =
        el.style.fontStyle == 'italic'
          ? null
          : 'italic');
  });

  return () => {
    hotkeys.unbind(key_events$3);
    hotkeys.unbind(command_events$2);
    hotkeys.unbind('cmd+b,cmd+i');
    hotkeys.unbind('up,down,left,right');
  }
}

function changeLeading(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'lineHeight',
      current:  parseInt(getStyle(el, 'lineHeight')),
      amount:   1,
      negative: direction.split('+').includes('down'),
    }))
    .map(payload =>
      Object.assign(payload, {
        current: payload.current == 'normal' || isNaN(payload.current)
          ? 1.14 * parseInt(getStyle(payload.el, 'fontSize')) // document this choice
          : payload.current
      }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.negative
          ? payload.current - payload.amount
          : payload.current + payload.amount
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = `${value}px`);
}

function changeKerning(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'letterSpacing',
      current:  parseFloat(getStyle(el, 'letterSpacing')),
      amount:   .1,
      negative: direction.split('+').includes('left'),
    }))
    .map(payload =>
      Object.assign(payload, {
        current: payload.current == 'normal' || isNaN(payload.current)
          ? 0
          : payload.current
      }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.negative
          ? (payload.current - payload.amount).toFixed(2)
          : (payload.current + payload.amount).toFixed(2)
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = `${value <= -2 ? -2 : value}px`);
}

function changeFontSize(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'fontSize',
      current:  parseInt(getStyle(el, 'fontSize')),
      amount:   direction.split('+').includes('shift') ? 10 : 1,
      negative: direction.split('+').includes('down'),
    }))
    .map(payload =>
      Object.assign(payload, {
        font_size: payload.negative
          ? payload.current - payload.amount
          : payload.current + payload.amount
      }))
    .forEach(({el, style, font_size}) =>
      el.style[style] = `${font_size <= 6 ? 6 : font_size}px`);
}

const weightMap = {
  normal: 2,
  bold:   5,
  light:  0,
  "": 2,
  "100":0,"200":1,"300":2,"400":3,"500":4,"600":5,"700":6,"800":7,"900":8
};
const weightOptions = [100,200,300,400,500,600,700,800,900];

function changeFontWeight(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'fontWeight',
      current:  getStyle(el, 'fontWeight'),
      direction: direction.split('+').includes('down'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? weightMap[payload.current] - 1
          : weightMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = weightOptions[value < 0 ? 0 : value >= weightOptions.length
        ? weightOptions.length
        : value
      ]);
}

const alignMap = {
  start: 0,
  left: 0,
  center: 1,
  right: 2,
};
const alignOptions = ['left','center','right'];

function changeAlignment(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'textAlign',
      current:  getStyle(el, 'textAlign'),
      direction: direction.split('+').includes('left'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? alignMap[payload.current] - 1
          : alignMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = alignOptions[value < 0 ? 0 : value >= 2 ? 2: value]);
}

const key_events$4 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},shift+${event}`
  , '')
  .substring(1);

const command_events$3 = `${metaKey}+up,${metaKey}+down,${metaKey}+left,${metaKey}+right`;

function Flex({selection}) {
  hotkeys(key_events$4, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();

    let selectedNodes = selection()
      , keys = handler.key.split('+');

    if (keys.includes('left') || keys.includes('right'))
      keys.includes('shift')
        ? changeHDistribution(selectedNodes, handler.key)
        : changeHAlignment(selectedNodes, handler.key);
    else
      keys.includes('shift')
        ? changeVDistribution(selectedNodes, handler.key)
        : changeVAlignment(selectedNodes, handler.key);
  });

  hotkeys(command_events$3, (e, handler) => {
    e.preventDefault();

    let selectedNodes = selection()
      , keys = handler.key.split('+');

    changeDirection(selectedNodes, keys.includes('left') ? 'row' : 'column');
  });

  return () => {
    hotkeys.unbind(key_events$4);
    hotkeys.unbind(command_events$3);
    hotkeys.unbind('up,down,left,right');
  }
}

const ensureFlex = el => {
  el.style.display = 'flex';
  return el
};

const accountForOtherJustifyContent = (cur, want) => {
  if (want == 'align' && (cur != 'flex-start' && cur != 'center' && cur != 'flex-end'))
    cur = 'normal';
  else if (want == 'distribute' && (cur != 'space-around' && cur != 'space-between'))
    cur = 'normal';

  return cur
};

// todo: support reversing direction
function changeDirection(els, value) {
  els
    .map(ensureFlex)
    .map(el => {
      el.style.flexDirection = value;
    });
}

const h_alignMap      = {normal: 0,'flex-start': 0,'center': 1,'flex-end': 2,};
const h_alignOptions$1  = ['flex-start','center','flex-end'];

function changeHAlignment(els, direction) {
  els
    .map(ensureFlex)
    .map(el => ({
      el,
      style:    'justifyContent',
      current:  accountForOtherJustifyContent(getStyle(el, 'justifyContent'), 'align'),
      direction: direction.split('+').includes('left'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? h_alignMap[payload.current] - 1
          : h_alignMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = h_alignOptions$1[value < 0 ? 0 : value >= 2 ? 2: value]);
}
const v_alignOptions$1  = ['flex-start','center','flex-end'];

function changeVAlignment(els, direction) {
  els
    .map(ensureFlex)
    .map(el => ({
      el,
      style:    'alignItems',
      current:  getStyle(el, 'alignItems'),
      direction: direction.split('+').includes('up'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? h_alignMap[payload.current] - 1
          : h_alignMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = v_alignOptions$1[value < 0 ? 0 : value >= 2 ? 2: value]);
}

const h_distributionMap      = {normal: 1,'space-around': 0,'': 1,'space-between': 2,};
const h_distributionOptions  = ['space-around','','space-between'];

function changeHDistribution(els, direction) {
  els
    .map(ensureFlex)
    .map(el => ({
      el,
      style:    'justifyContent',
      current:  accountForOtherJustifyContent(getStyle(el, 'justifyContent'), 'distribute'),
      direction: direction.split('+').includes('left'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? h_distributionMap[payload.current] - 1
          : h_distributionMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = h_distributionOptions[value < 0 ? 0 : value >= 2 ? 2: value]);
}

const v_distributionMap      = {normal: 1,'space-around': 0,'': 1,'space-between': 2,};
const v_distributionOptions  = ['space-around','','space-between'];

function changeVDistribution(els, direction) {
  els
    .map(ensureFlex)
    .map(el => ({
      el,
      style:    'alignContent',
      current:  getStyle(el, 'alignContent'),
      direction: direction.split('+').includes('up'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? v_distributionMap[payload.current] - 1
          : v_distributionMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = v_distributionOptions[value < 0 ? 0 : value >= 2 ? 2: value]);
}

function ColorPicker(pallete, selectorEngine) {
  const foregroundPicker  = $('#foreground', pallete);
  const backgroundPicker  = $('#background', pallete);
  const borderPicker      = $('#border', pallete);
  const fgInput           = $('input', foregroundPicker[0]);
  const bgInput           = $('input', backgroundPicker[0]);
  const boInput           = $('input', borderPicker[0]);

  const shadows = {
    active:   'rgba(0, 0, 0, 0.1) 0px 0.25em 0.5em, 0 0 0 2px hotpink',
    inactive: 'rgba(0, 0, 0, 0.1) 0px 0.25em 0.5em',
  };

  this.active_color       = 'background';
  this.elements           = [];

  // set colors
  fgInput.on('input', e =>
    this.elements.map(el =>
      el.style['color'] = e.target.value));

  bgInput.on('input', e =>
    this.elements.map(el =>
      el.style[el instanceof SVGElement
        ? 'fill'
        : 'backgroundColor'
      ] = e.target.value));

  boInput.on('input', e =>
    this.elements.map(el =>
      el.style[el instanceof SVGElement
        ? 'stroke'
        : 'border-color'
      ] = e.target.value));

  // read colors
  selectorEngine.onSelectedUpdate(elements => {
    if (!elements.length) return
    this.elements = elements;

    let isMeaningfulForeground  = false;
    let isMeaningfulBackground  = false;
    let isMeaningfulBorder      = false;
    let FG, BG, BO;

    if (this.elements.length == 1) {
      const el = this.elements[0];
      const meaningfulDontMatter = pallete.host.active_tool.dataset.tool === 'hueshift';

      if (el instanceof SVGElement) {
        FG = new TinyColor('rgb(0, 0, 0)');
        var bo_temp = getStyle(el, 'stroke');
        BO = new TinyColor(bo_temp === 'none'
          ? 'rgb(0, 0, 0)'
          : bo_temp);
        BG = new TinyColor(getStyle(el, 'fill'));
      }
      else {
        FG = new TinyColor(getStyle(el, 'color'));
        BG = new TinyColor(getStyle(el, 'backgroundColor'));
        BO = getStyle(el, 'borderWidth') === '0px'
          ? new TinyColor('rgb(0, 0, 0)')
          : new TinyColor(getStyle(el, 'borderColor'));
      }

      let fg = FG.toHexString();
      let bg = BG.toHexString();
      let bo = BO.toHexString();

      isMeaningfulForeground = FG.originalInput !== 'rgb(0, 0, 0)' || (el.children.length === 0 && el.textContent !== '');
      isMeaningfulBackground = BG.originalInput !== 'rgba(0, 0, 0, 0)';
      isMeaningfulBorder     = BO.originalInput !== 'rgb(0, 0, 0)';

      if (isMeaningfulForeground && !isMeaningfulBackground)
        setActive('foreground');
      else if (isMeaningfulBackground && !isMeaningfulForeground)
        setActive('background');

      const new_fg = isMeaningfulForeground ? fg : '';
      const new_bg = isMeaningfulBackground ? bg : '';
      const new_bo = isMeaningfulBorder ? bo : '';

      fgInput.attr('value', new_fg);
      bgInput.attr('value', new_bg);
      boInput.attr('value', new_bo);

      foregroundPicker.attr('style', `
        --contextual_color: ${new_fg};
        display: ${isMeaningfulForeground || meaningfulDontMatter ? 'inline-flex' : 'none'};
      `);

      backgroundPicker.attr('style', `
        --contextual_color: ${new_bg};
        display: ${isMeaningfulBackground || meaningfulDontMatter ? 'inline-flex' : 'none'};
      `);

      borderPicker.attr('style', `
        --contextual_color: ${new_bo};
        display: ${isMeaningfulBorder || meaningfulDontMatter ? 'inline-flex' : 'none'};
      `);
    }
    else {
      // show all 3 if they've selected more than 1 node
      // todo: this is giving up, and can be solved
      foregroundPicker.attr('style', `
        box-shadow: ${this.active_color == 'foreground' ? shadows.active : shadows.inactive};
        display: inline-flex;
      `);

      backgroundPicker.attr('style', `
        box-shadow: ${this.active_color == 'background' ? shadows.active : shadows.inactive};
        display: inline-flex;
      `);

      borderPicker.attr('style', `
        box-shadow: ${this.active_color == 'border' ? shadows.active : shadows.inactive};
        display: inline-flex;
      `);
    }
  });

  const getActive = () =>
    this.active_color;

  const setActive = key => {
    removeActive();
    this.active_color = key;

    if (key === 'foreground')
      foregroundPicker[0].style.boxShadow = shadows.active;
    if (key === 'background')
      backgroundPicker[0].style.boxShadow = shadows.active;
    if (key === 'border')
      borderPicker[0].style.boxShadow = shadows.active;
  };

  const removeActive = () =>
    [foregroundPicker, backgroundPicker, borderPicker].forEach(([picker]) =>
      picker.style.boxShadow = shadows.inactive);

  return {
    getActive,
    setActive,
    foreground: { color: color =>
      foregroundPicker[0].style.setProperty('--contextual_color', color)},
    background: { color: color =>
      backgroundPicker[0].style.setProperty('--contextual_color', color)}
  }
}

const key_events$5 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},shift+${event}`
  , '')
  .substring(1);

const command_events$4 = `${metaKey}+up,${metaKey}+shift+up,${metaKey}+down,${metaKey}+shift+down,${metaKey}+left,${metaKey}+shift+left,${metaKey}+right,${metaKey}+shift+right`;

function BoxShadow({selection}) {
  hotkeys(key_events$5, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();

    let selectedNodes = selection()
      , keys = handler.key.split('+');

    if (keys.includes('left') || keys.includes('right'))
      keys.includes('shift')
        ? changeBoxShadow(selectedNodes, keys, 'size')
        : changeBoxShadow(selectedNodes, keys, 'x');
    else
      keys.includes('shift')
        ? changeBoxShadow(selectedNodes, keys, 'blur')
        : changeBoxShadow(selectedNodes, keys, 'y');
  });

  hotkeys(command_events$4, (e, handler) => {
    e.preventDefault();
    let keys = handler.key.split('+');
    keys.includes('left') || keys.includes('right')
      ? changeBoxShadow(selection(), keys, 'opacity')
      : changeBoxShadow(selection(), keys, 'inset');
  });

  return () => {
    hotkeys.unbind(key_events$5);
    hotkeys.unbind(command_events$4);
    hotkeys.unbind('up,down,left,right');
  }
}

const ensureHasShadow = el => {
  if (el.style.boxShadow == '' || el.style.boxShadow == 'none')
    el.style.boxShadow = 'hsla(0,0%,0%,30%) 0 0 0 0';
  return el
};

// todo: work around this propMap with a better split
const propMap = {
  'opacity':  3,
  'x':        4,
  'y':        5,
  'blur':     6,
  'size':     7,
  'inset':    8,
};

const parseCurrentShadow = el => getStyle(el, 'boxShadow').split(' ');

function changeBoxShadow(els, direction, prop) {
  els
    .map(ensureHasShadow)
    .map(el => showHideSelected(el, 1500))
    .map(el => ({
      el,
      style:     'boxShadow',
      current:   parseCurrentShadow(el), // ["rgb(255,", "0,", "0)", "0px", "0px", "1px", "0px"]
      propIndex: parseCurrentShadow(el)[0].includes('rgba') ? propMap[prop] : propMap[prop] - 1
    }))
    .map(payload => {
      let updated = [...payload.current];
      let cur     = prop === 'opacity'
        ? payload.current[payload.propIndex]
        : parseInt(payload.current[payload.propIndex]);

      switch(prop) {
        case 'blur':
          var amount = direction.includes('shift') ? 10 : 1;
          updated[payload.propIndex] = direction.includes('down')
            ? `${cur - amount}px`
            : `${cur + amount}px`;
          break
        case 'inset':
          updated[payload.propIndex] = direction.includes('down')
            ? 'inset'
            : '';
          break
        case 'opacity':
          let cur_opacity = parseFloat(cur.slice(0, cur.indexOf(')')));
          var amount = direction.includes('shift') ? 0.10 : 0.01;
          updated[payload.propIndex] = direction.includes('left')
            ? cur_opacity - amount + ')'
            : cur_opacity + amount + ')';
          break
        default:
          updated[payload.propIndex] = direction.includes('left') || direction.includes('up')
            ? `${cur - 1}px`
            : `${cur + 1}px`;
          break
      }

      payload.value = updated;
      return payload
    })
    .forEach(({el, style, value}) =>
      el.style[style] = value.join(' '));
}

const key_events$6 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},shift+${event}`
  , '')
  .substring(1);

const command_events$5 = `${metaKey}+up,${metaKey}+shift+up,${metaKey}+down,${metaKey}+shift+down,${metaKey}+left,${metaKey}+shift+left,${metaKey}+right,${metaKey}+shift+right`;

function HueShift(Color) {
  this.active_color   = Color.getActive();
  this.elements       = [];

  hotkeys(key_events$6, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();

    let selectedNodes = this.elements
      , keys = handler.key.split('+');

    keys.includes('left') || keys.includes('right')
      ? changeHue(selectedNodes, keys, 's', Color)
      : changeHue(selectedNodes, keys, 'l', Color);
  });

  hotkeys(command_events$5, (e, handler) => {
    e.preventDefault();
    let keys = handler.key.split('+');
    keys.includes('left') || keys.includes('right')
      ? changeHue(this.elements, keys, 'a', Color)
      : changeHue(this.elements, keys, 'h', Color);
  });

  hotkeys(']', (e, handler) => {
    e.preventDefault();

    if (this.active_color == 'foreground')
      this.active_color = 'background';
    else if (this.active_color == 'background')
      this.active_color = 'border';

    Color.setActive(this.active_color);
  });

  hotkeys('[', (e, handler) => {
    e.preventDefault();

    if (this.active_color == 'background')
      this.active_color = 'foreground';
    else if (this.active_color == 'border')
      this.active_color = 'background';

    Color.setActive(this.active_color);
  });

  const onNodesSelected = els => {
    this.elements = els;
    Color.setActive(this.active_color);
  };

  const disconnect = () => {
    hotkeys.unbind(key_events$6);
    hotkeys.unbind(command_events$5);
    hotkeys.unbind('up,down,left,right');
  };

  return {
    onNodesSelected,
    disconnect,
  }
}

function changeHue(els, direction, prop, Color) {
  els
    .map(el => showHideSelected(el))
    .map(el => {
      const { foreground, background, border } = extractPalleteColors(el);

      // todo: teach hueshift to do handle color
      switch(Color.getActive()) {
        case 'background':
          return { el, current: background.color.toHsl(), style: background.style }
        case 'foreground':
          return { el, current: foreground.color.toHsl(), style: foreground.style }
        case 'border': {
          if (el.style.border === '') el.style.border = '1px solid black';
          return { el, current: border.color.toHsl(), style: border.style }
        }
      }
    })
    .map(payload =>
      Object.assign(payload, {
        amount:   direction.includes('shift') ? 10 : 1,
        negative: direction.includes('down') || direction.includes('left'),
      }))
    .map(payload => {
      if (prop === 's' || prop === 'l' || prop === 'a')
        payload.amount = payload.amount * 0.01;

      payload.current[prop] = payload.negative
        ? payload.current[prop] - payload.amount
        : payload.current[prop] + payload.amount;

      if (prop === 's' || prop === 'l' || prop === 'a') {
        if (payload.current[prop] > 1) payload.current[prop] = 1;
        if (payload.current[prop] < 0) payload.current[prop] = 0;
      }

      return payload
    })
    .forEach(({el, style, current}) => {
      let color = new TinyColor(current).setAlpha(current.a);
      el.style[style] = color.toHslString();

      if (style == 'color') Color.foreground.color(color.toHexString());
      if (style == 'backgroundColor') Color.background.color(color.toHexString());
    });
}

function extractPalleteColors(el) {
  if (el instanceof SVGElement) {
    const  fg_temp = getStyle(el, 'stroke');

    return {
      foreground: {
        style: 'stroke',
        color: new TinyColor(fg_temp === 'none'
          ? 'rgb(0, 0, 0)'
          : fg_temp),
      },
      background: {
        style: 'fill',
        color: new TinyColor(getStyle(el, 'fill')),
      },
      border: {
        style: 'outline',
        color: new TinyColor(getStyle(el, 'outline')),
      }
    }
  }
  else
    return {
      foreground: {
        style: 'color',
        color: new TinyColor(getStyle(el, 'color')),
      },
      background: {
        style: 'backgroundColor',
        color: new TinyColor(getStyle(el, 'backgroundColor')),
      },
      border: {
        style: 'borderColor',
        color: new TinyColor(getStyle(el, 'borderColor')),
      }
    }
}

let gridlines;

function Guides() {
  $('body').on('mousemove', on_hover);
  $('body').on('mouseout', on_hoverout);
  window.addEventListener('scroll', hideGridlines);

  return () => {
    $('body').off('mousemove', on_hover);
    $('body').off('mouseout', on_hoverout);
    window.removeEventListener('scroll', hideGridlines);
    hideGridlines();
  }
}

const on_hover = e => {
  const target = deepElementFromPoint(e.clientX, e.clientY);
  if (isOffBounds(target)) return
  showGridlines(target);
};

const on_hoverout = ({target}) =>
  hideGridlines();

const showGridlines = node => {
  if (gridlines) {
    gridlines.style.display = null;
    gridlines.update = node.getBoundingClientRect();
  }
  else {
    gridlines = document.createElement('visbug-gridlines');
    gridlines.position = node.getBoundingClientRect();

    document.body.appendChild(gridlines);
  }
};

const hideGridlines = node => {
  if (!gridlines) return
  gridlines.style.display = 'none';
};

function Screenshot(node, page) {
  alert('Coming Soon!');

  return () => {}
}

const key_events$7 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},alt+${event},shift+${event},shift+alt+${event}`
  , '')
  .substring(1);

function Position() {
  const state = {
    elements: []
  };

  hotkeys(key_events$7, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();
    positionElement(state.elements, handler.key);
  });

  const onNodesSelected = els => {
    state.elements.forEach(el =>
      el.teardown());

    state.elements = els.map(el =>
      draggable(el));
  };

  const disconnect = () => {
    state.elements.forEach(el => el.teardown());
    hotkeys.unbind(key_events$7);
    hotkeys.unbind('up,down,left,right');
  };

  return {
    onNodesSelected,
    disconnect,
  }
}

function draggable(el) {
  this.state = {
    mouse: {
      down: false,
      x: 0,
      y: 0,
    },
    element: {
      x: 0,
      y: 0,
    }
  };

  const setup = () => {
    el.style.transition   = 'none';
    el.style.cursor       = 'move';

    el.addEventListener('mousedown', onMouseDown, true);
    el.addEventListener('mouseup', onMouseUp, true);
    document.addEventListener('mousemove', onMouseMove, true);
  };

  const teardown = () => {
    el.style.transition   = null;
    el.style.cursor       = null;

    el.removeEventListener('mousedown', onMouseDown, true);
    el.removeEventListener('mouseup', onMouseUp, true);
    document.removeEventListener('mousemove', onMouseMove, true);
  };

  const onMouseDown = e => {
    e.preventDefault();

    const el = e.target;

    el.style.position = 'relative';
    el.style.willChange = 'top,left';

    if (el instanceof SVGElement) {
      const translate = el.getAttribute('transform');

      const [ x, y ] = translate
        ? extractSVGTranslate(translate)
        : [0,0];

      this.state.element.x  = x;
      this.state.element.y  = y;
    }
    else {
      this.state.element.x  = parseInt(getStyle(el, 'left'));
      this.state.element.y  = parseInt(getStyle(el, 'top'));
    }

    this.state.mouse.x      = e.clientX;
    this.state.mouse.y      = e.clientY;
    this.state.mouse.down   = true;
  };

  const onMouseUp = e => {
    e.preventDefault();
    e.stopPropagation();

    this.state.mouse.down = false;
    el.style.willChange = null;

    if (el instanceof SVGElement) {
      const translate = el.getAttribute('transform');

      const [ x, y ] = translate
        ? extractSVGTranslate(translate)
        : [0,0];

      this.state.element.x    = x;
      this.state.element.y    = y;
    }
    else {
      this.state.element.x    = parseInt(el.style.left) || 0;
      this.state.element.y    = parseInt(el.style.top) || 0;
    }
  };

  const onMouseMove = e => {
    e.preventDefault();
    e.stopPropagation();

    if (!this.state.mouse.down) return

    if (el instanceof SVGElement) {
      el.setAttribute('transform', `translate(
        ${this.state.element.x + e.clientX - this.state.mouse.x},
        ${this.state.element.y + e.clientY - this.state.mouse.y}
      )`);
    }
    else {
      el.style.left = this.state.element.x + e.clientX - this.state.mouse.x + 'px';
      el.style.top  = this.state.element.y + e.clientY - this.state.mouse.y + 'px';
    }
  };

  setup();
  el.teardown = teardown;

  return el
}

function positionElement(els, direction) {
  els
    .map(el => ensurePositionable(el))
    .map(el => showHideSelected(el))
    .map(el => ({
        el,
        ...extractCurrentValueAndSide(el, direction),
        amount:   direction.split('+').includes('shift') ? 10 : 1,
        negative: determineNegativity(el, direction),
    }))
    .map(payload =>
      Object.assign(payload, {
        position: payload.negative
          ? payload.current + payload.amount
          : payload.current - payload.amount
      }))
    .forEach(({el, style, position}) =>
      el instanceof SVGElement
        ? setTranslateOnSVG(el, direction, position)
        : el.style[style] = position + 'px');
}

const extractCurrentValueAndSide = (el, direction) => {
  let style, current;

  if (el instanceof SVGElement) {
    const translate = el.attr('transform');

    const [ x, y ] = translate
      ? extractSVGTranslate(translate)
      : [0,0];

    style   = 'transform';
    current = direction.includes('down') || direction.includes('up')
      ? y
      : x;
  }
  else {
    const side = getSide(direction).toLowerCase();
    style = (side === 'top' || side === 'bottom') ? 'top' : 'left';
    current = getStyle(el, style);

    current === 'auto'
      ? current = 0
      : current = parseInt(current, 10);
  }

  return { style, current }
};

const extractSVGTranslate = translate =>
  translate.substring(
    translate.indexOf('(') + 1,
    translate.indexOf(')')
  ).split(',')
  .map(val => parseFloat(val));

const setTranslateOnSVG = (el, direction, position) => {
  const transform = el.attr('transform');
  const [ x, y ] = transform
    ? extractSVGTranslate(transform)
    : [0,0];

  const pos = direction.includes('down') || direction.includes('up')
    ? `${x},${position}`
    : `${position},${y}`;

  el.attr('transform', `translate(${pos})`);
};

const determineNegativity = (el, direction) =>
  direction.includes('right') || direction.includes('down');

const ensurePositionable = el => {
  if (el instanceof HTMLElement)
    el.style.position = 'relative';
  return el
};

const VisBugModel = {
  g: {
    tool:        'guides',
    icon:        guides,
    label:       'Guides',
    description: 'Verify alignment & check your grid',
    instruction: `<div table>
                    <div>
                      <b>Measure:</b>
                      <span>${altKey} + hover</span>
                    </div>
                  </div>`,
  },
  i: {
    tool:        'inspector',
    icon:        inspector,
    label:       'Inspect',
    description: 'Peek into common & current styles of an element',
    instruction: `<div table>
                    <div>
                      <b>Pin it:</b>
                      <span>${altKey} + click</span>
                    </div>
                  </div>`,
  },
  x: {
    tool:        'accessibility',
    icon:        accessibility,
    label:       'Accessibility',
    description: 'Peek into A11y attributes & compliance status',
    instruction: `<div table>
                    <div>
                      <b>Pin it:</b>
                      <span>${altKey} + click</span>
                    </div>
                  </div>`,
  },
  v: {
    tool:        'move',
    icon:        move,
    label:       'Move',
    description: 'Push elements in & out of their container, or shuffle them within it',
    instruction: `<div table>
                    <div>
                      <b>Lateral:</b>
                      <span>◀ ▶</span>
                    </div>
                    <div>
                      <b>Out and above:</b>
                      <span>▲</span>
                    </div>
                    <div>
                      <b>Down and in:</b>
                      <span>▼</span>
                    </div>
                  </div>`,
  },
  // r: {
  //   tool:        'resize',
  //   icon:        Icons.resize,
  //   label:       'Resize',
  //   description: ''
  // },
  m: {
    tool:        'margin',
    icon:        margin,
    label:       'Margin',
    description: 'Add or subtract outer space from any or all sides of the selected element(s)',
    instruction: `<div table>
                    <div>
                      <b>+ Margin:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>- Margin:</b>
                      <span>${altKey} + ◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>All Sides:</b>
                      <span>${metaKey} +  ▲ ▼</span>
                    </div>
                  </div>`,
  },
  p: {
    tool:        'padding',
    icon:        padding,
    label:       'Padding',
    description: `Add or subtract inner space from any or all sides of the selected element(s)`,
    instruction: `<div table>
                    <div>
                      <b>+ Padding:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>- Padding:</b>
                      <span>${altKey} + ◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>All Sides:</b>
                      <span>${metaKey} +  ▲ ▼</span>
                    </div>
                  </div>`
  },
  // b: {
  //   tool:        'border',
  //   icon:        Icons.border,
  //   label:       'Border',
  //   description: ''
  // },
  a: {
    tool:        'align',
    icon:        align,
    label:       'Flexbox Align',
    description: `Create or modify flexbox direction, distribution & alignment`,
    instruction: `<div table>
                    <div>
                      <b>Alignment:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>Distribution:</b>
                      <span>Shift + ◀ ▶</span>
                    </div>
                    <div>
                      <b>Direction:</b>
                      <span>${metaKey} +  ◀ ▼</span>
                    </div>
                  </div>`,
  },
  h: {
    tool:        'hueshift',
    icon:        hueshift,
    label:       'Hue Shift',
    description: `Change foreground/background hue, brightness, saturation & opacity`,
    instruction: `<div table>
                    <div>
                      <b>Saturation:</b>
                      <span>◀ ▶</span>
                    </div>
                    <div>
                      <b>Brightness:</b>
                      <span>▲ ▼</span>
                    </div>
                    <div>
                      <b>Hue:</b>
                      <span>${metaKey} +  ▲ ▼</span>
                    </div>
                    <div>
                      <b>Opacity:</b>
                      <span>${metaKey} +  ◀ ▶</span>
                    </div>
                  </div>`,
  },
  d: {
    tool:        'boxshadow',
    icon:        boxshadow,
    label:       'Shadow',
    description: `Create & adjust position, blur & opacity of a box shadow`,
    instruction: `<div table>
                    <div>
                      <b>X/Y Position:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>Blur:</b>
                      <span>Shift + ▲ ▼</span>
                    </div>
                    <div>
                      <b>Spread:</b>
                      <span>Shift + ◀ ▶</span>
                    </div>
                    <div>
                      <b>Opacity:</b>
                      <span>${metaKey} + ◀ ▶</span>
                    </div>
                  </div>`,
  },
  // t: {
  //   tool:        'transform',
  //   icon:        Icons.transform,
  //   label:       '3D Transform',
  //   description: ''
  // },
  l: {
    tool:        'position',
    icon:        position,
    label:       'Position',
    description: 'Move svg (x,y) and elements (top,left,bottom,right)',
    instruction: `<div table>
                    <div>
                      <b>Nudge:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>Move:</b>
                      <span>Click & drag</span>
                    </div>
                  </div>`,
  },
  f: {
    tool:        'font',
    icon:        font,
    label:       'Font Styles',
    description: 'Change size, alignment, leading, letter-spacing, & weight',
    instruction: `<div table>
                    <div>
                      <b>Size:</b>
                      <span>▲ ▼</span>
                    </div>
                    <div>
                      <b>Alignment:</b>
                      <span>◀ ▶</span>
                    </div>
                    <div>
                      <b>Leading:</b>
                      <span>Shift + ▲ ▼</span>
                    </div>
                    <div>
                      <b>Letter-spacing:</b>
                      <span>Shift + ◀ ▶</span>
                    </div>
                    <div>
                      <b>Weight:</b>
                      <span>${metaKey} + ▲ ▼</span>
                    </div>
                  </div>`,
  },
  e: {
    tool:        'text',
    icon:        text,
    label:       'Edit Text',
    description: 'Change any text on the page with a <b>double click</b>',
    instruction: '',
  },
  // c: {
  //   tool:        'screenshot',
  //   icon:        Icons.camera,
  //   label:       'Screenshot',
  //   description: 'Screenshot selected elements or the entire page'
  // },
  s: {
    tool:        'search',
    icon:        search,
    label:       'Search',
    description: 'Select elements programatically by searching for them or use built in plugins with special commands',
    instruction: '',
  },
};

class VisBug extends HTMLElement {
  constructor() {
    super();

    this.toolbar_model  = VisBugModel;
    this._tutsBaseURL   = 'tuts'; // can be set by content script
    this.$shadow        = this.attachShadow({mode: 'closed'});
  }

  connectedCallback() {
    if (!this.$shadow.innerHTML)
      this.setup();

    this.selectorEngine = Selectable();
    this.colorPicker    = ColorPicker(this.$shadow, this.selectorEngine);
    provideSelectorEngine(this.selectorEngine);
  }

  disconnectedCallback() {
    this.deactivate_feature();
    this.selectorEngine.disconnect();
    hotkeys.unbind(
      Object.keys(this.toolbar_model).reduce((events, key) =>
        events += ',' + key, ''));
    hotkeys.unbind(`${metaKey}+/`);
  }

  setup() {
    this.$shadow.innerHTML = this.render();

    $('li[data-tool]', this.$shadow).on('click', e =>
      this.toolSelected(e.currentTarget) && e.stopPropagation());

    Object.entries(this.toolbar_model).forEach(([key, value]) =>
      hotkeys(key, e => {
        e.preventDefault();
        this.toolSelected(
          $(`[data-tool="${value.tool}"]`, this.$shadow)[0]
        );
      })
    );

    hotkeys(`${metaKey}+/,${metaKey}+.`, e =>
      this.$shadow.host.style.display =
        this.$shadow.host.style.display === 'none'
          ? 'block'
          : 'none');

    this.toolSelected($('[data-tool="guides"]', this.$shadow)[0]);
  }

  toolSelected(el) {
    if (typeof el === 'string')
      el = $(`[data-tool="${el}"]`, this.$shadow)[0];

    if (this.active_tool && this.active_tool.dataset.tool === el.dataset.tool) return

    if (this.active_tool) {
      this.active_tool.attr('data-active', null);
      this.deactivate_feature();
    }

    el.attr('data-active', true);
    this.active_tool = el;
    this[el.dataset.tool]();
  }

  render() {
    return `
      ${this.styles()}
      <visbug-hotkeys></visbug-hotkeys>
      <ol>
        ${Object.entries(this.toolbar_model).reduce((list, [key, tool]) => `
          ${list}
          <li aria-label="${tool.label} Tool" aria-description="${tool.description}" aria-hotkey="${key}" data-tool="${tool.tool}" data-active="${key == 'g'}">
            ${tool.icon}
            ${this.demoTip({key, ...tool})}
          </li>
        `,'')}
      </ol>
      <ol colors>
        <li style="display: none;" class="color" id="foreground" aria-label="Text" aria-description="Change the text color">
          <input type="color" value="">
          ${color_text}
        </li>
        <li style="display: none;" class="color" id="background" aria-label="Background or Fill" aria-description="Change the background color or fill of svg">
          <input type="color" value="">
          ${color_background}
        </li>
        <li style="display: none;" class="color" id="border" aria-label="Border or Stroke" aria-description="Change the border color or stroke of svg">
          <input type="color" value="">
          ${color_border}
        </li>
      </ol>
    `
  }

  styles() {
    return `
      <style>
        ${css}
      </style>
    `
  }

  demoTip({key, tool, label, description, instruction}) {
    return `
      <aside ${tool}>
        <figure>
          <img src="${this._tutsBaseURL}/${tool}.gif" alt="${description}" />
          <figcaption>
            <h2>
              ${label}
              <span hotkey>${key}</span>
            </h2>
            <p>${description}</p>
            ${instruction}
          </figcaption>
        </figure>
      </aside>
    `
  }

  move() {
    this.deactivate_feature = Moveable(this.selectorEngine);
  }

  margin() {
    this.deactivate_feature = Margin(this.selectorEngine);
  }

  padding() {
    this.deactivate_feature = Padding(this.selectorEngine);
  }

  font() {
    this.deactivate_feature = Font(this.selectorEngine);
  }

  text() {
    this.selectorEngine.onSelectedUpdate(EditText);
    this.deactivate_feature = () =>
      this.selectorEngine.removeSelectedCallback(EditText);
  }

  align() {
    this.deactivate_feature = Flex(this.selectorEngine);
  }

  search() {
    this.deactivate_feature = Search($('[data-tool="search"]', this.$shadow));
  }

  boxshadow() {
    this.deactivate_feature = BoxShadow(this.selectorEngine);
  }

  hueshift() {
    let feature = HueShift(this.colorPicker);
    this.selectorEngine.onSelectedUpdate(feature.onNodesSelected);
    this.deactivate_feature = () => {
      this.selectorEngine.removeSelectedCallback(feature.onNodesSelected);
      feature.disconnect();
    };
  }

  inspector() {
    this.deactivate_feature = MetaTip(this.selectorEngine);
  }

  accessibility() {
    this.deactivate_feature = Accessibility();
  }

  guides() {
    this.deactivate_feature = Guides();
  }

  screenshot() {
    this.deactivate_feature = Screenshot();
  }

  position() {
    let feature = Position();
    this.selectorEngine.onSelectedUpdate(feature.onNodesSelected);
    this.deactivate_feature = () => {
      this.selectorEngine.removeSelectedCallback(feature.onNodesSelected);
      feature.disconnect();
    };
  }

  get activeTool() {
    return this.active_tool.dataset.tool
  }

  set tutsBaseURL(url) {
    this._tutsBaseURL = url;
    this.setup();
  }
}

customElements.define('vis-bug', VisBug);

if ('ontouchstart' in document.documentElement)
  document.getElementById('mobile-info').style.display = '';

if (metaKey === 'ctrl')
  [...document.querySelectorAll('kbd')]
    .forEach(node => {
      node.textContent = node.textContent.replace('cmd','ctrl');
      node.textContent = node.textContent.replace('opt','alt');
    });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVuZGxlLmpzIiwic291cmNlcyI6WyIuLi9ub2RlX21vZHVsZXMvYmxpbmdibGluZ2pzL3NyYy9pbmRleC5qcyIsIi4uL25vZGVfbW9kdWxlcy9ob3RrZXlzLWpzL2Rpc3QvaG90a2V5cy5lc20uanMiLCJjb21wb25lbnRzL3NlbGVjdGlvbi9oYW5kbGVzLmVsZW1lbnQuanMiLCJjb21wb25lbnRzL3NlbGVjdGlvbi9ob3Zlci5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9zZWxlY3Rpb24vbGFiZWwuZWxlbWVudC5qcyIsInV0aWxpdGllcy9kZXNpZ24tcHJvcGVydGllcy5qcyIsInV0aWxpdGllcy9zdHlsZXMuanMiLCJ1dGlsaXRpZXMvYWNjZXNzaWJpbGl0eS5qcyIsInV0aWxpdGllcy9zdHJpbmdzLmpzIiwidXRpbGl0aWVzL2NvbW1vbi5qcyIsInV0aWxpdGllcy93aW5kb3cuanMiLCJjb21wb25lbnRzL3NlbGVjdGlvbi9ncmlkbGluZXMuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvc2VsZWN0aW9uL2Rpc3RhbmNlLmVsZW1lbnQuanMiLCJjb21wb25lbnRzL3NlbGVjdGlvbi9vdmVybGF5LmVsZW1lbnQuanMiLCJjb21wb25lbnRzL21ldGF0aXAvbWV0YXRpcC5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9tZXRhdGlwL2FsbHkuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvdmlzLWJ1Zy92aXMtYnVnLmljb25zLmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL2Jhc2UuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9ndWlkZXMuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9pbnNwZWN0b3IuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9hY2Nlc3NpYmlsaXR5LmVsZW1lbnQuanMiLCJjb21wb25lbnRzL2hvdGtleS1tYXAvbW92ZS5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL21hcmdpbi5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL3BhZGRpbmcuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9hbGlnbi5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL2h1ZXNoaWZ0LmVsZW1lbnQuanMiLCJjb21wb25lbnRzL2hvdGtleS1tYXAvYm94c2hhZG93LmVsZW1lbnQuanMiLCJjb21wb25lbnRzL2hvdGtleS1tYXAvcG9zaXRpb24uZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9mb250LmVsZW1lbnQuanMiLCJjb21wb25lbnRzL2hvdGtleS1tYXAvdGV4dC5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL3NlYXJjaC5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL2hvdGtleXMuZWxlbWVudC5qcyIsImZlYXR1cmVzL21hcmdpbi5qcyIsImZlYXR1cmVzL21vdmUuanMiLCJmZWF0dXJlcy9pbWFnZXN3YXAuanMiLCIuLi9ub2RlX21vZHVsZXMvcXVlcnktc2VsZWN0b3Itc2hhZG93LWRvbS9zcmMvcXVlcnlTZWxlY3RvckRlZXAuanMiLCJwbHVnaW5zL2JsYW5rLXBhZ2UuanMiLCJwbHVnaW5zL2JhcnJlbC1yb2xsLmpzIiwicGx1Z2lucy9wZXN0aWNpZGUuanMiLCJwbHVnaW5zL2NvbnN0cnVjdC5qcyIsInBsdWdpbnMvY29uc3RydWN0LmRlYnVnLmpzIiwicGx1Z2lucy93aXJlZnJhbWUuanMiLCJwbHVnaW5zL3NrZWxldG9uLmpzIiwicGx1Z2lucy90YWctZGVidWdnZXIuanMiLCJwbHVnaW5zL3JldmVuZ2UuanMiLCJwbHVnaW5zL19yZWdpc3RyeS5qcyIsImZlYXR1cmVzL3NlYXJjaC5qcyIsImZlYXR1cmVzL21lYXN1cmVtZW50cy5qcyIsIi4uL25vZGVfbW9kdWxlcy9AY3RybC90aW55Y29sb3IvYnVuZGxlcy90aW55Y29sb3IuZXMyMDE1LmpzIiwiZmVhdHVyZXMvbWV0YXRpcC5qcyIsImZlYXR1cmVzL2FjY2Vzc2liaWxpdHkuanMiLCJmZWF0dXJlcy9zZWxlY3RhYmxlLmpzIiwiZmVhdHVyZXMvcGFkZGluZy5qcyIsImZlYXR1cmVzL3RleHQuanMiLCJmZWF0dXJlcy9mb250LmpzIiwiZmVhdHVyZXMvZmxleC5qcyIsImZlYXR1cmVzL2NvbG9yLmpzIiwiZmVhdHVyZXMvYm94c2hhZG93LmpzIiwiZmVhdHVyZXMvaHVlc2hpZnQuanMiLCJmZWF0dXJlcy9ndWlkZXMuanMiLCJmZWF0dXJlcy9zY3JlZW5zaG90LmpzIiwiZmVhdHVyZXMvcG9zaXRpb24uanMiLCJjb21wb25lbnRzL3Zpcy1idWcvbW9kZWwuanMiLCJjb21wb25lbnRzL3Zpcy1idWcvdmlzLWJ1Zy5lbGVtZW50LmpzIiwiaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc3VnYXIgPSB7XG4gIG9uOiBmdW5jdGlvbihuYW1lcywgZm4pIHtcbiAgICBuYW1lc1xuICAgICAgLnNwbGl0KCcgJylcbiAgICAgIC5mb3JFYWNoKG5hbWUgPT5cbiAgICAgICAgdGhpcy5hZGRFdmVudExpc3RlbmVyKG5hbWUsIGZuKSlcbiAgICByZXR1cm4gdGhpc1xuICB9LFxuICBvZmY6IGZ1bmN0aW9uKG5hbWVzLCBmbikge1xuICAgIG5hbWVzXG4gICAgICAuc3BsaXQoJyAnKVxuICAgICAgLmZvckVhY2gobmFtZSA9PlxuICAgICAgICB0aGlzLnJlbW92ZUV2ZW50TGlzdGVuZXIobmFtZSwgZm4pKVxuICAgIHJldHVybiB0aGlzXG4gIH0sXG4gIGF0dHI6IGZ1bmN0aW9uKGF0dHIsIHZhbCkge1xuICAgIGlmICh2YWwgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHRoaXMuZ2V0QXR0cmlidXRlKGF0dHIpXG5cbiAgICB2YWwgPT0gbnVsbFxuICAgICAgPyB0aGlzLnJlbW92ZUF0dHJpYnV0ZShhdHRyKVxuICAgICAgOiB0aGlzLnNldEF0dHJpYnV0ZShhdHRyLCB2YWwgfHwgJycpXG4gICAgICBcbiAgICByZXR1cm4gdGhpc1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uICQocXVlcnksICRjb250ZXh0ID0gZG9jdW1lbnQpIHtcbiAgbGV0ICRub2RlcyA9IHF1ZXJ5IGluc3RhbmNlb2YgTm9kZUxpc3QgfHwgQXJyYXkuaXNBcnJheShxdWVyeSlcbiAgICA/IHF1ZXJ5XG4gICAgOiBxdWVyeSBpbnN0YW5jZW9mIEhUTUxFbGVtZW50IHx8IHF1ZXJ5IGluc3RhbmNlb2YgU1ZHRWxlbWVudFxuICAgICAgPyBbcXVlcnldXG4gICAgICA6ICRjb250ZXh0LnF1ZXJ5U2VsZWN0b3JBbGwocXVlcnkpXG5cbiAgaWYgKCEkbm9kZXMubGVuZ3RoKSAkbm9kZXMgPSBbXVxuXG4gIHJldHVybiBPYmplY3QuYXNzaWduKFxuICAgIFsuLi4kbm9kZXNdLm1hcCgkZWwgPT4gT2JqZWN0LmFzc2lnbigkZWwsIHN1Z2FyKSksIFxuICAgIHtcbiAgICAgIG9uOiBmdW5jdGlvbihuYW1lcywgZm4pIHtcbiAgICAgICAgdGhpcy5mb3JFYWNoKCRlbCA9PiAkZWwub24obmFtZXMsIGZuKSlcbiAgICAgICAgcmV0dXJuIHRoaXNcbiAgICAgIH0sXG4gICAgICBvZmY6IGZ1bmN0aW9uKG5hbWVzLCBmbikge1xuICAgICAgICB0aGlzLmZvckVhY2goJGVsID0+ICRlbC5vZmYobmFtZXMsIGZuKSlcbiAgICAgICAgcmV0dXJuIHRoaXNcbiAgICAgIH0sXG4gICAgICBhdHRyOiBmdW5jdGlvbihhdHRycywgdmFsKSB7XG4gICAgICAgIGlmICh0eXBlb2YgYXR0cnMgPT09ICdzdHJpbmcnICYmIHZhbCA9PT0gdW5kZWZpbmVkKVxuICAgICAgICAgIHJldHVybiB0aGlzWzBdLmF0dHIoYXR0cnMpXG5cbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIGF0dHJzID09PSAnb2JqZWN0JykgXG4gICAgICAgICAgdGhpcy5mb3JFYWNoKCRlbCA9PlxuICAgICAgICAgICAgT2JqZWN0LmVudHJpZXMoYXR0cnMpXG4gICAgICAgICAgICAgIC5mb3JFYWNoKChba2V5LCB2YWxdKSA9PlxuICAgICAgICAgICAgICAgICRlbC5hdHRyKGtleSwgdmFsKSkpXG5cbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIGF0dHJzID09ICdzdHJpbmcnICYmICh2YWwgfHwgdmFsID09IG51bGwgfHwgdmFsID09ICcnKSlcbiAgICAgICAgICB0aGlzLmZvckVhY2goJGVsID0+ICRlbC5hdHRyKGF0dHJzLCB2YWwpKVxuXG4gICAgICAgIHJldHVybiB0aGlzXG4gICAgICB9XG4gICAgfVxuICApXG59IiwiLyohXG4gKiBob3RrZXlzLWpzIHYzLjMuNVxuICogQSBzaW1wbGUgbWljcm8tbGlicmFyeSBmb3IgZGVmaW5pbmcgYW5kIGRpc3BhdGNoaW5nIGtleWJvYXJkIHNob3J0Y3V0cy4gSXQgaGFzIG5vIGRlcGVuZGVuY2llcy5cbiAqIFxuICogQ29weXJpZ2h0IChjKSAyMDE4IGtlbm55IHdvbmcgPHdvd29ob29AcXEuY29tPlxuICogaHR0cDovL2pheXdjamxvdmUuZ2l0aHViLmlvL2hvdGtleXNcbiAqIFxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlLlxuICovXG5cbnZhciBpc2ZmID0gdHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcgPyBuYXZpZ2F0b3IudXNlckFnZW50LnRvTG93ZXJDYXNlKCkuaW5kZXhPZignZmlyZWZveCcpID4gMCA6IGZhbHNlO1xuXG4vLyDnu5Hlrprkuovku7ZcbmZ1bmN0aW9uIGFkZEV2ZW50KG9iamVjdCwgZXZlbnQsIG1ldGhvZCkge1xuICBpZiAob2JqZWN0LmFkZEV2ZW50TGlzdGVuZXIpIHtcbiAgICBvYmplY3QuYWRkRXZlbnRMaXN0ZW5lcihldmVudCwgbWV0aG9kLCBmYWxzZSk7XG4gIH0gZWxzZSBpZiAob2JqZWN0LmF0dGFjaEV2ZW50KSB7XG4gICAgb2JqZWN0LmF0dGFjaEV2ZW50KCdvbicgKyBldmVudCwgZnVuY3Rpb24gKCkge1xuICAgICAgbWV0aG9kKHdpbmRvdy5ldmVudCk7XG4gICAgfSk7XG4gIH1cbn1cblxuLy8g5L+u6aWw6ZSu6L2s5o2i5oiQ5a+55bqU55qE6ZSu56CBXG5mdW5jdGlvbiBnZXRNb2RzKG1vZGlmaWVyLCBrZXkpIHtcbiAgdmFyIG1vZHMgPSBrZXkuc2xpY2UoMCwga2V5Lmxlbmd0aCAtIDEpO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IG1vZHMubGVuZ3RoOyBpKyspIHtcbiAgICBtb2RzW2ldID0gbW9kaWZpZXJbbW9kc1tpXS50b0xvd2VyQ2FzZSgpXTtcbiAgfXJldHVybiBtb2RzO1xufVxuXG4vLyDlpITnkIbkvKDnmoRrZXnlrZfnrKbkuLLovazmjaLmiJDmlbDnu4RcbmZ1bmN0aW9uIGdldEtleXMoa2V5KSB7XG4gIGlmICgha2V5KSBrZXkgPSAnJztcblxuICBrZXkgPSBrZXkucmVwbGFjZSgvXFxzL2csICcnKTsgLy8g5Yy56YWN5Lu75L2V56m655m95a2X56ymLOWMheaLrOepuuagvOOAgeWItuihqOespuOAgeaNoumhteespuetieetiVxuICB2YXIga2V5cyA9IGtleS5zcGxpdCgnLCcpOyAvLyDlkIzml7borr7nva7lpJrkuKrlv6vmjbfplK7vvIzku6UnLCfliIblibJcbiAgdmFyIGluZGV4ID0ga2V5cy5sYXN0SW5kZXhPZignJyk7XG5cbiAgLy8g5b+r5o236ZSu5Y+v6IO95YyF5ZCrJywn77yM6ZyA54m55q6K5aSE55CGXG4gIGZvciAoOyBpbmRleCA+PSAwOykge1xuICAgIGtleXNbaW5kZXggLSAxXSArPSAnLCc7XG4gICAga2V5cy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgIGluZGV4ID0ga2V5cy5sYXN0SW5kZXhPZignJyk7XG4gIH1cblxuICByZXR1cm4ga2V5cztcbn1cblxuLy8g5q+U6L6D5L+u6aWw6ZSu55qE5pWw57uEXG5mdW5jdGlvbiBjb21wYXJlQXJyYXkoYTEsIGEyKSB7XG4gIHZhciBhcnIxID0gYTEubGVuZ3RoID49IGEyLmxlbmd0aCA/IGExIDogYTI7XG4gIHZhciBhcnIyID0gYTEubGVuZ3RoID49IGEyLmxlbmd0aCA/IGEyIDogYTE7XG4gIHZhciBpc0luZGV4ID0gdHJ1ZTtcblxuICBmb3IgKHZhciBpID0gMDsgaSA8IGFycjEubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoYXJyMi5pbmRleE9mKGFycjFbaV0pID09PSAtMSkgaXNJbmRleCA9IGZhbHNlO1xuICB9XG4gIHJldHVybiBpc0luZGV4O1xufVxuXG52YXIgX2tleU1hcCA9IHsgLy8g54m55q6K6ZSuXG4gIGJhY2tzcGFjZTogOCxcbiAgdGFiOiA5LFxuICBjbGVhcjogMTIsXG4gIGVudGVyOiAxMyxcbiAgcmV0dXJuOiAxMyxcbiAgZXNjOiAyNyxcbiAgZXNjYXBlOiAyNyxcbiAgc3BhY2U6IDMyLFxuICBsZWZ0OiAzNyxcbiAgdXA6IDM4LFxuICByaWdodDogMzksXG4gIGRvd246IDQwLFxuICBkZWw6IDQ2LFxuICBkZWxldGU6IDQ2LFxuICBpbnM6IDQ1LFxuICBpbnNlcnQ6IDQ1LFxuICBob21lOiAzNixcbiAgZW5kOiAzNSxcbiAgcGFnZXVwOiAzMyxcbiAgcGFnZWRvd246IDM0LFxuICBjYXBzbG9jazogMjAsXG4gICfih6onOiAyMCxcbiAgJywnOiAxODgsXG4gICcuJzogMTkwLFxuICAnLyc6IDE5MSxcbiAgJ2AnOiAxOTIsXG4gICctJzogaXNmZiA/IDE3MyA6IDE4OSxcbiAgJz0nOiBpc2ZmID8gNjEgOiAxODcsXG4gICc7JzogaXNmZiA/IDU5IDogMTg2LFxuICAnXFwnJzogMjIyLFxuICAnWyc6IDIxOSxcbiAgJ10nOiAyMjEsXG4gICdcXFxcJzogMjIwXG59O1xuXG52YXIgX21vZGlmaWVyID0geyAvLyDkv67ppbDplK5cbiAgJ+KHpyc6IDE2LFxuICBzaGlmdDogMTYsXG4gICfijKUnOiAxOCxcbiAgYWx0OiAxOCxcbiAgb3B0aW9uOiAxOCxcbiAgJ+KMgyc6IDE3LFxuICBjdHJsOiAxNyxcbiAgY29udHJvbDogMTcsXG4gICfijJgnOiBpc2ZmID8gMjI0IDogOTEsXG4gIGNtZDogaXNmZiA/IDIyNCA6IDkxLFxuICBjb21tYW5kOiBpc2ZmID8gMjI0IDogOTFcbn07XG52YXIgX2Rvd25LZXlzID0gW107IC8vIOiusOW9leaRgeS4i+eahOe7keWumumUrlxudmFyIG1vZGlmaWVyTWFwID0ge1xuICAxNjogJ3NoaWZ0S2V5JyxcbiAgMTg6ICdhbHRLZXknLFxuICAxNzogJ2N0cmxLZXknXG59O1xudmFyIF9tb2RzID0geyAxNjogZmFsc2UsIDE4OiBmYWxzZSwgMTc6IGZhbHNlIH07XG52YXIgX2hhbmRsZXJzID0ge307XG5cbi8vIEYxfkYxMiDnibnmrorplK5cbmZvciAodmFyIGsgPSAxOyBrIDwgMjA7IGsrKykge1xuICBfa2V5TWFwWydmJyArIGtdID0gMTExICsgaztcbn1cblxuLy8g5YW85a65RmlyZWZveOWkhOeQhlxubW9kaWZpZXJNYXBbaXNmZiA/IDIyNCA6IDkxXSA9ICdtZXRhS2V5Jztcbl9tb2RzW2lzZmYgPyAyMjQgOiA5MV0gPSBmYWxzZTtcblxudmFyIF9zY29wZSA9ICdhbGwnOyAvLyDpu5jorqTng63plK7ojIPlm7RcbnZhciBpc0JpbmRFbGVtZW50ID0gZmFsc2U7IC8vIOaYr+WQpue7keWumuiKgueCuVxuXG4vLyDov5Tlm57plK7noIFcbnZhciBjb2RlID0gZnVuY3Rpb24gY29kZSh4KSB7XG4gIHJldHVybiBfa2V5TWFwW3gudG9Mb3dlckNhc2UoKV0gfHwgeC50b1VwcGVyQ2FzZSgpLmNoYXJDb2RlQXQoMCk7XG59O1xuXG4vLyDorr7nva7ojrflj5blvZPliY3ojIPlm7TvvIjpu5jorqTkuLon5omA5pyJJ++8iVxuZnVuY3Rpb24gc2V0U2NvcGUoc2NvcGUpIHtcbiAgX3Njb3BlID0gc2NvcGUgfHwgJ2FsbCc7XG59XG4vLyDojrflj5blvZPliY3ojIPlm7RcbmZ1bmN0aW9uIGdldFNjb3BlKCkge1xuICByZXR1cm4gX3Njb3BlIHx8ICdhbGwnO1xufVxuLy8g6I635Y+W5pGB5LiL57uR5a6a6ZSu55qE6ZSu5YC8XG5mdW5jdGlvbiBnZXRQcmVzc2VkS2V5Q29kZXMoKSB7XG4gIHJldHVybiBfZG93bktleXMuc2xpY2UoMCk7XG59XG5cbi8vIOihqOWNleaOp+S7tuaOp+S7tuWIpOaWrSDov5Tlm54gQm9vbGVhblxuZnVuY3Rpb24gZmlsdGVyKGV2ZW50KSB7XG4gIHZhciB0YWdOYW1lID0gZXZlbnQudGFyZ2V0LnRhZ05hbWUgfHwgZXZlbnQuc3JjRWxlbWVudC50YWdOYW1lO1xuICAvLyDlv73nlaXov5nkupvmoIfnrb7mg4XlhrXkuIvlv6vmjbfplK7ml6DmlYhcbiAgcmV0dXJuICEodGFnTmFtZSA9PT0gJ0lOUFVUJyB8fCB0YWdOYW1lID09PSAnU0VMRUNUJyB8fCB0YWdOYW1lID09PSAnVEVYVEFSRUEnKTtcbn1cblxuLy8g5Yik5pat5pGB5LiL55qE6ZSu5piv5ZCm5Li65p+Q5Liq6ZSu77yM6L+U5ZuedHJ1ZeaIluiAhWZhbHNlXG5mdW5jdGlvbiBpc1ByZXNzZWQoa2V5Q29kZSkge1xuICBpZiAodHlwZW9mIGtleUNvZGUgPT09ICdzdHJpbmcnKSB7XG4gICAga2V5Q29kZSA9IGNvZGUoa2V5Q29kZSk7IC8vIOi9rOaNouaIkOmUrueggVxuICB9XG4gIHJldHVybiBfZG93bktleXMuaW5kZXhPZihrZXlDb2RlKSAhPT0gLTE7XG59XG5cbi8vIOW+queOr+WIoOmZpGhhbmRsZXJz5Lit55qE5omA5pyJIHNjb3BlKOiMg+WbtClcbmZ1bmN0aW9uIGRlbGV0ZVNjb3BlKHNjb3BlLCBuZXdTY29wZSkge1xuICB2YXIgaGFuZGxlcnMgPSB2b2lkIDA7XG4gIHZhciBpID0gdm9pZCAwO1xuXG4gIC8vIOayoeacieaMh+WumnNjb3Bl77yM6I635Y+Wc2NvcGVcbiAgaWYgKCFzY29wZSkgc2NvcGUgPSBnZXRTY29wZSgpO1xuXG4gIGZvciAodmFyIGtleSBpbiBfaGFuZGxlcnMpIHtcbiAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKF9oYW5kbGVycywga2V5KSkge1xuICAgICAgaGFuZGxlcnMgPSBfaGFuZGxlcnNba2V5XTtcbiAgICAgIGZvciAoaSA9IDA7IGkgPCBoYW5kbGVycy5sZW5ndGg7KSB7XG4gICAgICAgIGlmIChoYW5kbGVyc1tpXS5zY29wZSA9PT0gc2NvcGUpIGhhbmRsZXJzLnNwbGljZShpLCAxKTtlbHNlIGkrKztcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyDlpoLmnpxzY29wZeiiq+WIoOmZpO+8jOWwhnNjb3Bl6YeN572u5Li6YWxsXG4gIGlmIChnZXRTY29wZSgpID09PSBzY29wZSkgc2V0U2NvcGUobmV3U2NvcGUgfHwgJ2FsbCcpO1xufVxuXG4vLyDmuIXpmaTkv67ppbDplK5cbmZ1bmN0aW9uIGNsZWFyTW9kaWZpZXIoZXZlbnQpIHtcbiAgdmFyIGtleSA9IGV2ZW50LmtleUNvZGUgfHwgZXZlbnQud2hpY2ggfHwgZXZlbnQuY2hhckNvZGU7XG4gIHZhciBpID0gX2Rvd25LZXlzLmluZGV4T2Yoa2V5KTtcblxuICAvLyDku47liJfooajkuK3muIXpmaTmjInljovov4fnmoTplK5cbiAgaWYgKGkgPj0gMCkgX2Rvd25LZXlzLnNwbGljZShpLCAxKTtcblxuICAvLyDkv67ppbDplK4gc2hpZnRLZXkgYWx0S2V5IGN0cmxLZXkgKGNvbW1hbmR8fG1ldGFLZXkpIOa4hemZpFxuICBpZiAoa2V5ID09PSA5MyB8fCBrZXkgPT09IDIyNCkga2V5ID0gOTE7XG4gIGlmIChrZXkgaW4gX21vZHMpIHtcbiAgICBfbW9kc1trZXldID0gZmFsc2U7XG5cbiAgICAvLyDlsIbkv67ppbDplK7ph43nva7kuLpmYWxzZVxuICAgIGZvciAodmFyIGsgaW4gX21vZGlmaWVyKSB7XG4gICAgICBpZiAoX21vZGlmaWVyW2tdID09PSBrZXkpIGhvdGtleXNba10gPSBmYWxzZTtcbiAgICB9XG4gIH1cbn1cblxuLy8g6Kej6Zmk57uR5a6a5p+Q5Liq6IyD5Zu055qE5b+r5o236ZSuXG5mdW5jdGlvbiB1bmJpbmQoa2V5LCBzY29wZSkge1xuICB2YXIgbXVsdGlwbGVLZXlzID0gZ2V0S2V5cyhrZXkpO1xuICB2YXIga2V5cyA9IHZvaWQgMDtcbiAgdmFyIG1vZHMgPSBbXTtcbiAgdmFyIG9iaiA9IHZvaWQgMDtcblxuICBmb3IgKHZhciBpID0gMDsgaSA8IG11bHRpcGxlS2V5cy5sZW5ndGg7IGkrKykge1xuICAgIC8vIOWwhue7hOWQiOW/q+aNt+mUruaLhuWIhuS4uuaVsOe7hFxuICAgIGtleXMgPSBtdWx0aXBsZUtleXNbaV0uc3BsaXQoJysnKTtcblxuICAgIC8vIOiusOW9leavj+S4que7hOWQiOmUruS4reeahOS/rumlsOmUrueahOmUrueggSDov5Tlm57mlbDnu4RcbiAgICBpZiAoa2V5cy5sZW5ndGggPiAxKSBtb2RzID0gZ2V0TW9kcyhfbW9kaWZpZXIsIGtleXMpO1xuXG4gICAgLy8g6I635Y+W6Zmk5L+u6aWw6ZSu5aSW55qE6ZSu5YC8a2V5XG4gICAga2V5ID0ga2V5c1trZXlzLmxlbmd0aCAtIDFdO1xuICAgIGtleSA9IGtleSA9PT0gJyonID8gJyonIDogY29kZShrZXkpO1xuXG4gICAgLy8g5Yik5pat5piv5ZCm5Lyg5YWl6IyD5Zu077yM5rKh5pyJ5bCx6I635Y+W6IyD5Zu0XG4gICAgaWYgKCFzY29wZSkgc2NvcGUgPSBnZXRTY29wZSgpO1xuXG4gICAgLy8g5aaC5L2Va2V55LiN5ZyoIF9oYW5kbGVycyDkuK3ov5Tlm57kuI3lgZrlpITnkIZcbiAgICBpZiAoIV9oYW5kbGVyc1trZXldKSByZXR1cm47XG5cbiAgICAvLyDmuIXnqbogaGFuZGxlcnMg5Lit5pWw5o2u77yMXG4gICAgLy8g6K6p6Kem5Y+R5b+r5o236ZSu6ZSu5LmL5ZCO5rKh5pyJ5LqL5Lu25omn6KGM5Yiw6L6+6Kej6Zmk5b+r5o236ZSu57uR5a6a55qE55uu55qEXG4gICAgZm9yICh2YXIgciA9IDA7IHIgPCBfaGFuZGxlcnNba2V5XS5sZW5ndGg7IHIrKykge1xuICAgICAgb2JqID0gX2hhbmRsZXJzW2tleV1bcl07XG4gICAgICAvLyDliKTmlq3mmK/lkKblnKjojIPlm7TlhoXlubbkuJTplK7lgLznm7jlkIxcbiAgICAgIGlmIChvYmouc2NvcGUgPT09IHNjb3BlICYmIGNvbXBhcmVBcnJheShvYmoubW9kcywgbW9kcykpIHtcbiAgICAgICAgX2hhbmRsZXJzW2tleV1bcl0gPSB7fTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuLy8g5a+555uR5ZCs5a+55bqU5b+r5o236ZSu55qE5Zue6LCD5Ye95pWw6L+b6KGM5aSE55CGXG5mdW5jdGlvbiBldmVudEhhbmRsZXIoZXZlbnQsIGhhbmRsZXIsIHNjb3BlKSB7XG4gIHZhciBtb2RpZmllcnNNYXRjaCA9IHZvaWQgMDtcblxuICAvLyDnnIvlroPmmK/lkKblnKjlvZPliY3ojIPlm7RcbiAgaWYgKGhhbmRsZXIuc2NvcGUgPT09IHNjb3BlIHx8IGhhbmRsZXIuc2NvcGUgPT09ICdhbGwnKSB7XG4gICAgLy8g5qOA5p+l5piv5ZCm5Yy56YWN5L+u6aWw56ym77yI5aaC5p6c5pyJ6L+U5ZuedHJ1Ze+8iVxuICAgIG1vZGlmaWVyc01hdGNoID0gaGFuZGxlci5tb2RzLmxlbmd0aCA+IDA7XG5cbiAgICBmb3IgKHZhciB5IGluIF9tb2RzKSB7XG4gICAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKF9tb2RzLCB5KSkge1xuICAgICAgICBpZiAoIV9tb2RzW3ldICYmIGhhbmRsZXIubW9kcy5pbmRleE9mKCt5KSA+IC0xIHx8IF9tb2RzW3ldICYmIGhhbmRsZXIubW9kcy5pbmRleE9mKCt5KSA9PT0gLTEpIG1vZGlmaWVyc01hdGNoID0gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8g6LCD55So5aSE55CG56iL5bqP77yM5aaC5p6c5piv5L+u6aWw6ZSu5LiN5YGa5aSE55CGXG4gICAgaWYgKGhhbmRsZXIubW9kcy5sZW5ndGggPT09IDAgJiYgIV9tb2RzWzE2XSAmJiAhX21vZHNbMThdICYmICFfbW9kc1sxN10gJiYgIV9tb2RzWzkxXSB8fCBtb2RpZmllcnNNYXRjaCB8fCBoYW5kbGVyLnNob3J0Y3V0ID09PSAnKicpIHtcbiAgICAgIGlmIChoYW5kbGVyLm1ldGhvZChldmVudCwgaGFuZGxlcikgPT09IGZhbHNlKSB7XG4gICAgICAgIGlmIChldmVudC5wcmV2ZW50RGVmYXVsdCkgZXZlbnQucHJldmVudERlZmF1bHQoKTtlbHNlIGV2ZW50LnJldHVyblZhbHVlID0gZmFsc2U7XG4gICAgICAgIGlmIChldmVudC5zdG9wUHJvcGFnYXRpb24pIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICBpZiAoZXZlbnQuY2FuY2VsQnViYmxlKSBldmVudC5jYW5jZWxCdWJibGUgPSB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4vLyDlpITnkIZrZXlkb3du5LqL5Lu2XG5mdW5jdGlvbiBkaXNwYXRjaChldmVudCkge1xuICB2YXIgYXN0ZXJpc2sgPSBfaGFuZGxlcnNbJyonXTtcbiAgdmFyIGtleSA9IGV2ZW50LmtleUNvZGUgfHwgZXZlbnQud2hpY2ggfHwgZXZlbnQuY2hhckNvZGU7XG5cbiAgLy8g5pCc6ZuG57uR5a6a55qE6ZSuXG4gIGlmIChfZG93bktleXMuaW5kZXhPZihrZXkpID09PSAtMSkgX2Rvd25LZXlzLnB1c2goa2V5KTtcblxuICAvLyBHZWNrbyhGaXJlZm94KeeahGNvbW1hbmTplK7lgLwyMjTvvIzlnKhXZWJraXQoQ2hyb21lKeS4reS/neaMgeS4gOiHtFxuICAvLyBXZWJraXTlt6blj7Njb21tYW5k6ZSu5YC85LiN5LiA5qC3XG4gIGlmIChrZXkgPT09IDkzIHx8IGtleSA9PT0gMjI0KSBrZXkgPSA5MTtcblxuICBpZiAoa2V5IGluIF9tb2RzKSB7XG4gICAgX21vZHNba2V5XSA9IHRydWU7XG5cbiAgICAvLyDlsIbnibnmrorlrZfnrKbnmoRrZXnms6jlhozliLAgaG90a2V5cyDkuIpcbiAgICBmb3IgKHZhciBrIGluIF9tb2RpZmllcikge1xuICAgICAgaWYgKF9tb2RpZmllcltrXSA9PT0ga2V5KSBob3RrZXlzW2tdID0gdHJ1ZTtcbiAgICB9XG5cbiAgICBpZiAoIWFzdGVyaXNrKSByZXR1cm47XG4gIH1cblxuICAvLyDlsIZtb2RpZmllck1hcOmHjOmdoueahOS/rumlsOmUrue7keWumuWIsGV2ZW505LitXG4gIGZvciAodmFyIGUgaW4gX21vZHMpIHtcbiAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKF9tb2RzLCBlKSkge1xuICAgICAgX21vZHNbZV0gPSBldmVudFttb2RpZmllck1hcFtlXV07XG4gICAgfVxuICB9XG5cbiAgLy8g6KGo5Y2V5o6n5Lu26L+H5rukIOm7mOiupOihqOWNleaOp+S7tuS4jeinpuWPkeW/q+aNt+mUrlxuICBpZiAoIWhvdGtleXMuZmlsdGVyLmNhbGwodGhpcywgZXZlbnQpKSByZXR1cm47XG5cbiAgLy8g6I635Y+W6IyD5Zu0IOm7mOiupOS4umFsbFxuICB2YXIgc2NvcGUgPSBnZXRTY29wZSgpO1xuXG4gIC8vIOWvueS7u+S9leW/q+aNt+mUrumDvemcgOimgeWBmueahOWkhOeQhlxuICBpZiAoYXN0ZXJpc2spIHtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFzdGVyaXNrLmxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAoYXN0ZXJpc2tbaV0uc2NvcGUgPT09IHNjb3BlKSBldmVudEhhbmRsZXIoZXZlbnQsIGFzdGVyaXNrW2ldLCBzY29wZSk7XG4gICAgfVxuICB9XG4gIC8vIGtleSDkuI3lnKhfaGFuZGxlcnPkuK3ov5Tlm55cbiAgaWYgKCEoa2V5IGluIF9oYW5kbGVycykpIHJldHVybjtcblxuICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgX2hhbmRsZXJzW2tleV0ubGVuZ3RoOyBfaSsrKSB7XG4gICAgLy8g5om+5Yiw5aSE55CG5YaF5a65XG4gICAgZXZlbnRIYW5kbGVyKGV2ZW50LCBfaGFuZGxlcnNba2V5XVtfaV0sIHNjb3BlKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBob3RrZXlzKGtleSwgb3B0aW9uLCBtZXRob2QpIHtcbiAgdmFyIGtleXMgPSBnZXRLZXlzKGtleSk7IC8vIOmcgOimgeWkhOeQhueahOW/q+aNt+mUruWIl+ihqFxuICB2YXIgbW9kcyA9IFtdO1xuICB2YXIgc2NvcGUgPSAnYWxsJzsgLy8gc2NvcGXpu5jorqTkuLphbGzvvIzmiYDmnInojIPlm7Tpg73mnInmlYhcbiAgdmFyIGVsZW1lbnQgPSBkb2N1bWVudDsgLy8g5b+r5o236ZSu5LqL5Lu257uR5a6a6IqC54K5XG4gIHZhciBpID0gMDtcblxuICAvLyDlr7nkuLrorr7lrprojIPlm7TnmoTliKTmlq1cbiAgaWYgKG1ldGhvZCA9PT0gdW5kZWZpbmVkICYmIHR5cGVvZiBvcHRpb24gPT09ICdmdW5jdGlvbicpIHtcbiAgICBtZXRob2QgPSBvcHRpb247XG4gIH1cblxuICBpZiAoT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG9wdGlvbikgPT09ICdbb2JqZWN0IE9iamVjdF0nKSB7XG4gICAgaWYgKG9wdGlvbi5zY29wZSkgc2NvcGUgPSBvcHRpb24uc2NvcGU7IC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbiAgICBpZiAob3B0aW9uLmVsZW1lbnQpIGVsZW1lbnQgPSBvcHRpb24uZWxlbWVudDsgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuICB9XG5cbiAgaWYgKHR5cGVvZiBvcHRpb24gPT09ICdzdHJpbmcnKSBzY29wZSA9IG9wdGlvbjtcblxuICAvLyDlr7nkuo7mr4/kuKrlv6vmjbfplK7ov5vooYzlpITnkIZcbiAgZm9yICg7IGkgPCBrZXlzLmxlbmd0aDsgaSsrKSB7XG4gICAga2V5ID0ga2V5c1tpXS5zcGxpdCgnKycpOyAvLyDmjInplK7liJfooahcbiAgICBtb2RzID0gW107XG5cbiAgICAvLyDlpoLmnpzmmK/nu4TlkIjlv6vmjbfplK7lj5blvpfnu4TlkIjlv6vmjbfplK5cbiAgICBpZiAoa2V5Lmxlbmd0aCA+IDEpIG1vZHMgPSBnZXRNb2RzKF9tb2RpZmllciwga2V5KTtcblxuICAgIC8vIOWwhumdnuS/rumlsOmUrui9rOWMluS4uumUrueggVxuICAgIGtleSA9IGtleVtrZXkubGVuZ3RoIC0gMV07XG4gICAga2V5ID0ga2V5ID09PSAnKicgPyAnKicgOiBjb2RlKGtleSk7IC8vICrooajnpLrljLnphY3miYDmnInlv6vmjbfplK5cblxuICAgIC8vIOWIpOaWrWtleeaYr+WQpuWcqF9oYW5kbGVyc+S4re+8jOS4jeWcqOWwsei1i+S4gOS4quepuuaVsOe7hFxuICAgIGlmICghKGtleSBpbiBfaGFuZGxlcnMpKSBfaGFuZGxlcnNba2V5XSA9IFtdO1xuXG4gICAgX2hhbmRsZXJzW2tleV0ucHVzaCh7XG4gICAgICBzY29wZTogc2NvcGUsXG4gICAgICBtb2RzOiBtb2RzLFxuICAgICAgc2hvcnRjdXQ6IGtleXNbaV0sXG4gICAgICBtZXRob2Q6IG1ldGhvZCxcbiAgICAgIGtleToga2V5c1tpXVxuICAgIH0pO1xuICB9XG4gIC8vIOWcqOWFqOWxgGRvY3VtZW505LiK6K6+572u5b+r5o236ZSuXG4gIGlmICh0eXBlb2YgZWxlbWVudCAhPT0gJ3VuZGVmaW5lZCcgJiYgIWlzQmluZEVsZW1lbnQpIHtcbiAgICBpc0JpbmRFbGVtZW50ID0gdHJ1ZTtcbiAgICBhZGRFdmVudChlbGVtZW50LCAna2V5ZG93bicsIGZ1bmN0aW9uIChlKSB7XG4gICAgICBkaXNwYXRjaChlKTtcbiAgICB9KTtcbiAgICBhZGRFdmVudChlbGVtZW50LCAna2V5dXAnLCBmdW5jdGlvbiAoZSkge1xuICAgICAgY2xlYXJNb2RpZmllcihlKTtcbiAgICB9KTtcbiAgfVxufVxuXG52YXIgX2FwaSA9IHtcbiAgc2V0U2NvcGU6IHNldFNjb3BlLFxuICBnZXRTY29wZTogZ2V0U2NvcGUsXG4gIGRlbGV0ZVNjb3BlOiBkZWxldGVTY29wZSxcbiAgZ2V0UHJlc3NlZEtleUNvZGVzOiBnZXRQcmVzc2VkS2V5Q29kZXMsXG4gIGlzUHJlc3NlZDogaXNQcmVzc2VkLFxuICBmaWx0ZXI6IGZpbHRlcixcbiAgdW5iaW5kOiB1bmJpbmRcbn07XG5mb3IgKHZhciBhIGluIF9hcGkpIHtcbiAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChfYXBpLCBhKSkge1xuICAgIGhvdGtleXNbYV0gPSBfYXBpW2FdO1xuICB9XG59XG5cbmlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICB2YXIgX2hvdGtleXMgPSB3aW5kb3cuaG90a2V5cztcbiAgaG90a2V5cy5ub0NvbmZsaWN0ID0gZnVuY3Rpb24gKGRlZXApIHtcbiAgICBpZiAoZGVlcCAmJiB3aW5kb3cuaG90a2V5cyA9PT0gaG90a2V5cykge1xuICAgICAgd2luZG93LmhvdGtleXMgPSBfaG90a2V5cztcbiAgICB9XG4gICAgcmV0dXJuIGhvdGtleXM7XG4gIH07XG4gIHdpbmRvdy5ob3RrZXlzID0gaG90a2V5cztcbn1cblxuZXhwb3J0IGRlZmF1bHQgaG90a2V5cztcbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcblxuZXhwb3J0IGNsYXNzIEhhbmRsZXMgZXh0ZW5kcyBIVE1MRWxlbWVudCB7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuICAgIHRoaXMuJHNoYWRvdyA9IHRoaXMuYXR0YWNoU2hhZG93KHttb2RlOiAnY2xvc2VkJ30pXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdGhpcy5vbl9yZXNpemUuYmluZCh0aGlzKSlcbiAgfVxuICBkaXNjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdGhpcy5vbl9yZXNpemUpXG4gIH1cblxuICBvbl9yZXNpemUoKSB7XG4gICAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICBjb25zdCBub2RlX2xhYmVsX2lkID0gdGhpcy4kc2hhZG93Lmhvc3QuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJylcbiAgICAgIGNvbnN0IFtzb3VyY2VfZWxdID0gJChgW2RhdGEtbGFiZWwtaWQ9XCIke25vZGVfbGFiZWxfaWR9XCJdYClcblxuICAgICAgaWYgKCFzb3VyY2VfZWwpIHJldHVyblxuXG4gICAgICB0aGlzLnBvc2l0aW9uID0ge1xuICAgICAgICBub2RlX2xhYmVsX2lkLFxuICAgICAgICBib3VuZGluZ1JlY3Q6IHNvdXJjZV9lbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSxcbiAgICAgIH1cbiAgICB9KVxuICB9XG5cbiAgc2V0IHBvc2l0aW9uKHtib3VuZGluZ1JlY3QsIG5vZGVfbGFiZWxfaWR9KSB7XG4gICAgdGhpcy4kc2hhZG93LmlubmVySFRNTCAgPSB0aGlzLnJlbmRlcihib3VuZGluZ1JlY3QsIG5vZGVfbGFiZWxfaWQpXG4gIH1cblxuICByZW5kZXIoeyB4LCB5LCB3aWR0aCwgaGVpZ2h0LCB0b3AsIGxlZnQgfSwgbm9kZV9sYWJlbF9pZCkge1xuICAgIHRoaXMuJHNoYWRvdy5ob3N0LnNldEF0dHJpYnV0ZSgnZGF0YS1sYWJlbC1pZCcsIG5vZGVfbGFiZWxfaWQpXG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoe3RvcCxsZWZ0fSl9XG4gICAgICA8c3ZnXG4gICAgICAgIGNsYXNzPVwidmlzYnVnLWhhbmRsZXNcIlxuICAgICAgICB3aWR0aD1cIiR7d2lkdGh9XCIgaGVpZ2h0PVwiJHtoZWlnaHR9XCJcbiAgICAgICAgdmlld0JveD1cIjAgMCAke3dpZHRofSAke2hlaWdodH1cIlxuICAgICAgICB2ZXJzaW9uPVwiMS4xXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgICA+XG4gICAgICAgIDxyZWN0IHN0cm9rZT1cImhvdHBpbmtcIiBmaWxsPVwibm9uZVwiIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIj48L3JlY3Q+XG4gICAgICAgIDxjaXJjbGUgc3Ryb2tlPVwiaG90cGlua1wiIGZpbGw9XCJ3aGl0ZVwiIGN4PVwiMFwiIGN5PVwiMFwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICAgIDxjaXJjbGUgc3Ryb2tlPVwiaG90cGlua1wiIGZpbGw9XCJ3aGl0ZVwiIGN4PVwiMTAwJVwiIGN5PVwiMFwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICAgIDxjaXJjbGUgc3Ryb2tlPVwiaG90cGlua1wiIGZpbGw9XCJ3aGl0ZVwiIGN4PVwiMTAwJVwiIGN5PVwiMTAwJVwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICAgIDxjaXJjbGUgc3Ryb2tlPVwiaG90cGlua1wiIGZpbGw9XCJ3aGl0ZVwiIGN4PVwiMFwiIGN5PVwiMTAwJVwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICAgIDxjaXJjbGUgZmlsbD1cImhvdHBpbmtcIiBjeD1cIiR7d2lkdGgvMn1cIiBjeT1cIjBcIiByPVwiMlwiPjwvY2lyY2xlPlxuICAgICAgICA8Y2lyY2xlIGZpbGw9XCJob3RwaW5rXCIgY3g9XCIwXCIgY3k9XCIke2hlaWdodC8yfVwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICAgIDxjaXJjbGUgZmlsbD1cImhvdHBpbmtcIiBjeD1cIiR7d2lkdGgvMn1cIiBjeT1cIiR7aGVpZ2h0fVwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICAgIDxjaXJjbGUgZmlsbD1cImhvdHBpbmtcIiBjeD1cIiR7d2lkdGh9XCIgY3k9XCIke2hlaWdodC8yfVwiIHI9XCIyXCI+PC9jaXJjbGU+XG4gICAgICA8L3N2Zz5cbiAgICBgXG4gIH1cblxuICBzdHlsZXMoe3RvcCxsZWZ0fSkge1xuICAgIHJldHVybiBgXG4gICAgICA8c3R5bGU+XG4gICAgICAgIDpob3N0ID4gc3ZnIHtcbiAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgdG9wOiAke3RvcCArIHdpbmRvdy5zY3JvbGxZfXB4O1xuICAgICAgICAgIGxlZnQ6ICR7bGVmdH1weDtcbiAgICAgICAgICBvdmVyZmxvdzogdmlzaWJsZTtcbiAgICAgICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICAgICAgICB6LWluZGV4OiAyMTQ3NDgzNjQ0O1xuICAgICAgICB9XG4gICAgICA8L3N0eWxlPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ3Zpc2J1Zy1oYW5kbGVzJywgSGFuZGxlcylcbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCB7IEhhbmRsZXMgfSBmcm9tICcuL2hhbmRsZXMuZWxlbWVudCdcblxuZXhwb3J0IGNsYXNzIEhvdmVyIGV4dGVuZHMgSGFuZGxlcyB7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuICB9XG5cbiAgcmVuZGVyKHsgeCwgeSwgd2lkdGgsIGhlaWdodCwgdG9wLCBsZWZ0IH0pIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcyh7dG9wLGxlZnR9KX1cbiAgICAgIDxzdHlsZT5cbiAgICAgICAgOmhvc3QgcmVjdCB7XG4gICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICAgIHZlY3Rvci1lZmZlY3Q6IG5vbi1zY2FsaW5nLXN0cm9rZTtcbiAgICAgICAgICBzdHJva2U6IGhzbCgyNjcsIDEwMCUsIDU4JSk7XG4gICAgICAgICAgc3Ryb2tlLXdpZHRoOiAxcHg7XG4gICAgICAgICAgZmlsbDogbm9uZTtcbiAgICAgICAgfVxuXG4gICAgICAgIDpob3N0ID4gc3ZnIHtcbiAgICAgICAgICB6LWluZGV4OiAyMTQ3NDgzNjQyO1xuICAgICAgICB9XG4gICAgICA8L3N0eWxlPlxuICAgICAgPHN2ZyB3aWR0aD1cIiR7d2lkdGh9XCIgaGVpZ2h0PVwiJHtoZWlnaHR9XCI+XG4gICAgICAgIDxyZWN0PjwvcmVjdD5cbiAgICAgIDwvc3ZnPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ3Zpc2J1Zy1ob3ZlcicsIEhvdmVyKVxuIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuXG5leHBvcnQgY2xhc3MgTGFiZWwgZXh0ZW5kcyBIVE1MRWxlbWVudCB7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuICAgIHRoaXMuJHNoYWRvdyA9IHRoaXMuYXR0YWNoU2hhZG93KHttb2RlOiAnY2xvc2VkJ30pXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICAkKCdhJywgdGhpcy4kc2hhZG93KS5vbignY2xpY2sgbW91c2VlbnRlcicsIHRoaXMuZGlzcGF0Y2hRdWVyeS5iaW5kKHRoaXMpKVxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCB0aGlzLm9uX3Jlc2l6ZS5iaW5kKHRoaXMpKVxuICB9XG5cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7XG4gICAgJCgnYScsIHRoaXMuJHNoYWRvdykub2ZmKCdjbGljaycsIHRoaXMuZGlzcGF0Y2hRdWVyeSlcbiAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdGhpcy5vbl9yZXNpemUpXG4gIH1cblxuICBvbl9yZXNpemUoKSB7XG4gICAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICBjb25zdCBub2RlX2xhYmVsX2lkID0gdGhpcy4kc2hhZG93Lmhvc3QuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJylcbiAgICAgIGNvbnN0IFtzb3VyY2VfZWxdICAgPSAkKGBbZGF0YS1sYWJlbC1pZD1cIiR7bm9kZV9sYWJlbF9pZH1cIl1gKVxuXG4gICAgICBpZiAoIXNvdXJjZV9lbCkgcmV0dXJuXG5cbiAgICAgIHRoaXMucG9zaXRpb24gPSB7XG4gICAgICAgIG5vZGVfbGFiZWxfaWQsXG4gICAgICAgIGJvdW5kaW5nUmVjdDogc291cmNlX2VsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICBkaXNwYXRjaFF1ZXJ5KGUpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5kaXNwYXRjaEV2ZW50KG5ldyBDdXN0b21FdmVudCgncXVlcnknLCB7XG4gICAgICBidWJibGVzOiB0cnVlLFxuICAgICAgZGV0YWlsOiAgIHtcbiAgICAgICAgdGV4dDogICAgICAgZS50YXJnZXQudGV4dENvbnRlbnQsXG4gICAgICAgIGFjdGl2YXRvcjogIGUudHlwZSxcbiAgICAgIH1cbiAgICB9KSlcbiAgfVxuXG4gIHNldCB0ZXh0KGNvbnRlbnQpIHtcbiAgICB0aGlzLl90ZXh0ID0gY29udGVudFxuICB9XG5cbiAgc2V0IHBvc2l0aW9uKHtib3VuZGluZ1JlY3QsIG5vZGVfbGFiZWxfaWR9KSB7XG4gICAgdGhpcy4kc2hhZG93LmlubmVySFRNTCAgPSB0aGlzLnJlbmRlcihib3VuZGluZ1JlY3QsIG5vZGVfbGFiZWxfaWQpXG4gIH1cblxuICBzZXQgdXBkYXRlKHt4LHl9KSB7XG4gICAgY29uc3QgbGFiZWwgPSB0aGlzLiRzaGFkb3cuY2hpbGRyZW5bMV1cbiAgICBsYWJlbC5zdHlsZS50b3AgID0geSArIHdpbmRvdy5zY3JvbGxZICsgJ3B4J1xuICAgIGxhYmVsLnN0eWxlLmxlZnQgPSB4IC0gMSArICdweCdcbiAgfVxuXG4gIHJlbmRlcih7IHgsIHksIHdpZHRoLCBoZWlnaHQsIHRvcCwgbGVmdCB9LCBub2RlX2xhYmVsX2lkKSB7XG4gICAgdGhpcy4kc2hhZG93Lmhvc3Quc2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJywgbm9kZV9sYWJlbF9pZClcblxuICAgIHJldHVybiBgXG4gICAgICAke3RoaXMuc3R5bGVzKHt0b3AsbGVmdCx3aWR0aH0pfVxuICAgICAgPHNwYW4+XG4gICAgICAgICR7dGhpcy5fdGV4dH1cbiAgICAgIDwvc3Bhbj5cbiAgICBgXG4gIH1cblxuICBzdHlsZXMoe3RvcCxsZWZ0LHdpZHRofSkge1xuICAgIHJldHVybiBgXG4gICAgICA8c3R5bGU+XG4gICAgICAgIDpob3N0IHtcbiAgICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgIH1cblxuICAgICAgICA6aG9zdCA+IHNwYW4ge1xuICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICB0b3A6ICR7dG9wICsgd2luZG93LnNjcm9sbFl9cHg7XG4gICAgICAgICAgbGVmdDogJHtsZWZ0IC0gMX1weDtcbiAgICAgICAgICBtYXgtd2lkdGg6ICR7d2lkdGggKyAod2luZG93LmlubmVyV2lkdGggLSBsZWZ0IC0gd2lkdGggLSAyMCl9cHg7XG4gICAgICAgICAgei1pbmRleDogMjE0NzQ4MzY0MztcbiAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTEwMCUpO1xuICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWxhYmVsLWJnLCBob3RwaW5rKTtcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiAwLjJlbSAwLjJlbSAwIDA7XG4gICAgICAgICAgdGV4dC1zaGFkb3c6IDAgMC41cHggMCBoc2xhKDAsIDAlLCAwJSwgMC40KTtcbiAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgICAgZm9udC1zaXplOiAwLjhlbTtcbiAgICAgICAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgICAgICAgIGZvbnQtZmFtaWx5OiBzeXN0ZW0tdWksIC1hcHBsZS1zeXN0ZW0sIFNlZ29lIFVJLCBSb2JvdG8sIFVidW50dSwgQ2FudGFyZWxsLCBOb3RvIFNhbnMsIHNhbnMtc2VyaWY7XG4gICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICAgICAgICBwYWRkaW5nOiAwLjI1ZW0gMC40ZW0gMC4xNWVtO1xuICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxLjE7XG4gICAgICAgIH1cblxuICAgICAgICA6aG9zdCBhIHtcbiAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gICAgICAgICAgY29sb3I6IGluaGVyaXQ7XG4gICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgIH1cblxuICAgICAgICA6aG9zdCBhOmhvdmVyIHtcbiAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgIH1cblxuICAgICAgICA6aG9zdCBhW25vZGVdOmJlZm9yZSB7XG4gICAgICAgICAgY29udGVudDogXCJcXFxcMDAzY1wiO1xuICAgICAgICB9XG5cbiAgICAgICAgOmhvc3QgYVtub2RlXTphZnRlciB7XG4gICAgICAgICAgY29udGVudDogXCJcXFxcMDAzZVwiO1xuICAgICAgICB9XG4gICAgICA8L3N0eWxlPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ3Zpc2J1Zy1sYWJlbCcsIExhYmVsKVxuIiwiZXhwb3J0IGNvbnN0IGRlc2lyZWRQcm9wTWFwID0ge1xuICBjb2xvcjogICAgICAgICAgICAgICAncmdiKDAsIDAsIDApJyxcbiAgYmFja2dyb3VuZENvbG9yOiAgICAgJ3JnYmEoMCwgMCwgMCwgMCknLFxuICBiYWNrZ3JvdW5kSW1hZ2U6ICAgICAnbm9uZScsXG4gIGJhY2tncm91bmRTaXplOiAgICAgICdhdXRvJyxcbiAgYmFja2dyb3VuZFBvc2l0aW9uOiAgJzAlIDAlJyxcbiAgLy8gYm9yZGVyQ29sb3I6ICAgICAgJ3JnYigwLCAwLCAwKScsXG4gIGJvcmRlcldpZHRoOiAgICAgICAgICcwcHgnLFxuICBib3JkZXJSYWRpdXM6ICAgICAgICAnMHB4JyxcbiAgYm94U2hhZG93OiAgICAgICAgICAgJ25vbmUnLFxuICBwYWRkaW5nOiAgICAgICAgICAgICAnMHB4JyxcbiAgbWFyZ2luOiAgICAgICAgICAgICAgJzBweCcsXG4gIGZvbnRGYW1pbHk6ICAgICAgICAgICcnLFxuICBmb250U2l6ZTogICAgICAgICAgICAnMTZweCcsXG4gIGZvbnRXZWlnaHQ6ICAgICAgICAgICc0MDAnLFxuICB0ZXh0QWxpZ246ICAgICAgICAgICAnc3RhcnQnLFxuICB0ZXh0U2hhZG93OiAgICAgICAgICAnbm9uZScsXG4gIHRleHRUcmFuc2Zvcm06ICAgICAgICdub25lJyxcbiAgbGluZUhlaWdodDogICAgICAgICAgJ25vcm1hbCcsXG4gIGxldHRlclNwYWNpbmc6ICAgICAgICdub3JtYWwnLFxuICBkaXNwbGF5OiAgICAgICAgICAgICAnYmxvY2snLFxuICBhbGlnbkl0ZW1zOiAgICAgICAgICAnbm9ybWFsJyxcbiAganVzdGlmeUNvbnRlbnQ6ICAgICAgJ25vcm1hbCcsXG4gIGZsZXhEaXJlY3Rpb246ICAgICAgICdyb3cnLFxuICBmbGV4V3JhcDogICAgICAgICAgICAnbm93cmFwJyxcbiAgZmxleEJhc2lzOiAgICAgICAgICAgJ2F1dG8nLFxuICAvLyBmbGV4RmxvdzogICAgICAgICAnbm9uZScsXG4gIGZpbGw6ICAgICAgICAgICAgICAgICdyZ2IoMCwgMCwgMCknLFxuICBzdHJva2U6ICAgICAgICAgICAgICAnbm9uZScsXG4gIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICdub25lJyxcbiAgZ3JpZEF1dG9Db2x1bW5zOiAgICAgJ2F1dG8nLFxuICBncmlkVGVtcGxhdGVSb3dzOiAgICAnbm9uZScsXG4gIGdyaWRBdXRvUm93czogICAgICAgICdhdXRvJyxcbiAgZ3JpZFRlbXBsYXRlQXJlYXM6ICAgJ25vbmUnLFxuICBncmlkQXJlYTogICAgICAgICAgICAnYXV0byAvIGF1dG8gLyBhdXRvIC8gYXV0bycsXG4gIGdhcDogICAgICAgICAgICAgICAgICdub3JtYWwgbm9ybWFsJyxcbiAgZ3JpZEF1dG9GbG93OiAgICAgICAgJ3JvdycsXG59XG5cbmV4cG9ydCBjb25zdCBkZXNpcmVkQWNjZXNzaWJpbGl0eU1hcCA9IFtcbiAgJ3JvbGUnLFxuICAndGFiaW5kZXgnLFxuICAnYXJpYS0qJyxcbiAgJ2ZvcicsXG4gICdhbHQnLFxuICAndGl0bGUnLFxuICAndHlwZScsXG5dXG5cbmV4cG9ydCBjb25zdCBsYXJnZVdDQUcyVGV4dE1hcCA9IFtcbiAge1xuICAgIGZvbnRTaXplOiAnMjRweCcsXG4gICAgZm9udFdlaWdodDogJzAnXG4gIH0sXG4gIHtcbiAgICBmb250U2l6ZTogJzE4LjVweCcsXG4gICAgZm9udFdlaWdodDogJzcwMCdcbiAgfVxuXVxuIiwiaW1wb3J0IHsgZGVzaXJlZFByb3BNYXAgfSBmcm9tICcuL2Rlc2lnbi1wcm9wZXJ0aWVzJ1xuXG5leHBvcnQgY29uc3QgZ2V0U3R5bGUgPSAoZWwsIG5hbWUpID0+IHtcbiAgaWYgKGRvY3VtZW50LmRlZmF1bHRWaWV3ICYmIGRvY3VtZW50LmRlZmF1bHRWaWV3LmdldENvbXB1dGVkU3R5bGUpIHtcbiAgICBuYW1lID0gbmFtZS5yZXBsYWNlKC8oW0EtWl0pL2csICctJDEnKVxuICAgIG5hbWUgPSBuYW1lLnRvTG93ZXJDYXNlKClcbiAgICBsZXQgcyA9IGRvY3VtZW50LmRlZmF1bHRWaWV3LmdldENvbXB1dGVkU3R5bGUoZWwsICcnKVxuICAgIHJldHVybiBzICYmIHMuZ2V0UHJvcGVydHlWYWx1ZShuYW1lKVxuICB9IFxufVxuXG5leHBvcnQgY29uc3QgZ2V0U3R5bGVzID0gZWwgPT4ge1xuICBjb25zdCBlbFN0eWxlT2JqZWN0ID0gZWwuc3R5bGVcbiAgY29uc3QgY29tcHV0ZWRTdHlsZSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsLCBudWxsKVxuXG4gIGxldCBkZXNpcmVkVmFsdWVzID0gW11cblxuICBmb3IgKHByb3AgaW4gZWwuc3R5bGUpXG4gICAgaWYgKHByb3AgaW4gZGVzaXJlZFByb3BNYXAgJiYgZGVzaXJlZFByb3BNYXBbcHJvcF0gIT0gY29tcHV0ZWRTdHlsZVtwcm9wXSlcbiAgICAgIGRlc2lyZWRWYWx1ZXMucHVzaCh7XG4gICAgICAgIHByb3AsXG4gICAgICAgIHZhbHVlOiBjb21wdXRlZFN0eWxlW3Byb3BdLnJlcGxhY2UoLywgcmdiYS9nLCAnXFxycmdiYScpXG4gICAgICB9KVxuXG4gIHJldHVybiBkZXNpcmVkVmFsdWVzXG59XG5cbmV4cG9ydCBjb25zdCBnZXRDb21wdXRlZEJhY2tncm91bmRDb2xvciA9IGVsID0+IHtcbiAgbGV0IGJhY2tncm91bmQgPSBnZXRTdHlsZShlbCwgJ2JhY2tncm91bmQtY29sb3InKVxuXG4gIGlmIChiYWNrZ3JvdW5kID09PSAncmdiYSgwLCAwLCAwLCAwKScpIHtcbiAgICBsZXQgbm9kZSAgPSBmaW5kTmVhcmVzdFBhcmVudEVsZW1lbnQoZWwpXG4gICAgICAsIGZvdW5kID0gZmFsc2VcblxuICAgIHdoaWxlKCFmb3VuZCkge1xuICAgICAgbGV0IGJnICA9IGdldFN0eWxlKG5vZGUsICdiYWNrZ3JvdW5kLWNvbG9yJylcblxuICAgICAgaWYgKGJnICE9PSAncmdiYSgwLCAwLCAwLCAwKScpIHtcbiAgICAgICAgZm91bmQgPSB0cnVlXG4gICAgICAgIGJhY2tncm91bmQgPSBiZ1xuICAgICAgfVxuXG4gICAgICBub2RlID0gZmluZE5lYXJlc3RQYXJlbnRFbGVtZW50KG5vZGUpXG5cbiAgICAgIGlmIChub2RlLm5vZGVOYW1lID09PSAnSFRNTCcpIHtcbiAgICAgICAgZm91bmQgPSB0cnVlXG4gICAgICAgIGJhY2tncm91bmQgPSAnd2hpdGUnXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGJhY2tncm91bmRcbn1cblxuZXhwb3J0IGNvbnN0IGZpbmROZWFyZXN0UGFyZW50RWxlbWVudCA9IGVsID0+XG4gIGVsLnBhcmVudE5vZGUgJiYgZWwucGFyZW50Tm9kZS5ub2RlVHlwZSA9PT0gMVxuICAgID8gZWwucGFyZW50Tm9kZVxuICAgIDogZWwucGFyZW50Tm9kZS5ub2RlTmFtZSA9PT0gJyNkb2N1bWVudC1mcmFnbWVudCdcbiAgICAgID8gZWwucGFyZW50Tm9kZS5ob3N0XG4gICAgICA6IGVsLnBhcmVudE5vZGUucGFyZW50Tm9kZS5ob3N0XG5cbmV4cG9ydCBjb25zdCBmaW5kTmVhcmVzdENoaWxkRWxlbWVudCA9IGVsID0+IHtcbiAgaWYgKGVsLnNoYWRvd1Jvb3QgJiYgZWwuc2hhZG93Um9vdC5jaGlsZHJlbi5sZW5ndGgpIHtcbiAgICByZXR1cm4gWy4uLmVsLnNoYWRvd1Jvb3QuY2hpbGRyZW5dXG4gICAgICAuZmlsdGVyKCh7bm9kZU5hbWV9KSA9PiBcbiAgICAgICAgIVsnTElOSycsJ1NUWUxFJywnU0NSSVBUJywnSFRNTCcsJ0hFQUQnXS5pbmNsdWRlcyhub2RlTmFtZSlcbiAgICAgIClbMF1cbiAgfVxuICBlbHNlIGlmIChlbC5jaGlsZHJlbi5sZW5ndGgpXG4gICAgcmV0dXJuIGVsLmNoaWxkcmVuWzBdXG59XG5cbmV4cG9ydCBjb25zdCBsb2FkU3R5bGVzID0gYXN5bmMgc3R5bGVzaGVldHMgPT4ge1xuICBjb25zdCBmZXRjaGVzID0gYXdhaXQgUHJvbWlzZS5hbGwoc3R5bGVzaGVldHMubWFwKHVybCA9PiBmZXRjaCh1cmwpKSlcbiAgY29uc3QgdGV4dHMgICA9IGF3YWl0IFByb21pc2UuYWxsKGZldGNoZXMubWFwKHVybCA9PiB1cmwudGV4dCgpKSlcbiAgY29uc3Qgc3R5bGUgICA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJylcblxuICBzdHlsZS50ZXh0Q29udGVudCA9IHRleHRzLnJlZHVjZSgoc3R5bGVzLCBmaWxlQ29udGVudHMpID0+IFxuICAgIHN0eWxlcyArIGZpbGVDb250ZW50c1xuICAsICcnKVxuXG4gIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoc3R5bGUpXG59XG4iLCJpbXBvcnQgeyBkZXNpcmVkQWNjZXNzaWJpbGl0eU1hcCwgZGVzaXJlZFByb3BNYXAsIGxhcmdlV0NBRzJUZXh0TWFwIH0gZnJvbSAnLi9kZXNpZ24tcHJvcGVydGllcydcbmltcG9ydCB7IGdldFN0eWxlcyB9IGZyb20gJy4vc3R5bGVzJ1xuXG5leHBvcnQgY29uc3QgZ2V0QTExeXMgPSBlbCA9PiB7XG4gIGNvbnN0IGVsQXR0cmlidXRlcyA9IGVsLmdldEF0dHJpYnV0ZU5hbWVzKClcblxuICByZXR1cm4gZGVzaXJlZEFjY2Vzc2liaWxpdHlNYXAucmVkdWNlKChhY2MsIGF0dHJpYnV0ZSkgPT4ge1xuICAgIGlmIChlbEF0dHJpYnV0ZXMuaW5jbHVkZXMoYXR0cmlidXRlKSlcbiAgICAgIGFjYy5wdXNoKHtcbiAgICAgICAgcHJvcDogICBhdHRyaWJ1dGUsXG4gICAgICAgIHZhbHVlOiAgZWwuZ2V0QXR0cmlidXRlKGF0dHJpYnV0ZSlcbiAgICAgIH0pXG5cbiAgICBpZiAoYXR0cmlidXRlID09PSAnYXJpYS0qJylcbiAgICAgIGVsQXR0cmlidXRlcy5mb3JFYWNoKGF0dHIgPT4ge1xuICAgICAgICBpZiAoYXR0ci5pbmNsdWRlcygnYXJpYScpKVxuICAgICAgICAgIGFjYy5wdXNoKHtcbiAgICAgICAgICAgIHByb3A6ICAgYXR0cixcbiAgICAgICAgICAgIHZhbHVlOiAgZWwuZ2V0QXR0cmlidXRlKGF0dHIpXG4gICAgICAgICAgfSlcbiAgICAgIH0pXG5cbiAgICByZXR1cm4gYWNjXG4gIH0sIFtdKVxufVxuXG5leHBvcnQgY29uc3QgZ2V0V0NBRzJUZXh0U2l6ZSA9IGVsID0+IHtcbiAgXG4gIGNvbnN0IHN0eWxlcyA9IGdldFN0eWxlcyhlbCkucmVkdWNlKChzdHlsZU1hcCwgc3R5bGUpID0+IHtcbiAgICAgIHN0eWxlTWFwW3N0eWxlLnByb3BdID0gc3R5bGUudmFsdWVcbiAgICAgIHJldHVybiBzdHlsZU1hcFxuICB9LCB7fSlcblxuICBjb25zdCB7IGZvbnRTaXplICAgPSBkZXNpcmVkUHJvcE1hcC5mb250U2l6ZSxcbiAgICAgICAgICBmb250V2VpZ2h0ID0gZGVzaXJlZFByb3BNYXAuZm9udFdlaWdodFxuICAgICAgfSA9IHN0eWxlc1xuICBcbiAgY29uc3QgaXNMYXJnZSA9IGxhcmdlV0NBRzJUZXh0TWFwLnNvbWUoXG4gICAgKGxhcmdlUHJvcGVydGllcykgPT4gcGFyc2VGbG9hdChmb250U2l6ZSkgPj0gcGFyc2VGbG9hdChsYXJnZVByb3BlcnRpZXMuZm9udFNpemUpIFxuICAgICAgICYmIHBhcnNlRmxvYXQoZm9udFdlaWdodCkgPj0gcGFyc2VGbG9hdChsYXJnZVByb3BlcnRpZXMuZm9udFdlaWdodCkgXG4gIClcblxuICByZXR1cm4gIGlzTGFyZ2UgPyAnTGFyZ2UnIDogJ1NtYWxsJ1xufSIsImV4cG9ydCBjb25zdCBjYW1lbFRvRGFzaCA9IChjYW1lbFN0cmluZyA9IFwiXCIpID0+XG4gIGNhbWVsU3RyaW5nLnJlcGxhY2UoLyhbQS1aXSkvZywgKCQxKSA9PlxuICAgIFwiLVwiKyQxLnRvTG93ZXJDYXNlKCkpXG5cbmV4cG9ydCBjb25zdCBub2RlS2V5ID0gbm9kZSA9PiB7XG4gIGxldCB0cmVlID0gW11cbiAgbGV0IGZ1cnRoZXN0X2xlYWYgPSBub2RlXG5cbiAgd2hpbGUgKGZ1cnRoZXN0X2xlYWYpIHtcbiAgICB0cmVlLnB1c2goZnVydGhlc3RfbGVhZilcbiAgICBmdXJ0aGVzdF9sZWFmID0gZnVydGhlc3RfbGVhZi5wYXJlbnROb2RlXG4gICAgICA/IGZ1cnRoZXN0X2xlYWYucGFyZW50Tm9kZVxuICAgICAgOiBmYWxzZVxuICB9XG5cbiAgcmV0dXJuIHRyZWUucmVkdWNlKChwYXRoLCBicmFuY2gpID0+IGBcbiAgICAke3BhdGh9JHticmFuY2gudGFnTmFtZX1fJHticmFuY2guY2xhc3NOYW1lfV8ke1suLi5ub2RlLnBhcmVudE5vZGUuY2hpbGRyZW5dLmluZGV4T2Yobm9kZSl9XyR7bm9kZS5jaGlsZHJlbi5sZW5ndGh9XG4gIGAsICcnKVxufVxuXG5leHBvcnQgY29uc3QgY3JlYXRlQ2xhc3NuYW1lID0gKGVsLCBlbGxpcHNlID0gZmFsc2UpID0+IHtcbiAgaWYgKCFlbC5jbGFzc05hbWUpIHJldHVybiAnJ1xuICBcbiAgY29uc3QgY29tYmluZWQgPSBBcnJheS5mcm9tKGVsLmNsYXNzTGlzdCkucmVkdWNlKChjbGFzc25hbWVzLCBjbGFzc25hbWUpID0+XG4gICAgY2xhc3NuYW1lcyArPSAnLicgKyBjbGFzc25hbWVcbiAgLCAnJylcblxuICByZXR1cm4gZWxsaXBzZSAmJiBjb21iaW5lZC5sZW5ndGggPiAzMFxuICAgID8gY29tYmluZWQuc3Vic3RyaW5nKDAsMzApICsgJy4uLidcbiAgICA6IGNvbWJpbmVkXG59XG5cbmV4cG9ydCBjb25zdCBtZXRhS2V5ID0gd2luZG93Lm5hdmlnYXRvci5wbGF0Zm9ybS5pbmNsdWRlcygnTWFjJylcbiAgPyAnY21kJ1xuICA6ICdjdHJsJ1xuXG5leHBvcnQgY29uc3QgYWx0S2V5ID0gd2luZG93Lm5hdmlnYXRvci5wbGF0Zm9ybS5pbmNsdWRlcygnTWFjJylcbiAgPyAnb3B0J1xuICA6ICdhbHQnXG4iLCJpbXBvcnQgJCBmcm9tICdibGluZ2JsaW5nanMnXG5pbXBvcnQgeyBub2RlS2V5IH0gZnJvbSAnLi9zdHJpbmdzJ1xuXG5leHBvcnQgY29uc3QgZGVlcEVsZW1lbnRGcm9tUG9pbnQgPSAoeCwgeSkgPT4ge1xuICBjb25zdCBlbCA9IGRvY3VtZW50LmVsZW1lbnRGcm9tUG9pbnQoeCwgeSlcblxuICBjb25zdCBjcmF3bFNoYWRvd3MgPSBub2RlID0+IHtcbiAgICBpZiAobm9kZS5zaGFkb3dSb290KSB7XG4gICAgICBjb25zdCBwb3RlbnRpYWwgPSBub2RlLnNoYWRvd1Jvb3QuZWxlbWVudEZyb21Qb2ludCh4LCB5KVxuXG4gICAgICBpZiAocG90ZW50aWFsID09IG5vZGUpICAgICAgICAgIHJldHVybiBub2RlXG4gICAgICBlbHNlIGlmIChwb3RlbnRpYWwuc2hhZG93Um9vdCkgIHJldHVybiBjcmF3bFNoYWRvd3MocG90ZW50aWFsKVxuICAgICAgZWxzZSAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcG90ZW50aWFsXG4gICAgfVxuICAgIGVsc2UgcmV0dXJuIG5vZGVcbiAgfVxuXG4gIGNvbnN0IG5lc3RlZF9zaGFkb3cgPSBjcmF3bFNoYWRvd3MoZWwpXG5cbiAgcmV0dXJuIG5lc3RlZF9zaGFkb3cgfHwgZWxcbn1cblxuZXhwb3J0IGNvbnN0IGdldFNpZGUgPSBkaXJlY3Rpb24gPT4ge1xuICBsZXQgc3RhcnQgPSBkaXJlY3Rpb24uc3BsaXQoJysnKS5wb3AoKS5yZXBsYWNlKC9eXFx3LywgYyA9PiBjLnRvVXBwZXJDYXNlKCkpXG4gIGlmIChzdGFydCA9PSAnVXAnKSBzdGFydCA9ICdUb3AnXG4gIGlmIChzdGFydCA9PSAnRG93bicpIHN0YXJ0ID0gJ0JvdHRvbSdcbiAgcmV0dXJuIHN0YXJ0XG59XG5cbmV4cG9ydCBjb25zdCBnZXROb2RlSW5kZXggPSBlbCA9PiB7XG4gIHJldHVybiBbLi4uZWwucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LmNoaWxkcmVuXVxuICAgIC5pbmRleE9mKGVsLnBhcmVudEVsZW1lbnQpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzaG93RWRnZShlbCkge1xuICByZXR1cm4gZWwuYW5pbWF0ZShbXG4gICAgeyBvdXRsaW5lOiAnMXB4IHNvbGlkIHRyYW5zcGFyZW50JyB9LFxuICAgIHsgb3V0bGluZTogJzFweCBzb2xpZCBoc2xhKDMzMCwgMTAwJSwgNzElLCA4MCUpJyB9LFxuICAgIHsgb3V0bGluZTogJzFweCBzb2xpZCB0cmFuc3BhcmVudCcgfSxcbiAgXSwgNjAwKVxufVxuXG5sZXQgdGltZW91dE1hcCA9IHt9XG5leHBvcnQgY29uc3Qgc2hvd0hpZGVTZWxlY3RlZCA9IChlbCwgZHVyYXRpb24gPSA3NTApID0+IHtcbiAgZWwuc2V0QXR0cmlidXRlKCdkYXRhLXNlbGVjdGVkLWhpZGUnLCB0cnVlKVxuICBzaG93SGlkZU5vZGVMYWJlbChlbCwgdHJ1ZSlcblxuICBpZiAodGltZW91dE1hcFtub2RlS2V5KGVsKV0pXG4gICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRNYXBbbm9kZUtleShlbCldKVxuXG4gIHRpbWVvdXRNYXBbbm9kZUtleShlbCldID0gc2V0VGltZW91dChfID0+IHtcbiAgICBlbC5yZW1vdmVBdHRyaWJ1dGUoJ2RhdGEtc2VsZWN0ZWQtaGlkZScpXG4gICAgc2hvd0hpZGVOb2RlTGFiZWwoZWwsIGZhbHNlKVxuICB9LCBkdXJhdGlvbilcblxuICByZXR1cm4gZWxcbn1cblxuZXhwb3J0IGNvbnN0IHNob3dIaWRlTm9kZUxhYmVsID0gKGVsLCBzaG93ID0gZmFsc2UpID0+IHtcbiAgaWYgKCFlbC5oYXNBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnKSlcbiAgICByZXR1cm5cblxuICBjb25zdCBsYWJlbF9pZCA9IGVsLmdldEF0dHJpYnV0ZSgnZGF0YS1sYWJlbC1pZCcpXG5cbiAgY29uc3Qgbm9kZXMgPSAkKGBcbiAgICB2aXNidWctbGFiZWxbZGF0YS1sYWJlbC1pZD1cIiR7bGFiZWxfaWR9XCJdLFxuICAgIHZpc2J1Zy1oYW5kbGVzW2RhdGEtbGFiZWwtaWQ9XCIke2xhYmVsX2lkfVwiXVxuICBgKVxuXG4gIG5vZGVzLmxlbmd0aCAmJiBzaG93XG4gICAgPyBub2Rlcy5mb3JFYWNoKGVsID0+XG4gICAgICBlbC5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnKVxuICAgIDogbm9kZXMuZm9yRWFjaChlbCA9PlxuICAgICAgZWwuc3R5bGUuZGlzcGxheSA9IG51bGwpXG59XG5cbmV4cG9ydCBjb25zdCBodG1sU3RyaW5nVG9Eb20gPSAoaHRtbFN0cmluZyA9IFwiXCIpID0+XG4gIChuZXcgRE9NUGFyc2VyKCkucGFyc2VGcm9tU3RyaW5nKGh0bWxTdHJpbmcsICd0ZXh0L2h0bWwnKSlcbiAgICAuYm9keS5maXJzdENoaWxkXG5cbmV4cG9ydCBjb25zdCBpc09mZkJvdW5kcyA9IG5vZGUgPT5cbiAgbm9kZS5jbG9zZXN0ICYmIChcbiAgICAgICBub2RlLmNsb3Nlc3QoJ3Zpcy1idWcnKVxuICAgIHx8IG5vZGUuY2xvc2VzdCgnaG90a2V5LW1hcCcpXG4gICAgfHwgbm9kZS5jbG9zZXN0KCd2aXNidWctbWV0YXRpcCcpXG4gICAgfHwgbm9kZS5jbG9zZXN0KCd2aXNidWctYWxseScpXG4gICAgfHwgbm9kZS5jbG9zZXN0KCd2aXNidWctbGFiZWwnKVxuICAgIHx8IG5vZGUuY2xvc2VzdCgndmlzYnVnLWhhbmRsZXMnKVxuICAgIHx8IG5vZGUuY2xvc2VzdCgndmlzYnVnLWdyaWRsaW5lcycpXG4gIClcblxuZXhwb3J0IGNvbnN0IGlzU2VsZWN0b3JWYWxpZCA9IChxcyA9PiAoXG4gIHNlbGVjdG9yID0+IHtcbiAgICB0cnkgeyBxcyhzZWxlY3RvcikgfSBjYXRjaCAoZSkgeyByZXR1cm4gZmFsc2UgfVxuICAgIHJldHVybiB0cnVlXG4gIH1cbikpKHMgPT4gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpLnF1ZXJ5U2VsZWN0b3IocykpXG4iLCJleHBvcnQgZnVuY3Rpb24gd2luZG93Qm91bmRzKCkge1xuICBjb25zdCBoZWlnaHQgID0gd2luZG93LmlubmVySGVpZ2h0XG4gIGNvbnN0IHdpZHRoICAgPSB3aW5kb3cuaW5uZXJXaWR0aFxuICBjb25zdCBib2R5ICAgID0gZG9jdW1lbnQuYm9keS5jbGllbnRXaWR0aFxuXG4gIGNvbnN0IGNhbGNXaWR0aCA9IGJvZHkgPD0gd2lkdGhcbiAgICA/IGJvZHlcbiAgICA6IHdpZHRoXG5cbiAgcmV0dXJuIHtcbiAgICB3aW5IZWlnaHQ6IGhlaWdodCxcbiAgICB3aW5XaWR0aDogIGNhbGNXaWR0aCxcbiAgfVxufVxuIiwiaW1wb3J0IHsgd2luZG93Qm91bmRzIH0gZnJvbSAnLi4vLi4vdXRpbGl0aWVzLydcblxuZXhwb3J0IGNsYXNzIEdyaWRsaW5lcyBleHRlbmRzIEhUTUxFbGVtZW50IHtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG4gICAgdGhpcy4kc2hhZG93ID0gdGhpcy5hdHRhY2hTaGFkb3coe21vZGU6ICdjbG9zZWQnfSlcbiAgfVxuXG4gIGNvbm5lY3RlZENhbGxiYWNrKCkge31cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7fVxuXG4gIHNldCBwb3NpdGlvbihib3VuZGluZ1JlY3QpIHtcbiAgICB0aGlzLiRzaGFkb3cuaW5uZXJIVE1MICA9IHRoaXMucmVuZGVyKGJvdW5kaW5nUmVjdClcbiAgfVxuXG4gIHNldCB1cGRhdGUoeyB3aWR0aCwgaGVpZ2h0LCB0b3AsIGxlZnQgfSkge1xuICAgIGNvbnN0IHsgd2luSGVpZ2h0LCB3aW5XaWR0aCB9ID0gd2luZG93Qm91bmRzKClcblxuICAgIHRoaXMuJHNoYWRvdy5ob3N0LnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snXG4gICAgY29uc3Qgc3ZnID0gdGhpcy4kc2hhZG93LmNoaWxkcmVuWzFdXG5cbiAgICBzdmcuc2V0QXR0cmlidXRlKCd2aWV3Qm94JywgYDAgMCAke3dpbldpZHRofSAke3dpbkhlaWdodH1gKVxuICAgIHN2Zy5jaGlsZHJlblswXS5zZXRBdHRyaWJ1dGUoJ3dpZHRoJywgd2lkdGggKyAncHgnKVxuICAgIHN2Zy5jaGlsZHJlblswXS5zZXRBdHRyaWJ1dGUoJ2hlaWdodCcsIGhlaWdodCArICdweCcpXG4gICAgc3ZnLmNoaWxkcmVuWzBdLnNldEF0dHJpYnV0ZSgneCcsIGxlZnQpXG4gICAgc3ZnLmNoaWxkcmVuWzBdLnNldEF0dHJpYnV0ZSgneScsIHRvcClcbiAgICBzdmcuY2hpbGRyZW5bMV0uc2V0QXR0cmlidXRlKCd4MScsIGxlZnQpXG4gICAgc3ZnLmNoaWxkcmVuWzFdLnNldEF0dHJpYnV0ZSgneDInLCBsZWZ0KVxuICAgIHN2Zy5jaGlsZHJlblsyXS5zZXRBdHRyaWJ1dGUoJ3gxJywgbGVmdCArIHdpZHRoKVxuICAgIHN2Zy5jaGlsZHJlblsyXS5zZXRBdHRyaWJ1dGUoJ3gyJywgbGVmdCArIHdpZHRoKVxuICAgIHN2Zy5jaGlsZHJlblszXS5zZXRBdHRyaWJ1dGUoJ3kxJywgdG9wKVxuICAgIHN2Zy5jaGlsZHJlblszXS5zZXRBdHRyaWJ1dGUoJ3kyJywgdG9wKVxuICAgIHN2Zy5jaGlsZHJlblszXS5zZXRBdHRyaWJ1dGUoJ3gyJywgd2luV2lkdGgpXG4gICAgc3ZnLmNoaWxkcmVuWzRdLnNldEF0dHJpYnV0ZSgneTEnLCB0b3AgKyBoZWlnaHQpXG4gICAgc3ZnLmNoaWxkcmVuWzRdLnNldEF0dHJpYnV0ZSgneTInLCB0b3AgKyBoZWlnaHQpXG4gICAgc3ZnLmNoaWxkcmVuWzRdLnNldEF0dHJpYnV0ZSgneDInLCB3aW5XaWR0aClcbiAgfVxuXG4gIHJlbmRlcih7IHgsIHksIHdpZHRoLCBoZWlnaHQsIHRvcCwgbGVmdCB9KSB7XG4gICAgY29uc3QgeyB3aW5IZWlnaHQsIHdpbldpZHRoIH0gPSB3aW5kb3dCb3VuZHMoKVxuXG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoe3RvcCxsZWZ0fSl9XG4gICAgICA8c3ZnXG4gICAgICAgIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIlxuICAgICAgICB2aWV3Qm94PVwiMCAwICR7d2luV2lkdGh9ICR7d2luSGVpZ2h0fVwiXG4gICAgICAgIHZlcnNpb249XCIxLjFcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgID5cbiAgICAgICAgPHJlY3RcbiAgICAgICAgICBzdHJva2U9XCJob3RwaW5rXCIgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgIHdpZHRoPVwiJHt3aWR0aH1cIiBoZWlnaHQ9XCIke2hlaWdodH1cIlxuICAgICAgICAgIHg9XCIke3h9XCIgeT1cIiR7eX1cIlxuICAgICAgICAgIHN0eWxlPVwiZGlzcGxheTpub25lO1wiXG4gICAgICAgID48L3JlY3Q+XG4gICAgICAgIDxsaW5lIHgxPVwiJHt4fVwiIHkxPVwiMFwiIHgyPVwiJHt4fVwiIHkyPVwiJHt3aW5IZWlnaHR9XCIgc3Ryb2tlPVwiaG90cGlua1wiIHN0cm9rZS1kYXNoYXJyYXk9XCIyXCIgc3Ryb2tlLWRhc2hvZmZzZXQ9XCIzXCI+PC9saW5lPlxuICAgICAgICA8bGluZSB4MT1cIiR7eCArIHdpZHRofVwiIHkxPVwiMFwiIHgyPVwiJHt4ICsgd2lkdGh9XCIgeTI9XCIke3dpbkhlaWdodH1cIiBzdHJva2U9XCJob3RwaW5rXCIgc3Ryb2tlLWRhc2hhcnJheT1cIjJcIiBzdHJva2UtZGFzaG9mZnNldD1cIjNcIj48L2xpbmU+XG4gICAgICAgIDxsaW5lIHgxPVwiMFwiIHkxPVwiJHt5fVwiIHgyPVwiJHt3aW5XaWR0aH1cIiB5Mj1cIiR7eX1cIiBzdHJva2U9XCJob3RwaW5rXCIgc3Ryb2tlLWRhc2hhcnJheT1cIjJcIiBzdHJva2UtZGFzaG9mZnNldD1cIjNcIj48L2xpbmU+XG4gICAgICAgIDxsaW5lIHgxPVwiMFwiIHkxPVwiJHt5ICsgaGVpZ2h0fVwiIHgyPVwiJHt3aW5XaWR0aH1cIiB5Mj1cIiR7eSArIGhlaWdodH1cIiBzdHJva2U9XCJob3RwaW5rXCIgc3Ryb2tlLWRhc2hhcnJheT1cIjJcIiBzdHJva2UtZGFzaG9mZnNldD1cIjNcIj48L2xpbmU+XG4gICAgICA8L3N2Zz5cbiAgICBgXG4gIH1cblxuICBzdHlsZXMoe3RvcCxsZWZ0fSkge1xuICAgIHJldHVybiBgXG4gICAgICA8c3R5bGU+XG4gICAgICAgIDpob3N0ID4gc3ZnIHtcbiAgICAgICAgICBwb3NpdGlvbjpmaXhlZDtcbiAgICAgICAgICB0b3A6MDtcbiAgICAgICAgICBsZWZ0OjA7XG4gICAgICAgICAgb3ZlcmZsb3c6dmlzaWJsZTtcbiAgICAgICAgICBwb2ludGVyLWV2ZW50czpub25lO1xuICAgICAgICAgIHotaW5kZXg6MjE0NzQ4MzY0MjtcbiAgICAgICAgfVxuICAgICAgPC9zdHlsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCd2aXNidWctZ3JpZGxpbmVzJywgR3JpZGxpbmVzKVxuIiwiZXhwb3J0IGNsYXNzIERpc3RhbmNlIGV4dGVuZHMgSFRNTEVsZW1lbnQge1xuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcbiAgICB0aGlzLiRzaGFkb3cgPSB0aGlzLmF0dGFjaFNoYWRvdyh7bW9kZTogJ29wZW4nfSlcbiAgfVxuXG4gIGNvbm5lY3RlZENhbGxiYWNrKCkge31cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7fVxuXG4gIHNldCBwb3NpdGlvbih7bGluZV9tb2RlbCwgbm9kZV9sYWJlbF9pZH0pIHtcbiAgICB0aGlzLiRzaGFkb3cuaW5uZXJIVE1MICA9IHRoaXMucmVuZGVyKGxpbmVfbW9kZWwsIG5vZGVfbGFiZWxfaWQpXG4gIH1cblxuICByZW5kZXIobWVhc3VyZW1lbnRzLCBub2RlX2xhYmVsX2lkKSB7XG4gICAgdGhpcy4kc2hhZG93Lmhvc3Quc2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJywgbm9kZV9sYWJlbF9pZClcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcyhtZWFzdXJlbWVudHMpfVxuICAgICAgPGZpZ3VyZSBxdWFkcmFudD1cIm1lYXN1cmVtZW50cy5xXCI+XG4gICAgICAgIDxkaXY+PC9kaXY+XG4gICAgICAgIDxmaWdjYXB0aW9uPjxiPiR7bWVhc3VyZW1lbnRzLmR9PC9iPnB4PC9maWdjYXB0aW9uPlxuICAgICAgICA8ZGl2PjwvZGl2PlxuICAgICAgPC9maWd1cmU+XG4gICAgYFxuICB9XG5cbiAgc3R5bGVzKHt5LHgsZCxxLHYgPSBmYWxzZX0pIHtcbiAgICByZXR1cm4gYFxuICAgICAgPHN0eWxlPlxuICAgICAgICA6aG9zdCB7XG4gICAgICAgICAgLS1saW5lLWNvbG9yOiBoc2woMjY3LCAxMDAlLCA1OCUpO1xuICAgICAgICAgIC0tbGluZS13aWR0aDogMXB4O1xuICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgfVxuXG4gICAgICAgIDpob3N0ID4gZmlndXJlIHtcbiAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICR7dlxuICAgICAgICAgICAgPyBgaGVpZ2h0OiAke2R9cHg7IHdpZHRoOiA1cHg7YFxuICAgICAgICAgICAgOiBgd2lkdGg6ICR7ZH1weDsgaGVpZ2h0OiA1cHg7YH1cbiAgICAgICAgICB0b3A6ICR7eSArIHdpbmRvdy5zY3JvbGxZfXB4O1xuICAgICAgICAgIGxlZnQ6ICR7eH1weDtcbiAgICAgICAgICB0cmFuc2Zvcm06ICR7dlxuICAgICAgICAgICAgPyAndHJhbnNsYXRlWCgtNTAlKSdcbiAgICAgICAgICAgIDogJ3RyYW5zbGF0ZVkoLTUwJSknfTtcbiAgICAgICAgICBvdmVyZmxvdzogdmlzaWJsZTtcbiAgICAgICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICAgICAgICB6LWluZGV4OiAyMTQ3NDgzNjQ2O1xuXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiAke3YgPyAnY29sdW1uJyA6ICdyb3cnfTtcbiAgICAgICAgfVxuXG4gICAgICAgIDpob3N0ID4gZmlndXJlIGZpZ2NhcHRpb24ge1xuICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICB0ZXh0LXNoYWRvdzogMCAwLjVweCAwIGhzbGEoMCwgMCUsIDAlLCAwLjQpO1xuICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWxpbmUtY29sb3IpO1xuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDFlbTtcbiAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgbGluZS1oZWlnaHQ6IDEuMTtcbiAgICAgICAgICBmb250LXNpemU6IDAuN2VtO1xuICAgICAgICAgIGZvbnQtZmFtaWx5OiBzeXN0ZW0tdWksIC1hcHBsZS1zeXN0ZW0sIFNlZ29lIFVJLCBSb2JvdG8sIFVidW50dSwgQ2FudGFyZWxsLCBOb3RvIFNhbnMsIHNhbnMtc2VyaWY7XG4gICAgICAgICAgcGFkZGluZzogMC4yNWVtIDAuNWVtIDAuMjc1ZW07XG4gICAgICAgICAgZm9udC12YXJpYW50LW51bWVyaWM6IHByb3BvcnRpb25hbC1udW0gb2xkc3R5bGUtbnVtcyBzdGFja2VkLWZyYWN0aW9ucyBzbGFzaGVkLXplcm87XG4gICAgICAgIH1cblxuICAgICAgICA6aG9zdCA+IGZpZ3VyZSBzcGFuIHtcbiAgICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1saW5lLWNvbG9yKTtcbiAgICAgICAgICAke3ZcbiAgICAgICAgICAgID8gJ2hlaWdodDogdmFyKC0tbGluZS13aWR0aCk7IHdpZHRoOiA1cHg7J1xuICAgICAgICAgICAgOiAnd2lkdGg6IHZhcigtLWxpbmUtd2lkdGgpOyBoZWlnaHQ6IDVweDsnfVxuICAgICAgICB9XG5cbiAgICAgICAgOmhvc3QgPiBmaWd1cmUgZGl2IHtcbiAgICAgICAgICBmbGV4OiAyO1xuICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWxpbmUtY29sb3IpO1xuICAgICAgICAgICR7dlxuICAgICAgICAgICAgPyAnd2lkdGg6IHZhcigtLWxpbmUtd2lkdGgpOydcbiAgICAgICAgICAgIDogJ2hlaWdodDogdmFyKC0tbGluZS13aWR0aCk7J31cbiAgICAgICAgfVxuXG4gICAgICAgIDpob3N0IGZpZ3VyZSA+IGRpdiR7cSA9PT0gJ3RvcCcgfHwgcSA9PT0gJ2xlZnQnID8gJzpsYXN0LW9mLXR5cGUnIDogJzpmaXJzdC1vZi10eXBlJ30ge1xuICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byAke3F9LCBob3RwaW5rIDAlLCB2YXIoLS1saW5lLWNvbG9yKSAxMDAlKTtcbiAgICAgICAgfVxuICAgICAgPC9zdHlsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCd2aXNidWctZGlzdGFuY2UnLCBEaXN0YW5jZSlcbiIsImV4cG9ydCBjbGFzcyBPdmVybGF5IGV4dGVuZHMgSFRNTEVsZW1lbnQge1xuICBcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuICAgIHRoaXMuJHNoYWRvdyA9IHRoaXMuYXR0YWNoU2hhZG93KHttb2RlOiAnY2xvc2VkJ30pXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG4gIGRpc2Nvbm5lY3RlZENhbGxiYWNrKCkge31cblxuICBzZXQgcG9zaXRpb24oYm91bmRpbmdSZWN0KSB7XG4gICAgdGhpcy4kc2hhZG93LmlubmVySFRNTCAgPSB0aGlzLnJlbmRlcihib3VuZGluZ1JlY3QpXG4gIH1cblxuICBzZXQgdXBkYXRlKHsgdG9wLCBsZWZ0LCB3aWR0aCwgaGVpZ2h0IH0pIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJ1xuXG4gICAgY29uc3Qgc3ZnID0gdGhpcy4kc2hhZG93LmNoaWxkcmVuWzBdXG4gICAgc3ZnLnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snXG4gICAgc3ZnLnN0eWxlLnRvcCA9IHdpbmRvdy5zY3JvbGxZICsgdG9wICsgJ3B4J1xuICAgIHN2Zy5zdHlsZS5sZWZ0ID0gbGVmdCArICdweCdcblxuICAgIHN2Zy5zZXRBdHRyaWJ1dGUoJ3dpZHRoJywgd2lkdGggKyAncHgnKVxuICAgIHN2Zy5zZXRBdHRyaWJ1dGUoJ2hlaWdodCcsIGhlaWdodCArICdweCcpXG4gIH1cblxuICByZW5kZXIoe2lkLCB0b3AsIGxlZnQsIGhlaWdodCwgd2lkdGh9KSB7XG4gICAgcmV0dXJuIGBcbiAgICAgIDxzdmcgXG4gICAgICAgIGNsYXNzPVwidmlzYnVnLW92ZXJsYXlcIlxuICAgICAgICBvdmVybGF5LWlkPVwiJHtpZH1cIlxuICAgICAgICBzdHlsZT1cIlxuICAgICAgICAgIGRpc3BsYXk6bm9uZTtcbiAgICAgICAgICBwb3NpdGlvbjphYnNvbHV0ZTtcbiAgICAgICAgICB0b3A6MDtcbiAgICAgICAgICBsZWZ0OjA7XG4gICAgICAgICAgb3ZlcmZsb3c6dmlzaWJsZTtcbiAgICAgICAgICBwb2ludGVyLWV2ZW50czpub25lO1xuICAgICAgICAgIHotaW5kZXg6IDk5OTtcbiAgICAgICAgXCIgXG4gICAgICAgIHdpZHRoPVwiJHt3aWR0aH1weFwiIGhlaWdodD1cIiR7aGVpZ2h0fXB4XCIgXG4gICAgICAgIHZpZXdCb3g9XCIwIDAgJHt3aWR0aH0gJHtoZWlnaHR9XCIgXG4gICAgICAgIHZlcnNpb249XCIxLjFcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgID5cbiAgICAgICAgPHJlY3QgXG4gICAgICAgICAgZmlsbD1cImhzbGEoMzMwLCAxMDAlLCA3MSUsIDAuNSlcIlxuICAgICAgICAgIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIlxuICAgICAgICA+PC9yZWN0PlxuICAgICAgPC9zdmc+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgndmlzYnVnLW92ZXJsYXknLCBPdmVybGF5KVxuIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IHsgY3JlYXRlQ2xhc3NuYW1lIH0gZnJvbSAnLi4vLi4vdXRpbGl0aWVzLydcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi9tZXRhdGlwLmVsZW1lbnQuY3NzJ1xuXG5leHBvcnQgY2xhc3MgTWV0YXRpcCBleHRlbmRzIEhUTUxFbGVtZW50IHtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG4gICAgdGhpcy4kc2hhZG93ID0gdGhpcy5hdHRhY2hTaGFkb3coe21vZGU6ICdjbG9zZWQnfSlcbiAgfVxuXG4gIGNvbm5lY3RlZENhbGxiYWNrKCkge1xuICAgICQodGhpcy4kc2hhZG93Lmhvc3QpLm9uKCdtb3VzZWVudGVyJywgdGhpcy5vYnNlcnZlLmJpbmQodGhpcykpXG4gIH1cblxuICBkaXNjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICB0aGlzLnVub2JzZXJ2ZSgpXG4gIH1cblxuICBkaXNwYXRjaFF1ZXJ5KGUpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5kaXNwYXRjaEV2ZW50KG5ldyBDdXN0b21FdmVudCgncXVlcnknLCB7XG4gICAgICBidWJibGVzOiB0cnVlLFxuICAgICAgZGV0YWlsOiAgIHtcbiAgICAgICAgdGV4dDogICAgICAgZS50YXJnZXQudGV4dENvbnRlbnQsXG4gICAgICAgIGFjdGl2YXRvcjogIGUudHlwZSxcbiAgICAgIH1cbiAgICB9KSlcbiAgfVxuXG4gIG9ic2VydmUoKSB7XG4gICAgJCgnaDUgPiBhJywgdGhpcy4kc2hhZG93KS5vbignY2xpY2sgbW91c2VlbnRlcicsIHRoaXMuZGlzcGF0Y2hRdWVyeS5iaW5kKHRoaXMpKVxuICAgICQoJ2g1ID4gYScsIHRoaXMuJHNoYWRvdykub24oJ21vdXNlbGVhdmUnLCB0aGlzLmRpc3BhdGNoVW5RdWVyeS5iaW5kKHRoaXMpKVxuICB9XG5cbiAgdW5vYnNlcnZlKCkge1xuICAgICQoJ2g1ID4gYScsIHRoaXMuJHNoYWRvdykub2ZmKCdjbGljayBtb3VzZWVudGVyJywgdGhpcy5kaXNwYXRjaFF1ZXJ5LmJpbmQodGhpcykpXG4gICAgJCgnaDUgPiBhJywgdGhpcy4kc2hhZG93KS5vZmYoJ21vdXNlbGVhdmUnLCB0aGlzLmRpc3BhdGNoVW5RdWVyeS5iaW5kKHRoaXMpKVxuICB9XG5cbiAgZGlzcGF0Y2hVblF1ZXJ5KGUpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5kaXNwYXRjaEV2ZW50KG5ldyBDdXN0b21FdmVudCgndW5xdWVyeScsIHtcbiAgICAgIGJ1YmJsZXM6IHRydWVcbiAgICB9KSlcbiAgICB0aGlzLnVub2JzZXJ2ZSgpXG4gIH1cblxuICBzZXQgbWV0YShkYXRhKSB7XG4gICAgdGhpcy4kc2hhZG93LmlubmVySFRNTCA9IHRoaXMucmVuZGVyKGRhdGEpXG4gIH1cblxuICByZW5kZXIoe2VsLCB3aWR0aCwgaGVpZ2h0LCBsb2NhbE1vZGlmaWNhdGlvbnMsIG5vdExvY2FsTW9kaWZpY2F0aW9uc30pIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcygpfVxuICAgICAgPGZpZ3VyZT5cbiAgICAgICAgPGg1PlxuICAgICAgICAgIDxhIG5vZGU+JHtlbC5ub2RlTmFtZS50b0xvd2VyQ2FzZSgpfTwvYT5cbiAgICAgICAgICA8YT4ke2VsLmlkICYmICcjJyArIGVsLmlkfTwvYT5cbiAgICAgICAgICAke2NyZWF0ZUNsYXNzbmFtZShlbCkuc3BsaXQoJy4nKVxuICAgICAgICAgICAgLmZpbHRlcihuYW1lID0+IG5hbWUgIT0gJycpXG4gICAgICAgICAgICAucmVkdWNlKChsaW5rcywgbmFtZSkgPT4gYFxuICAgICAgICAgICAgICAke2xpbmtzfVxuICAgICAgICAgICAgICA8YT4uJHtuYW1lfTwvYT5cbiAgICAgICAgICAgIGAsICcnKVxuICAgICAgICAgIH1cbiAgICAgICAgPC9oNT5cbiAgICAgICAgPHNtYWxsPlxuICAgICAgICAgIDxzcGFuXCI+JHtNYXRoLnJvdW5kKHdpZHRoKX08L3NwYW4+cHhcbiAgICAgICAgICA8c3BhbiBkaXZpZGVyPsOXPC9zcGFuPlxuICAgICAgICAgIDxzcGFuPiR7TWF0aC5yb3VuZChoZWlnaHQpfTwvc3Bhbj5weFxuICAgICAgICA8L3NtYWxsPlxuICAgICAgICA8ZGl2PiR7bm90TG9jYWxNb2RpZmljYXRpb25zLnJlZHVjZSgoaXRlbXMsIGl0ZW0pID0+IGBcbiAgICAgICAgICAke2l0ZW1zfVxuICAgICAgICAgIDxzcGFuIHByb3A+JHtpdGVtLnByb3B9Ojwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiB2YWx1ZT4ke2l0ZW0udmFsdWV9PC9zcGFuPlxuICAgICAgICBgLCAnJyl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICAke2xvY2FsTW9kaWZpY2F0aW9ucy5sZW5ndGggPyBgXG4gICAgICAgICAgPGg2IGxvY2FsLW1vZGlmaWNhdGlvbnM+TG9jYWwgTW9kaWZpY2F0aW9uczwvaDY+XG4gICAgICAgICAgPGRpdj4ke2xvY2FsTW9kaWZpY2F0aW9ucy5yZWR1Y2UoKGl0ZW1zLCBpdGVtKSA9PiBgXG4gICAgICAgICAgICAke2l0ZW1zfVxuICAgICAgICAgICAgPHNwYW4gcHJvcD4ke2l0ZW0ucHJvcH06PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gdmFsdWU+JHtpdGVtLnZhbHVlfTwvc3Bhbj5cbiAgICAgICAgICBgLCAnJyl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIGAgOiAnJ31cbiAgICAgIDwvZmlndXJlPlxuICAgIGBcbiAgfVxuXG4gIHN0eWxlcygpIHtcbiAgICByZXR1cm4gYFxuICAgICAgPHN0eWxlPlxuICAgICAgICAke3N0eWxlc31cbiAgICAgIDwvc3R5bGU+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgndmlzYnVnLW1ldGF0aXAnLCBNZXRhdGlwKVxuIiwiaW1wb3J0IHsgTWV0YXRpcCB9IGZyb20gJy4vbWV0YXRpcC5lbGVtZW50LmpzJ1xuXG5leHBvcnQgY2xhc3MgQWxseSBleHRlbmRzIE1ldGF0aXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG4gIH1cbiAgXG4gIHJlbmRlcih7ZWwsIGFsbHlfYXR0cmlidXRlcywgY29udHJhc3RfcmVzdWx0c30pIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcygpfVxuICAgICAgPGZpZ3VyZT5cbiAgICAgICAgPGg1PiR7ZWwubm9kZU5hbWUudG9Mb3dlckNhc2UoKX0ke2VsLmlkICYmICcjJyArIGVsLmlkfTwvaDU+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgJHthbGx5X2F0dHJpYnV0ZXMucmVkdWNlKChpdGVtcywgYXR0cikgPT4gYFxuICAgICAgICAgICAgJHtpdGVtc31cbiAgICAgICAgICAgIDxzcGFuIHByb3A+JHthdHRyLnByb3B9Ojwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIHZhbHVlPiR7YXR0ci52YWx1ZX08L3NwYW4+XG4gICAgICAgICAgYCwgJycpfVxuICAgICAgICAgICR7Y29udHJhc3RfcmVzdWx0c31cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2ZpZ3VyZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCd2aXNidWctYWxseScsIEFsbHkpXG4iLCJleHBvcnQgY29uc3QgY3Vyc29yID0gYFxuICA8c3ZnIGNsYXNzPVwiaWNvbi1jdXJzb3JcIiB2ZXJzaW9uPVwiMS4xXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMzIgMzJcIj5cbiAgICA8cGF0aCBkPVwiTTE2LjY4OSAxNy42NTVsNS4zMTEgMTIuMzQ1LTQgMi00LjY0Ni0xMi42NzgtNy4zNTQgNi42Nzh2LTI2bDIwIDE2LTkuMzExIDEuNjU1elwiPjwvcGF0aD5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBtb3ZlID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk0xNSA3LjVWMkg5djUuNWwzIDMgMy0zek03LjUgOUgydjZoNS41bDMtMy0zLTN6TTkgMTYuNVYyMmg2di01LjVsLTMtMy0zIDN6TTE2LjUgOWwtMyAzIDMgM0gyMlY5aC01LjV6XCIvPlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IHNlYXJjaCA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNMTUuNSAxNGgtLjc5bC0uMjgtLjI3QzE1LjQxIDEyLjU5IDE2IDExLjExIDE2IDkuNSAxNiA1LjkxIDEzLjA5IDMgOS41IDNTMyA1LjkxIDMgOS41IDUuOTEgMTYgOS41IDE2YzEuNjEgMCAzLjA5LS41OSA0LjIzLTEuNTdsLjI3LjI4di43OWw1IDQuOTlMMjAuNDkgMTlsLTQuOTktNXptLTYgMEM3LjAxIDE0IDUgMTEuOTkgNSA5LjVTNy4wMSA1IDkuNSA1IDE0IDcuMDEgMTQgOS41IDExLjk5IDE0IDkuNSAxNHpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgbWFyZ2luID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk05IDdIN3YyaDJWN3ptMCA0SDd2Mmgydi0yem0wLThjLTEuMTEgMC0yIC45LTIgMmgyVjN6bTQgMTJoLTJ2Mmgydi0yem02LTEydjJoMmMwLTEuMS0uOS0yLTItMnptLTYgMGgtMnYyaDJWM3pNOSAxN3YtMkg3YzAgMS4xLjg5IDIgMiAyem0xMC00aDJ2LTJoLTJ2MnptMC00aDJWN2gtMnYyem0wIDhjMS4xIDAgMi0uOSAyLTJoLTJ2MnpNNSA3SDN2MTJjMCAxLjEuODkgMiAyIDJoMTJ2LTJINVY3em0xMC0yaDJWM2gtMnYyem0wIDEyaDJ2LTJoLTJ2MnpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgcGFkZGluZyA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNMyAxM2gydi0ySDN2MnptMCA0aDJ2LTJIM3Yyem0yIDR2LTJIM2MwIDEuMS44OSAyIDIgMnpNMyA5aDJWN0gzdjJ6bTEyIDEyaDJ2LTJoLTJ2MnptNC0xOEg5Yy0xLjExIDAtMiAuOS0yIDJ2MTBjMCAxLjEuODkgMiAyIDJoMTBjMS4xIDAgMi0uOSAyLTJWNWMwLTEuMS0uOS0yLTItMnptMCAxMkg5VjVoMTB2MTB6bS04IDZoMnYtMmgtMnYyem0tNCAwaDJ2LTJIN3YyelwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBmb250ID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk05IDR2M2g1djEyaDNWN2g1VjRIOXptLTYgOGgzdjdoM3YtN2gzVjlIM3YzelwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCB0ZXh0ID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk0zIDE3LjI1VjIxaDMuNzVMMTcuODEgOS45NGwtMy43NS0zLjc1TDMgMTcuMjV6TTIwLjcxIDcuMDRjLjM5LS4zOS4zOS0xLjAyIDAtMS40MWwtMi4zNC0yLjM0Yy0uMzktLjM5LTEuMDItLjM5LTEuNDEgMGwtMS44MyAxLjgzIDMuNzUgMy43NSAxLjgzLTEuODN6XCIvPlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IGFsaWduID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgc3R5bGU9XCJ0cmFuc2Zvcm06cm90YXRlWig5MGRlZyk7XCI+XG4gICAgPHBhdGggZD1cIk0xMCAyMGg0VjRoLTR2MTZ6bS02IDBoNHYtOEg0djh6TTE2IDl2MTFoNFY5aC00elwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCByZXNpemUgPSBgXG4gIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICA8cGF0aCBkPVwiTTE5IDEyaC0ydjNoLTN2Mmg1di01ek03IDloM1Y3SDV2NWgyVjl6bTE0LTZIM2MtMS4xIDAtMiAuOS0yIDJ2MTRjMCAxLjEuOSAyIDIgMmgxOGMxLjEgMCAyLS45IDItMlY1YzAtMS4xLS45LTItMi0yem0wIDE2LjAxSDNWNC45OWgxOHYxNC4wMnpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgdHJhbnNmb3JtID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk0xMiw3QzYuNDgsNywyLDkuMjQsMiwxMmMwLDIuMjQsMi45NCw0LjEzLDcsNC43N1YyMGw0LTRsLTQtNHYyLjczYy0zLjE1LTAuNTYtNS0xLjktNS0yLjczYzAtMS4wNiwzLjA0LTMsOC0zczgsMS45NCw4LDNcbiAgICBjMCwwLjczLTEuNDYsMS44OS00LDIuNTN2Mi4wNWMzLjUzLTAuNzcsNi0yLjUzLDYtNC41OEMyMiw5LjI0LDE3LjUyLDcsMTIsN3pcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgYm9yZGVyID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk0xMyA3aC0ydjJoMlY3em0wIDRoLTJ2Mmgydi0yem00IDBoLTJ2Mmgydi0yek0zIDN2MThoMThWM0gzem0xNiAxNkg1VjVoMTR2MTR6bS02LTRoLTJ2Mmgydi0yem0tNC00SDd2Mmgydi0yelwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBodWVzaGlmdCA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNMTIgM2MtNC45NyAwLTkgNC4wMy05IDlzNC4wMyA5IDkgOWMuODMgMCAxLjUtLjY3IDEuNS0xLjUgMC0uMzktLjE1LS43NC0uMzktMS4wMS0uMjMtLjI2LS4zOC0uNjEtLjM4LS45OSAwLS44My42Ny0xLjUgMS41LTEuNUgxNmMyLjc2IDAgNS0yLjI0IDUtNSAwLTQuNDItNC4wMy04LTktOHptLTUuNSA5Yy0uODMgMC0xLjUtLjY3LTEuNS0xLjVTNS42NyA5IDYuNSA5IDggOS42NyA4IDEwLjUgNy4zMyAxMiA2LjUgMTJ6bTMtNEM4LjY3IDggOCA3LjMzIDggNi41UzguNjcgNSA5LjUgNXMxLjUuNjcgMS41IDEuNVMxMC4zMyA4IDkuNSA4em01IDBjLS44MyAwLTEuNS0uNjctMS41LTEuNVMxMy42NyA1IDE0LjUgNXMxLjUuNjcgMS41IDEuNVMxNS4zMyA4IDE0LjUgOHptMyA0Yy0uODMgMC0xLjUtLjY3LTEuNS0xLjVTMTYuNjcgOSAxNy41IDlzMS41LjY3IDEuNSAxLjUtLjY3IDEuNS0xLjUgMS41elwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBib3hzaGFkb3cgPSBgXG4gIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICA8cGF0aCBkPVwiTTIwIDguNjlWNGgtNC42OUwxMiAuNjkgOC42OSA0SDR2NC42OUwuNjkgMTIgNCAxNS4zMVYyMGg0LjY5TDEyIDIzLjMxIDE1LjMxIDIwSDIwdi00LjY5TDIzLjMxIDEyIDIwIDguNjl6TTEyIDE4Yy0uODkgMC0xLjc0LS4yLTIuNS0uNTVDMTEuNTYgMTYuNSAxMyAxNC40MiAxMyAxMnMtMS40NC00LjUtMy41LTUuNDVDMTAuMjYgNi4yIDExLjExIDYgMTIgNmMzLjMxIDAgNiAyLjY5IDYgNnMtMi42OSA2LTYgNnpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgaW5zcGVjdG9yID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPGc+XG4gICAgICA8cmVjdCB4PVwiMTFcIiB5PVwiN1wiIHdpZHRoPVwiMlwiIGhlaWdodD1cIjJcIi8+XG4gICAgICA8cmVjdCB4PVwiMTFcIiB5PVwiMTFcIiB3aWR0aD1cIjJcIiBoZWlnaHQ9XCI2XCIvPlxuICAgICAgPHBhdGggZD1cIk0xMiwyQzYuNDgsMiwyLDYuNDgsMiwxMmMwLDUuNTIsNC40OCwxMCwxMCwxMHMxMC00LjQ4LDEwLTEwQzIyLDYuNDgsMTcuNTIsMiwxMiwyeiBNMTIsMjBjLTQuNDEsMC04LTMuNTktOC04XG4gICAgICAgIGMwLTQuNDEsMy41OS04LDgtOHM4LDMuNTksOCw4QzIwLDE2LjQxLDE2LjQxLDIwLDEyLDIwelwiLz5cbiAgICA8L2c+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgY2FtZXJhID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCIzLjJcIi8+XG4gICAgPHBhdGggZD1cIk05IDJMNy4xNyA0SDRjLTEuMSAwLTIgLjktMiAydjEyYzAgMS4xLjkgMiAyIDJoMTZjMS4xIDAgMi0uOSAyLTJWNmMwLTEuMS0uOS0yLTItMmgtMy4xN0wxNSAySDl6bTMgMTVjLTIuNzYgMC01LTIuMjQtNS01czIuMjQtNSA1LTUgNSAyLjI0IDUgNS0yLjI0IDUtNSA1elwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBndWlkZXMgPSBgXG4gIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICA8cGF0aCBkPVwiTTIxLDZIM0MxLjksNiwxLDYuOSwxLDh2OGMwLDEuMSwwLjksMiwyLDJoMThjMS4xLDAsMi0wLjksMi0yVjhDMjMsNi45LDIyLjEsNiwyMSw2eiBNMjEsMTZIM1Y4aDJ2NGgyVjhoMnY0aDJWOGgydjRoMlY4XG4gICAgaDJ2NGgyVjhoMlYxNnpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgY29sb3JfdGV4dCA9IGBcbiAgPHN2ZyB2aWV3Qm94PVwiMCAwIDI1IDI3XCI+XG4gICAgPHBhdGggZD1cIk0xMSAzTDUuNSAxN2gyLjI1bDEuMTItM2g2LjI1bDEuMTIgM2gyLjI1TDEzIDNoLTJ6bS0xLjM4IDlMMTIgNS42NyAxNC4zOCAxMkg5LjYyelwiLz5cbiAgICA8cmVjdCBmaWxsPVwidmFyKC0tY29udGV4dHVhbF9jb2xvcilcIiB4PVwiMVwiIHk9XCIyMVwiIHdpZHRoPVwiMjNcIiBoZWlnaHQ9XCI1XCI+PC9yZWN0PlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IGNvbG9yX2JhY2tncm91bmQgPSBgXG4gIDxzdmcgdmlld0JveD1cIjAgMCAyNSAyN1wiPlxuICAgIDxwYXRoIGQ9XCJNMTYuNTYgOC45NEw3LjYyIDAgNi4yMSAxLjQxbDIuMzggMi4zOC01LjE1IDUuMTVjLS41OS41OS0uNTkgMS41NCAwIDIuMTJsNS41IDUuNWMuMjkuMjkuNjguNDQgMS4wNi40NHMuNzctLjE1IDEuMDYtLjQ0bDUuNS01LjVjLjU5LS41OC41OS0xLjUzIDAtMi4xMnpNNS4yMSAxMEwxMCA1LjIxIDE0Ljc5IDEwSDUuMjF6TTE5IDExLjVzLTIgMi4xNy0yIDMuNWMwIDEuMS45IDIgMiAyczItLjkgMi0yYzAtMS4zMy0yLTMuNS0yLTMuNXpcIi8+XG4gICAgPHJlY3QgZmlsbD1cInZhcigtLWNvbnRleHR1YWxfY29sb3IpXCIgeD1cIjFcIiB5PVwiMjFcIiB3aWR0aD1cIjIzXCIgaGVpZ2h0PVwiNVwiPjwvcmVjdD5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBjb2xvcl9ib3JkZXIgPSBgXG4gIDxzdmcgdmlld0JveD1cIjAgMCAyNSAyN1wiPlxuICAgIDxwYXRoIGQ9XCJNMTcuNzUgN0wxNCAzLjI1bC0xMCAxMFYxN2gzLjc1bDEwLTEwem0yLjk2LTIuOTZjLjM5LS4zOS4zOS0xLjAyIDAtMS40MUwxOC4zNy4yOWMtLjM5LS4zOS0xLjAyLS4zOS0xLjQxIDBMMTUgMi4yNSAxOC43NSA2bDEuOTYtMS45NnpcIi8+XG4gICAgPHJlY3QgZmlsbD1cInZhcigtLWNvbnRleHR1YWxfY29sb3IpXCIgeD1cIjFcIiB5PVwiMjFcIiB3aWR0aD1cIjIzXCIgaGVpZ2h0PVwiNVwiPjwvcmVjdD5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBwb3NpdGlvbiA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNMTUuNTQgNS41NEwxMy43NyA3LjMgMTIgNS41NCAxMC4yMyA3LjMgOC40NiA1LjU0IDEyIDJ6bTIuOTIgMTBsLTEuNzYtMS43N0wxOC40NiAxMmwtMS43Ni0xLjc3IDEuNzYtMS43N0wyMiAxMnptLTEwIDIuOTJsMS43Ny0xLjc2TDEyIDE4LjQ2bDEuNzctMS43NiAxLjc3IDEuNzZMMTIgMjJ6bS0yLjkyLTEwbDEuNzYgMS43N0w1LjU0IDEybDEuNzYgMS43Ny0xLjc2IDEuNzdMMiAxMnpcIi8+XG4gICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCIzXCIvPlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IGFjY2Vzc2liaWxpdHkgPSBgXG4gIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICA8cGF0aCBkPVwiTTEyLDJjMS4xLDAsMiwwLjksMiwycy0wLjksMi0yLDJzLTItMC45LTItMlMxMC45LDIsMTIsMnogTTIxLDloLTZ2MTNoLTJ2LTZoLTJ2Nkg5VjlIM1Y3aDE4Vjl6XCIvPlxuICA8L3N2Zz5cbmAiLCJpbXBvcnQgJCAgICAgICAgICAgIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzICAgICAgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCBzdHlsZXMgICAgICAgZnJvbSAnLi9iYXNlLmVsZW1lbnQuY3NzJ1xuaW1wb3J0ICogYXMgSWNvbnMgICBmcm9tICcuLi92aXMtYnVnL3Zpcy1idWcuaWNvbnMnXG5pbXBvcnQgeyBtZXRhS2V5LCBhbHRLZXkgfSAgZnJvbSAnLi4vLi4vdXRpbGl0aWVzLydcblxuZXhwb3J0IGNsYXNzIEhvdGtleU1hcCBleHRlbmRzIEhUTUxFbGVtZW50IHtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLmtleWJvYXJkX21vZGVsID0ge1xuICAgICAgbnVtOiAgICBbJ2AnLCcxJywnMicsJzMnLCc0JywnNScsJzYnLCc3JywnOCcsJzknLCcwJywnLScsJz0nLCdkZWxldGUnXSxcbiAgICAgIHRhYjogICAgWyd0YWInLCdxJywndycsJ2UnLCdyJywndCcsJ3knLCd1JywnaScsJ28nLCdwJywnWycsJ10nLCdcXFxcJ10sXG4gICAgICBjYXBzOiAgIFsnY2FwcycsJ2EnLCdzJywnZCcsJ2YnLCdnJywnaCcsJ2onLCdrJywnbCcsJ1xcJycsJ3JldHVybiddLFxuICAgICAgc2hpZnQ6ICBbJ3NoaWZ0JywneicsJ3gnLCdjJywndicsJ2InLCduJywnbScsJywnLCcuJywnLycsJ3NoaWZ0J10sXG4gICAgICBzcGFjZTogIFsnY3RybCcsYWx0S2V5LCdjbWQnLCdzcGFjZWJhcicsJ2NtZCcsYWx0S2V5LCdjdHJsJ11cbiAgICB9XG5cbiAgICB0aGlzLmtleV9zaXplX21vZGVsID0ge1xuICAgICAgbnVtOiAgICB7MTI6Mn0sXG4gICAgICB0YWI6ICAgIHswOjJ9LFxuICAgICAgY2FwczogICB7MDozLDExOjN9LFxuICAgICAgc2hpZnQ6ICB7MDo2LDExOjZ9LFxuICAgICAgc3BhY2U6ICB7MzoxMH0sXG4gICAgfVxuXG4gICAgdGhpcy4kc2hhZG93ICAgID0gdGhpcy5hdHRhY2hTaGFkb3coe21vZGU6ICdjbG9zZWQnfSlcblxuICAgIHRoaXMuX2hvdGtleSAgICA9ICcnXG4gICAgdGhpcy5fdXNlZGtleXMgID0gW11cblxuICAgIHRoaXMudG9vbCAgICAgICA9ICdob3RrZXltYXAnXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICB0aGlzLiRzaGlmdCAgPSAkKCdba2V5Ym9hcmRdID4gc2VjdGlvbiA+IFtzaGlmdF0nLCB0aGlzLiRzaGFkb3cpXG4gICAgdGhpcy4kY3RybCAgID0gJCgnW2tleWJvYXJkXSA+IHNlY3Rpb24gPiBbY3RybF0nLCB0aGlzLiRzaGFkb3cpXG4gICAgdGhpcy4kYWx0ICAgID0gJChgW2tleWJvYXJkXSA+IHNlY3Rpb24gPiBbJHthbHRLZXl9XWAsIHRoaXMuJHNoYWRvdylcbiAgICB0aGlzLiRjbWQgICAgPSAkKGBba2V5Ym9hcmRdID4gc2VjdGlvbiA+IFske21ldGFLZXl9XWAsIHRoaXMuJHNoYWRvdylcbiAgICB0aGlzLiR1cCAgICAgPSAkKCdbYXJyb3dzXSBbdXBdJywgdGhpcy4kc2hhZG93KVxuICAgIHRoaXMuJGRvd24gICA9ICQoJ1thcnJvd3NdIFtkb3duXScsIHRoaXMuJHNoYWRvdylcbiAgICB0aGlzLiRsZWZ0ICAgPSAkKCdbYXJyb3dzXSBbbGVmdF0nLCB0aGlzLiRzaGFkb3cpXG4gICAgdGhpcy4kcmlnaHQgID0gJCgnW2Fycm93c10gW3JpZ2h0XScsIHRoaXMuJHNoYWRvdylcbiAgfVxuXG4gIGRpc2Nvbm5lY3RlZENhbGxiYWNrKCkge31cblxuICBzZXQgdG9vbCh0b29sKSB7XG4gICAgdGhpcy5fdG9vbCA9IHRvb2xcbiAgICB0aGlzLiRzaGFkb3cuaW5uZXJIVE1MID0gdGhpcy5yZW5kZXIoKVxuICB9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gICAgaG90a2V5cygnKicsIChlLCBoYW5kbGVyKSA9PlxuICAgICAgdGhpcy53YXRjaEtleXMoZSwgaGFuZGxlcikpXG4gIH1cblxuICBoaWRlKCkge1xuICAgIHRoaXMuJHNoYWRvdy5ob3N0LnN0eWxlLmRpc3BsYXkgPSAnbm9uZSdcbiAgICBob3RrZXlzLnVuYmluZCgnKicpXG4gIH1cblxuICB3YXRjaEtleXMoZSwgaGFuZGxlcikge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKClcblxuICAgIHRoaXMuJHNoaWZ0LmF0dHIoJ3ByZXNzZWQnLCBob3RrZXlzLnNoaWZ0KVxuICAgIHRoaXMuJGN0cmwuYXR0cigncHJlc3NlZCcsIGhvdGtleXMuY3RybClcbiAgICB0aGlzLiRhbHQuYXR0cigncHJlc3NlZCcsIGhvdGtleXMuYWx0KVxuICAgIHRoaXMuJGNtZC5hdHRyKCdwcmVzc2VkJywgaG90a2V5c1ttZXRhS2V5XSlcbiAgICB0aGlzLiR1cC5hdHRyKCdwcmVzc2VkJywgZS5jb2RlID09PSAnQXJyb3dVcCcpXG4gICAgdGhpcy4kZG93bi5hdHRyKCdwcmVzc2VkJywgZS5jb2RlID09PSAnQXJyb3dEb3duJylcbiAgICB0aGlzLiRsZWZ0LmF0dHIoJ3ByZXNzZWQnLCBlLmNvZGUgPT09ICdBcnJvd0xlZnQnKVxuICAgIHRoaXMuJHJpZ2h0LmF0dHIoJ3ByZXNzZWQnLCBlLmNvZGUgPT09ICdBcnJvd1JpZ2h0JylcblxuICAgIGNvbnN0IHsgbmVnYXRpdmUsIG5lZ2F0aXZlX21vZGlmaWVyLCBzaWRlLCBhbW91bnQgfSA9IHRoaXMuY3JlYXRlQ29tbWFuZCh7ZSwgaG90a2V5c30pXG5cbiAgICAkKCdbY29tbWFuZF0nLCB0aGlzLiRzaGFkb3cpWzBdLmlubmVySFRNTCA9IHRoaXMuZGlzcGxheUNvbW1hbmQoe1xuICAgICAgbmVnYXRpdmUsIG5lZ2F0aXZlX21vZGlmaWVyLCBzaWRlLCBhbW91bnQsXG4gICAgfSlcbiAgfVxuXG4gIGNyZWF0ZUNvbW1hbmQoe2U6e2NvZGV9LCBob3RrZXlzfSkge1xuICAgIGxldCBhbW91bnQgICAgICAgICAgICAgID0gaG90a2V5cy5zaGlmdCA/IDEwIDogMVxuICAgIGxldCBuZWdhdGl2ZSAgICAgICAgICAgID0gaG90a2V5cy5hbHQgPyAnU3VidHJhY3QnIDogJ0FkZCdcbiAgICBsZXQgbmVnYXRpdmVfbW9kaWZpZXIgICA9IGhvdGtleXMuYWx0ID8gJ2Zyb20nIDogJ3RvJ1xuXG4gICAgbGV0IHNpZGUgPSAnW2Fycm93IGtleV0nXG4gICAgaWYgKGNvZGUgPT09ICdBcnJvd1VwJykgICAgIHNpZGUgPSAndGhlIHRvcCBzaWRlJ1xuICAgIGlmIChjb2RlID09PSAnQXJyb3dEb3duJykgICBzaWRlID0gJ3RoZSBib3R0b20gc2lkZSdcbiAgICBpZiAoY29kZSA9PT0gJ0Fycm93TGVmdCcpICAgc2lkZSA9ICd0aGUgbGVmdCBzaWRlJ1xuICAgIGlmIChjb2RlID09PSAnQXJyb3dSaWdodCcpICBzaWRlID0gJ3RoZSByaWdodCBzaWRlJ1xuICAgIGlmIChob3RrZXlzW21ldGFLZXldKSAgICAgICAgICAgIHNpZGUgPSAnYWxsIHNpZGVzJ1xuXG4gICAgaWYgKGhvdGtleXNbbWV0YUtleV0gJiYgY29kZSA9PT0gJ0Fycm93RG93bicpIHtcbiAgICAgIG5lZ2F0aXZlICAgICAgICAgICAgPSAnU3VidHJhY3QnXG4gICAgICBuZWdhdGl2ZV9tb2RpZmllciAgID0gJ2Zyb20nXG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG5lZ2F0aXZlLCBuZWdhdGl2ZV9tb2RpZmllciwgYW1vdW50LCBzaWRlLFxuICAgIH1cbiAgfVxuXG4gIGRpc3BsYXlDb21tYW5kKHtuZWdhdGl2ZSwgbmVnYXRpdmVfbW9kaWZpZXIsIHNpZGUsIGFtb3VudH0pIHtcbiAgICByZXR1cm4gYFxuICAgICAgPHNwYW4gbmVnYXRpdmU+JHtuZWdhdGl2ZX0gPC9zcGFuPlxuICAgICAgPHNwYW4gdG9vbD4ke3RoaXMuX3Rvb2x9PC9zcGFuPlxuICAgICAgPHNwYW4gbGlnaHQ+ICR7bmVnYXRpdmVfbW9kaWZpZXJ9IDwvc3Bhbj5cbiAgICAgIDxzcGFuIHNpZGU+JHtzaWRlfTwvc3Bhbj5cbiAgICAgIDxzcGFuIGxpZ2h0PiBieSA8L3NwYW4+XG4gICAgICA8c3BhbiBhbW91bnQ+JHthbW91bnR9PC9zcGFuPlxuICAgIGBcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcygpfVxuICAgICAgPGFydGljbGU+XG4gICAgICAgIDxkaXYgdG9vbC1pY29uPlxuICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgJHtJY29uc1t0aGlzLl90b29sXX1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICAke3RoaXMuZGlzcGxheUNvbW1hbmQoe1xuICAgICAgICAgICAgbmVnYXRpdmU6IGDCsVske2FsdEtleX1dIGAsXG4gICAgICAgICAgICBuZWdhdGl2ZV9tb2RpZmllcjogJyB0byAnLFxuICAgICAgICAgICAgdG9vbDogdGhpcy5fdG9vbCxcbiAgICAgICAgICAgIHNpZGU6ICdbYXJyb3cga2V5XScsXG4gICAgICAgICAgICBhbW91bnQ6IDFcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2FyZD5cbiAgICAgICAgICA8ZGl2IGtleWJvYXJkPlxuICAgICAgICAgICAgJHtPYmplY3QuZW50cmllcyh0aGlzLmtleWJvYXJkX21vZGVsKS5yZWR1Y2UoKGtleWJvYXJkLCBbcm93X25hbWUsIHJvd10pID0+IGBcbiAgICAgICAgICAgICAgJHtrZXlib2FyZH1cbiAgICAgICAgICAgICAgPHNlY3Rpb24gJHtyb3dfbmFtZX0+JHtyb3cucmVkdWNlKChyb3csIGtleSwgaSkgPT4gYFxuICAgICAgICAgICAgICAgICR7cm93fVxuICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAke2tleX1cbiAgICAgICAgICAgICAgICAgICR7dGhpcy5faG90a2V5ID09IGtleSA/ICdob3RrZXkgdGl0bGU9XCJUb29sIFNob3J0Y3V0IEhvdGtleVwiJyA6ICcnfVxuICAgICAgICAgICAgICAgICAgJHt0aGlzLl91c2Vka2V5cy5pbmNsdWRlcyhrZXkpID8gJ3VzZWQnIDogJyd9XG4gICAgICAgICAgICAgICAgICBzdHlsZT1cImZsZXg6JHt0aGlzLmtleV9zaXplX21vZGVsW3Jvd19uYW1lXVtpXSB8fCAxfTtcIlxuICAgICAgICAgICAgICAgID4ke2tleX08L3NwYW4+XG4gICAgICAgICAgICAgIGAsICcnKX1cbiAgICAgICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgICAgYCwgJycpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c2VjdGlvbiBhcnJvd3M+XG4gICAgICAgICAgICAgIDxzcGFuIHVwIHVzZWQ+4oaRPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBkb3duIHVzZWQ+4oaTPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBsZWZ0IHVzZWQ+4oaQPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiByaWdodCB1c2VkPuKGkjwvc3Bhbj5cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2FydGljbGU+XG4gICAgYFxuICB9XG5cbiAgc3R5bGVzKCkge1xuICAgIHJldHVybiBgXG4gICAgICA8c3R5bGU+XG4gICAgICAgICR7c3R5bGVzfVxuICAgICAgPC9zdHlsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXktbWFwJywgSG90a2V5TWFwKVxuIiwiaW1wb3J0IHsgSG90a2V5TWFwIH0gZnJvbSAnLi9iYXNlLmVsZW1lbnQnXG5pbXBvcnQgeyBndWlkZXMgYXMgaWNvbiB9IGZyb20gJy4uL3Zpcy1idWcvdmlzLWJ1Zy5pY29ucydcblxuZXhwb3J0IGNsYXNzIEd1aWRlc0hvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICAgPSAnZydcbiAgICB0aGlzLl91c2Vka2V5cyAgPSBbXVxuICAgIHRoaXMudG9vbCAgICAgICA9ICdndWlkZXMnXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxhcnRpY2xlPlxuICAgICAgICA8ZGl2IHRvb2wtaWNvbj5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICR7aWNvbn1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICBjb21pbmcgc29vblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLWd1aWRlcycsIEd1aWRlc0hvdGtleXMpXG4iLCJpbXBvcnQgeyBIb3RrZXlNYXAgfSBmcm9tICcuL2Jhc2UuZWxlbWVudCdcbmltcG9ydCB7IGluc3BlY3RvciBhcyBpY29uIH0gZnJvbSAnLi4vdmlzLWJ1Zy92aXMtYnVnLmljb25zJ1xuaW1wb3J0IHsgYWx0S2V5IH0gZnJvbSAnLi4vLi4vdXRpbGl0aWVzJztcblxuZXhwb3J0IGNsYXNzIEluc3BlY3RvckhvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICAgPSAnaSdcbiAgICB0aGlzLl91c2Vka2V5cyAgPSBbYWx0S2V5XVxuICAgIHRoaXMudG9vbCAgICAgICA9ICdpbnNwZWN0b3InXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxhcnRpY2xlPlxuICAgICAgICA8ZGl2IHRvb2wtaWNvbj5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICR7aWNvbn1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICBjb21pbmcgc29vblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLWluc3BlY3RvcicsIEluc3BlY3RvckhvdGtleXMpXG4iLCJpbXBvcnQgeyBIb3RrZXlNYXAgfSBmcm9tICcuL2Jhc2UuZWxlbWVudCdcbmltcG9ydCB7IGFjY2Vzc2liaWxpdHkgYXMgaWNvbiB9IGZyb20gJy4uL3Zpcy1idWcvdmlzLWJ1Zy5pY29ucydcbmltcG9ydCB7IGFsdEtleSB9IGZyb20gJy4uLy4uL3V0aWxpdGllcyc7XG5cbmV4cG9ydCBjbGFzcyBBY2Nlc3NpYmlsaXR5SG90a2V5cyBleHRlbmRzIEhvdGtleU1hcCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMuX2hvdGtleSAgICA9ICdwJ1xuICAgIHRoaXMuX3VzZWRrZXlzICA9IFthbHRLZXldXG4gICAgdGhpcy50b29sICAgICAgID0gJ2FjY2Vzc2liaWxpdHknXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxhcnRpY2xlPlxuICAgICAgICA8ZGl2IHRvb2wtaWNvbj5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICR7aWNvbn1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICBjb21pbmcgc29vblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLWFjY2Vzc2liaWxpdHknLCBBY2Nlc3NpYmlsaXR5SG90a2V5cylcbiIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuXG5leHBvcnQgY2xhc3MgTW92ZUhvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgID0gJ3YnXG4gICAgdGhpcy50b29sICAgICA9ICdtb3ZlJ1xuICB9XG5cbiAgY3JlYXRlQ29tbWFuZCh7ZTp7Y29kZX0sIGhvdGtleXN9KSB7XG4gICAgbGV0IGFtb3VudCwgbmVnYXRpdmUsIG5lZ2F0aXZlX21vZGlmaWVyXG5cbiAgICBsZXQgc2lkZSA9ICdbYXJyb3cga2V5XSdcbiAgICBpZiAoY29kZSA9PT0gJ0Fycm93VXAnKSAgICAgc2lkZSA9ICd1cCAmIG91dCBvZiBkaXYnXG4gICAgaWYgKGNvZGUgPT09ICdBcnJvd0Rvd24nKSAgIHNpZGUgPSAnZG93biAmIGludG8gbmV4dCBzaWJsaW5nIC8gb3V0ICYgdW5kZXIgZGl2J1xuICAgIGlmIChjb2RlID09PSAnQXJyb3dMZWZ0JykgICBzaWRlID0gJ3Rvd2FyZHMgdGhlIGZyb250L3RvcCBvZiB0aGUgc3RhY2snXG4gICAgaWYgKGNvZGUgPT09ICdBcnJvd1JpZ2h0JykgIHNpZGUgPSAndG93YXJkcyB0aGUgYmFjay9ib3R0b20gb2YgdGhlIHN0YWNrJ1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIG5lZ2F0aXZlLCBuZWdhdGl2ZV9tb2RpZmllciwgYW1vdW50LCBzaWRlLFxuICAgIH1cbiAgfVxuXG4gIGRpc3BsYXlDb21tYW5kKHtzaWRlfSkge1xuICAgIHJldHVybiBgXG4gICAgICA8c3BhbiB0b29sPiR7dGhpcy5fdG9vbH08L3NwYW4+XG4gICAgICA8c3BhbiBzaWRlPiR7c2lkZX08L3NwYW4+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1tb3ZlJywgTW92ZUhvdGtleXMpIiwiaW1wb3J0IHsgSG90a2V5TWFwIH0gZnJvbSAnLi9iYXNlLmVsZW1lbnQnXG5pbXBvcnQgeyBtZXRhS2V5LCBhbHRLZXkgfSAgIGZyb20gJy4uLy4uL3V0aWxpdGllcy8nXG5cbmV4cG9ydCBjbGFzcyBNYXJnaW5Ib3RrZXlzIGV4dGVuZHMgSG90a2V5TWFwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5faG90a2V5ICAgID0gJ20nXG4gICAgdGhpcy5fdXNlZGtleXMgID0gWydzaGlmdCcsbWV0YUtleSxhbHRLZXldXG5cbiAgICB0aGlzLnRvb2wgICAgICAgPSAnbWFyZ2luJ1xuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1tYXJnaW4nLCBNYXJnaW5Ib3RrZXlzKVxuIiwiaW1wb3J0IHsgSG90a2V5TWFwIH0gZnJvbSAnLi9iYXNlLmVsZW1lbnQnXG5pbXBvcnQgeyBtZXRhS2V5LCBhbHRLZXkgfSAgIGZyb20gJy4uLy4uL3V0aWxpdGllcy8nXG5cbmV4cG9ydCBjbGFzcyBQYWRkaW5nSG90a2V5cyBleHRlbmRzIEhvdGtleU1hcCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMuX2hvdGtleSAgICA9ICdwJ1xuICAgIHRoaXMuX3VzZWRrZXlzICA9IFsnc2hpZnQnLG1ldGFLZXksYWx0S2V5XVxuXG4gICAgdGhpcy50b29sICAgICAgID0gJ3BhZGRpbmcnXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLXBhZGRpbmcnLCBQYWRkaW5nSG90a2V5cylcbiIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuaW1wb3J0IHsgbWV0YUtleSB9IGZyb20gJy4uLy4uL3V0aWxpdGllcyc7XG5cbmNvbnN0IGhfYWxpZ25PcHRpb25zICA9IFsnbGVmdCcsJ2NlbnRlcicsJ3JpZ2h0J11cbmNvbnN0IHZfYWxpZ25PcHRpb25zICA9IFsndG9wJywnY2VudGVyJywnYm90dG9tJ11cbmNvbnN0IGRpc3RPcHRpb25zICAgICA9IFsnZXZlbmx5Jywnbm9ybWFsJywnYmV0d2VlbiddXG5cbmV4cG9ydCBjbGFzcyBBbGlnbkhvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICA9ICdhJ1xuICAgIHRoaXMuX3VzZWRrZXlzID0gW21ldGFLZXksJ3NoaWZ0J11cblxuICAgIHRoaXMuX2h0b29sICAgPSAwXG4gICAgdGhpcy5fdnRvb2wgICA9IDBcbiAgICB0aGlzLl9kdG9vbCAgID0gMVxuXG4gICAgdGhpcy5fc2lkZSAgICAgICAgID0gJ3RvcCBsZWZ0J1xuICAgIHRoaXMuX2RpcmVjdGlvbiAgICA9ICdyb3cnXG4gICAgdGhpcy5fZGlzdHJpYnV0aW9uID0gZGlzdE9wdGlvbnNbdGhpcy5fZHRvb2xdXG5cbiAgICB0aGlzLnRvb2wgICAgID0gJ2FsaWduJ1xuICB9XG5cbiAgY3JlYXRlQ29tbWFuZCh7ZTp7Y29kZX0sIGhvdGtleXN9KSB7XG4gICAgbGV0IGFtb3VudCAgICAgICAgICAgID0gdGhpcy5fZGlzdHJpYnV0aW9uXG4gICAgICAsIG5lZ2F0aXZlX21vZGlmaWVyID0gdGhpcy5fZGlyZWN0aW9uXG4gICAgICAsIHNpZGUgICAgICAgICAgICAgID0gdGhpcy5fc2lkZVxuICAgICAgLCBuZWdhdGl2ZVxuXG4gICAgaWYgKGhvdGtleXMuY21kICYmIChjb2RlID09PSAnQXJyb3dSaWdodCcgfHwgY29kZSA9PT0gJ0Fycm93RG93bicpKSB7XG4gICAgICBuZWdhdGl2ZV9tb2RpZmllciA9IGNvZGUgPT09ICdBcnJvd0Rvd24nXG4gICAgICAgID8gJ2NvbHVtbidcbiAgICAgICAgOiAncm93J1xuICAgICAgdGhpcy5fZGlyZWN0aW9uID0gbmVnYXRpdmVfbW9kaWZpZXJcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93VXAnKSAgICAgICAgICAgc2lkZSA9IHRoaXMuY2xhbXAodl9hbGlnbk9wdGlvbnMsICdfdnRvb2wnKVxuICAgICAgZWxzZSBpZiAoY29kZSA9PT0gJ0Fycm93RG93bicpICAgIHNpZGUgPSB0aGlzLmNsYW1wKHZfYWxpZ25PcHRpb25zLCAnX3Z0b29sJywgdHJ1ZSlcbiAgICAgIGVsc2UgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaWRlID0gdl9hbGlnbk9wdGlvbnNbdGhpcy5fdnRvb2xdXG5cbiAgICAgIGlmIChjb2RlID09PSAnQXJyb3dMZWZ0JykgICAgICAgICBzaWRlICs9ICcgJyArIHRoaXMuY2xhbXAoaF9hbGlnbk9wdGlvbnMsICdfaHRvb2wnKVxuICAgICAgZWxzZSBpZiAoY29kZSA9PT0gJ0Fycm93UmlnaHQnKSAgIHNpZGUgKz0gJyAnICsgdGhpcy5jbGFtcChoX2FsaWduT3B0aW9ucywgJ19odG9vbCcsIHRydWUpXG4gICAgICBlbHNlICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2lkZSArPSAnICcgKyBoX2FsaWduT3B0aW9uc1t0aGlzLl9odG9vbF1cblxuICAgICAgdGhpcy5fc2lkZSA9IHNpZGVcblxuICAgICAgaWYgKGhvdGtleXMuc2hpZnQgJiYgKGNvZGUgPT09ICdBcnJvd1JpZ2h0JyB8fCBjb2RlID09PSAnQXJyb3dMZWZ0JykpIHtcbiAgICAgICAgYW1vdW50ID0gdGhpcy5jbGFtcChkaXN0T3B0aW9ucywgJ19kdG9vbCcsIGNvZGUgPT09ICdBcnJvd1JpZ2h0JylcbiAgICAgICAgdGhpcy5fZGlzdHJpYnV0aW9uID0gYW1vdW50XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG5lZ2F0aXZlLCBuZWdhdGl2ZV9tb2RpZmllciwgYW1vdW50LCBzaWRlLFxuICAgIH1cbiAgfVxuXG4gIGRpc3BsYXlDb21tYW5kKHtzaWRlLCBhbW91bnQsIG5lZ2F0aXZlX21vZGlmaWVyfSkge1xuICAgIGlmIChhbW91bnQgPT0gMSkgYW1vdW50ID0gdGhpcy5fZGlzdHJpYnV0aW9uXG4gICAgaWYgKG5lZ2F0aXZlX21vZGlmaWVyID09ICcgdG8gJykgbmVnYXRpdmVfbW9kaWZpZXIgPSB0aGlzLl9kaXJlY3Rpb25cblxuICAgIHJldHVybiBgXG4gICAgICA8c3BhbiB0b29sPiR7dGhpcy5fdG9vbH08L3NwYW4+XG4gICAgICA8c3BhbiBsaWdodD4gYXMgPC9zcGFuPlxuICAgICAgPHNwYW4+JHtuZWdhdGl2ZV9tb2RpZmllcn06PC9zcGFuPlxuICAgICAgPHNwYW4gc2lkZT4ke3NpZGV9PC9zcGFuPlxuICAgICAgPHNwYW4gbGlnaHQ+IGRpc3RyaWJ1dGVkIDwvc3Bhbj5cbiAgICAgIDxzcGFuIGFtb3VudD4ke2Ftb3VudH08L3NwYW4+XG4gICAgYFxuICB9XG5cbiAgY2xhbXAocmFuZ2UsIHRvb2wsIGluY3JlbWVudCA9IGZhbHNlKSB7XG4gICAgaWYgKGluY3JlbWVudCkge1xuICAgICAgaWYgKHRoaXNbdG9vbF0gPCByYW5nZS5sZW5ndGggLSAxKVxuICAgICAgICB0aGlzW3Rvb2xdID0gdGhpc1t0b29sXSArIDFcbiAgICB9XG4gICAgZWxzZSBpZiAodGhpc1t0b29sXSA+IDApXG4gICAgICB0aGlzW3Rvb2xdID0gdGhpc1t0b29sXSAtIDFcblxuICAgIHJldHVybiByYW5nZVt0aGlzW3Rvb2xdXVxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1hbGlnbicsIEFsaWduSG90a2V5cylcbiIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuaW1wb3J0IHsgaHVlc2hpZnQgYXMgaWNvbiB9IGZyb20gJy4uL3Zpcy1idWcvdmlzLWJ1Zy5pY29ucydcbmltcG9ydCB7IG1ldGFLZXksIGFsdEtleSB9IGZyb20gJy4uLy4uL3V0aWxpdGllcyc7XG5cbmV4cG9ydCBjbGFzcyBIdWVzaGlmdEhvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICAgPSAnaCdcbiAgICB0aGlzLl91c2Vka2V5cyAgPSBbJ3NoaWZ0JyxtZXRhS2V5XVxuICAgIHRoaXMudG9vbCAgICAgICA9ICdodWVzaGlmdCdcbiAgfVxuXG4gIGNyZWF0ZUNvbW1hbmQoe2U6e2NvZGV9LCBob3RrZXlzfSkge1xuICAgIGxldCBhbW91bnQgICAgICAgICAgICAgID0gaG90a2V5cy5zaGlmdCA/IDEwIDogMVxuICAgIGxldCBuZWdhdGl2ZSAgICAgICAgICAgID0gJ1tpbmNyZWFzZS9kZWNyZWFzZV0nXG4gICAgbGV0IG5lZ2F0aXZlX21vZGlmaWVyICAgPSAnYnknXG4gICAgbGV0IHNpZGUgICAgICAgICAgICAgICAgPSAnW2Fycm93IGtleV0nXG5cbiAgICAvLyBzYXR1cmF0aW9uXG4gICAgaWYgKGhvdGtleXMuY21kKSB7XG4gICAgICBzaWRlID0naHVlJ1xuXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93RG93bicpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdkZWNyZWFzZSdcbiAgICAgIGlmIChjb2RlID09PSAnQXJyb3dVcCcpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdpbmNyZWFzZSdcbiAgICB9XG4gICAgZWxzZSBpZiAoY29kZSA9PT0gJ0Fycm93TGVmdCcgfHwgY29kZSA9PT0gJ0Fycm93UmlnaHQnKSB7XG4gICAgICBzaWRlID0gJ3NhdHVyYXRpb24nXG5cbiAgICAgIGlmIChjb2RlID09PSAnQXJyb3dMZWZ0JylcbiAgICAgICAgbmVnYXRpdmUgID0gJ2RlY3JlYXNlJ1xuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd1JpZ2h0JylcbiAgICAgICAgbmVnYXRpdmUgID0gJ2luY3JlYXNlJ1xuICAgIH1cbiAgICAvLyBsaWdodG5lc3NcbiAgICBlbHNlIGlmIChjb2RlID09PSAnQXJyb3dVcCcgfHwgY29kZSA9PT0gJ0Fycm93RG93bicpIHtcbiAgICAgIHNpZGUgPSAnbGlnaHRuZXNzJ1xuXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93RG93bicpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdkZWNyZWFzZSdcbiAgICAgIGlmIChjb2RlID09PSAnQXJyb3dVcCcpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdpbmNyZWFzZSdcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgbmVnYXRpdmUsIG5lZ2F0aXZlX21vZGlmaWVyLCBhbW91bnQsIHNpZGUsXG4gICAgfVxuICB9XG5cbiAgZGlzcGxheUNvbW1hbmQoe25lZ2F0aXZlLCBuZWdhdGl2ZV9tb2RpZmllciwgc2lkZSwgYW1vdW50fSkge1xuICAgIGlmIChuZWdhdGl2ZSA9PT0gYMKxWyR7YWx0S2V5fV0gYClcbiAgICAgIG5lZ2F0aXZlID0gJ1tpbmNyZWFzZS9kZWNyZWFzZV0nXG4gICAgaWYgKG5lZ2F0aXZlX21vZGlmaWVyID09PSAnIHRvICcpXG4gICAgICBuZWdhdGl2ZV9tb2RpZmllciA9ICcgYnkgJ1xuXG4gICAgcmV0dXJuIGBcbiAgICAgIDxzcGFuIG5lZ2F0aXZlPiR7bmVnYXRpdmV9PC9zcGFuPlxuICAgICAgPHNwYW4gc2lkZSB0b29sPiR7c2lkZX08L3NwYW4+XG4gICAgICA8c3BhbiBsaWdodD4ke25lZ2F0aXZlX21vZGlmaWVyfTwvc3Bhbj5cbiAgICAgIDxzcGFuIGFtb3VudD4ke2Ftb3VudH08L3NwYW4+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1odWVzaGlmdCcsIEh1ZXNoaWZ0SG90a2V5cylcbiIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuaW1wb3J0IHsgYm94c2hhZG93IGFzIGljb24gfSBmcm9tICcuLi92aXMtYnVnL3Zpcy1idWcuaWNvbnMnXG5pbXBvcnQgeyBtZXRhS2V5IH0gZnJvbSAnLi4vLi4vdXRpbGl0aWVzJztcblxuZXhwb3J0IGNsYXNzIEJveHNoYWRvd0hvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICAgPSAnZCdcbiAgICB0aGlzLl91c2Vka2V5cyAgPSBbJ3NoaWZ0JyxtZXRhS2V5XVxuICAgIHRoaXMudG9vbCAgICAgICA9ICdib3hzaGFkb3cnXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxhcnRpY2xlPlxuICAgICAgICA8ZGl2IHRvb2wtaWNvbj5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICR7aWNvbn1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICBjb21pbmcgc29vblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLWJveHNoYWRvdycsIEJveHNoYWRvd0hvdGtleXMpXG4iLCJpbXBvcnQgeyBIb3RrZXlNYXAgfSBmcm9tICcuL2Jhc2UuZWxlbWVudCdcbmltcG9ydCB7IHBvc2l0aW9uIGFzIGljb24gfSBmcm9tICcuLi92aXMtYnVnL3Zpcy1idWcuaWNvbnMnXG5pbXBvcnQgeyBhbHRLZXkgfSBmcm9tICcuLi8uLi91dGlsaXRpZXMnO1xuXG5leHBvcnQgY2xhc3MgUG9zaXRpb25Ib3RrZXlzIGV4dGVuZHMgSG90a2V5TWFwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5faG90a2V5ICAgID0gJ2wnXG4gICAgdGhpcy5fdXNlZGtleXMgID0gWydzaGlmdCcsYWx0S2V5XVxuICAgIHRoaXMudG9vbCAgICAgICA9ICdwb3NpdGlvbidcbiAgfVxuXG4gIGNvbm5lY3RlZENhbGxiYWNrKCkge31cblxuICBzaG93KCkge1xuICAgIHRoaXMuJHNoYWRvdy5ob3N0LnN0eWxlLmRpc3BsYXkgPSAnZmxleCdcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcygpfVxuICAgICAgPGFydGljbGU+XG4gICAgICAgIDxkaXYgdG9vbC1pY29uPlxuICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgJHtpY29ufVxuICAgICAgICAgICAgJHt0aGlzLl90b29sfSBUb29sXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjb21tYW5kPlxuICAgICAgICAgIGNvbWluZyBzb29uXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9hcnRpY2xlPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ2hvdGtleXMtcG9zaXRpb24nLCBQb3NpdGlvbkhvdGtleXMpXG4iLCJpbXBvcnQgeyBIb3RrZXlNYXAgfSBmcm9tICcuL2Jhc2UuZWxlbWVudCdcbmltcG9ydCB7IG1ldGFLZXksIGFsdEtleSB9IGZyb20gJy4uLy4uL3V0aWxpdGllcyc7XG5cbmV4cG9ydCBjbGFzcyBGb250SG90a2V5cyBleHRlbmRzIEhvdGtleU1hcCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMuX2hvdGtleSAgICA9ICdmJ1xuICAgIHRoaXMuX3VzZWRrZXlzICA9IFsnc2hpZnQnLG1ldGFLZXldXG4gICAgdGhpcy50b29sICAgICAgID0gJ2ZvbnQnXG4gIH1cblxuICBjcmVhdGVDb21tYW5kKHtlOntjb2RlfSwgaG90a2V5c30pIHtcbiAgICBsZXQgYW1vdW50ICAgICAgICAgICAgICA9IGhvdGtleXMuc2hpZnQgPyAxMCA6IDFcbiAgICBsZXQgbmVnYXRpdmUgICAgICAgICAgICA9ICdbaW5jcmVhc2UvZGVjcmVhc2VdJ1xuICAgIGxldCBuZWdhdGl2ZV9tb2RpZmllciAgID0gJ2J5J1xuICAgIGxldCBzaWRlICAgICAgICAgICAgICAgID0gJ1thcnJvdyBrZXldJ1xuXG4gICAgLy8ga2VybmluZ1xuICAgIGlmIChob3RrZXlzLnNoaWZ0ICYmIChjb2RlID09PSAnQXJyb3dMZWZ0JyB8fCBjb2RlID09PSAnQXJyb3dSaWdodCcpKSB7XG4gICAgICBzaWRlICAgID0gJ2tlcm5pbmcnXG4gICAgICBhbW91bnQgID0gJzFweCdcblxuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd0xlZnQnKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnZGVjcmVhc2UnXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93UmlnaHQnKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnaW5jcmVhc2UnXG4gICAgfVxuICAgIC8vIGxlYWRpbmdcbiAgICBlbHNlIGlmIChob3RrZXlzLnNoaWZ0ICYmIChjb2RlID09PSAnQXJyb3dVcCcgfHwgY29kZSA9PT0gJ0Fycm93RG93bicpKSB7XG4gICAgICBzaWRlICAgID0gJ2xlYWRpbmcnXG4gICAgICBhbW91bnQgID0gJzFweCdcblxuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd1VwJylcbiAgICAgICAgbmVnYXRpdmUgID0gJ2luY3JlYXNlJ1xuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd0Rvd24nKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnZGVjcmVhc2UnXG4gICAgfVxuICAgIC8vIGZvbnQgd2VpZ2h0XG4gICAgZWxzZSBpZiAoaG90a2V5cy5jbWQgJiYgKGNvZGUgPT09ICdBcnJvd1VwJyB8fCBjb2RlID09PSAnQXJyb3dEb3duJykpIHtcbiAgICAgIHNpZGUgICAgICAgICAgICAgICAgPSAnZm9udCB3ZWlnaHQnXG4gICAgICBhbW91bnQgICAgICAgICAgICAgID0gJydcbiAgICAgIG5lZ2F0aXZlX21vZGlmaWVyICAgPSAnJ1xuXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93VXAnKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnaW5jcmVhc2UnXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93RG93bicpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdkZWNyZWFzZSdcbiAgICB9XG4gICAgLy8gZm9udCBzaXplXG4gICAgZWxzZSBpZiAoY29kZSA9PT0gJ0Fycm93VXAnIHx8IGNvZGUgPT09ICdBcnJvd0Rvd24nKSB7XG4gICAgICBzaWRlICAgID0gJ2ZvbnQgc2l6ZSdcbiAgICAgIGFtb3VudCAgPSAnMXB4J1xuXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93VXAnKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnaW5jcmVhc2UnXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93RG93bicpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdkZWNyZWFzZSdcbiAgICB9XG4gICAgLy8gdGV4dCBhbGlnbm1lbnRcbiAgICBlbHNlIGlmIChjb2RlID09PSAnQXJyb3dSaWdodCcgfHwgY29kZSA9PT0gJ0Fycm93TGVmdCcpIHtcbiAgICAgIHNpZGUgICAgICAgICAgICAgICAgPSAndGV4dCBhbGlnbm1lbnQnXG4gICAgICBhbW91bnQgICAgICAgICAgICAgID0gJydcbiAgICAgIG5lZ2F0aXZlICAgICAgICAgICAgPSAnYWRqdXN0J1xuICAgICAgbmVnYXRpdmVfbW9kaWZpZXIgICA9ICcnXG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG5lZ2F0aXZlLCBuZWdhdGl2ZV9tb2RpZmllciwgYW1vdW50LCBzaWRlLFxuICAgIH1cbiAgfVxuXG4gIGRpc3BsYXlDb21tYW5kKHtuZWdhdGl2ZSwgbmVnYXRpdmVfbW9kaWZpZXIsIHNpZGUsIGFtb3VudH0pIHtcbiAgICBpZiAobmVnYXRpdmUgPT09IGDCsVske2FsdEtleX1dIGApXG4gICAgICBuZWdhdGl2ZSA9ICdbaW5jcmVhc2UvZGVjcmVhc2VdJ1xuICAgIGlmIChuZWdhdGl2ZV9tb2RpZmllciA9PT0gJyB0byAnKVxuICAgICAgbmVnYXRpdmVfbW9kaWZpZXIgPSAnIGJ5ICdcblxuICAgIHJldHVybiBgXG4gICAgICA8c3BhbiBuZWdhdGl2ZT4ke25lZ2F0aXZlfTwvc3Bhbj5cbiAgICAgIDxzcGFuIHNpZGUgdG9vbD4ke3NpZGV9PC9zcGFuPlxuICAgICAgPHNwYW4gbGlnaHQ+JHtuZWdhdGl2ZV9tb2RpZmllcn08L3NwYW4+XG4gICAgICA8c3BhbiBhbW91bnQ+JHthbW91bnR9PC9zcGFuPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ2hvdGtleXMtZm9udCcsIEZvbnRIb3RrZXlzKVxuIiwiaW1wb3J0IHsgSG90a2V5TWFwIH0gZnJvbSAnLi9iYXNlLmVsZW1lbnQnXG5pbXBvcnQgeyB0ZXh0IGFzIGljb24gfSBmcm9tICcuLi92aXMtYnVnL3Zpcy1idWcuaWNvbnMnXG5cbmV4cG9ydCBjbGFzcyBUZXh0SG90a2V5cyBleHRlbmRzIEhvdGtleU1hcCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMuX2hvdGtleSAgICA9ICdlJ1xuICAgIHRoaXMuX3VzZWRrZXlzICA9IFtdXG4gICAgdGhpcy50b29sICAgICAgID0gJ3RleHQnXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxhcnRpY2xlPlxuICAgICAgICA8ZGl2IHRvb2wtaWNvbj5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICR7aWNvbn1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICBjb21pbmcgc29vblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLXRleHQnLCBUZXh0SG90a2V5cylcbiIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuaW1wb3J0IHsgc2VhcmNoIGFzIGljb24gfSBmcm9tICcuLi92aXMtYnVnL3Zpcy1idWcuaWNvbnMnXG5cbmV4cG9ydCBjbGFzcyBTZWFyY2hIb3RrZXlzIGV4dGVuZHMgSG90a2V5TWFwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5faG90a2V5ICAgID0gJ3MnXG4gICAgdGhpcy5fdXNlZGtleXMgID0gW11cbiAgICB0aGlzLnRvb2wgICAgICAgPSAnc2VhcmNoJ1xuICB9XG5cbiAgY29ubmVjdGVkQ2FsbGJhY2soKSB7fVxuXG4gIHNob3coKSB7XG4gICAgdGhpcy4kc2hhZG93Lmhvc3Quc3R5bGUuZGlzcGxheSA9ICdmbGV4J1xuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiBgXG4gICAgICAke3RoaXMuc3R5bGVzKCl9XG4gICAgICA8YXJ0aWNsZT5cbiAgICAgICAgPGRpdiB0b29sLWljb24+XG4gICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAke2ljb259XG4gICAgICAgICAgICAke3RoaXMuX3Rvb2x9IFRvb2xcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNvbW1hbmQ+XG4gICAgICAgICAgY29taW5nIHNvb25cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2FydGljbGU+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1zZWFyY2gnLCBTZWFyY2hIb3RrZXlzKVxuIiwiaW1wb3J0ICQgICAgICAgIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzICBmcm9tICdob3RrZXlzLWpzJ1xuXG5pbXBvcnQgeyBHdWlkZXNIb3RrZXlzIH0gICAgICAgIGZyb20gJy4vZ3VpZGVzLmVsZW1lbnQnXG5pbXBvcnQgeyBJbnNwZWN0b3JIb3RrZXlzIH0gICAgIGZyb20gJy4vaW5zcGVjdG9yLmVsZW1lbnQnXG5pbXBvcnQgeyBBY2Nlc3NpYmlsaXR5SG90a2V5cyB9IGZyb20gJy4vYWNjZXNzaWJpbGl0eS5lbGVtZW50J1xuaW1wb3J0IHsgTW92ZUhvdGtleXMgfSAgICAgICAgICBmcm9tICcuL21vdmUuZWxlbWVudCdcbmltcG9ydCB7IE1hcmdpbkhvdGtleXMgfSAgICAgICAgZnJvbSAnLi9tYXJnaW4uZWxlbWVudCdcbmltcG9ydCB7IFBhZGRpbmdIb3RrZXlzIH0gICAgICAgZnJvbSAnLi9wYWRkaW5nLmVsZW1lbnQnXG5pbXBvcnQgeyBBbGlnbkhvdGtleXMgfSAgICAgICAgIGZyb20gJy4vYWxpZ24uZWxlbWVudCdcbmltcG9ydCB7IEh1ZXNoaWZ0SG90a2V5cyB9ICAgICAgZnJvbSAnLi9odWVzaGlmdC5lbGVtZW50J1xuaW1wb3J0IHsgQm94c2hhZG93SG90a2V5cyB9ICAgICBmcm9tICcuL2JveHNoYWRvdy5lbGVtZW50J1xuaW1wb3J0IHsgUG9zaXRpb25Ib3RrZXlzIH0gICAgICBmcm9tICcuL3Bvc2l0aW9uLmVsZW1lbnQnXG5pbXBvcnQgeyBGb250SG90a2V5cyB9ICAgICAgICAgIGZyb20gJy4vZm9udC5lbGVtZW50J1xuaW1wb3J0IHsgVGV4dEhvdGtleXMgfSAgICAgICAgICBmcm9tICcuL3RleHQuZWxlbWVudCdcbmltcG9ydCB7IFNlYXJjaEhvdGtleXMgfSAgICAgICAgZnJvbSAnLi9zZWFyY2guZWxlbWVudCdcblxuZXhwb3J0IGNsYXNzIEhvdGtleXMgZXh0ZW5kcyBIVE1MRWxlbWVudCB7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy50b29sX21hcCA9IHtcbiAgICAgIGd1aWRlczogICAgICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdob3RrZXlzLWd1aWRlcycpLFxuICAgICAgaW5zcGVjdG9yOiAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtaW5zcGVjdG9yJyksXG4gICAgICBhY2Nlc3NpYmlsaXR5OiAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaG90a2V5cy1hY2Nlc3NpYmlsaXR5JyksXG4gICAgICBtb3ZlOiAgICAgICAgICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaG90a2V5cy1tb3ZlJyksXG4gICAgICBtYXJnaW46ICAgICAgICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaG90a2V5cy1tYXJnaW4nKSxcbiAgICAgIHBhZGRpbmc6ICAgICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdob3RrZXlzLXBhZGRpbmcnKSxcbiAgICAgIGFsaWduOiAgICAgICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdob3RrZXlzLWFsaWduJyksXG4gICAgICBodWVzaGlmdDogICAgICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaG90a2V5cy1odWVzaGlmdCcpLFxuICAgICAgYm94c2hhZG93OiAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtYm94c2hhZG93JyksXG4gICAgICBwb3NpdGlvbjogICAgICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaG90a2V5cy1wb3NpdGlvbicpLFxuICAgICAgZm9udDogICAgICAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtZm9udCcpLFxuICAgICAgdGV4dDogICAgICAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtdGV4dCcpLFxuICAgICAgc2VhcmNoOiAgICAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtc2VhcmNoJyksXG4gICAgfVxuXG4gICAgT2JqZWN0LnZhbHVlcyh0aGlzLnRvb2xfbWFwKS5mb3JFYWNoKHRvb2wgPT5cbiAgICAgIHRoaXMuYXBwZW5kQ2hpbGQodG9vbCkpXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICBob3RrZXlzKCdzaGlmdCsvJywgZSA9PlxuICAgICAgdGhpcy5jdXJfdG9vbFxuICAgICAgICA/IHRoaXMuaGlkZVRvb2woKVxuICAgICAgICA6IHRoaXMuc2hvd1Rvb2woKSlcblxuICAgIGhvdGtleXMoJ2VzYycsIGUgPT4gdGhpcy5oaWRlVG9vbCgpKVxuICB9XG5cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7fVxuXG4gIGhpZGVUb29sKCkge1xuICAgIGlmICghdGhpcy5jdXJfdG9vbCkgcmV0dXJuXG4gICAgdGhpcy5jdXJfdG9vbC5oaWRlKClcbiAgICB0aGlzLmN1cl90b29sID0gbnVsbFxuICB9XG5cbiAgc2hvd1Rvb2woKSB7XG4gICAgdGhpcy5jdXJfdG9vbCA9IHRoaXMudG9vbF9tYXBbXG4gICAgICAkKCd2aXMtYnVnJylbMF0uYWN0aXZlVG9vbF1cbiAgICB0aGlzLmN1cl90b29sLnNob3coKVxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgndmlzYnVnLWhvdGtleXMnLCBIb3RrZXlzKVxuIiwiaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCB7IG1ldGFLZXksIGdldFN0eWxlLCBnZXRTaWRlLCBzaG93SGlkZVNlbGVjdGVkIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuLy8gdG9kbzogc2hvdyBtYXJnaW4gY29sb3JcbmNvbnN0IGtleV9ldmVudHMgPSAndXAsZG93bixsZWZ0LHJpZ2h0J1xuICAuc3BsaXQoJywnKVxuICAucmVkdWNlKChldmVudHMsIGV2ZW50KSA9PlxuICAgIGAke2V2ZW50c30sJHtldmVudH0sYWx0KyR7ZXZlbnR9LHNoaWZ0KyR7ZXZlbnR9LHNoaWZ0K2FsdCske2V2ZW50fWBcbiAgLCAnJylcbiAgLnN1YnN0cmluZygxKVxuXG5jb25zdCBjb21tYW5kX2V2ZW50cyA9IGAke21ldGFLZXl9K3VwLCR7bWV0YUtleX0rc2hpZnQrdXAsJHttZXRhS2V5fStkb3duLCR7bWV0YUtleX0rc2hpZnQrZG93bmBcblxuZXhwb3J0IGZ1bmN0aW9uIE1hcmdpbih7c2VsZWN0aW9ufSkge1xuICBob3RrZXlzKGtleV9ldmVudHMsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgaWYgKGUuY2FuY2VsQnViYmxlKSByZXR1cm5cblxuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHB1c2hFbGVtZW50KHNlbGVjdGlvbigpLCBoYW5kbGVyLmtleSlcbiAgfSlcblxuICBob3RrZXlzKGNvbW1hbmRfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHB1c2hBbGxFbGVtZW50U2lkZXMoc2VsZWN0aW9uKCksIGhhbmRsZXIua2V5KVxuICB9KVxuXG4gIHJldHVybiAoKSA9PiB7XG4gICAgaG90a2V5cy51bmJpbmQoa2V5X2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZChjb21tYW5kX2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZCgndXAsZG93bixsZWZ0LHJpZ2h0JykgLy8gYnVnIGluIGxpYj9cbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcHVzaEVsZW1lbnQoZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbCA9PiBzaG93SGlkZVNlbGVjdGVkKGVsKSlcbiAgICAubWFwKGVsID0+ICh7XG4gICAgICBlbCxcbiAgICAgIHN0eWxlOiAgICAnbWFyZ2luJyArIGdldFNpZGUoZGlyZWN0aW9uKSxcbiAgICAgIGN1cnJlbnQ6ICBwYXJzZUludChnZXRTdHlsZShlbCwgJ21hcmdpbicgKyBnZXRTaWRlKGRpcmVjdGlvbikpLCAxMCksXG4gICAgICBhbW91bnQ6ICAgZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ3NoaWZ0JykgPyAxMCA6IDEsXG4gICAgICBuZWdhdGl2ZTogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ2FsdCcpLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIG1hcmdpbjogcGF5bG9hZC5uZWdhdGl2ZVxuICAgICAgICAgID8gcGF5bG9hZC5jdXJyZW50IC0gcGF5bG9hZC5hbW91bnRcbiAgICAgICAgICA6IHBheWxvYWQuY3VycmVudCArIHBheWxvYWQuYW1vdW50XG4gICAgICB9KSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgbWFyZ2lufSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IGAke21hcmdpbiA8IDAgPyAwIDogbWFyZ2lufXB4YClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHB1c2hBbGxFbGVtZW50U2lkZXMoZWxzLCBrZXljb21tYW5kKSB7XG4gIGNvbnN0IGNvbWJvID0ga2V5Y29tbWFuZC5zcGxpdCgnKycpXG4gIGxldCBzcG9vZiA9ICcnXG5cbiAgaWYgKGNvbWJvLmluY2x1ZGVzKCdzaGlmdCcpKSAgc3Bvb2YgPSAnc2hpZnQrJyArIHNwb29mXG4gIGlmIChjb21iby5pbmNsdWRlcygnZG93bicpKSAgIHNwb29mID0gJ2FsdCsnICsgc3Bvb2ZcblxuICAndXAsZG93bixsZWZ0LHJpZ2h0Jy5zcGxpdCgnLCcpXG4gICAgLmZvckVhY2goc2lkZSA9PiBwdXNoRWxlbWVudChlbHMsIHNwb29mICsgc2lkZSkpXG59XG4iLCJpbXBvcnQgaG90a2V5cyBmcm9tICdob3RrZXlzLWpzJ1xuaW1wb3J0IHsgZ2V0Tm9kZUluZGV4LCBzaG93RWRnZSB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmNvbnN0IGtleV9ldmVudHMgPSAndXAsZG93bixsZWZ0LHJpZ2h0J1xuLy8gdG9kbzogaW5kaWNhdG9yIGZvciB3aGVuIG5vZGUgY2FuIGRlc2NlbmRcbi8vIHRvZG86IGluZGljYXRvciB3aGVyZSBsZWZ0IGFuZCByaWdodCB3aWxsIGdvXG4vLyB0b2RvOiBoYXZlIGl0IHdvcmsgd2l0aCBzaGFkb3dET01cbmV4cG9ydCBmdW5jdGlvbiBNb3ZlYWJsZSh7c2VsZWN0aW9ufSkge1xuICBob3RrZXlzKGtleV9ldmVudHMsIChlLCB7a2V5fSkgPT4ge1xuICAgIGlmIChlLmNhbmNlbEJ1YmJsZSkgcmV0dXJuXG4gICAgICBcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG4gICAgXG4gICAgc2VsZWN0aW9uKCkuZm9yRWFjaChlbCA9PiB7XG4gICAgICBtb3ZlRWxlbWVudChlbCwga2V5KVxuICAgICAgdXBkYXRlRmVlZGJhY2soZWwpXG4gICAgfSlcbiAgfSlcblxuICByZXR1cm4gKCkgPT4ge1xuICAgIGhvdGtleXMudW5iaW5kKGtleV9ldmVudHMpXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG1vdmVFbGVtZW50KGVsLCBkaXJlY3Rpb24pIHtcbiAgaWYgKCFlbCkgcmV0dXJuXG5cbiAgc3dpdGNoKGRpcmVjdGlvbikge1xuICAgIGNhc2UgJ2xlZnQnOlxuICAgICAgaWYgKGNhbk1vdmVMZWZ0KGVsKSlcbiAgICAgICAgZWwucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoZWwsIGVsLnByZXZpb3VzRWxlbWVudFNpYmxpbmcpXG4gICAgICBlbHNlXG4gICAgICAgIHNob3dFZGdlKGVsLnBhcmVudE5vZGUpXG4gICAgICBicmVha1xuXG4gICAgY2FzZSAncmlnaHQnOlxuICAgICAgaWYgKGNhbk1vdmVSaWdodChlbCkgJiYgZWwubmV4dEVsZW1lbnRTaWJsaW5nLm5leHRTaWJsaW5nKVxuICAgICAgICBlbC5wYXJlbnROb2RlLmluc2VydEJlZm9yZShlbCwgZWwubmV4dEVsZW1lbnRTaWJsaW5nLm5leHRTaWJsaW5nKVxuICAgICAgZWxzZSBpZiAoY2FuTW92ZVJpZ2h0KGVsKSlcbiAgICAgICAgZWwucGFyZW50Tm9kZS5hcHBlbmRDaGlsZChlbClcbiAgICAgIGVsc2VcbiAgICAgICAgc2hvd0VkZ2UoZWwucGFyZW50Tm9kZSlcbiAgICAgIGJyZWFrXG5cbiAgICBjYXNlICd1cCc6XG4gICAgICBpZiAoY2FuTW92ZVVwKGVsKSlcbiAgICAgICAgcG9wT3V0KHtlbH0pXG4gICAgICBicmVha1xuXG4gICAgY2FzZSAnZG93bic6XG4gICAgICBpZiAoY2FuTW92ZVVuZGVyKGVsKSlcbiAgICAgICAgcG9wT3V0KHtlbCwgdW5kZXI6IHRydWV9KVxuICAgICAgZWxzZSBpZiAoY2FuTW92ZURvd24oZWwpKVxuICAgICAgICBlbC5uZXh0RWxlbWVudFNpYmxpbmcucHJlcGVuZChlbClcbiAgICAgIGJyZWFrXG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IGNhbk1vdmVMZWZ0ICAgID0gZWwgPT4gZWwucHJldmlvdXNFbGVtZW50U2libGluZ1xuZXhwb3J0IGNvbnN0IGNhbk1vdmVSaWdodCAgID0gZWwgPT4gZWwubmV4dEVsZW1lbnRTaWJsaW5nXG5leHBvcnQgY29uc3QgY2FuTW92ZURvd24gICAgPSBlbCA9PiBlbC5uZXh0RWxlbWVudFNpYmxpbmcgJiYgZWwubmV4dEVsZW1lbnRTaWJsaW5nLmNoaWxkcmVuLmxlbmd0aFxuZXhwb3J0IGNvbnN0IGNhbk1vdmVVbmRlciAgID0gZWwgPT4gIWVsLm5leHRFbGVtZW50U2libGluZyAmJiBlbC5wYXJlbnROb2RlICYmIGVsLnBhcmVudE5vZGUucGFyZW50Tm9kZVxuZXhwb3J0IGNvbnN0IGNhbk1vdmVVcCAgICAgID0gZWwgPT4gZWwucGFyZW50Tm9kZSAmJiBlbC5wYXJlbnROb2RlLnBhcmVudE5vZGVcblxuZXhwb3J0IGNvbnN0IHBvcE91dCA9ICh7ZWwsIHVuZGVyID0gZmFsc2V9KSA9PlxuICBlbC5wYXJlbnROb2RlLnBhcmVudE5vZGUuaW5zZXJ0QmVmb3JlKGVsLCBcbiAgICBlbC5wYXJlbnROb2RlLnBhcmVudE5vZGUuY2hpbGRyZW5bXG4gICAgICB1bmRlclxuICAgICAgICA/IGdldE5vZGVJbmRleChlbCkgKyAxXG4gICAgICAgIDogZ2V0Tm9kZUluZGV4KGVsKV0pIFxuXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlRmVlZGJhY2soZWwpIHtcbiAgbGV0IG9wdGlvbnMgPSAnJ1xuICAvLyBnZXQgY3VycmVudCBlbGVtZW50cyBvZmZzZXQvc2l6ZVxuICBpZiAoY2FuTW92ZUxlZnQoZWwpKSAgb3B0aW9ucyArPSAn4oegJ1xuICBpZiAoY2FuTW92ZVJpZ2h0KGVsKSkgb3B0aW9ucyArPSAn4oeiJ1xuICBpZiAoY2FuTW92ZURvd24oZWwpKSAgb3B0aW9ucyArPSAn4oejJ1xuICBpZiAoY2FuTW92ZVVwKGVsKSkgICAgb3B0aW9ucyArPSAn4oehJ1xuICAvLyBjcmVhdGUvbW92ZSBhcnJvd3MgaW4gYWJzb2x1dGUvZml4ZWQgdG8gb3ZlcmxheSBlbGVtZW50XG4gIG9wdGlvbnMgJiYgY29uc29sZS5pbmZvKCclYycrb3B0aW9ucywgXCJmb250LXNpemU6IDJyZW07XCIpXG59IiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IHsgZ2V0U3R5bGUgfSBmcm9tICcuLi91dGlsaXRpZXMvJ1xuXG5sZXQgaW1ncyAgICAgID0gW11cbiAgLCBvdmVybGF5cyAgPSBbXVxuICAsIGRyYWdJdGVtXG5cbmV4cG9ydCBmdW5jdGlvbiB3YXRjaEltYWdlc0ZvclVwbG9hZCgpIHtcbiAgaW1ncyA9ICQoW1xuICAgIC4uLmRvY3VtZW50LmltYWdlcyxcbiAgICAuLi5maW5kQmFja2dyb3VuZEltYWdlcyhkb2N1bWVudCksXG4gIF0pXG5cbiAgY2xlYXJXYXRjaGVycyhpbWdzKVxuICBpbml0V2F0Y2hlcnMoaW1ncylcbn1cblxuY29uc3QgaW5pdFdhdGNoZXJzID0gaW1ncyA9PiB7XG4gIGltZ3Mub24oJ2RyYWdvdmVyJywgb25EcmFnRW50ZXIpXG4gIGltZ3Mub24oJ2RyYWdsZWF2ZScsIG9uRHJhZ0xlYXZlKVxuICBpbWdzLm9uKCdkcm9wJywgb25Ecm9wKVxuICAkKGRvY3VtZW50LmJvZHkpLm9uKCdkcmFnb3ZlcicsIG9uRHJhZ0VudGVyKVxuICAkKGRvY3VtZW50LmJvZHkpLm9uKCdkcmFnbGVhdmUnLCBvbkRyYWdMZWF2ZSlcbiAgJChkb2N1bWVudC5ib2R5KS5vbignZHJvcCcsIG9uRHJvcClcbiAgJChkb2N1bWVudC5ib2R5KS5vbignZHJhZ3N0YXJ0Jywgb25EcmFnU3RhcnQpXG4gICQoZG9jdW1lbnQuYm9keSkub24oJ2RyYWdlbmQnLCBvbkRyYWdFbmQpXG59XG5cbmNvbnN0IGNsZWFyV2F0Y2hlcnMgPSBpbWdzID0+IHtcbiAgaW1ncy5vZmYoJ2RyYWdlbnRlcicsIG9uRHJhZ0VudGVyKVxuICBpbWdzLm9mZignZHJhZ2xlYXZlJywgb25EcmFnTGVhdmUpXG4gIGltZ3Mub2ZmKCdkcm9wJywgb25Ecm9wKVxuICAkKGRvY3VtZW50LmJvZHkpLm9mZignZHJhZ2VudGVyJywgb25EcmFnRW50ZXIpXG4gICQoZG9jdW1lbnQuYm9keSkub2ZmKCdkcmFnbGVhdmUnLCBvbkRyYWdMZWF2ZSlcbiAgJChkb2N1bWVudC5ib2R5KS5vZmYoJ2Ryb3AnLCBvbkRyb3ApXG4gICQoZG9jdW1lbnQuYm9keSkub24oJ2RyYWdzdGFydCcsIG9uRHJhZ1N0YXJ0KVxuICAkKGRvY3VtZW50LmJvZHkpLm9uKCdkcmFnZW5kJywgb25EcmFnRW5kKVxuICBpbWdzID0gW11cbn1cblxuY29uc3QgcHJldmlld0ZpbGUgPSBmaWxlID0+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBsZXQgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKVxuICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGZpbGUpXG4gICAgcmVhZGVyLm9ubG9hZGVuZCA9ICgpID0+IHJlc29sdmUocmVhZGVyLnJlc3VsdClcbiAgfSlcbn1cblxuLy8gb25seSBmaXJlZCBmb3IgaW4tcGFnZSBkcmFnIGV2ZW50cywgdHJhY2sgd2hhdCB0aGUgdXNlciBwaWNrZWQgdXBcbmNvbnN0IG9uRHJhZ1N0YXJ0ID0gKHt0YXJnZXR9KSA9PlxuICBkcmFnSXRlbSA9IHRhcmdldFxuXG5jb25zdCBvbkRyYWdFbmQgPSBlID0+XG4gIGRyYWdJdGVtID0gdW5kZWZpbmVkXG5cbmNvbnN0IG9uRHJhZ0VudGVyID0gZSA9PiB7XG4gIGUucHJldmVudERlZmF1bHQoKVxuICBjb25zdCBwcmVfc2VsZWN0ZWQgPSAkKCdpbWdbZGF0YS1zZWxlY3RlZD10cnVlXScpXG5cbiAgaWYgKCFwcmVfc2VsZWN0ZWQubGVuZ3RoKVxuICAgIHNob3dPdmVybGF5KGUuY3VycmVudFRhcmdldCwgMClcbiAgZWxzZVxuICAgIHByZV9zZWxlY3RlZC5mb3JFYWNoKChpbWcsIGkpID0+XG4gICAgICBzaG93T3ZlcmxheShpbWcsIGkpKVxufVxuXG5jb25zdCBvbkRyYWdMZWF2ZSA9IGUgPT4gXG4gIGhpZGVPdmVybGF5cygpXG5cblxuY29uc3Qgb25Ecm9wID0gYXN5bmMgZSA9PiB7XG4gIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgY29uc3Qgc2VsZWN0ZWRJbWFnZXMgPSAkKCdpbWdbZGF0YS1zZWxlY3RlZD10cnVlXScpXG4gIFxuICBjb25zdCBzcmNzID0gZS5kYXRhVHJhbnNmZXIuZmlsZXMubGVuZ3RoIFxuICAgID8gYXdhaXQgUHJvbWlzZS5hbGwoWy4uLmUuZGF0YVRyYW5zZmVyLmZpbGVzXVxuICAgICAgLmZpbHRlcihmaWxlID0+IGZpbGUudHlwZS5pbmNsdWRlcygnaW1hZ2UnKSlcbiAgICAgIC5tYXAocHJldmlld0ZpbGUpKSBcbiAgICA6IFtkcmFnSXRlbS5zcmNdXG4gIFxuICBpZiAoc3Jjcy5sZW5ndGgpIHtcbiAgICBpZiAoIXNlbGVjdGVkSW1hZ2VzLmxlbmd0aClcbiAgICAgIGlmIChlLnRhcmdldC5ub2RlTmFtZSA9PT0gJ0lNRycpXG4gICAgICAgIGUudGFyZ2V0LnNyYyA9IHNyY3NbMF1cbiAgICAgIGVsc2VcbiAgICAgICAgaW1nc1xuICAgICAgICAgIC5maWx0ZXIoaW1nID0+IGltZy5jb250YWlucyhlLnRhcmdldCkpXG4gICAgICAgICAgLmZvckVhY2goaW1nID0+IFxuICAgICAgICAgICAgaW1nLnN0eWxlLmJhY2tncm91bmRJbWFnZSA9IGB1cmwoJHtzcmNzWzBdfSlgKVxuICAgIGVsc2UgaWYgKHNlbGVjdGVkSW1hZ2VzLmxlbmd0aCkge1xuICAgICAgbGV0IGkgPSAwXG4gICAgICBzZWxlY3RlZEltYWdlcy5mb3JFYWNoKGltZyA9PiB7XG4gICAgICAgIGltZy5zcmMgPSBzcmNzW2krK11cbiAgICAgICAgaWYgKGkgPj0gc3Jjcy5sZW5ndGgpIGkgPSAwXG4gICAgICB9KVxuICAgIH1cbiAgfVxuXG4gIGhpZGVPdmVybGF5cygpXG59XG5cbmNvbnN0IHNob3dPdmVybGF5ID0gKG5vZGUsIGkpID0+IHtcbiAgY29uc3QgcmVjdCAgICA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KClcbiAgY29uc3Qgb3ZlcmxheSA9IG92ZXJsYXlzW2ldXG5cbiAgaWYgKG92ZXJsYXkpIHtcbiAgICBvdmVybGF5LnVwZGF0ZSA9IHJlY3RcbiAgfVxuICBlbHNlIHtcbiAgICBvdmVybGF5c1tpXSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3Zpc2J1Zy1vdmVybGF5JylcbiAgICBvdmVybGF5c1tpXS5wb3NpdGlvbiA9IHJlY3RcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKG92ZXJsYXlzW2ldKVxuICB9XG59XG5cbmNvbnN0IGhpZGVPdmVybGF5cyA9ICgpID0+IHtcbiAgb3ZlcmxheXMuZm9yRWFjaChvdmVybGF5ID0+XG4gICAgb3ZlcmxheS5yZW1vdmUoKSlcbiAgb3ZlcmxheXMgPSBbXVxufVxuXG5jb25zdCBmaW5kQmFja2dyb3VuZEltYWdlcyA9IGVsID0+IHtcbiAgY29uc3Qgc3JjX3JlZ2V4ID0gL3VybFxcKFxccyo/WydcIl0/XFxzKj8oXFxTKz8pXFxzKj9bXCInXT9cXHMqP1xcKS9pXG5cbiAgcmV0dXJuICQoJyonKS5yZWR1Y2UoKGNvbGxlY3Rpb24sIG5vZGUpID0+IHtcbiAgICBjb25zdCBwcm9wID0gZ2V0U3R5bGUobm9kZSwgJ2JhY2tncm91bmQtaW1hZ2UnKVxuICAgIGNvbnN0IG1hdGNoID0gc3JjX3JlZ2V4LmV4ZWMocHJvcClcblxuICAgIC8vIGlmIChtYXRjaCkgY29sbGVjdGlvbi5wdXNoKG1hdGNoWzFdKVxuICAgIGlmIChtYXRjaCkgY29sbGVjdGlvbi5wdXNoKG5vZGUpXG5cbiAgICByZXR1cm4gY29sbGVjdGlvblxuICB9LCBbXSlcbn1cbiIsIi8qKlxyXG4gKiBAYXV0aG9yIEdlb3JnZWdyaWZmQCAoR2VvcmdlIEdyaWZmaXRocylcclxuICogTGljZW5zZSBBcGFjaGUtMi4wXHJcbiAqL1xyXG5cclxuLyoqXHJcbiogRmluZHMgZmlyc3QgbWF0Y2hpbmcgZWxlbWVudHMgb24gdGhlIHBhZ2UgdGhhdCBtYXkgYmUgaW4gYSBzaGFkb3cgcm9vdCB1c2luZyBhIGNvbXBsZXggc2VsZWN0b3Igb2Ygbi1kZXB0aFxyXG4qXHJcbiogRG9uJ3QgaGF2ZSB0byBzcGVjaWZ5IGFsbCBzaGFkb3cgcm9vdHMgdG8gYnV0dG9uLCB0cmVlIGlzIHRyYXZlcmVkIHRvIGZpbmQgdGhlIGNvcnJlY3QgZWxlbWVudFxyXG4qXHJcbiogRXhhbXBsZSBxdWVyeVNlbGVjdG9yQWxsRGVlcCgnZG93bmxvYWRzLWl0ZW06bnRoLWNoaWxkKDQpICNyZW1vdmUnKTtcclxuKlxyXG4qIEV4YW1wbGUgc2hvdWxkIHdvcmsgb24gY2hyb21lOi8vZG93bmxvYWRzIG91dHB1dHRpbmcgdGhlIHJlbW92ZSBidXR0b24gaW5zaWRlIG9mIGEgZG93bmxvYWQgY2FyZCBjb21wb25lbnRcclxuKlxyXG4qIEV4YW1wbGUgZmluZCBmaXJzdCBhY3RpdmUgZG93bmxvYWQgbGluayBlbGVtZW50IHF1ZXJ5U2VsZWN0b3JEZWVwKCcjZG93bmxvYWRzLWxpc3QgLmlzLWFjdGl2ZSBhW2hyZWZePVwiaHR0cHM6Ly9cIl0nKTtcclxuKlxyXG4qIEFub3RoZXIgZXhhbXBsZSBxdWVyeVNlbGVjdG9yQWxsRGVlcCgnI2Rvd25sb2Fkcy1saXN0IGRpdiN0aXRsZS1hcmVhICsgYScpO1xyXG5lLmcuXHJcbiovXHJcbmV4cG9ydCBmdW5jdGlvbiBxdWVyeVNlbGVjdG9yQWxsRGVlcChzZWxlY3Rvciwgcm9vdCA9IGRvY3VtZW50KSB7XHJcbiAgICByZXR1cm4gX3F1ZXJ5U2VsZWN0b3JEZWVwKHNlbGVjdG9yLCB0cnVlLCByb290KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHF1ZXJ5U2VsZWN0b3JEZWVwKHNlbGVjdG9yLCByb290ID0gZG9jdW1lbnQpIHtcclxuICAgIHJldHVybiBfcXVlcnlTZWxlY3RvckRlZXAoc2VsZWN0b3IsIGZhbHNlLCByb290KTtcclxufVxyXG5cclxuZnVuY3Rpb24gX3F1ZXJ5U2VsZWN0b3JEZWVwKHNlbGVjdG9yLCBmaW5kTWFueSwgcm9vdCkge1xyXG4gICAgbGV0IGxpZ2h0RWxlbWVudCA9IHJvb3QucXVlcnlTZWxlY3RvcihzZWxlY3Rvcik7XHJcblxyXG4gICAgaWYgKGRvY3VtZW50LmhlYWQuY3JlYXRlU2hhZG93Um9vdCB8fCBkb2N1bWVudC5oZWFkLmF0dGFjaFNoYWRvdykge1xyXG4gICAgICAgIC8vIG5vIG5lZWQgdG8gZG8gYW55IHNwZWNpYWwgaWYgc2VsZWN0b3IgbWF0Y2hlcyBzb21ldGhpbmcgc3BlY2lmaWMgaW4gbGlnaHQtZG9tXHJcbiAgICAgICAgaWYgKCFmaW5kTWFueSAmJiBsaWdodEVsZW1lbnQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGxpZ2h0RWxlbWVudDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIHNwbGl0IG9uIGNvbW1hcyBiZWNhdXNlIHRob3NlIGFyZSBhIGxvZ2ljYWwgZGl2aWRlIGluIHRoZSBvcGVyYXRpb25cclxuICAgICAgICBjb25zdCBzZWxlY3Rpb25zVG9NYWtlID0gc3BsaXRCeUNoYXJhY3RlclVubGVzc1F1b3RlZChzZWxlY3RvciwgJywnKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHNlbGVjdGlvbnNUb01ha2UucmVkdWNlKChhY2MsIG1pbmltYWxTZWxlY3RvcikgPT4ge1xyXG4gICAgICAgICAgICAvLyBpZiBub3QgZmluZGluZyBtYW55IGp1c3QgcmVkdWNlIHRoZSBmaXJzdCBtYXRjaFxyXG4gICAgICAgICAgICBpZiAoIWZpbmRNYW55ICYmIGFjYykge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGFjYztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyBkbyBiZXN0IHRvIHN1cHBvcnQgY29tcGxleCBzZWxlY3RvcnMgYW5kIHNwbGl0IHRoZSBxdWVyeVxyXG4gICAgICAgICAgICBjb25zdCBzcGxpdFNlbGVjdG9yID0gc3BsaXRCeUNoYXJhY3RlclVubGVzc1F1b3RlZChtaW5pbWFsU2VsZWN0b3JcclxuICAgICAgICAgICAgICAgICAgICAvL3JlbW92ZSB3aGl0ZSBzcGFjZSBhdCBzdGFydCBvZiBzZWxlY3RvclxyXG4gICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9eXFxzKy9nLCAnJylcclxuICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvXFxzKihbPit+XSspXFxzKi9nLCAnJDEnKSwgJyAnKVxyXG4gICAgICAgICAgICAgICAgLy8gZmlsdGVyIG91dCBlbnRyeSB3aGl0ZSBzZWxlY3RvcnNcclxuICAgICAgICAgICAgICAgIC5maWx0ZXIoKGVudHJ5KSA9PiAhIWVudHJ5KTtcclxuICAgICAgICAgICAgY29uc3QgcG9zc2libGVFbGVtZW50c0luZGV4ID0gc3BsaXRTZWxlY3Rvci5sZW5ndGggLSAxO1xyXG4gICAgICAgICAgICBjb25zdCBwb3NzaWJsZUVsZW1lbnRzID0gY29sbGVjdEFsbEVsZW1lbnRzRGVlcChzcGxpdFNlbGVjdG9yW3Bvc3NpYmxlRWxlbWVudHNJbmRleF0sIHJvb3QpO1xyXG4gICAgICAgICAgICBjb25zdCBmaW5kRWxlbWVudHMgPSBmaW5kTWF0Y2hpbmdFbGVtZW50KHNwbGl0U2VsZWN0b3IsIHBvc3NpYmxlRWxlbWVudHNJbmRleCwgcm9vdCk7XHJcbiAgICAgICAgICAgIGlmIChmaW5kTWFueSkge1xyXG4gICAgICAgICAgICAgICAgYWNjID0gYWNjLmNvbmNhdChwb3NzaWJsZUVsZW1lbnRzLmZpbHRlcihmaW5kRWxlbWVudHMpKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBhY2M7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBhY2MgPSBwb3NzaWJsZUVsZW1lbnRzLmZpbmQoZmluZEVsZW1lbnRzKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBhY2MgfHwgbnVsbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIGZpbmRNYW55ID8gW10gOiBudWxsKTtcclxuXHJcblxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAoIWZpbmRNYW55KSB7XHJcbiAgICAgICAgICAgIHJldHVybiBsaWdodEVsZW1lbnQ7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIHJvb3QucXVlcnlTZWxlY3RvckFsbChzZWxlY3Rvcik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxufVxyXG5cclxuZnVuY3Rpb24gZmluZE1hdGNoaW5nRWxlbWVudChzcGxpdFNlbGVjdG9yLCBwb3NzaWJsZUVsZW1lbnRzSW5kZXgsIHJvb3QpIHtcclxuICAgIHJldHVybiAoZWxlbWVudCkgPT4ge1xyXG4gICAgICAgIGxldCBwb3NpdGlvbiA9IHBvc3NpYmxlRWxlbWVudHNJbmRleDtcclxuICAgICAgICBsZXQgcGFyZW50ID0gZWxlbWVudDtcclxuICAgICAgICBsZXQgZm91bmRFbGVtZW50ID0gZmFsc2U7XHJcbiAgICAgICAgd2hpbGUgKHBhcmVudCkge1xyXG4gICAgICAgICAgICBjb25zdCBmb3VuZE1hdGNoID0gcGFyZW50Lm1hdGNoZXMoc3BsaXRTZWxlY3Rvcltwb3NpdGlvbl0pO1xyXG4gICAgICAgICAgICBpZiAoZm91bmRNYXRjaCAmJiBwb3NpdGlvbiA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgZm91bmRFbGVtZW50ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChmb3VuZE1hdGNoKSB7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbi0tO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHBhcmVudCA9IGZpbmRQYXJlbnRPckhvc3QocGFyZW50LCByb290KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGZvdW5kRWxlbWVudDtcclxuICAgIH07XHJcblxyXG59XHJcblxyXG5mdW5jdGlvbiBzcGxpdEJ5Q2hhcmFjdGVyVW5sZXNzUXVvdGVkKHNlbGVjdG9yLCBjaGFyYWN0ZXIpIHtcclxuICAgIHJldHVybiBzZWxlY3Rvci5tYXRjaCgvXFxcXD8ufF4kL2cpLnJlZHVjZSgocCwgYykgPT4ge1xyXG4gICAgICAgIGlmIChjID09PSAnXCInICYmICFwLnNRdW90ZSkge1xyXG4gICAgICAgICAgICBwLnF1b3RlIF49IDE7XHJcbiAgICAgICAgICAgIHAuYVtwLmEubGVuZ3RoIC0gMV0gKz0gYztcclxuICAgICAgICB9IGVsc2UgaWYgKGMgPT09ICdcXCcnICYmICFwLnF1b3RlKSB7XHJcbiAgICAgICAgICAgIHAuc1F1b3RlIF49IDE7XHJcbiAgICAgICAgICAgIHAuYVtwLmEubGVuZ3RoIC0gMV0gKz0gYztcclxuXHJcbiAgICAgICAgfSBlbHNlIGlmICghcC5xdW90ZSAmJiAhcC5zUXVvdGUgJiYgYyA9PT0gY2hhcmFjdGVyKSB7XHJcbiAgICAgICAgICAgIHAuYS5wdXNoKCcnKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBwLmFbcC5hLmxlbmd0aCAtIDFdICs9IGM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBwO1xyXG4gICAgfSwgeyBhOiBbJyddIH0pLmE7XHJcbn1cclxuXHJcblxyXG5mdW5jdGlvbiBmaW5kUGFyZW50T3JIb3N0KGVsZW1lbnQsIHJvb3QpIHtcclxuICAgIGNvbnN0IHBhcmVudE5vZGUgPSBlbGVtZW50LnBhcmVudE5vZGU7XHJcbiAgICByZXR1cm4gKHBhcmVudE5vZGUgJiYgcGFyZW50Tm9kZS5ob3N0ICYmIHBhcmVudE5vZGUubm9kZVR5cGUgPT09IDExKSA/IHBhcmVudE5vZGUuaG9zdCA6IHBhcmVudE5vZGUgPT09IHJvb3QgPyBudWxsIDogcGFyZW50Tm9kZTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEZpbmRzIGFsbCBlbGVtZW50cyBvbiB0aGUgcGFnZSwgaW5jbHVzaXZlIG9mIHRob3NlIHdpdGhpbiBzaGFkb3cgcm9vdHMuXHJcbiAqIEBwYXJhbSB7c3RyaW5nPX0gc2VsZWN0b3IgU2ltcGxlIHNlbGVjdG9yIHRvIGZpbHRlciB0aGUgZWxlbWVudHMgYnkuIGUuZy4gJ2EnLCAnZGl2Lm1haW4nXHJcbiAqIEByZXR1cm4geyFBcnJheTxzdHJpbmc+fSBMaXN0IG9mIGFuY2hvciBocmVmcy5cclxuICogQGF1dGhvciBlYmlkZWxAIChFcmljIEJpZGVsbWFuKVxyXG4gKiBMaWNlbnNlIEFwYWNoZS0yLjBcclxuICovXHJcbmZ1bmN0aW9uIGNvbGxlY3RBbGxFbGVtZW50c0RlZXAoc2VsZWN0b3IgPSBudWxsLCByb290KSB7XHJcbiAgICBjb25zdCBhbGxFbGVtZW50cyA9IFtdO1xyXG5cclxuICAgIGNvbnN0IGZpbmRBbGxFbGVtZW50cyA9IGZ1bmN0aW9uKG5vZGVzKSB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIGVsOyBlbCA9IG5vZGVzW2ldOyArK2kpIHtcclxuICAgICAgICAgICAgYWxsRWxlbWVudHMucHVzaChlbCk7XHJcbiAgICAgICAgICAgIC8vIElmIHRoZSBlbGVtZW50IGhhcyBhIHNoYWRvdyByb290LCBkaWcgZGVlcGVyLlxyXG4gICAgICAgICAgICBpZiAoZWwuc2hhZG93Um9vdCkge1xyXG4gICAgICAgICAgICAgICAgZmluZEFsbEVsZW1lbnRzKGVsLnNoYWRvd1Jvb3QucXVlcnlTZWxlY3RvckFsbCgnKicpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH07XHJcbiAgICBpZihyb290LnNoYWRvd1Jvb3QpIHtcclxuICAgICAgICBmaW5kQWxsRWxlbWVudHMocm9vdC5zaGFkb3dSb290LnF1ZXJ5U2VsZWN0b3JBbGwoJyonKSk7XHJcbiAgICB9XHJcbiAgICBmaW5kQWxsRWxlbWVudHMocm9vdC5xdWVyeVNlbGVjdG9yQWxsKCcqJykpO1xyXG5cclxuICAgIHJldHVybiBzZWxlY3RvciA/IGFsbEVsZW1lbnRzLmZpbHRlcihlbCA9PiBlbC5tYXRjaGVzKHNlbGVjdG9yKSkgOiBhbGxFbGVtZW50cztcclxufSIsImV4cG9ydCBjb25zdCBjb21tYW5kcyA9IFtcbiAgJ2VtcHR5IHBhZ2UnLFxuICAnYmxhbmsgcGFnZScsXG4gICdjbGVhciBjYW52YXMnLFxuXVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbigpIHtcbiAgZG9jdW1lbnRcbiAgICAucXVlcnlTZWxlY3RvckFsbCgnYm9keSA+ICo6bm90KHZpcy1idWcpOm5vdChzY3JpcHQpJylcbiAgICAuZm9yRWFjaChub2RlID0+IG5vZGUucmVtb3ZlKCkpXG59XG4iLCJleHBvcnQgY29uc3QgY29tbWFuZHMgPSBbXG4gICdiYXJyZWwgcm9sbCcsXG4gICdkbyBhIGJhcnJlbCByb2xsJyxcbl1cblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24oKSB7XG4gIGRvY3VtZW50LmJvZHkuc3R5bGUudHJhbnNmb3JtT3JpZ2luID0gJ2NlbnRlciA1MHZoJ1xuICBcbiAgYXdhaXQgZG9jdW1lbnQuYm9keS5hbmltYXRlKFtcbiAgICB7IHRyYW5zZm9ybTogJ3JvdGF0ZVooMCknIH0sXG4gICAgeyB0cmFuc2Zvcm06ICdyb3RhdGVaKDF0dXJuKScgfSxcbiAgXSwgeyBkdXJhdGlvbjogMTUwMCB9KS5maW5pc2hlZFxuXG4gIGRvY3VtZW50LmJvZHkuc3R5bGUudHJhbnNmb3JtT3JpZ2luID0gJydcbn0iLCJpbXBvcnQgeyBsb2FkU3R5bGVzIH0gZnJvbSAnLi4vdXRpbGl0aWVzL3N0eWxlcy5qcydcblxuZXhwb3J0IGNvbnN0IGNvbW1hbmRzID0gW1xuICAncGVzdGljaWRlJyxcbl1cblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24oKSB7XG4gIGF3YWl0IGxvYWRTdHlsZXMoWydodHRwczovL3VucGtnLmNvbS9wZXN0aWNpZGVAMS4zLjEvY3NzL3Blc3RpY2lkZS5taW4uY3NzJ10pXG59IiwiaW1wb3J0IHsgbG9hZFN0eWxlcyB9IGZyb20gJy4uL3V0aWxpdGllcy9zdHlsZXMuanMnXG5cbmV4cG9ydCBjb25zdCBjb21tYW5kcyA9IFtcbiAgJ3RyYXNoeScsXG4gICdjb25zdHJ1Y3QnLFxuXVxuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbigpIHtcbiAgYXdhaXQgbG9hZFN0eWxlcyhbJ2h0dHBzOi8vY2RuLmpzZGVsaXZyLm5ldC9naC90Ny9jb25zdHJ1Y3QuY3NzQG1hc3Rlci9jc3MvY29uc3RydWN0LmJveGVzLmNzcyddKVxufSIsImltcG9ydCB7IGxvYWRTdHlsZXMgfSBmcm9tICcuLi91dGlsaXRpZXMvc3R5bGVzLmpzJ1xuXG5leHBvcnQgY29uc3QgY29tbWFuZHMgPSBbXG4gICdkZWJ1ZyB0cmFzaHknLFxuICAnZGVidWcgY29uc3RydWN0Jyxcbl1cblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24oKSB7XG4gIGF3YWl0IGxvYWRTdHlsZXMoWydodHRwczovL2Nkbi5qc2RlbGl2ci5uZXQvZ2gvdDcvY29uc3RydWN0LmNzc0BtYXN0ZXIvY3NzL2NvbnN0cnVjdC5kZWJ1Zy5jc3MnXSlcbn0iLCJleHBvcnQgY29uc3QgY29tbWFuZHMgPSBbXG4gICd3aXJlZnJhbWUnLFxuICAnYmx1ZXByaW50Jyxcbl1cblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24oKSB7XG4gIGNvbnN0IHN0eWxlcyA9IGBcbiAgICAqOm5vdChwYXRoKTpub3QoZykge1xuICAgICAgY29sb3I6IGhzbGEoMjEwLCAxMDAlLCAxMDAlLCAwLjkpICFpbXBvcnRhbnQ7XG4gICAgICBiYWNrZ3JvdW5kOiBoc2xhKDIxMCwgMTAwJSwgNTAlLCAwLjUpICFpbXBvcnRhbnQ7XG4gICAgICBvdXRsaW5lOiBzb2xpZCAwLjI1cmVtIGhzbGEoMjEwLCAxMDAlLCAxMDAlLCAwLjUpICFpbXBvcnRhbnQ7XG4gICAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG4gICAgfVxuICBgXG5cbiAgY29uc3Qgc3R5bGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzdHlsZScpXG4gIHN0eWxlLnRleHRDb250ZW50ID0gc3R5bGVzXG4gIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoc3R5bGUpXG59IiwiZXhwb3J0IGNvbnN0IGNvbW1hbmRzID0gW1xuICAnc2tlbGV0b24nLFxuICAnb3V0bGluZScsXG5dXG5cbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uKCkge1xuICBjb25zdCBzdHlsZXMgPSBgXG4gICAgKjpub3QocGF0aCk6bm90KGcpIHtcbiAgICAgIGNvbG9yOiBoc2woMCwgMCUsIDAlKSAhaW1wb3J0YW50O1xuICAgICAgdGV4dC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbiAgICAgIGJhY2tncm91bmQ6IGhzbCgwLCAwJSwgMTAwJSkgIWltcG9ydGFudDtcbiAgICAgIG91dGxpbmU6IDFweCBzb2xpZCBoc2xhKDAsIDAlLCAwJSwgMC41KSAhaW1wb3J0YW50O1xuICAgICAgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICAgICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuICAgIH1cbiAgYFxuXG4gIGNvbnN0IHN0eWxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKVxuICBzdHlsZS50ZXh0Q29udGVudCA9IHN0eWxlc1xuICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHN0eWxlKVxufSIsIi8vIGh0dHBzOi8vZ2lzdC5naXRodWIuY29tL2FkZHlvc21hbmkvZmQzOTk5ZWE3ZmNlMjQyNzU2YjFcbmV4cG9ydCBjb25zdCBjb21tYW5kcyA9IFtcbiAgJ3RhZyBkZWJ1Z2dlcicsXG4gICdvc21hbmknLFxuXVxuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbigpIHtcbiAgZm9yIChpID0gMDsgQSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJyonKVtpKytdOylcbiAgICBBLnN0eWxlLm91dGxpbmUgPSBgc29saWQgaHNsKCR7KEErQSkubGVuZ3RoKjl9LDk5JSw1MCUpIDFweGBcbn0iLCIvLyBodHRwOi8vaGV5ZG9ud29ya3MuY29tL3JldmVuZ2VfY3NzX2Jvb2ttYXJrbGV0L1xuXG5pbXBvcnQgeyBsb2FkU3R5bGVzIH0gZnJvbSAnLi4vdXRpbGl0aWVzL3N0eWxlcy5qcydcblxuZXhwb3J0IGNvbnN0IGNvbW1hbmRzID0gW1xuICAncmV2ZW5nZScsXG4gICdyZXZlbmdlLmNzcycsXG4gICdoZXlkb24nLFxuXVxuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbigpIHtcbiAgYXdhaXQgbG9hZFN0eWxlcyhbJ2h0dHBzOi8vY2RuLmpzZGVsaXZyLm5ldC9naC9IZXlkb24vUkVWRU5HRS5DU1NAbWFzdGVyL3JldmVuZ2UuY3NzJ10pXG59IiwiaW1wb3J0IHsgY29tbWFuZHMgYXMgYmxhbmtfcGFnZV9jb21tYW5kcywgZGVmYXVsdCBhcyBCbGFua1BhZ2VQbHVnaW4gfSBmcm9tICcuL2JsYW5rLXBhZ2UnXG5pbXBvcnQgeyBjb21tYW5kcyBhcyBiYXJyZWxfcm9sbF9jb21tYW5kcywgZGVmYXVsdCBhcyBCYXJyZWxSb2xsUGx1Z2luIH0gZnJvbSAnLi9iYXJyZWwtcm9sbCdcbmltcG9ydCB7IGNvbW1hbmRzIGFzIHBlc3RpY2lkZV9jb21tYW5kcywgZGVmYXVsdCBhcyBQZXN0aWNpZGVQbHVnaW4gfSBmcm9tICcuL3Blc3RpY2lkZSdcbmltcG9ydCB7IGNvbW1hbmRzIGFzIGNvbnN0cnVjdF9jb21tYW5kcywgZGVmYXVsdCBhcyBDb25zdHJ1Y3RQbHVnaW4gfSBmcm9tICcuL2NvbnN0cnVjdCdcbmltcG9ydCB7IGNvbW1hbmRzIGFzIGNvbnN0cnVjdF9kZWJ1Z19jb21tYW5kcywgZGVmYXVsdCBhcyBDb25zdHJ1Y3REZWJ1Z1BsdWdpbiB9IGZyb20gJy4vY29uc3RydWN0LmRlYnVnJ1xuaW1wb3J0IHsgY29tbWFuZHMgYXMgd2lyZWZyYW1lX2NvbW1hbmRzLCBkZWZhdWx0IGFzIFdpcmVmcmFtZVBsdWdpbiB9IGZyb20gJy4vd2lyZWZyYW1lJ1xuaW1wb3J0IHsgY29tbWFuZHMgYXMgc2tlbGV0b25fY29tbWFuZHMsIGRlZmF1bHQgYXMgU2tlbGV0b25QbHVnaW4gfSBmcm9tICcuL3NrZWxldG9uJ1xuaW1wb3J0IHsgY29tbWFuZHMgYXMgdGFnX2RlYnVnZ2VyX2NvbW1hbmRzLCBkZWZhdWx0IGFzIFRhZ0RlYnVnZ2VyUGx1Z2luIH0gZnJvbSAnLi90YWctZGVidWdnZXInXG5pbXBvcnQgeyBjb21tYW5kcyBhcyByZXZlbmdlX2NvbW1hbmRzLCBkZWZhdWx0IGFzIFJldmVuZ2VQbHVnaW4gfSBmcm9tICcuL3JldmVuZ2UnXG5cbmNvbnN0IGNvbW1hbmRzVG9IYXNoID0gKHBsdWdpbl9jb21tYW5kcywgcGx1Z2luX2ZuKSA9PlxuICBwbHVnaW5fY29tbWFuZHMucmVkdWNlKChjb21tYW5kcywgY29tbWFuZCkgPT5cbiAgICBPYmplY3QuYXNzaWduKGNvbW1hbmRzLCB7W2AvJHtjb21tYW5kfWBdOnBsdWdpbl9mbn0pXG4gICwge30pXG5cbmV4cG9ydCBjb25zdCBQbHVnaW5SZWdpc3RyeSA9IG5ldyBNYXAoT2JqZWN0LmVudHJpZXMoe1xuICAuLi5jb21tYW5kc1RvSGFzaChibGFua19wYWdlX2NvbW1hbmRzLCBCbGFua1BhZ2VQbHVnaW4pLFxuICAuLi5jb21tYW5kc1RvSGFzaChiYXJyZWxfcm9sbF9jb21tYW5kcywgQmFycmVsUm9sbFBsdWdpbiksXG4gIC4uLmNvbW1hbmRzVG9IYXNoKHBlc3RpY2lkZV9jb21tYW5kcywgUGVzdGljaWRlUGx1Z2luKSxcbiAgLi4uY29tbWFuZHNUb0hhc2goY29uc3RydWN0X2NvbW1hbmRzLCBDb25zdHJ1Y3RQbHVnaW4pLFxuICAuLi5jb21tYW5kc1RvSGFzaChjb25zdHJ1Y3RfZGVidWdfY29tbWFuZHMsIENvbnN0cnVjdERlYnVnUGx1Z2luKSxcbiAgLi4uY29tbWFuZHNUb0hhc2god2lyZWZyYW1lX2NvbW1hbmRzLCBXaXJlZnJhbWVQbHVnaW4pLFxuICAuLi5jb21tYW5kc1RvSGFzaChza2VsZXRvbl9jb21tYW5kcywgU2tlbGV0b25QbHVnaW4pLFxuICAuLi5jb21tYW5kc1RvSGFzaCh0YWdfZGVidWdnZXJfY29tbWFuZHMsIFRhZ0RlYnVnZ2VyUGx1Z2luKSxcbiAgLi4uY29tbWFuZHNUb0hhc2gocmV2ZW5nZV9jb21tYW5kcywgUmV2ZW5nZVBsdWdpbiksXG59KSlcblxuZXhwb3J0IGNvbnN0IFBsdWdpbkhpbnRzID0gW1xuICBibGFua19wYWdlX2NvbW1hbmRzWzBdLFxuICBiYXJyZWxfcm9sbF9jb21tYW5kc1swXSxcbiAgcGVzdGljaWRlX2NvbW1hbmRzWzBdLFxuICBjb25zdHJ1Y3RfY29tbWFuZHNbMF0sXG4gIGNvbnN0cnVjdF9kZWJ1Z19jb21tYW5kc1swXSxcbiAgd2lyZWZyYW1lX2NvbW1hbmRzWzBdLFxuICBza2VsZXRvbl9jb21tYW5kc1swXSxcbiAgdGFnX2RlYnVnZ2VyX2NvbW1hbmRzWzBdLFxuICByZXZlbmdlX2NvbW1hbmRzWzBdLFxuXS5tYXAoY29tbWFuZCA9PiBgLyR7Y29tbWFuZH1gKVxuIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCB7IHF1ZXJ5U2VsZWN0b3JBbGxEZWVwIH0gZnJvbSAncXVlcnktc2VsZWN0b3Itc2hhZG93LWRvbSdcbmltcG9ydCB7IFBsdWdpblJlZ2lzdHJ5LCBQbHVnaW5IaW50cyB9IGZyb20gJy4uL3BsdWdpbnMvX3JlZ2lzdHJ5J1xuXG5sZXQgU2VsZWN0b3JFbmdpbmVcblxuLy8gY3JlYXRlIGlucHV0XG5jb25zdCBzZWFyY2hfYmFzZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG5zZWFyY2hfYmFzZS5jbGFzc0xpc3QuYWRkKCdzZWFyY2gnKVxuc2VhcmNoX2Jhc2UuaW5uZXJIVE1MID0gYFxuICA8aW5wdXQgbGlzdD1cInZpc2J1Zy1wbHVnaW5zXCIgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cImV4OiBpbWFnZXMsIC5idG4sIGJ1dHRvbiwgdGV4dCwgLi4uXCIvPlxuICA8ZGF0YWxpc3QgaWQ9XCJ2aXNidWctcGx1Z2luc1wiPlxuICAgICR7UGx1Z2luSGludHMucmVkdWNlKChvcHRpb25zLCBjb21tYW5kKSA9PlxuICAgICAgb3B0aW9ucyArPSBgPG9wdGlvbiB2YWx1ZT1cIiR7Y29tbWFuZH1cIj5wbHVnaW48L29wdGlvbj5gXG4gICAgLCAnJyl9XG4gICAgPG9wdGlvbiB2YWx1ZT1cImgxLCBoMiwgaDMsIC5nZXQtbXVsdGlwbGVcIj5leGFtcGxlPC9vcHRpb24+XG4gICAgPG9wdGlvbiB2YWx1ZT1cIm5hdiA+IGE6Zmlyc3QtY2hpbGRcIj5leGFtcGxlPC9vcHRpb24+XG4gICAgPG9wdGlvbiB2YWx1ZT1cIiNnZXQtYnktaWRcIj5leGFtcGxlPC9vcHRpb24+XG4gICAgPG9wdGlvbiB2YWx1ZT1cIi5nZXQtYnkuY2xhc3MtbmFtZXNcIj5leGFtcGxlPC9vcHRpb24+XG4gICAgPG9wdGlvbiB2YWx1ZT1cImltYWdlc1wiPmFsaWFzPC9vcHRpb24+XG4gICAgPG9wdGlvbiB2YWx1ZT1cInRleHRcIj5hbGlhczwvb3B0aW9uPlxuICA8L2RhdGFsaXN0PlxuYFxuXG5jb25zdCBzZWFyY2ggICAgICAgID0gJChzZWFyY2hfYmFzZSlcbmNvbnN0IHNlYXJjaElucHV0ICAgPSAkKCdpbnB1dCcsIHNlYXJjaF9iYXNlKVxuXG5jb25zdCBzaG93U2VhcmNoQmFyID0gKCkgPT4gc2VhcmNoLmF0dHIoJ3N0eWxlJywgJ2Rpc3BsYXk6YmxvY2snKVxuY29uc3QgaGlkZVNlYXJjaEJhciA9ICgpID0+IHNlYXJjaC5hdHRyKCdzdHlsZScsICdkaXNwbGF5Om5vbmUnKVxuY29uc3Qgc3RvcEJ1YmJsaW5nICA9IGUgPT4gZS5rZXkgIT0gJ0VzY2FwZScgJiYgZS5zdG9wUHJvcGFnYXRpb24oKVxuXG5leHBvcnQgZnVuY3Rpb24gU2VhcmNoKG5vZGUpIHtcbiAgaWYgKG5vZGUpIG5vZGVbMF0uYXBwZW5kQ2hpbGQoc2VhcmNoWzBdKVxuXG4gIGNvbnN0IG9uUXVlcnkgPSBlID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG5cbiAgICBjb25zdCBxdWVyeSA9IGUudGFyZ2V0LnZhbHVlXG5cbiAgICB3aW5kb3cucmVxdWVzdElkbGVDYWxsYmFjayhfID0+XG4gICAgICBxdWVyeVBhZ2UocXVlcnkpKVxuICB9XG5cbiAgc2VhcmNoSW5wdXQub24oJ2lucHV0Jywgb25RdWVyeSlcbiAgc2VhcmNoSW5wdXQub24oJ2tleWRvd24nLCBzdG9wQnViYmxpbmcpXG4gIC8vIHNlYXJjaElucHV0Lm9uKCdibHVyJywgaGlkZVNlYXJjaEJhcilcblxuICBzaG93U2VhcmNoQmFyKClcbiAgc2VhcmNoSW5wdXRbMF0uZm9jdXMoKVxuXG4gIC8vIGhvdGtleXMoJ2VzY2FwZSxlc2MnLCAoZSwgaGFuZGxlcikgPT4ge1xuICAvLyAgIGhpZGVTZWFyY2hCYXIoKVxuICAvLyAgIGhvdGtleXMudW5iaW5kKCdlc2NhcGUsZXNjJylcbiAgLy8gfSlcblxuICByZXR1cm4gKCkgPT4ge1xuICAgIGhpZGVTZWFyY2hCYXIoKVxuICAgIHNlYXJjaElucHV0Lm9mZignb25pbnB1dCcsIG9uUXVlcnkpXG4gICAgc2VhcmNoSW5wdXQub2ZmKCdrZXlkb3duJywgc3RvcEJ1YmJsaW5nKVxuICAgIHNlYXJjaElucHV0Lm9mZignYmx1cicsIGhpZGVTZWFyY2hCYXIpXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHByb3ZpZGVTZWxlY3RvckVuZ2luZShFbmdpbmUpIHtcbiAgU2VsZWN0b3JFbmdpbmUgPSBFbmdpbmVcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHF1ZXJ5UGFnZShxdWVyeSwgZm4pIHtcbiAgLy8gdG9kbzogc2hvdWxkIHN0YXNoIGEgY2xlYW51cCBtZXRob2QgdG8gYmUgY2FsbGVkIHdoZW4gcXVlcnkgZG9lc250IG1hdGNoXG4gIGlmIChQbHVnaW5SZWdpc3RyeS5oYXMocXVlcnkpKVxuICAgIHJldHVybiBQbHVnaW5SZWdpc3RyeS5nZXQocXVlcnkpKHF1ZXJ5KVxuXG4gIGlmIChxdWVyeSA9PSAnbGlua3MnKSAgICAgcXVlcnkgPSAnYSdcbiAgaWYgKHF1ZXJ5ID09ICdidXR0b25zJykgICBxdWVyeSA9ICdidXR0b24nXG4gIGlmIChxdWVyeSA9PSAnaW1hZ2VzJykgICAgcXVlcnkgPSAnaW1nJ1xuICBpZiAocXVlcnkgPT0gJ3RleHQnKSAgICAgIHF1ZXJ5ID0gJ3AsY2FwdGlvbixhLGgxLGgyLGgzLGg0LGg1LGg2LHNtYWxsLGRhdGUsdGltZSxsaSxkdCxkZCdcblxuICBpZiAoIXF1ZXJ5KSByZXR1cm4gU2VsZWN0b3JFbmdpbmUudW5zZWxlY3RfYWxsKClcbiAgaWYgKHF1ZXJ5ID09ICcuJyB8fCBxdWVyeSA9PSAnIycgfHwgcXVlcnkudHJpbSgpLmVuZHNXaXRoKCcsJykpIHJldHVyblxuXG4gIHRyeSB7XG4gICAgbGV0IG1hdGNoZXMgPSBxdWVyeVNlbGVjdG9yQWxsRGVlcChxdWVyeSArICc6bm90KHZpcy1idWcpOm5vdChzY3JpcHQpOm5vdChob3RrZXktbWFwKTpub3QoLnZpc2J1Zy1tZXRhdGlwKTpub3QodmlzYnVnLWxhYmVsKTpub3QodmlzYnVnLWhhbmRsZXMpJylcbiAgICBpZiAoIW1hdGNoZXMubGVuZ3RoKSBtYXRjaGVzID0gcXVlcnlTZWxlY3RvckFsbERlZXAocXVlcnkpXG4gICAgaWYgKCFmbikgU2VsZWN0b3JFbmdpbmUudW5zZWxlY3RfYWxsKClcbiAgICBpZiAobWF0Y2hlcy5sZW5ndGgpXG4gICAgICBtYXRjaGVzLmZvckVhY2goZWwgPT5cbiAgICAgICAgZm5cbiAgICAgICAgICA/IGZuKGVsKVxuICAgICAgICAgIDogU2VsZWN0b3JFbmdpbmUuc2VsZWN0KGVsKSlcbiAgfVxuICBjYXRjaCAoZXJyKSB7fVxufVxuIiwiY29uc3Qgc3RhdGUgPSB7XG4gIGRpc3RhbmNlczogIFtdLFxuICB0YXJnZXQ6ICAgICBudWxsLFxufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlTWVhc3VyZW1lbnRzKHskYW5jaG9yLCAkdGFyZ2V0fSkge1xuICBpZiAoc3RhdGUudGFyZ2V0ID09ICR0YXJnZXQgJiYgc3RhdGUuZGlzdGFuY2VzLmxlbmd0aCkgcmV0dXJuXG4gIGVsc2Ugc3RhdGUudGFyZ2V0ID0gJHRhcmdldFxuXG4gIGlmIChzdGF0ZS5kaXN0YW5jZXMubGVuZ3RoKSBjbGVhck1lYXN1cmVtZW50cygpXG5cbiAgY29uc3QgYW5jaG9yQm91bmRzID0gJGFuY2hvci5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKVxuICBjb25zdCB0YXJnZXRCb3VuZHMgPSAkdGFyZ2V0LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpXG5cbiAgY29uc3QgbWVhc3VyZW1lbnRzID0gW11cblxuICAvLyByaWdodFxuICBpZiAoYW5jaG9yQm91bmRzLnJpZ2h0IDwgdGFyZ2V0Qm91bmRzLmxlZnQpIHtcbiAgICBtZWFzdXJlbWVudHMucHVzaCh7XG4gICAgICB4OiBhbmNob3JCb3VuZHMucmlnaHQsXG4gICAgICB5OiBhbmNob3JCb3VuZHMudG9wICsgKGFuY2hvckJvdW5kcy5oZWlnaHQgLyAyKSxcbiAgICAgIGQ6IHRhcmdldEJvdW5kcy5sZWZ0IC0gYW5jaG9yQm91bmRzLnJpZ2h0LFxuICAgICAgcTogJ3JpZ2h0JyxcbiAgICB9KVxuICB9XG4gIGlmIChhbmNob3JCb3VuZHMucmlnaHQgPCB0YXJnZXRCb3VuZHMucmlnaHQgJiYgYW5jaG9yQm91bmRzLnJpZ2h0ID4gdGFyZ2V0Qm91bmRzLmxlZnQpIHtcbiAgICBtZWFzdXJlbWVudHMucHVzaCh7XG4gICAgICB4OiBhbmNob3JCb3VuZHMucmlnaHQsXG4gICAgICB5OiBhbmNob3JCb3VuZHMudG9wICsgKGFuY2hvckJvdW5kcy5oZWlnaHQgLyAyKSxcbiAgICAgIGQ6IHRhcmdldEJvdW5kcy5yaWdodCAtIGFuY2hvckJvdW5kcy5yaWdodCxcbiAgICAgIHE6ICdyaWdodCcsXG4gICAgfSlcbiAgfVxuXG4gIC8vIGxlZnRcbiAgaWYgKGFuY2hvckJvdW5kcy5sZWZ0ID4gdGFyZ2V0Qm91bmRzLnJpZ2h0KSB7XG4gICAgbWVhc3VyZW1lbnRzLnB1c2goe1xuICAgICAgeDogdGFyZ2V0Qm91bmRzLnJpZ2h0LFxuICAgICAgeTogYW5jaG9yQm91bmRzLnRvcCArIChhbmNob3JCb3VuZHMuaGVpZ2h0IC8gMiksXG4gICAgICBkOiBhbmNob3JCb3VuZHMubGVmdCAtIHRhcmdldEJvdW5kcy5yaWdodCxcbiAgICAgIHE6ICdsZWZ0JyxcbiAgICB9KVxuICB9XG4gIGlmIChhbmNob3JCb3VuZHMubGVmdCA+IHRhcmdldEJvdW5kcy5sZWZ0ICYmIGFuY2hvckJvdW5kcy5sZWZ0IDwgdGFyZ2V0Qm91bmRzLnJpZ2h0KSB7XG4gICAgbWVhc3VyZW1lbnRzLnB1c2goe1xuICAgICAgeDogdGFyZ2V0Qm91bmRzLmxlZnQsXG4gICAgICB5OiBhbmNob3JCb3VuZHMudG9wICsgKGFuY2hvckJvdW5kcy5oZWlnaHQgLyAyKSxcbiAgICAgIGQ6IGFuY2hvckJvdW5kcy5sZWZ0IC0gdGFyZ2V0Qm91bmRzLmxlZnQsXG4gICAgICBxOiAnbGVmdCcsXG4gICAgfSlcbiAgfVxuXG4gIC8vIHRvcFxuICBpZiAoYW5jaG9yQm91bmRzLnRvcCA+IHRhcmdldEJvdW5kcy5ib3R0b20pIHtcbiAgICBtZWFzdXJlbWVudHMucHVzaCh7XG4gICAgICB4OiBhbmNob3JCb3VuZHMubGVmdCArIChhbmNob3JCb3VuZHMud2lkdGggLyAyKSxcbiAgICAgIHk6IHRhcmdldEJvdW5kcy5ib3R0b20sXG4gICAgICBkOiBhbmNob3JCb3VuZHMudG9wIC0gdGFyZ2V0Qm91bmRzLmJvdHRvbSxcbiAgICAgIHE6ICd0b3AnLFxuICAgICAgdjogdHJ1ZSxcbiAgICB9KVxuICB9XG4gIGlmIChhbmNob3JCb3VuZHMudG9wID4gdGFyZ2V0Qm91bmRzLnRvcCAmJiBhbmNob3JCb3VuZHMudG9wIDwgdGFyZ2V0Qm91bmRzLmJvdHRvbSkge1xuICAgIG1lYXN1cmVtZW50cy5wdXNoKHtcbiAgICAgIHg6IGFuY2hvckJvdW5kcy5sZWZ0ICsgKGFuY2hvckJvdW5kcy53aWR0aCAvIDIpLFxuICAgICAgeTogdGFyZ2V0Qm91bmRzLnRvcCxcbiAgICAgIGQ6IGFuY2hvckJvdW5kcy50b3AgLSB0YXJnZXRCb3VuZHMudG9wLFxuICAgICAgcTogJ3RvcCcsXG4gICAgICB2OiB0cnVlLFxuICAgIH0pXG4gIH1cblxuICAvLyBib3R0b21cbiAgaWYgKGFuY2hvckJvdW5kcy5ib3R0b20gPCB0YXJnZXRCb3VuZHMudG9wKSB7XG4gICAgbWVhc3VyZW1lbnRzLnB1c2goe1xuICAgICAgeDogYW5jaG9yQm91bmRzLmxlZnQgKyAoYW5jaG9yQm91bmRzLndpZHRoIC8gMiksXG4gICAgICB5OiBhbmNob3JCb3VuZHMuYm90dG9tLFxuICAgICAgZDogdGFyZ2V0Qm91bmRzLnRvcCAtIGFuY2hvckJvdW5kcy5ib3R0b20sXG4gICAgICBxOiAnYm90dG9tJyxcbiAgICAgIHY6IHRydWUsXG4gICAgfSlcbiAgfVxuICBpZiAoYW5jaG9yQm91bmRzLmJvdHRvbSA8IHRhcmdldEJvdW5kcy5ib3R0b20gJiYgYW5jaG9yQm91bmRzLmJvdHRvbSA+IHRhcmdldEJvdW5kcy50b3ApIHtcbiAgICBtZWFzdXJlbWVudHMucHVzaCh7XG4gICAgICB4OiBhbmNob3JCb3VuZHMubGVmdCArIChhbmNob3JCb3VuZHMud2lkdGggLyAyKSxcbiAgICAgIHk6IGFuY2hvckJvdW5kcy5ib3R0b20sXG4gICAgICBkOiB0YXJnZXRCb3VuZHMuYm90dG9tIC0gYW5jaG9yQm91bmRzLmJvdHRvbSxcbiAgICAgIHE6ICdib3R0b20nLFxuICAgICAgdjogdHJ1ZSxcbiAgICB9KVxuICB9XG5cbiAgLy8gaW5zaWRlIGxlZnQvcmlnaHRcbiAgaWYgKGFuY2hvckJvdW5kcy5yaWdodCA+IHRhcmdldEJvdW5kcy5yaWdodCAmJiBhbmNob3JCb3VuZHMubGVmdCA8IHRhcmdldEJvdW5kcy5sZWZ0KSB7XG4gICAgbWVhc3VyZW1lbnRzLnB1c2goe1xuICAgICAgeDogdGFyZ2V0Qm91bmRzLnJpZ2h0LFxuICAgICAgeTogYW5jaG9yQm91bmRzLnRvcCArIChhbmNob3JCb3VuZHMuaGVpZ2h0IC8gMiksXG4gICAgICBkOiBhbmNob3JCb3VuZHMucmlnaHQgLSB0YXJnZXRCb3VuZHMucmlnaHQsXG4gICAgICBxOiAnbGVmdCcsXG4gICAgfSlcbiAgICBtZWFzdXJlbWVudHMucHVzaCh7XG4gICAgICB4OiBhbmNob3JCb3VuZHMubGVmdCxcbiAgICAgIHk6IGFuY2hvckJvdW5kcy50b3AgKyAoYW5jaG9yQm91bmRzLmhlaWdodCAvIDIpLFxuICAgICAgZDogdGFyZ2V0Qm91bmRzLmxlZnQgLSBhbmNob3JCb3VuZHMubGVmdCxcbiAgICAgIHE6ICdyaWdodCcsXG4gICAgfSlcbiAgfVxuXG4gIC8vIGluc2lkZSB0b3AvcmlnaHRcbiAgaWYgKGFuY2hvckJvdW5kcy50b3AgPCB0YXJnZXRCb3VuZHMudG9wICYmIGFuY2hvckJvdW5kcy5ib3R0b20gPiB0YXJnZXRCb3VuZHMuYm90dG9tKSB7XG4gICAgbWVhc3VyZW1lbnRzLnB1c2goe1xuICAgICAgeDogYW5jaG9yQm91bmRzLmxlZnQgKyAoYW5jaG9yQm91bmRzLndpZHRoIC8gMiksXG4gICAgICB5OiBhbmNob3JCb3VuZHMudG9wLFxuICAgICAgZDogdGFyZ2V0Qm91bmRzLnRvcCAtIGFuY2hvckJvdW5kcy50b3AsXG4gICAgICBxOiAnYm90dG9tJyxcbiAgICAgIHY6IHRydWUsXG4gICAgfSlcbiAgICBtZWFzdXJlbWVudHMucHVzaCh7XG4gICAgICB4OiBhbmNob3JCb3VuZHMubGVmdCArIChhbmNob3JCb3VuZHMud2lkdGggLyAyKSxcbiAgICAgIHk6IHRhcmdldEJvdW5kcy5ib3R0b20sXG4gICAgICBkOiBhbmNob3JCb3VuZHMuYm90dG9tIC0gdGFyZ2V0Qm91bmRzLmJvdHRvbSxcbiAgICAgIHE6ICd0b3AnLFxuICAgICAgdjogdHJ1ZSxcbiAgICB9KVxuICB9XG5cbiAgLy8gY3JlYXRlIGN1c3RvbSBlbGVtZW50cyBmb3IgYWxsIGNyZWF0ZWQgbWVhc3VyZW1lbnRzXG4gIG1lYXN1cmVtZW50c1xuICAgIC5tYXAobWVhc3VyZW1lbnQgPT4gT2JqZWN0LmFzc2lnbihtZWFzdXJlbWVudCwge1xuICAgICAgZDogTWF0aC5yb3VuZChtZWFzdXJlbWVudC5kLnRvRml4ZWQoMSkgKiAxMDApIC8gMTAwXG4gICAgfSkpXG4gICAgLmZvckVhY2gobWVhc3VyZW1lbnQgPT4ge1xuICAgICAgY29uc3QgJG1lYXN1cmVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndmlzYnVnLWRpc3RhbmNlJylcblxuICAgICAgJG1lYXN1cmVtZW50LnBvc2l0aW9uID0ge1xuICAgICAgICBsaW5lX21vZGVsOiAgICAgbWVhc3VyZW1lbnQsXG4gICAgICAgIG5vZGVfbGFiZWxfaWQ6ICBzdGF0ZS5kaXN0YW5jZXMubGVuZ3RoLFxuICAgICAgfVxuXG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKCRtZWFzdXJlbWVudClcbiAgICAgIHN0YXRlLmRpc3RhbmNlc1tzdGF0ZS5kaXN0YW5jZXMubGVuZ3RoXSA9ICRtZWFzdXJlbWVudFxuICAgIH0pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjbGVhck1lYXN1cmVtZW50cygpIHtcbiAgc3RhdGUuZGlzdGFuY2VzLmZvckVhY2gobm9kZSA9PiBub2RlLnJlbW92ZSgpKVxuICBzdGF0ZS5kaXN0YW5jZXMgPSBbXVxufVxuIiwiLyoqXG4gKiBUYWtlIGlucHV0IGZyb20gWzAsIG5dIGFuZCByZXR1cm4gaXQgYXMgWzAsIDFdXG4gKiBAaGlkZGVuXG4gKi9cbmZ1bmN0aW9uIGJvdW5kMDEobiwgbWF4KSB7XG4gICAgaWYgKGlzT25lUG9pbnRaZXJvKG4pKSB7XG4gICAgICAgIG4gPSAnMTAwJSc7XG4gICAgfVxuICAgIGNvbnN0IHByb2Nlc3NQZXJjZW50ID0gaXNQZXJjZW50YWdlKG4pO1xuICAgIG4gPSBtYXggPT09IDM2MCA/IG4gOiBNYXRoLm1pbihtYXgsIE1hdGgubWF4KDAsIHBhcnNlRmxvYXQobikpKTtcbiAgICAvLyBBdXRvbWF0aWNhbGx5IGNvbnZlcnQgcGVyY2VudGFnZSBpbnRvIG51bWJlclxuICAgIGlmIChwcm9jZXNzUGVyY2VudCkge1xuICAgICAgICBuID0gcGFyc2VJbnQoU3RyaW5nKG4gKiBtYXgpLCAxMCkgLyAxMDA7XG4gICAgfVxuICAgIC8vIEhhbmRsZSBmbG9hdGluZyBwb2ludCByb3VuZGluZyBlcnJvcnNcbiAgICBpZiAoTWF0aC5hYnMobiAtIG1heCkgPCAwLjAwMDAwMSkge1xuICAgICAgICByZXR1cm4gMTtcbiAgICB9XG4gICAgLy8gQ29udmVydCBpbnRvIFswLCAxXSByYW5nZSBpZiBpdCBpc24ndCBhbHJlYWR5XG4gICAgaWYgKG1heCA9PT0gMzYwKSB7XG4gICAgICAgIC8vIElmIG4gaXMgYSBodWUgZ2l2ZW4gaW4gZGVncmVlcyxcbiAgICAgICAgLy8gd3JhcCBhcm91bmQgb3V0LW9mLXJhbmdlIHZhbHVlcyBpbnRvIFswLCAzNjBdIHJhbmdlXG4gICAgICAgIC8vIHRoZW4gY29udmVydCBpbnRvIFswLCAxXS5cbiAgICAgICAgbiA9IChuIDwgMCA/IG4gJSBtYXggKyBtYXggOiBuICUgbWF4KSAvIHBhcnNlRmxvYXQoU3RyaW5nKG1heCkpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgLy8gSWYgbiBub3QgYSBodWUgZ2l2ZW4gaW4gZGVncmVlc1xuICAgICAgICAvLyBDb252ZXJ0IGludG8gWzAsIDFdIHJhbmdlIGlmIGl0IGlzbid0IGFscmVhZHkuXG4gICAgICAgIG4gPSAobiAlIG1heCkgLyBwYXJzZUZsb2F0KFN0cmluZyhtYXgpKTtcbiAgICB9XG4gICAgcmV0dXJuIG47XG59XG4vKipcbiAqIEZvcmNlIGEgbnVtYmVyIGJldHdlZW4gMCBhbmQgMVxuICogQGhpZGRlblxuICovXG5mdW5jdGlvbiBjbGFtcDAxKHZhbCkge1xuICAgIHJldHVybiBNYXRoLm1pbigxLCBNYXRoLm1heCgwLCB2YWwpKTtcbn1cbi8qKlxuICogTmVlZCB0byBoYW5kbGUgMS4wIGFzIDEwMCUsIHNpbmNlIG9uY2UgaXQgaXMgYSBudW1iZXIsIHRoZXJlIGlzIG5vIGRpZmZlcmVuY2UgYmV0d2VlbiBpdCBhbmQgMVxuICogPGh0dHA6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvNzQyMjA3Mi9qYXZhc2NyaXB0LWhvdy10by1kZXRlY3QtbnVtYmVyLWFzLWEtZGVjaW1hbC1pbmNsdWRpbmctMS0wPlxuICogQGhpZGRlblxuICovXG5mdW5jdGlvbiBpc09uZVBvaW50WmVybyhuKSB7XG4gICAgcmV0dXJuIHR5cGVvZiBuID09PSAnc3RyaW5nJyAmJiBuLmluZGV4T2YoJy4nKSAhPT0gLTEgJiYgcGFyc2VGbG9hdChuKSA9PT0gMTtcbn1cbi8qKlxuICogQ2hlY2sgdG8gc2VlIGlmIHN0cmluZyBwYXNzZWQgaW4gaXMgYSBwZXJjZW50YWdlXG4gKiBAaGlkZGVuXG4gKi9cbmZ1bmN0aW9uIGlzUGVyY2VudGFnZShuKSB7XG4gICAgcmV0dXJuIHR5cGVvZiBuID09PSAnc3RyaW5nJyAmJiBuLmluZGV4T2YoJyUnKSAhPT0gLTE7XG59XG4vKipcbiAqIFJldHVybiBhIHZhbGlkIGFscGhhIHZhbHVlIFswLDFdIHdpdGggYWxsIGludmFsaWQgdmFsdWVzIGJlaW5nIHNldCB0byAxXG4gKiBAaGlkZGVuXG4gKi9cbmZ1bmN0aW9uIGJvdW5kQWxwaGEoYSkge1xuICAgIGEgPSBwYXJzZUZsb2F0KGEpO1xuICAgIGlmIChpc05hTihhKSB8fCBhIDwgMCB8fCBhID4gMSkge1xuICAgICAgICBhID0gMTtcbiAgICB9XG4gICAgcmV0dXJuIGE7XG59XG4vKipcbiAqIFJlcGxhY2UgYSBkZWNpbWFsIHdpdGggaXQncyBwZXJjZW50YWdlIHZhbHVlXG4gKiBAaGlkZGVuXG4gKi9cbmZ1bmN0aW9uIGNvbnZlcnRUb1BlcmNlbnRhZ2Uobikge1xuICAgIGlmIChuIDw9IDEpIHtcbiAgICAgICAgcmV0dXJuICtuICogMTAwICsgJyUnO1xuICAgIH1cbiAgICByZXR1cm4gbjtcbn1cbi8qKlxuICogRm9yY2UgYSBoZXggdmFsdWUgdG8gaGF2ZSAyIGNoYXJhY3RlcnNcbiAqIEBoaWRkZW5cbiAqL1xuZnVuY3Rpb24gcGFkMihjKSB7XG4gICAgcmV0dXJuIGMubGVuZ3RoID09PSAxID8gJzAnICsgYyA6ICcnICsgYztcbn1cblxuLy8gYHJnYlRvSHNsYCwgYHJnYlRvSHN2YCwgYGhzbFRvUmdiYCwgYGhzdlRvUmdiYCBtb2RpZmllZCBmcm9tOlxuLy8gPGh0dHA6Ly9tamlqYWNrc29uLmNvbS8yMDA4LzAyL3JnYi10by1oc2wtYW5kLXJnYi10by1oc3YtY29sb3ItbW9kZWwtY29udmVyc2lvbi1hbGdvcml0aG1zLWluLWphdmFzY3JpcHQ+XG4vKipcbiAqIEhhbmRsZSBib3VuZHMgLyBwZXJjZW50YWdlIGNoZWNraW5nIHRvIGNvbmZvcm0gdG8gQ1NTIGNvbG9yIHNwZWNcbiAqIDxodHRwOi8vd3d3LnczLm9yZy9UUi9jc3MzLWNvbG9yLz5cbiAqICpBc3N1bWVzOiogciwgZywgYiBpbiBbMCwgMjU1XSBvciBbMCwgMV1cbiAqICpSZXR1cm5zOiogeyByLCBnLCBiIH0gaW4gWzAsIDI1NV1cbiAqL1xuZnVuY3Rpb24gcmdiVG9SZ2IociwgZywgYikge1xuICAgIHJldHVybiB7XG4gICAgICAgIHI6IGJvdW5kMDEociwgMjU1KSAqIDI1NSxcbiAgICAgICAgZzogYm91bmQwMShnLCAyNTUpICogMjU1LFxuICAgICAgICBiOiBib3VuZDAxKGIsIDI1NSkgKiAyNTUsXG4gICAgfTtcbn1cbi8qKlxuICogQ29udmVydHMgYW4gUkdCIGNvbG9yIHZhbHVlIHRvIEhTTC5cbiAqICpBc3N1bWVzOiogciwgZywgYW5kIGIgYXJlIGNvbnRhaW5lZCBpbiBbMCwgMjU1XSBvciBbMCwgMV1cbiAqICpSZXR1cm5zOiogeyBoLCBzLCBsIH0gaW4gWzAsMV1cbiAqL1xuZnVuY3Rpb24gcmdiVG9Ic2wociwgZywgYikge1xuICAgIHIgPSBib3VuZDAxKHIsIDI1NSk7XG4gICAgZyA9IGJvdW5kMDEoZywgMjU1KTtcbiAgICBiID0gYm91bmQwMShiLCAyNTUpO1xuICAgIGNvbnN0IG1heCA9IE1hdGgubWF4KHIsIGcsIGIpO1xuICAgIGNvbnN0IG1pbiA9IE1hdGgubWluKHIsIGcsIGIpO1xuICAgIGxldCBoID0gMDtcbiAgICBsZXQgcyA9IDA7XG4gICAgY29uc3QgbCA9IChtYXggKyBtaW4pIC8gMjtcbiAgICBpZiAobWF4ID09PSBtaW4pIHtcbiAgICAgICAgaCA9IHMgPSAwOyAvLyBhY2hyb21hdGljXG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjb25zdCBkID0gbWF4IC0gbWluO1xuICAgICAgICBzID0gbCA+IDAuNSA/IGQgLyAoMiAtIG1heCAtIG1pbikgOiBkIC8gKG1heCArIG1pbik7XG4gICAgICAgIHN3aXRjaCAobWF4KSB7XG4gICAgICAgICAgICBjYXNlIHI6XG4gICAgICAgICAgICAgICAgaCA9IChnIC0gYikgLyBkICsgKGcgPCBiID8gNiA6IDApO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBnOlxuICAgICAgICAgICAgICAgIGggPSAoYiAtIHIpIC8gZCArIDI7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGI6XG4gICAgICAgICAgICAgICAgaCA9IChyIC0gZykgLyBkICsgNDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBoIC89IDY7XG4gICAgfVxuICAgIHJldHVybiB7IGgsIHMsIGwgfTtcbn1cbi8qKlxuICogQ29udmVydHMgYW4gSFNMIGNvbG9yIHZhbHVlIHRvIFJHQi5cbiAqXG4gKiAqQXNzdW1lczoqIGggaXMgY29udGFpbmVkIGluIFswLCAxXSBvciBbMCwgMzYwXSBhbmQgcyBhbmQgbCBhcmUgY29udGFpbmVkIFswLCAxXSBvciBbMCwgMTAwXVxuICogKlJldHVybnM6KiB7IHIsIGcsIGIgfSBpbiB0aGUgc2V0IFswLCAyNTVdXG4gKi9cbmZ1bmN0aW9uIGhzbFRvUmdiKGgsIHMsIGwpIHtcbiAgICBsZXQgcjtcbiAgICBsZXQgZztcbiAgICBsZXQgYjtcbiAgICBoID0gYm91bmQwMShoLCAzNjApO1xuICAgIHMgPSBib3VuZDAxKHMsIDEwMCk7XG4gICAgbCA9IGJvdW5kMDEobCwgMTAwKTtcbiAgICBmdW5jdGlvbiBodWUycmdiKHAsIHEsIHQpIHtcbiAgICAgICAgaWYgKHQgPCAwKVxuICAgICAgICAgICAgdCArPSAxO1xuICAgICAgICBpZiAodCA+IDEpXG4gICAgICAgICAgICB0IC09IDE7XG4gICAgICAgIGlmICh0IDwgMSAvIDYpIHtcbiAgICAgICAgICAgIHJldHVybiBwICsgKHEgLSBwKSAqIDYgKiB0O1xuICAgICAgICB9XG4gICAgICAgIGlmICh0IDwgMSAvIDIpIHtcbiAgICAgICAgICAgIHJldHVybiBxO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0IDwgMiAvIDMpIHtcbiAgICAgICAgICAgIHJldHVybiBwICsgKHEgLSBwKSAqICgyIC8gMyAtIHQpICogNjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcDtcbiAgICB9XG4gICAgaWYgKHMgPT09IDApIHtcbiAgICAgICAgciA9IGcgPSBiID0gbDsgLy8gYWNocm9tYXRpY1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc3QgcSA9IGwgPCAwLjUgPyBsICogKDEgKyBzKSA6IGwgKyBzIC0gbCAqIHM7XG4gICAgICAgIGNvbnN0IHAgPSAyICogbCAtIHE7XG4gICAgICAgIHIgPSBodWUycmdiKHAsIHEsIGggKyAxIC8gMyk7XG4gICAgICAgIGcgPSBodWUycmdiKHAsIHEsIGgpO1xuICAgICAgICBiID0gaHVlMnJnYihwLCBxLCBoIC0gMSAvIDMpO1xuICAgIH1cbiAgICByZXR1cm4geyByOiByICogMjU1LCBnOiBnICogMjU1LCBiOiBiICogMjU1IH07XG59XG4vKipcbiAqIENvbnZlcnRzIGFuIFJHQiBjb2xvciB2YWx1ZSB0byBIU1ZcbiAqXG4gKiAqQXNzdW1lczoqIHIsIGcsIGFuZCBiIGFyZSBjb250YWluZWQgaW4gdGhlIHNldCBbMCwgMjU1XSBvciBbMCwgMV1cbiAqICpSZXR1cm5zOiogeyBoLCBzLCB2IH0gaW4gWzAsMV1cbiAqL1xuZnVuY3Rpb24gcmdiVG9Ic3YociwgZywgYikge1xuICAgIHIgPSBib3VuZDAxKHIsIDI1NSk7XG4gICAgZyA9IGJvdW5kMDEoZywgMjU1KTtcbiAgICBiID0gYm91bmQwMShiLCAyNTUpO1xuICAgIGNvbnN0IG1heCA9IE1hdGgubWF4KHIsIGcsIGIpO1xuICAgIGNvbnN0IG1pbiA9IE1hdGgubWluKHIsIGcsIGIpO1xuICAgIGxldCBoID0gMDtcbiAgICBjb25zdCB2ID0gbWF4O1xuICAgIGNvbnN0IGQgPSBtYXggLSBtaW47XG4gICAgY29uc3QgcyA9IG1heCA9PT0gMCA/IDAgOiBkIC8gbWF4O1xuICAgIGlmIChtYXggPT09IG1pbikge1xuICAgICAgICBoID0gMDsgLy8gYWNocm9tYXRpY1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgc3dpdGNoIChtYXgpIHtcbiAgICAgICAgICAgIGNhc2UgcjpcbiAgICAgICAgICAgICAgICBoID0gKGcgLSBiKSAvIGQgKyAoZyA8IGIgPyA2IDogMCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGc6XG4gICAgICAgICAgICAgICAgaCA9IChiIC0gcikgLyBkICsgMjtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgYjpcbiAgICAgICAgICAgICAgICBoID0gKHIgLSBnKSAvIGQgKyA0O1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGggLz0gNjtcbiAgICB9XG4gICAgcmV0dXJuIHsgaDogaCwgczogcywgdjogdiB9O1xufVxuLyoqXG4gKiBDb252ZXJ0cyBhbiBIU1YgY29sb3IgdmFsdWUgdG8gUkdCLlxuICpcbiAqICpBc3N1bWVzOiogaCBpcyBjb250YWluZWQgaW4gWzAsIDFdIG9yIFswLCAzNjBdIGFuZCBzIGFuZCB2IGFyZSBjb250YWluZWQgaW4gWzAsIDFdIG9yIFswLCAxMDBdXG4gKiAqUmV0dXJuczoqIHsgciwgZywgYiB9IGluIHRoZSBzZXQgWzAsIDI1NV1cbiAqL1xuZnVuY3Rpb24gaHN2VG9SZ2IoaCwgcywgdikge1xuICAgIGggPSBib3VuZDAxKGgsIDM2MCkgKiA2O1xuICAgIHMgPSBib3VuZDAxKHMsIDEwMCk7XG4gICAgdiA9IGJvdW5kMDEodiwgMTAwKTtcbiAgICBjb25zdCBpID0gTWF0aC5mbG9vcihoKTtcbiAgICBjb25zdCBmID0gaCAtIGk7XG4gICAgY29uc3QgcCA9IHYgKiAoMSAtIHMpO1xuICAgIGNvbnN0IHEgPSB2ICogKDEgLSBmICogcyk7XG4gICAgY29uc3QgdCA9IHYgKiAoMSAtICgxIC0gZikgKiBzKTtcbiAgICBjb25zdCBtb2QgPSBpICUgNjtcbiAgICBjb25zdCByID0gW3YsIHEsIHAsIHAsIHQsIHZdW21vZF07XG4gICAgY29uc3QgZyA9IFt0LCB2LCB2LCBxLCBwLCBwXVttb2RdO1xuICAgIGNvbnN0IGIgPSBbcCwgcCwgdCwgdiwgdiwgcV1bbW9kXTtcbiAgICByZXR1cm4geyByOiByICogMjU1LCBnOiBnICogMjU1LCBiOiBiICogMjU1IH07XG59XG4vKipcbiAqIENvbnZlcnRzIGFuIFJHQiBjb2xvciB0byBoZXhcbiAqXG4gKiBBc3N1bWVzIHIsIGcsIGFuZCBiIGFyZSBjb250YWluZWQgaW4gdGhlIHNldCBbMCwgMjU1XVxuICogUmV0dXJucyBhIDMgb3IgNiBjaGFyYWN0ZXIgaGV4XG4gKi9cbmZ1bmN0aW9uIHJnYlRvSGV4KHIsIGcsIGIsIGFsbG93M0NoYXIpIHtcbiAgICBjb25zdCBoZXggPSBbXG4gICAgICAgIHBhZDIoTWF0aC5yb3VuZChyKS50b1N0cmluZygxNikpLFxuICAgICAgICBwYWQyKE1hdGgucm91bmQoZykudG9TdHJpbmcoMTYpKSxcbiAgICAgICAgcGFkMihNYXRoLnJvdW5kKGIpLnRvU3RyaW5nKDE2KSksXG4gICAgXTtcbiAgICAvLyBSZXR1cm4gYSAzIGNoYXJhY3RlciBoZXggaWYgcG9zc2libGVcbiAgICBpZiAoYWxsb3czQ2hhciAmJlxuICAgICAgICBoZXhbMF0uY2hhckF0KDApID09PSBoZXhbMF0uY2hhckF0KDEpICYmXG4gICAgICAgIGhleFsxXS5jaGFyQXQoMCkgPT09IGhleFsxXS5jaGFyQXQoMSkgJiZcbiAgICAgICAgaGV4WzJdLmNoYXJBdCgwKSA9PT0gaGV4WzJdLmNoYXJBdCgxKSkge1xuICAgICAgICByZXR1cm4gaGV4WzBdLmNoYXJBdCgwKSArIGhleFsxXS5jaGFyQXQoMCkgKyBoZXhbMl0uY2hhckF0KDApO1xuICAgIH1cbiAgICByZXR1cm4gaGV4LmpvaW4oJycpO1xufVxuLyoqXG4gKiBDb252ZXJ0cyBhbiBSR0JBIGNvbG9yIHBsdXMgYWxwaGEgdHJhbnNwYXJlbmN5IHRvIGhleFxuICpcbiAqIEFzc3VtZXMgciwgZywgYiBhcmUgY29udGFpbmVkIGluIHRoZSBzZXQgWzAsIDI1NV0gYW5kXG4gKiBhIGluIFswLCAxXS4gUmV0dXJucyBhIDQgb3IgOCBjaGFyYWN0ZXIgcmdiYSBoZXhcbiAqL1xuZnVuY3Rpb24gcmdiYVRvSGV4KHIsIGcsIGIsIGEsIGFsbG93NENoYXIpIHtcbiAgICBjb25zdCBoZXggPSBbXG4gICAgICAgIHBhZDIoTWF0aC5yb3VuZChyKS50b1N0cmluZygxNikpLFxuICAgICAgICBwYWQyKE1hdGgucm91bmQoZykudG9TdHJpbmcoMTYpKSxcbiAgICAgICAgcGFkMihNYXRoLnJvdW5kKGIpLnRvU3RyaW5nKDE2KSksXG4gICAgICAgIHBhZDIoY29udmVydERlY2ltYWxUb0hleChhKSksXG4gICAgXTtcbiAgICAvLyBSZXR1cm4gYSA0IGNoYXJhY3RlciBoZXggaWYgcG9zc2libGVcbiAgICBpZiAoYWxsb3c0Q2hhciAmJlxuICAgICAgICBoZXhbMF0uY2hhckF0KDApID09PSBoZXhbMF0uY2hhckF0KDEpICYmXG4gICAgICAgIGhleFsxXS5jaGFyQXQoMCkgPT09IGhleFsxXS5jaGFyQXQoMSkgJiZcbiAgICAgICAgaGV4WzJdLmNoYXJBdCgwKSA9PT0gaGV4WzJdLmNoYXJBdCgxKSAmJlxuICAgICAgICBoZXhbM10uY2hhckF0KDApID09PSBoZXhbM10uY2hhckF0KDEpKSB7XG4gICAgICAgIHJldHVybiBoZXhbMF0uY2hhckF0KDApICsgaGV4WzFdLmNoYXJBdCgwKSArIGhleFsyXS5jaGFyQXQoMCkgKyBoZXhbM10uY2hhckF0KDApO1xuICAgIH1cbiAgICByZXR1cm4gaGV4LmpvaW4oJycpO1xufVxuLyoqXG4gKiBDb252ZXJ0cyBhbiBSR0JBIGNvbG9yIHRvIGFuIEFSR0IgSGV4OCBzdHJpbmdcbiAqIFJhcmVseSB1c2VkLCBidXQgcmVxdWlyZWQgZm9yIFwidG9GaWx0ZXIoKVwiXG4gKi9cbmZ1bmN0aW9uIHJnYmFUb0FyZ2JIZXgociwgZywgYiwgYSkge1xuICAgIGNvbnN0IGhleCA9IFtcbiAgICAgICAgcGFkMihjb252ZXJ0RGVjaW1hbFRvSGV4KGEpKSxcbiAgICAgICAgcGFkMihNYXRoLnJvdW5kKHIpLnRvU3RyaW5nKDE2KSksXG4gICAgICAgIHBhZDIoTWF0aC5yb3VuZChnKS50b1N0cmluZygxNikpLFxuICAgICAgICBwYWQyKE1hdGgucm91bmQoYikudG9TdHJpbmcoMTYpKSxcbiAgICBdO1xuICAgIHJldHVybiBoZXguam9pbignJyk7XG59XG4vKiogQ29udmVydHMgYSBkZWNpbWFsIHRvIGEgaGV4IHZhbHVlICovXG5mdW5jdGlvbiBjb252ZXJ0RGVjaW1hbFRvSGV4KGQpIHtcbiAgICByZXR1cm4gTWF0aC5yb3VuZChwYXJzZUZsb2F0KGQpICogMjU1KS50b1N0cmluZygxNik7XG59XG4vKiogQ29udmVydHMgYSBoZXggdmFsdWUgdG8gYSBkZWNpbWFsICovXG5mdW5jdGlvbiBjb252ZXJ0SGV4VG9EZWNpbWFsKGgpIHtcbiAgICByZXR1cm4gcGFyc2VJbnRGcm9tSGV4KGgpIC8gMjU1O1xufVxuLyoqIFBhcnNlIGEgYmFzZS0xNiBoZXggdmFsdWUgaW50byBhIGJhc2UtMTAgaW50ZWdlciAqL1xuZnVuY3Rpb24gcGFyc2VJbnRGcm9tSGV4KHZhbCkge1xuICAgIHJldHVybiBwYXJzZUludCh2YWwsIDE2KTtcbn1cblxuLy8gaHR0cHM6Ly9naXRodWIuY29tL2JhaGFtYXMxMC9jc3MtY29sb3ItbmFtZXMvYmxvYi9tYXN0ZXIvY3NzLWNvbG9yLW5hbWVzLmpzb25cbi8qKlxuICogQGhpZGRlblxuICovXG5jb25zdCBuYW1lcyA9IHtcbiAgICBhbGljZWJsdWU6ICcjZjBmOGZmJyxcbiAgICBhbnRpcXVld2hpdGU6ICcjZmFlYmQ3JyxcbiAgICBhcXVhOiAnIzAwZmZmZicsXG4gICAgYXF1YW1hcmluZTogJyM3ZmZmZDQnLFxuICAgIGF6dXJlOiAnI2YwZmZmZicsXG4gICAgYmVpZ2U6ICcjZjVmNWRjJyxcbiAgICBiaXNxdWU6ICcjZmZlNGM0JyxcbiAgICBibGFjazogJyMwMDAwMDAnLFxuICAgIGJsYW5jaGVkYWxtb25kOiAnI2ZmZWJjZCcsXG4gICAgYmx1ZTogJyMwMDAwZmYnLFxuICAgIGJsdWV2aW9sZXQ6ICcjOGEyYmUyJyxcbiAgICBicm93bjogJyNhNTJhMmEnLFxuICAgIGJ1cmx5d29vZDogJyNkZWI4ODcnLFxuICAgIGNhZGV0Ymx1ZTogJyM1ZjllYTAnLFxuICAgIGNoYXJ0cmV1c2U6ICcjN2ZmZjAwJyxcbiAgICBjaG9jb2xhdGU6ICcjZDI2OTFlJyxcbiAgICBjb3JhbDogJyNmZjdmNTAnLFxuICAgIGNvcm5mbG93ZXJibHVlOiAnIzY0OTVlZCcsXG4gICAgY29ybnNpbGs6ICcjZmZmOGRjJyxcbiAgICBjcmltc29uOiAnI2RjMTQzYycsXG4gICAgY3lhbjogJyMwMGZmZmYnLFxuICAgIGRhcmtibHVlOiAnIzAwMDA4YicsXG4gICAgZGFya2N5YW46ICcjMDA4YjhiJyxcbiAgICBkYXJrZ29sZGVucm9kOiAnI2I4ODYwYicsXG4gICAgZGFya2dyYXk6ICcjYTlhOWE5JyxcbiAgICBkYXJrZ3JlZW46ICcjMDA2NDAwJyxcbiAgICBkYXJrZ3JleTogJyNhOWE5YTknLFxuICAgIGRhcmtraGFraTogJyNiZGI3NmInLFxuICAgIGRhcmttYWdlbnRhOiAnIzhiMDA4YicsXG4gICAgZGFya29saXZlZ3JlZW46ICcjNTU2YjJmJyxcbiAgICBkYXJrb3JhbmdlOiAnI2ZmOGMwMCcsXG4gICAgZGFya29yY2hpZDogJyM5OTMyY2MnLFxuICAgIGRhcmtyZWQ6ICcjOGIwMDAwJyxcbiAgICBkYXJrc2FsbW9uOiAnI2U5OTY3YScsXG4gICAgZGFya3NlYWdyZWVuOiAnIzhmYmM4ZicsXG4gICAgZGFya3NsYXRlYmx1ZTogJyM0ODNkOGInLFxuICAgIGRhcmtzbGF0ZWdyYXk6ICcjMmY0ZjRmJyxcbiAgICBkYXJrc2xhdGVncmV5OiAnIzJmNGY0ZicsXG4gICAgZGFya3R1cnF1b2lzZTogJyMwMGNlZDEnLFxuICAgIGRhcmt2aW9sZXQ6ICcjOTQwMGQzJyxcbiAgICBkZWVwcGluazogJyNmZjE0OTMnLFxuICAgIGRlZXBza3libHVlOiAnIzAwYmZmZicsXG4gICAgZGltZ3JheTogJyM2OTY5NjknLFxuICAgIGRpbWdyZXk6ICcjNjk2OTY5JyxcbiAgICBkb2RnZXJibHVlOiAnIzFlOTBmZicsXG4gICAgZmlyZWJyaWNrOiAnI2IyMjIyMicsXG4gICAgZmxvcmFsd2hpdGU6ICcjZmZmYWYwJyxcbiAgICBmb3Jlc3RncmVlbjogJyMyMjhiMjInLFxuICAgIGZ1Y2hzaWE6ICcjZmYwMGZmJyxcbiAgICBnYWluc2Jvcm86ICcjZGNkY2RjJyxcbiAgICBnaG9zdHdoaXRlOiAnI2Y4ZjhmZicsXG4gICAgZ29sZDogJyNmZmQ3MDAnLFxuICAgIGdvbGRlbnJvZDogJyNkYWE1MjAnLFxuICAgIGdyYXk6ICcjODA4MDgwJyxcbiAgICBncmVlbjogJyMwMDgwMDAnLFxuICAgIGdyZWVueWVsbG93OiAnI2FkZmYyZicsXG4gICAgZ3JleTogJyM4MDgwODAnLFxuICAgIGhvbmV5ZGV3OiAnI2YwZmZmMCcsXG4gICAgaG90cGluazogJyNmZjY5YjQnLFxuICAgIGluZGlhbnJlZDogJyNjZDVjNWMnLFxuICAgIGluZGlnbzogJyM0YjAwODInLFxuICAgIGl2b3J5OiAnI2ZmZmZmMCcsXG4gICAga2hha2k6ICcjZjBlNjhjJyxcbiAgICBsYXZlbmRlcjogJyNlNmU2ZmEnLFxuICAgIGxhdmVuZGVyYmx1c2g6ICcjZmZmMGY1JyxcbiAgICBsYXduZ3JlZW46ICcjN2NmYzAwJyxcbiAgICBsZW1vbmNoaWZmb246ICcjZmZmYWNkJyxcbiAgICBsaWdodGJsdWU6ICcjYWRkOGU2JyxcbiAgICBsaWdodGNvcmFsOiAnI2YwODA4MCcsXG4gICAgbGlnaHRjeWFuOiAnI2UwZmZmZicsXG4gICAgbGlnaHRnb2xkZW5yb2R5ZWxsb3c6ICcjZmFmYWQyJyxcbiAgICBsaWdodGdyYXk6ICcjZDNkM2QzJyxcbiAgICBsaWdodGdyZWVuOiAnIzkwZWU5MCcsXG4gICAgbGlnaHRncmV5OiAnI2QzZDNkMycsXG4gICAgbGlnaHRwaW5rOiAnI2ZmYjZjMScsXG4gICAgbGlnaHRzYWxtb246ICcjZmZhMDdhJyxcbiAgICBsaWdodHNlYWdyZWVuOiAnIzIwYjJhYScsXG4gICAgbGlnaHRza3libHVlOiAnIzg3Y2VmYScsXG4gICAgbGlnaHRzbGF0ZWdyYXk6ICcjNzc4ODk5JyxcbiAgICBsaWdodHNsYXRlZ3JleTogJyM3Nzg4OTknLFxuICAgIGxpZ2h0c3RlZWxibHVlOiAnI2IwYzRkZScsXG4gICAgbGlnaHR5ZWxsb3c6ICcjZmZmZmUwJyxcbiAgICBsaW1lOiAnIzAwZmYwMCcsXG4gICAgbGltZWdyZWVuOiAnIzMyY2QzMicsXG4gICAgbGluZW46ICcjZmFmMGU2JyxcbiAgICBtYWdlbnRhOiAnI2ZmMDBmZicsXG4gICAgbWFyb29uOiAnIzgwMDAwMCcsXG4gICAgbWVkaXVtYXF1YW1hcmluZTogJyM2NmNkYWEnLFxuICAgIG1lZGl1bWJsdWU6ICcjMDAwMGNkJyxcbiAgICBtZWRpdW1vcmNoaWQ6ICcjYmE1NWQzJyxcbiAgICBtZWRpdW1wdXJwbGU6ICcjOTM3MGRiJyxcbiAgICBtZWRpdW1zZWFncmVlbjogJyMzY2IzNzEnLFxuICAgIG1lZGl1bXNsYXRlYmx1ZTogJyM3YjY4ZWUnLFxuICAgIG1lZGl1bXNwcmluZ2dyZWVuOiAnIzAwZmE5YScsXG4gICAgbWVkaXVtdHVycXVvaXNlOiAnIzQ4ZDFjYycsXG4gICAgbWVkaXVtdmlvbGV0cmVkOiAnI2M3MTU4NScsXG4gICAgbWlkbmlnaHRibHVlOiAnIzE5MTk3MCcsXG4gICAgbWludGNyZWFtOiAnI2Y1ZmZmYScsXG4gICAgbWlzdHlyb3NlOiAnI2ZmZTRlMScsXG4gICAgbW9jY2FzaW46ICcjZmZlNGI1JyxcbiAgICBuYXZham93aGl0ZTogJyNmZmRlYWQnLFxuICAgIG5hdnk6ICcjMDAwMDgwJyxcbiAgICBvbGRsYWNlOiAnI2ZkZjVlNicsXG4gICAgb2xpdmU6ICcjODA4MDAwJyxcbiAgICBvbGl2ZWRyYWI6ICcjNmI4ZTIzJyxcbiAgICBvcmFuZ2U6ICcjZmZhNTAwJyxcbiAgICBvcmFuZ2VyZWQ6ICcjZmY0NTAwJyxcbiAgICBvcmNoaWQ6ICcjZGE3MGQ2JyxcbiAgICBwYWxlZ29sZGVucm9kOiAnI2VlZThhYScsXG4gICAgcGFsZWdyZWVuOiAnIzk4ZmI5OCcsXG4gICAgcGFsZXR1cnF1b2lzZTogJyNhZmVlZWUnLFxuICAgIHBhbGV2aW9sZXRyZWQ6ICcjZGI3MDkzJyxcbiAgICBwYXBheWF3aGlwOiAnI2ZmZWZkNScsXG4gICAgcGVhY2hwdWZmOiAnI2ZmZGFiOScsXG4gICAgcGVydTogJyNjZDg1M2YnLFxuICAgIHBpbms6ICcjZmZjMGNiJyxcbiAgICBwbHVtOiAnI2RkYTBkZCcsXG4gICAgcG93ZGVyYmx1ZTogJyNiMGUwZTYnLFxuICAgIHB1cnBsZTogJyM4MDAwODAnLFxuICAgIHJlYmVjY2FwdXJwbGU6ICcjNjYzMzk5JyxcbiAgICByZWQ6ICcjZmYwMDAwJyxcbiAgICByb3N5YnJvd246ICcjYmM4ZjhmJyxcbiAgICByb3lhbGJsdWU6ICcjNDE2OWUxJyxcbiAgICBzYWRkbGVicm93bjogJyM4YjQ1MTMnLFxuICAgIHNhbG1vbjogJyNmYTgwNzInLFxuICAgIHNhbmR5YnJvd246ICcjZjRhNDYwJyxcbiAgICBzZWFncmVlbjogJyMyZThiNTcnLFxuICAgIHNlYXNoZWxsOiAnI2ZmZjVlZScsXG4gICAgc2llbm5hOiAnI2EwNTIyZCcsXG4gICAgc2lsdmVyOiAnI2MwYzBjMCcsXG4gICAgc2t5Ymx1ZTogJyM4N2NlZWInLFxuICAgIHNsYXRlYmx1ZTogJyM2YTVhY2QnLFxuICAgIHNsYXRlZ3JheTogJyM3MDgwOTAnLFxuICAgIHNsYXRlZ3JleTogJyM3MDgwOTAnLFxuICAgIHNub3c6ICcjZmZmYWZhJyxcbiAgICBzcHJpbmdncmVlbjogJyMwMGZmN2YnLFxuICAgIHN0ZWVsYmx1ZTogJyM0NjgyYjQnLFxuICAgIHRhbjogJyNkMmI0OGMnLFxuICAgIHRlYWw6ICcjMDA4MDgwJyxcbiAgICB0aGlzdGxlOiAnI2Q4YmZkOCcsXG4gICAgdG9tYXRvOiAnI2ZmNjM0NycsXG4gICAgdHVycXVvaXNlOiAnIzQwZTBkMCcsXG4gICAgdmlvbGV0OiAnI2VlODJlZScsXG4gICAgd2hlYXQ6ICcjZjVkZWIzJyxcbiAgICB3aGl0ZTogJyNmZmZmZmYnLFxuICAgIHdoaXRlc21va2U6ICcjZjVmNWY1JyxcbiAgICB5ZWxsb3c6ICcjZmZmZjAwJyxcbiAgICB5ZWxsb3dncmVlbjogJyM5YWNkMzInLFxufTtcblxuLyoqXG4gKiBHaXZlbiBhIHN0cmluZyBvciBvYmplY3QsIGNvbnZlcnQgdGhhdCBpbnB1dCB0byBSR0JcbiAqXG4gKiBQb3NzaWJsZSBzdHJpbmcgaW5wdXRzOlxuICogYGBgXG4gKiBcInJlZFwiXG4gKiBcIiNmMDBcIiBvciBcImYwMFwiXG4gKiBcIiNmZjAwMDBcIiBvciBcImZmMDAwMFwiXG4gKiBcIiNmZjAwMDAwMFwiIG9yIFwiZmYwMDAwMDBcIlxuICogXCJyZ2IgMjU1IDAgMFwiIG9yIFwicmdiICgyNTUsIDAsIDApXCJcbiAqIFwicmdiIDEuMCAwIDBcIiBvciBcInJnYiAoMSwgMCwgMClcIlxuICogXCJyZ2JhICgyNTUsIDAsIDAsIDEpXCIgb3IgXCJyZ2JhIDI1NSwgMCwgMCwgMVwiXG4gKiBcInJnYmEgKDEuMCwgMCwgMCwgMSlcIiBvciBcInJnYmEgMS4wLCAwLCAwLCAxXCJcbiAqIFwiaHNsKDAsIDEwMCUsIDUwJSlcIiBvciBcImhzbCAwIDEwMCUgNTAlXCJcbiAqIFwiaHNsYSgwLCAxMDAlLCA1MCUsIDEpXCIgb3IgXCJoc2xhIDAgMTAwJSA1MCUsIDFcIlxuICogXCJoc3YoMCwgMTAwJSwgMTAwJSlcIiBvciBcImhzdiAwIDEwMCUgMTAwJVwiXG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gaW5wdXRUb1JHQihjb2xvcikge1xuICAgIGxldCByZ2IgPSB7IHI6IDAsIGc6IDAsIGI6IDAgfTtcbiAgICBsZXQgYSA9IDE7XG4gICAgbGV0IHMgPSBudWxsO1xuICAgIGxldCB2ID0gbnVsbDtcbiAgICBsZXQgbCA9IG51bGw7XG4gICAgbGV0IG9rID0gZmFsc2U7XG4gICAgbGV0IGZvcm1hdCA9IGZhbHNlO1xuICAgIGlmICh0eXBlb2YgY29sb3IgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGNvbG9yID0gc3RyaW5nSW5wdXRUb09iamVjdChjb2xvcik7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgY29sb3IgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGlmIChpc1ZhbGlkQ1NTVW5pdChjb2xvci5yKSAmJiBpc1ZhbGlkQ1NTVW5pdChjb2xvci5nKSAmJiBpc1ZhbGlkQ1NTVW5pdChjb2xvci5iKSkge1xuICAgICAgICAgICAgcmdiID0gcmdiVG9SZ2IoY29sb3IuciwgY29sb3IuZywgY29sb3IuYik7XG4gICAgICAgICAgICBvayA9IHRydWU7XG4gICAgICAgICAgICBmb3JtYXQgPSBTdHJpbmcoY29sb3Iucikuc3Vic3RyKC0xKSA9PT0gJyUnID8gJ3ByZ2InIDogJ3JnYic7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaXNWYWxpZENTU1VuaXQoY29sb3IuaCkgJiYgaXNWYWxpZENTU1VuaXQoY29sb3IucykgJiYgaXNWYWxpZENTU1VuaXQoY29sb3IudikpIHtcbiAgICAgICAgICAgIHMgPSBjb252ZXJ0VG9QZXJjZW50YWdlKGNvbG9yLnMpO1xuICAgICAgICAgICAgdiA9IGNvbnZlcnRUb1BlcmNlbnRhZ2UoY29sb3Iudik7XG4gICAgICAgICAgICByZ2IgPSBoc3ZUb1JnYihjb2xvci5oLCBzLCB2KTtcbiAgICAgICAgICAgIG9rID0gdHJ1ZTtcbiAgICAgICAgICAgIGZvcm1hdCA9ICdoc3YnO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGlzVmFsaWRDU1NVbml0KGNvbG9yLmgpICYmIGlzVmFsaWRDU1NVbml0KGNvbG9yLnMpICYmIGlzVmFsaWRDU1NVbml0KGNvbG9yLmwpKSB7XG4gICAgICAgICAgICBzID0gY29udmVydFRvUGVyY2VudGFnZShjb2xvci5zKTtcbiAgICAgICAgICAgIGwgPSBjb252ZXJ0VG9QZXJjZW50YWdlKGNvbG9yLmwpO1xuICAgICAgICAgICAgcmdiID0gaHNsVG9SZ2IoY29sb3IuaCwgcywgbCk7XG4gICAgICAgICAgICBvayA9IHRydWU7XG4gICAgICAgICAgICBmb3JtYXQgPSAnaHNsJztcbiAgICAgICAgfVxuICAgICAgICBpZiAoY29sb3IuaGFzT3duUHJvcGVydHkoJ2EnKSkge1xuICAgICAgICAgICAgYSA9IGNvbG9yLmE7XG4gICAgICAgIH1cbiAgICB9XG4gICAgYSA9IGJvdW5kQWxwaGEoYSk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgb2ssXG4gICAgICAgIGZvcm1hdDogY29sb3IuZm9ybWF0IHx8IGZvcm1hdCxcbiAgICAgICAgcjogTWF0aC5taW4oMjU1LCBNYXRoLm1heChyZ2IuciwgMCkpLFxuICAgICAgICBnOiBNYXRoLm1pbigyNTUsIE1hdGgubWF4KHJnYi5nLCAwKSksXG4gICAgICAgIGI6IE1hdGgubWluKDI1NSwgTWF0aC5tYXgocmdiLmIsIDApKSxcbiAgICAgICAgYSxcbiAgICB9O1xufVxuLy8gPGh0dHA6Ly93d3cudzMub3JnL1RSL2NzczMtdmFsdWVzLyNpbnRlZ2Vycz5cbmNvbnN0IENTU19JTlRFR0VSID0gJ1stXFxcXCtdP1xcXFxkKyU/Jztcbi8vIDxodHRwOi8vd3d3LnczLm9yZy9UUi9jc3MzLXZhbHVlcy8jbnVtYmVyLXZhbHVlPlxuY29uc3QgQ1NTX05VTUJFUiA9ICdbLVxcXFwrXT9cXFxcZCpcXFxcLlxcXFxkKyU/Jztcbi8vIEFsbG93IHBvc2l0aXZlL25lZ2F0aXZlIGludGVnZXIvbnVtYmVyLiAgRG9uJ3QgY2FwdHVyZSB0aGUgZWl0aGVyL29yLCBqdXN0IHRoZSBlbnRpcmUgb3V0Y29tZS5cbmNvbnN0IENTU19VTklUID0gYCg/OiR7Q1NTX05VTUJFUn0pfCg/OiR7Q1NTX0lOVEVHRVJ9KWA7XG4vLyBBY3R1YWwgbWF0Y2hpbmcuXG4vLyBQYXJlbnRoZXNlcyBhbmQgY29tbWFzIGFyZSBvcHRpb25hbCwgYnV0IG5vdCByZXF1aXJlZC5cbi8vIFdoaXRlc3BhY2UgY2FuIHRha2UgdGhlIHBsYWNlIG9mIGNvbW1hcyBvciBvcGVuaW5nIHBhcmVuXG5jb25zdCBQRVJNSVNTSVZFX01BVENIMyA9IGBbXFxcXHN8XFxcXChdKygke0NTU19VTklUfSlbLHxcXFxcc10rKCR7Q1NTX1VOSVR9KVssfFxcXFxzXSsoJHtDU1NfVU5JVH0pXFxcXHMqXFxcXCk/YDtcbmNvbnN0IFBFUk1JU1NJVkVfTUFUQ0g0ID0gYFtcXFxcc3xcXFxcKF0rKCR7Q1NTX1VOSVR9KVssfFxcXFxzXSsoJHtDU1NfVU5JVH0pWyx8XFxcXHNdKygke0NTU19VTklUfSlbLHxcXFxcc10rKCR7Q1NTX1VOSVR9KVxcXFxzKlxcXFwpP2A7XG5jb25zdCBtYXRjaGVycyA9IHtcbiAgICBDU1NfVU5JVDogbmV3IFJlZ0V4cChDU1NfVU5JVCksXG4gICAgcmdiOiBuZXcgUmVnRXhwKCdyZ2InICsgUEVSTUlTU0lWRV9NQVRDSDMpLFxuICAgIHJnYmE6IG5ldyBSZWdFeHAoJ3JnYmEnICsgUEVSTUlTU0lWRV9NQVRDSDQpLFxuICAgIGhzbDogbmV3IFJlZ0V4cCgnaHNsJyArIFBFUk1JU1NJVkVfTUFUQ0gzKSxcbiAgICBoc2xhOiBuZXcgUmVnRXhwKCdoc2xhJyArIFBFUk1JU1NJVkVfTUFUQ0g0KSxcbiAgICBoc3Y6IG5ldyBSZWdFeHAoJ2hzdicgKyBQRVJNSVNTSVZFX01BVENIMyksXG4gICAgaHN2YTogbmV3IFJlZ0V4cCgnaHN2YScgKyBQRVJNSVNTSVZFX01BVENINCksXG4gICAgaGV4MzogL14jPyhbMC05YS1mQS1GXXsxfSkoWzAtOWEtZkEtRl17MX0pKFswLTlhLWZBLUZdezF9KSQvLFxuICAgIGhleDY6IC9eIz8oWzAtOWEtZkEtRl17Mn0pKFswLTlhLWZBLUZdezJ9KShbMC05YS1mQS1GXXsyfSkkLyxcbiAgICBoZXg0OiAvXiM/KFswLTlhLWZBLUZdezF9KShbMC05YS1mQS1GXXsxfSkoWzAtOWEtZkEtRl17MX0pKFswLTlhLWZBLUZdezF9KSQvLFxuICAgIGhleDg6IC9eIz8oWzAtOWEtZkEtRl17Mn0pKFswLTlhLWZBLUZdezJ9KShbMC05YS1mQS1GXXsyfSkoWzAtOWEtZkEtRl17Mn0pJC8sXG59O1xuLyoqXG4gKiBQZXJtaXNzaXZlIHN0cmluZyBwYXJzaW5nLiAgVGFrZSBpbiBhIG51bWJlciBvZiBmb3JtYXRzLCBhbmQgb3V0cHV0IGFuIG9iamVjdFxuICogYmFzZWQgb24gZGV0ZWN0ZWQgZm9ybWF0LiAgUmV0dXJucyBgeyByLCBnLCBiIH1gIG9yIGB7IGgsIHMsIGwgfWAgb3IgYHsgaCwgcywgdn1gXG4gKi9cbmZ1bmN0aW9uIHN0cmluZ0lucHV0VG9PYmplY3QoY29sb3IpIHtcbiAgICBjb2xvciA9IGNvbG9yLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgIGlmIChjb2xvci5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBsZXQgbmFtZWQgPSBmYWxzZTtcbiAgICBpZiAobmFtZXNbY29sb3JdKSB7XG4gICAgICAgIGNvbG9yID0gbmFtZXNbY29sb3JdO1xuICAgICAgICBuYW1lZCA9IHRydWU7XG4gICAgfVxuICAgIGVsc2UgaWYgKGNvbG9yID09PSAndHJhbnNwYXJlbnQnKSB7XG4gICAgICAgIHJldHVybiB7IHI6IDAsIGc6IDAsIGI6IDAsIGE6IDAsIGZvcm1hdDogJ25hbWUnIH07XG4gICAgfVxuICAgIC8vIFRyeSB0byBtYXRjaCBzdHJpbmcgaW5wdXQgdXNpbmcgcmVndWxhciBleHByZXNzaW9ucy5cbiAgICAvLyBLZWVwIG1vc3Qgb2YgdGhlIG51bWJlciBib3VuZGluZyBvdXQgb2YgdGhpcyBmdW5jdGlvbiAtIGRvbid0IHdvcnJ5IGFib3V0IFswLDFdIG9yIFswLDEwMF0gb3IgWzAsMzYwXVxuICAgIC8vIEp1c3QgcmV0dXJuIGFuIG9iamVjdCBhbmQgbGV0IHRoZSBjb252ZXJzaW9uIGZ1bmN0aW9ucyBoYW5kbGUgdGhhdC5cbiAgICAvLyBUaGlzIHdheSB0aGUgcmVzdWx0IHdpbGwgYmUgdGhlIHNhbWUgd2hldGhlciB0aGUgdGlueWNvbG9yIGlzIGluaXRpYWxpemVkIHdpdGggc3RyaW5nIG9yIG9iamVjdC5cbiAgICBsZXQgbWF0Y2ggPSBtYXRjaGVycy5yZ2IuZXhlYyhjb2xvcik7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICAgIHJldHVybiB7IHI6IG1hdGNoWzFdLCBnOiBtYXRjaFsyXSwgYjogbWF0Y2hbM10gfTtcbiAgICB9XG4gICAgbWF0Y2ggPSBtYXRjaGVycy5yZ2JhLmV4ZWMoY29sb3IpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgICByZXR1cm4geyByOiBtYXRjaFsxXSwgZzogbWF0Y2hbMl0sIGI6IG1hdGNoWzNdLCBhOiBtYXRjaFs0XSB9O1xuICAgIH1cbiAgICBtYXRjaCA9IG1hdGNoZXJzLmhzbC5leGVjKGNvbG9yKTtcbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgcmV0dXJuIHsgaDogbWF0Y2hbMV0sIHM6IG1hdGNoWzJdLCBsOiBtYXRjaFszXSB9O1xuICAgIH1cbiAgICBtYXRjaCA9IG1hdGNoZXJzLmhzbGEuZXhlYyhjb2xvcik7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICAgIHJldHVybiB7IGg6IG1hdGNoWzFdLCBzOiBtYXRjaFsyXSwgbDogbWF0Y2hbM10sIGE6IG1hdGNoWzRdIH07XG4gICAgfVxuICAgIG1hdGNoID0gbWF0Y2hlcnMuaHN2LmV4ZWMoY29sb3IpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgICByZXR1cm4geyBoOiBtYXRjaFsxXSwgczogbWF0Y2hbMl0sIHY6IG1hdGNoWzNdIH07XG4gICAgfVxuICAgIG1hdGNoID0gbWF0Y2hlcnMuaHN2YS5leGVjKGNvbG9yKTtcbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgcmV0dXJuIHsgaDogbWF0Y2hbMV0sIHM6IG1hdGNoWzJdLCB2OiBtYXRjaFszXSwgYTogbWF0Y2hbNF0gfTtcbiAgICB9XG4gICAgbWF0Y2ggPSBtYXRjaGVycy5oZXg4LmV4ZWMoY29sb3IpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcjogcGFyc2VJbnRGcm9tSGV4KG1hdGNoWzFdKSxcbiAgICAgICAgICAgIGc6IHBhcnNlSW50RnJvbUhleChtYXRjaFsyXSksXG4gICAgICAgICAgICBiOiBwYXJzZUludEZyb21IZXgobWF0Y2hbM10pLFxuICAgICAgICAgICAgYTogY29udmVydEhleFRvRGVjaW1hbChtYXRjaFs0XSksXG4gICAgICAgICAgICBmb3JtYXQ6IG5hbWVkID8gJ25hbWUnIDogJ2hleDgnLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBtYXRjaCA9IG1hdGNoZXJzLmhleDYuZXhlYyhjb2xvcik7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByOiBwYXJzZUludEZyb21IZXgobWF0Y2hbMV0pLFxuICAgICAgICAgICAgZzogcGFyc2VJbnRGcm9tSGV4KG1hdGNoWzJdKSxcbiAgICAgICAgICAgIGI6IHBhcnNlSW50RnJvbUhleChtYXRjaFszXSksXG4gICAgICAgICAgICBmb3JtYXQ6IG5hbWVkID8gJ25hbWUnIDogJ2hleCcsXG4gICAgICAgIH07XG4gICAgfVxuICAgIG1hdGNoID0gbWF0Y2hlcnMuaGV4NC5leGVjKGNvbG9yKTtcbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHI6IHBhcnNlSW50RnJvbUhleChtYXRjaFsxXSArIG1hdGNoWzFdKSxcbiAgICAgICAgICAgIGc6IHBhcnNlSW50RnJvbUhleChtYXRjaFsyXSArIG1hdGNoWzJdKSxcbiAgICAgICAgICAgIGI6IHBhcnNlSW50RnJvbUhleChtYXRjaFszXSArIG1hdGNoWzNdKSxcbiAgICAgICAgICAgIGE6IGNvbnZlcnRIZXhUb0RlY2ltYWwobWF0Y2hbNF0gKyBtYXRjaFs0XSksXG4gICAgICAgICAgICBmb3JtYXQ6IG5hbWVkID8gJ25hbWUnIDogJ2hleDgnLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBtYXRjaCA9IG1hdGNoZXJzLmhleDMuZXhlYyhjb2xvcik7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByOiBwYXJzZUludEZyb21IZXgobWF0Y2hbMV0gKyBtYXRjaFsxXSksXG4gICAgICAgICAgICBnOiBwYXJzZUludEZyb21IZXgobWF0Y2hbMl0gKyBtYXRjaFsyXSksXG4gICAgICAgICAgICBiOiBwYXJzZUludEZyb21IZXgobWF0Y2hbM10gKyBtYXRjaFszXSksXG4gICAgICAgICAgICBmb3JtYXQ6IG5hbWVkID8gJ25hbWUnIDogJ2hleCcsXG4gICAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn1cbi8qKlxuICogQ2hlY2sgdG8gc2VlIGlmIGl0IGxvb2tzIGxpa2UgYSBDU1MgdW5pdFxuICogKHNlZSBgbWF0Y2hlcnNgIGFib3ZlIGZvciBkZWZpbml0aW9uKS5cbiAqL1xuZnVuY3Rpb24gaXNWYWxpZENTU1VuaXQoY29sb3IpIHtcbiAgICByZXR1cm4gISFtYXRjaGVycy5DU1NfVU5JVC5leGVjKFN0cmluZyhjb2xvcikpO1xufVxuXG5jbGFzcyBUaW55Q29sb3Ige1xuICAgIGNvbnN0cnVjdG9yKGNvbG9yID0gJycsIG9wdHMgPSB7fSkge1xuICAgICAgICAvLyBJZiBpbnB1dCBpcyBhbHJlYWR5IGEgdGlueWNvbG9yLCByZXR1cm4gaXRzZWxmXG4gICAgICAgIGlmIChjb2xvciBpbnN0YW5jZW9mIFRpbnlDb2xvcikge1xuICAgICAgICAgICAgcmV0dXJuIGNvbG9yO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMub3JpZ2luYWxJbnB1dCA9IGNvbG9yO1xuICAgICAgICBjb25zdCByZ2IgPSBpbnB1dFRvUkdCKGNvbG9yKTtcbiAgICAgICAgdGhpcy5vcmlnaW5hbElucHV0ID0gY29sb3I7XG4gICAgICAgIHRoaXMuciA9IHJnYi5yO1xuICAgICAgICB0aGlzLmcgPSByZ2IuZztcbiAgICAgICAgdGhpcy5iID0gcmdiLmI7XG4gICAgICAgIHRoaXMuYSA9IHJnYi5hO1xuICAgICAgICB0aGlzLnJvdW5kQSA9IE1hdGgucm91bmQoMTAwICogdGhpcy5hKSAvIDEwMDtcbiAgICAgICAgdGhpcy5mb3JtYXQgPSBvcHRzLmZvcm1hdCB8fCByZ2IuZm9ybWF0O1xuICAgICAgICB0aGlzLmdyYWRpZW50VHlwZSA9IG9wdHMuZ3JhZGllbnRUeXBlO1xuICAgICAgICAvLyBEb24ndCBsZXQgdGhlIHJhbmdlIG9mIFswLDI1NV0gY29tZSBiYWNrIGluIFswLDFdLlxuICAgICAgICAvLyBQb3RlbnRpYWxseSBsb3NlIGEgbGl0dGxlIGJpdCBvZiBwcmVjaXNpb24gaGVyZSwgYnV0IHdpbGwgZml4IGlzc3VlcyB3aGVyZVxuICAgICAgICAvLyAuNSBnZXRzIGludGVycHJldGVkIGFzIGhhbGYgb2YgdGhlIHRvdGFsLCBpbnN0ZWFkIG9mIGhhbGYgb2YgMVxuICAgICAgICAvLyBJZiBpdCB3YXMgc3VwcG9zZWQgdG8gYmUgMTI4LCB0aGlzIHdhcyBhbHJlYWR5IHRha2VuIGNhcmUgb2YgYnkgYGlucHV0VG9SZ2JgXG4gICAgICAgIGlmICh0aGlzLnIgPCAxKSB7XG4gICAgICAgICAgICB0aGlzLnIgPSBNYXRoLnJvdW5kKHRoaXMucik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuZyA8IDEpIHtcbiAgICAgICAgICAgIHRoaXMuZyA9IE1hdGgucm91bmQodGhpcy5nKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5iIDwgMSkge1xuICAgICAgICAgICAgdGhpcy5iID0gTWF0aC5yb3VuZCh0aGlzLmIpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuaXNWYWxpZCA9IHJnYi5vaztcbiAgICB9XG4gICAgaXNEYXJrKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5nZXRCcmlnaHRuZXNzKCkgPCAxMjg7XG4gICAgfVxuICAgIGlzTGlnaHQoKSB7XG4gICAgICAgIHJldHVybiAhdGhpcy5pc0RhcmsoKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgcGVyY2VpdmVkIGJyaWdodG5lc3Mgb2YgdGhlIGNvbG9yLCBmcm9tIDAtMjU1LlxuICAgICAqL1xuICAgIGdldEJyaWdodG5lc3MoKSB7XG4gICAgICAgIC8vIGh0dHA6Ly93d3cudzMub3JnL1RSL0FFUlQjY29sb3ItY29udHJhc3RcbiAgICAgICAgY29uc3QgcmdiID0gdGhpcy50b1JnYigpO1xuICAgICAgICByZXR1cm4gKHJnYi5yICogMjk5ICsgcmdiLmcgKiA1ODcgKyByZ2IuYiAqIDExNCkgLyAxMDAwO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBwZXJjZWl2ZWQgbHVtaW5hbmNlIG9mIGEgY29sb3IsIGZyb20gMC0xLlxuICAgICAqL1xuICAgIGdldEx1bWluYW5jZSgpIHtcbiAgICAgICAgLy8gaHR0cDovL3d3dy53My5vcmcvVFIvMjAwOC9SRUMtV0NBRzIwLTIwMDgxMjExLyNyZWxhdGl2ZWx1bWluYW5jZWRlZlxuICAgICAgICBjb25zdCByZ2IgPSB0aGlzLnRvUmdiKCk7XG4gICAgICAgIGxldCBSO1xuICAgICAgICBsZXQgRztcbiAgICAgICAgbGV0IEI7XG4gICAgICAgIGNvbnN0IFJzUkdCID0gcmdiLnIgLyAyNTU7XG4gICAgICAgIGNvbnN0IEdzUkdCID0gcmdiLmcgLyAyNTU7XG4gICAgICAgIGNvbnN0IEJzUkdCID0gcmdiLmIgLyAyNTU7XG4gICAgICAgIGlmIChSc1JHQiA8PSAwLjAzOTI4KSB7XG4gICAgICAgICAgICBSID0gUnNSR0IgLyAxMi45MjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIFIgPSBNYXRoLnBvdygoUnNSR0IgKyAwLjA1NSkgLyAxLjA1NSwgMi40KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoR3NSR0IgPD0gMC4wMzkyOCkge1xuICAgICAgICAgICAgRyA9IEdzUkdCIC8gMTIuOTI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBHID0gTWF0aC5wb3coKEdzUkdCICsgMC4wNTUpIC8gMS4wNTUsIDIuNCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKEJzUkdCIDw9IDAuMDM5MjgpIHtcbiAgICAgICAgICAgIEIgPSBCc1JHQiAvIDEyLjkyO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgQiA9IE1hdGgucG93KChCc1JHQiArIDAuMDU1KSAvIDEuMDU1LCAyLjQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAwLjIxMjYgKiBSICsgMC43MTUyICogRyArIDAuMDcyMiAqIEI7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFNldHMgdGhlIGFscGhhIHZhbHVlIG9uIHRoZSBjdXJyZW50IGNvbG9yLlxuICAgICAqXG4gICAgICogQHBhcmFtIGFscGhhIC0gVGhlIG5ldyBhbHBoYSB2YWx1ZS4gVGhlIGFjY2VwdGVkIHJhbmdlIGlzIDAtMS5cbiAgICAgKi9cbiAgICBzZXRBbHBoYShhbHBoYSkge1xuICAgICAgICB0aGlzLmEgPSBib3VuZEFscGhhKGFscGhhKTtcbiAgICAgICAgdGhpcy5yb3VuZEEgPSBNYXRoLnJvdW5kKDEwMCAqIHRoaXMuYSkgLyAxMDA7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBvYmplY3QgYXMgYSBIU1ZBIG9iamVjdC5cbiAgICAgKi9cbiAgICB0b0hzdigpIHtcbiAgICAgICAgY29uc3QgaHN2ID0gcmdiVG9Ic3YodGhpcy5yLCB0aGlzLmcsIHRoaXMuYik7XG4gICAgICAgIHJldHVybiB7IGg6IGhzdi5oICogMzYwLCBzOiBoc3YucywgdjogaHN2LnYsIGE6IHRoaXMuYSB9O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBoc3ZhIHZhbHVlcyBpbnRlcnBvbGF0ZWQgaW50byBhIHN0cmluZyB3aXRoIHRoZSBmb2xsb3dpbmcgZm9ybWF0OlxuICAgICAqIFwiaHN2YSh4eHgsIHh4eCwgeHh4LCB4eClcIi5cbiAgICAgKi9cbiAgICB0b0hzdlN0cmluZygpIHtcbiAgICAgICAgY29uc3QgaHN2ID0gcmdiVG9Ic3YodGhpcy5yLCB0aGlzLmcsIHRoaXMuYik7XG4gICAgICAgIGNvbnN0IGggPSBNYXRoLnJvdW5kKGhzdi5oICogMzYwKTtcbiAgICAgICAgY29uc3QgcyA9IE1hdGgucm91bmQoaHN2LnMgKiAxMDApO1xuICAgICAgICBjb25zdCB2ID0gTWF0aC5yb3VuZChoc3YudiAqIDEwMCk7XG4gICAgICAgIHJldHVybiB0aGlzLmEgPT09IDEgPyBgaHN2KCR7aH0sICR7c30lLCAke3Z9JSlgIDogYGhzdmEoJHtofSwgJHtzfSUsICR7dn0lLCAke3RoaXMucm91bmRBfSlgO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBvYmplY3QgYXMgYSBIU0xBIG9iamVjdC5cbiAgICAgKi9cbiAgICB0b0hzbCgpIHtcbiAgICAgICAgY29uc3QgaHNsID0gcmdiVG9Ic2wodGhpcy5yLCB0aGlzLmcsIHRoaXMuYik7XG4gICAgICAgIHJldHVybiB7IGg6IGhzbC5oICogMzYwLCBzOiBoc2wucywgbDogaHNsLmwsIGE6IHRoaXMuYSB9O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBoc2xhIHZhbHVlcyBpbnRlcnBvbGF0ZWQgaW50byBhIHN0cmluZyB3aXRoIHRoZSBmb2xsb3dpbmcgZm9ybWF0OlxuICAgICAqIFwiaHNsYSh4eHgsIHh4eCwgeHh4LCB4eClcIi5cbiAgICAgKi9cbiAgICB0b0hzbFN0cmluZygpIHtcbiAgICAgICAgY29uc3QgaHNsID0gcmdiVG9Ic2wodGhpcy5yLCB0aGlzLmcsIHRoaXMuYik7XG4gICAgICAgIGNvbnN0IGggPSBNYXRoLnJvdW5kKGhzbC5oICogMzYwKTtcbiAgICAgICAgY29uc3QgcyA9IE1hdGgucm91bmQoaHNsLnMgKiAxMDApO1xuICAgICAgICBjb25zdCBsID0gTWF0aC5yb3VuZChoc2wubCAqIDEwMCk7XG4gICAgICAgIHJldHVybiB0aGlzLmEgPT09IDEgPyBgaHNsKCR7aH0sICR7c30lLCAke2x9JSlgIDogYGhzbGEoJHtofSwgJHtzfSUsICR7bH0lLCAke3RoaXMucm91bmRBfSlgO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBoZXggdmFsdWUgb2YgdGhlIGNvbG9yLlxuICAgICAqIEBwYXJhbSBhbGxvdzNDaGFyIHdpbGwgc2hvcnRlbiBoZXggdmFsdWUgdG8gMyBjaGFyIGlmIHBvc3NpYmxlXG4gICAgICovXG4gICAgdG9IZXgoYWxsb3czQ2hhciA9IGZhbHNlKSB7XG4gICAgICAgIHJldHVybiByZ2JUb0hleCh0aGlzLnIsIHRoaXMuZywgdGhpcy5iLCBhbGxvdzNDaGFyKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgaGV4IHZhbHVlIG9mIHRoZSBjb2xvciAtd2l0aCBhICMgYXBwZW5lZC5cbiAgICAgKiBAcGFyYW0gYWxsb3czQ2hhciB3aWxsIHNob3J0ZW4gaGV4IHZhbHVlIHRvIDMgY2hhciBpZiBwb3NzaWJsZVxuICAgICAqL1xuICAgIHRvSGV4U3RyaW5nKGFsbG93M0NoYXIgPSBmYWxzZSkge1xuICAgICAgICByZXR1cm4gJyMnICsgdGhpcy50b0hleChhbGxvdzNDaGFyKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgaGV4IDggdmFsdWUgb2YgdGhlIGNvbG9yLlxuICAgICAqIEBwYXJhbSBhbGxvdzRDaGFyIHdpbGwgc2hvcnRlbiBoZXggdmFsdWUgdG8gNCBjaGFyIGlmIHBvc3NpYmxlXG4gICAgICovXG4gICAgdG9IZXg4KGFsbG93NENoYXIgPSBmYWxzZSkge1xuICAgICAgICByZXR1cm4gcmdiYVRvSGV4KHRoaXMuciwgdGhpcy5nLCB0aGlzLmIsIHRoaXMuYSwgYWxsb3c0Q2hhcik7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIGhleCA4IHZhbHVlIG9mIHRoZSBjb2xvciAtd2l0aCBhICMgYXBwZW5lZC5cbiAgICAgKiBAcGFyYW0gYWxsb3c0Q2hhciB3aWxsIHNob3J0ZW4gaGV4IHZhbHVlIHRvIDQgY2hhciBpZiBwb3NzaWJsZVxuICAgICAqL1xuICAgIHRvSGV4OFN0cmluZyhhbGxvdzRDaGFyID0gZmFsc2UpIHtcbiAgICAgICAgcmV0dXJuICcjJyArIHRoaXMudG9IZXg4KGFsbG93NENoYXIpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBvYmplY3QgYXMgYSBSR0JBIG9iamVjdC5cbiAgICAgKi9cbiAgICB0b1JnYigpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHI6IE1hdGgucm91bmQodGhpcy5yKSxcbiAgICAgICAgICAgIGc6IE1hdGgucm91bmQodGhpcy5nKSxcbiAgICAgICAgICAgIGI6IE1hdGgucm91bmQodGhpcy5iKSxcbiAgICAgICAgICAgIGE6IHRoaXMuYSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgUkdCQSB2YWx1ZXMgaW50ZXJwb2xhdGVkIGludG8gYSBzdHJpbmcgd2l0aCB0aGUgZm9sbG93aW5nIGZvcm1hdDpcbiAgICAgKiBcIlJHQkEoeHh4LCB4eHgsIHh4eCwgeHgpXCIuXG4gICAgICovXG4gICAgdG9SZ2JTdHJpbmcoKSB7XG4gICAgICAgIGNvbnN0IHIgPSBNYXRoLnJvdW5kKHRoaXMucik7XG4gICAgICAgIGNvbnN0IGcgPSBNYXRoLnJvdW5kKHRoaXMuZyk7XG4gICAgICAgIGNvbnN0IGIgPSBNYXRoLnJvdW5kKHRoaXMuYik7XG4gICAgICAgIHJldHVybiB0aGlzLmEgPT09IDEgPyBgcmdiKCR7cn0sICR7Z30sICR7Yn0pYCA6IGByZ2JhKCR7cn0sICR7Z30sICR7Yn0sICR7dGhpcy5yb3VuZEF9KWA7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIG9iamVjdCBhcyBhIFJHQkEgb2JqZWN0LlxuICAgICAqL1xuICAgIHRvUGVyY2VudGFnZVJnYigpIHtcbiAgICAgICAgY29uc3QgZm10ID0gKHgpID0+IE1hdGgucm91bmQoYm91bmQwMSh4LCAyNTUpICogMTAwKSArICclJztcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHI6IGZtdCh0aGlzLnIpLFxuICAgICAgICAgICAgZzogZm10KHRoaXMuZyksXG4gICAgICAgICAgICBiOiBmbXQodGhpcy5iKSxcbiAgICAgICAgICAgIGE6IHRoaXMuYSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgUkdCQSByZWxhdGl2ZSB2YWx1ZXMgaW50ZXJwb2xhdGVkIGludG8gYSBzdHJpbmdcbiAgICAgKi9cbiAgICB0b1BlcmNlbnRhZ2VSZ2JTdHJpbmcoKSB7XG4gICAgICAgIGNvbnN0IHJuZCA9ICh4KSA9PiBNYXRoLnJvdW5kKGJvdW5kMDEoeCwgMjU1KSAqIDEwMCk7XG4gICAgICAgIHJldHVybiB0aGlzLmEgPT09IDFcbiAgICAgICAgICAgID8gYHJnYigke3JuZCh0aGlzLnIpfSUsICR7cm5kKHRoaXMuZyl9JSwgJHtybmQodGhpcy5iKX0lKWBcbiAgICAgICAgICAgIDogYHJnYmEoJHtybmQodGhpcy5yKX0lLCAke3JuZCh0aGlzLmcpfSUsICR7cm5kKHRoaXMuYil9JSwgJHt0aGlzLnJvdW5kQX0pYDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogVGhlICdyZWFsJyBuYW1lIG9mIHRoZSBjb2xvciAtaWYgdGhlcmUgaXMgb25lLlxuICAgICAqL1xuICAgIHRvTmFtZSgpIHtcbiAgICAgICAgaWYgKHRoaXMuYSA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuICd0cmFuc3BhcmVudCc7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuYSA8IDEpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBoZXggPSAnIycgKyByZ2JUb0hleCh0aGlzLnIsIHRoaXMuZywgdGhpcy5iLCBmYWxzZSk7XG4gICAgICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKG5hbWVzKSkge1xuICAgICAgICAgICAgaWYgKG5hbWVzW2tleV0gPT09IGhleCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBrZXk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBTdHJpbmcgcmVwcmVzZW50YXRpb24gb2YgdGhlIGNvbG9yLlxuICAgICAqXG4gICAgICogQHBhcmFtIGZvcm1hdCAtIFRoZSBmb3JtYXQgdG8gYmUgdXNlZCB3aGVuIGRpc3BsYXlpbmcgdGhlIHN0cmluZyByZXByZXNlbnRhdGlvbi5cbiAgICAgKi9cbiAgICB0b1N0cmluZyhmb3JtYXQpIHtcbiAgICAgICAgY29uc3QgZm9ybWF0U2V0ID0gISFmb3JtYXQ7XG4gICAgICAgIGZvcm1hdCA9IGZvcm1hdCB8fCB0aGlzLmZvcm1hdDtcbiAgICAgICAgbGV0IGZvcm1hdHRlZFN0cmluZyA9IGZhbHNlO1xuICAgICAgICBjb25zdCBoYXNBbHBoYSA9IHRoaXMuYSA8IDEgJiYgdGhpcy5hID49IDA7XG4gICAgICAgIGNvbnN0IG5lZWRzQWxwaGFGb3JtYXQgPSAhZm9ybWF0U2V0ICYmIGhhc0FscGhhICYmIChmb3JtYXQuc3RhcnRzV2l0aCgnaGV4JykgfHwgZm9ybWF0ID09PSAnbmFtZScpO1xuICAgICAgICBpZiAobmVlZHNBbHBoYUZvcm1hdCkge1xuICAgICAgICAgICAgLy8gU3BlY2lhbCBjYXNlIGZvciBcInRyYW5zcGFyZW50XCIsIGFsbCBvdGhlciBub24tYWxwaGEgZm9ybWF0c1xuICAgICAgICAgICAgLy8gd2lsbCByZXR1cm4gcmdiYSB3aGVuIHRoZXJlIGlzIHRyYW5zcGFyZW5jeS5cbiAgICAgICAgICAgIGlmIChmb3JtYXQgPT09ICduYW1lJyAmJiB0aGlzLmEgPT09IDApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy50b05hbWUoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0aGlzLnRvUmdiU3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ3JnYicpIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZFN0cmluZyA9IHRoaXMudG9SZ2JTdHJpbmcoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZm9ybWF0ID09PSAncHJnYicpIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZFN0cmluZyA9IHRoaXMudG9QZXJjZW50YWdlUmdiU3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ2hleCcgfHwgZm9ybWF0ID09PSAnaGV4NicpIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZFN0cmluZyA9IHRoaXMudG9IZXhTdHJpbmcoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZm9ybWF0ID09PSAnaGV4MycpIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZFN0cmluZyA9IHRoaXMudG9IZXhTdHJpbmcodHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ2hleDQnKSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRTdHJpbmcgPSB0aGlzLnRvSGV4OFN0cmluZyh0cnVlKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZm9ybWF0ID09PSAnaGV4OCcpIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZFN0cmluZyA9IHRoaXMudG9IZXg4U3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ25hbWUnKSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRTdHJpbmcgPSB0aGlzLnRvTmFtZSgpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChmb3JtYXQgPT09ICdoc2wnKSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRTdHJpbmcgPSB0aGlzLnRvSHNsU3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ2hzdicpIHtcbiAgICAgICAgICAgIGZvcm1hdHRlZFN0cmluZyA9IHRoaXMudG9Ic3ZTdHJpbmcoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZm9ybWF0dGVkU3RyaW5nIHx8IHRoaXMudG9IZXhTdHJpbmcoKTtcbiAgICB9XG4gICAgY2xvbmUoKSB7XG4gICAgICAgIHJldHVybiBuZXcgVGlueUNvbG9yKHRoaXMudG9TdHJpbmcoKSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIExpZ2h0ZW4gdGhlIGNvbG9yIGEgZ2l2ZW4gYW1vdW50LiBQcm92aWRpbmcgMTAwIHdpbGwgYWx3YXlzIHJldHVybiB3aGl0ZS5cbiAgICAgKiBAcGFyYW0gYW1vdW50IC0gdmFsaWQgYmV0d2VlbiAxLTEwMFxuICAgICAqL1xuICAgIGxpZ2h0ZW4oYW1vdW50ID0gMTApIHtcbiAgICAgICAgY29uc3QgaHNsID0gdGhpcy50b0hzbCgpO1xuICAgICAgICBoc2wubCArPSBhbW91bnQgLyAxMDA7XG4gICAgICAgIGhzbC5sID0gY2xhbXAwMShoc2wubCk7XG4gICAgICAgIHJldHVybiBuZXcgVGlueUNvbG9yKGhzbCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEJyaWdodGVuIHRoZSBjb2xvciBhIGdpdmVuIGFtb3VudCwgZnJvbSAwIHRvIDEwMC5cbiAgICAgKiBAcGFyYW0gYW1vdW50IC0gdmFsaWQgYmV0d2VlbiAxLTEwMFxuICAgICAqL1xuICAgIGJyaWdodGVuKGFtb3VudCA9IDEwKSB7XG4gICAgICAgIGNvbnN0IHJnYiA9IHRoaXMudG9SZ2IoKTtcbiAgICAgICAgcmdiLnIgPSBNYXRoLm1heCgwLCBNYXRoLm1pbigyNTUsIHJnYi5yIC0gTWF0aC5yb3VuZCgyNTUgKiAtKGFtb3VudCAvIDEwMCkpKSk7XG4gICAgICAgIHJnYi5nID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oMjU1LCByZ2IuZyAtIE1hdGgucm91bmQoMjU1ICogLShhbW91bnQgLyAxMDApKSkpO1xuICAgICAgICByZ2IuYiA9IE1hdGgubWF4KDAsIE1hdGgubWluKDI1NSwgcmdiLmIgLSBNYXRoLnJvdW5kKDI1NSAqIC0oYW1vdW50IC8gMTAwKSkpKTtcbiAgICAgICAgcmV0dXJuIG5ldyBUaW55Q29sb3IocmdiKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogRGFya2VuIHRoZSBjb2xvciBhIGdpdmVuIGFtb3VudCwgZnJvbSAwIHRvIDEwMC5cbiAgICAgKiBQcm92aWRpbmcgMTAwIHdpbGwgYWx3YXlzIHJldHVybiBibGFjay5cbiAgICAgKiBAcGFyYW0gYW1vdW50IC0gdmFsaWQgYmV0d2VlbiAxLTEwMFxuICAgICAqL1xuICAgIGRhcmtlbihhbW91bnQgPSAxMCkge1xuICAgICAgICBjb25zdCBoc2wgPSB0aGlzLnRvSHNsKCk7XG4gICAgICAgIGhzbC5sIC09IGFtb3VudCAvIDEwMDtcbiAgICAgICAgaHNsLmwgPSBjbGFtcDAxKGhzbC5sKTtcbiAgICAgICAgcmV0dXJuIG5ldyBUaW55Q29sb3IoaHNsKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogTWl4IHRoZSBjb2xvciB3aXRoIHB1cmUgd2hpdGUsIGZyb20gMCB0byAxMDAuXG4gICAgICogUHJvdmlkaW5nIDAgd2lsbCBkbyBub3RoaW5nLCBwcm92aWRpbmcgMTAwIHdpbGwgYWx3YXlzIHJldHVybiB3aGl0ZS5cbiAgICAgKiBAcGFyYW0gYW1vdW50IC0gdmFsaWQgYmV0d2VlbiAxLTEwMFxuICAgICAqL1xuICAgIHRpbnQoYW1vdW50ID0gMTApIHtcbiAgICAgICAgcmV0dXJuIHRoaXMubWl4KCd3aGl0ZScsIGFtb3VudCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIE1peCB0aGUgY29sb3Igd2l0aCBwdXJlIGJsYWNrLCBmcm9tIDAgdG8gMTAwLlxuICAgICAqIFByb3ZpZGluZyAwIHdpbGwgZG8gbm90aGluZywgcHJvdmlkaW5nIDEwMCB3aWxsIGFsd2F5cyByZXR1cm4gYmxhY2suXG4gICAgICogQHBhcmFtIGFtb3VudCAtIHZhbGlkIGJldHdlZW4gMS0xMDBcbiAgICAgKi9cbiAgICBzaGFkZShhbW91bnQgPSAxMCkge1xuICAgICAgICByZXR1cm4gdGhpcy5taXgoJ2JsYWNrJywgYW1vdW50KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogRGVzYXR1cmF0ZSB0aGUgY29sb3IgYSBnaXZlbiBhbW91bnQsIGZyb20gMCB0byAxMDAuXG4gICAgICogUHJvdmlkaW5nIDEwMCB3aWxsIGlzIHRoZSBzYW1lIGFzIGNhbGxpbmcgZ3JleXNjYWxlXG4gICAgICogQHBhcmFtIGFtb3VudCAtIHZhbGlkIGJldHdlZW4gMS0xMDBcbiAgICAgKi9cbiAgICBkZXNhdHVyYXRlKGFtb3VudCA9IDEwKSB7XG4gICAgICAgIGNvbnN0IGhzbCA9IHRoaXMudG9Ic2woKTtcbiAgICAgICAgaHNsLnMgLT0gYW1vdW50IC8gMTAwO1xuICAgICAgICBoc2wucyA9IGNsYW1wMDEoaHNsLnMpO1xuICAgICAgICByZXR1cm4gbmV3IFRpbnlDb2xvcihoc2wpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBTYXR1cmF0ZSB0aGUgY29sb3IgYSBnaXZlbiBhbW91bnQsIGZyb20gMCB0byAxMDAuXG4gICAgICogQHBhcmFtIGFtb3VudCAtIHZhbGlkIGJldHdlZW4gMS0xMDBcbiAgICAgKi9cbiAgICBzYXR1cmF0ZShhbW91bnQgPSAxMCkge1xuICAgICAgICBjb25zdCBoc2wgPSB0aGlzLnRvSHNsKCk7XG4gICAgICAgIGhzbC5zICs9IGFtb3VudCAvIDEwMDtcbiAgICAgICAgaHNsLnMgPSBjbGFtcDAxKGhzbC5zKTtcbiAgICAgICAgcmV0dXJuIG5ldyBUaW55Q29sb3IoaHNsKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQ29tcGxldGVseSBkZXNhdHVyYXRlcyBhIGNvbG9yIGludG8gZ3JleXNjYWxlLlxuICAgICAqIFNhbWUgYXMgY2FsbGluZyBgZGVzYXR1cmF0ZSgxMDApYFxuICAgICAqL1xuICAgIGdyZXlzY2FsZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZGVzYXR1cmF0ZSgxMDApO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBTcGluIHRha2VzIGEgcG9zaXRpdmUgb3IgbmVnYXRpdmUgYW1vdW50IHdpdGhpbiBbLTM2MCwgMzYwXSBpbmRpY2F0aW5nIHRoZSBjaGFuZ2Ugb2YgaHVlLlxuICAgICAqIFZhbHVlcyBvdXRzaWRlIG9mIHRoaXMgcmFuZ2Ugd2lsbCBiZSB3cmFwcGVkIGludG8gdGhpcyByYW5nZS5cbiAgICAgKi9cbiAgICBzcGluKGFtb3VudCkge1xuICAgICAgICBjb25zdCBoc2wgPSB0aGlzLnRvSHNsKCk7XG4gICAgICAgIGNvbnN0IGh1ZSA9IChoc2wuaCArIGFtb3VudCkgJSAzNjA7XG4gICAgICAgIGhzbC5oID0gaHVlIDwgMCA/IDM2MCArIGh1ZSA6IGh1ZTtcbiAgICAgICAgcmV0dXJuIG5ldyBUaW55Q29sb3IoaHNsKTtcbiAgICB9XG4gICAgbWl4KGNvbG9yLCBhbW91bnQgPSA1MCkge1xuICAgICAgICBjb25zdCByZ2IxID0gdGhpcy50b1JnYigpO1xuICAgICAgICBjb25zdCByZ2IyID0gbmV3IFRpbnlDb2xvcihjb2xvcikudG9SZ2IoKTtcbiAgICAgICAgY29uc3QgcCA9IGFtb3VudCAvIDEwMDtcbiAgICAgICAgY29uc3QgcmdiYSA9IHtcbiAgICAgICAgICAgIHI6IChyZ2IyLnIgLSByZ2IxLnIpICogcCArIHJnYjEucixcbiAgICAgICAgICAgIGc6IChyZ2IyLmcgLSByZ2IxLmcpICogcCArIHJnYjEuZyxcbiAgICAgICAgICAgIGI6IChyZ2IyLmIgLSByZ2IxLmIpICogcCArIHJnYjEuYixcbiAgICAgICAgICAgIGE6IChyZ2IyLmEgLSByZ2IxLmEpICogcCArIHJnYjEuYSxcbiAgICAgICAgfTtcbiAgICAgICAgcmV0dXJuIG5ldyBUaW55Q29sb3IocmdiYSk7XG4gICAgfVxuICAgIGFuYWxvZ291cyhyZXN1bHRzID0gNiwgc2xpY2VzID0gMzApIHtcbiAgICAgICAgY29uc3QgaHNsID0gdGhpcy50b0hzbCgpO1xuICAgICAgICBjb25zdCBwYXJ0ID0gMzYwIC8gc2xpY2VzO1xuICAgICAgICBjb25zdCByZXQgPSBbdGhpc107XG4gICAgICAgIGZvciAoaHNsLmggPSAoaHNsLmggLSAoKHBhcnQgKiByZXN1bHRzKSA+PiAxKSArIDcyMCkgJSAzNjA7IC0tcmVzdWx0czspIHtcbiAgICAgICAgICAgIGhzbC5oID0gKGhzbC5oICsgcGFydCkgJSAzNjA7XG4gICAgICAgICAgICByZXQucHVzaChuZXcgVGlueUNvbG9yKGhzbCkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXQ7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIHRha2VuIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL2luZnVzaW9uL2pRdWVyeS14Y29sb3IvYmxvYi9tYXN0ZXIvanF1ZXJ5Lnhjb2xvci5qc1xuICAgICAqL1xuICAgIGNvbXBsZW1lbnQoKSB7XG4gICAgICAgIGNvbnN0IGhzbCA9IHRoaXMudG9Ic2woKTtcbiAgICAgICAgaHNsLmggPSAoaHNsLmggKyAxODApICUgMzYwO1xuICAgICAgICByZXR1cm4gbmV3IFRpbnlDb2xvcihoc2wpO1xuICAgIH1cbiAgICBtb25vY2hyb21hdGljKHJlc3VsdHMgPSA2KSB7XG4gICAgICAgIGNvbnN0IGhzdiA9IHRoaXMudG9Ic3YoKTtcbiAgICAgICAgY29uc3QgaCA9IGhzdi5oO1xuICAgICAgICBjb25zdCBzID0gaHN2LnM7XG4gICAgICAgIGxldCB2ID0gaHN2LnY7XG4gICAgICAgIGNvbnN0IHJlcyA9IFtdO1xuICAgICAgICBjb25zdCBtb2RpZmljYXRpb24gPSAxIC8gcmVzdWx0cztcbiAgICAgICAgd2hpbGUgKHJlc3VsdHMtLSkge1xuICAgICAgICAgICAgcmVzLnB1c2gobmV3IFRpbnlDb2xvcih7IGgsIHMsIHYgfSkpO1xuICAgICAgICAgICAgdiA9ICh2ICsgbW9kaWZpY2F0aW9uKSAlIDE7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlcztcbiAgICB9XG4gICAgc3BsaXRjb21wbGVtZW50KCkge1xuICAgICAgICBjb25zdCBoc2wgPSB0aGlzLnRvSHNsKCk7XG4gICAgICAgIGNvbnN0IGggPSBoc2wuaDtcbiAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgIHRoaXMsXG4gICAgICAgICAgICBuZXcgVGlueUNvbG9yKHsgaDogKGggKyA3MikgJSAzNjAsIHM6IGhzbC5zLCBsOiBoc2wubCB9KSxcbiAgICAgICAgICAgIG5ldyBUaW55Q29sb3IoeyBoOiAoaCArIDIxNikgJSAzNjAsIHM6IGhzbC5zLCBsOiBoc2wubCB9KSxcbiAgICAgICAgXTtcbiAgICB9XG4gICAgdHJpYWQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnBvbHlhZCgzKTtcbiAgICB9XG4gICAgdGV0cmFkKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5wb2x5YWQoNCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEdldCBwb2x5YWQgY29sb3JzLCBsaWtlIChmb3IgMSwgMiwgMywgNCwgNSwgNiwgNywgOCwgZXRjLi4uKVxuICAgICAqIG1vbmFkLCBkeWFkLCB0cmlhZCwgdGV0cmFkLCBwZW50YWQsIGhleGFkLCBoZXB0YWQsIG9jdGFkLCBldGMuLi5cbiAgICAgKi9cbiAgICBwb2x5YWQobikge1xuICAgICAgICBjb25zdCBoc2wgPSB0aGlzLnRvSHNsKCk7XG4gICAgICAgIGNvbnN0IGggPSBoc2wuaDtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW3RoaXNdO1xuICAgICAgICBjb25zdCBpbmNyZW1lbnQgPSAzNjAgLyBuO1xuICAgICAgICBmb3IgKGxldCBpID0gMTsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgcmVzdWx0LnB1c2gobmV3IFRpbnlDb2xvcih7IGg6IChoICsgaSAqIGluY3JlbWVudCkgJSAzNjAsIHM6IGhzbC5zLCBsOiBoc2wubCB9KSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogY29tcGFyZSBjb2xvciB2cyBjdXJyZW50IGNvbG9yXG4gICAgICovXG4gICAgZXF1YWxzKGNvbG9yKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnRvUmdiU3RyaW5nKCkgPT09IG5ldyBUaW55Q29sb3IoY29sb3IpLnRvUmdiU3RyaW5nKCk7XG4gICAgfVxufVxuXG4vLyBSZWFkYWJpbGl0eSBGdW5jdGlvbnNcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gPGh0dHA6Ly93d3cudzMub3JnL1RSLzIwMDgvUkVDLVdDQUcyMC0yMDA4MTIxMS8jY29udHJhc3QtcmF0aW9kZWYgKFdDQUcgVmVyc2lvbiAyKVxuLyoqXG4gKiBBS0EgYGNvbnRyYXN0YFxuICpcbiAqIEFuYWx5emUgdGhlIDIgY29sb3JzIGFuZCByZXR1cm5zIHRoZSBjb2xvciBjb250cmFzdCBkZWZpbmVkIGJ5IChXQ0FHIFZlcnNpb24gMilcbiAqL1xuZnVuY3Rpb24gcmVhZGFiaWxpdHkoY29sb3IxLCBjb2xvcjIpIHtcbiAgICBjb25zdCBjMSA9IG5ldyBUaW55Q29sb3IoY29sb3IxKTtcbiAgICBjb25zdCBjMiA9IG5ldyBUaW55Q29sb3IoY29sb3IyKTtcbiAgICByZXR1cm4gKChNYXRoLm1heChjMS5nZXRMdW1pbmFuY2UoKSwgYzIuZ2V0THVtaW5hbmNlKCkpICsgMC4wNSkgL1xuICAgICAgICAoTWF0aC5taW4oYzEuZ2V0THVtaW5hbmNlKCksIGMyLmdldEx1bWluYW5jZSgpKSArIDAuMDUpKTtcbn1cbi8qKlxuICogRW5zdXJlIHRoYXQgZm9yZWdyb3VuZCBhbmQgYmFja2dyb3VuZCBjb2xvciBjb21iaW5hdGlvbnMgbWVldCBXQ0FHMiBndWlkZWxpbmVzLlxuICogVGhlIHRoaXJkIGFyZ3VtZW50IGlzIGFuIG9iamVjdC5cbiAqICAgICAgdGhlICdsZXZlbCcgcHJvcGVydHkgc3RhdGVzICdBQScgb3IgJ0FBQScgLSBpZiBtaXNzaW5nIG9yIGludmFsaWQsIGl0IGRlZmF1bHRzIHRvICdBQSc7XG4gKiAgICAgIHRoZSAnc2l6ZScgcHJvcGVydHkgc3RhdGVzICdsYXJnZScgb3IgJ3NtYWxsJyAtIGlmIG1pc3Npbmcgb3IgaW52YWxpZCwgaXQgZGVmYXVsdHMgdG8gJ3NtYWxsJy5cbiAqIElmIHRoZSBlbnRpcmUgb2JqZWN0IGlzIGFic2VudCwgaXNSZWFkYWJsZSBkZWZhdWx0cyB0byB7bGV2ZWw6XCJBQVwiLHNpemU6XCJzbWFsbFwifS5cbiAqXG4gKiBFeGFtcGxlXG4gKiBgYGB0c1xuICogbmV3IFRpbnlDb2xvcigpLmlzUmVhZGFibGUoJyMwMDAnLCAnIzExMScpID0+IGZhbHNlXG4gKiBuZXcgVGlueUNvbG9yKCkuaXNSZWFkYWJsZSgnIzAwMCcsICcjMTExJywgeyBsZXZlbDogJ0FBJywgc2l6ZTogJ2xhcmdlJyB9KSA9PiBmYWxzZVxuICogYGBgXG4gKi9cbmZ1bmN0aW9uIGlzUmVhZGFibGUoY29sb3IxLCBjb2xvcjIsIHdjYWcyID0geyBsZXZlbDogJ0FBJywgc2l6ZTogJ3NtYWxsJyB9KSB7XG4gICAgY29uc3QgcmVhZGFiaWxpdHlMZXZlbCA9IHJlYWRhYmlsaXR5KGNvbG9yMSwgY29sb3IyKTtcbiAgICBzd2l0Y2ggKCh3Y2FnMi5sZXZlbCB8fCAnQUEnKSArICh3Y2FnMi5zaXplIHx8ICdzbWFsbCcpKSB7XG4gICAgICAgIGNhc2UgJ0FBc21hbGwnOlxuICAgICAgICBjYXNlICdBQUFsYXJnZSc6XG4gICAgICAgICAgICByZXR1cm4gcmVhZGFiaWxpdHlMZXZlbCA+PSA0LjU7XG4gICAgICAgIGNhc2UgJ0FBbGFyZ2UnOlxuICAgICAgICAgICAgcmV0dXJuIHJlYWRhYmlsaXR5TGV2ZWwgPj0gMztcbiAgICAgICAgY2FzZSAnQUFBc21hbGwnOlxuICAgICAgICAgICAgcmV0dXJuIHJlYWRhYmlsaXR5TGV2ZWwgPj0gNztcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xufVxuLyoqXG4gKiBHaXZlbiBhIGJhc2UgY29sb3IgYW5kIGEgbGlzdCBvZiBwb3NzaWJsZSBmb3JlZ3JvdW5kIG9yIGJhY2tncm91bmRcbiAqIGNvbG9ycyBmb3IgdGhhdCBiYXNlLCByZXR1cm5zIHRoZSBtb3N0IHJlYWRhYmxlIGNvbG9yLlxuICogT3B0aW9uYWxseSByZXR1cm5zIEJsYWNrIG9yIFdoaXRlIGlmIHRoZSBtb3N0IHJlYWRhYmxlIGNvbG9yIGlzIHVucmVhZGFibGUuXG4gKlxuICogQHBhcmFtIGJhc2VDb2xvciAtIHRoZSBiYXNlIGNvbG9yLlxuICogQHBhcmFtIGNvbG9yTGlzdCAtIGFycmF5IG9mIGNvbG9ycyB0byBwaWNrIHRoZSBtb3N0IHJlYWRhYmxlIG9uZSBmcm9tLlxuICogQHBhcmFtIGFyZ3MgLSBhbmQgb2JqZWN0IHdpdGggZXh0cmEgYXJndW1lbnRzXG4gKlxuICogRXhhbXBsZVxuICogYGBgdHNcbiAqIG5ldyBUaW55Q29sb3IoKS5tb3N0UmVhZGFibGUoJyMxMjMnLCBbJyMxMjRcIiwgXCIjMTI1J10sIHsgaW5jbHVkZUZhbGxiYWNrQ29sb3JzOiBmYWxzZSB9KS50b0hleFN0cmluZygpOyAvLyBcIiMxMTIyNTVcIlxuICogbmV3IFRpbnlDb2xvcigpLm1vc3RSZWFkYWJsZSgnIzEyMycsIFsnIzEyNFwiLCBcIiMxMjUnXSx7IGluY2x1ZGVGYWxsYmFja0NvbG9yczogdHJ1ZSB9KS50b0hleFN0cmluZygpOyAgLy8gXCIjZmZmZmZmXCJcbiAqIG5ldyBUaW55Q29sb3IoKS5tb3N0UmVhZGFibGUoJyNhODAxNWEnLCBbXCIjZmFmM2YzXCJdLCB7IGluY2x1ZGVGYWxsYmFja0NvbG9yczp0cnVlLCBsZXZlbDogJ0FBQScsIHNpemU6ICdsYXJnZScgfSkudG9IZXhTdHJpbmcoKTsgLy8gXCIjZmFmM2YzXCJcbiAqIG5ldyBUaW55Q29sb3IoKS5tb3N0UmVhZGFibGUoJyNhODAxNWEnLCBbXCIjZmFmM2YzXCJdLCB7IGluY2x1ZGVGYWxsYmFja0NvbG9yczp0cnVlLCBsZXZlbDogJ0FBQScsIHNpemU6ICdzbWFsbCcgfSkudG9IZXhTdHJpbmcoKTsgLy8gXCIjZmZmZmZmXCJcbiAqIGBgYFxuICovXG5mdW5jdGlvbiBtb3N0UmVhZGFibGUoYmFzZUNvbG9yLCBjb2xvckxpc3QsIGFyZ3MgPSB7IGluY2x1ZGVGYWxsYmFja0NvbG9yczogZmFsc2UsIGxldmVsOiAnQUEnLCBzaXplOiAnc21hbGwnIH0pIHtcbiAgICBsZXQgYmVzdENvbG9yID0gbnVsbDtcbiAgICBsZXQgYmVzdFNjb3JlID0gMDtcbiAgICBjb25zdCBpbmNsdWRlRmFsbGJhY2tDb2xvcnMgPSBhcmdzLmluY2x1ZGVGYWxsYmFja0NvbG9ycztcbiAgICBjb25zdCBsZXZlbCA9IGFyZ3MubGV2ZWw7XG4gICAgY29uc3Qgc2l6ZSA9IGFyZ3Muc2l6ZTtcbiAgICBmb3IgKGNvbnN0IGNvbG9yIG9mIGNvbG9yTGlzdCkge1xuICAgICAgICBjb25zdCBzY29yZSA9IHJlYWRhYmlsaXR5KGJhc2VDb2xvciwgY29sb3IpO1xuICAgICAgICBpZiAoc2NvcmUgPiBiZXN0U2NvcmUpIHtcbiAgICAgICAgICAgIGJlc3RTY29yZSA9IHNjb3JlO1xuICAgICAgICAgICAgYmVzdENvbG9yID0gbmV3IFRpbnlDb2xvcihjb2xvcik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKGlzUmVhZGFibGUoYmFzZUNvbG9yLCBiZXN0Q29sb3IsIHsgbGV2ZWwsIHNpemUgfSkgfHwgIWluY2x1ZGVGYWxsYmFja0NvbG9ycykge1xuICAgICAgICByZXR1cm4gYmVzdENvbG9yO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgYXJncy5pbmNsdWRlRmFsbGJhY2tDb2xvcnMgPSBmYWxzZTtcbiAgICAgICAgcmV0dXJuIG1vc3RSZWFkYWJsZShiYXNlQ29sb3IsIFsnI2ZmZicsICcjMDAwJ10sIGFyZ3MpO1xuICAgIH1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBjb2xvciByZXByZXNlbnRlZCBhcyBhIE1pY3Jvc29mdCBmaWx0ZXIgZm9yIHVzZSBpbiBvbGQgdmVyc2lvbnMgb2YgSUUuXG4gKi9cbmZ1bmN0aW9uIHRvTXNGaWx0ZXIoZmlyc3RDb2xvciwgc2Vjb25kQ29sb3IpIHtcbiAgICBjb25zdCBjb2xvciA9IG5ldyBUaW55Q29sb3IoZmlyc3RDb2xvcik7XG4gICAgY29uc3QgaGV4OFN0cmluZyA9ICcjJyArIHJnYmFUb0FyZ2JIZXgoY29sb3IuciwgY29sb3IuZywgY29sb3IuYiwgY29sb3IuYSk7XG4gICAgbGV0IHNlY29uZEhleDhTdHJpbmcgPSBoZXg4U3RyaW5nO1xuICAgIGNvbnN0IGdyYWRpZW50VHlwZSA9IGNvbG9yLmdyYWRpZW50VHlwZSA/ICdHcmFkaWVudFR5cGUgPSAxLCAnIDogJyc7XG4gICAgaWYgKHNlY29uZENvbG9yKSB7XG4gICAgICAgIGNvbnN0IHMgPSBuZXcgVGlueUNvbG9yKHNlY29uZENvbG9yKTtcbiAgICAgICAgc2Vjb25kSGV4OFN0cmluZyA9ICcjJyArIHJnYmFUb0FyZ2JIZXgocy5yLCBzLmcsIHMuYiwgcy5hKTtcbiAgICB9XG4gICAgcmV0dXJuIGBwcm9naWQ6RFhJbWFnZVRyYW5zZm9ybS5NaWNyb3NvZnQuZ3JhZGllbnQoJHtncmFkaWVudFR5cGV9c3RhcnRDb2xvcnN0cj0ke2hleDhTdHJpbmd9LGVuZENvbG9yc3RyPSR7c2Vjb25kSGV4OFN0cmluZ30pYDtcbn1cblxuLyoqXG4gKiBJZiBpbnB1dCBpcyBhbiBvYmplY3QsIGZvcmNlIDEgaW50byBcIjEuMFwiIHRvIGhhbmRsZSByYXRpb3MgcHJvcGVybHlcbiAqIFN0cmluZyBpbnB1dCByZXF1aXJlcyBcIjEuMFwiIGFzIGlucHV0LCBzbyAxIHdpbGwgYmUgdHJlYXRlZCBhcyAxXG4gKi9cbmZ1bmN0aW9uIGZyb21SYXRpbyhyYXRpbywgb3B0cykge1xuICAgIGNvbnN0IG5ld0NvbG9yID0ge1xuICAgICAgICByOiBjb252ZXJ0VG9QZXJjZW50YWdlKHJhdGlvLnIpLFxuICAgICAgICBnOiBjb252ZXJ0VG9QZXJjZW50YWdlKHJhdGlvLmcpLFxuICAgICAgICBiOiBjb252ZXJ0VG9QZXJjZW50YWdlKHJhdGlvLmIpLFxuICAgIH07XG4gICAgaWYgKHJhdGlvLmEgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBuZXdDb2xvci5hID0gK3JhdGlvLmE7XG4gICAgfVxuICAgIHJldHVybiBuZXcgVGlueUNvbG9yKG5ld0NvbG9yLCBvcHRzKTtcbn1cbi8qKiBvbGQgcmFuZG9tIGZ1bmN0aW9uICovXG5mdW5jdGlvbiBsZWdhY3lSYW5kb20oKSB7XG4gICAgcmV0dXJuIG5ldyBUaW55Q29sb3Ioe1xuICAgICAgICByOiBNYXRoLnJhbmRvbSgpLFxuICAgICAgICBnOiBNYXRoLnJhbmRvbSgpLFxuICAgICAgICBiOiBNYXRoLnJhbmRvbSgpLFxuICAgIH0pO1xufVxuXG4vLyByYW5kb21Db2xvciBieSBEYXZpZCBNZXJmaWVsZCB1bmRlciB0aGUgQ0MwIGxpY2Vuc2VcbmZ1bmN0aW9uIHJhbmRvbShvcHRpb25zID0ge30pIHtcbiAgICAvLyBDaGVjayBpZiB3ZSBuZWVkIHRvIGdlbmVyYXRlIG11bHRpcGxlIGNvbG9yc1xuICAgIGlmIChvcHRpb25zLmNvdW50ICE9PSB1bmRlZmluZWQgJiYgb3B0aW9ucy5jb3VudCAhPT0gbnVsbCkge1xuICAgICAgICBjb25zdCB0b3RhbENvbG9ycyA9IG9wdGlvbnMuY291bnQ7XG4gICAgICAgIGNvbnN0IGNvbG9ycyA9IFtdO1xuICAgICAgICBvcHRpb25zLmNvdW50ID0gdW5kZWZpbmVkO1xuICAgICAgICB3aGlsZSAodG90YWxDb2xvcnMgPiBjb2xvcnMubGVuZ3RoKSB7XG4gICAgICAgICAgICAvLyBTaW5jZSB3ZSdyZSBnZW5lcmF0aW5nIG11bHRpcGxlIGNvbG9ycyxcbiAgICAgICAgICAgIC8vIGluY3JlbWVtZW50IHRoZSBzZWVkLiBPdGhlcndpc2Ugd2UnZCBqdXN0XG4gICAgICAgICAgICAvLyBnZW5lcmF0ZSB0aGUgc2FtZSBjb2xvciBlYWNoIHRpbWUuLi5cbiAgICAgICAgICAgIG9wdGlvbnMuY291bnQgPSBudWxsO1xuICAgICAgICAgICAgaWYgKG9wdGlvbnMuc2VlZCkge1xuICAgICAgICAgICAgICAgIG9wdGlvbnMuc2VlZCArPSAxO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29sb3JzLnB1c2gocmFuZG9tKG9wdGlvbnMpKTtcbiAgICAgICAgfVxuICAgICAgICBvcHRpb25zLmNvdW50ID0gdG90YWxDb2xvcnM7XG4gICAgICAgIHJldHVybiBjb2xvcnM7XG4gICAgfVxuICAgIC8vIEZpcnN0IHdlIHBpY2sgYSBodWUgKEgpXG4gICAgY29uc3QgaCA9IHBpY2tIdWUob3B0aW9ucy5odWUsIG9wdGlvbnMuc2VlZCk7XG4gICAgLy8gVGhlbiB1c2UgSCB0byBkZXRlcm1pbmUgc2F0dXJhdGlvbiAoUylcbiAgICBjb25zdCBzID0gcGlja1NhdHVyYXRpb24oaCwgb3B0aW9ucyk7XG4gICAgLy8gVGhlbiB1c2UgUyBhbmQgSCB0byBkZXRlcm1pbmUgYnJpZ2h0bmVzcyAoQikuXG4gICAgY29uc3QgdiA9IHBpY2tCcmlnaHRuZXNzKGgsIHMsIG9wdGlvbnMpO1xuICAgIGNvbnN0IHJlcyA9IHsgaCwgcywgdiB9O1xuICAgIGlmIChvcHRpb25zLmFscGhhICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmVzLmEgPSBvcHRpb25zLmFscGhhO1xuICAgIH1cbiAgICAvLyBUaGVuIHdlIHJldHVybiB0aGUgSFNCIGNvbG9yIGluIHRoZSBkZXNpcmVkIGZvcm1hdFxuICAgIHJldHVybiBuZXcgVGlueUNvbG9yKHJlcyk7XG59XG5mdW5jdGlvbiBwaWNrSHVlKGh1ZSwgc2VlZCkge1xuICAgIGNvbnN0IGh1ZVJhbmdlID0gZ2V0SHVlUmFuZ2UoaHVlKTtcbiAgICBsZXQgcmVzID0gcmFuZG9tV2l0aGluKGh1ZVJhbmdlLCBzZWVkKTtcbiAgICAvLyBJbnN0ZWFkIG9mIHN0b3JpbmcgcmVkIGFzIHR3byBzZXBlcmF0ZSByYW5nZXMsXG4gICAgLy8gd2UgZ3JvdXAgdGhlbSwgdXNpbmcgbmVnYXRpdmUgbnVtYmVyc1xuICAgIGlmIChyZXMgPCAwKSB7XG4gICAgICAgIHJlcyA9IDM2MCArIHJlcztcbiAgICB9XG4gICAgcmV0dXJuIHJlcztcbn1cbmZ1bmN0aW9uIHBpY2tTYXR1cmF0aW9uKGh1ZSwgb3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zLmh1ZSA9PT0gJ21vbm9jaHJvbWUnKSB7XG4gICAgICAgIHJldHVybiAwO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5sdW1pbm9zaXR5ID09PSAncmFuZG9tJykge1xuICAgICAgICByZXR1cm4gcmFuZG9tV2l0aGluKFswLCAxMDBdLCBvcHRpb25zLnNlZWQpO1xuICAgIH1cbiAgICBjb25zdCBzYXR1cmF0aW9uUmFuZ2UgPSBnZXRDb2xvckluZm8oaHVlKS5zYXR1cmF0aW9uUmFuZ2U7XG4gICAgbGV0IHNNaW4gPSBzYXR1cmF0aW9uUmFuZ2VbMF07XG4gICAgbGV0IHNNYXggPSBzYXR1cmF0aW9uUmFuZ2VbMV07XG4gICAgc3dpdGNoIChvcHRpb25zLmx1bWlub3NpdHkpIHtcbiAgICAgICAgY2FzZSAnYnJpZ2h0JzpcbiAgICAgICAgICAgIHNNaW4gPSA1NTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdkYXJrJzpcbiAgICAgICAgICAgIHNNaW4gPSBzTWF4IC0gMTA7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnbGlnaHQnOlxuICAgICAgICAgICAgc01heCA9IDU1O1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgfVxuICAgIHJldHVybiByYW5kb21XaXRoaW4oW3NNaW4sIHNNYXhdLCBvcHRpb25zLnNlZWQpO1xufVxuZnVuY3Rpb24gcGlja0JyaWdodG5lc3MoSCwgUywgb3B0aW9ucykge1xuICAgIGxldCBiTWluID0gZ2V0TWluaW11bUJyaWdodG5lc3MoSCwgUyk7XG4gICAgbGV0IGJNYXggPSAxMDA7XG4gICAgc3dpdGNoIChvcHRpb25zLmx1bWlub3NpdHkpIHtcbiAgICAgICAgY2FzZSAnZGFyayc6XG4gICAgICAgICAgICBiTWF4ID0gYk1pbiArIDIwO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ2xpZ2h0JzpcbiAgICAgICAgICAgIGJNaW4gPSAoYk1heCArIGJNaW4pIC8gMjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdyYW5kb20nOlxuICAgICAgICAgICAgYk1pbiA9IDA7XG4gICAgICAgICAgICBiTWF4ID0gMTAwO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgfVxuICAgIHJldHVybiByYW5kb21XaXRoaW4oW2JNaW4sIGJNYXhdLCBvcHRpb25zLnNlZWQpO1xufVxuZnVuY3Rpb24gZ2V0TWluaW11bUJyaWdodG5lc3MoSCwgUykge1xuICAgIGNvbnN0IGxvd2VyQm91bmRzID0gZ2V0Q29sb3JJbmZvKEgpLmxvd2VyQm91bmRzO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbG93ZXJCb3VuZHMubGVuZ3RoIC0gMTsgaSsrKSB7XG4gICAgICAgIGNvbnN0IHMxID0gbG93ZXJCb3VuZHNbaV1bMF07XG4gICAgICAgIGNvbnN0IHYxID0gbG93ZXJCb3VuZHNbaV1bMV07XG4gICAgICAgIGNvbnN0IHMyID0gbG93ZXJCb3VuZHNbaSArIDFdWzBdO1xuICAgICAgICBjb25zdCB2MiA9IGxvd2VyQm91bmRzW2kgKyAxXVsxXTtcbiAgICAgICAgaWYgKFMgPj0gczEgJiYgUyA8PSBzMikge1xuICAgICAgICAgICAgY29uc3QgbSA9ICh2MiAtIHYxKSAvIChzMiAtIHMxKTtcbiAgICAgICAgICAgIGNvbnN0IGIgPSB2MSAtIG0gKiBzMTtcbiAgICAgICAgICAgIHJldHVybiBtICogUyArIGI7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIDA7XG59XG5mdW5jdGlvbiBnZXRIdWVSYW5nZShjb2xvcklucHV0KSB7XG4gICAgY29uc3QgbnVtID0gcGFyc2VJbnQoY29sb3JJbnB1dCwgMTApO1xuICAgIGlmICghTnVtYmVyLmlzTmFOKG51bSkgJiYgbnVtIDwgMzYwICYmIG51bSA+IDApIHtcbiAgICAgICAgcmV0dXJuIFtudW0sIG51bV07XG4gICAgfVxuICAgIGlmICh0eXBlb2YgY29sb3JJbnB1dCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgY29uc3QgbmFtZWRDb2xvciA9IGJvdW5kcy5maW5kKG4gPT4gbi5uYW1lID09PSBjb2xvcklucHV0KTtcbiAgICAgICAgaWYgKG5hbWVkQ29sb3IpIHtcbiAgICAgICAgICAgIGNvbnN0IGNvbG9yID0gZGVmaW5lQ29sb3IobmFtZWRDb2xvcik7XG4gICAgICAgICAgICBpZiAoY29sb3IuaHVlUmFuZ2UpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gY29sb3IuaHVlUmFuZ2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcGFyc2VkID0gbmV3IFRpbnlDb2xvcihjb2xvcklucHV0KTtcbiAgICAgICAgaWYgKHBhcnNlZC5pc1ZhbGlkKSB7XG4gICAgICAgICAgICBjb25zdCBodWUgPSBwYXJzZWQudG9Ic3YoKS5oO1xuICAgICAgICAgICAgcmV0dXJuIFtodWUsIGh1ZV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIFswLCAzNjBdO1xufVxuZnVuY3Rpb24gZ2V0Q29sb3JJbmZvKGh1ZSkge1xuICAgIC8vIE1hcHMgcmVkIGNvbG9ycyB0byBtYWtlIHBpY2tpbmcgaHVlIGVhc2llclxuICAgIGlmIChodWUgPj0gMzM0ICYmIGh1ZSA8PSAzNjApIHtcbiAgICAgICAgaHVlIC09IDM2MDtcbiAgICB9XG4gICAgZm9yIChjb25zdCBib3VuZCBvZiBib3VuZHMpIHtcbiAgICAgICAgY29uc3QgY29sb3IgPSBkZWZpbmVDb2xvcihib3VuZCk7XG4gICAgICAgIGlmIChjb2xvci5odWVSYW5nZSAmJiBodWUgPj0gY29sb3IuaHVlUmFuZ2VbMF0gJiYgaHVlIDw9IGNvbG9yLmh1ZVJhbmdlWzFdKSB7XG4gICAgICAgICAgICByZXR1cm4gY29sb3I7XG4gICAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgRXJyb3IoJ0NvbG9yIG5vdCBmb3VuZCcpO1xufVxuZnVuY3Rpb24gcmFuZG9tV2l0aGluKHJhbmdlLCBzZWVkKSB7XG4gICAgaWYgKHNlZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm4gTWF0aC5mbG9vcihyYW5nZVswXSArIE1hdGgucmFuZG9tKCkgKiAocmFuZ2VbMV0gKyAxIC0gcmFuZ2VbMF0pKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIFNlZWRlZCByYW5kb20gYWxnb3JpdGhtIGZyb20gaHR0cDovL2luZGllZ2Ftci5jb20vZ2VuZXJhdGUtcmVwZWF0YWJsZS1yYW5kb20tbnVtYmVycy1pbi1qcy9cbiAgICAgICAgY29uc3QgbWF4ID0gcmFuZ2VbMV0gfHwgMTtcbiAgICAgICAgY29uc3QgbWluID0gcmFuZ2VbMF0gfHwgMDtcbiAgICAgICAgc2VlZCA9IChzZWVkICogOTMwMSArIDQ5Mjk3KSAlIDIzMzI4MDtcbiAgICAgICAgY29uc3Qgcm5kID0gc2VlZCAvIDIzMzI4MC4wO1xuICAgICAgICByZXR1cm4gTWF0aC5mbG9vcihtaW4gKyBybmQgKiAobWF4IC0gbWluKSk7XG4gICAgfVxufVxuZnVuY3Rpb24gZGVmaW5lQ29sb3IoYm91bmQpIHtcbiAgICBjb25zdCBzTWluID0gYm91bmQubG93ZXJCb3VuZHNbMF1bMF07XG4gICAgY29uc3Qgc01heCA9IGJvdW5kLmxvd2VyQm91bmRzW2JvdW5kLmxvd2VyQm91bmRzLmxlbmd0aCAtIDFdWzBdO1xuICAgIGNvbnN0IGJNaW4gPSBib3VuZC5sb3dlckJvdW5kc1tib3VuZC5sb3dlckJvdW5kcy5sZW5ndGggLSAxXVsxXTtcbiAgICBjb25zdCBiTWF4ID0gYm91bmQubG93ZXJCb3VuZHNbMF1bMV07XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbmFtZTogYm91bmQubmFtZSxcbiAgICAgICAgaHVlUmFuZ2U6IGJvdW5kLmh1ZVJhbmdlLFxuICAgICAgICBsb3dlckJvdW5kczogYm91bmQubG93ZXJCb3VuZHMsXG4gICAgICAgIHNhdHVyYXRpb25SYW5nZTogW3NNaW4sIHNNYXhdLFxuICAgICAgICBicmlnaHRuZXNzUmFuZ2U6IFtiTWluLCBiTWF4XSxcbiAgICB9O1xufVxuLyoqXG4gKiBAaGlkZGVuXG4gKi9cbmNvbnN0IGJvdW5kcyA9IFtcbiAgICB7XG4gICAgICAgIG5hbWU6ICdtb25vY2hyb21lJyxcbiAgICAgICAgaHVlUmFuZ2U6IG51bGwsXG4gICAgICAgIGxvd2VyQm91bmRzOiBbWzAsIDBdLCBbMTAwLCAwXV0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6ICdyZWQnLFxuICAgICAgICBodWVSYW5nZTogWy0yNiwgMThdLFxuICAgICAgICBsb3dlckJvdW5kczogW1xuICAgICAgICAgICAgWzIwLCAxMDBdLFxuICAgICAgICAgICAgWzMwLCA5Ml0sXG4gICAgICAgICAgICBbNDAsIDg5XSxcbiAgICAgICAgICAgIFs1MCwgODVdLFxuICAgICAgICAgICAgWzYwLCA3OF0sXG4gICAgICAgICAgICBbNzAsIDcwXSxcbiAgICAgICAgICAgIFs4MCwgNjBdLFxuICAgICAgICAgICAgWzkwLCA1NV0sXG4gICAgICAgICAgICBbMTAwLCA1MF0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6ICdvcmFuZ2UnLFxuICAgICAgICBodWVSYW5nZTogWzE5LCA0Nl0sXG4gICAgICAgIGxvd2VyQm91bmRzOiBbWzIwLCAxMDBdLCBbMzAsIDkzXSwgWzQwLCA4OF0sIFs1MCwgODZdLCBbNjAsIDg1XSwgWzcwLCA3MF0sIFsxMDAsIDcwXV0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6ICd5ZWxsb3cnLFxuICAgICAgICBodWVSYW5nZTogWzQ3LCA2Ml0sXG4gICAgICAgIGxvd2VyQm91bmRzOiBbWzI1LCAxMDBdLCBbNDAsIDk0XSwgWzUwLCA4OV0sIFs2MCwgODZdLCBbNzAsIDg0XSwgWzgwLCA4Ml0sIFs5MCwgODBdLCBbMTAwLCA3NV1dLFxuICAgIH0sXG4gICAge1xuICAgICAgICBuYW1lOiAnZ3JlZW4nLFxuICAgICAgICBodWVSYW5nZTogWzYzLCAxNzhdLFxuICAgICAgICBsb3dlckJvdW5kczogW1szMCwgMTAwXSwgWzQwLCA5MF0sIFs1MCwgODVdLCBbNjAsIDgxXSwgWzcwLCA3NF0sIFs4MCwgNjRdLCBbOTAsIDUwXSwgWzEwMCwgNDBdXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgbmFtZTogJ2JsdWUnLFxuICAgICAgICBodWVSYW5nZTogWzE3OSwgMjU3XSxcbiAgICAgICAgbG93ZXJCb3VuZHM6IFtcbiAgICAgICAgICAgIFsyMCwgMTAwXSxcbiAgICAgICAgICAgIFszMCwgODZdLFxuICAgICAgICAgICAgWzQwLCA4MF0sXG4gICAgICAgICAgICBbNTAsIDc0XSxcbiAgICAgICAgICAgIFs2MCwgNjBdLFxuICAgICAgICAgICAgWzcwLCA1Ml0sXG4gICAgICAgICAgICBbODAsIDQ0XSxcbiAgICAgICAgICAgIFs5MCwgMzldLFxuICAgICAgICAgICAgWzEwMCwgMzVdLFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBuYW1lOiAncHVycGxlJyxcbiAgICAgICAgaHVlUmFuZ2U6IFsyNTgsIDI4Ml0sXG4gICAgICAgIGxvd2VyQm91bmRzOiBbXG4gICAgICAgICAgICBbMjAsIDEwMF0sXG4gICAgICAgICAgICBbMzAsIDg3XSxcbiAgICAgICAgICAgIFs0MCwgNzldLFxuICAgICAgICAgICAgWzUwLCA3MF0sXG4gICAgICAgICAgICBbNjAsIDY1XSxcbiAgICAgICAgICAgIFs3MCwgNTldLFxuICAgICAgICAgICAgWzgwLCA1Ml0sXG4gICAgICAgICAgICBbOTAsIDQ1XSxcbiAgICAgICAgICAgIFsxMDAsIDQyXSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgbmFtZTogJ3BpbmsnLFxuICAgICAgICBodWVSYW5nZTogWzI4MywgMzM0XSxcbiAgICAgICAgbG93ZXJCb3VuZHM6IFtbMjAsIDEwMF0sIFszMCwgOTBdLCBbNDAsIDg2XSwgWzYwLCA4NF0sIFs4MCwgODBdLCBbOTAsIDc1XSwgWzEwMCwgNzNdXSxcbiAgICB9LFxuXTtcblxuZXhwb3J0IHsgVGlueUNvbG9yLCBuYW1lcywgcmVhZGFiaWxpdHksIGlzUmVhZGFibGUsIG1vc3RSZWFkYWJsZSwgdG9Nc0ZpbHRlciwgZnJvbVJhdGlvLCBsZWdhY3lSYW5kb20sIGlucHV0VG9SR0IsIHN0cmluZ0lucHV0VG9PYmplY3QsIGlzVmFsaWRDU1NVbml0LCByYW5kb20sIGJvdW5kcyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dGlueWNvbG9yLmVzMjAxNS5qcy5tYXBcbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgeyBUaW55Q29sb3IgfSBmcm9tICdAY3RybC90aW55Y29sb3InXG5pbXBvcnQgeyBxdWVyeVBhZ2UgfSBmcm9tICcuL3NlYXJjaCdcbmltcG9ydCB7IGdldFN0eWxlcywgY2FtZWxUb0Rhc2gsIGlzT2ZmQm91bmRzLCBkZWVwRWxlbWVudEZyb21Qb2ludCB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmNvbnN0IHN0YXRlID0ge1xuICBhY3RpdmU6IHtcbiAgICB0aXA6ICBudWxsLFxuICAgIHRhcmdldDogbnVsbCxcbiAgfSxcbiAgdGlwczogbmV3IE1hcCgpLFxufVxuXG5jb25zdCBzZXJ2aWNlcyA9IHt9XG5cbmV4cG9ydCBmdW5jdGlvbiBNZXRhVGlwKHtzZWxlY3R9KSB7XG4gIHNlcnZpY2VzLnNlbGVjdG9ycyA9IHtzZWxlY3R9XG5cbiAgJCgnYm9keScpLm9uKCdtb3VzZW1vdmUnLCBtb3VzZU1vdmUpXG4gICQoJ2JvZHknKS5vbignY2xpY2snLCB0b2dnbGVQaW5uZWQpXG5cbiAgaG90a2V5cygnZXNjJywgXyA9PiByZW1vdmVBbGwoKSlcblxuICByZXN0b3JlUGlubmVkVGlwcygpXG5cbiAgcmV0dXJuICgpID0+IHtcbiAgICAkKCdib2R5Jykub2ZmKCdtb3VzZW1vdmUnLCBtb3VzZU1vdmUpXG4gICAgJCgnYm9keScpLm9mZignY2xpY2snLCB0b2dnbGVQaW5uZWQpXG4gICAgaG90a2V5cy51bmJpbmQoJ2VzYycpXG4gICAgaGlkZUFsbCgpXG4gIH1cbn1cblxuY29uc3QgbW91c2VNb3ZlID0gZSA9PiB7XG4gIGNvbnN0IHRhcmdldCA9IGRlZXBFbGVtZW50RnJvbVBvaW50KGUuY2xpZW50WCwgZS5jbGllbnRZKVxuXG4gIGlmIChpc09mZkJvdW5kcyh0YXJnZXQpIHx8IHRhcmdldC5ub2RlTmFtZSA9PT0gJ1ZJU0JVRy1NRVRBVElQJyB8fCB0YXJnZXQuaGFzQXR0cmlidXRlKCdkYXRhLW1ldGF0aXAnKSkgeyAvLyBha2E6IG1vdXNlIG91dFxuICAgIGlmIChzdGF0ZS5hY3RpdmUudGlwKSB7XG4gICAgICB3aXBlKHtcbiAgICAgICAgdGlwOiBzdGF0ZS5hY3RpdmUudGlwLFxuICAgICAgICBlOiB7dGFyZ2V0OiBzdGF0ZS5hY3RpdmUudGFyZ2V0fSxcbiAgICAgIH0pXG4gICAgICBjbGVhckFjdGl2ZSgpXG4gICAgfVxuICAgIHJldHVyblxuICB9XG5cbiAgdG9nZ2xlVGFyZ2V0Q3Vyc29yKGUuYWx0S2V5LCB0YXJnZXQpXG5cbiAgc2hvd1RpcCh0YXJnZXQsIGUpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzaG93VGlwKHRhcmdldCwgZSkge1xuICBpZiAoIXN0YXRlLmFjdGl2ZS50aXApIHsgLy8gY3JlYXRlXG4gICAgY29uc3QgdGlwID0gcmVuZGVyKHRhcmdldClcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHRpcClcblxuICAgIHBvc2l0aW9uVGlwKHRpcCwgZSlcbiAgICBvYnNlcnZlKHt0aXAsIHRhcmdldH0pXG5cbiAgICBzdGF0ZS5hY3RpdmUudGlwICAgID0gdGlwXG4gICAgc3RhdGUuYWN0aXZlLnRhcmdldCA9IHRhcmdldFxuICB9XG4gIGVsc2UgaWYgKHRhcmdldCA9PSBzdGF0ZS5hY3RpdmUudGFyZ2V0KSB7IC8vIHVwZGF0ZSBwb3NpdGlvblxuICAgIC8vIHVwZGF0ZSBwb3NpdGlvblxuICAgIHBvc2l0aW9uVGlwKHN0YXRlLmFjdGl2ZS50aXAsIGUpXG4gIH1cbiAgZWxzZSB7IC8vIHVwZGF0ZSBjb250ZW50XG4gICAgcmVuZGVyKHRhcmdldCwgc3RhdGUuYWN0aXZlLnRpcClcbiAgICBzdGF0ZS5hY3RpdmUudGFyZ2V0ID0gdGFyZ2V0XG4gICAgcG9zaXRpb25UaXAoc3RhdGUuYWN0aXZlLnRpcCwgZSlcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcG9zaXRpb25UaXAodGlwLCBlKSB7XG4gIGNvbnN0IHsgbm9ydGgsIHdlc3QgfSA9IG1vdXNlX3F1YWRyYW50KGUpXG4gIGNvbnN0IHsgbGVmdCwgdG9wIH0gICA9IHRpcF9wb3NpdGlvbih0aXAsIGUsIG5vcnRoLCB3ZXN0KVxuXG4gIHRpcC5zdHlsZS5sZWZ0ICA9IGxlZnRcbiAgdGlwLnN0eWxlLnRvcCAgID0gdG9wXG5cbiAgdGlwLnN0eWxlLnNldFByb3BlcnR5KCctLWFycm93Jywgbm9ydGhcbiAgICA/ICd2YXIoLS1hcnJvdy11cCknXG4gICAgOiAndmFyKC0tYXJyb3ctZG93biknKVxuXG4gIHRpcC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1zaGFkb3ctZGlyZWN0aW9uJywgbm9ydGhcbiAgICA/ICd2YXIoLS1zaGFkb3ctdXApJ1xuICAgIDogJ3ZhcigtLXNoYWRvdy1kb3duKScpXG5cbiAgdGlwLnN0eWxlLnNldFByb3BlcnR5KCctLWFycm93LXRvcCcsICFub3J0aFxuICAgID8gJy03cHgnXG4gICAgOiAnY2FsYygxMDAlIC0gMXB4KScpXG5cbiAgdGlwLnN0eWxlLnNldFByb3BlcnR5KCctLWFycm93LWxlZnQnLCB3ZXN0XG4gICAgPyAnY2FsYygxMDAlIC0gMTVweCAtIDE1cHgpJ1xuICAgIDogJzE1cHgnKVxufVxuXG5jb25zdCByZXN0b3JlUGlubmVkVGlwcyA9ICgpID0+IHtcbiAgc3RhdGUudGlwcy5mb3JFYWNoKCh7dGlwfSwgdGFyZ2V0KSA9PiB7XG4gICAgdGlwLnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snXG4gICAgcmVuZGVyKHRhcmdldCwgdGlwKVxuICAgIG9ic2VydmUoe3RpcCwgdGFyZ2V0fSlcbiAgfSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGhpZGVBbGwoKSB7XG4gIHN0YXRlLnRpcHMuZm9yRWFjaCgoe3RpcH0sIHRhcmdldCkgPT5cbiAgICB0aXAuc3R5bGUuZGlzcGxheSA9ICdub25lJylcblxuICBpZiAoc3RhdGUuYWN0aXZlLnRpcCkge1xuICAgIHN0YXRlLmFjdGl2ZS50aXAucmVtb3ZlKClcbiAgICBjbGVhckFjdGl2ZSgpXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHJlbW92ZUFsbCgpIHtcbiAgc3RhdGUudGlwcy5mb3JFYWNoKCh7dGlwfSwgdGFyZ2V0KSA9PiB7XG4gICAgdGlwLnJlbW92ZSgpXG4gICAgdW5vYnNlcnZlKHt0aXAsIHRhcmdldH0pXG4gIH0pXG5cbiAgJCgnW2RhdGEtbWV0YXRpcF0nKS5hdHRyKCdkYXRhLW1ldGF0aXAnLCBudWxsKVxuXG4gIHN0YXRlLnRpcHMuY2xlYXIoKVxufVxuXG5jb25zdCByZW5kZXIgPSAoZWwsIHRpcCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3Zpc2J1Zy1tZXRhdGlwJykpID0+IHtcbiAgY29uc3QgeyB3aWR0aCwgaGVpZ2h0IH0gPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKVxuICBjb25zdCBzdHlsZXMgPSBnZXRTdHlsZXMoZWwpXG4gICAgLm1hcChzdHlsZSA9PiBPYmplY3QuYXNzaWduKHN0eWxlLCB7XG4gICAgICBwcm9wOiBjYW1lbFRvRGFzaChzdHlsZS5wcm9wKVxuICAgIH0pKVxuICAgIC5maWx0ZXIoc3R5bGUgPT5cbiAgICAgIHN0eWxlLnByb3AuaW5jbHVkZXMoJ2ZvbnQtZmFtaWx5JylcbiAgICAgICAgPyBlbC5tYXRjaGVzKCdoMSxoMixoMyxoNCxoNSxoNixwLGEsZGF0ZSxjYXB0aW9uLGJ1dHRvbixmaWdjYXB0aW9uLG5hdixoZWFkZXIsZm9vdGVyJylcbiAgICAgICAgOiB0cnVlXG4gICAgKVxuICAgIC5tYXAoc3R5bGUgPT4ge1xuICAgICAgaWYgKHN0eWxlLnByb3AuaW5jbHVkZXMoJ2NvbG9yJykgfHwgc3R5bGUucHJvcC5pbmNsdWRlcygnQ29sb3InKSB8fCBzdHlsZS5wcm9wLmluY2x1ZGVzKCdmaWxsJykgfHwgc3R5bGUucHJvcC5pbmNsdWRlcygnc3Ryb2tlJykpXG4gICAgICAgIHN0eWxlLnZhbHVlID0gYDxzcGFuIGNvbG9yIHN0eWxlPVwiYmFja2dyb3VuZC1jb2xvcjoke3N0eWxlLnZhbHVlfTtcIj48L3NwYW4+JHtuZXcgVGlueUNvbG9yKHN0eWxlLnZhbHVlKS50b0hzbFN0cmluZygpfWBcblxuICAgICAgaWYgKHN0eWxlLnByb3AuaW5jbHVkZXMoJ2ZvbnQtZmFtaWx5JykgJiYgc3R5bGUudmFsdWUubGVuZ3RoID4gMjUpXG4gICAgICAgIHN0eWxlLnZhbHVlID0gc3R5bGUudmFsdWUuc2xpY2UoMCwyNSkgKyAnLi4uJ1xuXG4gICAgICBpZiAoc3R5bGUucHJvcC5pbmNsdWRlcygnZ3JpZC10ZW1wbGF0ZS1hcmVhcycpKVxuICAgICAgICBzdHlsZS52YWx1ZSA9IHN0eWxlLnZhbHVlLnJlcGxhY2UoL1wiIFwiL2csICdcIjxicj5cIicpXG5cbiAgICAgIGlmIChzdHlsZS5wcm9wLmluY2x1ZGVzKCdiYWNrZ3JvdW5kLWltYWdlJykpXG4gICAgICAgIHN0eWxlLnZhbHVlID0gYDxhIHRhcmdldD1cIl9ibGFua1wiIGhyZWY9XCIke3N0eWxlLnZhbHVlLnNsaWNlKHN0eWxlLnZhbHVlLmluZGV4T2YoJygnKSArIDIsIHN0eWxlLnZhbHVlLmxlbmd0aCAtIDIpfVwiPiR7c3R5bGUudmFsdWUuc2xpY2UoMCwyNSkgKyAnLi4uJ308L2E+YFxuXG4gICAgICAvLyBjaGVjayBpZiBzdHlsZSBpcyBpbmxpbmUgc3R5bGUsIHNob3cgaW5kaWNhdG9yXG4gICAgICBpZiAoZWwuZ2V0QXR0cmlidXRlKCdzdHlsZScpICYmIGVsLmdldEF0dHJpYnV0ZSgnc3R5bGUnKS5pbmNsdWRlcyhzdHlsZS5wcm9wKSlcbiAgICAgICAgc3R5bGUudmFsdWUgPSBgPHNwYW4gbG9jYWwtY2hhbmdlPiR7c3R5bGUudmFsdWV9PC9zcGFuPmBcblxuICAgICAgcmV0dXJuIHN0eWxlXG4gICAgfSlcblxuICBjb25zdCBsb2NhbE1vZGlmaWNhdGlvbnMgPSBzdHlsZXMuZmlsdGVyKHN0eWxlID0+XG4gICAgZWwuZ2V0QXR0cmlidXRlKCdzdHlsZScpICYmIGVsLmdldEF0dHJpYnV0ZSgnc3R5bGUnKS5pbmNsdWRlcyhzdHlsZS5wcm9wKVxuICAgICAgPyAxXG4gICAgICA6IDApXG5cbiAgY29uc3Qgbm90TG9jYWxNb2RpZmljYXRpb25zID0gc3R5bGVzLmZpbHRlcihzdHlsZSA9PlxuICAgIGVsLmdldEF0dHJpYnV0ZSgnc3R5bGUnKSAmJiBlbC5nZXRBdHRyaWJ1dGUoJ3N0eWxlJykuaW5jbHVkZXMoc3R5bGUucHJvcClcbiAgICAgID8gMFxuICAgICAgOiAxKVxuXG4gIHRpcC5tZXRhID0ge1xuICAgIGVsLFxuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICBsb2NhbE1vZGlmaWNhdGlvbnMsXG4gICAgbm90TG9jYWxNb2RpZmljYXRpb25zLFxuICB9XG5cbiAgcmV0dXJuIHRpcFxufVxuXG5jb25zdCBtb3VzZV9xdWFkcmFudCA9IGUgPT4gKHtcbiAgbm9ydGg6IGUuY2xpZW50WSA+IHdpbmRvdy5pbm5lckhlaWdodCAvIDIsXG4gIHdlc3Q6ICBlLmNsaWVudFggPiB3aW5kb3cuaW5uZXJXaWR0aCAvIDJcbn0pXG5cbmNvbnN0IHRpcF9wb3NpdGlvbiA9IChub2RlLCBlLCBub3J0aCwgd2VzdCkgPT4gKHtcbiAgdG9wOiBgJHtub3J0aFxuICAgID8gZS5wYWdlWSAtIG5vZGUuY2xpZW50SGVpZ2h0IC0gMjBcbiAgICA6IGUucGFnZVkgKyAyNX1weGAsXG4gIGxlZnQ6IGAke3dlc3RcbiAgICA/IGUucGFnZVggLSBub2RlLmNsaWVudFdpZHRoICsgMjNcbiAgICA6IGUucGFnZVggLSAyMX1weGAsXG59KVxuXG5jb25zdCBoYW5kbGVCbHVyID0gKHt0YXJnZXR9KSA9PiB7XG4gIGlmICghdGFyZ2V0Lmhhc0F0dHJpYnV0ZSgnZGF0YS1tZXRhdGlwJykgJiYgc3RhdGUudGlwcy5oYXModGFyZ2V0KSlcbiAgICB3aXBlKHN0YXRlLnRpcHMuZ2V0KHRhcmdldCkpXG59XG5cbmNvbnN0IHdpcGUgPSAoe3RpcCwgZTp7dGFyZ2V0fX0pID0+IHtcbiAgdGlwLnJlbW92ZSgpXG4gIHVub2JzZXJ2ZSh7dGlwLCB0YXJnZXR9KVxuICBzdGF0ZS50aXBzLmRlbGV0ZSh0YXJnZXQpXG59XG5cbmNvbnN0IHRvZ2dsZVBpbm5lZCA9IGUgPT4ge1xuICBjb25zdCB0YXJnZXQgPSBkZWVwRWxlbWVudEZyb21Qb2ludChlLmNsaWVudFgsIGUuY2xpZW50WSlcblxuICBpZiAoZS5hbHRLZXkgJiYgIXRhcmdldC5oYXNBdHRyaWJ1dGUoJ2RhdGEtbWV0YXRpcCcpKSB7XG4gICAgdGFyZ2V0LnNldEF0dHJpYnV0ZSgnZGF0YS1tZXRhdGlwJywgdHJ1ZSlcbiAgICBzdGF0ZS50aXBzLnNldCh0YXJnZXQsIHtcbiAgICAgIHRpcDogc3RhdGUuYWN0aXZlLnRpcCxcbiAgICAgIGUsXG4gICAgfSlcbiAgICBjbGVhckFjdGl2ZSgpXG4gIH1cbiAgZWxzZSBpZiAodGFyZ2V0Lmhhc0F0dHJpYnV0ZSgnZGF0YS1tZXRhdGlwJykpIHtcbiAgICB0YXJnZXQucmVtb3ZlQXR0cmlidXRlKCdkYXRhLW1ldGF0aXAnKVxuICAgIHdpcGUoc3RhdGUudGlwcy5nZXQodGFyZ2V0KSlcbiAgfVxufVxuXG5jb25zdCBsaW5rUXVlcnlDbGlja2VkID0gKHtkZXRhaWw6eyB0ZXh0LCBhY3RpdmF0b3IgfX0pID0+IHtcbiAgaWYgKCF0ZXh0KSByZXR1cm5cblxuICBxdWVyeVBhZ2UoJ1tkYXRhLXBzZXVkby1zZWxlY3RdJywgZWwgPT5cbiAgICBlbC5yZW1vdmVBdHRyaWJ1dGUoJ2RhdGEtcHNldWRvLXNlbGVjdCcpKVxuXG4gIHF1ZXJ5UGFnZSh0ZXh0ICsgJzpub3QoW2RhdGEtc2VsZWN0ZWRdKScsIGVsID0+XG4gICAgYWN0aXZhdG9yID09PSAnbW91c2VlbnRlcidcbiAgICAgID8gZWwuc2V0QXR0cmlidXRlKCdkYXRhLXBzZXVkby1zZWxlY3QnLCB0cnVlKVxuICAgICAgOiBzZXJ2aWNlcy5zZWxlY3RvcnMuc2VsZWN0KGVsKSlcbn1cblxuY29uc3QgbGlua1F1ZXJ5SG92ZXJPdXQgPSBlID0+IHtcbiAgcXVlcnlQYWdlKCdbZGF0YS1wc2V1ZG8tc2VsZWN0XScsIGVsID0+XG4gICAgZWwucmVtb3ZlQXR0cmlidXRlKCdkYXRhLXBzZXVkby1zZWxlY3QnKSlcbn1cblxuY29uc3QgdG9nZ2xlVGFyZ2V0Q3Vyc29yID0gKGtleSwgdGFyZ2V0KSA9PlxuICBrZXlcbiAgICA/IHRhcmdldC5zZXRBdHRyaWJ1dGUoJ2RhdGEtcGluaG92ZXInLCB0cnVlKVxuICAgIDogdGFyZ2V0LnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1waW5ob3ZlcicpXG5cbmNvbnN0IG9ic2VydmUgPSAoe3RpcCwgdGFyZ2V0fSkgPT4ge1xuICAkKHRpcCkub24oJ3F1ZXJ5JywgbGlua1F1ZXJ5Q2xpY2tlZClcbiAgJCh0aXApLm9uKCd1bnF1ZXJ5JywgbGlua1F1ZXJ5SG92ZXJPdXQpXG4gICQodGFyZ2V0KS5vbignRE9NTm9kZVJlbW92ZWQnLCBoYW5kbGVCbHVyKVxufVxuXG5jb25zdCB1bm9ic2VydmUgPSAoe3RpcCwgdGFyZ2V0fSkgPT4ge1xuICAkKHRpcCkub2ZmKCdxdWVyeScsIGxpbmtRdWVyeUNsaWNrZWQpXG4gICQodGlwKS5vZmYoJ3VucXVlcnknLCBsaW5rUXVlcnlIb3Zlck91dClcbiAgJCh0YXJnZXQpLm9mZignRE9NTm9kZVJlbW92ZWQnLCBoYW5kbGVCbHVyKVxufVxuXG5jb25zdCBjbGVhckFjdGl2ZSA9ICgpID0+IHtcbiAgc3RhdGUuYWN0aXZlLnRpcCAgICA9IG51bGxcbiAgc3RhdGUuYWN0aXZlLnRhcmdldCA9IG51bGxcbn1cbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgeyBUaW55Q29sb3IsIHJlYWRhYmlsaXR5LCBpc1JlYWRhYmxlIH0gZnJvbSAnQGN0cmwvdGlueWNvbG9yJ1xuaW1wb3J0IHtcbiAgZ2V0U3R5bGUsIGdldFN0eWxlcywgaXNPZmZCb3VuZHMsXG4gIGdldEExMXlzLCBnZXRXQ0FHMlRleHRTaXplLCBnZXRDb21wdXRlZEJhY2tncm91bmRDb2xvcixcbiAgZGVlcEVsZW1lbnRGcm9tUG9pbnRcbn0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuY29uc3Qgc3RhdGUgPSB7XG4gIGFjdGl2ZToge1xuICAgIHRpcDogIG51bGwsXG4gICAgdGFyZ2V0OiBudWxsLFxuICB9LFxuICB0aXBzOiBuZXcgTWFwKCksXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBBY2Nlc3NpYmlsaXR5KCkge1xuICAkKCdib2R5Jykub24oJ21vdXNlbW92ZScsIG1vdXNlTW92ZSlcbiAgJCgnYm9keScpLm9uKCdjbGljaycsIHRvZ2dsZVBpbm5lZClcblxuICBob3RrZXlzKCdlc2MnLCBfID0+IHJlbW92ZUFsbCgpKVxuXG4gIHJlc3RvcmVQaW5uZWRUaXBzKClcblxuICByZXR1cm4gKCkgPT4ge1xuICAgICQoJ2JvZHknKS5vZmYoJ21vdXNlbW92ZScsIG1vdXNlTW92ZSlcbiAgICAkKCdib2R5Jykub2ZmKCdjbGljaycsIHRvZ2dsZVBpbm5lZClcbiAgICBob3RrZXlzLnVuYmluZCgnZXNjJylcbiAgICBoaWRlQWxsKClcbiAgfVxufVxuXG5jb25zdCBtb3VzZU1vdmUgPSBlID0+IHtcbiAgY29uc3QgdGFyZ2V0ID0gZGVlcEVsZW1lbnRGcm9tUG9pbnQoZS5jbGllbnRYLCBlLmNsaWVudFkpXG5cbiAgaWYgKGlzT2ZmQm91bmRzKHRhcmdldCkgfHwgdGFyZ2V0Lm5vZGVOYW1lID09PSAnVklTQlVHLUFMTFlUSVAnIHx8IHRhcmdldC5oYXNBdHRyaWJ1dGUoJ2RhdGEtYWxseXRpcCcpKSB7IC8vIGFrYTogbW91c2Ugb3V0XG4gICAgaWYgKHN0YXRlLmFjdGl2ZS50aXApIHtcbiAgICAgIHdpcGUoe1xuICAgICAgICB0aXA6IHN0YXRlLmFjdGl2ZS50aXAsXG4gICAgICAgIGU6IHt0YXJnZXQ6IHN0YXRlLmFjdGl2ZS50YXJnZXR9LFxuICAgICAgfSlcbiAgICAgIGNsZWFyQWN0aXZlKClcbiAgICB9XG4gICAgcmV0dXJuXG4gIH1cblxuICB0b2dnbGVUYXJnZXRDdXJzb3IoZS5hbHRLZXksIHRhcmdldClcblxuICBzaG93VGlwKHRhcmdldCwgZSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNob3dUaXAodGFyZ2V0LCBlKSB7XG4gIGlmICghc3RhdGUuYWN0aXZlLnRpcCkgeyAvLyBjcmVhdGVcbiAgICBjb25zdCB0aXAgPSByZW5kZXIodGFyZ2V0KVxuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQodGlwKVxuXG4gICAgcG9zaXRpb25UaXAodGlwLCBlKVxuICAgIG9ic2VydmUoe3RpcCwgdGFyZ2V0fSlcblxuICAgIHN0YXRlLmFjdGl2ZS50aXAgICAgPSB0aXBcbiAgICBzdGF0ZS5hY3RpdmUudGFyZ2V0ID0gdGFyZ2V0XG4gIH1cbiAgZWxzZSBpZiAodGFyZ2V0ID09IHN0YXRlLmFjdGl2ZS50YXJnZXQpIHsgLy8gdXBkYXRlIHBvc2l0aW9uXG4gICAgLy8gdXBkYXRlIHBvc2l0aW9uXG4gICAgcG9zaXRpb25UaXAoc3RhdGUuYWN0aXZlLnRpcCwgZSlcbiAgfVxuICBlbHNlIHsgLy8gdXBkYXRlIGNvbnRlbnRcbiAgICByZW5kZXIodGFyZ2V0LCBzdGF0ZS5hY3RpdmUudGlwKVxuICAgIHN0YXRlLmFjdGl2ZS50YXJnZXQgPSB0YXJnZXRcbiAgICBwb3NpdGlvblRpcChzdGF0ZS5hY3RpdmUudGlwLCBlKVxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwb3NpdGlvblRpcCh0aXAsIGUpIHtcbiAgY29uc3QgeyBub3J0aCwgd2VzdCB9ID0gbW91c2VfcXVhZHJhbnQoZSlcbiAgY29uc3Qge2xlZnQsIHRvcH0gICAgID0gdGlwX3Bvc2l0aW9uKHRpcCwgZSwgbm9ydGgsIHdlc3QpXG5cbiAgdGlwLnN0eWxlLmxlZnQgID0gbGVmdFxuICB0aXAuc3R5bGUudG9wICAgPSB0b3BcblxuICB0aXAuc3R5bGUuc2V0UHJvcGVydHkoJy0tYXJyb3cnLCBub3J0aFxuICAgID8gJ3ZhcigtLWFycm93LXVwKSdcbiAgICA6ICd2YXIoLS1hcnJvdy1kb3duKScpXG5cbiAgdGlwLnN0eWxlLnNldFByb3BlcnR5KCctLXNoYWRvdy1kaXJlY3Rpb24nLCBub3J0aFxuICAgID8gJ3ZhcigtLXNoYWRvdy11cCknXG4gICAgOiAndmFyKC0tc2hhZG93LWRvd24pJylcblxuICB0aXAuc3R5bGUuc2V0UHJvcGVydHkoJy0tYXJyb3ctdG9wJywgIW5vcnRoXG4gICAgPyAnLTdweCdcbiAgICA6ICdjYWxjKDEwMCUgLSAxcHgpJylcblxuICB0aXAuc3R5bGUuc2V0UHJvcGVydHkoJy0tYXJyb3ctbGVmdCcsIHdlc3RcbiAgICA/ICdjYWxjKDEwMCUgLSAxNXB4IC0gMTVweCknXG4gICAgOiAnMTVweCcpXG59XG5cbmNvbnN0IHJlc3RvcmVQaW5uZWRUaXBzID0gKCkgPT4ge1xuICBzdGF0ZS50aXBzLmZvckVhY2goKHt0aXB9LCB0YXJnZXQpID0+IHtcbiAgICB0aXAuc3R5bGUuZGlzcGxheSA9ICdibG9jaydcbiAgICByZW5kZXIodGFyZ2V0LCB0aXApXG4gICAgb2JzZXJ2ZSh7dGlwLCB0YXJnZXR9KVxuICB9KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gaGlkZUFsbCgpIHtcbiAgc3RhdGUudGlwcy5mb3JFYWNoKCh7dGlwfSwgdGFyZ2V0KSA9PlxuICAgIHRpcC5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnKVxuXG4gIGlmIChzdGF0ZS5hY3RpdmUudGlwKSB7XG4gICAgc3RhdGUuYWN0aXZlLnRpcC5yZW1vdmUoKVxuICAgIGNsZWFyQWN0aXZlKClcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlQWxsKCkge1xuICBzdGF0ZS50aXBzLmZvckVhY2goKHt0aXB9LCB0YXJnZXQpID0+IHtcbiAgICB0aXAucmVtb3ZlKClcbiAgICB1bm9ic2VydmUoe3RpcCwgdGFyZ2V0fSlcbiAgfSlcblxuICAkKCdbZGF0YS1hbGx5dGlwXScpLmF0dHIoJ2RhdGEtYWxseXRpcCcsIG51bGwpXG5cbiAgc3RhdGUudGlwcy5jbGVhcigpXG59XG5cbmNvbnN0IHJlbmRlciA9IChlbCwgdGlwID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndmlzYnVnLWFsbHknKSkgPT4ge1xuICBjb25zdCBjb250cmFzdF9yZXN1bHRzID0gZGV0ZXJtaW5lQ29sb3JDb250cmFzdChlbClcbiAgY29uc3QgYWxseV9hdHRyaWJ1dGVzID0gZ2V0QTExeXMoZWwpXG5cbiAgYWxseV9hdHRyaWJ1dGVzLm1hcChhbGx5ID0+XG4gICAgYWxseS5wcm9wLmluY2x1ZGVzKCdhbHQnKVxuICAgICAgPyBhbGx5LnZhbHVlID0gYDxzcGFuIHRleHQ+JHthbGx5LnZhbHVlfTwvc3Bhbj5gXG4gICAgICA6IGFsbHkpXG5cbiAgYWxseV9hdHRyaWJ1dGVzLm1hcChhbGx5ID0+XG4gICAgYWxseS5wcm9wLmluY2x1ZGVzKCd0aXRsZScpXG4gICAgICA/IGFsbHkudmFsdWUgPSBgPHNwYW4gdGV4dCBsb25nZm9ybT4ke2FsbHkudmFsdWV9PC9zcGFuPmBcbiAgICAgIDogYWxseSlcblxuICB0aXAubWV0YSA9IHtcbiAgICBlbCxcbiAgICBhbGx5X2F0dHJpYnV0ZXMsXG4gICAgY29udHJhc3RfcmVzdWx0cyxcbiAgfVxuXG4gIHJldHVybiB0aXBcbn1cblxuY29uc3QgZGV0ZXJtaW5lQ29sb3JDb250cmFzdCA9IGVsID0+IHtcbiAgLy8gcXVlc3Rpb246IGhvdyB0byBrbm93IGlmIHRoZSBjdXJyZW50IG5vZGUgaXMgYWN0dWFsbHkgYSBibGFjayBiYWNrZ3JvdW5kP1xuICAvLyBxdWVzdGlvbjogaXMgdGhlcmUgYW4gYXBpIGZvciBjb21wb3NpdGVkIHZhbHVlcz9cbiAgY29uc3QgdGV4dCAgICAgID0gZ2V0U3R5bGUoZWwsICdjb2xvcicpXG4gIGNvbnN0IHRleHRTaXplICA9IGdldFdDQUcyVGV4dFNpemUoZWwpXG5cbiAgbGV0IGJhY2tncm91bmQgID0gZ2V0Q29tcHV0ZWRCYWNrZ3JvdW5kQ29sb3IoZWwpXG5cbiAgY29uc3QgWyBhYV9jb250cmFzdCwgYWFhX2NvbnRyYXN0IF0gPSBbXG4gICAgaXNSZWFkYWJsZShiYWNrZ3JvdW5kLCB0ZXh0LCB7IGxldmVsOiBcIkFBXCIsIHNpemU6IHRleHRTaXplLnRvTG93ZXJDYXNlKCkgfSksXG4gICAgaXNSZWFkYWJsZShiYWNrZ3JvdW5kLCB0ZXh0LCB7IGxldmVsOiBcIkFBQVwiLCBzaXplOiB0ZXh0U2l6ZS50b0xvd2VyQ2FzZSgpIH0pXG4gIF1cblxuICByZXR1cm4gYFxuICAgIDxzcGFuIHByb3A+Q29sb3IgY29udHJhc3Q8L3NwYW4+XG4gICAgPHNwYW4gdmFsdWUgY29udHJhc3Q+XG4gICAgICA8c3BhbiBzdHlsZT1cIlxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiR7YmFja2dyb3VuZH07XG4gICAgICAgIGNvbG9yOiR7dGV4dH07XG4gICAgICBcIj4ke01hdGguZmxvb3IocmVhZGFiaWxpdHkoYmFja2dyb3VuZCwgdGV4dCkgICogMTAwKSAvIDEwMH08L3NwYW4+XG4gICAgPC9zcGFuPlxuICAgIDxzcGFuIHByb3A+4oC6IEFBICR7dGV4dFNpemV9PC9zcGFuPlxuICAgIDxzcGFuIHZhbHVlIHN0eWxlPVwiJHthYV9jb250cmFzdCA/ICdjb2xvcjpncmVlbjsnIDogJ2NvbG9yOnJlZCd9XCI+JHthYV9jb250cmFzdCA/ICfinJMnIDogJ8OXJ308L3NwYW4+XG4gICAgPHNwYW4gcHJvcD7igLogQUFBICR7dGV4dFNpemV9PC9zcGFuPlxuICAgIDxzcGFuIHZhbHVlIHN0eWxlPVwiJHthYWFfY29udHJhc3QgPyAnY29sb3I6Z3JlZW47JyA6ICdjb2xvcjpyZWQnfVwiPiR7YWFhX2NvbnRyYXN0ID8gJ+KckycgOiAnw5cnfTwvc3Bhbj5cbiAgYFxufVxuXG5jb25zdCBtb3VzZV9xdWFkcmFudCA9IGUgPT4gKHtcbiAgbm9ydGg6IGUuY2xpZW50WSA+IHdpbmRvdy5pbm5lckhlaWdodCAvIDIsXG4gIHdlc3Q6ICBlLmNsaWVudFggPiB3aW5kb3cuaW5uZXJXaWR0aCAvIDJcbn0pXG5cbmNvbnN0IHRpcF9wb3NpdGlvbiA9IChub2RlLCBlLCBub3J0aCwgd2VzdCkgPT4gKHtcbiAgdG9wOiBgJHtub3J0aFxuICAgID8gZS5wYWdlWSAtIG5vZGUuY2xpZW50SGVpZ2h0IC0gMjBcbiAgICA6IGUucGFnZVkgKyAyNX1weGAsXG4gIGxlZnQ6IGAke3dlc3RcbiAgICA/IGUucGFnZVggLSBub2RlLmNsaWVudFdpZHRoICsgMjNcbiAgICA6IGUucGFnZVggLSAyMX1weGAsXG59KVxuXG5jb25zdCBoYW5kbGVCbHVyID0gKHt0YXJnZXR9KSA9PiB7XG4gIGlmICghdGFyZ2V0Lmhhc0F0dHJpYnV0ZSgnZGF0YS1hbGx5dGlwJykgJiYgc3RhdGUudGlwcy5oYXModGFyZ2V0KSlcbiAgICB3aXBlKHN0YXRlLnRpcHMuZ2V0KHRhcmdldCkpXG59XG5cbmNvbnN0IHdpcGUgPSAoe3RpcCwgZTp7dGFyZ2V0fX0pID0+IHtcbiAgdGlwLnJlbW92ZSgpXG4gIHVub2JzZXJ2ZSh7dGlwLCB0YXJnZXR9KVxuICBzdGF0ZS50aXBzLmRlbGV0ZSh0YXJnZXQpXG59XG5cbmNvbnN0IHRvZ2dsZVBpbm5lZCA9IGUgPT4ge1xuICBjb25zdCB0YXJnZXQgPSBkZWVwRWxlbWVudEZyb21Qb2ludChlLmNsaWVudFgsIGUuY2xpZW50WSlcblxuICBpZiAoZS5hbHRLZXkgJiYgIXRhcmdldC5oYXNBdHRyaWJ1dGUoJ2RhdGEtYWxseXRpcCcpKSB7XG4gICAgdGFyZ2V0LnNldEF0dHJpYnV0ZSgnZGF0YS1hbGx5dGlwJywgdHJ1ZSlcbiAgICBzdGF0ZS50aXBzLnNldCh0YXJnZXQsIHtcbiAgICAgIHRpcDogc3RhdGUuYWN0aXZlLnRpcCxcbiAgICAgIGUsXG4gICAgfSlcbiAgICBjbGVhckFjdGl2ZSgpXG4gIH1cbiAgZWxzZSBpZiAodGFyZ2V0Lmhhc0F0dHJpYnV0ZSgnZGF0YS1hbGx5dGlwJykpIHtcbiAgICB0YXJnZXQucmVtb3ZlQXR0cmlidXRlKCdkYXRhLWFsbHl0aXAnKVxuICAgIHdpcGUoc3RhdGUudGlwcy5nZXQodGFyZ2V0KSlcbiAgfVxufVxuXG5jb25zdCB0b2dnbGVUYXJnZXRDdXJzb3IgPSAoa2V5LCB0YXJnZXQpID0+XG4gIGtleVxuICAgID8gdGFyZ2V0LnNldEF0dHJpYnV0ZSgnZGF0YS1waW5ob3ZlcicsIHRydWUpXG4gICAgOiB0YXJnZXQucmVtb3ZlQXR0cmlidXRlKCdkYXRhLXBpbmhvdmVyJylcblxuY29uc3Qgb2JzZXJ2ZSA9ICh7dGlwLCB0YXJnZXR9KSA9PiB7XG4gICQodGFyZ2V0KS5vbignRE9NTm9kZVJlbW92ZWQnLCBoYW5kbGVCbHVyKVxufVxuXG5jb25zdCB1bm9ic2VydmUgPSAoe3RpcCwgdGFyZ2V0fSkgPT4ge1xuICAkKHRhcmdldCkub2ZmKCdET01Ob2RlUmVtb3ZlZCcsIGhhbmRsZUJsdXIpXG59XG5cbmNvbnN0IGNsZWFyQWN0aXZlID0gKCkgPT4ge1xuICBzdGF0ZS5hY3RpdmUudGlwICAgID0gbnVsbFxuICBzdGF0ZS5hY3RpdmUudGFyZ2V0ID0gbnVsbFxufVxuIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcblxuaW1wb3J0IHsgY2FuTW92ZUxlZnQsIGNhbk1vdmVSaWdodCwgY2FuTW92ZVVwIH0gZnJvbSAnLi9tb3ZlJ1xuaW1wb3J0IHsgd2F0Y2hJbWFnZXNGb3JVcGxvYWQgfSBmcm9tICcuL2ltYWdlc3dhcCdcbmltcG9ydCB7IHF1ZXJ5UGFnZSB9IGZyb20gJy4vc2VhcmNoJ1xuaW1wb3J0IHsgY3JlYXRlTWVhc3VyZW1lbnRzLCBjbGVhck1lYXN1cmVtZW50cyB9IGZyb20gJy4vbWVhc3VyZW1lbnRzJ1xuaW1wb3J0IHsgc2hvd1RpcCBhcyBzaG93TWV0YVRpcCwgcmVtb3ZlQWxsIGFzIHJlbW92ZUFsbE1ldGFUaXBzIH0gZnJvbSAnLi9tZXRhdGlwJ1xuaW1wb3J0IHsgc2hvd1RpcCBhcyBzaG93QWNjZXNzaWJpbGl0eVRpcCwgcmVtb3ZlQWxsIGFzIHJlbW92ZUFsbEFjY2Vzc2liaWxpdHlUaXBzIH0gZnJvbSAnLi9hY2Nlc3NpYmlsaXR5J1xuXG5pbXBvcnQge1xuICBtZXRhS2V5LCBodG1sU3RyaW5nVG9Eb20sIGNyZWF0ZUNsYXNzbmFtZSxcbiAgaXNPZmZCb3VuZHMsIGdldFN0eWxlcywgZGVlcEVsZW1lbnRGcm9tUG9pbnQsXG4gIGlzU2VsZWN0b3JWYWxpZCwgZmluZE5lYXJlc3RDaGlsZEVsZW1lbnRcbn0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuZXhwb3J0IGZ1bmN0aW9uIFNlbGVjdGFibGUoKSB7XG4gIGNvbnN0IHBhZ2UgICAgICAgICAgICAgID0gZG9jdW1lbnQuYm9keVxuICBsZXQgc2VsZWN0ZWQgICAgICAgICAgICA9IFtdXG4gIGxldCBzZWxlY3RlZENhbGxiYWNrcyAgID0gW11cbiAgbGV0IGxhYmVscyAgICAgICAgICAgICAgPSBbXVxuICBsZXQgaGFuZGxlcyAgICAgICAgICAgICA9IFtdXG5cbiAgY29uc3QgaG92ZXJfc3RhdGUgICAgICAgPSB7XG4gICAgdGFyZ2V0OiAgIG51bGwsXG4gICAgZWxlbWVudDogIG51bGwsXG4gICAgbGFiZWw6ICAgIG51bGwsXG4gIH1cblxuICBjb25zdCBsaXN0ZW4gPSAoKSA9PiB7XG4gICAgcGFnZS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIG9uX2NsaWNrLCB0cnVlKVxuICAgIHBhZ2UuYWRkRXZlbnRMaXN0ZW5lcignZGJsY2xpY2snLCBvbl9kYmxjbGljaywgdHJ1ZSlcblxuICAgIHBhZ2Uub24oJ3NlbGVjdHN0YXJ0Jywgb25fc2VsZWN0aW9uKVxuICAgIHBhZ2Uub24oJ21vdXNlbW92ZScsIG9uX2hvdmVyKVxuXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY29weScsIG9uX2NvcHkpXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY3V0Jywgb25fY3V0KVxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3Bhc3RlJywgb25fcGFzdGUpXG5cbiAgICB3YXRjaENvbW1hbmRLZXkoKVxuXG4gICAgaG90a2V5cyhgJHttZXRhS2V5fSthbHQrY2AsIG9uX2NvcHlfc3R5bGVzKVxuICAgIGhvdGtleXMoYCR7bWV0YUtleX0rYWx0K3ZgLCBlID0+IG9uX3Bhc3RlX3N0eWxlcygpKVxuICAgIGhvdGtleXMoJ2VzYycsIG9uX2VzYylcbiAgICBob3RrZXlzKGAke21ldGFLZXl9K2RgLCBvbl9kdXBsaWNhdGUpXG4gICAgaG90a2V5cygnYmFja3NwYWNlLGRlbCxkZWxldGUnLCBvbl9kZWxldGUpXG4gICAgaG90a2V5cygnYWx0K2RlbCxhbHQrYmFja3NwYWNlJywgb25fY2xlYXJzdHlsZXMpXG4gICAgaG90a2V5cyhgJHttZXRhS2V5fStlLCR7bWV0YUtleX0rc2hpZnQrZWAsIG9uX2V4cGFuZF9zZWxlY3Rpb24pXG4gICAgaG90a2V5cyhgJHttZXRhS2V5fStnLCR7bWV0YUtleX0rc2hpZnQrZ2AsIG9uX2dyb3VwKVxuICAgIGhvdGtleXMoJ3RhYixzaGlmdCt0YWIsZW50ZXIsc2hpZnQrZW50ZXInLCBvbl9rZXlib2FyZF90cmF2ZXJzYWwpXG4gICAgaG90a2V5cyhgJHttZXRhS2V5fStzaGlmdCtlbnRlcmAsIG9uX3NlbGVjdF9jaGlsZHJlbilcbiAgfVxuXG4gIGNvbnN0IHVubGlzdGVuID0gKCkgPT4ge1xuICAgIHBhZ2UucmVtb3ZlRXZlbnRMaXN0ZW5lcignY2xpY2snLCBvbl9jbGljaywgdHJ1ZSlcbiAgICBwYWdlLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2RibGNsaWNrJywgb25fZGJsY2xpY2ssIHRydWUpXG5cbiAgICBwYWdlLm9mZignc2VsZWN0c3RhcnQnLCBvbl9zZWxlY3Rpb24pXG4gICAgcGFnZS5vZmYoJ21vdXNlbW92ZScsIG9uX2hvdmVyKVxuXG4gICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignY29weScsIG9uX2NvcHkpXG4gICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignY3V0Jywgb25fY3V0KVxuICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Bhc3RlJywgb25fcGFzdGUpXG5cbiAgICBob3RrZXlzLnVuYmluZChgZXNjLCR7bWV0YUtleX0rZCxiYWNrc3BhY2UsZGVsLGRlbGV0ZSxhbHQrZGVsLGFsdCtiYWNrc3BhY2UsJHttZXRhS2V5fStlLCR7bWV0YUtleX0rc2hpZnQrZSwke21ldGFLZXl9K2csJHttZXRhS2V5fStzaGlmdCtnLHRhYixzaGlmdCt0YWIsZW50ZXIsc2hpZnQrZW50ZXJgKVxuICB9XG5cbiAgY29uc3Qgb25fY2xpY2sgPSBlID0+IHtcbiAgICBjb25zdCAkdGFyZ2V0ID0gZGVlcEVsZW1lbnRGcm9tUG9pbnQoZS5jbGllbnRYLCBlLmNsaWVudFkpXG5cbiAgICBpZiAoaXNPZmZCb3VuZHMoJHRhcmdldCkgJiYgIXNlbGVjdGVkLmZpbHRlcihlbCA9PiBlbCA9PSAkdGFyZ2V0KS5sZW5ndGgpXG4gICAgICByZXR1cm5cblxuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGlmICghZS5hbHRLZXkpIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgICBpZiAoIWUuc2hpZnRLZXkpIHVuc2VsZWN0X2FsbCgpXG5cbiAgICBpZihlLnNoaWZ0S2V5ICYmICR0YXJnZXQuaGFzQXR0cmlidXRlKCdkYXRhLXNlbGVjdGVkJykpXG4gICAgICB1bnNlbGVjdCgkdGFyZ2V0LmdldEF0dHJpYnV0ZSgnZGF0YS1sYWJlbC1pZCcpKVxuICAgIGVsc2VcbiAgICAgIHNlbGVjdCgkdGFyZ2V0KVxuICB9XG5cbiAgY29uc3QgdW5zZWxlY3QgPSBpZCA9PiB7XG4gICAgWy4uLmxhYmVscywgLi4uaGFuZGxlc11cbiAgICAgIC5maWx0ZXIobm9kZSA9PlxuICAgICAgICAgIG5vZGUuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJykgPT09IGlkKVxuICAgICAgICAuZm9yRWFjaChub2RlID0+XG4gICAgICAgICAgbm9kZS5yZW1vdmUoKSlcblxuICAgIHNlbGVjdGVkLmZpbHRlcihub2RlID0+XG4gICAgICBub2RlLmdldEF0dHJpYnV0ZSgnZGF0YS1sYWJlbC1pZCcpID09PSBpZClcbiAgICAgIC5mb3JFYWNoKG5vZGUgPT5cbiAgICAgICAgJChub2RlKS5hdHRyKHtcbiAgICAgICAgICAnZGF0YS1zZWxlY3RlZCc6ICAgICAgbnVsbCxcbiAgICAgICAgICAnZGF0YS1zZWxlY3RlZC1oaWRlJzogbnVsbCxcbiAgICAgICAgICAnZGF0YS1sYWJlbC1pZCc6ICAgICAgbnVsbCxcbiAgICAgICAgICAnZGF0YS1wc2V1ZG8tc2VsZWN0JzogICAgICAgICBudWxsLFxuICAgICAgICAgICdkYXRhLW1lYXN1cmluZyc6ICAgICBudWxsLFxuICAgICAgfSkpXG5cbiAgICBzZWxlY3RlZCA9IHNlbGVjdGVkLmZpbHRlcihub2RlID0+IG5vZGUuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJykgIT09IGlkKVxuXG4gICAgdGVsbFdhdGNoZXJzKClcbiAgfVxuXG4gIGNvbnN0IG9uX2RibGNsaWNrID0gZSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKVxuICAgIGlmIChpc09mZkJvdW5kcyhlLnRhcmdldCkpIHJldHVyblxuICAgICQoJ3Zpcy1idWcnKVswXS50b29sU2VsZWN0ZWQoJ3RleHQnKVxuICB9XG5cbiAgY29uc3Qgd2F0Y2hDb21tYW5kS2V5ID0gZSA9PiB7XG4gICAgbGV0IGRpZF9oaWRlID0gZmFsc2VcblxuICAgIGRvY3VtZW50Lm9ua2V5ZG93biA9IGZ1bmN0aW9uKGUpIHtcbiAgICAgIGlmIChob3RrZXlzLmN0cmwgJiYgc2VsZWN0ZWQubGVuZ3RoKSB7XG4gICAgICAgICQoJ3Zpc2J1Zy1oYW5kbGVzLCB2aXNidWctbGFiZWwsIHZpc2J1Zy1ob3ZlcicpLmZvckVhY2goZWwgPT5cbiAgICAgICAgICBlbC5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnKVxuXG4gICAgICAgIGRpZF9oaWRlID0gdHJ1ZVxuICAgICAgfVxuICAgIH1cblxuICAgIGRvY3VtZW50Lm9ua2V5dXAgPSBmdW5jdGlvbihlKSB7XG4gICAgICBpZiAoZGlkX2hpZGUpIHtcbiAgICAgICAgJCgndmlzYnVnLWhhbmRsZXMsIHZpc2J1Zy1sYWJlbCwgdmlzYnVnLWhvdmVyJykuZm9yRWFjaChlbCA9PlxuICAgICAgICAgIGVsLnN0eWxlLmRpc3BsYXkgPSBudWxsKVxuXG4gICAgICAgIGRpZF9oaWRlID0gZmFsc2VcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjb25zdCBvbl9lc2MgPSBfID0+XG4gICAgc2VsZWN0ZWQubGVuZ3RoICYmIHVuc2VsZWN0X2FsbCgpXG5cbiAgY29uc3Qgb25fZHVwbGljYXRlID0gZSA9PiB7XG4gICAgY29uc3Qgcm9vdF9ub2RlID0gc2VsZWN0ZWRbMF1cbiAgICBpZiAoIXJvb3Rfbm9kZSkgcmV0dXJuXG5cbiAgICBjb25zdCBkZWVwX2Nsb25lID0gcm9vdF9ub2RlLmNsb25lTm9kZSh0cnVlKVxuICAgIGRlZXBfY2xvbmUucmVtb3ZlQXR0cmlidXRlKCdkYXRhLXNlbGVjdGVkJylcbiAgICByb290X25vZGUucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoZGVlcF9jbG9uZSwgcm9vdF9ub2RlLm5leHRTaWJsaW5nKVxuICAgIGUucHJldmVudERlZmF1bHQoKVxuICB9XG5cbiAgY29uc3Qgb25fZGVsZXRlID0gZSA9PlxuICAgIHNlbGVjdGVkLmxlbmd0aCAmJiBkZWxldGVfYWxsKClcblxuICBjb25zdCBvbl9jbGVhcnN0eWxlcyA9IGUgPT5cbiAgICBzZWxlY3RlZC5mb3JFYWNoKGVsID0+XG4gICAgICBlbC5hdHRyKCdzdHlsZScsIG51bGwpKVxuXG4gIGNvbnN0IG9uX2NvcHkgPSBlID0+IHtcbiAgICAvLyBpZiB1c2VyIGhhcyBzZWxlY3RlZCB0ZXh0LCBkb250IHRyeSB0byBjb3B5IGFuIGVsZW1lbnRcbiAgICBpZiAod2luZG93LmdldFNlbGVjdGlvbigpLnRvU3RyaW5nKCkubGVuZ3RoKVxuICAgICAgcmV0dXJuXG5cbiAgICBpZiAoc2VsZWN0ZWRbMF0gJiYgdGhpcy5ub2RlX2NsaXBib2FyZCAhPT0gc2VsZWN0ZWRbMF0pIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgbGV0ICRub2RlID0gc2VsZWN0ZWRbMF0uY2xvbmVOb2RlKHRydWUpXG4gICAgICAkbm9kZS5yZW1vdmVBdHRyaWJ1dGUoJ2RhdGEtc2VsZWN0ZWQnKVxuICAgICAgdGhpcy5jb3B5X2JhY2t1cCA9ICRub2RlLm91dGVySFRNTFxuICAgICAgZS5jbGlwYm9hcmREYXRhLnNldERhdGEoJ3RleHQvaHRtbCcsIHRoaXMuY29weV9iYWNrdXApXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgb25fY3V0ID0gZSA9PiB7XG4gICAgaWYgKHNlbGVjdGVkWzBdICYmIHRoaXMubm9kZV9jbGlwYm9hcmQgIT09IHNlbGVjdGVkWzBdKSB7XG4gICAgICBsZXQgJG5vZGUgPSBzZWxlY3RlZFswXS5jbG9uZU5vZGUodHJ1ZSlcbiAgICAgICRub2RlLnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1zZWxlY3RlZCcpXG4gICAgICB0aGlzLmNvcHlfYmFja3VwID0gJG5vZGUub3V0ZXJIVE1MXG4gICAgICBlLmNsaXBib2FyZERhdGEuc2V0RGF0YSgndGV4dC9odG1sJywgdGhpcy5jb3B5X2JhY2t1cClcbiAgICAgIHNlbGVjdGVkWzBdLnJlbW92ZSgpXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgb25fcGFzdGUgPSBlID0+IHtcbiAgICBjb25zdCBjbGlwRGF0YSA9IGUuY2xpcGJvYXJkRGF0YS5nZXREYXRhKCd0ZXh0L2h0bWwnKVxuICAgIGNvbnN0IHBvdGVudGlhbEhUTUwgPSBjbGlwRGF0YSB8fCB0aGlzLmNvcHlfYmFja3VwXG4gICAgaWYgKHNlbGVjdGVkWzBdICYmIHBvdGVudGlhbEhUTUwpIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgc2VsZWN0ZWRbMF0uYXBwZW5kQ2hpbGQoXG4gICAgICAgIGh0bWxTdHJpbmdUb0RvbShwb3RlbnRpYWxIVE1MKSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBvbl9jb3B5X3N0eWxlcyA9IGUgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHRoaXMuY29waWVkX3N0eWxlcyA9IHNlbGVjdGVkLm1hcChlbCA9PlxuICAgICAgZ2V0U3R5bGVzKGVsKSlcbiAgfVxuXG4gIGNvbnN0IG9uX3Bhc3RlX3N0eWxlcyA9IChpbmRleCA9IDApID0+XG4gICAgc2VsZWN0ZWQuZm9yRWFjaChlbCA9PiB7XG4gICAgICB0aGlzLmNvcGllZF9zdHlsZXNbaW5kZXhdXG4gICAgICAgIC5tYXAoKHtwcm9wLCB2YWx1ZX0pID0+XG4gICAgICAgICAgZWwuc3R5bGVbcHJvcF0gPSB2YWx1ZSlcblxuICAgICAgaW5kZXggPj0gdGhpcy5jb3BpZWRfc3R5bGVzLmxlbmd0aCAtIDFcbiAgICAgICAgPyBpbmRleCA9IDBcbiAgICAgICAgOiBpbmRleCsrXG4gICAgfSlcblxuICBjb25zdCBvbl9leHBhbmRfc2VsZWN0aW9uID0gKGUsIHtrZXl9KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICBjb25zdCBbcm9vdF0gPSBzZWxlY3RlZFxuICAgIGlmICghcm9vdCkgcmV0dXJuXG5cbiAgICBjb25zdCBxdWVyeSA9IGNvbWJpbmVOb2RlTmFtZUFuZENsYXNzKHJvb3QpXG5cbiAgICBpZiAoaXNTZWxlY3RvclZhbGlkKHF1ZXJ5KSlcbiAgICAgIGV4cGFuZFNlbGVjdGlvbih7XG4gICAgICAgIHF1ZXJ5LFxuICAgICAgICBhbGw6IGtleS5pbmNsdWRlcygnc2hpZnQnKSxcbiAgICAgIH0pXG4gIH1cblxuICBjb25zdCBvbl9ncm91cCA9IChlLCB7a2V5fSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuXG4gICAgaWYgKGtleS5zcGxpdCgnKycpLmluY2x1ZGVzKCdzaGlmdCcpKSB7XG4gICAgICBsZXQgJHNlbGVjdGVkID0gWy4uLnNlbGVjdGVkXVxuICAgICAgdW5zZWxlY3RfYWxsKClcbiAgICAgICRzZWxlY3RlZC5yZXZlcnNlKCkuZm9yRWFjaChlbCA9PiB7XG4gICAgICAgIGxldCBsID0gZWwuY2hpbGRyZW4ubGVuZ3RoXG4gICAgICAgIHdoaWxlIChlbC5jaGlsZHJlbi5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgdmFyIG5vZGUgPSBlbC5jaGlsZE5vZGVzW2VsLmNoaWxkcmVuLmxlbmd0aCAtIDFdXG4gICAgICAgICAgaWYgKG5vZGUubm9kZU5hbWUgIT09ICcjdGV4dCcpXG4gICAgICAgICAgICBzZWxlY3Qobm9kZSlcbiAgICAgICAgICBlbC5wYXJlbnROb2RlLnByZXBlbmQobm9kZSlcbiAgICAgICAgfVxuICAgICAgICBlbC5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKGVsKVxuICAgICAgfSlcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICBsZXQgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICAgIHNlbGVjdGVkWzBdLnBhcmVudE5vZGUucHJlcGVuZChcbiAgICAgICAgc2VsZWN0ZWQucmV2ZXJzZSgpLnJlZHVjZSgoZGl2LCBlbCkgPT4ge1xuICAgICAgICAgIGRpdi5hcHBlbmRDaGlsZChlbClcbiAgICAgICAgICByZXR1cm4gZGl2XG4gICAgICAgIH0sIGRpdilcbiAgICAgIClcbiAgICAgIHVuc2VsZWN0X2FsbCgpXG4gICAgICBzZWxlY3QoZGl2KVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IG9uX3NlbGVjdGlvbiA9IGUgPT5cbiAgICAhaXNPZmZCb3VuZHMoZS50YXJnZXQpXG4gICAgJiYgc2VsZWN0ZWQubGVuZ3RoXG4gICAgJiYgc2VsZWN0ZWRbMF0udGV4dENvbnRlbnQgIT0gZS50YXJnZXQudGV4dENvbnRlbnRcbiAgICAmJiBlLnByZXZlbnREZWZhdWx0KClcblxuICBjb25zdCBvbl9rZXlib2FyZF90cmF2ZXJzYWwgPSAoZSwge2tleX0pID0+IHtcbiAgICBpZiAoIXNlbGVjdGVkLmxlbmd0aCkgcmV0dXJuXG5cbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG5cbiAgICBjb25zdCB0YXJnZXRzID0gc2VsZWN0ZWQucmVkdWNlKChmbGF0X25fdW5pcXVlLCBub2RlKSA9PiB7XG4gICAgICBjb25zdCBlbGVtZW50X3RvX2xlZnQgICAgID0gY2FuTW92ZUxlZnQobm9kZSlcbiAgICAgIGNvbnN0IGVsZW1lbnRfdG9fcmlnaHQgICAgPSBjYW5Nb3ZlUmlnaHQobm9kZSlcbiAgICAgIGNvbnN0IGhhc19wYXJlbnRfZWxlbWVudCAgPSBjYW5Nb3ZlVXAobm9kZSlcbiAgICAgIGNvbnN0IGhhc19jaGlsZF9lbGVtZW50cyAgPSBmaW5kTmVhcmVzdENoaWxkRWxlbWVudChub2RlKVxuXG4gICAgICBpZiAoa2V5LmluY2x1ZGVzKCdzaGlmdCcpKSB7XG4gICAgICAgIGlmIChrZXkuaW5jbHVkZXMoJ3RhYicpICYmIGVsZW1lbnRfdG9fbGVmdClcbiAgICAgICAgICBmbGF0X25fdW5pcXVlLmFkZChlbGVtZW50X3RvX2xlZnQpXG4gICAgICAgIGVsc2UgaWYgKGtleS5pbmNsdWRlcygnZW50ZXInKSAmJiBoYXNfcGFyZW50X2VsZW1lbnQpXG4gICAgICAgICAgZmxhdF9uX3VuaXF1ZS5hZGQoaGFzX3BhcmVudF9lbGVtZW50KVxuICAgICAgICBlbHNlXG4gICAgICAgICAgZmxhdF9uX3VuaXF1ZS5hZGQobm9kZSlcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICBpZiAoa2V5LmluY2x1ZGVzKCd0YWInKSAmJiBlbGVtZW50X3RvX3JpZ2h0KVxuICAgICAgICAgIGZsYXRfbl91bmlxdWUuYWRkKGVsZW1lbnRfdG9fcmlnaHQpXG4gICAgICAgIGVsc2UgaWYgKGtleS5pbmNsdWRlcygnZW50ZXInKSAmJiBoYXNfY2hpbGRfZWxlbWVudHMpXG4gICAgICAgICAgZmxhdF9uX3VuaXF1ZS5hZGQoaGFzX2NoaWxkX2VsZW1lbnRzKVxuICAgICAgICBlbHNlXG4gICAgICAgICAgZmxhdF9uX3VuaXF1ZS5hZGQobm9kZSlcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGZsYXRfbl91bmlxdWVcbiAgICB9LCBuZXcgU2V0KCkpXG5cbiAgICBpZiAodGFyZ2V0cy5zaXplKSB7XG4gICAgICB1bnNlbGVjdF9hbGwoKVxuICAgICAgdGFyZ2V0cy5mb3JFYWNoKG5vZGUgPT4ge1xuICAgICAgICBzZWxlY3Qobm9kZSlcbiAgICAgICAgc2hvd190aXAobm9kZSlcbiAgICAgIH0pXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgc2hvd190aXAgPSBlbCA9PiB7XG4gICAgY29uc3QgYWN0aXZlX3Rvb2wgPSAkKCd2aXMtYnVnJylbMF0uYWN0aXZlVG9vbFxuICAgIGxldCB0aXBGYWN0b3J5XG5cbiAgICBpZiAoYWN0aXZlX3Rvb2wgPT09ICdhY2Nlc3NpYmlsaXR5Jykge1xuICAgICAgcmVtb3ZlQWxsQWNjZXNzaWJpbGl0eVRpcHMoKVxuICAgICAgdGlwRmFjdG9yeSA9IHNob3dBY2Nlc3NpYmlsaXR5VGlwXG4gICAgfVxuICAgIGVsc2UgaWYgKGFjdGl2ZV90b29sID09PSAnaW5zcGVjdG9yJykge1xuICAgICAgcmVtb3ZlQWxsTWV0YVRpcHMoKVxuICAgICAgdGlwRmFjdG9yeSA9IHNob3dNZXRhVGlwXG4gICAgfVxuXG4gICAgaWYgKCF0aXBGYWN0b3J5KSByZXR1cm5cblxuICAgIGNvbnN0IHt0b3AsIGxlZnR9ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KClcbiAgICBjb25zdCB7IHBhZ2VZT2Zmc2V0LCBwYWdlWE9mZnNldCB9ID0gd2luZG93XG5cbiAgICB0aXBGYWN0b3J5KGVsLCB7XG4gICAgICBjbGllbnRZOiAgdG9wLFxuICAgICAgY2xpZW50WDogIGxlZnQsXG4gICAgICBwYWdlWTogICAgcGFnZVlPZmZzZXQgKyB0b3AgLSAxMCxcbiAgICAgIHBhZ2VYOiAgICBwYWdlWE9mZnNldCArIGxlZnQgKyAyMCxcbiAgICB9KVxuICB9XG5cbiAgY29uc3Qgb25faG92ZXIgPSBlID0+IHtcbiAgICBjb25zdCAkdGFyZ2V0ID0gZGVlcEVsZW1lbnRGcm9tUG9pbnQoZS5jbGllbnRYLCBlLmNsaWVudFkpXG5cbiAgICBpZiAoaXNPZmZCb3VuZHMoJHRhcmdldCkgfHwgJHRhcmdldC5oYXNBdHRyaWJ1dGUoJ2RhdGEtc2VsZWN0ZWQnKSlcbiAgICAgIHJldHVybiBjbGVhckhvdmVyKClcblxuICAgIG92ZXJsYXlIb3ZlclVJKCR0YXJnZXQpXG5cbiAgICBpZiAoZS5hbHRLZXkgJiYgJCgndmlzLWJ1ZycpWzBdLmFjdGl2ZVRvb2wgPT09ICdndWlkZXMnICYmIHNlbGVjdGVkLmxlbmd0aCA9PT0gMSAmJiBzZWxlY3RlZFswXSAhPSAkdGFyZ2V0KSB7XG4gICAgICAkdGFyZ2V0LnNldEF0dHJpYnV0ZSgnZGF0YS1tZWFzdXJpbmcnLCB0cnVlKVxuICAgICAgY29uc3QgWyRhbmNob3JdID0gc2VsZWN0ZWRcbiAgICAgIHJldHVybiBjcmVhdGVNZWFzdXJlbWVudHMoeyRhbmNob3IsICR0YXJnZXR9KVxuICAgIH1cbiAgICBlbHNlIGlmICgkdGFyZ2V0Lmhhc0F0dHJpYnV0ZSgnZGF0YS1tZWFzdXJpbmcnKSkge1xuICAgICAgJHRhcmdldC5yZW1vdmVBdHRyaWJ1dGUoJ2RhdGEtbWVhc3VyaW5nJylcbiAgICAgIGNsZWFyTWVhc3VyZW1lbnRzKClcbiAgICB9XG4gIH1cblxuICBjb25zdCBzZWxlY3QgPSBlbCA9PiB7XG4gICAgZWwuc2V0QXR0cmlidXRlKCdkYXRhLXNlbGVjdGVkJywgdHJ1ZSlcbiAgICBlbC5zZXRBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnLCBsYWJlbHMubGVuZ3RoKVxuXG4gICAgY2xlYXJIb3ZlcigpXG5cbiAgICBvdmVybGF5TWV0YVVJKGVsKVxuICAgIHNlbGVjdGVkLnVuc2hpZnQoZWwpXG4gICAgdGVsbFdhdGNoZXJzKClcbiAgfVxuXG4gIGNvbnN0IHNlbGVjdGlvbiA9ICgpID0+XG4gICAgc2VsZWN0ZWRcblxuICBjb25zdCB1bnNlbGVjdF9hbGwgPSAoKSA9PiB7XG4gICAgc2VsZWN0ZWRcbiAgICAgIC5mb3JFYWNoKGVsID0+XG4gICAgICAgICQoZWwpLmF0dHIoe1xuICAgICAgICAgICdkYXRhLXNlbGVjdGVkJzogICAgICBudWxsLFxuICAgICAgICAgICdkYXRhLXNlbGVjdGVkLWhpZGUnOiBudWxsLFxuICAgICAgICAgICdkYXRhLWxhYmVsLWlkJzogICAgICBudWxsLFxuICAgICAgICAgICdkYXRhLXBzZXVkby1zZWxlY3QnOiBudWxsLFxuICAgICAgICB9KSlcblxuICAgIEFycmF5LmZyb20oWy4uLmhhbmRsZXMsIC4uLmxhYmVsc10pLmZvckVhY2goZWwgPT5cbiAgICAgIGVsLnJlbW92ZSgpKVxuXG4gICAgbGFiZWxzICAgID0gW11cbiAgICBoYW5kbGVzICAgPSBbXVxuICAgIHNlbGVjdGVkICA9IFtdXG4gIH1cblxuICBjb25zdCBkZWxldGVfYWxsID0gKCkgPT4ge1xuICAgIGNvbnN0IHNlbGVjdGVkX2FmdGVyX2RlbGV0ZSA9IHNlbGVjdGVkLm1hcChlbCA9PiB7XG4gICAgICBpZiAoY2FuTW92ZVJpZ2h0KGVsKSkgICAgIHJldHVybiBjYW5Nb3ZlUmlnaHQoZWwpXG4gICAgICBlbHNlIGlmIChjYW5Nb3ZlTGVmdChlbCkpIHJldHVybiBjYW5Nb3ZlTGVmdChlbClcbiAgICAgIGVsc2UgaWYgKGVsLnBhcmVudE5vZGUpICAgcmV0dXJuIGVsLnBhcmVudE5vZGVcbiAgICB9KVxuXG4gICAgQXJyYXkuZnJvbShbLi4uc2VsZWN0ZWQsIC4uLmxhYmVscywgLi4uaGFuZGxlc10pLmZvckVhY2goZWwgPT5cbiAgICAgIGVsLnJlbW92ZSgpKVxuXG4gICAgbGFiZWxzICAgID0gW11cbiAgICBoYW5kbGVzICAgPSBbXVxuICAgIHNlbGVjdGVkICA9IFtdXG5cbiAgICBzZWxlY3RlZF9hZnRlcl9kZWxldGUuZm9yRWFjaChlbCA9PlxuICAgICAgc2VsZWN0KGVsKSlcbiAgfVxuXG4gIGNvbnN0IGV4cGFuZFNlbGVjdGlvbiA9ICh7cXVlcnksIGFsbCA9IGZhbHNlfSkgPT4ge1xuICAgIGlmIChhbGwpIHtcbiAgICAgIGNvbnN0IHVuc2VsZWN0ZWRzID0gJChxdWVyeSArICc6bm90KFtkYXRhLXNlbGVjdGVkXSknKVxuICAgICAgdW5zZWxlY3RlZHMuZm9yRWFjaChzZWxlY3QpXG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgY29uc3QgcG90ZW50aWFscyA9ICQocXVlcnkpXG4gICAgICBpZiAoIXBvdGVudGlhbHMpIHJldHVyblxuXG4gICAgICBjb25zdCBbYW5jaG9yXSA9IHNlbGVjdGVkXG4gICAgICBjb25zdCByb290X25vZGVfaW5kZXggPSBwb3RlbnRpYWxzLnJlZHVjZSgoaW5kZXgsIG5vZGUsIGkpID0+XG4gICAgICAgIG5vZGUgPT0gYW5jaG9yXG4gICAgICAgICAgPyBpbmRleCA9IGlcbiAgICAgICAgICA6IGluZGV4XG4gICAgICAsIG51bGwpXG5cbiAgICAgIGlmIChyb290X25vZGVfaW5kZXggIT09IG51bGwpIHtcbiAgICAgICAgaWYgKCFwb3RlbnRpYWxzW3Jvb3Rfbm9kZV9pbmRleCArIDFdKSB7XG4gICAgICAgICAgY29uc3QgcG90ZW50aWFsID0gcG90ZW50aWFscy5maWx0ZXIoZWwgPT4gIWVsLmF0dHIoJ2RhdGEtc2VsZWN0ZWQnKSlbMF1cbiAgICAgICAgICBpZiAocG90ZW50aWFsKSBzZWxlY3QocG90ZW50aWFsKVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgIHNlbGVjdChwb3RlbnRpYWxzW3Jvb3Rfbm9kZV9pbmRleCArIDFdKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgY29uc3QgY29tYmluZU5vZGVOYW1lQW5kQ2xhc3MgPSBub2RlID0+XG4gICAgYCR7bm9kZS5ub2RlTmFtZS50b0xvd2VyQ2FzZSgpfSR7Y3JlYXRlQ2xhc3NuYW1lKG5vZGUpfWBcblxuICBjb25zdCBvdmVybGF5SG92ZXJVSSA9IGVsID0+IHtcbiAgICBpZiAoaG92ZXJfc3RhdGUudGFyZ2V0ID09PSBlbCkgcmV0dXJuXG5cbiAgICBob3Zlcl9zdGF0ZS50YXJnZXQgID0gZWxcbiAgICBob3Zlcl9zdGF0ZS5lbGVtZW50ID0gY3JlYXRlSG92ZXIoZWwpXG4gICAgaG92ZXJfc3RhdGUubGFiZWwgPSBjcmVhdGVIb3ZlckxhYmVsKGVsLCBgXG4gICAgICA8YSBub2RlPiR7ZWwubm9kZU5hbWUudG9Mb3dlckNhc2UoKX08L2E+XG4gICAgICA8YT4ke2VsLmlkICYmICcjJyArIGVsLmlkfTwvYT5cbiAgICAgICR7Y3JlYXRlQ2xhc3NuYW1lKGVsKS5zcGxpdCgnLicpXG4gICAgICAgIC5maWx0ZXIobmFtZSA9PiBuYW1lICE9ICcnKVxuICAgICAgICAucmVkdWNlKChsaW5rcywgbmFtZSkgPT4gYFxuICAgICAgICAgICR7bGlua3N9XG4gICAgICAgICAgPGE+LiR7bmFtZX08L2E+XG4gICAgICAgIGAsICcnKVxuICAgICAgfVxuICAgIGApXG4gIH1cblxuICBjb25zdCBjbGVhckhvdmVyID0gKCkgPT4ge1xuICAgIGlmICghaG92ZXJfc3RhdGUudGFyZ2V0KSByZXR1cm5cblxuICAgIGhvdmVyX3N0YXRlLmVsZW1lbnQgJiYgaG92ZXJfc3RhdGUuZWxlbWVudC5yZW1vdmUoKVxuICAgIGhvdmVyX3N0YXRlLmxhYmVsICYmIGhvdmVyX3N0YXRlLmxhYmVsLnJlbW92ZSgpXG5cbiAgICBob3Zlcl9zdGF0ZS50YXJnZXQgID0gbnVsbFxuICAgIGhvdmVyX3N0YXRlLmVsZW1lbnQgPSBudWxsXG4gICAgaG92ZXJfc3RhdGUubGFiZWwgICA9IG51bGxcbiAgfVxuXG4gIGNvbnN0IG92ZXJsYXlNZXRhVUkgPSBlbCA9PiB7XG4gICAgbGV0IGhhbmRsZSA9IGNyZWF0ZUhhbmRsZShlbClcbiAgICBsZXQgbGFiZWwgID0gY3JlYXRlTGFiZWwoZWwsIGBcbiAgICAgIDxhIG5vZGU+JHtlbC5ub2RlTmFtZS50b0xvd2VyQ2FzZSgpfTwvYT5cbiAgICAgIDxhPiR7ZWwuaWQgJiYgJyMnICsgZWwuaWR9PC9hPlxuICAgICAgJHtjcmVhdGVDbGFzc25hbWUoZWwpLnNwbGl0KCcuJylcbiAgICAgICAgLmZpbHRlcihuYW1lID0+IG5hbWUgIT0gJycpXG4gICAgICAgIC5yZWR1Y2UoKGxpbmtzLCBuYW1lKSA9PiBgXG4gICAgICAgICAgJHtsaW5rc31cbiAgICAgICAgICA8YT4uJHtuYW1lfTwvYT5cbiAgICAgICAgYCwgJycpXG4gICAgICB9XG4gICAgYClcblxuICAgIGxldCBvYnNlcnZlciAgICAgICAgPSBjcmVhdGVPYnNlcnZlcihlbCwge2hhbmRsZSxsYWJlbH0pXG4gICAgbGV0IHBhcmVudE9ic2VydmVyICA9IGNyZWF0ZU9ic2VydmVyKGVsLCB7aGFuZGxlLGxhYmVsfSlcblxuICAgIG9ic2VydmVyLm9ic2VydmUoZWwsIHsgYXR0cmlidXRlczogdHJ1ZSB9KVxuICAgIHBhcmVudE9ic2VydmVyLm9ic2VydmUoZWwucGFyZW50Tm9kZSwgeyBjaGlsZExpc3Q6dHJ1ZSwgc3VidHJlZTp0cnVlIH0pXG5cbiAgICAkKGxhYmVsKS5vbignRE9NTm9kZVJlbW92ZWQnLCBfID0+IHtcbiAgICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKVxuICAgICAgcGFyZW50T2JzZXJ2ZXIuZGlzY29ubmVjdCgpXG4gICAgfSlcbiAgfVxuXG4gIGNvbnN0IHNldExhYmVsID0gKGVsLCBsYWJlbCkgPT5cbiAgICBsYWJlbC51cGRhdGUgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKVxuXG4gIGNvbnN0IGNyZWF0ZUxhYmVsID0gKGVsLCB0ZXh0KSA9PiB7XG4gICAgY29uc3QgaWQgPSBwYXJzZUludChlbC5nZXRBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnKSlcblxuICAgIGlmICghbGFiZWxzW2lkXSkge1xuICAgICAgY29uc3QgbGFiZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCd2aXNidWctbGFiZWwnKVxuXG4gICAgICBsYWJlbC50ZXh0ID0gdGV4dFxuICAgICAgbGFiZWwucG9zaXRpb24gPSB7XG4gICAgICAgIGJvdW5kaW5nUmVjdDogICBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSxcbiAgICAgICAgbm9kZV9sYWJlbF9pZDogIGlkLFxuICAgICAgfVxuXG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGxhYmVsKVxuXG4gICAgICAkKGxhYmVsKS5vbigncXVlcnknLCAoe2RldGFpbH0pID0+IHtcbiAgICAgICAgaWYgKCFkZXRhaWwudGV4dCkgcmV0dXJuXG4gICAgICAgIHRoaXMucXVlcnlfdGV4dCA9IGRldGFpbC50ZXh0XG5cbiAgICAgICAgcXVlcnlQYWdlKCdbZGF0YS1wc2V1ZG8tc2VsZWN0XScsIGVsID0+XG4gICAgICAgICAgZWwucmVtb3ZlQXR0cmlidXRlKCdkYXRhLXBzZXVkby1zZWxlY3QnKSlcblxuICAgICAgICBxdWVyeVBhZ2UodGhpcy5xdWVyeV90ZXh0ICsgJzpub3QoW2RhdGEtc2VsZWN0ZWRdKScsIGVsID0+XG4gICAgICAgICAgZGV0YWlsLmFjdGl2YXRvciA9PT0gJ21vdXNlZW50ZXInXG4gICAgICAgICAgICA/IGVsLnNldEF0dHJpYnV0ZSgnZGF0YS1wc2V1ZG8tc2VsZWN0JywgdHJ1ZSlcbiAgICAgICAgICAgIDogc2VsZWN0KGVsKSlcbiAgICAgIH0pXG5cbiAgICAgICQobGFiZWwpLm9uKCdtb3VzZWxlYXZlJywgZSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG4gICAgICAgIHF1ZXJ5UGFnZSgnW2RhdGEtcHNldWRvLXNlbGVjdF0nLCBlbCA9PlxuICAgICAgICAgIGVsLnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1wc2V1ZG8tc2VsZWN0JykpXG4gICAgICB9KVxuXG4gICAgICBsYWJlbHNbbGFiZWxzLmxlbmd0aF0gPSBsYWJlbFxuXG4gICAgICByZXR1cm4gbGFiZWxcbiAgICB9XG4gIH1cblxuICBjb25zdCBjcmVhdGVIYW5kbGUgPSBlbCA9PiB7XG4gICAgY29uc3QgaWQgPSBwYXJzZUludChlbC5nZXRBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnKSlcblxuICAgIGlmICghaGFuZGxlc1tpZF0pIHtcbiAgICAgIGNvbnN0IGhhbmRsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3Zpc2J1Zy1oYW5kbGVzJylcblxuICAgICAgaGFuZGxlLnBvc2l0aW9uID0ge1xuICAgICAgICBib3VuZGluZ1JlY3Q6ICAgZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksXG4gICAgICAgIG5vZGVfbGFiZWxfaWQ6ICBpZCxcbiAgICAgIH1cblxuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChoYW5kbGUpXG5cbiAgICAgIGhhbmRsZXNbaGFuZGxlcy5sZW5ndGhdID0gaGFuZGxlXG4gICAgICByZXR1cm4gaGFuZGxlXG4gICAgfVxuICB9XG5cbiAgY29uc3QgY3JlYXRlSG92ZXIgPSBlbCA9PiB7XG4gICAgaWYgKCFlbC5oYXNBdHRyaWJ1dGUoJ2RhdGEtcHNldWRvLXNlbGVjdCcpICYmICFlbC5oYXNBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnKSkge1xuICAgICAgaWYgKGhvdmVyX3N0YXRlLmVsZW1lbnQpXG4gICAgICAgIGhvdmVyX3N0YXRlLmVsZW1lbnQucmVtb3ZlKClcblxuICAgICAgaG92ZXJfc3RhdGUuZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3Zpc2J1Zy1ob3ZlcicpXG5cbiAgICAgIGhvdmVyX3N0YXRlLmVsZW1lbnQucG9zaXRpb24gPSB7XG4gICAgICAgIGJvdW5kaW5nUmVjdDogZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksXG4gICAgICB9XG5cbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoaG92ZXJfc3RhdGUuZWxlbWVudClcblxuICAgICAgcmV0dXJuIGhvdmVyX3N0YXRlLmVsZW1lbnRcbiAgICB9XG4gIH1cblxuICBjb25zdCBjcmVhdGVIb3ZlckxhYmVsID0gKGVsLCB0ZXh0KSA9PiB7XG4gICAgaWYgKCFlbC5oYXNBdHRyaWJ1dGUoJ2RhdGEtcHNldWRvLXNlbGVjdCcpICYmICFlbC5oYXNBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnKSkge1xuICAgICAgaWYgKGhvdmVyX3N0YXRlLmxhYmVsKVxuICAgICAgICBob3Zlcl9zdGF0ZS5sYWJlbC5yZW1vdmUoKVxuXG4gICAgICBob3Zlcl9zdGF0ZS5sYWJlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3Zpc2J1Zy1sYWJlbCcpXG5cbiAgICAgIGhvdmVyX3N0YXRlLmxhYmVsLnRleHQgPSB0ZXh0XG4gICAgICBob3Zlcl9zdGF0ZS5sYWJlbC5wb3NpdGlvbiA9IHtcbiAgICAgICAgYm91bmRpbmdSZWN0OiAgIGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgICBub2RlX2xhYmVsX2lkOiAgJ2hvdmVyJyxcbiAgICAgIH1cblxuICAgICAgaG92ZXJfc3RhdGUubGFiZWwuc3R5bGUgPSBgLS1sYWJlbC1iZzogaHNsKDI2NywgMTAwJSwgNTglKWBcblxuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChob3Zlcl9zdGF0ZS5sYWJlbClcblxuICAgICAgcmV0dXJuIGhvdmVyX3N0YXRlLmxhYmVsXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgc2V0SGFuZGxlID0gKG5vZGUsIGhhbmRsZSkgPT4ge1xuICAgIGhhbmRsZS5wb3NpdGlvbiA9IHtcbiAgICAgIGJvdW5kaW5nUmVjdDogICBub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgbm9kZV9sYWJlbF9pZDogIG5vZGUuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJyksXG4gICAgfVxuICB9XG5cbiAgY29uc3QgY3JlYXRlT2JzZXJ2ZXIgPSAobm9kZSwge2xhYmVsLGhhbmRsZX0pID0+XG4gICAgbmV3IE11dGF0aW9uT2JzZXJ2ZXIobGlzdCA9PiB7XG4gICAgICBzZXRMYWJlbChub2RlLCBsYWJlbClcbiAgICAgIHNldEhhbmRsZShub2RlLCBoYW5kbGUpXG4gICAgfSlcblxuICBjb25zdCBvblNlbGVjdGVkVXBkYXRlID0gKGNiLCBpbW1lZGlhdGVDYWxsYmFjayA9IHRydWUpID0+IHtcbiAgICBzZWxlY3RlZENhbGxiYWNrcy5wdXNoKGNiKVxuICAgIGlmIChpbW1lZGlhdGVDYWxsYmFjaykgY2Ioc2VsZWN0ZWQpXG4gIH1cblxuICBjb25zdCByZW1vdmVTZWxlY3RlZENhbGxiYWNrID0gY2IgPT5cbiAgICBzZWxlY3RlZENhbGxiYWNrcyA9IHNlbGVjdGVkQ2FsbGJhY2tzLmZpbHRlcihjYWxsYmFjayA9PiBjYWxsYmFjayAhPSBjYilcblxuICBjb25zdCB0ZWxsV2F0Y2hlcnMgPSAoKSA9PlxuICAgIHNlbGVjdGVkQ2FsbGJhY2tzLmZvckVhY2goY2IgPT4gY2Ioc2VsZWN0ZWQpKVxuXG4gIGNvbnN0IGRpc2Nvbm5lY3QgPSAoKSA9PiB7XG4gICAgdW5zZWxlY3RfYWxsKClcbiAgICB1bmxpc3RlbigpXG4gIH1cblxuICBjb25zdCBvbl9zZWxlY3RfY2hpbGRyZW4gPSAoZSwge2tleX0pID0+IHtcbiAgICBjb25zdCB0YXJnZXRzID0gc2VsZWN0ZWRcbiAgICAgIC5maWx0ZXIobm9kZSA9PiBub2RlLmNoaWxkcmVuLmxlbmd0aClcbiAgICAgIC5yZWR1Y2UoKGZsYXQsIHtjaGlsZHJlbn0pID0+XG4gICAgICAgIFsuLi5mbGF0LCAuLi5BcnJheS5mcm9tKGNoaWxkcmVuKV0sIFtdKVxuXG4gICAgaWYgKHRhcmdldHMubGVuZ3RoKSB7XG4gICAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcblxuICAgICAgdW5zZWxlY3RfYWxsKClcbiAgICAgIHRhcmdldHMuZm9yRWFjaChub2RlID0+IHNlbGVjdChub2RlKSlcbiAgICB9XG4gIH1cblxuICB3YXRjaEltYWdlc0ZvclVwbG9hZCgpXG4gIGxpc3RlbigpXG5cbiAgcmV0dXJuIHtcbiAgICBzZWxlY3QsXG4gICAgc2VsZWN0aW9uLFxuICAgIHVuc2VsZWN0X2FsbCxcbiAgICBvblNlbGVjdGVkVXBkYXRlLFxuICAgIHJlbW92ZVNlbGVjdGVkQ2FsbGJhY2ssXG4gICAgZGlzY29ubmVjdCxcbiAgfVxufVxuIiwiaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCB7IG1ldGFLZXksIGdldFN0eWxlLCBnZXRTaWRlLCBzaG93SGlkZVNlbGVjdGVkIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuLy8gdG9kbzogc2hvdyBwYWRkaW5nIGNvbG9yXG5jb25zdCBrZXlfZXZlbnRzID0gJ3VwLGRvd24sbGVmdCxyaWdodCdcbiAgLnNwbGl0KCcsJylcbiAgLnJlZHVjZSgoZXZlbnRzLCBldmVudCkgPT5cbiAgICBgJHtldmVudHN9LCR7ZXZlbnR9LGFsdCske2V2ZW50fSxzaGlmdCske2V2ZW50fSxzaGlmdCthbHQrJHtldmVudH1gXG4gICwgJycpXG4gIC5zdWJzdHJpbmcoMSlcblxuY29uc3QgY29tbWFuZF9ldmVudHMgPSBgJHttZXRhS2V5fSt1cCwke21ldGFLZXl9K3NoaWZ0K3VwLCR7bWV0YUtleX0rZG93biwke21ldGFLZXl9K3NoaWZ0K2Rvd25gXG5cbmV4cG9ydCBmdW5jdGlvbiBQYWRkaW5nKHtzZWxlY3Rpb259KSB7XG4gIGhvdGtleXMoa2V5X2V2ZW50cywgKGUsIGhhbmRsZXIpID0+IHtcbiAgICBpZiAoZS5jYW5jZWxCdWJibGUpIHJldHVyblxuXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgcGFkRWxlbWVudChzZWxlY3Rpb24oKSwgaGFuZGxlci5rZXkpXG4gIH0pXG5cbiAgaG90a2V5cyhjb21tYW5kX2V2ZW50cywgKGUsIGhhbmRsZXIpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBwYWRBbGxFbGVtZW50U2lkZXMoc2VsZWN0aW9uKCksIGhhbmRsZXIua2V5KVxuICB9KVxuXG4gIHJldHVybiAoKSA9PiB7XG4gICAgaG90a2V5cy51bmJpbmQoa2V5X2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZChjb21tYW5kX2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZCgndXAsZG93bixsZWZ0LHJpZ2h0JykgLy8gYnVnIGluIGxpYj9cbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFkRWxlbWVudChlbHMsIGRpcmVjdGlvbikge1xuICBlbHNcbiAgICAubWFwKGVsID0+IHNob3dIaWRlU2VsZWN0ZWQoZWwpKVxuICAgIC5tYXAoZWwgPT4gKHtcbiAgICAgIGVsLFxuICAgICAgc3R5bGU6ICAgICdwYWRkaW5nJyArIGdldFNpZGUoZGlyZWN0aW9uKSxcbiAgICAgIGN1cnJlbnQ6ICBwYXJzZUludChnZXRTdHlsZShlbCwgJ3BhZGRpbmcnICsgZ2V0U2lkZShkaXJlY3Rpb24pKSwgMTApLFxuICAgICAgYW1vdW50OiAgIGRpcmVjdGlvbi5zcGxpdCgnKycpLmluY2x1ZGVzKCdzaGlmdCcpID8gMTAgOiAxLFxuICAgICAgbmVnYXRpdmU6IGRpcmVjdGlvbi5zcGxpdCgnKycpLmluY2x1ZGVzKCdhbHQnKSxcbiAgICB9KSlcbiAgICAubWFwKHBheWxvYWQgPT5cbiAgICAgIE9iamVjdC5hc3NpZ24ocGF5bG9hZCwge1xuICAgICAgICBwYWRkaW5nOiBwYXlsb2FkLm5lZ2F0aXZlXG4gICAgICAgICAgPyBwYXlsb2FkLmN1cnJlbnQgLSBwYXlsb2FkLmFtb3VudFxuICAgICAgICAgIDogcGF5bG9hZC5jdXJyZW50ICsgcGF5bG9hZC5hbW91bnRcbiAgICAgIH0pKVxuICAgIC5mb3JFYWNoKCh7ZWwsIHN0eWxlLCBwYWRkaW5nfSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IGAke3BhZGRpbmcgPCAwID8gMCA6IHBhZGRpbmd9cHhgKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFkQWxsRWxlbWVudFNpZGVzKGVscywga2V5Y29tbWFuZCkge1xuICBjb25zdCBjb21ibyA9IGtleWNvbW1hbmQuc3BsaXQoJysnKVxuICBsZXQgc3Bvb2YgPSAnJ1xuXG4gIGlmIChjb21iby5pbmNsdWRlcygnc2hpZnQnKSkgIHNwb29mID0gJ3NoaWZ0KycgKyBzcG9vZlxuICBpZiAoY29tYm8uaW5jbHVkZXMoJ2Rvd24nKSkgICBzcG9vZiA9ICdhbHQrJyArIHNwb29mXG5cbiAgJ3VwLGRvd24sbGVmdCxyaWdodCcuc3BsaXQoJywnKVxuICAgIC5mb3JFYWNoKHNpZGUgPT4gcGFkRWxlbWVudChlbHMsIHNwb29mICsgc2lkZSkpXG59XG4iLCJpbXBvcnQgJCBmcm9tICdibGluZ2JsaW5nanMnXG5pbXBvcnQgaG90a2V5cyBmcm9tICdob3RrZXlzLWpzJ1xuaW1wb3J0IHsgc2hvd0hpZGVOb2RlTGFiZWwgfSBmcm9tICcuLi91dGlsaXRpZXMvJ1xuXG5jb25zdCByZW1vdmVFZGl0YWJpbGl0eSA9ICh7dGFyZ2V0fSkgPT4ge1xuICB0YXJnZXQucmVtb3ZlQXR0cmlidXRlKCdjb250ZW50ZWRpdGFibGUnKVxuICB0YXJnZXQucmVtb3ZlQXR0cmlidXRlKCdzcGVsbGNoZWNrJylcbiAgdGFyZ2V0LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2JsdXInLCByZW1vdmVFZGl0YWJpbGl0eSlcbiAgdGFyZ2V0LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBzdG9wQnViYmxpbmcpXG4gIGhvdGtleXMudW5iaW5kKCdlc2NhcGUsZXNjJylcbn1cblxuY29uc3Qgc3RvcEJ1YmJsaW5nID0gZSA9PiBlLmtleSAhPSAnRXNjYXBlJyAmJiBlLnN0b3BQcm9wYWdhdGlvbigpXG5cbmNvbnN0IGNsZWFudXAgPSAoZSwgaGFuZGxlcikgPT4ge1xuICAkKCdbc3BlbGxjaGVjaz1cInRydWVcIl0nKS5mb3JFYWNoKHRhcmdldCA9PiByZW1vdmVFZGl0YWJpbGl0eSh7dGFyZ2V0fSkpXG4gIHdpbmRvdy5nZXRTZWxlY3Rpb24oKS5lbXB0eSgpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBFZGl0VGV4dChlbGVtZW50cykge1xuICBpZiAoIWVsZW1lbnRzLmxlbmd0aCkgcmV0dXJuXG5cbiAgZWxlbWVudHMubWFwKGVsID0+IHtcbiAgICBsZXQgJGVsID0gJChlbClcblxuICAgICRlbC5hdHRyKHtcbiAgICAgIGNvbnRlbnRlZGl0YWJsZTogdHJ1ZSxcbiAgICAgIHNwZWxsY2hlY2s6IHRydWUsXG4gICAgfSlcbiAgICBlbC5mb2N1cygpXG4gICAgc2hvd0hpZGVOb2RlTGFiZWwoZWwsIHRydWUpXG5cbiAgICAkZWwub24oJ2tleWRvd24nLCBzdG9wQnViYmxpbmcpXG4gICAgJGVsLm9uKCdibHVyJywgcmVtb3ZlRWRpdGFiaWxpdHkpXG4gIH0pXG5cbiAgaG90a2V5cygnZXNjYXBlLGVzYycsIGNsZWFudXApXG59IiwiaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCB7IG1ldGFLZXksIGdldFN0eWxlLCBzaG93SGlkZVNlbGVjdGVkIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuY29uc3Qga2V5X2V2ZW50cyA9ICd1cCxkb3duLGxlZnQscmlnaHQnXG4gIC5zcGxpdCgnLCcpXG4gIC5yZWR1Y2UoKGV2ZW50cywgZXZlbnQpID0+XG4gICAgYCR7ZXZlbnRzfSwke2V2ZW50fSxzaGlmdCske2V2ZW50fWBcbiAgLCAnJylcbiAgLnN1YnN0cmluZygxKVxuXG5jb25zdCBjb21tYW5kX2V2ZW50cyA9IGAke21ldGFLZXl9K3VwLCR7bWV0YUtleX0rZG93bmBcblxuZXhwb3J0IGZ1bmN0aW9uIEZvbnQoe3NlbGVjdGlvbn0pIHtcbiAgaG90a2V5cyhrZXlfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGlmIChlLmNhbmNlbEJ1YmJsZSkgcmV0dXJuXG5cbiAgICBlLnByZXZlbnREZWZhdWx0KClcblxuICAgIGxldCBzZWxlY3RlZE5vZGVzID0gc2VsZWN0aW9uKClcbiAgICAgICwga2V5cyA9IGhhbmRsZXIua2V5LnNwbGl0KCcrJylcblxuICAgIGlmIChrZXlzLmluY2x1ZGVzKCdsZWZ0JykgfHwga2V5cy5pbmNsdWRlcygncmlnaHQnKSlcbiAgICAgIGtleXMuaW5jbHVkZXMoJ3NoaWZ0JylcbiAgICAgICAgPyBjaGFuZ2VLZXJuaW5nKHNlbGVjdGVkTm9kZXMsIGhhbmRsZXIua2V5KVxuICAgICAgICA6IGNoYW5nZUFsaWdubWVudChzZWxlY3RlZE5vZGVzLCBoYW5kbGVyLmtleSlcbiAgICBlbHNlXG4gICAgICBrZXlzLmluY2x1ZGVzKCdzaGlmdCcpXG4gICAgICAgID8gY2hhbmdlTGVhZGluZyhzZWxlY3RlZE5vZGVzLCBoYW5kbGVyLmtleSlcbiAgICAgICAgOiBjaGFuZ2VGb250U2l6ZShzZWxlY3RlZE5vZGVzLCBoYW5kbGVyLmtleSlcbiAgfSlcblxuICBob3RrZXlzKGNvbW1hbmRfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGxldCBrZXlzID0gaGFuZGxlci5rZXkuc3BsaXQoJysnKVxuICAgIGNoYW5nZUZvbnRXZWlnaHQoc2VsZWN0aW9uKCksIGtleXMuaW5jbHVkZXMoJ3VwJykgPyAndXAnIDogJ2Rvd24nKVxuICB9KVxuXG4gIGhvdGtleXMoJ2NtZCtiJywgZSA9PiB7XG4gICAgc2VsZWN0aW9uKCkuZm9yRWFjaChlbCA9PlxuICAgICAgZWwuc3R5bGUuZm9udFdlaWdodCA9XG4gICAgICAgIGVsLnN0eWxlLmZvbnRXZWlnaHQgPT0gJ2JvbGQnXG4gICAgICAgICAgPyBudWxsXG4gICAgICAgICAgOiAnYm9sZCcpXG4gIH0pXG5cbiAgaG90a2V5cygnY21kK2knLCBlID0+IHtcbiAgICBzZWxlY3Rpb24oKS5mb3JFYWNoKGVsID0+XG4gICAgICBlbC5zdHlsZS5mb250U3R5bGUgPVxuICAgICAgICBlbC5zdHlsZS5mb250U3R5bGUgPT0gJ2l0YWxpYydcbiAgICAgICAgICA/IG51bGxcbiAgICAgICAgICA6ICdpdGFsaWMnKVxuICB9KVxuXG4gIHJldHVybiAoKSA9PiB7XG4gICAgaG90a2V5cy51bmJpbmQoa2V5X2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZChjb21tYW5kX2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZCgnY21kK2IsY21kK2knKVxuICAgIGhvdGtleXMudW5iaW5kKCd1cCxkb3duLGxlZnQscmlnaHQnKVxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjaGFuZ2VMZWFkaW5nKGVscywgZGlyZWN0aW9uKSB7XG4gIGVsc1xuICAgIC5tYXAoZWwgPT4gc2hvd0hpZGVTZWxlY3RlZChlbCkpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgZWwsXG4gICAgICBzdHlsZTogICAgJ2xpbmVIZWlnaHQnLFxuICAgICAgY3VycmVudDogIHBhcnNlSW50KGdldFN0eWxlKGVsLCAnbGluZUhlaWdodCcpKSxcbiAgICAgIGFtb3VudDogICAxLFxuICAgICAgbmVnYXRpdmU6IGRpcmVjdGlvbi5zcGxpdCgnKycpLmluY2x1ZGVzKCdkb3duJyksXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgY3VycmVudDogcGF5bG9hZC5jdXJyZW50ID09ICdub3JtYWwnIHx8IGlzTmFOKHBheWxvYWQuY3VycmVudClcbiAgICAgICAgICA/IDEuMTQgKiBwYXJzZUludChnZXRTdHlsZShwYXlsb2FkLmVsLCAnZm9udFNpemUnKSkgLy8gZG9jdW1lbnQgdGhpcyBjaG9pY2VcbiAgICAgICAgICA6IHBheWxvYWQuY3VycmVudFxuICAgICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgdmFsdWU6IHBheWxvYWQubmVnYXRpdmVcbiAgICAgICAgICA/IHBheWxvYWQuY3VycmVudCAtIHBheWxvYWQuYW1vdW50XG4gICAgICAgICAgOiBwYXlsb2FkLmN1cnJlbnQgKyBwYXlsb2FkLmFtb3VudFxuICAgICAgfSkpXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIHZhbHVlfSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IGAke3ZhbHVlfXB4YClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZUtlcm5pbmcoZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbCA9PiBzaG93SGlkZVNlbGVjdGVkKGVsKSlcbiAgICAubWFwKGVsID0+ICh7XG4gICAgICBlbCxcbiAgICAgIHN0eWxlOiAgICAnbGV0dGVyU3BhY2luZycsXG4gICAgICBjdXJyZW50OiAgcGFyc2VGbG9hdChnZXRTdHlsZShlbCwgJ2xldHRlclNwYWNpbmcnKSksXG4gICAgICBhbW91bnQ6ICAgLjEsXG4gICAgICBuZWdhdGl2ZTogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ2xlZnQnKSxcbiAgICB9KSlcbiAgICAubWFwKHBheWxvYWQgPT5cbiAgICAgIE9iamVjdC5hc3NpZ24ocGF5bG9hZCwge1xuICAgICAgICBjdXJyZW50OiBwYXlsb2FkLmN1cnJlbnQgPT0gJ25vcm1hbCcgfHwgaXNOYU4ocGF5bG9hZC5jdXJyZW50KVxuICAgICAgICAgID8gMFxuICAgICAgICAgIDogcGF5bG9hZC5jdXJyZW50XG4gICAgICB9KSlcbiAgICAubWFwKHBheWxvYWQgPT5cbiAgICAgIE9iamVjdC5hc3NpZ24ocGF5bG9hZCwge1xuICAgICAgICB2YWx1ZTogcGF5bG9hZC5uZWdhdGl2ZVxuICAgICAgICAgID8gKHBheWxvYWQuY3VycmVudCAtIHBheWxvYWQuYW1vdW50KS50b0ZpeGVkKDIpXG4gICAgICAgICAgOiAocGF5bG9hZC5jdXJyZW50ICsgcGF5bG9hZC5hbW91bnQpLnRvRml4ZWQoMilcbiAgICAgIH0pKVxuICAgIC5mb3JFYWNoKCh7ZWwsIHN0eWxlLCB2YWx1ZX0pID0+XG4gICAgICBlbC5zdHlsZVtzdHlsZV0gPSBgJHt2YWx1ZSA8PSAtMiA/IC0yIDogdmFsdWV9cHhgKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY2hhbmdlRm9udFNpemUoZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbCA9PiBzaG93SGlkZVNlbGVjdGVkKGVsKSlcbiAgICAubWFwKGVsID0+ICh7XG4gICAgICBlbCxcbiAgICAgIHN0eWxlOiAgICAnZm9udFNpemUnLFxuICAgICAgY3VycmVudDogIHBhcnNlSW50KGdldFN0eWxlKGVsLCAnZm9udFNpemUnKSksXG4gICAgICBhbW91bnQ6ICAgZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ3NoaWZ0JykgPyAxMCA6IDEsXG4gICAgICBuZWdhdGl2ZTogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ2Rvd24nKSxcbiAgICB9KSlcbiAgICAubWFwKHBheWxvYWQgPT5cbiAgICAgIE9iamVjdC5hc3NpZ24ocGF5bG9hZCwge1xuICAgICAgICBmb250X3NpemU6IHBheWxvYWQubmVnYXRpdmVcbiAgICAgICAgICA/IHBheWxvYWQuY3VycmVudCAtIHBheWxvYWQuYW1vdW50XG4gICAgICAgICAgOiBwYXlsb2FkLmN1cnJlbnQgKyBwYXlsb2FkLmFtb3VudFxuICAgICAgfSkpXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIGZvbnRfc2l6ZX0pID0+XG4gICAgICBlbC5zdHlsZVtzdHlsZV0gPSBgJHtmb250X3NpemUgPD0gNiA/IDYgOiBmb250X3NpemV9cHhgKVxufVxuXG5jb25zdCB3ZWlnaHRNYXAgPSB7XG4gIG5vcm1hbDogMixcbiAgYm9sZDogICA1LFxuICBsaWdodDogIDAsXG4gIFwiXCI6IDIsXG4gIFwiMTAwXCI6MCxcIjIwMFwiOjEsXCIzMDBcIjoyLFwiNDAwXCI6MyxcIjUwMFwiOjQsXCI2MDBcIjo1LFwiNzAwXCI6NixcIjgwMFwiOjcsXCI5MDBcIjo4XG59XG5jb25zdCB3ZWlnaHRPcHRpb25zID0gWzEwMCwyMDAsMzAwLDQwMCw1MDAsNjAwLDcwMCw4MDAsOTAwXVxuXG5leHBvcnQgZnVuY3Rpb24gY2hhbmdlRm9udFdlaWdodChlbHMsIGRpcmVjdGlvbikge1xuICBlbHNcbiAgICAubWFwKGVsID0+IHNob3dIaWRlU2VsZWN0ZWQoZWwpKVxuICAgIC5tYXAoZWwgPT4gKHtcbiAgICAgIGVsLFxuICAgICAgc3R5bGU6ICAgICdmb250V2VpZ2h0JyxcbiAgICAgIGN1cnJlbnQ6ICBnZXRTdHlsZShlbCwgJ2ZvbnRXZWlnaHQnKSxcbiAgICAgIGRpcmVjdGlvbjogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ2Rvd24nKSxcbiAgICB9KSlcbiAgICAubWFwKHBheWxvYWQgPT5cbiAgICAgIE9iamVjdC5hc3NpZ24ocGF5bG9hZCwge1xuICAgICAgICB2YWx1ZTogcGF5bG9hZC5kaXJlY3Rpb25cbiAgICAgICAgICA/IHdlaWdodE1hcFtwYXlsb2FkLmN1cnJlbnRdIC0gMVxuICAgICAgICAgIDogd2VpZ2h0TWFwW3BheWxvYWQuY3VycmVudF0gKyAxXG4gICAgICB9KSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgdmFsdWV9KSA9PlxuICAgICAgZWwuc3R5bGVbc3R5bGVdID0gd2VpZ2h0T3B0aW9uc1t2YWx1ZSA8IDAgPyAwIDogdmFsdWUgPj0gd2VpZ2h0T3B0aW9ucy5sZW5ndGhcbiAgICAgICAgPyB3ZWlnaHRPcHRpb25zLmxlbmd0aFxuICAgICAgICA6IHZhbHVlXG4gICAgICBdKVxufVxuXG5jb25zdCBhbGlnbk1hcCA9IHtcbiAgc3RhcnQ6IDAsXG4gIGxlZnQ6IDAsXG4gIGNlbnRlcjogMSxcbiAgcmlnaHQ6IDIsXG59XG5jb25zdCBhbGlnbk9wdGlvbnMgPSBbJ2xlZnQnLCdjZW50ZXInLCdyaWdodCddXG5cbmV4cG9ydCBmdW5jdGlvbiBjaGFuZ2VBbGlnbm1lbnQoZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbCA9PiBzaG93SGlkZVNlbGVjdGVkKGVsKSlcbiAgICAubWFwKGVsID0+ICh7XG4gICAgICBlbCxcbiAgICAgIHN0eWxlOiAgICAndGV4dEFsaWduJyxcbiAgICAgIGN1cnJlbnQ6ICBnZXRTdHlsZShlbCwgJ3RleHRBbGlnbicpLFxuICAgICAgZGlyZWN0aW9uOiBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygnbGVmdCcpLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIHZhbHVlOiBwYXlsb2FkLmRpcmVjdGlvblxuICAgICAgICAgID8gYWxpZ25NYXBbcGF5bG9hZC5jdXJyZW50XSAtIDFcbiAgICAgICAgICA6IGFsaWduTWFwW3BheWxvYWQuY3VycmVudF0gKyAxXG4gICAgICB9KSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgdmFsdWV9KSA9PlxuICAgICAgZWwuc3R5bGVbc3R5bGVdID0gYWxpZ25PcHRpb25zW3ZhbHVlIDwgMCA/IDAgOiB2YWx1ZSA+PSAyID8gMjogdmFsdWVdKVxufVxuIiwiaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCB7IG1ldGFLZXksIGdldFN0eWxlIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuY29uc3Qga2V5X2V2ZW50cyA9ICd1cCxkb3duLGxlZnQscmlnaHQnXG4gIC5zcGxpdCgnLCcpXG4gIC5yZWR1Y2UoKGV2ZW50cywgZXZlbnQpID0+XG4gICAgYCR7ZXZlbnRzfSwke2V2ZW50fSxzaGlmdCske2V2ZW50fWBcbiAgLCAnJylcbiAgLnN1YnN0cmluZygxKVxuXG5jb25zdCBjb21tYW5kX2V2ZW50cyA9IGAke21ldGFLZXl9K3VwLCR7bWV0YUtleX0rZG93biwke21ldGFLZXl9K2xlZnQsJHttZXRhS2V5fStyaWdodGBcblxuZXhwb3J0IGZ1bmN0aW9uIEZsZXgoe3NlbGVjdGlvbn0pIHtcbiAgaG90a2V5cyhrZXlfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGlmIChlLmNhbmNlbEJ1YmJsZSkgcmV0dXJuXG5cbiAgICBlLnByZXZlbnREZWZhdWx0KClcblxuICAgIGxldCBzZWxlY3RlZE5vZGVzID0gc2VsZWN0aW9uKClcbiAgICAgICwga2V5cyA9IGhhbmRsZXIua2V5LnNwbGl0KCcrJylcblxuICAgIGlmIChrZXlzLmluY2x1ZGVzKCdsZWZ0JykgfHwga2V5cy5pbmNsdWRlcygncmlnaHQnKSlcbiAgICAgIGtleXMuaW5jbHVkZXMoJ3NoaWZ0JylcbiAgICAgICAgPyBjaGFuZ2VIRGlzdHJpYnV0aW9uKHNlbGVjdGVkTm9kZXMsIGhhbmRsZXIua2V5KVxuICAgICAgICA6IGNoYW5nZUhBbGlnbm1lbnQoc2VsZWN0ZWROb2RlcywgaGFuZGxlci5rZXkpXG4gICAgZWxzZVxuICAgICAga2V5cy5pbmNsdWRlcygnc2hpZnQnKVxuICAgICAgICA/IGNoYW5nZVZEaXN0cmlidXRpb24oc2VsZWN0ZWROb2RlcywgaGFuZGxlci5rZXkpXG4gICAgICAgIDogY2hhbmdlVkFsaWdubWVudChzZWxlY3RlZE5vZGVzLCBoYW5kbGVyLmtleSlcbiAgfSlcblxuICBob3RrZXlzKGNvbW1hbmRfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuXG4gICAgbGV0IHNlbGVjdGVkTm9kZXMgPSBzZWxlY3Rpb24oKVxuICAgICAgLCBrZXlzID0gaGFuZGxlci5rZXkuc3BsaXQoJysnKVxuXG4gICAgY2hhbmdlRGlyZWN0aW9uKHNlbGVjdGVkTm9kZXMsIGtleXMuaW5jbHVkZXMoJ2xlZnQnKSA/ICdyb3cnIDogJ2NvbHVtbicpXG4gIH0pXG5cbiAgcmV0dXJuICgpID0+IHtcbiAgICBob3RrZXlzLnVuYmluZChrZXlfZXZlbnRzKVxuICAgIGhvdGtleXMudW5iaW5kKGNvbW1hbmRfZXZlbnRzKVxuICAgIGhvdGtleXMudW5iaW5kKCd1cCxkb3duLGxlZnQscmlnaHQnKVxuICB9XG59XG5cbmNvbnN0IGVuc3VyZUZsZXggPSBlbCA9PiB7XG4gIGVsLnN0eWxlLmRpc3BsYXkgPSAnZmxleCdcbiAgcmV0dXJuIGVsXG59XG5cbmNvbnN0IGFjY291bnRGb3JPdGhlckp1c3RpZnlDb250ZW50ID0gKGN1ciwgd2FudCkgPT4ge1xuICBpZiAod2FudCA9PSAnYWxpZ24nICYmIChjdXIgIT0gJ2ZsZXgtc3RhcnQnICYmIGN1ciAhPSAnY2VudGVyJyAmJiBjdXIgIT0gJ2ZsZXgtZW5kJykpXG4gICAgY3VyID0gJ25vcm1hbCdcbiAgZWxzZSBpZiAod2FudCA9PSAnZGlzdHJpYnV0ZScgJiYgKGN1ciAhPSAnc3BhY2UtYXJvdW5kJyAmJiBjdXIgIT0gJ3NwYWNlLWJldHdlZW4nKSlcbiAgICBjdXIgPSAnbm9ybWFsJ1xuXG4gIHJldHVybiBjdXJcbn1cblxuLy8gdG9kbzogc3VwcG9ydCByZXZlcnNpbmcgZGlyZWN0aW9uXG5leHBvcnQgZnVuY3Rpb24gY2hhbmdlRGlyZWN0aW9uKGVscywgdmFsdWUpIHtcbiAgZWxzXG4gICAgLm1hcChlbnN1cmVGbGV4KVxuICAgIC5tYXAoZWwgPT4ge1xuICAgICAgZWwuc3R5bGUuZmxleERpcmVjdGlvbiA9IHZhbHVlXG4gICAgfSlcbn1cblxuY29uc3QgaF9hbGlnbk1hcCAgICAgID0ge25vcm1hbDogMCwnZmxleC1zdGFydCc6IDAsJ2NlbnRlcic6IDEsJ2ZsZXgtZW5kJzogMix9XG5jb25zdCBoX2FsaWduT3B0aW9ucyAgPSBbJ2ZsZXgtc3RhcnQnLCdjZW50ZXInLCdmbGV4LWVuZCddXG5cbmV4cG9ydCBmdW5jdGlvbiBjaGFuZ2VIQWxpZ25tZW50KGVscywgZGlyZWN0aW9uKSB7XG4gIGVsc1xuICAgIC5tYXAoZW5zdXJlRmxleClcbiAgICAubWFwKGVsID0+ICh7XG4gICAgICBlbCxcbiAgICAgIHN0eWxlOiAgICAnanVzdGlmeUNvbnRlbnQnLFxuICAgICAgY3VycmVudDogIGFjY291bnRGb3JPdGhlckp1c3RpZnlDb250ZW50KGdldFN0eWxlKGVsLCAnanVzdGlmeUNvbnRlbnQnKSwgJ2FsaWduJyksXG4gICAgICBkaXJlY3Rpb246IGRpcmVjdGlvbi5zcGxpdCgnKycpLmluY2x1ZGVzKCdsZWZ0JyksXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgdmFsdWU6IHBheWxvYWQuZGlyZWN0aW9uXG4gICAgICAgICAgPyBoX2FsaWduTWFwW3BheWxvYWQuY3VycmVudF0gLSAxXG4gICAgICAgICAgOiBoX2FsaWduTWFwW3BheWxvYWQuY3VycmVudF0gKyAxXG4gICAgICB9KSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgdmFsdWV9KSA9PlxuICAgICAgZWwuc3R5bGVbc3R5bGVdID0gaF9hbGlnbk9wdGlvbnNbdmFsdWUgPCAwID8gMCA6IHZhbHVlID49IDIgPyAyOiB2YWx1ZV0pXG59XG5cbmNvbnN0IHZfYWxpZ25NYXAgICAgICA9IHtub3JtYWw6IDAsJ2ZsZXgtc3RhcnQnOiAwLCdjZW50ZXInOiAxLCdmbGV4LWVuZCc6IDIsfVxuY29uc3Qgdl9hbGlnbk9wdGlvbnMgID0gWydmbGV4LXN0YXJ0JywnY2VudGVyJywnZmxleC1lbmQnXVxuXG5leHBvcnQgZnVuY3Rpb24gY2hhbmdlVkFsaWdubWVudChlbHMsIGRpcmVjdGlvbikge1xuICBlbHNcbiAgICAubWFwKGVuc3VyZUZsZXgpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgZWwsXG4gICAgICBzdHlsZTogICAgJ2FsaWduSXRlbXMnLFxuICAgICAgY3VycmVudDogIGdldFN0eWxlKGVsLCAnYWxpZ25JdGVtcycpLFxuICAgICAgZGlyZWN0aW9uOiBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygndXAnKSxcbiAgICB9KSlcbiAgICAubWFwKHBheWxvYWQgPT5cbiAgICAgIE9iamVjdC5hc3NpZ24ocGF5bG9hZCwge1xuICAgICAgICB2YWx1ZTogcGF5bG9hZC5kaXJlY3Rpb25cbiAgICAgICAgICA/IGhfYWxpZ25NYXBbcGF5bG9hZC5jdXJyZW50XSAtIDFcbiAgICAgICAgICA6IGhfYWxpZ25NYXBbcGF5bG9hZC5jdXJyZW50XSArIDFcbiAgICAgIH0pKVxuICAgIC5mb3JFYWNoKCh7ZWwsIHN0eWxlLCB2YWx1ZX0pID0+XG4gICAgICBlbC5zdHlsZVtzdHlsZV0gPSB2X2FsaWduT3B0aW9uc1t2YWx1ZSA8IDAgPyAwIDogdmFsdWUgPj0gMiA/IDI6IHZhbHVlXSlcbn1cblxuY29uc3QgaF9kaXN0cmlidXRpb25NYXAgICAgICA9IHtub3JtYWw6IDEsJ3NwYWNlLWFyb3VuZCc6IDAsJyc6IDEsJ3NwYWNlLWJldHdlZW4nOiAyLH1cbmNvbnN0IGhfZGlzdHJpYnV0aW9uT3B0aW9ucyAgPSBbJ3NwYWNlLWFyb3VuZCcsJycsJ3NwYWNlLWJldHdlZW4nXVxuXG5leHBvcnQgZnVuY3Rpb24gY2hhbmdlSERpc3RyaWJ1dGlvbihlbHMsIGRpcmVjdGlvbikge1xuICBlbHNcbiAgICAubWFwKGVuc3VyZUZsZXgpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgZWwsXG4gICAgICBzdHlsZTogICAgJ2p1c3RpZnlDb250ZW50JyxcbiAgICAgIGN1cnJlbnQ6ICBhY2NvdW50Rm9yT3RoZXJKdXN0aWZ5Q29udGVudChnZXRTdHlsZShlbCwgJ2p1c3RpZnlDb250ZW50JyksICdkaXN0cmlidXRlJyksXG4gICAgICBkaXJlY3Rpb246IGRpcmVjdGlvbi5zcGxpdCgnKycpLmluY2x1ZGVzKCdsZWZ0JyksXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgdmFsdWU6IHBheWxvYWQuZGlyZWN0aW9uXG4gICAgICAgICAgPyBoX2Rpc3RyaWJ1dGlvbk1hcFtwYXlsb2FkLmN1cnJlbnRdIC0gMVxuICAgICAgICAgIDogaF9kaXN0cmlidXRpb25NYXBbcGF5bG9hZC5jdXJyZW50XSArIDFcbiAgICAgIH0pKVxuICAgIC5mb3JFYWNoKCh7ZWwsIHN0eWxlLCB2YWx1ZX0pID0+XG4gICAgICBlbC5zdHlsZVtzdHlsZV0gPSBoX2Rpc3RyaWJ1dGlvbk9wdGlvbnNbdmFsdWUgPCAwID8gMCA6IHZhbHVlID49IDIgPyAyOiB2YWx1ZV0pXG59XG5cbmNvbnN0IHZfZGlzdHJpYnV0aW9uTWFwICAgICAgPSB7bm9ybWFsOiAxLCdzcGFjZS1hcm91bmQnOiAwLCcnOiAxLCdzcGFjZS1iZXR3ZWVuJzogMix9XG5jb25zdCB2X2Rpc3RyaWJ1dGlvbk9wdGlvbnMgID0gWydzcGFjZS1hcm91bmQnLCcnLCdzcGFjZS1iZXR3ZWVuJ11cblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZVZEaXN0cmlidXRpb24oZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbnN1cmVGbGV4KVxuICAgIC5tYXAoZWwgPT4gKHtcbiAgICAgIGVsLFxuICAgICAgc3R5bGU6ICAgICdhbGlnbkNvbnRlbnQnLFxuICAgICAgY3VycmVudDogIGdldFN0eWxlKGVsLCAnYWxpZ25Db250ZW50JyksXG4gICAgICBkaXJlY3Rpb246IGRpcmVjdGlvbi5zcGxpdCgnKycpLmluY2x1ZGVzKCd1cCcpLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIHZhbHVlOiBwYXlsb2FkLmRpcmVjdGlvblxuICAgICAgICAgID8gdl9kaXN0cmlidXRpb25NYXBbcGF5bG9hZC5jdXJyZW50XSAtIDFcbiAgICAgICAgICA6IHZfZGlzdHJpYnV0aW9uTWFwW3BheWxvYWQuY3VycmVudF0gKyAxXG4gICAgICB9KSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgdmFsdWV9KSA9PlxuICAgICAgZWwuc3R5bGVbc3R5bGVdID0gdl9kaXN0cmlidXRpb25PcHRpb25zW3ZhbHVlIDwgMCA/IDAgOiB2YWx1ZSA+PSAyID8gMjogdmFsdWVdKVxufVxuIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IHsgVGlueUNvbG9yIH0gZnJvbSAnQGN0cmwvdGlueWNvbG9yJ1xuaW1wb3J0IHsgZ2V0U3R5bGUgfSBmcm9tICcuLi91dGlsaXRpZXMvJ1xuXG5leHBvcnQgZnVuY3Rpb24gQ29sb3JQaWNrZXIocGFsbGV0ZSwgc2VsZWN0b3JFbmdpbmUpIHtcbiAgY29uc3QgZm9yZWdyb3VuZFBpY2tlciAgPSAkKCcjZm9yZWdyb3VuZCcsIHBhbGxldGUpXG4gIGNvbnN0IGJhY2tncm91bmRQaWNrZXIgID0gJCgnI2JhY2tncm91bmQnLCBwYWxsZXRlKVxuICBjb25zdCBib3JkZXJQaWNrZXIgICAgICA9ICQoJyNib3JkZXInLCBwYWxsZXRlKVxuICBjb25zdCBmZ0lucHV0ICAgICAgICAgICA9ICQoJ2lucHV0JywgZm9yZWdyb3VuZFBpY2tlclswXSlcbiAgY29uc3QgYmdJbnB1dCAgICAgICAgICAgPSAkKCdpbnB1dCcsIGJhY2tncm91bmRQaWNrZXJbMF0pXG4gIGNvbnN0IGJvSW5wdXQgICAgICAgICAgID0gJCgnaW5wdXQnLCBib3JkZXJQaWNrZXJbMF0pXG5cbiAgY29uc3Qgc2hhZG93cyA9IHtcbiAgICBhY3RpdmU6ICAgJ3JnYmEoMCwgMCwgMCwgMC4xKSAwcHggMC4yNWVtIDAuNWVtLCAwIDAgMCAycHggaG90cGluaycsXG4gICAgaW5hY3RpdmU6ICdyZ2JhKDAsIDAsIDAsIDAuMSkgMHB4IDAuMjVlbSAwLjVlbScsXG4gIH1cblxuICB0aGlzLmFjdGl2ZV9jb2xvciAgICAgICA9ICdiYWNrZ3JvdW5kJ1xuICB0aGlzLmVsZW1lbnRzICAgICAgICAgICA9IFtdXG5cbiAgLy8gc2V0IGNvbG9yc1xuICBmZ0lucHV0Lm9uKCdpbnB1dCcsIGUgPT5cbiAgICB0aGlzLmVsZW1lbnRzLm1hcChlbCA9PlxuICAgICAgZWwuc3R5bGVbJ2NvbG9yJ10gPSBlLnRhcmdldC52YWx1ZSkpXG5cbiAgYmdJbnB1dC5vbignaW5wdXQnLCBlID0+XG4gICAgdGhpcy5lbGVtZW50cy5tYXAoZWwgPT5cbiAgICAgIGVsLnN0eWxlW2VsIGluc3RhbmNlb2YgU1ZHRWxlbWVudFxuICAgICAgICA/ICdmaWxsJ1xuICAgICAgICA6ICdiYWNrZ3JvdW5kQ29sb3InXG4gICAgICBdID0gZS50YXJnZXQudmFsdWUpKVxuXG4gIGJvSW5wdXQub24oJ2lucHV0JywgZSA9PlxuICAgIHRoaXMuZWxlbWVudHMubWFwKGVsID0+XG4gICAgICBlbC5zdHlsZVtlbCBpbnN0YW5jZW9mIFNWR0VsZW1lbnRcbiAgICAgICAgPyAnc3Ryb2tlJ1xuICAgICAgICA6ICdib3JkZXItY29sb3InXG4gICAgICBdID0gZS50YXJnZXQudmFsdWUpKVxuXG4gIC8vIHJlYWQgY29sb3JzXG4gIHNlbGVjdG9yRW5naW5lLm9uU2VsZWN0ZWRVcGRhdGUoZWxlbWVudHMgPT4ge1xuICAgIGlmICghZWxlbWVudHMubGVuZ3RoKSByZXR1cm5cbiAgICB0aGlzLmVsZW1lbnRzID0gZWxlbWVudHNcblxuICAgIGxldCBpc01lYW5pbmdmdWxGb3JlZ3JvdW5kICA9IGZhbHNlXG4gICAgbGV0IGlzTWVhbmluZ2Z1bEJhY2tncm91bmQgID0gZmFsc2VcbiAgICBsZXQgaXNNZWFuaW5nZnVsQm9yZGVyICAgICAgPSBmYWxzZVxuICAgIGxldCBGRywgQkcsIEJPXG5cbiAgICBpZiAodGhpcy5lbGVtZW50cy5sZW5ndGggPT0gMSkge1xuICAgICAgY29uc3QgZWwgPSB0aGlzLmVsZW1lbnRzWzBdXG4gICAgICBjb25zdCBtZWFuaW5nZnVsRG9udE1hdHRlciA9IHBhbGxldGUuaG9zdC5hY3RpdmVfdG9vbC5kYXRhc2V0LnRvb2wgPT09ICdodWVzaGlmdCdcblxuICAgICAgaWYgKGVsIGluc3RhbmNlb2YgU1ZHRWxlbWVudCkge1xuICAgICAgICBGRyA9IG5ldyBUaW55Q29sb3IoJ3JnYigwLCAwLCAwKScpXG4gICAgICAgIHZhciBib190ZW1wID0gZ2V0U3R5bGUoZWwsICdzdHJva2UnKVxuICAgICAgICBCTyA9IG5ldyBUaW55Q29sb3IoYm9fdGVtcCA9PT0gJ25vbmUnXG4gICAgICAgICAgPyAncmdiKDAsIDAsIDApJ1xuICAgICAgICAgIDogYm9fdGVtcClcbiAgICAgICAgQkcgPSBuZXcgVGlueUNvbG9yKGdldFN0eWxlKGVsLCAnZmlsbCcpKVxuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgIEZHID0gbmV3IFRpbnlDb2xvcihnZXRTdHlsZShlbCwgJ2NvbG9yJykpXG4gICAgICAgIEJHID0gbmV3IFRpbnlDb2xvcihnZXRTdHlsZShlbCwgJ2JhY2tncm91bmRDb2xvcicpKVxuICAgICAgICBCTyA9IGdldFN0eWxlKGVsLCAnYm9yZGVyV2lkdGgnKSA9PT0gJzBweCdcbiAgICAgICAgICA/IG5ldyBUaW55Q29sb3IoJ3JnYigwLCAwLCAwKScpXG4gICAgICAgICAgOiBuZXcgVGlueUNvbG9yKGdldFN0eWxlKGVsLCAnYm9yZGVyQ29sb3InKSlcbiAgICAgIH1cblxuICAgICAgbGV0IGZnID0gRkcudG9IZXhTdHJpbmcoKVxuICAgICAgbGV0IGJnID0gQkcudG9IZXhTdHJpbmcoKVxuICAgICAgbGV0IGJvID0gQk8udG9IZXhTdHJpbmcoKVxuXG4gICAgICBpc01lYW5pbmdmdWxGb3JlZ3JvdW5kID0gRkcub3JpZ2luYWxJbnB1dCAhPT0gJ3JnYigwLCAwLCAwKScgfHwgKGVsLmNoaWxkcmVuLmxlbmd0aCA9PT0gMCAmJiBlbC50ZXh0Q29udGVudCAhPT0gJycpXG4gICAgICBpc01lYW5pbmdmdWxCYWNrZ3JvdW5kID0gQkcub3JpZ2luYWxJbnB1dCAhPT0gJ3JnYmEoMCwgMCwgMCwgMCknXG4gICAgICBpc01lYW5pbmdmdWxCb3JkZXIgICAgID0gQk8ub3JpZ2luYWxJbnB1dCAhPT0gJ3JnYigwLCAwLCAwKSdcblxuICAgICAgaWYgKGlzTWVhbmluZ2Z1bEZvcmVncm91bmQgJiYgIWlzTWVhbmluZ2Z1bEJhY2tncm91bmQpXG4gICAgICAgIHNldEFjdGl2ZSgnZm9yZWdyb3VuZCcpXG4gICAgICBlbHNlIGlmIChpc01lYW5pbmdmdWxCYWNrZ3JvdW5kICYmICFpc01lYW5pbmdmdWxGb3JlZ3JvdW5kKVxuICAgICAgICBzZXRBY3RpdmUoJ2JhY2tncm91bmQnKVxuXG4gICAgICBjb25zdCBuZXdfZmcgPSBpc01lYW5pbmdmdWxGb3JlZ3JvdW5kID8gZmcgOiAnJ1xuICAgICAgY29uc3QgbmV3X2JnID0gaXNNZWFuaW5nZnVsQmFja2dyb3VuZCA/IGJnIDogJydcbiAgICAgIGNvbnN0IG5ld19ibyA9IGlzTWVhbmluZ2Z1bEJvcmRlciA/IGJvIDogJydcblxuICAgICAgZmdJbnB1dC5hdHRyKCd2YWx1ZScsIG5ld19mZylcbiAgICAgIGJnSW5wdXQuYXR0cigndmFsdWUnLCBuZXdfYmcpXG4gICAgICBib0lucHV0LmF0dHIoJ3ZhbHVlJywgbmV3X2JvKVxuXG4gICAgICBmb3JlZ3JvdW5kUGlja2VyLmF0dHIoJ3N0eWxlJywgYFxuICAgICAgICAtLWNvbnRleHR1YWxfY29sb3I6ICR7bmV3X2ZnfTtcbiAgICAgICAgZGlzcGxheTogJHtpc01lYW5pbmdmdWxGb3JlZ3JvdW5kIHx8IG1lYW5pbmdmdWxEb250TWF0dGVyID8gJ2lubGluZS1mbGV4JyA6ICdub25lJ307XG4gICAgICBgKVxuXG4gICAgICBiYWNrZ3JvdW5kUGlja2VyLmF0dHIoJ3N0eWxlJywgYFxuICAgICAgICAtLWNvbnRleHR1YWxfY29sb3I6ICR7bmV3X2JnfTtcbiAgICAgICAgZGlzcGxheTogJHtpc01lYW5pbmdmdWxCYWNrZ3JvdW5kIHx8IG1lYW5pbmdmdWxEb250TWF0dGVyID8gJ2lubGluZS1mbGV4JyA6ICdub25lJ307XG4gICAgICBgKVxuXG4gICAgICBib3JkZXJQaWNrZXIuYXR0cignc3R5bGUnLCBgXG4gICAgICAgIC0tY29udGV4dHVhbF9jb2xvcjogJHtuZXdfYm99O1xuICAgICAgICBkaXNwbGF5OiAke2lzTWVhbmluZ2Z1bEJvcmRlciB8fCBtZWFuaW5nZnVsRG9udE1hdHRlciA/ICdpbmxpbmUtZmxleCcgOiAnbm9uZSd9O1xuICAgICAgYClcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAvLyBzaG93IGFsbCAzIGlmIHRoZXkndmUgc2VsZWN0ZWQgbW9yZSB0aGFuIDEgbm9kZVxuICAgICAgLy8gdG9kbzogdGhpcyBpcyBnaXZpbmcgdXAsIGFuZCBjYW4gYmUgc29sdmVkXG4gICAgICBmb3JlZ3JvdW5kUGlja2VyLmF0dHIoJ3N0eWxlJywgYFxuICAgICAgICBib3gtc2hhZG93OiAke3RoaXMuYWN0aXZlX2NvbG9yID09ICdmb3JlZ3JvdW5kJyA/IHNoYWRvd3MuYWN0aXZlIDogc2hhZG93cy5pbmFjdGl2ZX07XG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICAgICAgYClcblxuICAgICAgYmFja2dyb3VuZFBpY2tlci5hdHRyKCdzdHlsZScsIGBcbiAgICAgICAgYm94LXNoYWRvdzogJHt0aGlzLmFjdGl2ZV9jb2xvciA9PSAnYmFja2dyb3VuZCcgPyBzaGFkb3dzLmFjdGl2ZSA6IHNoYWRvd3MuaW5hY3RpdmV9O1xuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgICAgIGApXG5cbiAgICAgIGJvcmRlclBpY2tlci5hdHRyKCdzdHlsZScsIGBcbiAgICAgICAgYm94LXNoYWRvdzogJHt0aGlzLmFjdGl2ZV9jb2xvciA9PSAnYm9yZGVyJyA/IHNoYWRvd3MuYWN0aXZlIDogc2hhZG93cy5pbmFjdGl2ZX07XG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICAgICAgYClcbiAgICB9XG4gIH0pXG5cbiAgY29uc3QgZ2V0QWN0aXZlID0gKCkgPT5cbiAgICB0aGlzLmFjdGl2ZV9jb2xvclxuXG4gIGNvbnN0IHNldEFjdGl2ZSA9IGtleSA9PiB7XG4gICAgcmVtb3ZlQWN0aXZlKClcbiAgICB0aGlzLmFjdGl2ZV9jb2xvciA9IGtleVxuXG4gICAgaWYgKGtleSA9PT0gJ2ZvcmVncm91bmQnKVxuICAgICAgZm9yZWdyb3VuZFBpY2tlclswXS5zdHlsZS5ib3hTaGFkb3cgPSBzaGFkb3dzLmFjdGl2ZVxuICAgIGlmIChrZXkgPT09ICdiYWNrZ3JvdW5kJylcbiAgICAgIGJhY2tncm91bmRQaWNrZXJbMF0uc3R5bGUuYm94U2hhZG93ID0gc2hhZG93cy5hY3RpdmVcbiAgICBpZiAoa2V5ID09PSAnYm9yZGVyJylcbiAgICAgIGJvcmRlclBpY2tlclswXS5zdHlsZS5ib3hTaGFkb3cgPSBzaGFkb3dzLmFjdGl2ZVxuICB9XG5cbiAgY29uc3QgcmVtb3ZlQWN0aXZlID0gKCkgPT5cbiAgICBbZm9yZWdyb3VuZFBpY2tlciwgYmFja2dyb3VuZFBpY2tlciwgYm9yZGVyUGlja2VyXS5mb3JFYWNoKChbcGlja2VyXSkgPT5cbiAgICAgIHBpY2tlci5zdHlsZS5ib3hTaGFkb3cgPSBzaGFkb3dzLmluYWN0aXZlKVxuXG4gIHJldHVybiB7XG4gICAgZ2V0QWN0aXZlLFxuICAgIHNldEFjdGl2ZSxcbiAgICBmb3JlZ3JvdW5kOiB7IGNvbG9yOiBjb2xvciA9PlxuICAgICAgZm9yZWdyb3VuZFBpY2tlclswXS5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1jb250ZXh0dWFsX2NvbG9yJywgY29sb3IpfSxcbiAgICBiYWNrZ3JvdW5kOiB7IGNvbG9yOiBjb2xvciA9PlxuICAgICAgYmFja2dyb3VuZFBpY2tlclswXS5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1jb250ZXh0dWFsX2NvbG9yJywgY29sb3IpfVxuICB9XG59XG4iLCJpbXBvcnQgaG90a2V5cyBmcm9tICdob3RrZXlzLWpzJ1xuaW1wb3J0IHsgbWV0YUtleSwgZ2V0U3R5bGUsIHNob3dIaWRlU2VsZWN0ZWQgfSBmcm9tICcuLi91dGlsaXRpZXMvJ1xuXG5jb25zdCBrZXlfZXZlbnRzID0gJ3VwLGRvd24sbGVmdCxyaWdodCdcbiAgLnNwbGl0KCcsJylcbiAgLnJlZHVjZSgoZXZlbnRzLCBldmVudCkgPT5cbiAgICBgJHtldmVudHN9LCR7ZXZlbnR9LHNoaWZ0KyR7ZXZlbnR9YFxuICAsICcnKVxuICAuc3Vic3RyaW5nKDEpXG5cbmNvbnN0IGNvbW1hbmRfZXZlbnRzID0gYCR7bWV0YUtleX0rdXAsJHttZXRhS2V5fStzaGlmdCt1cCwke21ldGFLZXl9K2Rvd24sJHttZXRhS2V5fStzaGlmdCtkb3duLCR7bWV0YUtleX0rbGVmdCwke21ldGFLZXl9K3NoaWZ0K2xlZnQsJHttZXRhS2V5fStyaWdodCwke21ldGFLZXl9K3NoaWZ0K3JpZ2h0YFxuXG5leHBvcnQgZnVuY3Rpb24gQm94U2hhZG93KHtzZWxlY3Rpb259KSB7XG4gIGhvdGtleXMoa2V5X2V2ZW50cywgKGUsIGhhbmRsZXIpID0+IHtcbiAgICBpZiAoZS5jYW5jZWxCdWJibGUpIHJldHVyblxuXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICBsZXQgc2VsZWN0ZWROb2RlcyA9IHNlbGVjdGlvbigpXG4gICAgICAsIGtleXMgPSBoYW5kbGVyLmtleS5zcGxpdCgnKycpXG5cbiAgICBpZiAoa2V5cy5pbmNsdWRlcygnbGVmdCcpIHx8IGtleXMuaW5jbHVkZXMoJ3JpZ2h0JykpXG4gICAgICBrZXlzLmluY2x1ZGVzKCdzaGlmdCcpXG4gICAgICAgID8gY2hhbmdlQm94U2hhZG93KHNlbGVjdGVkTm9kZXMsIGtleXMsICdzaXplJylcbiAgICAgICAgOiBjaGFuZ2VCb3hTaGFkb3coc2VsZWN0ZWROb2Rlcywga2V5cywgJ3gnKVxuICAgIGVsc2VcbiAgICAgIGtleXMuaW5jbHVkZXMoJ3NoaWZ0JylcbiAgICAgICAgPyBjaGFuZ2VCb3hTaGFkb3coc2VsZWN0ZWROb2Rlcywga2V5cywgJ2JsdXInKVxuICAgICAgICA6IGNoYW5nZUJveFNoYWRvdyhzZWxlY3RlZE5vZGVzLCBrZXlzLCAneScpXG4gIH0pXG5cbiAgaG90a2V5cyhjb21tYW5kX2V2ZW50cywgKGUsIGhhbmRsZXIpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBsZXQga2V5cyA9IGhhbmRsZXIua2V5LnNwbGl0KCcrJylcbiAgICBrZXlzLmluY2x1ZGVzKCdsZWZ0JykgfHwga2V5cy5pbmNsdWRlcygncmlnaHQnKVxuICAgICAgPyBjaGFuZ2VCb3hTaGFkb3coc2VsZWN0aW9uKCksIGtleXMsICdvcGFjaXR5JylcbiAgICAgIDogY2hhbmdlQm94U2hhZG93KHNlbGVjdGlvbigpLCBrZXlzLCAnaW5zZXQnKVxuICB9KVxuXG4gIHJldHVybiAoKSA9PiB7XG4gICAgaG90a2V5cy51bmJpbmQoa2V5X2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZChjb21tYW5kX2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZCgndXAsZG93bixsZWZ0LHJpZ2h0JylcbiAgfVxufVxuXG5jb25zdCBlbnN1cmVIYXNTaGFkb3cgPSBlbCA9PiB7XG4gIGlmIChlbC5zdHlsZS5ib3hTaGFkb3cgPT0gJycgfHwgZWwuc3R5bGUuYm94U2hhZG93ID09ICdub25lJylcbiAgICBlbC5zdHlsZS5ib3hTaGFkb3cgPSAnaHNsYSgwLDAlLDAlLDMwJSkgMCAwIDAgMCdcbiAgcmV0dXJuIGVsXG59XG5cbi8vIHRvZG86IHdvcmsgYXJvdW5kIHRoaXMgcHJvcE1hcCB3aXRoIGEgYmV0dGVyIHNwbGl0XG5jb25zdCBwcm9wTWFwID0ge1xuICAnb3BhY2l0eSc6ICAzLFxuICAneCc6ICAgICAgICA0LFxuICAneSc6ICAgICAgICA1LFxuICAnYmx1cic6ICAgICA2LFxuICAnc2l6ZSc6ICAgICA3LFxuICAnaW5zZXQnOiAgICA4LFxufVxuXG5jb25zdCBwYXJzZUN1cnJlbnRTaGFkb3cgPSBlbCA9PiBnZXRTdHlsZShlbCwgJ2JveFNoYWRvdycpLnNwbGl0KCcgJylcblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZUJveFNoYWRvdyhlbHMsIGRpcmVjdGlvbiwgcHJvcCkge1xuICBlbHNcbiAgICAubWFwKGVuc3VyZUhhc1NoYWRvdylcbiAgICAubWFwKGVsID0+IHNob3dIaWRlU2VsZWN0ZWQoZWwsIDE1MDApKVxuICAgIC5tYXAoZWwgPT4gKHtcbiAgICAgIGVsLFxuICAgICAgc3R5bGU6ICAgICAnYm94U2hhZG93JyxcbiAgICAgIGN1cnJlbnQ6ICAgcGFyc2VDdXJyZW50U2hhZG93KGVsKSwgLy8gW1wicmdiKDI1NSxcIiwgXCIwLFwiLCBcIjApXCIsIFwiMHB4XCIsIFwiMHB4XCIsIFwiMXB4XCIsIFwiMHB4XCJdXG4gICAgICBwcm9wSW5kZXg6IHBhcnNlQ3VycmVudFNoYWRvdyhlbClbMF0uaW5jbHVkZXMoJ3JnYmEnKSA/IHByb3BNYXBbcHJvcF0gOiBwcm9wTWFwW3Byb3BdIC0gMVxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PiB7XG4gICAgICBsZXQgdXBkYXRlZCA9IFsuLi5wYXlsb2FkLmN1cnJlbnRdXG4gICAgICBsZXQgY3VyICAgICA9IHByb3AgPT09ICdvcGFjaXR5J1xuICAgICAgICA/IHBheWxvYWQuY3VycmVudFtwYXlsb2FkLnByb3BJbmRleF1cbiAgICAgICAgOiBwYXJzZUludChwYXlsb2FkLmN1cnJlbnRbcGF5bG9hZC5wcm9wSW5kZXhdKVxuXG4gICAgICBzd2l0Y2gocHJvcCkge1xuICAgICAgICBjYXNlICdibHVyJzpcbiAgICAgICAgICB2YXIgYW1vdW50ID0gZGlyZWN0aW9uLmluY2x1ZGVzKCdzaGlmdCcpID8gMTAgOiAxXG4gICAgICAgICAgdXBkYXRlZFtwYXlsb2FkLnByb3BJbmRleF0gPSBkaXJlY3Rpb24uaW5jbHVkZXMoJ2Rvd24nKVxuICAgICAgICAgICAgPyBgJHtjdXIgLSBhbW91bnR9cHhgXG4gICAgICAgICAgICA6IGAke2N1ciArIGFtb3VudH1weGBcbiAgICAgICAgICBicmVha1xuICAgICAgICBjYXNlICdpbnNldCc6XG4gICAgICAgICAgdXBkYXRlZFtwYXlsb2FkLnByb3BJbmRleF0gPSBkaXJlY3Rpb24uaW5jbHVkZXMoJ2Rvd24nKVxuICAgICAgICAgICAgPyAnaW5zZXQnXG4gICAgICAgICAgICA6ICcnXG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSAnb3BhY2l0eSc6XG4gICAgICAgICAgbGV0IGN1cl9vcGFjaXR5ID0gcGFyc2VGbG9hdChjdXIuc2xpY2UoMCwgY3VyLmluZGV4T2YoJyknKSkpXG4gICAgICAgICAgdmFyIGFtb3VudCA9IGRpcmVjdGlvbi5pbmNsdWRlcygnc2hpZnQnKSA/IDAuMTAgOiAwLjAxXG4gICAgICAgICAgdXBkYXRlZFtwYXlsb2FkLnByb3BJbmRleF0gPSBkaXJlY3Rpb24uaW5jbHVkZXMoJ2xlZnQnKVxuICAgICAgICAgICAgPyBjdXJfb3BhY2l0eSAtIGFtb3VudCArICcpJ1xuICAgICAgICAgICAgOiBjdXJfb3BhY2l0eSArIGFtb3VudCArICcpJ1xuICAgICAgICAgIGJyZWFrXG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgdXBkYXRlZFtwYXlsb2FkLnByb3BJbmRleF0gPSBkaXJlY3Rpb24uaW5jbHVkZXMoJ2xlZnQnKSB8fCBkaXJlY3Rpb24uaW5jbHVkZXMoJ3VwJylcbiAgICAgICAgICAgID8gYCR7Y3VyIC0gMX1weGBcbiAgICAgICAgICAgIDogYCR7Y3VyICsgMX1weGBcbiAgICAgICAgICBicmVha1xuICAgICAgfVxuXG4gICAgICBwYXlsb2FkLnZhbHVlID0gdXBkYXRlZFxuICAgICAgcmV0dXJuIHBheWxvYWRcbiAgICB9KVxuICAgIC5mb3JFYWNoKCh7ZWwsIHN0eWxlLCB2YWx1ZX0pID0+XG4gICAgICBlbC5zdHlsZVtzdHlsZV0gPSB2YWx1ZS5qb2luKCcgJykpXG59XG4iLCJpbXBvcnQgJCBmcm9tICdibGluZ2JsaW5nanMnXG5pbXBvcnQgaG90a2V5cyBmcm9tICdob3RrZXlzLWpzJ1xuaW1wb3J0IHsgVGlueUNvbG9yIH0gZnJvbSAnQGN0cmwvdGlueWNvbG9yJ1xuXG5pbXBvcnQgeyBtZXRhS2V5LCBnZXRTdHlsZSwgc2hvd0hpZGVTZWxlY3RlZCB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmNvbnN0IGtleV9ldmVudHMgPSAndXAsZG93bixsZWZ0LHJpZ2h0J1xuICAuc3BsaXQoJywnKVxuICAucmVkdWNlKChldmVudHMsIGV2ZW50KSA9PlxuICAgIGAke2V2ZW50c30sJHtldmVudH0sc2hpZnQrJHtldmVudH1gXG4gICwgJycpXG4gIC5zdWJzdHJpbmcoMSlcblxuY29uc3QgY29tbWFuZF9ldmVudHMgPSBgJHttZXRhS2V5fSt1cCwke21ldGFLZXl9K3NoaWZ0K3VwLCR7bWV0YUtleX0rZG93biwke21ldGFLZXl9K3NoaWZ0K2Rvd24sJHttZXRhS2V5fStsZWZ0LCR7bWV0YUtleX0rc2hpZnQrbGVmdCwke21ldGFLZXl9K3JpZ2h0LCR7bWV0YUtleX0rc2hpZnQrcmlnaHRgXG5cbmV4cG9ydCBmdW5jdGlvbiBIdWVTaGlmdChDb2xvcikge1xuICB0aGlzLmFjdGl2ZV9jb2xvciAgID0gQ29sb3IuZ2V0QWN0aXZlKClcbiAgdGhpcy5lbGVtZW50cyAgICAgICA9IFtdXG5cbiAgaG90a2V5cyhrZXlfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGlmIChlLmNhbmNlbEJ1YmJsZSkgcmV0dXJuXG5cbiAgICBlLnByZXZlbnREZWZhdWx0KClcblxuICAgIGxldCBzZWxlY3RlZE5vZGVzID0gdGhpcy5lbGVtZW50c1xuICAgICAgLCBrZXlzID0gaGFuZGxlci5rZXkuc3BsaXQoJysnKVxuXG4gICAga2V5cy5pbmNsdWRlcygnbGVmdCcpIHx8IGtleXMuaW5jbHVkZXMoJ3JpZ2h0JylcbiAgICAgID8gY2hhbmdlSHVlKHNlbGVjdGVkTm9kZXMsIGtleXMsICdzJywgQ29sb3IpXG4gICAgICA6IGNoYW5nZUh1ZShzZWxlY3RlZE5vZGVzLCBrZXlzLCAnbCcsIENvbG9yKVxuICB9KVxuXG4gIGhvdGtleXMoY29tbWFuZF9ldmVudHMsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgbGV0IGtleXMgPSBoYW5kbGVyLmtleS5zcGxpdCgnKycpXG4gICAga2V5cy5pbmNsdWRlcygnbGVmdCcpIHx8IGtleXMuaW5jbHVkZXMoJ3JpZ2h0JylcbiAgICAgID8gY2hhbmdlSHVlKHRoaXMuZWxlbWVudHMsIGtleXMsICdhJywgQ29sb3IpXG4gICAgICA6IGNoYW5nZUh1ZSh0aGlzLmVsZW1lbnRzLCBrZXlzLCAnaCcsIENvbG9yKVxuICB9KVxuXG4gIGhvdGtleXMoJ10nLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuXG4gICAgaWYgKHRoaXMuYWN0aXZlX2NvbG9yID09ICdmb3JlZ3JvdW5kJylcbiAgICAgIHRoaXMuYWN0aXZlX2NvbG9yID0gJ2JhY2tncm91bmQnXG4gICAgZWxzZSBpZiAodGhpcy5hY3RpdmVfY29sb3IgPT0gJ2JhY2tncm91bmQnKVxuICAgICAgdGhpcy5hY3RpdmVfY29sb3IgPSAnYm9yZGVyJ1xuXG4gICAgQ29sb3Iuc2V0QWN0aXZlKHRoaXMuYWN0aXZlX2NvbG9yKVxuICB9KVxuXG4gIGhvdGtleXMoJ1snLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuXG4gICAgaWYgKHRoaXMuYWN0aXZlX2NvbG9yID09ICdiYWNrZ3JvdW5kJylcbiAgICAgIHRoaXMuYWN0aXZlX2NvbG9yID0gJ2ZvcmVncm91bmQnXG4gICAgZWxzZSBpZiAodGhpcy5hY3RpdmVfY29sb3IgPT0gJ2JvcmRlcicpXG4gICAgICB0aGlzLmFjdGl2ZV9jb2xvciA9ICdiYWNrZ3JvdW5kJ1xuXG4gICAgQ29sb3Iuc2V0QWN0aXZlKHRoaXMuYWN0aXZlX2NvbG9yKVxuICB9KVxuXG4gIGNvbnN0IG9uTm9kZXNTZWxlY3RlZCA9IGVscyA9PiB7XG4gICAgdGhpcy5lbGVtZW50cyA9IGVsc1xuICAgIENvbG9yLnNldEFjdGl2ZSh0aGlzLmFjdGl2ZV9jb2xvcilcbiAgfVxuXG4gIGNvbnN0IGRpc2Nvbm5lY3QgPSAoKSA9PiB7XG4gICAgaG90a2V5cy51bmJpbmQoa2V5X2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZChjb21tYW5kX2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZCgndXAsZG93bixsZWZ0LHJpZ2h0JylcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgb25Ob2Rlc1NlbGVjdGVkLFxuICAgIGRpc2Nvbm5lY3QsXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZUh1ZShlbHMsIGRpcmVjdGlvbiwgcHJvcCwgQ29sb3IpIHtcbiAgZWxzXG4gICAgLm1hcChlbCA9PiBzaG93SGlkZVNlbGVjdGVkKGVsKSlcbiAgICAubWFwKGVsID0+IHtcbiAgICAgIGNvbnN0IHsgZm9yZWdyb3VuZCwgYmFja2dyb3VuZCwgYm9yZGVyIH0gPSBleHRyYWN0UGFsbGV0ZUNvbG9ycyhlbClcblxuICAgICAgLy8gdG9kbzogdGVhY2ggaHVlc2hpZnQgdG8gZG8gaGFuZGxlIGNvbG9yXG4gICAgICBzd2l0Y2goQ29sb3IuZ2V0QWN0aXZlKCkpIHtcbiAgICAgICAgY2FzZSAnYmFja2dyb3VuZCc6XG4gICAgICAgICAgcmV0dXJuIHsgZWwsIGN1cnJlbnQ6IGJhY2tncm91bmQuY29sb3IudG9Ic2woKSwgc3R5bGU6IGJhY2tncm91bmQuc3R5bGUgfVxuICAgICAgICBjYXNlICdmb3JlZ3JvdW5kJzpcbiAgICAgICAgICByZXR1cm4geyBlbCwgY3VycmVudDogZm9yZWdyb3VuZC5jb2xvci50b0hzbCgpLCBzdHlsZTogZm9yZWdyb3VuZC5zdHlsZSB9XG4gICAgICAgIGNhc2UgJ2JvcmRlcic6IHtcbiAgICAgICAgICBpZiAoZWwuc3R5bGUuYm9yZGVyID09PSAnJykgZWwuc3R5bGUuYm9yZGVyID0gJzFweCBzb2xpZCBibGFjaydcbiAgICAgICAgICByZXR1cm4geyBlbCwgY3VycmVudDogYm9yZGVyLmNvbG9yLnRvSHNsKCksIHN0eWxlOiBib3JkZXIuc3R5bGUgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSlcbiAgICAubWFwKHBheWxvYWQgPT5cbiAgICAgIE9iamVjdC5hc3NpZ24ocGF5bG9hZCwge1xuICAgICAgICBhbW91bnQ6ICAgZGlyZWN0aW9uLmluY2x1ZGVzKCdzaGlmdCcpID8gMTAgOiAxLFxuICAgICAgICBuZWdhdGl2ZTogZGlyZWN0aW9uLmluY2x1ZGVzKCdkb3duJykgfHwgZGlyZWN0aW9uLmluY2x1ZGVzKCdsZWZ0JyksXG4gICAgICB9KSlcbiAgICAubWFwKHBheWxvYWQgPT4ge1xuICAgICAgaWYgKHByb3AgPT09ICdzJyB8fCBwcm9wID09PSAnbCcgfHwgcHJvcCA9PT0gJ2EnKVxuICAgICAgICBwYXlsb2FkLmFtb3VudCA9IHBheWxvYWQuYW1vdW50ICogMC4wMVxuXG4gICAgICBwYXlsb2FkLmN1cnJlbnRbcHJvcF0gPSBwYXlsb2FkLm5lZ2F0aXZlXG4gICAgICAgID8gcGF5bG9hZC5jdXJyZW50W3Byb3BdIC0gcGF5bG9hZC5hbW91bnRcbiAgICAgICAgOiBwYXlsb2FkLmN1cnJlbnRbcHJvcF0gKyBwYXlsb2FkLmFtb3VudFxuXG4gICAgICBpZiAocHJvcCA9PT0gJ3MnIHx8IHByb3AgPT09ICdsJyB8fCBwcm9wID09PSAnYScpIHtcbiAgICAgICAgaWYgKHBheWxvYWQuY3VycmVudFtwcm9wXSA+IDEpIHBheWxvYWQuY3VycmVudFtwcm9wXSA9IDFcbiAgICAgICAgaWYgKHBheWxvYWQuY3VycmVudFtwcm9wXSA8IDApIHBheWxvYWQuY3VycmVudFtwcm9wXSA9IDBcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHBheWxvYWRcbiAgICB9KVxuICAgIC5mb3JFYWNoKCh7ZWwsIHN0eWxlLCBjdXJyZW50fSkgPT4ge1xuICAgICAgbGV0IGNvbG9yID0gbmV3IFRpbnlDb2xvcihjdXJyZW50KS5zZXRBbHBoYShjdXJyZW50LmEpXG4gICAgICBlbC5zdHlsZVtzdHlsZV0gPSBjb2xvci50b0hzbFN0cmluZygpXG5cbiAgICAgIGlmIChzdHlsZSA9PSAnY29sb3InKSBDb2xvci5mb3JlZ3JvdW5kLmNvbG9yKGNvbG9yLnRvSGV4U3RyaW5nKCkpXG4gICAgICBpZiAoc3R5bGUgPT0gJ2JhY2tncm91bmRDb2xvcicpIENvbG9yLmJhY2tncm91bmQuY29sb3IoY29sb3IudG9IZXhTdHJpbmcoKSlcbiAgICB9KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZXh0cmFjdFBhbGxldGVDb2xvcnMoZWwpIHtcbiAgaWYgKGVsIGluc3RhbmNlb2YgU1ZHRWxlbWVudCkge1xuICAgIGNvbnN0ICBmZ190ZW1wID0gZ2V0U3R5bGUoZWwsICdzdHJva2UnKVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIGZvcmVncm91bmQ6IHtcbiAgICAgICAgc3R5bGU6ICdzdHJva2UnLFxuICAgICAgICBjb2xvcjogbmV3IFRpbnlDb2xvcihmZ190ZW1wID09PSAnbm9uZSdcbiAgICAgICAgICA/ICdyZ2IoMCwgMCwgMCknXG4gICAgICAgICAgOiBmZ190ZW1wKSxcbiAgICAgIH0sXG4gICAgICBiYWNrZ3JvdW5kOiB7XG4gICAgICAgIHN0eWxlOiAnZmlsbCcsXG4gICAgICAgIGNvbG9yOiBuZXcgVGlueUNvbG9yKGdldFN0eWxlKGVsLCAnZmlsbCcpKSxcbiAgICAgIH0sXG4gICAgICBib3JkZXI6IHtcbiAgICAgICAgc3R5bGU6ICdvdXRsaW5lJyxcbiAgICAgICAgY29sb3I6IG5ldyBUaW55Q29sb3IoZ2V0U3R5bGUoZWwsICdvdXRsaW5lJykpLFxuICAgICAgfVxuICAgIH1cbiAgfVxuICBlbHNlXG4gICAgcmV0dXJuIHtcbiAgICAgIGZvcmVncm91bmQ6IHtcbiAgICAgICAgc3R5bGU6ICdjb2xvcicsXG4gICAgICAgIGNvbG9yOiBuZXcgVGlueUNvbG9yKGdldFN0eWxlKGVsLCAnY29sb3InKSksXG4gICAgICB9LFxuICAgICAgYmFja2dyb3VuZDoge1xuICAgICAgICBzdHlsZTogJ2JhY2tncm91bmRDb2xvcicsXG4gICAgICAgIGNvbG9yOiBuZXcgVGlueUNvbG9yKGdldFN0eWxlKGVsLCAnYmFja2dyb3VuZENvbG9yJykpLFxuICAgICAgfSxcbiAgICAgIGJvcmRlcjoge1xuICAgICAgICBzdHlsZTogJ2JvcmRlckNvbG9yJyxcbiAgICAgICAgY29sb3I6IG5ldyBUaW55Q29sb3IoZ2V0U3R5bGUoZWwsICdib3JkZXJDb2xvcicpKSxcbiAgICAgIH1cbiAgICB9XG59XG4iLCJpbXBvcnQgJCBmcm9tICdibGluZ2JsaW5nanMnXG5pbXBvcnQgeyBpc09mZkJvdW5kcywgZGVlcEVsZW1lbnRGcm9tUG9pbnQgfSBmcm9tICcuLi91dGlsaXRpZXMvJ1xuXG5sZXQgZ3JpZGxpbmVzXG5cbmV4cG9ydCBmdW5jdGlvbiBHdWlkZXMoKSB7XG4gICQoJ2JvZHknKS5vbignbW91c2Vtb3ZlJywgb25faG92ZXIpXG4gICQoJ2JvZHknKS5vbignbW91c2VvdXQnLCBvbl9ob3Zlcm91dClcbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIGhpZGVHcmlkbGluZXMpXG5cbiAgcmV0dXJuICgpID0+IHtcbiAgICAkKCdib2R5Jykub2ZmKCdtb3VzZW1vdmUnLCBvbl9ob3ZlcilcbiAgICAkKCdib2R5Jykub2ZmKCdtb3VzZW91dCcsIG9uX2hvdmVyb3V0KVxuICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdzY3JvbGwnLCBoaWRlR3JpZGxpbmVzKVxuICAgIGhpZGVHcmlkbGluZXMoKVxuICB9XG59XG5cbmNvbnN0IG9uX2hvdmVyID0gZSA9PiB7XG4gIGNvbnN0IHRhcmdldCA9IGRlZXBFbGVtZW50RnJvbVBvaW50KGUuY2xpZW50WCwgZS5jbGllbnRZKVxuICBpZiAoaXNPZmZCb3VuZHModGFyZ2V0KSkgcmV0dXJuXG4gIHNob3dHcmlkbGluZXModGFyZ2V0KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlR3VpZGUodmVydCA9IHRydWUpIHtcbiAgbGV0IGd1aWRlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgbGV0IHN0eWxlcyA9IGBcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgYmFja2dyb3VuZDogaHNsYSgzMzAsIDEwMCUsIDcxJSwgNzAlKTtcbiAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICB6LWluZGV4OiAyMTQ3NDgzNjQzO1xuICBgXG5cbiAgdmVydCBcbiAgICA/IHN0eWxlcyArPSBgXG4gICAgICAgIHdpZHRoOiAxcHg7XG4gICAgICAgIGhlaWdodDogMTAwdmg7XG4gICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDE4MGRlZyk7XG4gICAgICBgXG4gICAgOiBzdHlsZXMgKz0gYFxuICAgICAgICBoZWlnaHQ6IDFweDtcbiAgICAgICAgd2lkdGg6IDEwMHZ3O1xuICAgICAgYFxuXG4gIGd1aWRlLnN0eWxlID0gc3R5bGVzXG5cbiAgcmV0dXJuIGd1aWRlXG59XG5cbmNvbnN0IG9uX2hvdmVyb3V0ID0gKHt0YXJnZXR9KSA9PlxuICBoaWRlR3JpZGxpbmVzKClcblxuY29uc3Qgc2hvd0dyaWRsaW5lcyA9IG5vZGUgPT4ge1xuICBpZiAoZ3JpZGxpbmVzKSB7XG4gICAgZ3JpZGxpbmVzLnN0eWxlLmRpc3BsYXkgPSBudWxsXG4gICAgZ3JpZGxpbmVzLnVwZGF0ZSA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KClcbiAgfVxuICBlbHNlIHtcbiAgICBncmlkbGluZXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCd2aXNidWctZ3JpZGxpbmVzJylcbiAgICBncmlkbGluZXMucG9zaXRpb24gPSBub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpXG5cbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGdyaWRsaW5lcylcbiAgfVxufVxuXG5jb25zdCBoaWRlR3JpZGxpbmVzID0gbm9kZSA9PiB7XG4gIGlmICghZ3JpZGxpbmVzKSByZXR1cm5cbiAgZ3JpZGxpbmVzLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSdcbn1cbiIsImV4cG9ydCBmdW5jdGlvbiBTY3JlZW5zaG90KG5vZGUsIHBhZ2UpIHtcbiAgYWxlcnQoJ0NvbWluZyBTb29uIScpXG5cbiAgcmV0dXJuICgpID0+IHt9XG59IiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCB7IG1ldGFLZXksIGdldFN0eWxlLCBnZXRTaWRlLCBzaG93SGlkZVNlbGVjdGVkIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuY29uc3Qga2V5X2V2ZW50cyA9ICd1cCxkb3duLGxlZnQscmlnaHQnXG4gIC5zcGxpdCgnLCcpXG4gIC5yZWR1Y2UoKGV2ZW50cywgZXZlbnQpID0+XG4gICAgYCR7ZXZlbnRzfSwke2V2ZW50fSxhbHQrJHtldmVudH0sc2hpZnQrJHtldmVudH0sc2hpZnQrYWx0KyR7ZXZlbnR9YFxuICAsICcnKVxuICAuc3Vic3RyaW5nKDEpXG5cbmNvbnN0IGNvbW1hbmRfZXZlbnRzID0gYCR7bWV0YUtleX0rdXAsJHttZXRhS2V5fStzaGlmdCt1cCwke21ldGFLZXl9K2Rvd24sJHttZXRhS2V5fStzaGlmdCtkb3duYFxuXG5leHBvcnQgZnVuY3Rpb24gUG9zaXRpb24oKSB7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIGVsZW1lbnRzOiBbXVxuICB9XG5cbiAgaG90a2V5cyhrZXlfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGlmIChlLmNhbmNlbEJ1YmJsZSkgcmV0dXJuXG5cbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBwb3NpdGlvbkVsZW1lbnQoc3RhdGUuZWxlbWVudHMsIGhhbmRsZXIua2V5KVxuICB9KVxuXG4gIGNvbnN0IG9uTm9kZXNTZWxlY3RlZCA9IGVscyA9PiB7XG4gICAgc3RhdGUuZWxlbWVudHMuZm9yRWFjaChlbCA9PlxuICAgICAgZWwudGVhcmRvd24oKSlcblxuICAgIHN0YXRlLmVsZW1lbnRzID0gZWxzLm1hcChlbCA9PlxuICAgICAgZHJhZ2dhYmxlKGVsKSlcbiAgfVxuXG4gIGNvbnN0IGRpc2Nvbm5lY3QgPSAoKSA9PiB7XG4gICAgc3RhdGUuZWxlbWVudHMuZm9yRWFjaChlbCA9PiBlbC50ZWFyZG93bigpKVxuICAgIGhvdGtleXMudW5iaW5kKGtleV9ldmVudHMpXG4gICAgaG90a2V5cy51bmJpbmQoJ3VwLGRvd24sbGVmdCxyaWdodCcpXG4gIH1cblxuICByZXR1cm4ge1xuICAgIG9uTm9kZXNTZWxlY3RlZCxcbiAgICBkaXNjb25uZWN0LFxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkcmFnZ2FibGUoZWwpIHtcbiAgdGhpcy5zdGF0ZSA9IHtcbiAgICBtb3VzZToge1xuICAgICAgZG93bjogZmFsc2UsXG4gICAgICB4OiAwLFxuICAgICAgeTogMCxcbiAgICB9LFxuICAgIGVsZW1lbnQ6IHtcbiAgICAgIHg6IDAsXG4gICAgICB5OiAwLFxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHNldHVwID0gKCkgPT4ge1xuICAgIGVsLnN0eWxlLnRyYW5zaXRpb24gICA9ICdub25lJ1xuICAgIGVsLnN0eWxlLmN1cnNvciAgICAgICA9ICdtb3ZlJ1xuXG4gICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgb25Nb3VzZURvd24sIHRydWUpXG4gICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignbW91c2V1cCcsIG9uTW91c2VVcCwgdHJ1ZSlcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZW1vdmUnLCBvbk1vdXNlTW92ZSwgdHJ1ZSlcbiAgfVxuXG4gIGNvbnN0IHRlYXJkb3duID0gKCkgPT4ge1xuICAgIGVsLnN0eWxlLnRyYW5zaXRpb24gICA9IG51bGxcbiAgICBlbC5zdHlsZS5jdXJzb3IgICAgICAgPSBudWxsXG5cbiAgICBlbC5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBvbk1vdXNlRG93biwgdHJ1ZSlcbiAgICBlbC5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZXVwJywgb25Nb3VzZVVwLCB0cnVlKVxuICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNlbW92ZScsIG9uTW91c2VNb3ZlLCB0cnVlKVxuICB9XG5cbiAgY29uc3Qgb25Nb3VzZURvd24gPSBlID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcblxuICAgIGNvbnN0IGVsID0gZS50YXJnZXRcblxuICAgIGVsLnN0eWxlLnBvc2l0aW9uID0gJ3JlbGF0aXZlJ1xuICAgIGVsLnN0eWxlLndpbGxDaGFuZ2UgPSAndG9wLGxlZnQnXG5cbiAgICBpZiAoZWwgaW5zdGFuY2VvZiBTVkdFbGVtZW50KSB7XG4gICAgICBjb25zdCB0cmFuc2xhdGUgPSBlbC5nZXRBdHRyaWJ1dGUoJ3RyYW5zZm9ybScpXG5cbiAgICAgIGNvbnN0IFsgeCwgeSBdID0gdHJhbnNsYXRlXG4gICAgICAgID8gZXh0cmFjdFNWR1RyYW5zbGF0ZSh0cmFuc2xhdGUpXG4gICAgICAgIDogWzAsMF1cblxuICAgICAgdGhpcy5zdGF0ZS5lbGVtZW50LnggID0geFxuICAgICAgdGhpcy5zdGF0ZS5lbGVtZW50LnkgID0geVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIHRoaXMuc3RhdGUuZWxlbWVudC54ICA9IHBhcnNlSW50KGdldFN0eWxlKGVsLCAnbGVmdCcpKVxuICAgICAgdGhpcy5zdGF0ZS5lbGVtZW50LnkgID0gcGFyc2VJbnQoZ2V0U3R5bGUoZWwsICd0b3AnKSlcbiAgICB9XG5cbiAgICB0aGlzLnN0YXRlLm1vdXNlLnggICAgICA9IGUuY2xpZW50WFxuICAgIHRoaXMuc3RhdGUubW91c2UueSAgICAgID0gZS5jbGllbnRZXG4gICAgdGhpcy5zdGF0ZS5tb3VzZS5kb3duICAgPSB0cnVlXG4gIH1cblxuICBjb25zdCBvbk1vdXNlVXAgPSBlID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG5cbiAgICB0aGlzLnN0YXRlLm1vdXNlLmRvd24gPSBmYWxzZVxuICAgIGVsLnN0eWxlLndpbGxDaGFuZ2UgPSBudWxsXG5cbiAgICBpZiAoZWwgaW5zdGFuY2VvZiBTVkdFbGVtZW50KSB7XG4gICAgICBjb25zdCB0cmFuc2xhdGUgPSBlbC5nZXRBdHRyaWJ1dGUoJ3RyYW5zZm9ybScpXG5cbiAgICAgIGNvbnN0IFsgeCwgeSBdID0gdHJhbnNsYXRlXG4gICAgICAgID8gZXh0cmFjdFNWR1RyYW5zbGF0ZSh0cmFuc2xhdGUpXG4gICAgICAgIDogWzAsMF1cblxuICAgICAgdGhpcy5zdGF0ZS5lbGVtZW50LnggICAgPSB4XG4gICAgICB0aGlzLnN0YXRlLmVsZW1lbnQueSAgICA9IHlcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICB0aGlzLnN0YXRlLmVsZW1lbnQueCAgICA9IHBhcnNlSW50KGVsLnN0eWxlLmxlZnQpIHx8IDBcbiAgICAgIHRoaXMuc3RhdGUuZWxlbWVudC55ICAgID0gcGFyc2VJbnQoZWwuc3R5bGUudG9wKSB8fCAwXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgb25Nb3VzZU1vdmUgPSBlID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG5cbiAgICBpZiAoIXRoaXMuc3RhdGUubW91c2UuZG93bikgcmV0dXJuXG5cbiAgICBpZiAoZWwgaW5zdGFuY2VvZiBTVkdFbGVtZW50KSB7XG4gICAgICBlbC5zZXRBdHRyaWJ1dGUoJ3RyYW5zZm9ybScsIGB0cmFuc2xhdGUoXG4gICAgICAgICR7dGhpcy5zdGF0ZS5lbGVtZW50LnggKyBlLmNsaWVudFggLSB0aGlzLnN0YXRlLm1vdXNlLnh9LFxuICAgICAgICAke3RoaXMuc3RhdGUuZWxlbWVudC55ICsgZS5jbGllbnRZIC0gdGhpcy5zdGF0ZS5tb3VzZS55fVxuICAgICAgKWApXG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgZWwuc3R5bGUubGVmdCA9IHRoaXMuc3RhdGUuZWxlbWVudC54ICsgZS5jbGllbnRYIC0gdGhpcy5zdGF0ZS5tb3VzZS54ICsgJ3B4J1xuICAgICAgZWwuc3R5bGUudG9wICA9IHRoaXMuc3RhdGUuZWxlbWVudC55ICsgZS5jbGllbnRZIC0gdGhpcy5zdGF0ZS5tb3VzZS55ICsgJ3B4J1xuICAgIH1cbiAgfVxuXG4gIHNldHVwKClcbiAgZWwudGVhcmRvd24gPSB0ZWFyZG93blxuXG4gIHJldHVybiBlbFxufVxuXG5leHBvcnQgZnVuY3Rpb24gcG9zaXRpb25FbGVtZW50KGVscywgZGlyZWN0aW9uKSB7XG4gIGVsc1xuICAgIC5tYXAoZWwgPT4gZW5zdXJlUG9zaXRpb25hYmxlKGVsKSlcbiAgICAubWFwKGVsID0+IHNob3dIaWRlU2VsZWN0ZWQoZWwpKVxuICAgIC5tYXAoZWwgPT4gKHtcbiAgICAgICAgZWwsXG4gICAgICAgIC4uLmV4dHJhY3RDdXJyZW50VmFsdWVBbmRTaWRlKGVsLCBkaXJlY3Rpb24pLFxuICAgICAgICBhbW91bnQ6ICAgZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ3NoaWZ0JykgPyAxMCA6IDEsXG4gICAgICAgIG5lZ2F0aXZlOiBkZXRlcm1pbmVOZWdhdGl2aXR5KGVsLCBkaXJlY3Rpb24pLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIHBvc2l0aW9uOiBwYXlsb2FkLm5lZ2F0aXZlXG4gICAgICAgICAgPyBwYXlsb2FkLmN1cnJlbnQgKyBwYXlsb2FkLmFtb3VudFxuICAgICAgICAgIDogcGF5bG9hZC5jdXJyZW50IC0gcGF5bG9hZC5hbW91bnRcbiAgICAgIH0pKVxuICAgIC5mb3JFYWNoKCh7ZWwsIHN0eWxlLCBwb3NpdGlvbn0pID0+XG4gICAgICBlbCBpbnN0YW5jZW9mIFNWR0VsZW1lbnRcbiAgICAgICAgPyBzZXRUcmFuc2xhdGVPblNWRyhlbCwgZGlyZWN0aW9uLCBwb3NpdGlvbilcbiAgICAgICAgOiBlbC5zdHlsZVtzdHlsZV0gPSBwb3NpdGlvbiArICdweCcpXG59XG5cbmNvbnN0IGV4dHJhY3RDdXJyZW50VmFsdWVBbmRTaWRlID0gKGVsLCBkaXJlY3Rpb24pID0+IHtcbiAgbGV0IHN0eWxlLCBjdXJyZW50XG5cbiAgaWYgKGVsIGluc3RhbmNlb2YgU1ZHRWxlbWVudCkge1xuICAgIGNvbnN0IHRyYW5zbGF0ZSA9IGVsLmF0dHIoJ3RyYW5zZm9ybScpXG5cbiAgICBjb25zdCBbIHgsIHkgXSA9IHRyYW5zbGF0ZVxuICAgICAgPyBleHRyYWN0U1ZHVHJhbnNsYXRlKHRyYW5zbGF0ZSlcbiAgICAgIDogWzAsMF1cblxuICAgIHN0eWxlICAgPSAndHJhbnNmb3JtJ1xuICAgIGN1cnJlbnQgPSBkaXJlY3Rpb24uaW5jbHVkZXMoJ2Rvd24nKSB8fCBkaXJlY3Rpb24uaW5jbHVkZXMoJ3VwJylcbiAgICAgID8geVxuICAgICAgOiB4XG4gIH1cbiAgZWxzZSB7XG4gICAgY29uc3Qgc2lkZSA9IGdldFNpZGUoZGlyZWN0aW9uKS50b0xvd2VyQ2FzZSgpXG4gICAgc3R5bGUgPSAoc2lkZSA9PT0gJ3RvcCcgfHwgc2lkZSA9PT0gJ2JvdHRvbScpID8gJ3RvcCcgOiAnbGVmdCdcbiAgICBjdXJyZW50ID0gZ2V0U3R5bGUoZWwsIHN0eWxlKVxuXG4gICAgY3VycmVudCA9PT0gJ2F1dG8nXG4gICAgICA/IGN1cnJlbnQgPSAwXG4gICAgICA6IGN1cnJlbnQgPSBwYXJzZUludChjdXJyZW50LCAxMClcbiAgfVxuXG4gIHJldHVybiB7IHN0eWxlLCBjdXJyZW50IH1cbn1cblxuY29uc3QgZXh0cmFjdFNWR1RyYW5zbGF0ZSA9IHRyYW5zbGF0ZSA9PlxuICB0cmFuc2xhdGUuc3Vic3RyaW5nKFxuICAgIHRyYW5zbGF0ZS5pbmRleE9mKCcoJykgKyAxLFxuICAgIHRyYW5zbGF0ZS5pbmRleE9mKCcpJylcbiAgKS5zcGxpdCgnLCcpXG4gIC5tYXAodmFsID0+IHBhcnNlRmxvYXQodmFsKSlcblxuY29uc3Qgc2V0VHJhbnNsYXRlT25TVkcgPSAoZWwsIGRpcmVjdGlvbiwgcG9zaXRpb24pID0+IHtcbiAgY29uc3QgdHJhbnNmb3JtID0gZWwuYXR0cigndHJhbnNmb3JtJylcbiAgY29uc3QgWyB4LCB5IF0gPSB0cmFuc2Zvcm1cbiAgICA/IGV4dHJhY3RTVkdUcmFuc2xhdGUodHJhbnNmb3JtKVxuICAgIDogWzAsMF1cblxuICBjb25zdCBwb3MgPSBkaXJlY3Rpb24uaW5jbHVkZXMoJ2Rvd24nKSB8fCBkaXJlY3Rpb24uaW5jbHVkZXMoJ3VwJylcbiAgICA/IGAke3h9LCR7cG9zaXRpb259YFxuICAgIDogYCR7cG9zaXRpb259LCR7eX1gXG5cbiAgZWwuYXR0cigndHJhbnNmb3JtJywgYHRyYW5zbGF0ZSgke3Bvc30pYClcbn1cblxuY29uc3QgZGV0ZXJtaW5lTmVnYXRpdml0eSA9IChlbCwgZGlyZWN0aW9uKSA9PlxuICBkaXJlY3Rpb24uaW5jbHVkZXMoJ3JpZ2h0JykgfHwgZGlyZWN0aW9uLmluY2x1ZGVzKCdkb3duJylcblxuY29uc3QgZW5zdXJlUG9zaXRpb25hYmxlID0gZWwgPT4ge1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MRWxlbWVudClcbiAgICBlbC5zdHlsZS5wb3NpdGlvbiA9ICdyZWxhdGl2ZSdcbiAgcmV0dXJuIGVsXG59XG4iLCJpbXBvcnQgKiBhcyBJY29ucyBmcm9tICcuL3Zpcy1idWcuaWNvbnMnXG5pbXBvcnQgeyBtZXRhS2V5LCBhbHRLZXkgfSBmcm9tICcuLi8uLi91dGlsaXRpZXMvJ1xuXG5leHBvcnQgY29uc3QgVmlzQnVnTW9kZWwgPSB7XG4gIGc6IHtcbiAgICB0b29sOiAgICAgICAgJ2d1aWRlcycsXG4gICAgaWNvbjogICAgICAgIEljb25zLmd1aWRlcyxcbiAgICBsYWJlbDogICAgICAgJ0d1aWRlcycsXG4gICAgZGVzY3JpcHRpb246ICdWZXJpZnkgYWxpZ25tZW50ICYgY2hlY2sgeW91ciBncmlkJyxcbiAgICBpbnN0cnVjdGlvbjogYDxkaXYgdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+TWVhc3VyZTo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+JHthbHRLZXl9ICsgaG92ZXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+YCxcbiAgfSxcbiAgaToge1xuICAgIHRvb2w6ICAgICAgICAnaW5zcGVjdG9yJyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMuaW5zcGVjdG9yLFxuICAgIGxhYmVsOiAgICAgICAnSW5zcGVjdCcsXG4gICAgZGVzY3JpcHRpb246ICdQZWVrIGludG8gY29tbW9uICYgY3VycmVudCBzdHlsZXMgb2YgYW4gZWxlbWVudCcsXG4gICAgaW5zdHJ1Y3Rpb246IGA8ZGl2IHRhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPlBpbiBpdDo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+JHthbHRLZXl9ICsgY2xpY2s8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+YCxcbiAgfSxcbiAgeDoge1xuICAgIHRvb2w6ICAgICAgICAnYWNjZXNzaWJpbGl0eScsXG4gICAgaWNvbjogICAgICAgIEljb25zLmFjY2Vzc2liaWxpdHksXG4gICAgbGFiZWw6ICAgICAgICdBY2Nlc3NpYmlsaXR5JyxcbiAgICBkZXNjcmlwdGlvbjogJ1BlZWsgaW50byBBMTF5IGF0dHJpYnV0ZXMgJiBjb21wbGlhbmNlIHN0YXR1cycsXG4gICAgaW5zdHJ1Y3Rpb246IGA8ZGl2IHRhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPlBpbiBpdDo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+JHthbHRLZXl9ICsgY2xpY2s8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+YCxcbiAgfSxcbiAgdjoge1xuICAgIHRvb2w6ICAgICAgICAnbW92ZScsXG4gICAgaWNvbjogICAgICAgIEljb25zLm1vdmUsXG4gICAgbGFiZWw6ICAgICAgICdNb3ZlJyxcbiAgICBkZXNjcmlwdGlvbjogJ1B1c2ggZWxlbWVudHMgaW4gJiBvdXQgb2YgdGhlaXIgY29udGFpbmVyLCBvciBzaHVmZmxlIHRoZW0gd2l0aGluIGl0JyxcbiAgICBpbnN0cnVjdGlvbjogYDxkaXYgdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+TGF0ZXJhbDo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4peAIOKWtjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+T3V0IGFuZCBhYm92ZTo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4payPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5Eb3duIGFuZCBpbjo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PmAsXG4gIH0sXG4gIC8vIHI6IHtcbiAgLy8gICB0b29sOiAgICAgICAgJ3Jlc2l6ZScsXG4gIC8vICAgaWNvbjogICAgICAgIEljb25zLnJlc2l6ZSxcbiAgLy8gICBsYWJlbDogICAgICAgJ1Jlc2l6ZScsXG4gIC8vICAgZGVzY3JpcHRpb246ICcnXG4gIC8vIH0sXG4gIG06IHtcbiAgICB0b29sOiAgICAgICAgJ21hcmdpbicsXG4gICAgaWNvbjogICAgICAgIEljb25zLm1hcmdpbixcbiAgICBsYWJlbDogICAgICAgJ01hcmdpbicsXG4gICAgZGVzY3JpcHRpb246ICdBZGQgb3Igc3VidHJhY3Qgb3V0ZXIgc3BhY2UgZnJvbSBhbnkgb3IgYWxsIHNpZGVzIG9mIHRoZSBzZWxlY3RlZCBlbGVtZW50KHMpJyxcbiAgICBpbnN0cnVjdGlvbjogYDxkaXYgdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+KyBNYXJnaW46PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKXgCDilrYg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+LSBNYXJnaW46PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiR7YWx0S2V5fSArIOKXgCDilrYg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+QWxsIFNpZGVzOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4ke21ldGFLZXl9ICsgIOKWsiDilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+YCxcbiAgfSxcbiAgcDoge1xuICAgIHRvb2w6ICAgICAgICAncGFkZGluZycsXG4gICAgaWNvbjogICAgICAgIEljb25zLnBhZGRpbmcsXG4gICAgbGFiZWw6ICAgICAgICdQYWRkaW5nJyxcbiAgICBkZXNjcmlwdGlvbjogYEFkZCBvciBzdWJ0cmFjdCBpbm5lciBzcGFjZSBmcm9tIGFueSBvciBhbGwgc2lkZXMgb2YgdGhlIHNlbGVjdGVkIGVsZW1lbnQocylgLFxuICAgIGluc3RydWN0aW9uOiBgPGRpdiB0YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj4rIFBhZGRpbmc6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKXgCDilrYg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+LSBQYWRkaW5nOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4ke2FsdEtleX0gKyDil4Ag4pa2IOKWsiDilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPkFsbCBTaWRlczo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+JHttZXRhS2V5fSArICDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PmBcbiAgfSxcbiAgLy8gYjoge1xuICAvLyAgIHRvb2w6ICAgICAgICAnYm9yZGVyJyxcbiAgLy8gICBpY29uOiAgICAgICAgSWNvbnMuYm9yZGVyLFxuICAvLyAgIGxhYmVsOiAgICAgICAnQm9yZGVyJyxcbiAgLy8gICBkZXNjcmlwdGlvbjogJydcbiAgLy8gfSxcbiAgYToge1xuICAgIHRvb2w6ICAgICAgICAnYWxpZ24nLFxuICAgIGljb246ICAgICAgICBJY29ucy5hbGlnbixcbiAgICBsYWJlbDogICAgICAgJ0ZsZXhib3ggQWxpZ24nLFxuICAgIGRlc2NyaXB0aW9uOiBgQ3JlYXRlIG9yIG1vZGlmeSBmbGV4Ym94IGRpcmVjdGlvbiwgZGlzdHJpYnV0aW9uICYgYWxpZ25tZW50YCxcbiAgICBpbnN0cnVjdGlvbjogYDxkaXYgdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+QWxpZ25tZW50OjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7il4Ag4pa2IOKWsiDilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPkRpc3RyaWJ1dGlvbjo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2hpZnQgKyDil4Ag4pa2PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5EaXJlY3Rpb246PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiR7bWV0YUtleX0gKyAg4peAIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5gLFxuICB9LFxuICBoOiB7XG4gICAgdG9vbDogICAgICAgICdodWVzaGlmdCcsXG4gICAgaWNvbjogICAgICAgIEljb25zLmh1ZXNoaWZ0LFxuICAgIGxhYmVsOiAgICAgICAnSHVlIFNoaWZ0JyxcbiAgICBkZXNjcmlwdGlvbjogYENoYW5nZSBmb3JlZ3JvdW5kL2JhY2tncm91bmQgaHVlLCBicmlnaHRuZXNzLCBzYXR1cmF0aW9uICYgb3BhY2l0eWAsXG4gICAgaW5zdHJ1Y3Rpb246IGA8ZGl2IHRhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPlNhdHVyYXRpb246PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKXgCDilrY8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPkJyaWdodG5lc3M6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKWsiDilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPkh1ZTo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+JHttZXRhS2V5fSArICDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5PcGFjaXR5OjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4ke21ldGFLZXl9ICsgIOKXgCDilrY8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+YCxcbiAgfSxcbiAgZDoge1xuICAgIHRvb2w6ICAgICAgICAnYm94c2hhZG93JyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMuYm94c2hhZG93LFxuICAgIGxhYmVsOiAgICAgICAnU2hhZG93JyxcbiAgICBkZXNjcmlwdGlvbjogYENyZWF0ZSAmIGFkanVzdCBwb3NpdGlvbiwgYmx1ciAmIG9wYWNpdHkgb2YgYSBib3ggc2hhZG93YCxcbiAgICBpbnN0cnVjdGlvbjogYDxkaXYgdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+WC9ZIFBvc2l0aW9uOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7il4Ag4pa2IOKWsiDilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPkJsdXI6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlNoaWZ0ICsg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+U3ByZWFkOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TaGlmdCArIOKXgCDilrY8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPk9wYWNpdHk6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiR7bWV0YUtleX0gKyDil4Ag4pa2PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PmAsXG4gIH0sXG4gIC8vIHQ6IHtcbiAgLy8gICB0b29sOiAgICAgICAgJ3RyYW5zZm9ybScsXG4gIC8vICAgaWNvbjogICAgICAgIEljb25zLnRyYW5zZm9ybSxcbiAgLy8gICBsYWJlbDogICAgICAgJzNEIFRyYW5zZm9ybScsXG4gIC8vICAgZGVzY3JpcHRpb246ICcnXG4gIC8vIH0sXG4gIGw6IHtcbiAgICB0b29sOiAgICAgICAgJ3Bvc2l0aW9uJyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMucG9zaXRpb24sXG4gICAgbGFiZWw6ICAgICAgICdQb3NpdGlvbicsXG4gICAgZGVzY3JpcHRpb246ICdNb3ZlIHN2ZyAoeCx5KSBhbmQgZWxlbWVudHMgKHRvcCxsZWZ0LGJvdHRvbSxyaWdodCknLFxuICAgIGluc3RydWN0aW9uOiBgPGRpdiB0YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5OdWRnZTo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4peAIOKWtiDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5Nb3ZlOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5DbGljayAmIGRyYWc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+YCxcbiAgfSxcbiAgZjoge1xuICAgIHRvb2w6ICAgICAgICAnZm9udCcsXG4gICAgaWNvbjogICAgICAgIEljb25zLmZvbnQsXG4gICAgbGFiZWw6ICAgICAgICdGb250IFN0eWxlcycsXG4gICAgZGVzY3JpcHRpb246ICdDaGFuZ2Ugc2l6ZSwgYWxpZ25tZW50LCBsZWFkaW5nLCBsZXR0ZXItc3BhY2luZywgJiB3ZWlnaHQnLFxuICAgIGluc3RydWN0aW9uOiBgPGRpdiB0YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5TaXplOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7ilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5BbGlnbm1lbnQ6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKXgCDilrY8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPkxlYWRpbmc6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlNoaWZ0ICsg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+TGV0dGVyLXNwYWNpbmc6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlNoaWZ0ICsg4peAIOKWtjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+V2VpZ2h0OjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4ke21ldGFLZXl9ICsg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5gLFxuICB9LFxuICBlOiB7XG4gICAgdG9vbDogICAgICAgICd0ZXh0JyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMudGV4dCxcbiAgICBsYWJlbDogICAgICAgJ0VkaXQgVGV4dCcsXG4gICAgZGVzY3JpcHRpb246ICdDaGFuZ2UgYW55IHRleHQgb24gdGhlIHBhZ2Ugd2l0aCBhIDxiPmRvdWJsZSBjbGljazwvYj4nLFxuICAgIGluc3RydWN0aW9uOiAnJyxcbiAgfSxcbiAgLy8gYzoge1xuICAvLyAgIHRvb2w6ICAgICAgICAnc2NyZWVuc2hvdCcsXG4gIC8vICAgaWNvbjogICAgICAgIEljb25zLmNhbWVyYSxcbiAgLy8gICBsYWJlbDogICAgICAgJ1NjcmVlbnNob3QnLFxuICAvLyAgIGRlc2NyaXB0aW9uOiAnU2NyZWVuc2hvdCBzZWxlY3RlZCBlbGVtZW50cyBvciB0aGUgZW50aXJlIHBhZ2UnXG4gIC8vIH0sXG4gIHM6IHtcbiAgICB0b29sOiAgICAgICAgJ3NlYXJjaCcsXG4gICAgaWNvbjogICAgICAgIEljb25zLnNlYXJjaCxcbiAgICBsYWJlbDogICAgICAgJ1NlYXJjaCcsXG4gICAgZGVzY3JpcHRpb246ICdTZWxlY3QgZWxlbWVudHMgcHJvZ3JhbWF0aWNhbGx5IGJ5IHNlYXJjaGluZyBmb3IgdGhlbSBvciB1c2UgYnVpbHQgaW4gcGx1Z2lucyB3aXRoIHNwZWNpYWwgY29tbWFuZHMnLFxuICAgIGluc3RydWN0aW9uOiAnJyxcbiAgfSxcbn1cbiIsImltcG9ydCAkICAgICAgICAgIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzICAgIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgc3R5bGVzICAgICBmcm9tICcuL3Zpcy1idWcuZWxlbWVudC5jc3MnXG5cbmltcG9ydCB7XG4gIEhhbmRsZXMsIExhYmVsLCBPdmVybGF5LCBHcmlkbGluZXMsXG4gIEhvdGtleXMsIE1ldGF0aXAsIEFsbHksIERpc3RhbmNlLFxufSBmcm9tICcuLi8nXG5cbmltcG9ydCB7XG4gIFNlbGVjdGFibGUsIE1vdmVhYmxlLCBQYWRkaW5nLCBNYXJnaW4sIEVkaXRUZXh0LCBGb250LFxuICBGbGV4LCBTZWFyY2gsIENvbG9yUGlja2VyLCBCb3hTaGFkb3csIEh1ZVNoaWZ0LCBNZXRhVGlwLFxuICBHdWlkZXMsIFNjcmVlbnNob3QsIFBvc2l0aW9uLCBBY2Nlc3NpYmlsaXR5XG59IGZyb20gJy4uLy4uL2ZlYXR1cmVzLydcblxuaW1wb3J0IHsgVmlzQnVnTW9kZWwgfSAgICAgICAgICAgICAgZnJvbSAnLi9tb2RlbCdcbmltcG9ydCAqIGFzIEljb25zICAgICAgICAgICAgICAgICBmcm9tICcuL3Zpcy1idWcuaWNvbnMnXG5pbXBvcnQgeyBwcm92aWRlU2VsZWN0b3JFbmdpbmUgfSAgZnJvbSAnLi4vLi4vZmVhdHVyZXMvc2VhcmNoJ1xuaW1wb3J0IHsgbWV0YUtleSB9ICAgICAgICAgICAgICAgIGZyb20gJy4uLy4uL3V0aWxpdGllcy8nXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFZpc0J1ZyBleHRlbmRzIEhUTUxFbGVtZW50IHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy50b29sYmFyX21vZGVsICA9IFZpc0J1Z01vZGVsXG4gICAgdGhpcy5fdHV0c0Jhc2VVUkwgICA9ICd0dXRzJyAvLyBjYW4gYmUgc2V0IGJ5IGNvbnRlbnQgc2NyaXB0XG4gICAgdGhpcy4kc2hhZG93ICAgICAgICA9IHRoaXMuYXR0YWNoU2hhZG93KHttb2RlOiAnY2xvc2VkJ30pXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICBpZiAoIXRoaXMuJHNoYWRvdy5pbm5lckhUTUwpXG4gICAgICB0aGlzLnNldHVwKClcblxuICAgIHRoaXMuc2VsZWN0b3JFbmdpbmUgPSBTZWxlY3RhYmxlKClcbiAgICB0aGlzLmNvbG9yUGlja2VyICAgID0gQ29sb3JQaWNrZXIodGhpcy4kc2hhZG93LCB0aGlzLnNlbGVjdG9yRW5naW5lKVxuICAgIHByb3ZpZGVTZWxlY3RvckVuZ2luZSh0aGlzLnNlbGVjdG9yRW5naW5lKVxuICB9XG5cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7XG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUoKVxuICAgIHRoaXMuc2VsZWN0b3JFbmdpbmUuZGlzY29ubmVjdCgpXG4gICAgaG90a2V5cy51bmJpbmQoXG4gICAgICBPYmplY3Qua2V5cyh0aGlzLnRvb2xiYXJfbW9kZWwpLnJlZHVjZSgoZXZlbnRzLCBrZXkpID0+XG4gICAgICAgIGV2ZW50cyArPSAnLCcgKyBrZXksICcnKSlcbiAgICBob3RrZXlzLnVuYmluZChgJHttZXRhS2V5fSsvYClcbiAgfVxuXG4gIHNldHVwKCkge1xuICAgIHRoaXMuJHNoYWRvdy5pbm5lckhUTUwgPSB0aGlzLnJlbmRlcigpXG5cbiAgICAkKCdsaVtkYXRhLXRvb2xdJywgdGhpcy4kc2hhZG93KS5vbignY2xpY2snLCBlID0+XG4gICAgICB0aGlzLnRvb2xTZWxlY3RlZChlLmN1cnJlbnRUYXJnZXQpICYmIGUuc3RvcFByb3BhZ2F0aW9uKCkpXG5cbiAgICBPYmplY3QuZW50cmllcyh0aGlzLnRvb2xiYXJfbW9kZWwpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT5cbiAgICAgIGhvdGtleXMoa2V5LCBlID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIHRoaXMudG9vbFNlbGVjdGVkKFxuICAgICAgICAgICQoYFtkYXRhLXRvb2w9XCIke3ZhbHVlLnRvb2x9XCJdYCwgdGhpcy4kc2hhZG93KVswXVxuICAgICAgICApXG4gICAgICB9KVxuICAgIClcblxuICAgIGhvdGtleXMoYCR7bWV0YUtleX0rLywke21ldGFLZXl9Ky5gLCBlID0+XG4gICAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID1cbiAgICAgICAgdGhpcy4kc2hhZG93Lmhvc3Quc3R5bGUuZGlzcGxheSA9PT0gJ25vbmUnXG4gICAgICAgICAgPyAnYmxvY2snXG4gICAgICAgICAgOiAnbm9uZScpXG5cbiAgICB0aGlzLnRvb2xTZWxlY3RlZCgkKCdbZGF0YS10b29sPVwiZ3VpZGVzXCJdJywgdGhpcy4kc2hhZG93KVswXSlcbiAgfVxuXG4gIHRvb2xTZWxlY3RlZChlbCkge1xuICAgIGlmICh0eXBlb2YgZWwgPT09ICdzdHJpbmcnKVxuICAgICAgZWwgPSAkKGBbZGF0YS10b29sPVwiJHtlbH1cIl1gLCB0aGlzLiRzaGFkb3cpWzBdXG5cbiAgICBpZiAodGhpcy5hY3RpdmVfdG9vbCAmJiB0aGlzLmFjdGl2ZV90b29sLmRhdGFzZXQudG9vbCA9PT0gZWwuZGF0YXNldC50b29sKSByZXR1cm5cblxuICAgIGlmICh0aGlzLmFjdGl2ZV90b29sKSB7XG4gICAgICB0aGlzLmFjdGl2ZV90b29sLmF0dHIoJ2RhdGEtYWN0aXZlJywgbnVsbClcbiAgICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlKClcbiAgICB9XG5cbiAgICBlbC5hdHRyKCdkYXRhLWFjdGl2ZScsIHRydWUpXG4gICAgdGhpcy5hY3RpdmVfdG9vbCA9IGVsXG4gICAgdGhpc1tlbC5kYXRhc2V0LnRvb2xdKClcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcygpfVxuICAgICAgPHZpc2J1Zy1ob3RrZXlzPjwvdmlzYnVnLWhvdGtleXM+XG4gICAgICA8b2w+XG4gICAgICAgICR7T2JqZWN0LmVudHJpZXModGhpcy50b29sYmFyX21vZGVsKS5yZWR1Y2UoKGxpc3QsIFtrZXksIHRvb2xdKSA9PiBgXG4gICAgICAgICAgJHtsaXN0fVxuICAgICAgICAgIDxsaSBhcmlhLWxhYmVsPVwiJHt0b29sLmxhYmVsfSBUb29sXCIgYXJpYS1kZXNjcmlwdGlvbj1cIiR7dG9vbC5kZXNjcmlwdGlvbn1cIiBhcmlhLWhvdGtleT1cIiR7a2V5fVwiIGRhdGEtdG9vbD1cIiR7dG9vbC50b29sfVwiIGRhdGEtYWN0aXZlPVwiJHtrZXkgPT0gJ2cnfVwiPlxuICAgICAgICAgICAgJHt0b29sLmljb259XG4gICAgICAgICAgICAke3RoaXMuZGVtb1RpcCh7a2V5LCAuLi50b29sfSl9XG4gICAgICAgICAgPC9saT5cbiAgICAgICAgYCwnJyl9XG4gICAgICA8L29sPlxuICAgICAgPG9sIGNvbG9ycz5cbiAgICAgICAgPGxpIHN0eWxlPVwiZGlzcGxheTogbm9uZTtcIiBjbGFzcz1cImNvbG9yXCIgaWQ9XCJmb3JlZ3JvdW5kXCIgYXJpYS1sYWJlbD1cIlRleHRcIiBhcmlhLWRlc2NyaXB0aW9uPVwiQ2hhbmdlIHRoZSB0ZXh0IGNvbG9yXCI+XG4gICAgICAgICAgPGlucHV0IHR5cGU9XCJjb2xvclwiIHZhbHVlPVwiXCI+XG4gICAgICAgICAgJHtJY29ucy5jb2xvcl90ZXh0fVxuICAgICAgICA8L2xpPlxuICAgICAgICA8bGkgc3R5bGU9XCJkaXNwbGF5OiBub25lO1wiIGNsYXNzPVwiY29sb3JcIiBpZD1cImJhY2tncm91bmRcIiBhcmlhLWxhYmVsPVwiQmFja2dyb3VuZCBvciBGaWxsXCIgYXJpYS1kZXNjcmlwdGlvbj1cIkNoYW5nZSB0aGUgYmFja2dyb3VuZCBjb2xvciBvciBmaWxsIG9mIHN2Z1wiPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY29sb3JcIiB2YWx1ZT1cIlwiPlxuICAgICAgICAgICR7SWNvbnMuY29sb3JfYmFja2dyb3VuZH1cbiAgICAgICAgPC9saT5cbiAgICAgICAgPGxpIHN0eWxlPVwiZGlzcGxheTogbm9uZTtcIiBjbGFzcz1cImNvbG9yXCIgaWQ9XCJib3JkZXJcIiBhcmlhLWxhYmVsPVwiQm9yZGVyIG9yIFN0cm9rZVwiIGFyaWEtZGVzY3JpcHRpb249XCJDaGFuZ2UgdGhlIGJvcmRlciBjb2xvciBvciBzdHJva2Ugb2Ygc3ZnXCI+XG4gICAgICAgICAgPGlucHV0IHR5cGU9XCJjb2xvclwiIHZhbHVlPVwiXCI+XG4gICAgICAgICAgJHtJY29ucy5jb2xvcl9ib3JkZXJ9XG4gICAgICAgIDwvbGk+XG4gICAgICA8L29sPlxuICAgIGBcbiAgfVxuXG4gIHN0eWxlcygpIHtcbiAgICByZXR1cm4gYFxuICAgICAgPHN0eWxlPlxuICAgICAgICAke3N0eWxlc31cbiAgICAgIDwvc3R5bGU+XG4gICAgYFxuICB9XG5cbiAgZGVtb1RpcCh7a2V5LCB0b29sLCBsYWJlbCwgZGVzY3JpcHRpb24sIGluc3RydWN0aW9ufSkge1xuICAgIHJldHVybiBgXG4gICAgICA8YXNpZGUgJHt0b29sfT5cbiAgICAgICAgPGZpZ3VyZT5cbiAgICAgICAgICA8aW1nIHNyYz1cIiR7dGhpcy5fdHV0c0Jhc2VVUkx9LyR7dG9vbH0uZ2lmXCIgYWx0PVwiJHtkZXNjcmlwdGlvbn1cIiAvPlxuICAgICAgICAgIDxmaWdjYXB0aW9uPlxuICAgICAgICAgICAgPGgyPlxuICAgICAgICAgICAgICAke2xhYmVsfVxuICAgICAgICAgICAgICA8c3BhbiBob3RrZXk+JHtrZXl9PC9zcGFuPlxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgIDxwPiR7ZGVzY3JpcHRpb259PC9wPlxuICAgICAgICAgICAgJHtpbnN0cnVjdGlvbn1cbiAgICAgICAgICA8L2ZpZ2NhcHRpb24+XG4gICAgICAgIDwvZmlndXJlPlxuICAgICAgPC9hc2lkZT5cbiAgICBgXG4gIH1cblxuICBtb3ZlKCkge1xuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gTW92ZWFibGUodGhpcy5zZWxlY3RvckVuZ2luZSlcbiAgfVxuXG4gIG1hcmdpbigpIHtcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9IE1hcmdpbih0aGlzLnNlbGVjdG9yRW5naW5lKVxuICB9XG5cbiAgcGFkZGluZygpIHtcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9IFBhZGRpbmcodGhpcy5zZWxlY3RvckVuZ2luZSlcbiAgfVxuXG4gIGZvbnQoKSB7XG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSBGb250KHRoaXMuc2VsZWN0b3JFbmdpbmUpXG4gIH1cblxuICB0ZXh0KCkge1xuICAgIHRoaXMuc2VsZWN0b3JFbmdpbmUub25TZWxlY3RlZFVwZGF0ZShFZGl0VGV4dClcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9ICgpID0+XG4gICAgICB0aGlzLnNlbGVjdG9yRW5naW5lLnJlbW92ZVNlbGVjdGVkQ2FsbGJhY2soRWRpdFRleHQpXG4gIH1cblxuICBhbGlnbigpIHtcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9IEZsZXgodGhpcy5zZWxlY3RvckVuZ2luZSlcbiAgfVxuXG4gIHNlYXJjaCgpIHtcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9IFNlYXJjaCgkKCdbZGF0YS10b29sPVwic2VhcmNoXCJdJywgdGhpcy4kc2hhZG93KSlcbiAgfVxuXG4gIGJveHNoYWRvdygpIHtcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9IEJveFNoYWRvdyh0aGlzLnNlbGVjdG9yRW5naW5lKVxuICB9XG5cbiAgaHVlc2hpZnQoKSB7XG4gICAgbGV0IGZlYXR1cmUgPSBIdWVTaGlmdCh0aGlzLmNvbG9yUGlja2VyKVxuICAgIHRoaXMuc2VsZWN0b3JFbmdpbmUub25TZWxlY3RlZFVwZGF0ZShmZWF0dXJlLm9uTm9kZXNTZWxlY3RlZClcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9ICgpID0+IHtcbiAgICAgIHRoaXMuc2VsZWN0b3JFbmdpbmUucmVtb3ZlU2VsZWN0ZWRDYWxsYmFjayhmZWF0dXJlLm9uTm9kZXNTZWxlY3RlZClcbiAgICAgIGZlYXR1cmUuZGlzY29ubmVjdCgpXG4gICAgfVxuICB9XG5cbiAgaW5zcGVjdG9yKCkge1xuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gTWV0YVRpcCh0aGlzLnNlbGVjdG9yRW5naW5lKVxuICB9XG5cbiAgYWNjZXNzaWJpbGl0eSgpIHtcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9IEFjY2Vzc2liaWxpdHkoKVxuICB9XG5cbiAgZ3VpZGVzKCkge1xuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gR3VpZGVzKClcbiAgfVxuXG4gIHNjcmVlbnNob3QoKSB7XG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSBTY3JlZW5zaG90KClcbiAgfVxuXG4gIHBvc2l0aW9uKCkge1xuICAgIGxldCBmZWF0dXJlID0gUG9zaXRpb24oKVxuICAgIHRoaXMuc2VsZWN0b3JFbmdpbmUub25TZWxlY3RlZFVwZGF0ZShmZWF0dXJlLm9uTm9kZXNTZWxlY3RlZClcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9ICgpID0+IHtcbiAgICAgIHRoaXMuc2VsZWN0b3JFbmdpbmUucmVtb3ZlU2VsZWN0ZWRDYWxsYmFjayhmZWF0dXJlLm9uTm9kZXNTZWxlY3RlZClcbiAgICAgIGZlYXR1cmUuZGlzY29ubmVjdCgpXG4gICAgfVxuICB9XG5cbiAgZ2V0IGFjdGl2ZVRvb2woKSB7XG4gICAgcmV0dXJuIHRoaXMuYWN0aXZlX3Rvb2wuZGF0YXNldC50b29sXG4gIH1cblxuICBzZXQgdHV0c0Jhc2VVUkwodXJsKSB7XG4gICAgdGhpcy5fdHV0c0Jhc2VVUkwgPSB1cmxcbiAgICB0aGlzLnNldHVwKClcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ3Zpcy1idWcnLCBWaXNCdWcpXG4iLCJpbXBvcnQgVmlzQnVnIGZyb20gJy4vY29tcG9uZW50cy92aXMtYnVnL3Zpcy1idWcuZWxlbWVudCdcbmltcG9ydCB7IG1ldGFLZXkgfSBmcm9tICcuL3V0aWxpdGllcydcblxuaWYgKCdvbnRvdWNoc3RhcnQnIGluIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudClcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ21vYmlsZS1pbmZvJykuc3R5bGUuZGlzcGxheSA9ICcnXG5cbmlmIChtZXRhS2V5ID09PSAnY3RybCcpXG4gIFsuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdrYmQnKV1cbiAgICAuZm9yRWFjaChub2RlID0+IHtcbiAgICAgIG5vZGUudGV4dENvbnRlbnQgPSBub2RlLnRleHRDb250ZW50LnJlcGxhY2UoJ2NtZCcsJ2N0cmwnKVxuICAgICAgbm9kZS50ZXh0Q29udGVudCA9IG5vZGUudGV4dENvbnRlbnQucmVwbGFjZSgnb3B0JywnYWx0JylcbiAgICB9KVxuIl0sIm5hbWVzIjpbInN0eWxlcyIsImhvdGtleXMiLCJpY29uIiwia2V5X2V2ZW50cyIsImNvbW1hbmRzIiwiYmxhbmtfcGFnZV9jb21tYW5kcyIsImJhcnJlbF9yb2xsX2NvbW1hbmRzIiwicGVzdGljaWRlX2NvbW1hbmRzIiwiY29uc3RydWN0X2NvbW1hbmRzIiwiY29uc3RydWN0X2RlYnVnX2NvbW1hbmRzIiwid2lyZWZyYW1lX2NvbW1hbmRzIiwic2tlbGV0b25fY29tbWFuZHMiLCJ0YWdfZGVidWdnZXJfY29tbWFuZHMiLCJyZXZlbmdlX2NvbW1hbmRzIiwic2VhcmNoIiwic3RhdGUiLCJtb3VzZU1vdmUiLCJ0b2dnbGVQaW5uZWQiLCJyZW1vdmVBbGwiLCJyZXN0b3JlUGlubmVkVGlwcyIsImhpZGVBbGwiLCJ3aXBlIiwiY2xlYXJBY3RpdmUiLCJ0b2dnbGVUYXJnZXRDdXJzb3IiLCJzaG93VGlwIiwicmVuZGVyIiwicG9zaXRpb25UaXAiLCJvYnNlcnZlIiwibW91c2VfcXVhZHJhbnQiLCJ0aXBfcG9zaXRpb24iLCJ1bm9ic2VydmUiLCJoYW5kbGVCbHVyIiwicmVtb3ZlQWxsQWNjZXNzaWJpbGl0eVRpcHMiLCJzaG93QWNjZXNzaWJpbGl0eVRpcCIsInJlbW92ZUFsbE1ldGFUaXBzIiwic2hvd01ldGFUaXAiLCJjb21tYW5kX2V2ZW50cyIsInN0b3BCdWJibGluZyIsImhfYWxpZ25PcHRpb25zIiwidl9hbGlnbk9wdGlvbnMiLCJJY29ucy5ndWlkZXMiLCJJY29ucy5pbnNwZWN0b3IiLCJJY29ucy5hY2Nlc3NpYmlsaXR5IiwiSWNvbnMubW92ZSIsIkljb25zLm1hcmdpbiIsIkljb25zLnBhZGRpbmciLCJJY29ucy5hbGlnbiIsIkljb25zLmh1ZXNoaWZ0IiwiSWNvbnMuYm94c2hhZG93IiwiSWNvbnMucG9zaXRpb24iLCJJY29ucy5mb250IiwiSWNvbnMudGV4dCIsIkljb25zLnNlYXJjaCIsIkljb25zLmNvbG9yX3RleHQiLCJJY29ucy5jb2xvcl9iYWNrZ3JvdW5kIiwiSWNvbnMuY29sb3JfYm9yZGVyIl0sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLEtBQUssR0FBRztFQUNaLEVBQUUsRUFBRSxTQUFTLEtBQUssRUFBRSxFQUFFLEVBQUU7SUFDdEIsS0FBSztPQUNGLEtBQUssQ0FBQyxHQUFHLENBQUM7T0FDVixPQUFPLENBQUMsSUFBSTtRQUNYLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLEVBQUM7SUFDcEMsT0FBTyxJQUFJO0dBQ1o7RUFDRCxHQUFHLEVBQUUsU0FBUyxLQUFLLEVBQUUsRUFBRSxFQUFFO0lBQ3ZCLEtBQUs7T0FDRixLQUFLLENBQUMsR0FBRyxDQUFDO09BQ1YsT0FBTyxDQUFDLElBQUk7UUFDWCxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxFQUFDO0lBQ3ZDLE9BQU8sSUFBSTtHQUNaO0VBQ0QsSUFBSSxFQUFFLFNBQVMsSUFBSSxFQUFFLEdBQUcsRUFBRTtJQUN4QixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQzs7SUFFckQsR0FBRyxJQUFJLElBQUk7UUFDUCxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQztRQUMxQixJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxHQUFHLElBQUksRUFBRSxFQUFDOztJQUV0QyxPQUFPLElBQUk7R0FDWjtFQUNGOztBQUVELEFBQWUsU0FBUyxDQUFDLENBQUMsS0FBSyxFQUFFLFFBQVEsR0FBRyxRQUFRLEVBQUU7RUFDcEQsSUFBSSxNQUFNLEdBQUcsS0FBSyxZQUFZLFFBQVEsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztNQUMxRCxLQUFLO01BQ0wsS0FBSyxZQUFZLFdBQVcsSUFBSSxLQUFLLFlBQVksVUFBVTtRQUN6RCxDQUFDLEtBQUssQ0FBQztRQUNQLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUM7O0VBRXRDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLE1BQU0sR0FBRyxHQUFFOztFQUUvQixPQUFPLE1BQU0sQ0FBQyxNQUFNO0lBQ2xCLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2pEO01BQ0UsRUFBRSxFQUFFLFNBQVMsS0FBSyxFQUFFLEVBQUUsRUFBRTtRQUN0QixJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsRUFBQztRQUN0QyxPQUFPLElBQUk7T0FDWjtNQUNELEdBQUcsRUFBRSxTQUFTLEtBQUssRUFBRSxFQUFFLEVBQUU7UUFDdkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLEVBQUM7UUFDdkMsT0FBTyxJQUFJO09BQ1o7TUFDRCxJQUFJLEVBQUUsU0FBUyxLQUFLLEVBQUUsR0FBRyxFQUFFO1FBQ3pCLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxJQUFJLEdBQUcsS0FBSyxTQUFTO1VBQ2hELE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7O2FBRXZCLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUTtVQUNoQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUc7WUFDZCxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztlQUNsQixPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7Z0JBQ2xCLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUM7O2FBRXZCLElBQUksT0FBTyxLQUFLLElBQUksUUFBUSxLQUFLLEdBQUcsSUFBSSxHQUFHLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLENBQUM7VUFDcEUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLEVBQUM7O1FBRTNDLE9BQU8sSUFBSTtPQUNaO0tBQ0Y7R0FDRjs7O0FDOURIOzs7Ozs7Ozs7O0FBVUEsSUFBSSxJQUFJLEdBQUcsT0FBTyxTQUFTLEtBQUssV0FBVyxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUM7OztBQUcvRyxTQUFTLFFBQVEsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRTtFQUN2QyxJQUFJLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRTtJQUMzQixNQUFNLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztHQUMvQyxNQUFNLElBQUksTUFBTSxDQUFDLFdBQVcsRUFBRTtJQUM3QixNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyxLQUFLLEVBQUUsWUFBWTtNQUMzQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0tBQ3RCLENBQUMsQ0FBQztHQUNKO0NBQ0Y7OztBQUdELFNBQVMsT0FBTyxDQUFDLFFBQVEsRUFBRSxHQUFHLEVBQUU7RUFDOUIsSUFBSSxJQUFJLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztFQUN4QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtJQUNwQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO0dBQzNDLE9BQU8sSUFBSSxDQUFDO0NBQ2Q7OztBQUdELFNBQVMsT0FBTyxDQUFDLEdBQUcsRUFBRTtFQUNwQixJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsR0FBRyxFQUFFLENBQUM7O0VBRW5CLEdBQUcsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztFQUM3QixJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQzFCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7OztFQUdqQyxPQUFPLEtBQUssSUFBSSxDQUFDLEdBQUc7SUFDbEIsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUM7SUFDdkIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDdEIsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7R0FDOUI7O0VBRUQsT0FBTyxJQUFJLENBQUM7Q0FDYjs7O0FBR0QsU0FBUyxZQUFZLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRTtFQUM1QixJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxNQUFNLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztFQUM1QyxJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxNQUFNLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztFQUM1QyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUM7O0VBRW5CLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO0lBQ3BDLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxPQUFPLEdBQUcsS0FBSyxDQUFDO0dBQ25EO0VBQ0QsT0FBTyxPQUFPLENBQUM7Q0FDaEI7O0FBRUQsSUFBSSxPQUFPLEdBQUc7RUFDWixTQUFTLEVBQUUsQ0FBQztFQUNaLEdBQUcsRUFBRSxDQUFDO0VBQ04sS0FBSyxFQUFFLEVBQUU7RUFDVCxLQUFLLEVBQUUsRUFBRTtFQUNULE1BQU0sRUFBRSxFQUFFO0VBQ1YsR0FBRyxFQUFFLEVBQUU7RUFDUCxNQUFNLEVBQUUsRUFBRTtFQUNWLEtBQUssRUFBRSxFQUFFO0VBQ1QsSUFBSSxFQUFFLEVBQUU7RUFDUixFQUFFLEVBQUUsRUFBRTtFQUNOLEtBQUssRUFBRSxFQUFFO0VBQ1QsSUFBSSxFQUFFLEVBQUU7RUFDUixHQUFHLEVBQUUsRUFBRTtFQUNQLE1BQU0sRUFBRSxFQUFFO0VBQ1YsR0FBRyxFQUFFLEVBQUU7RUFDUCxNQUFNLEVBQUUsRUFBRTtFQUNWLElBQUksRUFBRSxFQUFFO0VBQ1IsR0FBRyxFQUFFLEVBQUU7RUFDUCxNQUFNLEVBQUUsRUFBRTtFQUNWLFFBQVEsRUFBRSxFQUFFO0VBQ1osUUFBUSxFQUFFLEVBQUU7RUFDWixHQUFHLEVBQUUsRUFBRTtFQUNQLEdBQUcsRUFBRSxHQUFHO0VBQ1IsR0FBRyxFQUFFLEdBQUc7RUFDUixHQUFHLEVBQUUsR0FBRztFQUNSLEdBQUcsRUFBRSxHQUFHO0VBQ1IsR0FBRyxFQUFFLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRztFQUNyQixHQUFHLEVBQUUsSUFBSSxHQUFHLEVBQUUsR0FBRyxHQUFHO0VBQ3BCLEdBQUcsRUFBRSxJQUFJLEdBQUcsRUFBRSxHQUFHLEdBQUc7RUFDcEIsSUFBSSxFQUFFLEdBQUc7RUFDVCxHQUFHLEVBQUUsR0FBRztFQUNSLEdBQUcsRUFBRSxHQUFHO0VBQ1IsSUFBSSxFQUFFLEdBQUc7Q0FDVixDQUFDOztBQUVGLElBQUksU0FBUyxHQUFHO0VBQ2QsR0FBRyxFQUFFLEVBQUU7RUFDUCxLQUFLLEVBQUUsRUFBRTtFQUNULEdBQUcsRUFBRSxFQUFFO0VBQ1AsR0FBRyxFQUFFLEVBQUU7RUFDUCxNQUFNLEVBQUUsRUFBRTtFQUNWLEdBQUcsRUFBRSxFQUFFO0VBQ1AsSUFBSSxFQUFFLEVBQUU7RUFDUixPQUFPLEVBQUUsRUFBRTtFQUNYLEdBQUcsRUFBRSxJQUFJLEdBQUcsR0FBRyxHQUFHLEVBQUU7RUFDcEIsR0FBRyxFQUFFLElBQUksR0FBRyxHQUFHLEdBQUcsRUFBRTtFQUNwQixPQUFPLEVBQUUsSUFBSSxHQUFHLEdBQUcsR0FBRyxFQUFFO0NBQ3pCLENBQUM7QUFDRixJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUM7QUFDbkIsSUFBSSxXQUFXLEdBQUc7RUFDaEIsRUFBRSxFQUFFLFVBQVU7RUFDZCxFQUFFLEVBQUUsUUFBUTtFQUNaLEVBQUUsRUFBRSxTQUFTO0NBQ2QsQ0FBQztBQUNGLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQztBQUNoRCxJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUM7OztBQUduQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFO0VBQzNCLE9BQU8sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztDQUM1Qjs7O0FBR0QsV0FBVyxDQUFDLElBQUksR0FBRyxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDO0FBQ3pDLEtBQUssQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQzs7QUFFL0IsSUFBSSxNQUFNLEdBQUcsS0FBSyxDQUFDO0FBQ25CLElBQUksYUFBYSxHQUFHLEtBQUssQ0FBQzs7O0FBRzFCLElBQUksSUFBSSxHQUFHLFNBQVMsSUFBSSxDQUFDLENBQUMsRUFBRTtFQUMxQixPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0NBQ2xFLENBQUM7OztBQUdGLFNBQVMsUUFBUSxDQUFDLEtBQUssRUFBRTtFQUN2QixNQUFNLEdBQUcsS0FBSyxJQUFJLEtBQUssQ0FBQztDQUN6Qjs7QUFFRCxTQUFTLFFBQVEsR0FBRztFQUNsQixPQUFPLE1BQU0sSUFBSSxLQUFLLENBQUM7Q0FDeEI7O0FBRUQsU0FBUyxrQkFBa0IsR0FBRztFQUM1QixPQUFPLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Q0FDM0I7OztBQUdELFNBQVMsTUFBTSxDQUFDLEtBQUssRUFBRTtFQUNyQixJQUFJLE9BQU8sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQzs7RUFFL0QsT0FBTyxFQUFFLE9BQU8sS0FBSyxPQUFPLElBQUksT0FBTyxLQUFLLFFBQVEsSUFBSSxPQUFPLEtBQUssVUFBVSxDQUFDLENBQUM7Q0FDakY7OztBQUdELFNBQVMsU0FBUyxDQUFDLE9BQU8sRUFBRTtFQUMxQixJQUFJLE9BQU8sT0FBTyxLQUFLLFFBQVEsRUFBRTtJQUMvQixPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0dBQ3pCO0VBQ0QsT0FBTyxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0NBQzFDOzs7QUFHRCxTQUFTLFdBQVcsQ0FBQyxLQUFLLEVBQUUsUUFBUSxFQUFFO0VBQ3BDLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxDQUFDO0VBQ3RCLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDOzs7RUFHZixJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssR0FBRyxRQUFRLEVBQUUsQ0FBQzs7RUFFL0IsS0FBSyxJQUFJLEdBQUcsSUFBSSxTQUFTLEVBQUU7SUFDekIsSUFBSSxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxFQUFFO01BQ3hELFFBQVEsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7TUFDMUIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxHQUFHO1FBQ2hDLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxLQUFLLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztPQUNqRTtLQUNGO0dBQ0Y7OztFQUdELElBQUksUUFBUSxFQUFFLEtBQUssS0FBSyxFQUFFLFFBQVEsQ0FBQyxRQUFRLElBQUksS0FBSyxDQUFDLENBQUM7Q0FDdkQ7OztBQUdELFNBQVMsYUFBYSxDQUFDLEtBQUssRUFBRTtFQUM1QixJQUFJLEdBQUcsR0FBRyxLQUFLLENBQUMsT0FBTyxJQUFJLEtBQUssQ0FBQyxLQUFLLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQztFQUN6RCxJQUFJLENBQUMsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7RUFHL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDOzs7RUFHbkMsSUFBSSxHQUFHLEtBQUssRUFBRSxJQUFJLEdBQUcsS0FBSyxHQUFHLEVBQUUsR0FBRyxHQUFHLEVBQUUsQ0FBQztFQUN4QyxJQUFJLEdBQUcsSUFBSSxLQUFLLEVBQUU7SUFDaEIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQzs7O0lBR25CLEtBQUssSUFBSSxDQUFDLElBQUksU0FBUyxFQUFFO01BQ3ZCLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDO0tBQzlDO0dBQ0Y7Q0FDRjs7O0FBR0QsU0FBUyxNQUFNLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRTtFQUMxQixJQUFJLFlBQVksR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDaEMsSUFBSSxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUM7RUFDbEIsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO0VBQ2QsSUFBSSxHQUFHLEdBQUcsS0FBSyxDQUFDLENBQUM7O0VBRWpCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFOztJQUU1QyxJQUFJLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O0lBR2xDLElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsSUFBSSxHQUFHLE9BQU8sQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7OztJQUdyRCxHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDNUIsR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O0lBR3BDLElBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSyxHQUFHLFFBQVEsRUFBRSxDQUFDOzs7SUFHL0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxPQUFPOzs7O0lBSTVCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO01BQzlDLEdBQUcsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O01BRXhCLElBQUksR0FBRyxDQUFDLEtBQUssS0FBSyxLQUFLLElBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEVBQUU7UUFDdkQsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztPQUN4QjtLQUNGO0dBQ0Y7Q0FDRjs7O0FBR0QsU0FBUyxZQUFZLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUU7RUFDM0MsSUFBSSxjQUFjLEdBQUcsS0FBSyxDQUFDLENBQUM7OztFQUc1QixJQUFJLE9BQU8sQ0FBQyxLQUFLLEtBQUssS0FBSyxJQUFJLE9BQU8sQ0FBQyxLQUFLLEtBQUssS0FBSyxFQUFFOztJQUV0RCxjQUFjLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDOztJQUV6QyxLQUFLLElBQUksQ0FBQyxJQUFJLEtBQUssRUFBRTtNQUNuQixJQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUU7UUFDbEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLGNBQWMsR0FBRyxLQUFLLENBQUM7T0FDdkg7S0FDRjs7O0lBR0QsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksY0FBYyxJQUFJLE9BQU8sQ0FBQyxRQUFRLEtBQUssR0FBRyxFQUFFO01BQ25JLElBQUksT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUssS0FBSyxFQUFFO1FBQzVDLElBQUksS0FBSyxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsY0FBYyxFQUFFLENBQUMsS0FBSyxLQUFLLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztRQUNoRixJQUFJLEtBQUssQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ25ELElBQUksS0FBSyxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztPQUNuRDtLQUNGO0dBQ0Y7Q0FDRjs7O0FBR0QsU0FBUyxRQUFRLENBQUMsS0FBSyxFQUFFO0VBQ3ZCLElBQUksUUFBUSxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUM5QixJQUFJLEdBQUcsR0FBRyxLQUFLLENBQUMsT0FBTyxJQUFJLEtBQUssQ0FBQyxLQUFLLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQzs7O0VBR3pELElBQUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7O0VBSXZELElBQUksR0FBRyxLQUFLLEVBQUUsSUFBSSxHQUFHLEtBQUssR0FBRyxFQUFFLEdBQUcsR0FBRyxFQUFFLENBQUM7O0VBRXhDLElBQUksR0FBRyxJQUFJLEtBQUssRUFBRTtJQUNoQixLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDOzs7SUFHbEIsS0FBSyxJQUFJLENBQUMsSUFBSSxTQUFTLEVBQUU7TUFDdkIsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7S0FDN0M7O0lBRUQsSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPO0dBQ3ZCOzs7RUFHRCxLQUFLLElBQUksQ0FBQyxJQUFJLEtBQUssRUFBRTtJQUNuQixJQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUU7TUFDbEQsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNsQztHQUNGOzs7RUFHRCxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxFQUFFLE9BQU87OztFQUc5QyxJQUFJLEtBQUssR0FBRyxRQUFRLEVBQUUsQ0FBQzs7O0VBR3ZCLElBQUksUUFBUSxFQUFFO0lBQ1osS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7TUFDeEMsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEtBQUssRUFBRSxZQUFZLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztLQUMxRTtHQUNGOztFQUVELElBQUksRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLEVBQUUsT0FBTzs7RUFFaEMsS0FBSyxJQUFJLEVBQUUsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLEVBQUU7O0lBRWpELFlBQVksQ0FBQyxLQUFLLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO0dBQ2hEO0NBQ0Y7O0FBRUQsU0FBUyxPQUFPLENBQUMsR0FBRyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUU7RUFDcEMsSUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQ3hCLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztFQUNkLElBQUksS0FBSyxHQUFHLEtBQUssQ0FBQztFQUNsQixJQUFJLE9BQU8sR0FBRyxRQUFRLENBQUM7RUFDdkIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7RUFHVixJQUFJLE1BQU0sS0FBSyxTQUFTLElBQUksT0FBTyxNQUFNLEtBQUssVUFBVSxFQUFFO0lBQ3hELE1BQU0sR0FBRyxNQUFNLENBQUM7R0FDakI7O0VBRUQsSUFBSSxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssaUJBQWlCLEVBQUU7SUFDaEUsSUFBSSxNQUFNLENBQUMsS0FBSyxFQUFFLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDO0lBQ3ZDLElBQUksTUFBTSxDQUFDLE9BQU8sRUFBRSxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztHQUM5Qzs7RUFFRCxJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVEsRUFBRSxLQUFLLEdBQUcsTUFBTSxDQUFDOzs7RUFHL0MsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtJQUMzQixHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN6QixJQUFJLEdBQUcsRUFBRSxDQUFDOzs7SUFHVixJQUFJLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLElBQUksR0FBRyxPQUFPLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDOzs7SUFHbkQsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQzFCLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7OztJQUdwQyxJQUFJLEVBQUUsR0FBRyxJQUFJLFNBQVMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7O0lBRTdDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7TUFDbEIsS0FBSyxFQUFFLEtBQUs7TUFDWixJQUFJLEVBQUUsSUFBSTtNQUNWLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO01BQ2pCLE1BQU0sRUFBRSxNQUFNO01BQ2QsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7S0FDYixDQUFDLENBQUM7R0FDSjs7RUFFRCxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxDQUFDLGFBQWEsRUFBRTtJQUNwRCxhQUFhLEdBQUcsSUFBSSxDQUFDO0lBQ3JCLFFBQVEsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFVBQVUsQ0FBQyxFQUFFO01BQ3hDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNiLENBQUMsQ0FBQztJQUNILFFBQVEsQ0FBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQyxFQUFFO01BQ3RDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNsQixDQUFDLENBQUM7R0FDSjtDQUNGOztBQUVELElBQUksSUFBSSxHQUFHO0VBQ1QsUUFBUSxFQUFFLFFBQVE7RUFDbEIsUUFBUSxFQUFFLFFBQVE7RUFDbEIsV0FBVyxFQUFFLFdBQVc7RUFDeEIsa0JBQWtCLEVBQUUsa0JBQWtCO0VBQ3RDLFNBQVMsRUFBRSxTQUFTO0VBQ3BCLE1BQU0sRUFBRSxNQUFNO0VBQ2QsTUFBTSxFQUFFLE1BQU07Q0FDZixDQUFDO0FBQ0YsS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLEVBQUU7RUFDbEIsSUFBSSxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFO0lBQ2pELE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7R0FDdEI7Q0FDRjs7QUFFRCxJQUFJLE9BQU8sTUFBTSxLQUFLLFdBQVcsRUFBRTtFQUNqQyxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDO0VBQzlCLE9BQU8sQ0FBQyxVQUFVLEdBQUcsVUFBVSxJQUFJLEVBQUU7SUFDbkMsSUFBSSxJQUFJLElBQUksTUFBTSxDQUFDLE9BQU8sS0FBSyxPQUFPLEVBQUU7TUFDdEMsTUFBTSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUM7S0FDM0I7SUFDRCxPQUFPLE9BQU8sQ0FBQztHQUNoQixDQUFDO0VBQ0YsTUFBTSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7Q0FDMUI7Ozs7QUMxWU0sTUFBTSxPQUFPLFNBQVMsV0FBVyxDQUFDOztFQUV2QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7SUFDUCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLEVBQUM7R0FDbkQ7O0VBRUQsaUJBQWlCLEdBQUc7SUFDbEIsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQztHQUM3RDtFQUNELG9CQUFvQixHQUFHO0lBQ3JCLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBQztHQUNyRDs7RUFFRCxTQUFTLEdBQUc7SUFDVixNQUFNLENBQUMscUJBQXFCLENBQUMsTUFBTTtNQUNqQyxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFDO01BQ3JFLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhLENBQUMsRUFBRSxDQUFDLEVBQUM7O01BRTNELElBQUksQ0FBQyxTQUFTLEVBQUUsTUFBTTs7TUFFdEIsSUFBSSxDQUFDLFFBQVEsR0FBRztRQUNkLGFBQWE7UUFDYixZQUFZLEVBQUUsU0FBUyxDQUFDLHFCQUFxQixFQUFFO1FBQ2hEO0tBQ0YsRUFBQztHQUNIOztFQUVELElBQUksUUFBUSxDQUFDLENBQUMsWUFBWSxFQUFFLGFBQWEsQ0FBQyxFQUFFO0lBQzFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLGFBQWEsRUFBQztHQUNuRTs7RUFFRCxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFLGFBQWEsRUFBRTtJQUN4RCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFFLGFBQWEsRUFBQztJQUM5RCxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzs7O2VBR2pCLEVBQUUsS0FBSyxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUM7cUJBQ3JCLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUM7Ozs7Ozs7O21DQVFKLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQzswQ0FDSCxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7bUNBQ2xCLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDO21DQUN6QixFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQzs7SUFFeEQsQ0FBQztHQUNGOztFQUVELE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRTtJQUNqQixPQUFPLENBQUM7Ozs7ZUFJRyxFQUFFLEdBQUcsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDO2dCQUN0QixFQUFFLElBQUksQ0FBQzs7Ozs7O0lBTW5CLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDOztBQ3RFekMsTUFBTSxLQUFLLFNBQVMsT0FBTyxDQUFDOztFQUVqQyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7R0FDUjs7RUFFRCxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFO0lBQ3pDLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7a0JBZWQsRUFBRSxLQUFLLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQzs7O0lBR3pDLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQzs7QUMvQnJDLE1BQU0sS0FBSyxTQUFTLFdBQVcsQ0FBQzs7RUFFckMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFO0lBQ1AsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxFQUFDO0dBQ25EOztFQUVELGlCQUFpQixHQUFHO0lBQ2xCLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQztJQUMxRSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDO0dBQzdEOztFQUVELG9CQUFvQixHQUFHO0lBQ3JCLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBQztJQUNyRCxNQUFNLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUM7R0FDckQ7O0VBRUQsU0FBUyxHQUFHO0lBQ1YsTUFBTSxDQUFDLHFCQUFxQixDQUFDLE1BQU07TUFDakMsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsRUFBQztNQUNyRSxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUsYUFBYSxDQUFDLEVBQUUsQ0FBQyxFQUFDOztNQUU3RCxJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU07O01BRXRCLElBQUksQ0FBQyxRQUFRLEdBQUc7UUFDZCxhQUFhO1FBQ2IsWUFBWSxFQUFFLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRTtRQUNoRDtLQUNGLEVBQUM7R0FDSDs7RUFFRCxhQUFhLENBQUMsQ0FBQyxFQUFFO0lBQ2YsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksV0FBVyxDQUFDLE9BQU8sRUFBRTtNQUN2RCxPQUFPLEVBQUUsSUFBSTtNQUNiLE1BQU0sSUFBSTtRQUNSLElBQUksUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVc7UUFDaEMsU0FBUyxHQUFHLENBQUMsQ0FBQyxJQUFJO09BQ25CO0tBQ0YsQ0FBQyxFQUFDO0dBQ0o7O0VBRUQsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO0lBQ2hCLElBQUksQ0FBQyxLQUFLLEdBQUcsUUFBTztHQUNyQjs7RUFFRCxJQUFJLFFBQVEsQ0FBQyxDQUFDLFlBQVksRUFBRSxhQUFhLENBQUMsRUFBRTtJQUMxQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxhQUFhLEVBQUM7R0FDbkU7O0VBRUQsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7SUFDaEIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFDO0lBQ3RDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxNQUFNLENBQUMsT0FBTyxHQUFHLEtBQUk7SUFDNUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFJO0dBQ2hDOztFQUVELE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUUsYUFBYSxFQUFFO0lBQ3hELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLEVBQUUsYUFBYSxFQUFDOztJQUU5RCxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7O1FBRTlCLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQzs7SUFFakIsQ0FBQztHQUNGOztFQUVELE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7SUFDdkIsT0FBTyxDQUFDOzs7Ozs7OztlQVFHLEVBQUUsR0FBRyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUM7Z0JBQ3RCLEVBQUUsSUFBSSxHQUFHLENBQUMsQ0FBQztxQkFDTixFQUFFLEtBQUssSUFBSSxNQUFNLENBQUMsVUFBVSxHQUFHLElBQUksR0FBRyxLQUFLLEdBQUcsRUFBRSxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lBc0NuRSxDQUFDO0dBQ0Y7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUM7O0FDekhyQyxNQUFNLGNBQWMsR0FBRztFQUM1QixLQUFLLGdCQUFnQixjQUFjO0VBQ25DLGVBQWUsTUFBTSxrQkFBa0I7RUFDdkMsZUFBZSxNQUFNLE1BQU07RUFDM0IsY0FBYyxPQUFPLE1BQU07RUFDM0Isa0JBQWtCLEdBQUcsT0FBTzs7RUFFNUIsV0FBVyxVQUFVLEtBQUs7RUFDMUIsWUFBWSxTQUFTLEtBQUs7RUFDMUIsU0FBUyxZQUFZLE1BQU07RUFDM0IsT0FBTyxjQUFjLEtBQUs7RUFDMUIsTUFBTSxlQUFlLEtBQUs7RUFDMUIsVUFBVSxXQUFXLEVBQUU7RUFDdkIsUUFBUSxhQUFhLE1BQU07RUFDM0IsVUFBVSxXQUFXLEtBQUs7RUFDMUIsU0FBUyxZQUFZLE9BQU87RUFDNUIsVUFBVSxXQUFXLE1BQU07RUFDM0IsYUFBYSxRQUFRLE1BQU07RUFDM0IsVUFBVSxXQUFXLFFBQVE7RUFDN0IsYUFBYSxRQUFRLFFBQVE7RUFDN0IsT0FBTyxjQUFjLE9BQU87RUFDNUIsVUFBVSxXQUFXLFFBQVE7RUFDN0IsY0FBYyxPQUFPLFFBQVE7RUFDN0IsYUFBYSxRQUFRLEtBQUs7RUFDMUIsUUFBUSxhQUFhLFFBQVE7RUFDN0IsU0FBUyxZQUFZLE1BQU07O0VBRTNCLElBQUksaUJBQWlCLGNBQWM7RUFDbkMsTUFBTSxlQUFlLE1BQU07RUFDM0IsbUJBQW1CLEVBQUUsTUFBTTtFQUMzQixlQUFlLE1BQU0sTUFBTTtFQUMzQixnQkFBZ0IsS0FBSyxNQUFNO0VBQzNCLFlBQVksU0FBUyxNQUFNO0VBQzNCLGlCQUFpQixJQUFJLE1BQU07RUFDM0IsUUFBUSxhQUFhLDJCQUEyQjtFQUNoRCxHQUFHLGtCQUFrQixlQUFlO0VBQ3BDLFlBQVksU0FBUyxLQUFLO0VBQzNCOztBQUVELEFBQU8sTUFBTSx1QkFBdUIsR0FBRztFQUNyQyxNQUFNO0VBQ04sVUFBVTtFQUNWLFFBQVE7RUFDUixLQUFLO0VBQ0wsS0FBSztFQUNMLE9BQU87RUFDUCxNQUFNO0VBQ1A7O0FBRUQsQUFBTyxNQUFNLGlCQUFpQixHQUFHO0VBQy9CO0lBQ0UsUUFBUSxFQUFFLE1BQU07SUFDaEIsVUFBVSxFQUFFLEdBQUc7R0FDaEI7RUFDRDtJQUNFLFFBQVEsRUFBRSxRQUFRO0lBQ2xCLFVBQVUsRUFBRSxLQUFLO0dBQ2xCO0NBQ0Y7O0FDeERNLE1BQU0sUUFBUSxHQUFHLENBQUMsRUFBRSxFQUFFLElBQUksS0FBSztFQUNwQyxJQUFJLFFBQVEsQ0FBQyxXQUFXLElBQUksUUFBUSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRTtJQUNqRSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsS0FBSyxFQUFDO0lBQ3RDLElBQUksR0FBRyxJQUFJLENBQUMsV0FBVyxHQUFFO0lBQ3pCLElBQUksQ0FBQyxHQUFHLFFBQVEsQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBQztJQUNyRCxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO0dBQ3JDO0VBQ0Y7O0FBRUQsQUFBTyxNQUFNLFNBQVMsR0FBRyxFQUFFLElBQUk7RUFDN0IsTUFBTSxhQUFhLEdBQUcsRUFBRSxDQUFDLE1BQUs7RUFDOUIsTUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUM7O0VBRXZELElBQUksYUFBYSxHQUFHLEdBQUU7O0VBRXRCLEtBQUssSUFBSSxJQUFJLEVBQUUsQ0FBQyxLQUFLO0lBQ25CLElBQUksSUFBSSxJQUFJLGNBQWMsSUFBSSxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksYUFBYSxDQUFDLElBQUksQ0FBQztNQUN2RSxhQUFhLENBQUMsSUFBSSxDQUFDO1FBQ2pCLElBQUk7UUFDSixLQUFLLEVBQUUsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDO09BQ3hELEVBQUM7O0VBRU4sT0FBTyxhQUFhO0VBQ3JCOztBQUVELEFBQU8sTUFBTSwwQkFBMEIsR0FBRyxFQUFFLElBQUk7RUFDOUMsSUFBSSxVQUFVLEdBQUcsUUFBUSxDQUFDLEVBQUUsRUFBRSxrQkFBa0IsRUFBQzs7RUFFakQsSUFBSSxVQUFVLEtBQUssa0JBQWtCLEVBQUU7SUFDckMsSUFBSSxJQUFJLElBQUksd0JBQXdCLENBQUMsRUFBRSxDQUFDO1FBQ3BDLEtBQUssR0FBRyxNQUFLOztJQUVqQixNQUFNLENBQUMsS0FBSyxFQUFFO01BQ1osSUFBSSxFQUFFLElBQUksUUFBUSxDQUFDLElBQUksRUFBRSxrQkFBa0IsRUFBQzs7TUFFNUMsSUFBSSxFQUFFLEtBQUssa0JBQWtCLEVBQUU7UUFDN0IsS0FBSyxHQUFHLEtBQUk7UUFDWixVQUFVLEdBQUcsR0FBRTtPQUNoQjs7TUFFRCxJQUFJLEdBQUcsd0JBQXdCLENBQUMsSUFBSSxFQUFDOztNQUVyQyxJQUFJLElBQUksQ0FBQyxRQUFRLEtBQUssTUFBTSxFQUFFO1FBQzVCLEtBQUssR0FBRyxLQUFJO1FBQ1osVUFBVSxHQUFHLFFBQU87T0FDckI7S0FDRjtHQUNGOztFQUVELE9BQU8sVUFBVTtFQUNsQjs7QUFFRCxBQUFPLE1BQU0sd0JBQXdCLEdBQUcsRUFBRTtFQUN4QyxFQUFFLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsUUFBUSxLQUFLLENBQUM7TUFDekMsRUFBRSxDQUFDLFVBQVU7TUFDYixFQUFFLENBQUMsVUFBVSxDQUFDLFFBQVEsS0FBSyxvQkFBb0I7UUFDN0MsRUFBRSxDQUFDLFVBQVUsQ0FBQyxJQUFJO1FBQ2xCLEVBQUUsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEtBQUk7O0FBRXJDLEFBQU8sTUFBTSx1QkFBdUIsR0FBRyxFQUFFLElBQUk7RUFDM0MsSUFBSSxFQUFFLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRTtJQUNsRCxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQztPQUMvQixNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUNqQixDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUM7T0FDNUQsQ0FBQyxDQUFDLENBQUM7R0FDUDtPQUNJLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxNQUFNO0lBQ3pCLE9BQU8sRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7RUFDeEI7O0FBRUQsQUFBTyxNQUFNLFVBQVUsR0FBRyxNQUFNLFdBQVcsSUFBSTtFQUM3QyxNQUFNLE9BQU8sR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUM7RUFDckUsTUFBTSxLQUFLLEtBQUssTUFBTSxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFDO0VBQ2pFLE1BQU0sS0FBSyxLQUFLLFFBQVEsQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFDOztFQUUvQyxLQUFLLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLEVBQUUsWUFBWTtJQUNwRCxNQUFNLEdBQUcsWUFBWTtJQUNyQixFQUFFLEVBQUM7O0VBRUwsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFDO0NBQ2pDOztBQy9FTSxNQUFNLFFBQVEsR0FBRyxFQUFFLElBQUk7RUFDNUIsTUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDLGlCQUFpQixHQUFFOztFQUUzQyxPQUFPLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxTQUFTLEtBQUs7SUFDeEQsSUFBSSxZQUFZLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQztNQUNsQyxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsSUFBSSxJQUFJLFNBQVM7UUFDakIsS0FBSyxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDO09BQ25DLEVBQUM7O0lBRUosSUFBSSxTQUFTLEtBQUssUUFBUTtNQUN4QixZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSTtRQUMzQixJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1VBQ3ZCLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxJQUFJLElBQUksSUFBSTtZQUNaLEtBQUssR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQztXQUM5QixFQUFDO09BQ0wsRUFBQzs7SUFFSixPQUFPLEdBQUc7R0FDWCxFQUFFLEVBQUUsQ0FBQztFQUNQOztBQUVELEFBQU8sTUFBTSxnQkFBZ0IsR0FBRyxFQUFFLElBQUk7O0VBRXBDLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxLQUFLO01BQ3JELFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQUs7TUFDbEMsT0FBTyxRQUFRO0dBQ2xCLEVBQUUsRUFBRSxFQUFDOztFQUVOLE1BQU0sRUFBRSxRQUFRLEtBQUssY0FBYyxDQUFDLFFBQVE7VUFDcEMsVUFBVSxHQUFHLGNBQWMsQ0FBQyxVQUFVO09BQ3pDLEdBQUcsT0FBTTs7RUFFZCxNQUFNLE9BQU8sR0FBRyxpQkFBaUIsQ0FBQyxJQUFJO0lBQ3BDLENBQUMsZUFBZSxLQUFLLFVBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxVQUFVLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztVQUMzRSxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksVUFBVSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUM7SUFDdkU7O0VBRUQsUUFBUSxPQUFPLEdBQUcsT0FBTyxHQUFHLE9BQU87OztDQUNwQyxEQzNDTSxNQUFNLFdBQVcsR0FBRyxDQUFDLFdBQVcsR0FBRyxFQUFFO0VBQzFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUMsRUFBRTtJQUNqQyxHQUFHLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxFQUFDOztBQUV6QixBQUFPLE1BQU0sT0FBTyxHQUFHLElBQUksSUFBSTtFQUM3QixJQUFJLElBQUksR0FBRyxHQUFFO0VBQ2IsSUFBSSxhQUFhLEdBQUcsS0FBSTs7RUFFeEIsT0FBTyxhQUFhLEVBQUU7SUFDcEIsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUM7SUFDeEIsYUFBYSxHQUFHLGFBQWEsQ0FBQyxVQUFVO1FBQ3BDLGFBQWEsQ0FBQyxVQUFVO1FBQ3hCLE1BQUs7R0FDVjs7RUFFRCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxLQUFLLENBQUM7SUFDcEMsRUFBRSxJQUFJLENBQUMsRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO0VBQ3JILENBQUMsRUFBRSxFQUFFLENBQUM7RUFDUDs7QUFFRCxBQUFPLE1BQU0sZUFBZSxHQUFHLENBQUMsRUFBRSxFQUFFLE9BQU8sR0FBRyxLQUFLLEtBQUs7RUFDdEQsSUFBSSxDQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFOztFQUU1QixNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLEVBQUUsU0FBUztJQUNyRSxVQUFVLElBQUksR0FBRyxHQUFHLFNBQVM7SUFDN0IsRUFBRSxFQUFDOztFQUVMLE9BQU8sT0FBTyxJQUFJLFFBQVEsQ0FBQyxNQUFNLEdBQUcsRUFBRTtNQUNsQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLO01BQ2hDLFFBQVE7RUFDYjs7QUFFRCxBQUFPLE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7SUFDNUQsS0FBSztJQUNMLE9BQU07O0FBRVYsQUFBTyxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDO0lBQzNELEtBQUs7SUFDTCxLQUFLOztBQ25DRixNQUFNLG9CQUFvQixHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSztFQUM1QyxNQUFNLEVBQUUsR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBQzs7RUFFMUMsTUFBTSxZQUFZLEdBQUcsSUFBSSxJQUFJO0lBQzNCLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtNQUNuQixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUM7O01BRXhELElBQUksU0FBUyxJQUFJLElBQUksV0FBVyxPQUFPLElBQUk7V0FDdEMsSUFBSSxTQUFTLENBQUMsVUFBVSxHQUFHLE9BQU8sWUFBWSxDQUFDLFNBQVMsQ0FBQztzQ0FDOUIsT0FBTyxTQUFTO0tBQ2pEO1NBQ0ksT0FBTyxJQUFJO0lBQ2pCOztFQUVELE1BQU0sYUFBYSxHQUFHLFlBQVksQ0FBQyxFQUFFLEVBQUM7O0VBRXRDLE9BQU8sYUFBYSxJQUFJLEVBQUU7RUFDM0I7O0FBRUQsQUFBTyxNQUFNLE9BQU8sR0FBRyxTQUFTLElBQUk7RUFDbEMsSUFBSSxLQUFLLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxFQUFFLEVBQUM7RUFDM0UsSUFBSSxLQUFLLElBQUksSUFBSSxFQUFFLEtBQUssR0FBRyxNQUFLO0VBQ2hDLElBQUksS0FBSyxJQUFJLE1BQU0sRUFBRSxLQUFLLEdBQUcsU0FBUTtFQUNyQyxPQUFPLEtBQUs7RUFDYjs7QUFFRCxBQUFPLE1BQU0sWUFBWSxHQUFHLEVBQUUsSUFBSTtFQUNoQyxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUM7S0FDaEQsT0FBTyxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUM7RUFDN0I7O0FBRUQsQUFBTyxTQUFTLFFBQVEsQ0FBQyxFQUFFLEVBQUU7RUFDM0IsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDO0lBQ2hCLEVBQUUsT0FBTyxFQUFFLHVCQUF1QixFQUFFO0lBQ3BDLEVBQUUsT0FBTyxFQUFFLHFDQUFxQyxFQUFFO0lBQ2xELEVBQUUsT0FBTyxFQUFFLHVCQUF1QixFQUFFO0dBQ3JDLEVBQUUsR0FBRyxDQUFDO0NBQ1I7O0FBRUQsSUFBSSxVQUFVLEdBQUcsR0FBRTtBQUNuQixBQUFPLE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQyxFQUFFLEVBQUUsUUFBUSxHQUFHLEdBQUcsS0FBSztFQUN0RCxFQUFFLENBQUMsWUFBWSxDQUFDLG9CQUFvQixFQUFFLElBQUksRUFBQztFQUMzQyxpQkFBaUIsQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFDOztFQUUzQixJQUFJLFVBQVUsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDekIsWUFBWSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQzs7RUFFdkMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxDQUFDLElBQUk7SUFDeEMsRUFBRSxDQUFDLGVBQWUsQ0FBQyxvQkFBb0IsRUFBQztJQUN4QyxpQkFBaUIsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFDO0dBQzdCLEVBQUUsUUFBUSxFQUFDOztFQUVaLE9BQU8sRUFBRTtFQUNWOztBQUVELEFBQU8sTUFBTSxpQkFBaUIsR0FBRyxDQUFDLEVBQUUsRUFBRSxJQUFJLEdBQUcsS0FBSyxLQUFLO0VBQ3JELElBQUksQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQztJQUNuQyxNQUFNOztFQUVSLE1BQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFDOztFQUVqRCxNQUFNLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQztnQ0FDYSxFQUFFLFFBQVEsQ0FBQztrQ0FDVCxFQUFFLFFBQVEsQ0FBQztFQUMzQyxDQUFDLEVBQUM7O0VBRUYsS0FBSyxDQUFDLE1BQU0sSUFBSSxJQUFJO01BQ2hCLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUNoQixFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7TUFDMUIsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQ2hCLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLElBQUksRUFBQztFQUM3Qjs7QUFFRCxBQUFPLE1BQU0sZUFBZSxHQUFHLENBQUMsVUFBVSxHQUFHLEVBQUU7RUFDN0MsQ0FBQyxJQUFJLFNBQVMsRUFBRSxDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsV0FBVyxDQUFDO0tBQ3RELElBQUksQ0FBQyxXQUFVOztBQUVwQixBQUFPLE1BQU0sV0FBVyxHQUFHLElBQUk7RUFDN0IsSUFBSSxDQUFDLE9BQU87T0FDUCxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztPQUN2QixJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQztPQUMxQixJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDO09BQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDO09BQzNCLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDO09BQzVCLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUM7T0FDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQztJQUNwQzs7QUFFSCxBQUFPLE1BQU0sZUFBZSxHQUFHLENBQUMsRUFBRTtFQUNoQyxRQUFRLElBQUk7SUFDVixJQUFJLEVBQUUsRUFBRSxDQUFDLFFBQVEsRUFBQyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxPQUFPLEtBQUssRUFBRTtJQUMvQyxPQUFPLElBQUk7R0FDWjtDQUNGLEVBQUUsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUNoR3BELFNBQVMsWUFBWSxHQUFHO0VBQzdCLE1BQU0sTUFBTSxJQUFJLE1BQU0sQ0FBQyxZQUFXO0VBQ2xDLE1BQU0sS0FBSyxLQUFLLE1BQU0sQ0FBQyxXQUFVO0VBQ2pDLE1BQU0sSUFBSSxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBVzs7RUFFekMsTUFBTSxTQUFTLEdBQUcsSUFBSSxJQUFJLEtBQUs7TUFDM0IsSUFBSTtNQUNKLE1BQUs7O0VBRVQsT0FBTztJQUNMLFNBQVMsRUFBRSxNQUFNO0lBQ2pCLFFBQVEsR0FBRyxTQUFTO0dBQ3JCO0NBQ0Y7O0FDWE0sTUFBTSxTQUFTLFNBQVMsV0FBVyxDQUFDOztFQUV6QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7SUFDUCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLEVBQUM7R0FDbkQ7O0VBRUQsaUJBQWlCLEdBQUcsRUFBRTtFQUN0QixvQkFBb0IsR0FBRyxFQUFFOztFQUV6QixJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUU7SUFDekIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUM7R0FDcEQ7O0VBRUQsSUFBSSxNQUFNLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRTtJQUN2QyxNQUFNLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxHQUFHLFlBQVksR0FBRTs7SUFFOUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxRQUFPO0lBQ3pDLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQzs7SUFFcEMsR0FBRyxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQyxFQUFDO0lBQzNELEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxLQUFLLEdBQUcsSUFBSSxFQUFDO0lBQ25ELEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxNQUFNLEdBQUcsSUFBSSxFQUFDO0lBQ3JELEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUM7SUFDdkMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBQztJQUN0QyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFDO0lBQ3hDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUM7SUFDeEMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLElBQUksR0FBRyxLQUFLLEVBQUM7SUFDaEQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLElBQUksR0FBRyxLQUFLLEVBQUM7SUFDaEQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBQztJQUN2QyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFDO0lBQ3ZDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7SUFDNUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLEdBQUcsR0FBRyxNQUFNLEVBQUM7SUFDaEQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLEdBQUcsR0FBRyxNQUFNLEVBQUM7SUFDaEQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztHQUM3Qzs7RUFFRCxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFO0lBQ3pDLE1BQU0sRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLEdBQUcsWUFBWSxHQUFFOztJQUU5QyxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzs7O3FCQUdYLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUM7Ozs7O2lCQUs1QixFQUFFLEtBQUssQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDO2FBQy9CLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUM7OztrQkFHUixFQUFFLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7a0JBQ3ZDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxhQUFhLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDO3lCQUNoRCxFQUFFLENBQUMsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7eUJBQy9CLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDOztJQUV0RSxDQUFDO0dBQ0Y7O0VBRUQsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQ2pCLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7SUFXUixDQUFDO0dBQ0Y7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLGtCQUFrQixFQUFFLFNBQVMsQ0FBQzs7QUMvRTdDLE1BQU0sUUFBUSxTQUFTLFdBQVcsQ0FBQzs7RUFFeEMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFO0lBQ1AsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxFQUFDO0dBQ2pEOztFQUVELGlCQUFpQixHQUFHLEVBQUU7RUFDdEIsb0JBQW9CLEdBQUcsRUFBRTs7RUFFekIsSUFBSSxRQUFRLENBQUMsQ0FBQyxVQUFVLEVBQUUsYUFBYSxDQUFDLEVBQUU7SUFDeEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsYUFBYSxFQUFDO0dBQ2pFOztFQUVELE1BQU0sQ0FBQyxZQUFZLEVBQUUsYUFBYSxFQUFFO0lBQ2xDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLEVBQUUsYUFBYSxFQUFDO0lBQzlELE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQzs7O3VCQUdYLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQzs7O0lBR3BDLENBQUM7R0FDRjs7RUFFRCxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxFQUFFO0lBQzFCLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7VUFXRixFQUFFLENBQUM7Y0FDQyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDO2NBQzdCLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2VBQzdCLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUM7Z0JBQ3BCLEVBQUUsQ0FBQyxDQUFDO3FCQUNDLEVBQUUsQ0FBQztjQUNWLGtCQUFrQjtjQUNsQixrQkFBa0IsQ0FBQzs7Ozs7OzswQkFPUCxFQUFFLENBQUMsR0FBRyxRQUFRLEdBQUcsS0FBSyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7VUFrQnZDLEVBQUUsQ0FBQztjQUNDLHdDQUF3QztjQUN4Qyx3Q0FBd0MsQ0FBQzs7Ozs7O1VBTTdDLEVBQUUsQ0FBQztjQUNDLDJCQUEyQjtjQUMzQiw0QkFBNEIsQ0FBQzs7OzBCQUdqQixFQUFFLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxLQUFLLE1BQU0sR0FBRyxlQUFlLEdBQUcsZ0JBQWdCLENBQUM7eUNBQ3BELEVBQUUsQ0FBQyxDQUFDOzs7SUFHekMsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxRQUFRLENBQUM7O0FDM0YzQyxNQUFNLE9BQU8sU0FBUyxXQUFXLENBQUM7O0VBRXZDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTtJQUNQLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsRUFBQztHQUNuRDs7RUFFRCxpQkFBaUIsR0FBRyxFQUFFO0VBQ3RCLG9CQUFvQixHQUFHLEVBQUU7O0VBRXpCLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRTtJQUN6QixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBQztHQUNwRDs7RUFFRCxJQUFJLE1BQU0sQ0FBQyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFO0lBQ3ZDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsUUFBTzs7SUFFekMsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFDO0lBQ3BDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLFFBQU87SUFDM0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLE9BQU8sR0FBRyxHQUFHLEdBQUcsS0FBSTtJQUMzQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSTs7SUFFNUIsR0FBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsS0FBSyxHQUFHLElBQUksRUFBQztJQUN2QyxHQUFHLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxNQUFNLEdBQUcsSUFBSSxFQUFDO0dBQzFDOztFQUVELE1BQU0sQ0FBQyxDQUFDLEVBQUUsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRTtJQUNyQyxPQUFPLENBQUM7OztvQkFHUSxFQUFFLEVBQUUsQ0FBQzs7Ozs7Ozs7OztlQVVWLEVBQUUsS0FBSyxDQUFDLFlBQVksRUFBRSxNQUFNLENBQUM7cUJBQ3ZCLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUM7Ozs7Ozs7O0lBUW5DLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDOzs7O0FDakR6QyxNQUFNLE9BQU8sU0FBUyxXQUFXLENBQUM7O0VBRXZDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTtJQUNQLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsRUFBQztHQUNuRDs7RUFFRCxpQkFBaUIsR0FBRztJQUNsQixDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDO0dBQy9EOztFQUVELG9CQUFvQixHQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLEdBQUU7R0FDakI7O0VBRUQsYUFBYSxDQUFDLENBQUMsRUFBRTtJQUNmLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLFdBQVcsQ0FBQyxPQUFPLEVBQUU7TUFDdkQsT0FBTyxFQUFFLElBQUk7TUFDYixNQUFNLElBQUk7UUFDUixJQUFJLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXO1FBQ2hDLFNBQVMsR0FBRyxDQUFDLENBQUMsSUFBSTtPQUNuQjtLQUNGLENBQUMsRUFBQztHQUNKOztFQUVELE9BQU8sR0FBRztJQUNSLENBQUMsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQztJQUMvRSxDQUFDLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDO0dBQzVFOztFQUVELFNBQVMsR0FBRztJQUNWLENBQUMsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQztJQUNoRixDQUFDLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDO0dBQzdFOztFQUVELGVBQWUsQ0FBQyxDQUFDLEVBQUU7SUFDakIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksV0FBVyxDQUFDLFNBQVMsRUFBRTtNQUN6RCxPQUFPLEVBQUUsSUFBSTtLQUNkLENBQUMsRUFBQztJQUNILElBQUksQ0FBQyxTQUFTLEdBQUU7R0FDakI7O0VBRUQsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFO0lBQ2IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUM7R0FDM0M7O0VBRUQsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsa0JBQWtCLEVBQUUscUJBQXFCLENBQUMsRUFBRTtJQUNyRSxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzs7O2tCQUdKLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUNqQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7VUFDMUIsRUFBRSxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzthQUM3QixNQUFNLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFLENBQUM7YUFDMUIsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLElBQUksS0FBSyxDQUFDO2NBQ3hCLEVBQUUsS0FBSyxDQUFDO2tCQUNKLEVBQUUsSUFBSSxDQUFDO1lBQ2IsQ0FBQyxFQUFFLEVBQUUsQ0FBQztXQUNQOzs7aUJBR00sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDOztnQkFFckIsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDOzthQUV4QixFQUFFLHFCQUFxQixDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLEtBQUssQ0FBQztVQUNwRCxFQUFFLEtBQUssQ0FBQztxQkFDRyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUM7c0JBQ1gsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQzNCLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQzs7UUFFUCxFQUFFLGtCQUFrQixDQUFDLE1BQU0sR0FBRyxDQUFDOztlQUV4QixFQUFFLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLEtBQUssQ0FBQztZQUNqRCxFQUFFLEtBQUssQ0FBQzt1QkFDRyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUM7d0JBQ1gsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO1VBQzNCLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQzs7UUFFVCxDQUFDLEdBQUcsRUFBRSxDQUFDOztJQUVYLENBQUM7R0FDRjs7RUFFRCxNQUFNLEdBQUc7SUFDUCxPQUFPLENBQUM7O1FBRUosRUFBRUEsS0FBTSxDQUFDOztJQUViLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDOztBQ2hHekMsTUFBTSxJQUFJLFNBQVMsT0FBTyxDQUFDO0VBQ2hDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTtHQUNSOztFQUVELE1BQU0sQ0FBQyxDQUFDLEVBQUUsRUFBRSxlQUFlLEVBQUUsZ0JBQWdCLENBQUMsRUFBRTtJQUM5QyxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzs7WUFFVixFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDOztVQUVyRCxFQUFFLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxLQUFLLENBQUM7WUFDekMsRUFBRSxLQUFLLENBQUM7dUJBQ0csRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDO3dCQUNYLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQztVQUMzQixDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7VUFDUCxFQUFFLGdCQUFnQixDQUFDOzs7SUFHekIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDOzs7O0FDekJuQyxNQUFNLE1BQU0sR0FBRyxDQUFDOzs7O0FBSXZCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLElBQUksR0FBRyxDQUFDOzs7O0FBSXJCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLE1BQU0sR0FBRyxDQUFDOzs7O0FBSXZCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLE1BQU0sR0FBRyxDQUFDOzs7O0FBSXZCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLE9BQU8sR0FBRyxDQUFDOzs7O0FBSXhCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLElBQUksR0FBRyxDQUFDOzs7O0FBSXJCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLElBQUksR0FBRyxDQUFDOzs7O0FBSXJCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLEtBQUssR0FBRyxDQUFDOzs7O0FBSXRCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLE1BQU0sR0FBRyxDQUFDOzs7O0FBSXZCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLFNBQVMsR0FBRyxDQUFDOzs7OztBQUsxQixFQUFDOztBQUVELEFBQU8sTUFBTSxNQUFNLEdBQUcsQ0FBQzs7OztBQUl2QixFQUFDOztBQUVELEFBQU8sTUFBTSxRQUFRLEdBQUcsQ0FBQzs7OztBQUl6QixFQUFDOztBQUVELEFBQU8sTUFBTSxTQUFTLEdBQUcsQ0FBQzs7OztBQUkxQixFQUFDOztBQUVELEFBQU8sTUFBTSxTQUFTLEdBQUcsQ0FBQzs7Ozs7Ozs7O0FBUzFCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLE1BQU0sR0FBRyxDQUFDOzs7OztBQUt2QixFQUFDOztBQUVELEFBQU8sTUFBTSxNQUFNLEdBQUcsQ0FBQzs7Ozs7QUFLdkIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sVUFBVSxHQUFHLENBQUM7Ozs7O0FBSzNCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLGdCQUFnQixHQUFHLENBQUM7Ozs7O0FBS2pDLEVBQUM7O0FBRUQsQUFBTyxNQUFNLFlBQVksR0FBRyxDQUFDOzs7OztBQUs3QixFQUFDOztBQUVELEFBQU8sTUFBTSxRQUFRLEdBQUcsQ0FBQzs7Ozs7QUFLekIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sYUFBYSxHQUFHLENBQUM7Ozs7QUFJOUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBQUMsRENsSU0sTUFBTSxTQUFTLFNBQVMsV0FBVyxDQUFDOztFQUV6QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLGNBQWMsR0FBRztNQUNwQixHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO01BQ3RFLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7TUFDcEUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7TUFDbEUsS0FBSyxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7TUFDakUsS0FBSyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO01BQzdEOztJQUVELElBQUksQ0FBQyxjQUFjLEdBQUc7TUFDcEIsR0FBRyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztNQUNkLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDYixJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7TUFDbEIsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO01BQ2xCLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7TUFDZjs7SUFFRCxJQUFJLENBQUMsT0FBTyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLEVBQUM7O0lBRXJELElBQUksQ0FBQyxPQUFPLE1BQU0sR0FBRTtJQUNwQixJQUFJLENBQUMsU0FBUyxJQUFJLEdBQUU7O0lBRXBCLElBQUksQ0FBQyxJQUFJLFNBQVMsWUFBVztHQUM5Qjs7RUFFRCxpQkFBaUIsR0FBRztJQUNsQixJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxnQ0FBZ0MsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFDO0lBQ2hFLElBQUksQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLCtCQUErQixFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUM7SUFDL0QsSUFBSSxDQUFDLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBQztJQUNwRSxJQUFJLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFDO0lBQ3JFLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFDO0lBQy9DLElBQUksQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUM7SUFDakQsSUFBSSxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBQztJQUNqRCxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFDO0dBQ25EOztFQUVELG9CQUFvQixHQUFHLEVBQUU7O0VBRXpCLElBQUksSUFBSSxDQUFDLElBQUksRUFBRTtJQUNiLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSTtJQUNqQixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFFO0dBQ3ZDOztFQUVELElBQUksR0FBRztJQUNMLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTTtJQUN4QyxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU87TUFDdEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUM7R0FDOUI7O0VBRUQsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFNO0lBQ3hDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFDO0dBQ3BCOztFQUVELFNBQVMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxFQUFFO0lBQ3BCLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsQ0FBQyxDQUFDLHdCQUF3QixHQUFFOztJQUU1QixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBQztJQUMxQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBQztJQUN4QyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBQztJQUN0QyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFDO0lBQzNDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsSUFBSSxLQUFLLFNBQVMsRUFBQztJQUM5QyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUM7SUFDbEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFDO0lBQ2xELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsSUFBSSxLQUFLLFlBQVksRUFBQzs7SUFFcEQsTUFBTSxFQUFFLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsRUFBQzs7SUFFdEYsQ0FBQyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7TUFDOUQsUUFBUSxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxNQUFNO0tBQzFDLEVBQUM7R0FDSDs7RUFFRCxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBRUMsVUFBTyxDQUFDLEVBQUU7SUFDakMsSUFBSSxNQUFNLGdCQUFnQkEsVUFBTyxDQUFDLEtBQUssR0FBRyxFQUFFLEdBQUcsRUFBQztJQUNoRCxJQUFJLFFBQVEsY0FBY0EsVUFBTyxDQUFDLEdBQUcsR0FBRyxVQUFVLEdBQUcsTUFBSztJQUMxRCxJQUFJLGlCQUFpQixLQUFLQSxVQUFPLENBQUMsR0FBRyxHQUFHLE1BQU0sR0FBRyxLQUFJOztJQUVyRCxJQUFJLElBQUksR0FBRyxjQUFhO0lBQ3hCLElBQUksSUFBSSxLQUFLLFNBQVMsTUFBTSxJQUFJLEdBQUcsZUFBYztJQUNqRCxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxHQUFHLGtCQUFpQjtJQUNwRCxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxHQUFHLGdCQUFlO0lBQ2xELElBQUksSUFBSSxLQUFLLFlBQVksR0FBRyxJQUFJLEdBQUcsaUJBQWdCO0lBQ25ELElBQUlBLFVBQU8sQ0FBQyxPQUFPLENBQUMsYUFBYSxJQUFJLEdBQUcsWUFBVzs7SUFFbkQsSUFBSUEsVUFBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLElBQUksS0FBSyxXQUFXLEVBQUU7TUFDNUMsUUFBUSxjQUFjLFdBQVU7TUFDaEMsaUJBQWlCLEtBQUssT0FBTTtLQUM3Qjs7SUFFRCxPQUFPO01BQ0wsUUFBUSxFQUFFLGlCQUFpQixFQUFFLE1BQU0sRUFBRSxJQUFJO0tBQzFDO0dBQ0Y7O0VBRUQsY0FBYyxDQUFDLENBQUMsUUFBUSxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsRUFBRTtJQUMxRCxPQUFPLENBQUM7cUJBQ1MsRUFBRSxRQUFRLENBQUM7aUJBQ2YsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO21CQUNYLEVBQUUsaUJBQWlCLENBQUM7aUJBQ3RCLEVBQUUsSUFBSSxDQUFDOzttQkFFTCxFQUFFLE1BQU0sQ0FBQztJQUN4QixDQUFDO0dBQ0Y7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Ozs7WUFJVixFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDcEIsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzs7O1VBSWYsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDO1lBQ3BCLFFBQVEsRUFBRSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDO1lBQ3pCLGlCQUFpQixFQUFFLE1BQU07WUFDekIsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLO1lBQ2hCLElBQUksRUFBRSxhQUFhO1lBQ25CLE1BQU0sRUFBRSxDQUFDO1dBQ1YsQ0FBQyxDQUFDOzs7O1lBSUQsRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQztjQUMzRSxFQUFFLFFBQVEsQ0FBQzt1QkFDRixFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUM7Z0JBQ2xELEVBQUUsR0FBRyxDQUFDOztrQkFFSixFQUFFLEdBQUcsQ0FBQztrQkFDTixFQUFFLElBQUksQ0FBQyxPQUFPLElBQUksR0FBRyxHQUFHLHFDQUFxQyxHQUFHLEVBQUUsQ0FBQztrQkFDbkUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLEdBQUcsRUFBRSxDQUFDOzhCQUNqQyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNyRCxFQUFFLEdBQUcsQ0FBQztjQUNULENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQzs7WUFFVCxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7Ozs7Ozs7Ozs7OztJQVlmLENBQUM7R0FDRjs7RUFFRCxNQUFNLEdBQUc7SUFDUCxPQUFPLENBQUM7O1FBRUosRUFBRUQsS0FBTSxDQUFDOztJQUViLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQzs7QUMzS3ZDLE1BQU0sYUFBYSxTQUFTLFNBQVMsQ0FBQztFQUMzQyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLElBQUksR0FBRTtJQUNwQixJQUFJLENBQUMsSUFBSSxTQUFTLFNBQVE7R0FDM0I7O0VBRUQsaUJBQWlCLEdBQUcsRUFBRTs7RUFFdEIsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFNO0dBQ3pDOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDOzs7O1lBSVYsRUFBRUUsTUFBSSxDQUFDO1lBQ1AsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzs7Ozs7O0lBT3JCLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsYUFBYSxDQUFDOztBQ2hDL0MsTUFBTSxnQkFBZ0IsU0FBUyxTQUFTLENBQUM7RUFDOUMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFDO0lBQzFCLElBQUksQ0FBQyxJQUFJLFNBQVMsWUFBVztHQUM5Qjs7RUFFRCxpQkFBaUIsR0FBRyxFQUFFOztFQUV0QixJQUFJLEdBQUc7SUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU07R0FDekM7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Ozs7WUFJVixFQUFFQSxTQUFJLENBQUM7WUFDUCxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7Ozs7Ozs7SUFPckIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRSxnQkFBZ0IsQ0FBQzs7QUNqQ3JELE1BQU0sb0JBQW9CLFNBQVMsU0FBUyxDQUFDO0VBQ2xELFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTs7SUFFUCxJQUFJLENBQUMsT0FBTyxNQUFNLElBQUc7SUFDckIsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLE1BQU0sRUFBQztJQUMxQixJQUFJLENBQUMsSUFBSSxTQUFTLGdCQUFlO0dBQ2xDOztFQUVELGlCQUFpQixHQUFHLEVBQUU7O0VBRXRCLElBQUksR0FBRztJQUNMLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTTtHQUN6Qzs7RUFFRCxNQUFNLEdBQUc7SUFDUCxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzs7OztZQUlWLEVBQUVBLGFBQUksQ0FBQztZQUNQLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQzs7Ozs7OztJQU9yQixDQUFDO0dBQ0Y7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLHVCQUF1QixFQUFFLG9CQUFvQixDQUFDOztBQ25DN0QsTUFBTSxXQUFXLFNBQVMsU0FBUyxDQUFDO0VBQ3pDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTs7SUFFUCxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUc7SUFDbkIsSUFBSSxDQUFDLElBQUksT0FBTyxPQUFNO0dBQ3ZCOztFQUVELGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFO0lBQ2pDLElBQUksTUFBTSxFQUFFLFFBQVEsRUFBRSxrQkFBaUI7O0lBRXZDLElBQUksSUFBSSxHQUFHLGNBQWE7SUFDeEIsSUFBSSxJQUFJLEtBQUssU0FBUyxNQUFNLElBQUksR0FBRyxrQkFBaUI7SUFDcEQsSUFBSSxJQUFJLEtBQUssV0FBVyxJQUFJLElBQUksR0FBRyw2Q0FBNEM7SUFDL0UsSUFBSSxJQUFJLEtBQUssV0FBVyxJQUFJLElBQUksR0FBRyxxQ0FBb0M7SUFDdkUsSUFBSSxJQUFJLEtBQUssWUFBWSxHQUFHLElBQUksR0FBRyx1Q0FBc0M7O0lBRXpFLE9BQU87TUFDTCxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxFQUFFLElBQUk7S0FDMUM7R0FDRjs7RUFFRCxjQUFjLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRTtJQUNyQixPQUFPLENBQUM7aUJBQ0ssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO2lCQUNiLEVBQUUsSUFBSSxDQUFDO0lBQ3BCLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLFdBQVc7O2tEQUFDLGxEQzdCM0MsTUFBTSxhQUFhLFNBQVMsU0FBUyxDQUFDO0VBQzNDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTs7SUFFUCxJQUFJLENBQUMsT0FBTyxNQUFNLElBQUc7SUFDckIsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFDOztJQUUxQyxJQUFJLENBQUMsSUFBSSxTQUFTLFNBQVE7R0FDM0I7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLGFBQWEsQ0FBQzs7QUNYL0MsTUFBTSxjQUFjLFNBQVMsU0FBUyxDQUFDO0VBQzVDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTs7SUFFUCxJQUFJLENBQUMsT0FBTyxNQUFNLElBQUc7SUFDckIsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFDOztJQUUxQyxJQUFJLENBQUMsSUFBSSxTQUFTLFVBQVM7R0FDNUI7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLGNBQWMsQ0FBQzs7QUNYeEQsTUFBTSxjQUFjLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBQztBQUNqRCxNQUFNLGNBQWMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFDO0FBQ2pELE1BQU0sV0FBVyxPQUFPLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUM7O0FBRXJELEFBQU8sTUFBTSxZQUFZLFNBQVMsU0FBUyxDQUFDO0VBQzFDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTs7SUFFUCxJQUFJLENBQUMsT0FBTyxLQUFLLElBQUc7SUFDcEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUM7O0lBRWxDLElBQUksQ0FBQyxNQUFNLEtBQUssRUFBQztJQUNqQixJQUFJLENBQUMsTUFBTSxLQUFLLEVBQUM7SUFDakIsSUFBSSxDQUFDLE1BQU0sS0FBSyxFQUFDOztJQUVqQixJQUFJLENBQUMsS0FBSyxXQUFXLFdBQVU7SUFDL0IsSUFBSSxDQUFDLFVBQVUsTUFBTSxNQUFLO0lBQzFCLElBQUksQ0FBQyxhQUFhLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUM7O0lBRTdDLElBQUksQ0FBQyxJQUFJLE9BQU8sUUFBTztHQUN4Qjs7RUFFRCxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLENBQUMsRUFBRTtJQUNqQyxJQUFJLE1BQU0sY0FBYyxJQUFJLENBQUMsYUFBYTtRQUN0QyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsVUFBVTtRQUNuQyxJQUFJLGdCQUFnQixJQUFJLENBQUMsS0FBSztRQUM5QixTQUFROztJQUVaLElBQUksT0FBTyxDQUFDLEdBQUcsS0FBSyxJQUFJLEtBQUssWUFBWSxJQUFJLElBQUksS0FBSyxXQUFXLENBQUMsRUFBRTtNQUNsRSxpQkFBaUIsR0FBRyxJQUFJLEtBQUssV0FBVztVQUNwQyxRQUFRO1VBQ1IsTUFBSztNQUNULElBQUksQ0FBQyxVQUFVLEdBQUcsa0JBQWlCO0tBQ3BDO1NBQ0k7TUFDSCxJQUFJLElBQUksS0FBSyxTQUFTLFlBQVksSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUFFLFFBQVEsRUFBQztXQUN4RSxJQUFJLElBQUksS0FBSyxXQUFXLEtBQUssSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUM7d0NBQ2pELElBQUksR0FBRyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBQzs7TUFFcEUsSUFBSSxJQUFJLEtBQUssV0FBVyxVQUFVLElBQUksSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFDO1dBQy9FLElBQUksSUFBSSxLQUFLLFlBQVksSUFBSSxJQUFJLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUM7d0NBQ3hELElBQUksSUFBSSxHQUFHLEdBQUcsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUM7O01BRTNFLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSTs7TUFFakIsSUFBSSxPQUFPLENBQUMsS0FBSyxLQUFLLElBQUksS0FBSyxZQUFZLElBQUksSUFBSSxLQUFLLFdBQVcsQ0FBQyxFQUFFO1FBQ3BFLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxRQUFRLEVBQUUsSUFBSSxLQUFLLFlBQVksRUFBQztRQUNqRSxJQUFJLENBQUMsYUFBYSxHQUFHLE9BQU07T0FDNUI7S0FDRjs7SUFFRCxPQUFPO01BQ0wsUUFBUSxFQUFFLGlCQUFpQixFQUFFLE1BQU0sRUFBRSxJQUFJO0tBQzFDO0dBQ0Y7O0VBRUQsY0FBYyxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxpQkFBaUIsQ0FBQyxFQUFFO0lBQ2hELElBQUksTUFBTSxJQUFJLENBQUMsRUFBRSxNQUFNLEdBQUcsSUFBSSxDQUFDLGNBQWE7SUFDNUMsSUFBSSxpQkFBaUIsSUFBSSxNQUFNLEVBQUUsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLFdBQVU7O0lBRXBFLE9BQU8sQ0FBQztpQkFDSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7O1lBRWxCLEVBQUUsaUJBQWlCLENBQUM7aUJBQ2YsRUFBRSxJQUFJLENBQUM7O21CQUVMLEVBQUUsTUFBTSxDQUFDO0lBQ3hCLENBQUM7R0FDRjs7RUFFRCxLQUFLLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxTQUFTLEdBQUcsS0FBSyxFQUFFO0lBQ3BDLElBQUksU0FBUyxFQUFFO01BQ2IsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBQztLQUM5QjtTQUNJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7TUFDckIsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFDOztJQUU3QixPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7R0FDekI7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxZQUFZLENBQUM7O0FDakY3QyxNQUFNLGVBQWUsU0FBUyxTQUFTLENBQUM7RUFDN0MsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBQztJQUNuQyxJQUFJLENBQUMsSUFBSSxTQUFTLFdBQVU7R0FDN0I7O0VBRUQsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUU7SUFDakMsSUFBSSxNQUFNLGdCQUFnQixPQUFPLENBQUMsS0FBSyxHQUFHLEVBQUUsR0FBRyxFQUFDO0lBQ2hELElBQUksUUFBUSxjQUFjLHNCQUFxQjtJQUMvQyxJQUFJLGlCQUFpQixLQUFLLEtBQUk7SUFDOUIsSUFBSSxJQUFJLGtCQUFrQixjQUFhOzs7SUFHdkMsSUFBSSxPQUFPLENBQUMsR0FBRyxFQUFFO01BQ2YsSUFBSSxFQUFFLE1BQUs7O01BRVgsSUFBSSxJQUFJLEtBQUssV0FBVztRQUN0QixRQUFRLElBQUksV0FBVTtNQUN4QixJQUFJLElBQUksS0FBSyxTQUFTO1FBQ3BCLFFBQVEsSUFBSSxXQUFVO0tBQ3pCO1NBQ0ksSUFBSSxJQUFJLEtBQUssV0FBVyxJQUFJLElBQUksS0FBSyxZQUFZLEVBQUU7TUFDdEQsSUFBSSxHQUFHLGFBQVk7O01BRW5CLElBQUksSUFBSSxLQUFLLFdBQVc7UUFDdEIsUUFBUSxJQUFJLFdBQVU7TUFDeEIsSUFBSSxJQUFJLEtBQUssWUFBWTtRQUN2QixRQUFRLElBQUksV0FBVTtLQUN6Qjs7U0FFSSxJQUFJLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxLQUFLLFdBQVcsRUFBRTtNQUNuRCxJQUFJLEdBQUcsWUFBVzs7TUFFbEIsSUFBSSxJQUFJLEtBQUssV0FBVztRQUN0QixRQUFRLElBQUksV0FBVTtNQUN4QixJQUFJLElBQUksS0FBSyxTQUFTO1FBQ3BCLFFBQVEsSUFBSSxXQUFVO0tBQ3pCOztJQUVELE9BQU87TUFDTCxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxFQUFFLElBQUk7S0FDMUM7R0FDRjs7RUFFRCxjQUFjLENBQUMsQ0FBQyxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLE1BQU0sQ0FBQyxFQUFFO0lBQzFELElBQUksUUFBUSxLQUFLLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUM7TUFDOUIsUUFBUSxHQUFHLHNCQUFxQjtJQUNsQyxJQUFJLGlCQUFpQixLQUFLLE1BQU07TUFDOUIsaUJBQWlCLEdBQUcsT0FBTTs7SUFFNUIsT0FBTyxDQUFDO3FCQUNTLEVBQUUsUUFBUSxDQUFDO3NCQUNWLEVBQUUsSUFBSSxDQUFDO2tCQUNYLEVBQUUsaUJBQWlCLENBQUM7bUJBQ25CLEVBQUUsTUFBTSxDQUFDO0lBQ3hCLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQUUsZUFBZSxDQUFDOztBQzlEbkQsTUFBTSxnQkFBZ0IsU0FBUyxTQUFTLENBQUM7RUFDOUMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBQztJQUNuQyxJQUFJLENBQUMsSUFBSSxTQUFTLFlBQVc7R0FDOUI7O0VBRUQsaUJBQWlCLEdBQUcsRUFBRTs7RUFFdEIsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFNO0dBQ3pDOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDOzs7O1lBSVYsRUFBRUEsU0FBSSxDQUFDO1lBQ1AsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzs7Ozs7O0lBT3JCLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLEVBQUUsZ0JBQWdCLENBQUM7O0FDakNyRCxNQUFNLGVBQWUsU0FBUyxTQUFTLENBQUM7RUFDN0MsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBQztJQUNsQyxJQUFJLENBQUMsSUFBSSxTQUFTLFdBQVU7R0FDN0I7O0VBRUQsaUJBQWlCLEdBQUcsRUFBRTs7RUFFdEIsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFNO0dBQ3pDOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDOzs7O1lBSVYsRUFBRUEsUUFBSSxDQUFDO1lBQ1AsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzs7Ozs7O0lBT3JCLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQUUsZUFBZSxDQUFDOztBQ2xDbkQsTUFBTSxXQUFXLFNBQVMsU0FBUyxDQUFDO0VBQ3pDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTs7SUFFUCxJQUFJLENBQUMsT0FBTyxNQUFNLElBQUc7SUFDckIsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUM7SUFDbkMsSUFBSSxDQUFDLElBQUksU0FBUyxPQUFNO0dBQ3pCOztFQUVELGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFO0lBQ2pDLElBQUksTUFBTSxnQkFBZ0IsT0FBTyxDQUFDLEtBQUssR0FBRyxFQUFFLEdBQUcsRUFBQztJQUNoRCxJQUFJLFFBQVEsY0FBYyxzQkFBcUI7SUFDL0MsSUFBSSxpQkFBaUIsS0FBSyxLQUFJO0lBQzlCLElBQUksSUFBSSxrQkFBa0IsY0FBYTs7O0lBR3ZDLElBQUksT0FBTyxDQUFDLEtBQUssS0FBSyxJQUFJLEtBQUssV0FBVyxJQUFJLElBQUksS0FBSyxZQUFZLENBQUMsRUFBRTtNQUNwRSxJQUFJLE1BQU0sVUFBUztNQUNuQixNQUFNLElBQUksTUFBSzs7TUFFZixJQUFJLElBQUksS0FBSyxXQUFXO1FBQ3RCLFFBQVEsSUFBSSxXQUFVO01BQ3hCLElBQUksSUFBSSxLQUFLLFlBQVk7UUFDdkIsUUFBUSxJQUFJLFdBQVU7S0FDekI7O1NBRUksSUFBSSxPQUFPLENBQUMsS0FBSyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxLQUFLLFdBQVcsQ0FBQyxFQUFFO01BQ3RFLElBQUksTUFBTSxVQUFTO01BQ25CLE1BQU0sSUFBSSxNQUFLOztNQUVmLElBQUksSUFBSSxLQUFLLFNBQVM7UUFDcEIsUUFBUSxJQUFJLFdBQVU7TUFDeEIsSUFBSSxJQUFJLEtBQUssV0FBVztRQUN0QixRQUFRLElBQUksV0FBVTtLQUN6Qjs7U0FFSSxJQUFJLE9BQU8sQ0FBQyxHQUFHLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssV0FBVyxDQUFDLEVBQUU7TUFDcEUsSUFBSSxrQkFBa0IsY0FBYTtNQUNuQyxNQUFNLGdCQUFnQixHQUFFO01BQ3hCLGlCQUFpQixLQUFLLEdBQUU7O01BRXhCLElBQUksSUFBSSxLQUFLLFNBQVM7UUFDcEIsUUFBUSxJQUFJLFdBQVU7TUFDeEIsSUFBSSxJQUFJLEtBQUssV0FBVztRQUN0QixRQUFRLElBQUksV0FBVTtLQUN6Qjs7U0FFSSxJQUFJLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxLQUFLLFdBQVcsRUFBRTtNQUNuRCxJQUFJLE1BQU0sWUFBVztNQUNyQixNQUFNLElBQUksTUFBSzs7TUFFZixJQUFJLElBQUksS0FBSyxTQUFTO1FBQ3BCLFFBQVEsSUFBSSxXQUFVO01BQ3hCLElBQUksSUFBSSxLQUFLLFdBQVc7UUFDdEIsUUFBUSxJQUFJLFdBQVU7S0FDekI7O1NBRUksSUFBSSxJQUFJLEtBQUssWUFBWSxJQUFJLElBQUksS0FBSyxXQUFXLEVBQUU7TUFDdEQsSUFBSSxrQkFBa0IsaUJBQWdCO01BQ3RDLE1BQU0sZ0JBQWdCLEdBQUU7TUFDeEIsUUFBUSxjQUFjLFNBQVE7TUFDOUIsaUJBQWlCLEtBQUssR0FBRTtLQUN6Qjs7SUFFRCxPQUFPO01BQ0wsUUFBUSxFQUFFLGlCQUFpQixFQUFFLE1BQU0sRUFBRSxJQUFJO0tBQzFDO0dBQ0Y7O0VBRUQsY0FBYyxDQUFDLENBQUMsUUFBUSxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsRUFBRTtJQUMxRCxJQUFJLFFBQVEsS0FBSyxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDO01BQzlCLFFBQVEsR0FBRyxzQkFBcUI7SUFDbEMsSUFBSSxpQkFBaUIsS0FBSyxNQUFNO01BQzlCLGlCQUFpQixHQUFHLE9BQU07O0lBRTVCLE9BQU8sQ0FBQztxQkFDUyxFQUFFLFFBQVEsQ0FBQztzQkFDVixFQUFFLElBQUksQ0FBQztrQkFDWCxFQUFFLGlCQUFpQixDQUFDO21CQUNuQixFQUFFLE1BQU0sQ0FBQztJQUN4QixDQUFDO0dBQ0Y7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxXQUFXLENBQUM7O0FDcEYzQyxNQUFNLFdBQVcsU0FBUyxTQUFTLENBQUM7RUFDekMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLEdBQUU7SUFDcEIsSUFBSSxDQUFDLElBQUksU0FBUyxPQUFNO0dBQ3pCOztFQUVELGlCQUFpQixHQUFHLEVBQUU7O0VBRXRCLElBQUksR0FBRztJQUNMLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTTtHQUN6Qzs7RUFFRCxNQUFNLEdBQUc7SUFDUCxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzs7OztZQUlWLEVBQUVBLElBQUksQ0FBQztZQUNQLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQzs7Ozs7OztJQU9yQixDQUFDO0dBQ0Y7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxXQUFXLENBQUM7O0FDakMzQyxNQUFNLGFBQWEsU0FBUyxTQUFTLENBQUM7RUFDM0MsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLEdBQUU7SUFDcEIsSUFBSSxDQUFDLElBQUksU0FBUyxTQUFRO0dBQzNCOztFQUVELGlCQUFpQixHQUFHLEVBQUU7O0VBRXRCLElBQUksR0FBRztJQUNMLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTTtHQUN6Qzs7RUFFRCxNQUFNLEdBQUc7SUFDUCxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzs7OztZQUlWLEVBQUVBLE1BQUksQ0FBQztZQUNQLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQzs7Ozs7OztJQU9yQixDQUFDO0dBQ0Y7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLGFBQWEsQ0FBQzs7QUNuQi9DLE1BQU0sT0FBTyxTQUFTLFdBQVcsQ0FBQzs7RUFFdkMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxRQUFRLEdBQUc7TUFDZCxNQUFNLFVBQVUsUUFBUSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQztNQUN4RCxTQUFTLE9BQU8sUUFBUSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQztNQUMzRCxhQUFhLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyx1QkFBdUIsQ0FBQztNQUMvRCxJQUFJLFlBQVksUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUM7TUFDdEQsTUFBTSxVQUFVLFFBQVEsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUM7TUFDeEQsT0FBTyxTQUFTLFFBQVEsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUM7TUFDekQsS0FBSyxXQUFXLFFBQVEsQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDO01BQ3ZELFFBQVEsUUFBUSxRQUFRLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDO01BQzFELFNBQVMsT0FBTyxRQUFRLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDO01BQzNELFFBQVEsUUFBUSxRQUFRLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDO01BQzFELElBQUksWUFBWSxRQUFRLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQztNQUN0RCxJQUFJLFlBQVksUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUM7TUFDdEQsTUFBTSxVQUFVLFFBQVEsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUM7TUFDekQ7O0lBRUQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUk7TUFDdkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBQztHQUMxQjs7RUFFRCxpQkFBaUIsR0FBRztJQUNsQixPQUFPLENBQUMsU0FBUyxFQUFFLENBQUM7TUFDbEIsSUFBSSxDQUFDLFFBQVE7VUFDVCxJQUFJLENBQUMsUUFBUSxFQUFFO1VBQ2YsSUFBSSxDQUFDLFFBQVEsRUFBRSxFQUFDOztJQUV0QixPQUFPLENBQUMsS0FBSyxFQUFFLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFLEVBQUM7R0FDckM7O0VBRUQsb0JBQW9CLEdBQUcsRUFBRTs7RUFFekIsUUFBUSxHQUFHO0lBQ1QsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsTUFBTTtJQUMxQixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksR0FBRTtJQUNwQixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUk7R0FDckI7O0VBRUQsUUFBUSxHQUFHO0lBQ1QsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUTtNQUMzQixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxFQUFDO0lBQzdCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFFO0dBQ3JCO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxPQUFPLENBQUM7O0FDL0RoRDtBQUNBLE1BQU0sVUFBVSxHQUFHLG9CQUFvQjtHQUNwQyxLQUFLLENBQUMsR0FBRyxDQUFDO0dBQ1YsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUs7SUFDcEIsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkUsRUFBRSxDQUFDO0dBQ0osU0FBUyxDQUFDLENBQUMsRUFBQzs7QUFFZixNQUFNLGNBQWMsR0FBRyxDQUFDLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLFdBQVcsRUFBQzs7QUFFaEcsQUFBTyxTQUFTLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUFFO0VBQ2xDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ2xDLElBQUksQ0FBQyxDQUFDLFlBQVksRUFBRSxNQUFNOztJQUUxQixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLFdBQVcsQ0FBQyxTQUFTLEVBQUUsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFDO0dBQ3RDLEVBQUM7O0VBRUYsT0FBTyxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDdEMsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixtQkFBbUIsQ0FBQyxTQUFTLEVBQUUsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFDO0dBQzlDLEVBQUM7O0VBRUYsT0FBTyxNQUFNO0lBQ1gsT0FBTyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUM7SUFDMUIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUM7SUFDOUIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsRUFBQztHQUNyQztDQUNGOztBQUVELEFBQU8sU0FBUyxXQUFXLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRTtFQUMxQyxHQUFHO0tBQ0EsR0FBRyxDQUFDLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUMvQixHQUFHLENBQUMsRUFBRSxLQUFLO01BQ1YsRUFBRTtNQUNGLEtBQUssS0FBSyxRQUFRLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQztNQUN2QyxPQUFPLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsUUFBUSxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztNQUNuRSxNQUFNLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7TUFDekQsUUFBUSxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztLQUMvQyxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLE1BQU0sRUFBRSxPQUFPLENBQUMsUUFBUTtZQUNwQixPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxNQUFNO1lBQ2hDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU07T0FDckMsQ0FBQyxDQUFDO0tBQ0osT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQztNQUMzQixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxNQUFNLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUM7Q0FDdEQ7O0FBRUQsQUFBTyxTQUFTLG1CQUFtQixDQUFDLEdBQUcsRUFBRSxVQUFVLEVBQUU7RUFDbkQsTUFBTSxLQUFLLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUM7RUFDbkMsSUFBSSxLQUFLLEdBQUcsR0FBRTs7RUFFZCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsS0FBSyxHQUFHLFFBQVEsR0FBRyxNQUFLO0VBQ3RELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLEdBQUcsTUFBTSxHQUFHLE1BQUs7O0VBRXBELG9CQUFvQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7S0FDNUIsT0FBTyxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsR0FBRyxFQUFFLEtBQUssR0FBRyxJQUFJLENBQUMsRUFBQztDQUNuRDs7QUMzREQsTUFBTUMsWUFBVSxHQUFHLHFCQUFvQjs7OztBQUl2QyxBQUFPLFNBQVMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUU7RUFDcEMsT0FBTyxDQUFDQSxZQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSztJQUNoQyxJQUFJLENBQUMsQ0FBQyxZQUFZLEVBQUUsTUFBTTs7SUFFMUIsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixDQUFDLENBQUMsZUFBZSxHQUFFOztJQUVuQixTQUFTLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRSxJQUFJO01BQ3hCLFdBQVcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFDO01BQ3BCLGNBQWMsQ0FBQyxFQUFFLEVBQUM7S0FDbkIsRUFBQztHQUNILEVBQUM7O0VBRUYsT0FBTyxNQUFNO0lBQ1gsT0FBTyxDQUFDLE1BQU0sQ0FBQ0EsWUFBVSxFQUFDO0dBQzNCO0NBQ0Y7O0FBRUQsQUFBTyxTQUFTLFdBQVcsQ0FBQyxFQUFFLEVBQUUsU0FBUyxFQUFFO0VBQ3pDLElBQUksQ0FBQyxFQUFFLEVBQUUsTUFBTTs7RUFFZixPQUFPLFNBQVM7SUFDZCxLQUFLLE1BQU07TUFDVCxJQUFJLFdBQVcsQ0FBQyxFQUFFLENBQUM7UUFDakIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxzQkFBc0IsRUFBQzs7UUFFekQsUUFBUSxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUM7TUFDekIsS0FBSzs7SUFFUCxLQUFLLE9BQU87TUFDVixJQUFJLFlBQVksQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsa0JBQWtCLENBQUMsV0FBVztRQUN2RCxFQUFFLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsRUFBQztXQUM5RCxJQUFJLFlBQVksQ0FBQyxFQUFFLENBQUM7UUFDdkIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsRUFBRSxFQUFDOztRQUU3QixRQUFRLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBQztNQUN6QixLQUFLOztJQUVQLEtBQUssSUFBSTtNQUNQLElBQUksU0FBUyxDQUFDLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFDO01BQ2QsS0FBSzs7SUFFUCxLQUFLLE1BQU07TUFDVCxJQUFJLFlBQVksQ0FBQyxFQUFFLENBQUM7UUFDbEIsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBQztXQUN0QixJQUFJLFdBQVcsQ0FBQyxFQUFFLENBQUM7UUFDdEIsRUFBRSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUM7TUFDbkMsS0FBSztHQUNSO0NBQ0Y7O0FBRUQsQUFBTyxNQUFNLFdBQVcsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDLHVCQUFzQjtBQUM3RCxBQUFPLE1BQU0sWUFBWSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsbUJBQWtCO0FBQ3pELEFBQU8sTUFBTSxXQUFXLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxrQkFBa0IsSUFBSSxFQUFFLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLE9BQU07QUFDbEcsQUFBTyxNQUFNLFlBQVksS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsa0JBQWtCLElBQUksRUFBRSxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUMsVUFBVSxDQUFDLFdBQVU7QUFDdkcsQUFBTyxNQUFNLFNBQVMsUUFBUSxFQUFFLElBQUksRUFBRSxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUMsVUFBVSxDQUFDLFdBQVU7O0FBRTdFLEFBQU8sTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEdBQUcsS0FBSyxDQUFDO0VBQ3hDLEVBQUUsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFO0lBQ3RDLEVBQUUsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLFFBQVE7TUFDL0IsS0FBSztVQUNELFlBQVksQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDO1VBQ3BCLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDOztBQUU1QixBQUFPLFNBQVMsY0FBYyxDQUFDLEVBQUUsRUFBRTtFQUNqQyxJQUFJLE9BQU8sR0FBRyxHQUFFOztFQUVoQixJQUFJLFdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLElBQUksSUFBRztFQUNwQyxJQUFJLFlBQVksQ0FBQyxFQUFFLENBQUMsRUFBRSxPQUFPLElBQUksSUFBRztFQUNwQyxJQUFJLFdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLElBQUksSUFBRztFQUNwQyxJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsS0FBSyxPQUFPLElBQUksSUFBRzs7RUFFcEMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxrQkFBa0IsRUFBQzs7O0NBQzFELERDOUVELElBQUksSUFBSSxRQUFRLEVBQUU7SUFDZCxRQUFRLElBQUksRUFBRTtJQUNkLFNBQVE7O0FBRVosQUFBTyxTQUFTLG9CQUFvQixHQUFHO0VBQ3JDLElBQUksR0FBRyxDQUFDLENBQUM7SUFDUCxHQUFHLFFBQVEsQ0FBQyxNQUFNO0lBQ2xCLEdBQUcsb0JBQW9CLENBQUMsUUFBUSxDQUFDO0dBQ2xDLEVBQUM7O0VBRUYsYUFBYSxDQUFDLElBQUksRUFBQztFQUNuQixZQUFZLENBQUMsSUFBSSxFQUFDO0NBQ25COztBQUVELE1BQU0sWUFBWSxHQUFHLElBQUksSUFBSTtFQUMzQixJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRSxXQUFXLEVBQUM7RUFDaEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFDO0VBQ2pDLElBQUksQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBQztFQUN2QixDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFDO0VBQzVDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUM7RUFDN0MsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBQztFQUNuQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFDO0VBQzdDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUM7RUFDMUM7O0FBRUQsTUFBTSxhQUFhLEdBQUcsSUFBSSxJQUFJO0VBQzVCLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBQztFQUNsQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUM7RUFDbEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFDO0VBQ3hCLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUM7RUFDOUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBQztFQUM5QyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFDO0VBQ3BDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUM7RUFDN0MsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBQztFQUN6QyxJQUFJLEdBQUcsR0FBRTtFQUNWOztBQUVELE1BQU0sV0FBVyxHQUFHLElBQUksSUFBSTtFQUMxQixPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sS0FBSztJQUN0QyxJQUFJLE1BQU0sR0FBRyxJQUFJLFVBQVUsR0FBRTtJQUM3QixNQUFNLENBQUMsYUFBYSxDQUFDLElBQUksRUFBQztJQUMxQixNQUFNLENBQUMsU0FBUyxHQUFHLE1BQU0sT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUM7R0FDaEQsQ0FBQztFQUNIOzs7QUFHRCxNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDO0VBQzNCLFFBQVEsR0FBRyxPQUFNOztBQUVuQixNQUFNLFNBQVMsR0FBRyxDQUFDO0VBQ2pCLFFBQVEsR0FBRyxVQUFTOztBQUV0QixNQUFNLFdBQVcsR0FBRyxDQUFDLElBQUk7RUFDdkIsQ0FBQyxDQUFDLGNBQWMsR0FBRTtFQUNsQixNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMseUJBQXlCLEVBQUM7O0VBRWpELElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTTtJQUN0QixXQUFXLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDLEVBQUM7O0lBRS9CLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztNQUMxQixXQUFXLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFDO0VBQ3pCOztBQUVELE1BQU0sV0FBVyxHQUFHLENBQUM7RUFDbkIsWUFBWSxHQUFFOzs7QUFHaEIsTUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLElBQUk7RUFDeEIsQ0FBQyxDQUFDLGVBQWUsR0FBRTtFQUNuQixDQUFDLENBQUMsY0FBYyxHQUFFOztFQUVsQixNQUFNLGNBQWMsR0FBRyxDQUFDLENBQUMseUJBQXlCLEVBQUM7O0VBRW5ELE1BQU0sSUFBSSxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLE1BQU07TUFDcEMsTUFBTSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQztPQUMxQyxNQUFNLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO09BQzNDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztNQUNsQixDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUM7O0VBRWxCLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtJQUNmLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTTtNQUN4QixJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLEtBQUs7UUFDN0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMsRUFBQzs7UUFFdEIsSUFBSTtXQUNELE1BQU0sQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7V0FDckMsT0FBTyxDQUFDLEdBQUc7WUFDVixHQUFHLENBQUMsS0FBSyxDQUFDLGVBQWUsR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUM7U0FDakQsSUFBSSxjQUFjLENBQUMsTUFBTSxFQUFFO01BQzlCLElBQUksQ0FBQyxHQUFHLEVBQUM7TUFDVCxjQUFjLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSTtRQUM1QixHQUFHLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBQztRQUNuQixJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxFQUFDO09BQzVCLEVBQUM7S0FDSDtHQUNGOztFQUVELFlBQVksR0FBRTtFQUNmOztBQUVELE1BQU0sV0FBVyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSztFQUMvQixNQUFNLElBQUksTUFBTSxJQUFJLENBQUMscUJBQXFCLEdBQUU7RUFDNUMsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFBQzs7RUFFM0IsSUFBSSxPQUFPLEVBQUU7SUFDWCxPQUFPLENBQUMsTUFBTSxHQUFHLEtBQUk7R0FDdEI7T0FDSTtJQUNILFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLGdCQUFnQixFQUFDO0lBQ3RELFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsS0FBSTtJQUMzQixRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUM7R0FDdkM7RUFDRjs7QUFFRCxNQUFNLFlBQVksR0FBRyxNQUFNO0VBQ3pCLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTztJQUN0QixPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUM7RUFDbkIsUUFBUSxHQUFHLEdBQUU7RUFDZDs7QUFFRCxNQUFNLG9CQUFvQixHQUFHLEVBQUUsSUFBSTtFQUNqQyxNQUFNLFNBQVMsR0FBRywyQ0FBMEM7O0VBRTVELE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFVBQVUsRUFBRSxJQUFJLEtBQUs7SUFDekMsTUFBTSxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQUksRUFBRSxrQkFBa0IsRUFBQztJQUMvQyxNQUFNLEtBQUssR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQzs7O0lBR2xDLElBQUksS0FBSyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDOztJQUVoQyxPQUFPLFVBQVU7R0FDbEIsRUFBRSxFQUFFLENBQUM7Q0FDUDs7QUN2SUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtQkEsQUFBTyxTQUFTLG9CQUFvQixDQUFDLFFBQVEsRUFBRSxJQUFJLEdBQUcsUUFBUSxFQUFFO0lBQzVELE9BQU8sa0JBQWtCLENBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztDQUNuRDtBQUNELEFBSUE7QUFDQSxTQUFTLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFO0lBQ2xELElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7O0lBRWhELElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRTs7UUFFOUQsSUFBSSxDQUFDLFFBQVEsSUFBSSxZQUFZLEVBQUU7WUFDM0IsT0FBTyxZQUFZLENBQUM7U0FDdkI7OztRQUdELE1BQU0sZ0JBQWdCLEdBQUcsNEJBQTRCLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDOztRQUVyRSxPQUFPLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxlQUFlLEtBQUs7O1lBRXJELElBQUksQ0FBQyxRQUFRLElBQUksR0FBRyxFQUFFO2dCQUNsQixPQUFPLEdBQUcsQ0FBQzthQUNkOztZQUVELE1BQU0sYUFBYSxHQUFHLDRCQUE0QixDQUFDLGVBQWU7O3FCQUV6RCxPQUFPLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQztxQkFDcEIsT0FBTyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQzs7aUJBRTFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEMsTUFBTSxxQkFBcUIsR0FBRyxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUN2RCxNQUFNLGdCQUFnQixHQUFHLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzVGLE1BQU0sWUFBWSxHQUFHLG1CQUFtQixDQUFDLGFBQWEsRUFBRSxxQkFBcUIsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNyRixJQUFJLFFBQVEsRUFBRTtnQkFDVixHQUFHLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztnQkFDeEQsT0FBTyxHQUFHLENBQUM7YUFDZCxNQUFNO2dCQUNILEdBQUcsR0FBRyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBQzFDLE9BQU8sR0FBRyxJQUFJLElBQUksQ0FBQzthQUN0QjtTQUNKLEVBQUUsUUFBUSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQzs7O0tBRzVCLE1BQU07UUFDSCxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ1gsT0FBTyxZQUFZLENBQUM7U0FDdkIsTUFBTTtZQUNILE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQzFDO0tBQ0o7O0NBRUo7O0FBRUQsU0FBUyxtQkFBbUIsQ0FBQyxhQUFhLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFO0lBQ3JFLE9BQU8sQ0FBQyxPQUFPLEtBQUs7UUFDaEIsSUFBSSxRQUFRLEdBQUcscUJBQXFCLENBQUM7UUFDckMsSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDO1FBQ3JCLElBQUksWUFBWSxHQUFHLEtBQUssQ0FBQztRQUN6QixPQUFPLE1BQU0sRUFBRTtZQUNYLE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDM0QsSUFBSSxVQUFVLElBQUksUUFBUSxLQUFLLENBQUMsRUFBRTtnQkFDOUIsWUFBWSxHQUFHLElBQUksQ0FBQztnQkFDcEIsTUFBTTthQUNUO1lBQ0QsSUFBSSxVQUFVLEVBQUU7Z0JBQ1osUUFBUSxFQUFFLENBQUM7YUFDZDtZQUNELE1BQU0sR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDM0M7UUFDRCxPQUFPLFlBQVksQ0FBQztLQUN2QixDQUFDOztDQUVMOztBQUVELFNBQVMsNEJBQTRCLENBQUMsUUFBUSxFQUFFLFNBQVMsRUFBRTtJQUN2RCxPQUFPLFFBQVEsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSztRQUMvQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFO1lBQ3hCLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDO1lBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDNUIsTUFBTSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO1lBQy9CLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDO1lBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7O1NBRTVCLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsS0FBSyxTQUFTLEVBQUU7WUFDakQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDaEIsTUFBTTtZQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzVCO1FBQ0QsT0FBTyxDQUFDLENBQUM7S0FDWixFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztDQUNyQjs7O0FBR0QsU0FBUyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFO0lBQ3JDLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUM7SUFDdEMsT0FBTyxDQUFDLFVBQVUsSUFBSSxVQUFVLENBQUMsSUFBSSxJQUFJLFVBQVUsQ0FBQyxRQUFRLEtBQUssRUFBRSxJQUFJLFVBQVUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsVUFBVSxDQUFDO0NBQ3BJOzs7Ozs7Ozs7QUFTRCxTQUFTLHNCQUFzQixDQUFDLFFBQVEsR0FBRyxJQUFJLEVBQUUsSUFBSSxFQUFFO0lBQ25ELE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQzs7SUFFdkIsTUFBTSxlQUFlLEdBQUcsU0FBUyxLQUFLLEVBQUU7UUFDcEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDcEMsV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQzs7WUFFckIsSUFBSSxFQUFFLENBQUMsVUFBVSxFQUFFO2dCQUNmLGVBQWUsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7YUFDeEQ7U0FDSjtLQUNKLENBQUM7SUFDRixHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUU7UUFDaEIsZUFBZSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztLQUMxRDtJQUNELGVBQWUsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQzs7SUFFNUMsT0FBTyxRQUFRLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLFdBQVcsQ0FBQzs7O0NBQ2xGLERDaEpNLE1BQU0sUUFBUSxHQUFHO0VBQ3RCLFlBQVk7RUFDWixZQUFZO0VBQ1osY0FBYztFQUNmOztBQUVELEFBQWUsd0JBQVEsR0FBRztFQUN4QixRQUFRO0tBQ0wsZ0JBQWdCLENBQUMsbUNBQW1DLENBQUM7S0FDckQsT0FBTyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUM7Q0FDbEM7O0FDVk0sTUFBTUMsVUFBUSxHQUFHO0VBQ3RCLGFBQWE7RUFDYixrQkFBa0I7RUFDbkI7O0FBRUQsQUFBZSwrQkFBYyxHQUFHO0VBQzlCLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGVBQWUsR0FBRyxjQUFhOztFQUVuRCxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBQzFCLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRTtJQUMzQixFQUFFLFNBQVMsRUFBRSxnQkFBZ0IsRUFBRTtHQUNoQyxFQUFFLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsU0FBUTs7RUFFL0IsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxHQUFHLEdBQUU7OztDQUN6QyxEQ1pNLE1BQU1BLFVBQVEsR0FBRztFQUN0QixXQUFXO0VBQ1o7O0FBRUQsQUFBZSw4QkFBYyxHQUFHO0VBQzlCLE1BQU0sVUFBVSxDQUFDLENBQUMseURBQXlELENBQUMsRUFBQzs7O0NBQzlFLERDTk0sTUFBTUEsVUFBUSxHQUFHO0VBQ3RCLFFBQVE7RUFDUixXQUFXO0VBQ1o7O0FBRUQsQUFBZSw4QkFBYyxHQUFHO0VBQzlCLE1BQU0sVUFBVSxDQUFDLENBQUMsNkVBQTZFLENBQUMsRUFBQzs7O0NBQ2xHLERDUE0sTUFBTUEsVUFBUSxHQUFHO0VBQ3RCLGNBQWM7RUFDZCxpQkFBaUI7RUFDbEI7O0FBRUQsQUFBZSxtQ0FBYyxHQUFHO0VBQzlCLE1BQU0sVUFBVSxDQUFDLENBQUMsNkVBQTZFLENBQUMsRUFBQzs7O0NBQ2xHLERDVE0sTUFBTUEsVUFBUSxHQUFHO0VBQ3RCLFdBQVc7RUFDWCxXQUFXO0VBQ1o7O0FBRUQsQUFBZSw4QkFBYyxHQUFHO0VBQzlCLE1BQU0sTUFBTSxHQUFHLENBQUM7Ozs7Ozs7RUFPaEIsRUFBQzs7RUFFRCxNQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBQztFQUM3QyxLQUFLLENBQUMsV0FBVyxHQUFHLE9BQU07RUFDMUIsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFDOzs7Q0FDakMsRENsQk0sTUFBTUEsVUFBUSxHQUFHO0VBQ3RCLFVBQVU7RUFDVixTQUFTO0VBQ1Y7O0FBRUQsQUFBZSw2QkFBYyxHQUFHO0VBQzlCLE1BQU0sTUFBTSxHQUFHLENBQUM7Ozs7Ozs7OztFQVNoQixFQUFDOztFQUVELE1BQU0sS0FBSyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFDO0VBQzdDLEtBQUssQ0FBQyxXQUFXLEdBQUcsT0FBTTtFQUMxQixRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUM7OztBQ25CbEM7QUFDQSxBQUFPLE1BQU1BLFVBQVEsR0FBRztFQUN0QixjQUFjO0VBQ2QsUUFBUTtFQUNUOztBQUVELEFBQWUsZ0NBQWMsR0FBRztFQUM5QixLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUNqRCxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUM7OztBQ1JoRTtBQUNBLEFBRUE7QUFDQSxBQUFPLE1BQU1BLFVBQVEsR0FBRztFQUN0QixTQUFTO0VBQ1QsYUFBYTtFQUNiLFFBQVE7RUFDVDs7QUFFRCxBQUFlLDRCQUFjLEdBQUc7RUFDOUIsTUFBTSxVQUFVLENBQUMsQ0FBQyxtRUFBbUUsQ0FBQyxFQUFDOzs7Q0FDeEYsRENGRCxNQUFNLGNBQWMsR0FBRyxDQUFDLGVBQWUsRUFBRSxTQUFTO0VBQ2hELGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQ0EsV0FBUSxFQUFFLE9BQU87SUFDdkMsTUFBTSxDQUFDLE1BQU0sQ0FBQ0EsV0FBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQ3BELEVBQUUsRUFBQzs7QUFFUCxBQUFPLE1BQU0sY0FBYyxHQUFHLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7RUFDbkQsR0FBRyxjQUFjLENBQUNDLFFBQW1CLEVBQUUsZUFBZSxDQUFDO0VBQ3ZELEdBQUcsY0FBYyxDQUFDQyxVQUFvQixFQUFFLGdCQUFnQixDQUFDO0VBQ3pELEdBQUcsY0FBYyxDQUFDQyxVQUFrQixFQUFFLGVBQWUsQ0FBQztFQUN0RCxHQUFHLGNBQWMsQ0FBQ0MsVUFBa0IsRUFBRSxlQUFlLENBQUM7RUFDdEQsR0FBRyxjQUFjLENBQUNDLFVBQXdCLEVBQUUsb0JBQW9CLENBQUM7RUFDakUsR0FBRyxjQUFjLENBQUNDLFVBQWtCLEVBQUUsZUFBZSxDQUFDO0VBQ3RELEdBQUcsY0FBYyxDQUFDQyxVQUFpQixFQUFFLGNBQWMsQ0FBQztFQUNwRCxHQUFHLGNBQWMsQ0FBQ0MsVUFBcUIsRUFBRSxpQkFBaUIsQ0FBQztFQUMzRCxHQUFHLGNBQWMsQ0FBQ0MsVUFBZ0IsRUFBRSxhQUFhLENBQUM7Q0FDbkQsQ0FBQyxFQUFDOztBQUVILEFBQU8sTUFBTSxXQUFXLEdBQUc7RUFDekJSLFFBQW1CLENBQUMsQ0FBQyxDQUFDO0VBQ3RCQyxVQUFvQixDQUFDLENBQUMsQ0FBQztFQUN2QkMsVUFBa0IsQ0FBQyxDQUFDLENBQUM7RUFDckJDLFVBQWtCLENBQUMsQ0FBQyxDQUFDO0VBQ3JCQyxVQUF3QixDQUFDLENBQUMsQ0FBQztFQUMzQkMsVUFBa0IsQ0FBQyxDQUFDLENBQUM7RUFDckJDLFVBQWlCLENBQUMsQ0FBQyxDQUFDO0VBQ3BCQyxVQUFxQixDQUFDLENBQUMsQ0FBQztFQUN4QkMsVUFBZ0IsQ0FBQyxDQUFDLENBQUM7Q0FDcEIsQ0FBQyxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7O0FDaEMvQixJQUFJLGVBQWM7OztBQUdsQixNQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBQztBQUNqRCxXQUFXLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUM7QUFDbkMsV0FBVyxDQUFDLFNBQVMsR0FBRyxDQUFDOzs7SUFHckIsRUFBRSxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLE9BQU87TUFDcEMsT0FBTyxJQUFJLENBQUMsZUFBZSxFQUFFLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQztNQUN2RCxFQUFFLENBQUMsQ0FBQzs7Ozs7Ozs7QUFRVixFQUFDOztBQUVELE1BQU1DLFFBQU0sVUFBVSxDQUFDLENBQUMsV0FBVyxFQUFDO0FBQ3BDLE1BQU0sV0FBVyxLQUFLLENBQUMsQ0FBQyxPQUFPLEVBQUUsV0FBVyxFQUFDOztBQUU3QyxNQUFNLGFBQWEsR0FBRyxNQUFNQSxRQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxlQUFlLEVBQUM7QUFDakUsTUFBTSxhQUFhLEdBQUcsTUFBTUEsUUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsY0FBYyxFQUFDO0FBQ2hFLE1BQU0sWUFBWSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLFFBQVEsSUFBSSxDQUFDLENBQUMsZUFBZSxHQUFFOztBQUVuRSxBQUFPLFNBQVMsTUFBTSxDQUFDLElBQUksRUFBRTtFQUMzQixJQUFJLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDQSxRQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUM7O0VBRXhDLE1BQU0sT0FBTyxHQUFHLENBQUMsSUFBSTtJQUNuQixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLENBQUMsQ0FBQyxlQUFlLEdBQUU7O0lBRW5CLE1BQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBSzs7SUFFNUIsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUM7TUFDMUIsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFDO0lBQ3BCOztFQUVELFdBQVcsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLE9BQU8sRUFBQztFQUNoQyxXQUFXLENBQUMsRUFBRSxDQUFDLFNBQVMsRUFBRSxZQUFZLEVBQUM7OztFQUd2QyxhQUFhLEdBQUU7RUFDZixXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFFOzs7Ozs7O0VBT3RCLE9BQU8sTUFBTTtJQUNYLGFBQWEsR0FBRTtJQUNmLFdBQVcsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBQztJQUNuQyxXQUFXLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxZQUFZLEVBQUM7SUFDeEMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsYUFBYSxFQUFDO0dBQ3ZDO0NBQ0Y7O0FBRUQsQUFBTyxTQUFTLHFCQUFxQixDQUFDLE1BQU0sRUFBRTtFQUM1QyxjQUFjLEdBQUcsT0FBTTtDQUN4Qjs7QUFFRCxBQUFPLFNBQVMsU0FBUyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7O0VBRW5DLElBQUksY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7SUFDM0IsT0FBTyxjQUFjLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQzs7RUFFekMsSUFBSSxLQUFLLElBQUksT0FBTyxNQUFNLEtBQUssR0FBRyxJQUFHO0VBQ3JDLElBQUksS0FBSyxJQUFJLFNBQVMsSUFBSSxLQUFLLEdBQUcsU0FBUTtFQUMxQyxJQUFJLEtBQUssSUFBSSxRQUFRLEtBQUssS0FBSyxHQUFHLE1BQUs7RUFDdkMsSUFBSSxLQUFLLElBQUksTUFBTSxPQUFPLEtBQUssR0FBRyx5REFBd0Q7O0VBRTFGLElBQUksQ0FBQyxLQUFLLEVBQUUsT0FBTyxjQUFjLENBQUMsWUFBWSxFQUFFO0VBQ2hELElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLElBQUksR0FBRyxJQUFJLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTTs7RUFFdEUsSUFBSTtJQUNGLElBQUksT0FBTyxHQUFHLG9CQUFvQixDQUFDLEtBQUssR0FBRyxzR0FBc0csRUFBQztJQUNsSixJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLEdBQUcsb0JBQW9CLENBQUMsS0FBSyxFQUFDO0lBQzFELElBQUksQ0FBQyxFQUFFLEVBQUUsY0FBYyxDQUFDLFlBQVksR0FBRTtJQUN0QyxJQUFJLE9BQU8sQ0FBQyxNQUFNO01BQ2hCLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRTtRQUNoQixFQUFFO1lBQ0UsRUFBRSxDQUFDLEVBQUUsQ0FBQztZQUNOLGNBQWMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUM7R0FDbkM7RUFDRCxPQUFPLEdBQUcsRUFBRSxFQUFFO0NBQ2Y7O0FDN0ZELE1BQU0sS0FBSyxHQUFHO0VBQ1osU0FBUyxHQUFHLEVBQUU7RUFDZCxNQUFNLE1BQU0sSUFBSTtFQUNqQjs7QUFFRCxBQUFPLFNBQVMsa0JBQWtCLENBQUMsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLEVBQUU7RUFDckQsSUFBSSxLQUFLLENBQUMsTUFBTSxJQUFJLE9BQU8sSUFBSSxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxNQUFNO09BQ3hELEtBQUssQ0FBQyxNQUFNLEdBQUcsUUFBTzs7RUFFM0IsSUFBSSxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxpQkFBaUIsR0FBRTs7RUFFL0MsTUFBTSxZQUFZLEdBQUcsT0FBTyxDQUFDLHFCQUFxQixHQUFFO0VBQ3BELE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyxxQkFBcUIsR0FBRTs7RUFFcEQsTUFBTSxZQUFZLEdBQUcsR0FBRTs7O0VBR3ZCLElBQUksWUFBWSxDQUFDLEtBQUssR0FBRyxZQUFZLENBQUMsSUFBSSxFQUFFO0lBQzFDLFlBQVksQ0FBQyxJQUFJLENBQUM7TUFDaEIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxLQUFLO01BQ3JCLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFJLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO01BQy9DLENBQUMsRUFBRSxZQUFZLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxLQUFLO01BQ3pDLENBQUMsRUFBRSxPQUFPO0tBQ1gsRUFBQztHQUNIO0VBQ0QsSUFBSSxZQUFZLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxLQUFLLElBQUksWUFBWSxDQUFDLEtBQUssR0FBRyxZQUFZLENBQUMsSUFBSSxFQUFFO0lBQ3JGLFlBQVksQ0FBQyxJQUFJLENBQUM7TUFDaEIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxLQUFLO01BQ3JCLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFJLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO01BQy9DLENBQUMsRUFBRSxZQUFZLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxLQUFLO01BQzFDLENBQUMsRUFBRSxPQUFPO0tBQ1gsRUFBQztHQUNIOzs7RUFHRCxJQUFJLFlBQVksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLEtBQUssRUFBRTtJQUMxQyxZQUFZLENBQUMsSUFBSSxDQUFDO01BQ2hCLENBQUMsRUFBRSxZQUFZLENBQUMsS0FBSztNQUNyQixDQUFDLEVBQUUsWUFBWSxDQUFDLEdBQUcsSUFBSSxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztNQUMvQyxDQUFDLEVBQUUsWUFBWSxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsS0FBSztNQUN6QyxDQUFDLEVBQUUsTUFBTTtLQUNWLEVBQUM7R0FDSDtFQUNELElBQUksWUFBWSxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsSUFBSSxJQUFJLFlBQVksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLEtBQUssRUFBRTtJQUNuRixZQUFZLENBQUMsSUFBSSxDQUFDO01BQ2hCLENBQUMsRUFBRSxZQUFZLENBQUMsSUFBSTtNQUNwQixDQUFDLEVBQUUsWUFBWSxDQUFDLEdBQUcsSUFBSSxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztNQUMvQyxDQUFDLEVBQUUsWUFBWSxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsSUFBSTtNQUN4QyxDQUFDLEVBQUUsTUFBTTtLQUNWLEVBQUM7R0FDSDs7O0VBR0QsSUFBSSxZQUFZLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUU7SUFDMUMsWUFBWSxDQUFDLElBQUksQ0FBQztNQUNoQixDQUFDLEVBQUUsWUFBWSxDQUFDLElBQUksSUFBSSxZQUFZLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztNQUMvQyxDQUFDLEVBQUUsWUFBWSxDQUFDLE1BQU07TUFDdEIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDLE1BQU07TUFDekMsQ0FBQyxFQUFFLEtBQUs7TUFDUixDQUFDLEVBQUUsSUFBSTtLQUNSLEVBQUM7R0FDSDtFQUNELElBQUksWUFBWSxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUMsR0FBRyxJQUFJLFlBQVksQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRTtJQUNqRixZQUFZLENBQUMsSUFBSSxDQUFDO01BQ2hCLENBQUMsRUFBRSxZQUFZLENBQUMsSUFBSSxJQUFJLFlBQVksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO01BQy9DLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRztNQUNuQixDQUFDLEVBQUUsWUFBWSxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUMsR0FBRztNQUN0QyxDQUFDLEVBQUUsS0FBSztNQUNSLENBQUMsRUFBRSxJQUFJO0tBQ1IsRUFBQztHQUNIOzs7RUFHRCxJQUFJLFlBQVksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDLEdBQUcsRUFBRTtJQUMxQyxZQUFZLENBQUMsSUFBSSxDQUFDO01BQ2hCLENBQUMsRUFBRSxZQUFZLENBQUMsSUFBSSxJQUFJLFlBQVksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO01BQy9DLENBQUMsRUFBRSxZQUFZLENBQUMsTUFBTTtNQUN0QixDQUFDLEVBQUUsWUFBWSxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUMsTUFBTTtNQUN6QyxDQUFDLEVBQUUsUUFBUTtNQUNYLENBQUMsRUFBRSxJQUFJO0tBQ1IsRUFBQztHQUNIO0VBQ0QsSUFBSSxZQUFZLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQyxNQUFNLElBQUksWUFBWSxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUMsR0FBRyxFQUFFO0lBQ3ZGLFlBQVksQ0FBQyxJQUFJLENBQUM7TUFDaEIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxJQUFJLElBQUksWUFBWSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7TUFDL0MsQ0FBQyxFQUFFLFlBQVksQ0FBQyxNQUFNO01BQ3RCLENBQUMsRUFBRSxZQUFZLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQyxNQUFNO01BQzVDLENBQUMsRUFBRSxRQUFRO01BQ1gsQ0FBQyxFQUFFLElBQUk7S0FDUixFQUFDO0dBQ0g7OztFQUdELElBQUksWUFBWSxDQUFDLEtBQUssR0FBRyxZQUFZLENBQUMsS0FBSyxJQUFJLFlBQVksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLElBQUksRUFBRTtJQUNwRixZQUFZLENBQUMsSUFBSSxDQUFDO01BQ2hCLENBQUMsRUFBRSxZQUFZLENBQUMsS0FBSztNQUNyQixDQUFDLEVBQUUsWUFBWSxDQUFDLEdBQUcsSUFBSSxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztNQUMvQyxDQUFDLEVBQUUsWUFBWSxDQUFDLEtBQUssR0FBRyxZQUFZLENBQUMsS0FBSztNQUMxQyxDQUFDLEVBQUUsTUFBTTtLQUNWLEVBQUM7SUFDRixZQUFZLENBQUMsSUFBSSxDQUFDO01BQ2hCLENBQUMsRUFBRSxZQUFZLENBQUMsSUFBSTtNQUNwQixDQUFDLEVBQUUsWUFBWSxDQUFDLEdBQUcsSUFBSSxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztNQUMvQyxDQUFDLEVBQUUsWUFBWSxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsSUFBSTtNQUN4QyxDQUFDLEVBQUUsT0FBTztLQUNYLEVBQUM7R0FDSDs7O0VBR0QsSUFBSSxZQUFZLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQyxHQUFHLElBQUksWUFBWSxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFO0lBQ3BGLFlBQVksQ0FBQyxJQUFJLENBQUM7TUFDaEIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxJQUFJLElBQUksWUFBWSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7TUFDL0MsQ0FBQyxFQUFFLFlBQVksQ0FBQyxHQUFHO01BQ25CLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQyxHQUFHO01BQ3RDLENBQUMsRUFBRSxRQUFRO01BQ1gsQ0FBQyxFQUFFLElBQUk7S0FDUixFQUFDO0lBQ0YsWUFBWSxDQUFDLElBQUksQ0FBQztNQUNoQixDQUFDLEVBQUUsWUFBWSxDQUFDLElBQUksSUFBSSxZQUFZLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztNQUMvQyxDQUFDLEVBQUUsWUFBWSxDQUFDLE1BQU07TUFDdEIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDLE1BQU07TUFDNUMsQ0FBQyxFQUFFLEtBQUs7TUFDUixDQUFDLEVBQUUsSUFBSTtLQUNSLEVBQUM7R0FDSDs7O0VBR0QsWUFBWTtLQUNULEdBQUcsQ0FBQyxXQUFXLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUU7TUFDN0MsQ0FBQyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRztLQUNwRCxDQUFDLENBQUM7S0FDRixPQUFPLENBQUMsV0FBVyxJQUFJO01BQ3RCLE1BQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLEVBQUM7O01BRTlELFlBQVksQ0FBQyxRQUFRLEdBQUc7UUFDdEIsVUFBVSxNQUFNLFdBQVc7UUFDM0IsYUFBYSxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTTtRQUN2Qzs7TUFFRCxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUM7TUFDdkMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxHQUFHLGFBQVk7S0FDdkQsRUFBQztDQUNMOztBQUVELEFBQU8sU0FBUyxpQkFBaUIsR0FBRztFQUNsQyxLQUFLLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFDO0VBQzlDLEtBQUssQ0FBQyxTQUFTLEdBQUcsR0FBRTtDQUNyQjs7QUNuSkQ7Ozs7QUFJQSxTQUFTLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFO0lBQ3JCLElBQUksY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO1FBQ25CLENBQUMsR0FBRyxNQUFNLENBQUM7S0FDZDtJQUNELE1BQU0sY0FBYyxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN2QyxDQUFDLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7SUFFaEUsSUFBSSxjQUFjLEVBQUU7UUFDaEIsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQztLQUMzQzs7SUFFRCxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLFFBQVEsRUFBRTtRQUM5QixPQUFPLENBQUMsQ0FBQztLQUNaOztJQUVELElBQUksR0FBRyxLQUFLLEdBQUcsRUFBRTs7OztRQUliLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsSUFBSSxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7S0FDbkU7U0FDSTs7O1FBR0QsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7S0FDM0M7SUFDRCxPQUFPLENBQUMsQ0FBQztDQUNaOzs7OztBQUtELFNBQVMsT0FBTyxDQUFDLEdBQUcsRUFBRTtJQUNsQixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7Q0FDeEM7Ozs7OztBQU1ELFNBQVMsY0FBYyxDQUFDLENBQUMsRUFBRTtJQUN2QixPQUFPLE9BQU8sQ0FBQyxLQUFLLFFBQVEsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7Q0FDaEY7Ozs7O0FBS0QsU0FBUyxZQUFZLENBQUMsQ0FBQyxFQUFFO0lBQ3JCLE9BQU8sT0FBTyxDQUFDLEtBQUssUUFBUSxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7Q0FDekQ7Ozs7O0FBS0QsU0FBUyxVQUFVLENBQUMsQ0FBQyxFQUFFO0lBQ25CLENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbEIsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQzVCLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDVDtJQUNELE9BQU8sQ0FBQyxDQUFDO0NBQ1o7Ozs7O0FBS0QsU0FBUyxtQkFBbUIsQ0FBQyxDQUFDLEVBQUU7SUFDNUIsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1FBQ1IsT0FBTyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0tBQ3pCO0lBQ0QsT0FBTyxDQUFDLENBQUM7Q0FDWjs7Ozs7QUFLRCxTQUFTLElBQUksQ0FBQyxDQUFDLEVBQUU7SUFDYixPQUFPLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztDQUM1Qzs7Ozs7Ozs7OztBQVVELFNBQVMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFO0lBQ3ZCLE9BQU87UUFDSCxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsR0FBRyxHQUFHO1FBQ3hCLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLEdBQUc7UUFDeEIsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRztLQUMzQixDQUFDO0NBQ0w7Ozs7OztBQU1ELFNBQVMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFO0lBQ3ZCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUM5QixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDOUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ1YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ1YsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsQ0FBQztJQUMxQixJQUFJLEdBQUcsS0FBSyxHQUFHLEVBQUU7UUFDYixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUNiO1NBQ0k7UUFDRCxNQUFNLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO1FBQ3BCLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDcEQsUUFBUSxHQUFHO1lBQ1AsS0FBSyxDQUFDO2dCQUNGLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNsQyxNQUFNO1lBQ1YsS0FBSyxDQUFDO2dCQUNGLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDcEIsTUFBTTtZQUNWLEtBQUssQ0FBQztnQkFDRixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3BCLE1BQU07U0FDYjtRQUNELENBQUMsSUFBSSxDQUFDLENBQUM7S0FDVjtJQUNELE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDO0NBQ3RCOzs7Ozs7O0FBT0QsU0FBUyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUU7SUFDdkIsSUFBSSxDQUFDLENBQUM7SUFDTixJQUFJLENBQUMsQ0FBQztJQUNOLElBQUksQ0FBQyxDQUFDO0lBQ04sQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDcEIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDcEIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDcEIsU0FBUyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUU7UUFDdEIsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUNMLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDWCxJQUFJLENBQUMsR0FBRyxDQUFDO1lBQ0wsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNYLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDWCxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUM5QjtRQUNELElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDWCxPQUFPLENBQUMsQ0FBQztTQUNaO1FBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN4QztRQUNELE9BQU8sQ0FBQyxDQUFDO0tBQ1o7SUFDRCxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7UUFDVCxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDakI7U0FDSTtRQUNELE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDaEQsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDcEIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDN0IsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3JCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0tBQ2hDO0lBQ0QsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7Q0FDakQ7Ozs7Ozs7QUFPRCxTQUFTLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRTtJQUN2QixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNwQixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNwQixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNwQixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDOUIsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzlCLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNWLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUNkLE1BQU0sQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7SUFDcEIsTUFBTSxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUNsQyxJQUFJLEdBQUcsS0FBSyxHQUFHLEVBQUU7UUFDYixDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQ1Q7U0FDSTtRQUNELFFBQVEsR0FBRztZQUNQLEtBQUssQ0FBQztnQkFDRixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDbEMsTUFBTTtZQUNWLEtBQUssQ0FBQztnQkFDRixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3BCLE1BQU07WUFDVixLQUFLLENBQUM7Z0JBQ0YsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNwQixNQUFNO1NBQ2I7UUFDRCxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ1Y7SUFDRCxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQztDQUMvQjs7Ozs7OztBQU9ELFNBQVMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFO0lBQ3ZCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN4QixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNwQixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNwQixNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3hCLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDaEIsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUN0QixNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUMxQixNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNoQyxNQUFNLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2xCLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNsQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbEMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2xDLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO0NBQ2pEOzs7Ozs7O0FBT0QsU0FBUyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsVUFBVSxFQUFFO0lBQ25DLE1BQU0sR0FBRyxHQUFHO1FBQ1IsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDbkMsQ0FBQzs7SUFFRixJQUFJLFVBQVU7UUFDVixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3JDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDckMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFO1FBQ3ZDLE9BQU8sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDakU7SUFDRCxPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7Q0FDdkI7Ozs7Ozs7QUFPRCxTQUFTLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsVUFBVSxFQUFFO0lBQ3ZDLE1BQU0sR0FBRyxHQUFHO1FBQ1IsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQy9CLENBQUM7O0lBRUYsSUFBSSxVQUFVO1FBQ1YsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNyQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3JDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDckMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFO1FBQ3ZDLE9BQU8sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNwRjtJQUNELE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztDQUN2QjtBQUNELEFBYUE7QUFDQSxTQUFTLG1CQUFtQixDQUFDLENBQUMsRUFBRTtJQUM1QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztDQUN2RDs7QUFFRCxTQUFTLG1CQUFtQixDQUFDLENBQUMsRUFBRTtJQUM1QixPQUFPLGVBQWUsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7Q0FDbkM7O0FBRUQsU0FBUyxlQUFlLENBQUMsR0FBRyxFQUFFO0lBQzFCLE9BQU8sUUFBUSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztDQUM1Qjs7Ozs7O0FBTUQsTUFBTSxLQUFLLEdBQUc7SUFDVixTQUFTLEVBQUUsU0FBUztJQUNwQixZQUFZLEVBQUUsU0FBUztJQUN2QixJQUFJLEVBQUUsU0FBUztJQUNmLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLEtBQUssRUFBRSxTQUFTO0lBQ2hCLEtBQUssRUFBRSxTQUFTO0lBQ2hCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLEtBQUssRUFBRSxTQUFTO0lBQ2hCLGNBQWMsRUFBRSxTQUFTO0lBQ3pCLElBQUksRUFBRSxTQUFTO0lBQ2YsVUFBVSxFQUFFLFNBQVM7SUFDckIsS0FBSyxFQUFFLFNBQVM7SUFDaEIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsVUFBVSxFQUFFLFNBQVM7SUFDckIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsS0FBSyxFQUFFLFNBQVM7SUFDaEIsY0FBYyxFQUFFLFNBQVM7SUFDekIsUUFBUSxFQUFFLFNBQVM7SUFDbkIsT0FBTyxFQUFFLFNBQVM7SUFDbEIsSUFBSSxFQUFFLFNBQVM7SUFDZixRQUFRLEVBQUUsU0FBUztJQUNuQixRQUFRLEVBQUUsU0FBUztJQUNuQixhQUFhLEVBQUUsU0FBUztJQUN4QixRQUFRLEVBQUUsU0FBUztJQUNuQixTQUFTLEVBQUUsU0FBUztJQUNwQixRQUFRLEVBQUUsU0FBUztJQUNuQixTQUFTLEVBQUUsU0FBUztJQUNwQixXQUFXLEVBQUUsU0FBUztJQUN0QixjQUFjLEVBQUUsU0FBUztJQUN6QixVQUFVLEVBQUUsU0FBUztJQUNyQixVQUFVLEVBQUUsU0FBUztJQUNyQixPQUFPLEVBQUUsU0FBUztJQUNsQixVQUFVLEVBQUUsU0FBUztJQUNyQixZQUFZLEVBQUUsU0FBUztJQUN2QixhQUFhLEVBQUUsU0FBUztJQUN4QixhQUFhLEVBQUUsU0FBUztJQUN4QixhQUFhLEVBQUUsU0FBUztJQUN4QixhQUFhLEVBQUUsU0FBUztJQUN4QixVQUFVLEVBQUUsU0FBUztJQUNyQixRQUFRLEVBQUUsU0FBUztJQUNuQixXQUFXLEVBQUUsU0FBUztJQUN0QixPQUFPLEVBQUUsU0FBUztJQUNsQixPQUFPLEVBQUUsU0FBUztJQUNsQixVQUFVLEVBQUUsU0FBUztJQUNyQixTQUFTLEVBQUUsU0FBUztJQUNwQixXQUFXLEVBQUUsU0FBUztJQUN0QixXQUFXLEVBQUUsU0FBUztJQUN0QixPQUFPLEVBQUUsU0FBUztJQUNsQixTQUFTLEVBQUUsU0FBUztJQUNwQixVQUFVLEVBQUUsU0FBUztJQUNyQixJQUFJLEVBQUUsU0FBUztJQUNmLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLElBQUksRUFBRSxTQUFTO0lBQ2YsS0FBSyxFQUFFLFNBQVM7SUFDaEIsV0FBVyxFQUFFLFNBQVM7SUFDdEIsSUFBSSxFQUFFLFNBQVM7SUFDZixRQUFRLEVBQUUsU0FBUztJQUNuQixPQUFPLEVBQUUsU0FBUztJQUNsQixTQUFTLEVBQUUsU0FBUztJQUNwQixNQUFNLEVBQUUsU0FBUztJQUNqQixLQUFLLEVBQUUsU0FBUztJQUNoQixLQUFLLEVBQUUsU0FBUztJQUNoQixRQUFRLEVBQUUsU0FBUztJQUNuQixhQUFhLEVBQUUsU0FBUztJQUN4QixTQUFTLEVBQUUsU0FBUztJQUNwQixZQUFZLEVBQUUsU0FBUztJQUN2QixTQUFTLEVBQUUsU0FBUztJQUNwQixVQUFVLEVBQUUsU0FBUztJQUNyQixTQUFTLEVBQUUsU0FBUztJQUNwQixvQkFBb0IsRUFBRSxTQUFTO0lBQy9CLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLGFBQWEsRUFBRSxTQUFTO0lBQ3hCLFlBQVksRUFBRSxTQUFTO0lBQ3ZCLGNBQWMsRUFBRSxTQUFTO0lBQ3pCLGNBQWMsRUFBRSxTQUFTO0lBQ3pCLGNBQWMsRUFBRSxTQUFTO0lBQ3pCLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLElBQUksRUFBRSxTQUFTO0lBQ2YsU0FBUyxFQUFFLFNBQVM7SUFDcEIsS0FBSyxFQUFFLFNBQVM7SUFDaEIsT0FBTyxFQUFFLFNBQVM7SUFDbEIsTUFBTSxFQUFFLFNBQVM7SUFDakIsZ0JBQWdCLEVBQUUsU0FBUztJQUMzQixVQUFVLEVBQUUsU0FBUztJQUNyQixZQUFZLEVBQUUsU0FBUztJQUN2QixZQUFZLEVBQUUsU0FBUztJQUN2QixjQUFjLEVBQUUsU0FBUztJQUN6QixlQUFlLEVBQUUsU0FBUztJQUMxQixpQkFBaUIsRUFBRSxTQUFTO0lBQzVCLGVBQWUsRUFBRSxTQUFTO0lBQzFCLGVBQWUsRUFBRSxTQUFTO0lBQzFCLFlBQVksRUFBRSxTQUFTO0lBQ3ZCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFFBQVEsRUFBRSxTQUFTO0lBQ25CLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLElBQUksRUFBRSxTQUFTO0lBQ2YsT0FBTyxFQUFFLFNBQVM7SUFDbEIsS0FBSyxFQUFFLFNBQVM7SUFDaEIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsTUFBTSxFQUFFLFNBQVM7SUFDakIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsTUFBTSxFQUFFLFNBQVM7SUFDakIsYUFBYSxFQUFFLFNBQVM7SUFDeEIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsYUFBYSxFQUFFLFNBQVM7SUFDeEIsYUFBYSxFQUFFLFNBQVM7SUFDeEIsVUFBVSxFQUFFLFNBQVM7SUFDckIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsSUFBSSxFQUFFLFNBQVM7SUFDZixJQUFJLEVBQUUsU0FBUztJQUNmLElBQUksRUFBRSxTQUFTO0lBQ2YsVUFBVSxFQUFFLFNBQVM7SUFDckIsTUFBTSxFQUFFLFNBQVM7SUFDakIsYUFBYSxFQUFFLFNBQVM7SUFDeEIsR0FBRyxFQUFFLFNBQVM7SUFDZCxTQUFTLEVBQUUsU0FBUztJQUNwQixTQUFTLEVBQUUsU0FBUztJQUNwQixXQUFXLEVBQUUsU0FBUztJQUN0QixNQUFNLEVBQUUsU0FBUztJQUNqQixVQUFVLEVBQUUsU0FBUztJQUNyQixRQUFRLEVBQUUsU0FBUztJQUNuQixRQUFRLEVBQUUsU0FBUztJQUNuQixNQUFNLEVBQUUsU0FBUztJQUNqQixNQUFNLEVBQUUsU0FBUztJQUNqQixPQUFPLEVBQUUsU0FBUztJQUNsQixTQUFTLEVBQUUsU0FBUztJQUNwQixTQUFTLEVBQUUsU0FBUztJQUNwQixTQUFTLEVBQUUsU0FBUztJQUNwQixJQUFJLEVBQUUsU0FBUztJQUNmLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLEdBQUcsRUFBRSxTQUFTO0lBQ2QsSUFBSSxFQUFFLFNBQVM7SUFDZixPQUFPLEVBQUUsU0FBUztJQUNsQixNQUFNLEVBQUUsU0FBUztJQUNqQixTQUFTLEVBQUUsU0FBUztJQUNwQixNQUFNLEVBQUUsU0FBUztJQUNqQixLQUFLLEVBQUUsU0FBUztJQUNoQixLQUFLLEVBQUUsU0FBUztJQUNoQixVQUFVLEVBQUUsU0FBUztJQUNyQixNQUFNLEVBQUUsU0FBUztJQUNqQixXQUFXLEVBQUUsU0FBUztDQUN6QixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW9CRixTQUFTLFVBQVUsQ0FBQyxLQUFLLEVBQUU7SUFDdkIsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDO0lBQy9CLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNWLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQztJQUNiLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQztJQUNiLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQztJQUNiLElBQUksRUFBRSxHQUFHLEtBQUssQ0FBQztJQUNmLElBQUksTUFBTSxHQUFHLEtBQUssQ0FBQztJQUNuQixJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRTtRQUMzQixLQUFLLEdBQUcsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDdEM7SUFDRCxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRTtRQUMzQixJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQy9FLEdBQUcsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxQyxFQUFFLEdBQUcsSUFBSSxDQUFDO1lBQ1YsTUFBTSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLE1BQU0sR0FBRyxLQUFLLENBQUM7U0FDaEU7YUFDSSxJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3BGLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakMsQ0FBQyxHQUFHLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNqQyxHQUFHLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzlCLEVBQUUsR0FBRyxJQUFJLENBQUM7WUFDVixNQUFNLEdBQUcsS0FBSyxDQUFDO1NBQ2xCO2FBQ0ksSUFBSSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNwRixDQUFDLEdBQUcsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2pDLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUM5QixFQUFFLEdBQUcsSUFBSSxDQUFDO1lBQ1YsTUFBTSxHQUFHLEtBQUssQ0FBQztTQUNsQjtRQUNELElBQUksS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUMzQixDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQztTQUNmO0tBQ0o7SUFDRCxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2xCLE9BQU87UUFDSCxFQUFFO1FBQ0YsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNLElBQUksTUFBTTtRQUM5QixDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BDLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNwQyxDQUFDO0tBQ0osQ0FBQztDQUNMOztBQUVELE1BQU0sV0FBVyxHQUFHLGVBQWUsQ0FBQzs7QUFFcEMsTUFBTSxVQUFVLEdBQUcsc0JBQXNCLENBQUM7O0FBRTFDLE1BQU0sUUFBUSxHQUFHLENBQUMsR0FBRyxFQUFFLFVBQVUsQ0FBQyxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7O0FBSXhELE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxXQUFXLEVBQUUsUUFBUSxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUN0RyxNQUFNLGlCQUFpQixHQUFHLENBQUMsV0FBVyxFQUFFLFFBQVEsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUMzSCxNQUFNLFFBQVEsR0FBRztJQUNiLFFBQVEsRUFBRSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUM7SUFDOUIsR0FBRyxFQUFFLElBQUksTUFBTSxDQUFDLEtBQUssR0FBRyxpQkFBaUIsQ0FBQztJQUMxQyxJQUFJLEVBQUUsSUFBSSxNQUFNLENBQUMsTUFBTSxHQUFHLGlCQUFpQixDQUFDO0lBQzVDLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQyxLQUFLLEdBQUcsaUJBQWlCLENBQUM7SUFDMUMsSUFBSSxFQUFFLElBQUksTUFBTSxDQUFDLE1BQU0sR0FBRyxpQkFBaUIsQ0FBQztJQUM1QyxHQUFHLEVBQUUsSUFBSSxNQUFNLENBQUMsS0FBSyxHQUFHLGlCQUFpQixDQUFDO0lBQzFDLElBQUksRUFBRSxJQUFJLE1BQU0sQ0FBQyxNQUFNLEdBQUcsaUJBQWlCLENBQUM7SUFDNUMsSUFBSSxFQUFFLHNEQUFzRDtJQUM1RCxJQUFJLEVBQUUsc0RBQXNEO0lBQzVELElBQUksRUFBRSxzRUFBc0U7SUFDNUUsSUFBSSxFQUFFLHNFQUFzRTtDQUMvRSxDQUFDOzs7OztBQUtGLFNBQVMsbUJBQW1CLENBQUMsS0FBSyxFQUFFO0lBQ2hDLEtBQUssR0FBRyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDbkMsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtRQUNwQixPQUFPLEtBQUssQ0FBQztLQUNoQjtJQUNELElBQUksS0FBSyxHQUFHLEtBQUssQ0FBQztJQUNsQixJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUNkLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDckIsS0FBSyxHQUFHLElBQUksQ0FBQztLQUNoQjtTQUNJLElBQUksS0FBSyxLQUFLLGFBQWEsRUFBRTtRQUM5QixPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLENBQUM7S0FDckQ7Ozs7O0lBS0QsSUFBSSxLQUFLLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDckMsSUFBSSxLQUFLLEVBQUU7UUFDUCxPQUFPLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUNwRDtJQUNELEtBQUssR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNsQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7S0FDakU7SUFDRCxLQUFLLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDakMsSUFBSSxLQUFLLEVBQUU7UUFDUCxPQUFPLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUNwRDtJQUNELEtBQUssR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNsQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7S0FDakU7SUFDRCxLQUFLLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDakMsSUFBSSxLQUFLLEVBQUU7UUFDUCxPQUFPLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUNwRDtJQUNELEtBQUssR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNsQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7S0FDakU7SUFDRCxLQUFLLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDbEMsSUFBSSxLQUFLLEVBQUU7UUFDUCxPQUFPO1lBQ0gsQ0FBQyxFQUFFLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDNUIsQ0FBQyxFQUFFLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDNUIsQ0FBQyxFQUFFLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDNUIsQ0FBQyxFQUFFLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNoQyxNQUFNLEVBQUUsS0FBSyxHQUFHLE1BQU0sR0FBRyxNQUFNO1NBQ2xDLENBQUM7S0FDTDtJQUNELEtBQUssR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNsQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU87WUFDSCxDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QixDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QixDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QixNQUFNLEVBQUUsS0FBSyxHQUFHLE1BQU0sR0FBRyxLQUFLO1NBQ2pDLENBQUM7S0FDTDtJQUNELEtBQUssR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNsQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU87WUFDSCxDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdkMsQ0FBQyxFQUFFLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZDLENBQUMsRUFBRSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2QyxDQUFDLEVBQUUsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMzQyxNQUFNLEVBQUUsS0FBSyxHQUFHLE1BQU0sR0FBRyxNQUFNO1NBQ2xDLENBQUM7S0FDTDtJQUNELEtBQUssR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNsQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU87WUFDSCxDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdkMsQ0FBQyxFQUFFLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZDLENBQUMsRUFBRSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2QyxNQUFNLEVBQUUsS0FBSyxHQUFHLE1BQU0sR0FBRyxLQUFLO1NBQ2pDLENBQUM7S0FDTDtJQUNELE9BQU8sS0FBSyxDQUFDO0NBQ2hCOzs7OztBQUtELFNBQVMsY0FBYyxDQUFDLEtBQUssRUFBRTtJQUMzQixPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztDQUNsRDs7QUFFRCxNQUFNLFNBQVMsQ0FBQztJQUNaLFdBQVcsQ0FBQyxLQUFLLEdBQUcsRUFBRSxFQUFFLElBQUksR0FBRyxFQUFFLEVBQUU7O1FBRS9CLElBQUksS0FBSyxZQUFZLFNBQVMsRUFBRTtZQUM1QixPQUFPLEtBQUssQ0FBQztTQUNoQjtRQUNELElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBQzNCLE1BQU0sR0FBRyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM5QixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztRQUMzQixJQUFJLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDZixJQUFJLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDZixJQUFJLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDZixJQUFJLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDZixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7UUFDN0MsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUM7UUFDeEMsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDOzs7OztRQUt0QyxJQUFJLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ1osSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUMvQjtRQUNELElBQUksSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDWixJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQy9CO1FBQ0QsSUFBSSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNaLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDL0I7UUFDRCxJQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQyxFQUFFLENBQUM7S0FDekI7SUFDRCxNQUFNLEdBQUc7UUFDTCxPQUFPLElBQUksQ0FBQyxhQUFhLEVBQUUsR0FBRyxHQUFHLENBQUM7S0FDckM7SUFDRCxPQUFPLEdBQUc7UUFDTixPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO0tBQ3pCOzs7O0lBSUQsYUFBYSxHQUFHOztRQUVaLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN6QixPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksSUFBSSxDQUFDO0tBQzNEOzs7O0lBSUQsWUFBWSxHQUFHOztRQUVYLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsQ0FBQztRQUNOLElBQUksQ0FBQyxDQUFDO1FBQ04sSUFBSSxDQUFDLENBQUM7UUFDTixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUMxQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUMxQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUMxQixJQUFJLEtBQUssSUFBSSxPQUFPLEVBQUU7WUFDbEIsQ0FBQyxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUM7U0FDckI7YUFDSTtZQUNELENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLEtBQUssSUFBSSxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUM7U0FDOUM7UUFDRCxJQUFJLEtBQUssSUFBSSxPQUFPLEVBQUU7WUFDbEIsQ0FBQyxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUM7U0FDckI7YUFDSTtZQUNELENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLEtBQUssSUFBSSxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUM7U0FDOUM7UUFDRCxJQUFJLEtBQUssSUFBSSxPQUFPLEVBQUU7WUFDbEIsQ0FBQyxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUM7U0FDckI7YUFDSTtZQUNELENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLEtBQUssSUFBSSxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUM7U0FDOUM7UUFDRCxPQUFPLE1BQU0sR0FBRyxDQUFDLEdBQUcsTUFBTSxHQUFHLENBQUMsR0FBRyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0tBQy9DOzs7Ozs7SUFNRCxRQUFRLENBQUMsS0FBSyxFQUFFO1FBQ1osSUFBSSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDM0IsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1FBQzdDLE9BQU8sSUFBSSxDQUFDO0tBQ2Y7Ozs7SUFJRCxLQUFLLEdBQUc7UUFDSixNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QyxPQUFPLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUM7S0FDNUQ7Ozs7O0lBS0QsV0FBVyxHQUFHO1FBQ1YsTUFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0MsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ2xDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUNsQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDbEMsT0FBTyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDaEc7Ozs7SUFJRCxLQUFLLEdBQUc7UUFDSixNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QyxPQUFPLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUM7S0FDNUQ7Ozs7O0lBS0QsV0FBVyxHQUFHO1FBQ1YsTUFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0MsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ2xDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUNsQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDbEMsT0FBTyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDaEc7Ozs7O0lBS0QsS0FBSyxDQUFDLFVBQVUsR0FBRyxLQUFLLEVBQUU7UUFDdEIsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7S0FDdkQ7Ozs7O0lBS0QsV0FBVyxDQUFDLFVBQVUsR0FBRyxLQUFLLEVBQUU7UUFDNUIsT0FBTyxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQztLQUN2Qzs7Ozs7SUFLRCxNQUFNLENBQUMsVUFBVSxHQUFHLEtBQUssRUFBRTtRQUN2QixPQUFPLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0tBQ2hFOzs7OztJQUtELFlBQVksQ0FBQyxVQUFVLEdBQUcsS0FBSyxFQUFFO1FBQzdCLE9BQU8sR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7S0FDeEM7Ozs7SUFJRCxLQUFLLEdBQUc7UUFDSixPQUFPO1lBQ0gsQ0FBQyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUNyQixDQUFDLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ3JCLENBQUMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDckIsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ1osQ0FBQztLQUNMOzs7OztJQUtELFdBQVcsR0FBRztRQUNWLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzdCLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzdCLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzdCLE9BQU8sSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQzVGOzs7O0lBSUQsZUFBZSxHQUFHO1FBQ2QsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUMzRCxPQUFPO1lBQ0gsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ2QsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ2QsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ2QsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ1osQ0FBQztLQUNMOzs7O0lBSUQscUJBQXFCLEdBQUc7UUFDcEIsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ3JELE9BQU8sSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDO2NBQ2IsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7Y0FDeEQsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNuRjs7OztJQUlELE1BQU0sR0FBRztRQUNMLElBQUksSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZCxPQUFPLGFBQWEsQ0FBQztTQUN4QjtRQUNELElBQUksSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDWixPQUFPLEtBQUssQ0FBQztTQUNoQjtRQUNELE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDMUQsS0FBSyxNQUFNLEdBQUcsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2xDLElBQUksS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEdBQUcsRUFBRTtnQkFDcEIsT0FBTyxHQUFHLENBQUM7YUFDZDtTQUNKO1FBQ0QsT0FBTyxLQUFLLENBQUM7S0FDaEI7Ozs7OztJQU1ELFFBQVEsQ0FBQyxNQUFNLEVBQUU7UUFDYixNQUFNLFNBQVMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQzNCLE1BQU0sR0FBRyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUMvQixJQUFJLGVBQWUsR0FBRyxLQUFLLENBQUM7UUFDNUIsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDM0MsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLFNBQVMsSUFBSSxRQUFRLEtBQUssTUFBTSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxNQUFNLEtBQUssTUFBTSxDQUFDLENBQUM7UUFDbkcsSUFBSSxnQkFBZ0IsRUFBRTs7O1lBR2xCLElBQUksTUFBTSxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDbkMsT0FBTyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDeEI7WUFDRCxPQUFPLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUM3QjtRQUNELElBQUksTUFBTSxLQUFLLEtBQUssRUFBRTtZQUNsQixlQUFlLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3hDO1FBQ0QsSUFBSSxNQUFNLEtBQUssTUFBTSxFQUFFO1lBQ25CLGVBQWUsR0FBRyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztTQUNsRDtRQUNELElBQUksTUFBTSxLQUFLLEtBQUssSUFBSSxNQUFNLEtBQUssTUFBTSxFQUFFO1lBQ3ZDLGVBQWUsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDeEM7UUFDRCxJQUFJLE1BQU0sS0FBSyxNQUFNLEVBQUU7WUFDbkIsZUFBZSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDNUM7UUFDRCxJQUFJLE1BQU0sS0FBSyxNQUFNLEVBQUU7WUFDbkIsZUFBZSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDN0M7UUFDRCxJQUFJLE1BQU0sS0FBSyxNQUFNLEVBQUU7WUFDbkIsZUFBZSxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztTQUN6QztRQUNELElBQUksTUFBTSxLQUFLLE1BQU0sRUFBRTtZQUNuQixlQUFlLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1NBQ25DO1FBQ0QsSUFBSSxNQUFNLEtBQUssS0FBSyxFQUFFO1lBQ2xCLGVBQWUsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDeEM7UUFDRCxJQUFJLE1BQU0sS0FBSyxLQUFLLEVBQUU7WUFDbEIsZUFBZSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUN4QztRQUNELE9BQU8sZUFBZSxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztLQUNoRDtJQUNELEtBQUssR0FBRztRQUNKLE9BQU8sSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7S0FDekM7Ozs7O0lBS0QsT0FBTyxDQUFDLE1BQU0sR0FBRyxFQUFFLEVBQUU7UUFDakIsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLEdBQUcsQ0FBQyxDQUFDLElBQUksTUFBTSxHQUFHLEdBQUcsQ0FBQztRQUN0QixHQUFHLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdkIsT0FBTyxJQUFJLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUM3Qjs7Ozs7SUFLRCxRQUFRLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRTtRQUNsQixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDekIsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEVBQUUsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzlFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxFQUFFLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM5RSxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsRUFBRSxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDOUUsT0FBTyxJQUFJLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUM3Qjs7Ozs7O0lBTUQsTUFBTSxDQUFDLE1BQU0sR0FBRyxFQUFFLEVBQUU7UUFDaEIsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLEdBQUcsQ0FBQyxDQUFDLElBQUksTUFBTSxHQUFHLEdBQUcsQ0FBQztRQUN0QixHQUFHLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdkIsT0FBTyxJQUFJLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUM3Qjs7Ozs7O0lBTUQsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLEVBQUU7UUFDZCxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0tBQ3BDOzs7Ozs7SUFNRCxLQUFLLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRTtRQUNmLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUM7S0FDcEM7Ozs7OztJQU1ELFVBQVUsQ0FBQyxNQUFNLEdBQUcsRUFBRSxFQUFFO1FBQ3BCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN6QixHQUFHLENBQUMsQ0FBQyxJQUFJLE1BQU0sR0FBRyxHQUFHLENBQUM7UUFDdEIsR0FBRyxDQUFDLENBQUMsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZCLE9BQU8sSUFBSSxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDN0I7Ozs7O0lBS0QsUUFBUSxDQUFDLE1BQU0sR0FBRyxFQUFFLEVBQUU7UUFDbEIsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLEdBQUcsQ0FBQyxDQUFDLElBQUksTUFBTSxHQUFHLEdBQUcsQ0FBQztRQUN0QixHQUFHLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdkIsT0FBTyxJQUFJLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUM3Qjs7Ozs7SUFLRCxTQUFTLEdBQUc7UUFDUixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDL0I7Ozs7O0lBS0QsSUFBSSxDQUFDLE1BQU0sRUFBRTtRQUNULE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN6QixNQUFNLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsTUFBTSxJQUFJLEdBQUcsQ0FBQztRQUNuQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7UUFDbEMsT0FBTyxJQUFJLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUM3QjtJQUNELEdBQUcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxHQUFHLEVBQUUsRUFBRTtRQUNwQixNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDMUIsTUFBTSxJQUFJLEdBQUcsSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDMUMsTUFBTSxDQUFDLEdBQUcsTUFBTSxHQUFHLEdBQUcsQ0FBQztRQUN2QixNQUFNLElBQUksR0FBRztZQUNULENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7WUFDakMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztZQUNqQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1lBQ2pDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7U0FDcEMsQ0FBQztRQUNGLE9BQU8sSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDOUI7SUFDRCxTQUFTLENBQUMsT0FBTyxHQUFHLENBQUMsRUFBRSxNQUFNLEdBQUcsRUFBRSxFQUFFO1FBQ2hDLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN6QixNQUFNLElBQUksR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDO1FBQzFCLE1BQU0sR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbkIsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxPQUFPLEtBQUssQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLEdBQUcsRUFBRSxFQUFFLE9BQU8sR0FBRztZQUNwRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLElBQUksR0FBRyxDQUFDO1lBQzdCLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUNoQztRQUNELE9BQU8sR0FBRyxDQUFDO0tBQ2Q7Ozs7SUFJRCxVQUFVLEdBQUc7UUFDVCxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDekIsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLEdBQUcsQ0FBQztRQUM1QixPQUFPLElBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQzdCO0lBQ0QsYUFBYSxDQUFDLE9BQU8sR0FBRyxDQUFDLEVBQUU7UUFDdkIsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDaEIsTUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNoQixJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ2QsTUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDO1FBQ2YsTUFBTSxZQUFZLEdBQUcsQ0FBQyxHQUFHLE9BQU8sQ0FBQztRQUNqQyxPQUFPLE9BQU8sRUFBRSxFQUFFO1lBQ2QsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3JDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxZQUFZLElBQUksQ0FBQyxDQUFDO1NBQzlCO1FBQ0QsT0FBTyxHQUFHLENBQUM7S0FDZDtJQUNELGVBQWUsR0FBRztRQUNkLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN6QixNQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ2hCLE9BQU87WUFDSCxJQUFJO1lBQ0osSUFBSSxTQUFTLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLEdBQUcsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQ3hELElBQUksU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQztTQUM1RCxDQUFDO0tBQ0w7SUFDRCxLQUFLLEdBQUc7UUFDSixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDekI7SUFDRCxNQUFNLEdBQUc7UUFDTCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDekI7Ozs7O0lBS0QsTUFBTSxDQUFDLENBQUMsRUFBRTtRQUNOLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN6QixNQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ2hCLE1BQU0sTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEIsTUFBTSxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUMxQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxTQUFTLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFNBQVMsSUFBSSxHQUFHLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDcEY7UUFDRCxPQUFPLE1BQU0sQ0FBQztLQUNqQjs7OztJQUlELE1BQU0sQ0FBQyxLQUFLLEVBQUU7UUFDVixPQUFPLElBQUksQ0FBQyxXQUFXLEVBQUUsS0FBSyxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztLQUNwRTtDQUNKOzs7Ozs7Ozs7O0FBVUQsU0FBUyxXQUFXLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRTtJQUNqQyxNQUFNLEVBQUUsR0FBRyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNqQyxNQUFNLEVBQUUsR0FBRyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNqQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsWUFBWSxFQUFFLEVBQUUsRUFBRSxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsSUFBSTtTQUN6RCxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxZQUFZLEVBQUUsRUFBRSxFQUFFLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsRUFBRTtDQUNoRTs7Ozs7Ozs7Ozs7Ozs7QUFjRCxTQUFTLFVBQVUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLEtBQUssR0FBRyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxFQUFFO0lBQ3hFLE1BQU0sZ0JBQWdCLEdBQUcsV0FBVyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztJQUNyRCxRQUFRLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSyxDQUFDLElBQUksSUFBSSxPQUFPLENBQUM7UUFDbkQsS0FBSyxTQUFTLENBQUM7UUFDZixLQUFLLFVBQVU7WUFDWCxPQUFPLGdCQUFnQixJQUFJLEdBQUcsQ0FBQztRQUNuQyxLQUFLLFNBQVM7WUFDVixPQUFPLGdCQUFnQixJQUFJLENBQUMsQ0FBQztRQUNqQyxLQUFLLFVBQVU7WUFDWCxPQUFPLGdCQUFnQixJQUFJLENBQUMsQ0FBQztLQUNwQztJQUNELE9BQU8sS0FBSyxDQUFDO0NBQ2hCOztBQ3hrQ0QsTUFBTUMsT0FBSyxHQUFHO0VBQ1osTUFBTSxFQUFFO0lBQ04sR0FBRyxHQUFHLElBQUk7SUFDVixNQUFNLEVBQUUsSUFBSTtHQUNiO0VBQ0QsSUFBSSxFQUFFLElBQUksR0FBRyxFQUFFO0VBQ2hCOztBQUVELE1BQU0sUUFBUSxHQUFHLEdBQUU7O0FBRW5CLEFBQU8sU0FBUyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRTtFQUNoQyxRQUFRLENBQUMsU0FBUyxHQUFHLENBQUMsTUFBTSxFQUFDOztFQUU3QixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUM7RUFDcEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsWUFBWSxFQUFDOztFQUVuQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUMsSUFBSSxTQUFTLEVBQUUsRUFBQzs7RUFFaEMsaUJBQWlCLEdBQUU7O0VBRW5CLE9BQU8sTUFBTTtJQUNYLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBQztJQUNyQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUM7SUFDcEMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUM7SUFDckIsT0FBTyxHQUFFO0dBQ1Y7Q0FDRjs7QUFFRCxNQUFNLFNBQVMsR0FBRyxDQUFDLElBQUk7RUFDckIsTUFBTSxNQUFNLEdBQUcsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsT0FBTyxFQUFDOztFQUV6RCxJQUFJLFdBQVcsQ0FBQyxNQUFNLENBQUMsSUFBSSxNQUFNLENBQUMsUUFBUSxLQUFLLGdCQUFnQixJQUFJLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLEVBQUU7SUFDdEcsSUFBSUEsT0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUU7TUFDcEIsSUFBSSxDQUFDO1FBQ0gsR0FBRyxFQUFFQSxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUc7UUFDckIsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFQSxPQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztPQUNqQyxFQUFDO01BQ0YsV0FBVyxHQUFFO0tBQ2Q7SUFDRCxNQUFNO0dBQ1A7O0VBRUQsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUM7O0VBRXBDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFDO0VBQ25COztBQUVELEFBQU8sU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRTtFQUNqQyxJQUFJLENBQUNBLE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFO0lBQ3JCLE1BQU0sR0FBRyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUM7SUFDMUIsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFDOztJQUU5QixXQUFXLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBQztJQUNuQixPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLEVBQUM7O0lBRXRCQSxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsTUFBTSxJQUFHO0lBQ3pCQSxPQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxPQUFNO0dBQzdCO09BQ0ksSUFBSSxNQUFNLElBQUlBLE9BQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFOztJQUV0QyxXQUFXLENBQUNBLE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBQztHQUNqQztPQUNJO0lBQ0gsTUFBTSxDQUFDLE1BQU0sRUFBRUEsT0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUM7SUFDaENBLE9BQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLE9BQU07SUFDNUIsV0FBVyxDQUFDQSxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUM7R0FDakM7Q0FDRjs7QUFFRCxBQUFPLFNBQVMsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUU7RUFDbEMsTUFBTSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxjQUFjLENBQUMsQ0FBQyxFQUFDO0VBQ3pDLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBQzs7RUFFekQsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLElBQUksS0FBSTtFQUN0QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsS0FBSyxJQUFHOztFQUVyQixHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsS0FBSztNQUNsQyxpQkFBaUI7TUFDakIsbUJBQW1CLEVBQUM7O0VBRXhCLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLG9CQUFvQixFQUFFLEtBQUs7TUFDN0Msa0JBQWtCO01BQ2xCLG9CQUFvQixFQUFDOztFQUV6QixHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxLQUFLO01BQ3ZDLE1BQU07TUFDTixrQkFBa0IsRUFBQzs7RUFFdkIsR0FBRyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsY0FBYyxFQUFFLElBQUk7TUFDdEMsMEJBQTBCO01BQzFCLE1BQU0sRUFBQztDQUNaOztBQUVELE1BQU0saUJBQWlCLEdBQUcsTUFBTTtFQUM5QkEsT0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLE1BQU0sS0FBSztJQUNwQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxRQUFPO0lBQzNCLE1BQU0sQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFDO0lBQ25CLE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsRUFBQztHQUN2QixFQUFDO0VBQ0g7O0FBRUQsQUFBTyxTQUFTLE9BQU8sR0FBRztFQUN4QkEsT0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLE1BQU07SUFDL0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTSxFQUFDOztFQUU3QixJQUFJQSxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRTtJQUNwQkEsT0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFFO0lBQ3pCLFdBQVcsR0FBRTtHQUNkO0NBQ0Y7O0FBRUQsQUFBTyxTQUFTLFNBQVMsR0FBRztFQUMxQkEsT0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLE1BQU0sS0FBSztJQUNwQyxHQUFHLENBQUMsTUFBTSxHQUFFO0lBQ1osU0FBUyxDQUFDLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFDO0dBQ3pCLEVBQUM7O0VBRUYsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLEVBQUM7O0VBRTlDQSxPQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRTtDQUNuQjs7QUFFRCxNQUFNLE1BQU0sR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLO0VBQ3JFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRSxDQUFDLHFCQUFxQixHQUFFO0VBQ3BELE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUM7S0FDekIsR0FBRyxDQUFDLEtBQUssSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtNQUNqQyxJQUFJLEVBQUUsV0FBVyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7S0FDOUIsQ0FBQyxDQUFDO0tBQ0YsTUFBTSxDQUFDLEtBQUs7TUFDWCxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUM7VUFDOUIsRUFBRSxDQUFDLE9BQU8sQ0FBQyx3RUFBd0UsQ0FBQztVQUNwRixJQUFJO0tBQ1Q7S0FDQSxHQUFHLENBQUMsS0FBSyxJQUFJO01BQ1osSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUM7UUFDOUgsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLG9DQUFvQyxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxFQUFDOztNQUV6SCxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLEVBQUU7UUFDL0QsS0FBSyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBSzs7TUFFL0MsSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQztRQUM1QyxLQUFLLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUM7O01BRXJELElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsa0JBQWtCLENBQUM7UUFDekMsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLHlCQUF5QixFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUM7OztNQUc3SixJQUFJLEVBQUUsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztRQUMzRSxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUM7O01BRTFELE9BQU8sS0FBSztLQUNiLEVBQUM7O0VBRUosTUFBTSxrQkFBa0IsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUs7SUFDNUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO1FBQ3JFLENBQUM7UUFDRCxDQUFDLEVBQUM7O0VBRVIsTUFBTSxxQkFBcUIsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUs7SUFDL0MsRUFBRSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO1FBQ3JFLENBQUM7UUFDRCxDQUFDLEVBQUM7O0VBRVIsR0FBRyxDQUFDLElBQUksR0FBRztJQUNULEVBQUU7SUFDRixLQUFLO0lBQ0wsTUFBTTtJQUNOLGtCQUFrQjtJQUNsQixxQkFBcUI7SUFDdEI7O0VBRUQsT0FBTyxHQUFHO0VBQ1g7O0FBRUQsTUFBTSxjQUFjLEdBQUcsQ0FBQyxLQUFLO0VBQzNCLEtBQUssRUFBRSxDQUFDLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxXQUFXLEdBQUcsQ0FBQztFQUN6QyxJQUFJLEdBQUcsQ0FBQyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMsVUFBVSxHQUFHLENBQUM7Q0FDekMsRUFBQzs7QUFFRixNQUFNLFlBQVksR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksTUFBTTtFQUM5QyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEtBQUs7TUFDVCxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRTtNQUNoQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7RUFDcEIsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJO01BQ1QsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUU7TUFDL0IsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDO0NBQ3JCLEVBQUM7O0FBRUYsTUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0VBQy9CLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxJQUFJQSxPQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7SUFDaEUsSUFBSSxDQUFDQSxPQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBQztFQUMvQjs7QUFFRCxNQUFNLElBQUksR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUs7RUFDbEMsR0FBRyxDQUFDLE1BQU0sR0FBRTtFQUNaLFNBQVMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsRUFBQztFQUN4QkEsT0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFDO0VBQzFCOztBQUVELE1BQU0sWUFBWSxHQUFHLENBQUMsSUFBSTtFQUN4QixNQUFNLE1BQU0sR0FBRyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUM7O0VBRXpELElBQUksQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLEVBQUU7SUFDcEQsTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUUsSUFBSSxFQUFDO0lBQ3pDQSxPQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUU7TUFDckIsR0FBRyxFQUFFQSxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUc7TUFDckIsQ0FBQztLQUNGLEVBQUM7SUFDRixXQUFXLEdBQUU7R0FDZDtPQUNJLElBQUksTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsRUFBRTtJQUM1QyxNQUFNLENBQUMsZUFBZSxDQUFDLGNBQWMsRUFBQztJQUN0QyxJQUFJLENBQUNBLE9BQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFDO0dBQzdCO0VBQ0Y7O0FBRUQsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxDQUFDLEtBQUs7RUFDekQsSUFBSSxDQUFDLElBQUksRUFBRSxNQUFNOztFQUVqQixTQUFTLENBQUMsc0JBQXNCLEVBQUUsRUFBRTtJQUNsQyxFQUFFLENBQUMsZUFBZSxDQUFDLG9CQUFvQixDQUFDLEVBQUM7O0VBRTNDLFNBQVMsQ0FBQyxJQUFJLEdBQUcsdUJBQXVCLEVBQUUsRUFBRTtJQUMxQyxTQUFTLEtBQUssWUFBWTtRQUN0QixFQUFFLENBQUMsWUFBWSxDQUFDLG9CQUFvQixFQUFFLElBQUksQ0FBQztRQUMzQyxRQUFRLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBQztFQUNyQzs7QUFFRCxNQUFNLGlCQUFpQixHQUFHLENBQUMsSUFBSTtFQUM3QixTQUFTLENBQUMsc0JBQXNCLEVBQUUsRUFBRTtJQUNsQyxFQUFFLENBQUMsZUFBZSxDQUFDLG9CQUFvQixDQUFDLEVBQUM7RUFDNUM7O0FBRUQsTUFBTSxrQkFBa0IsR0FBRyxDQUFDLEdBQUcsRUFBRSxNQUFNO0VBQ3JDLEdBQUc7TUFDQyxNQUFNLENBQUMsWUFBWSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7TUFDMUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxlQUFlLEVBQUM7O0FBRTdDLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLEtBQUs7RUFDakMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUM7RUFDcEMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUUsaUJBQWlCLEVBQUM7RUFDdkMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRSxVQUFVLEVBQUM7RUFDM0M7O0FBRUQsTUFBTSxTQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsS0FBSztFQUNuQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsRUFBQztFQUNyQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxpQkFBaUIsRUFBQztFQUN4QyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLFVBQVUsRUFBQztFQUM1Qzs7QUFFRCxNQUFNLFdBQVcsR0FBRyxNQUFNO0VBQ3hCQSxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsTUFBTSxLQUFJO0VBQzFCQSxPQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxLQUFJO0NBQzNCOztBQzFQRCxNQUFNQSxPQUFLLEdBQUc7RUFDWixNQUFNLEVBQUU7SUFDTixHQUFHLEdBQUcsSUFBSTtJQUNWLE1BQU0sRUFBRSxJQUFJO0dBQ2I7RUFDRCxJQUFJLEVBQUUsSUFBSSxHQUFHLEVBQUU7RUFDaEI7O0FBRUQsQUFBTyxTQUFTLGFBQWEsR0FBRztFQUM5QixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRUMsV0FBUyxFQUFDO0VBQ3BDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFQyxjQUFZLEVBQUM7O0VBRW5DLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxJQUFJQyxXQUFTLEVBQUUsRUFBQzs7RUFFaENDLG1CQUFpQixHQUFFOztFQUVuQixPQUFPLE1BQU07SUFDWCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRUgsV0FBUyxFQUFDO0lBQ3JDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFQyxjQUFZLEVBQUM7SUFDcEMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUM7SUFDckJHLFNBQU8sR0FBRTtHQUNWO0NBQ0Y7O0FBRUQsTUFBTUosV0FBUyxHQUFHLENBQUMsSUFBSTtFQUNyQixNQUFNLE1BQU0sR0FBRyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUM7O0VBRXpELElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxRQUFRLEtBQUssZ0JBQWdCLElBQUksTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsRUFBRTtJQUN0RyxJQUFJRCxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRTtNQUNwQk0sTUFBSSxDQUFDO1FBQ0gsR0FBRyxFQUFFTixPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUc7UUFDckIsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFQSxPQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztPQUNqQyxFQUFDO01BQ0ZPLGFBQVcsR0FBRTtLQUNkO0lBQ0QsTUFBTTtHQUNQOztFQUVEQyxvQkFBa0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBQzs7RUFFcENDLFNBQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFDO0VBQ25COztBQUVELEFBQU8sU0FBU0EsU0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUU7RUFDakMsSUFBSSxDQUFDVCxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRTtJQUNyQixNQUFNLEdBQUcsR0FBR1UsUUFBTSxDQUFDLE1BQU0sRUFBQztJQUMxQixRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUM7O0lBRTlCQyxhQUFXLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBQztJQUNuQkMsU0FBTyxDQUFDLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFDOztJQUV0QlosT0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sSUFBRztJQUN6QkEsT0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsT0FBTTtHQUM3QjtPQUNJLElBQUksTUFBTSxJQUFJQSxPQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTs7SUFFdENXLGFBQVcsQ0FBQ1gsT0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFDO0dBQ2pDO09BQ0k7SUFDSFUsUUFBTSxDQUFDLE1BQU0sRUFBRVYsT0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUM7SUFDaENBLE9BQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLE9BQU07SUFDNUJXLGFBQVcsQ0FBQ1gsT0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFDO0dBQ2pDO0NBQ0Y7O0FBRUQsQUFBTyxTQUFTVyxhQUFXLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRTtFQUNsQyxNQUFNLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHRSxnQkFBYyxDQUFDLENBQUMsRUFBQztFQUN6QyxNQUFNLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxPQUFPQyxjQUFZLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFDOztFQUV6RCxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksSUFBSSxLQUFJO0VBQ3RCLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxLQUFLLElBQUc7O0VBRXJCLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxLQUFLO01BQ2xDLGlCQUFpQjtNQUNqQixtQkFBbUIsRUFBQzs7RUFFeEIsR0FBRyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsb0JBQW9CLEVBQUUsS0FBSztNQUM3QyxrQkFBa0I7TUFDbEIsb0JBQW9CLEVBQUM7O0VBRXpCLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLGFBQWEsRUFBRSxDQUFDLEtBQUs7TUFDdkMsTUFBTTtNQUNOLGtCQUFrQixFQUFDOztFQUV2QixHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxjQUFjLEVBQUUsSUFBSTtNQUN0QywwQkFBMEI7TUFDMUIsTUFBTSxFQUFDO0NBQ1o7O0FBRUQsTUFBTVYsbUJBQWlCLEdBQUcsTUFBTTtFQUM5QkosT0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLE1BQU0sS0FBSztJQUNwQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxRQUFPO0lBQzNCVSxRQUFNLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBQztJQUNuQkUsU0FBTyxDQUFDLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFDO0dBQ3ZCLEVBQUM7RUFDSDs7QUFFRCxBQUFPLFNBQVNQLFNBQU8sR0FBRztFQUN4QkwsT0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLE1BQU07SUFDL0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTSxFQUFDOztFQUU3QixJQUFJQSxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRTtJQUNwQkEsT0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFFO0lBQ3pCTyxhQUFXLEdBQUU7R0FDZDtDQUNGOztBQUVELEFBQU8sU0FBU0osV0FBUyxHQUFHO0VBQzFCSCxPQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTSxLQUFLO0lBQ3BDLEdBQUcsQ0FBQyxNQUFNLEdBQUU7SUFDWmUsV0FBUyxDQUFDLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFDO0dBQ3pCLEVBQUM7O0VBRUYsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLEVBQUM7O0VBRTlDZixPQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRTtDQUNuQjs7QUFFRCxNQUFNVSxRQUFNLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLEtBQUs7RUFDbEUsTUFBTSxnQkFBZ0IsR0FBRyxzQkFBc0IsQ0FBQyxFQUFFLEVBQUM7RUFDbkQsTUFBTSxlQUFlLEdBQUcsUUFBUSxDQUFDLEVBQUUsRUFBQzs7RUFFcEMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxJQUFJO0lBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztRQUNyQixJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1FBQzlDLElBQUksRUFBQzs7RUFFWCxlQUFlLENBQUMsR0FBRyxDQUFDLElBQUk7SUFDdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUN2RCxJQUFJLEVBQUM7O0VBRVgsR0FBRyxDQUFDLElBQUksR0FBRztJQUNULEVBQUU7SUFDRixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2pCOztFQUVELE9BQU8sR0FBRztFQUNYOztBQUVELE1BQU0sc0JBQXNCLEdBQUcsRUFBRSxJQUFJOzs7RUFHbkMsTUFBTSxJQUFJLFFBQVEsUUFBUSxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUM7RUFDdkMsTUFBTSxRQUFRLElBQUksZ0JBQWdCLENBQUMsRUFBRSxFQUFDOztFQUV0QyxJQUFJLFVBQVUsSUFBSSwwQkFBMEIsQ0FBQyxFQUFFLEVBQUM7O0VBRWhELE1BQU0sRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLEdBQUc7SUFDcEMsVUFBVSxDQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQztJQUMzRSxVQUFVLENBQUMsVUFBVSxFQUFFLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDO0lBQzdFOztFQUVELE9BQU8sQ0FBQzs7Ozt5QkFJZSxFQUFFLFVBQVUsQ0FBQztjQUN4QixFQUFFLElBQUksQ0FBQztRQUNiLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQzs7b0JBRTdDLEVBQUUsUUFBUSxDQUFDO3VCQUNSLEVBQUUsV0FBVyxHQUFHLGNBQWMsR0FBRyxXQUFXLENBQUMsRUFBRSxFQUFFLFdBQVcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO3FCQUMzRSxFQUFFLFFBQVEsQ0FBQzt1QkFDVCxFQUFFLFlBQVksR0FBRyxjQUFjLEdBQUcsV0FBVyxDQUFDLEVBQUUsRUFBRSxZQUFZLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUNoRyxDQUFDO0VBQ0Y7O0FBRUQsTUFBTUcsZ0JBQWMsR0FBRyxDQUFDLEtBQUs7RUFDM0IsS0FBSyxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLFdBQVcsR0FBRyxDQUFDO0VBQ3pDLElBQUksR0FBRyxDQUFDLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxVQUFVLEdBQUcsQ0FBQztDQUN6QyxFQUFDOztBQUVGLE1BQU1DLGNBQVksR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksTUFBTTtFQUM5QyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEtBQUs7TUFDVCxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRTtNQUNoQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7RUFDcEIsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJO01BQ1QsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUU7TUFDL0IsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDO0NBQ3JCLEVBQUM7O0FBRUYsTUFBTUUsWUFBVSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztFQUMvQixJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsSUFBSWhCLE9BQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztJQUNoRU0sTUFBSSxDQUFDTixPQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBQztFQUMvQjs7QUFFRCxNQUFNTSxNQUFJLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLO0VBQ2xDLEdBQUcsQ0FBQyxNQUFNLEdBQUU7RUFDWlMsV0FBUyxDQUFDLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxFQUFDO0VBQ3hCZixPQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUM7RUFDMUI7O0FBRUQsTUFBTUUsY0FBWSxHQUFHLENBQUMsSUFBSTtFQUN4QixNQUFNLE1BQU0sR0FBRyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUM7O0VBRXpELElBQUksQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLEVBQUU7SUFDcEQsTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUUsSUFBSSxFQUFDO0lBQ3pDRixPQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUU7TUFDckIsR0FBRyxFQUFFQSxPQUFLLENBQUMsTUFBTSxDQUFDLEdBQUc7TUFDckIsQ0FBQztLQUNGLEVBQUM7SUFDRk8sYUFBVyxHQUFFO0dBQ2Q7T0FDSSxJQUFJLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLEVBQUU7SUFDNUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxjQUFjLEVBQUM7SUFDdENELE1BQUksQ0FBQ04sT0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUM7R0FDN0I7RUFDRjs7QUFFRCxNQUFNUSxvQkFBa0IsR0FBRyxDQUFDLEdBQUcsRUFBRSxNQUFNO0VBQ3JDLEdBQUc7TUFDQyxNQUFNLENBQUMsWUFBWSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7TUFDMUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxlQUFlLEVBQUM7O0FBRTdDLE1BQU1JLFNBQU8sR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0VBQ2pDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsZ0JBQWdCLEVBQUVJLFlBQVUsRUFBQztFQUMzQzs7QUFFRCxNQUFNRCxXQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsS0FBSztFQUNuQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFQyxZQUFVLEVBQUM7RUFDNUM7O0FBRUQsTUFBTVQsYUFBVyxHQUFHLE1BQU07RUFDeEJQLE9BQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLEtBQUk7RUFDMUJBLE9BQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLEtBQUk7Q0FDM0I7O0FDNU5NLFNBQVMsVUFBVSxHQUFHO0VBQzNCLE1BQU0sSUFBSSxnQkFBZ0IsUUFBUSxDQUFDLEtBQUk7RUFDdkMsSUFBSSxRQUFRLGNBQWMsR0FBRTtFQUM1QixJQUFJLGlCQUFpQixLQUFLLEdBQUU7RUFDNUIsSUFBSSxNQUFNLGdCQUFnQixHQUFFO0VBQzVCLElBQUksT0FBTyxlQUFlLEdBQUU7O0VBRTVCLE1BQU0sV0FBVyxTQUFTO0lBQ3hCLE1BQU0sSUFBSSxJQUFJO0lBQ2QsT0FBTyxHQUFHLElBQUk7SUFDZCxLQUFLLEtBQUssSUFBSTtJQUNmOztFQUVELE1BQU0sTUFBTSxHQUFHLE1BQU07SUFDbkIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFDO0lBQzlDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBQzs7SUFFcEQsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLEVBQUUsWUFBWSxFQUFDO0lBQ3BDLElBQUksQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLFFBQVEsRUFBQzs7SUFFOUIsUUFBUSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUM7SUFDMUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUM7SUFDeEMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUM7O0lBRTVDLGVBQWUsR0FBRTs7SUFFakIsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsY0FBYyxFQUFDO0lBQzNDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxlQUFlLEVBQUUsRUFBQztJQUNuRCxPQUFPLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBQztJQUN0QixPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRSxZQUFZLEVBQUM7SUFDckMsT0FBTyxDQUFDLHNCQUFzQixFQUFFLFNBQVMsRUFBQztJQUMxQyxPQUFPLENBQUMsdUJBQXVCLEVBQUUsY0FBYyxFQUFDO0lBQ2hELE9BQU8sQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUUsbUJBQW1CLEVBQUM7SUFDL0QsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRSxRQUFRLEVBQUM7SUFDcEQsT0FBTyxDQUFDLGlDQUFpQyxFQUFFLHFCQUFxQixFQUFDO0lBQ2pFLE9BQU8sQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLFlBQVksQ0FBQyxFQUFFLGtCQUFrQixFQUFDO0lBQ3REOztFQUVELE1BQU0sUUFBUSxHQUFHLE1BQU07SUFDckIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFDO0lBQ2pELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBQzs7SUFFdkQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsWUFBWSxFQUFDO0lBQ3JDLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFFBQVEsRUFBQzs7SUFFL0IsUUFBUSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUM7SUFDN0MsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUM7SUFDM0MsUUFBUSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUM7O0lBRS9DLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLDhDQUE4QyxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyx3Q0FBd0MsQ0FBQyxFQUFDO0lBQzlLOztFQUVELE1BQU0sUUFBUSxHQUFHLENBQUMsSUFBSTtJQUNwQixNQUFNLE9BQU8sR0FBRyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUM7O0lBRTFELElBQUksV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLE9BQU8sQ0FBQyxDQUFDLE1BQU07TUFDdEUsTUFBTTs7SUFFUixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxlQUFlLEdBQUU7SUFDbEMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsWUFBWSxHQUFFOztJQUUvQixHQUFHLENBQUMsQ0FBQyxRQUFRLElBQUksT0FBTyxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUM7TUFDcEQsUUFBUSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLEVBQUM7O01BRS9DLE1BQU0sQ0FBQyxPQUFPLEVBQUM7SUFDbEI7O0VBRUQsTUFBTSxRQUFRLEdBQUcsRUFBRSxJQUFJO0lBQ3JCLENBQUMsR0FBRyxNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUM7T0FDcEIsTUFBTSxDQUFDLElBQUk7VUFDUixJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztTQUMzQyxPQUFPLENBQUMsSUFBSTtVQUNYLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBQzs7SUFFcEIsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJO01BQ2xCLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxDQUFDO09BQ3pDLE9BQU8sQ0FBQyxJQUFJO1FBQ1gsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztVQUNYLGVBQWUsT0FBTyxJQUFJO1VBQzFCLG9CQUFvQixFQUFFLElBQUk7VUFDMUIsZUFBZSxPQUFPLElBQUk7VUFDMUIsb0JBQW9CLFVBQVUsSUFBSTtVQUNsQyxnQkFBZ0IsTUFBTSxJQUFJO09BQzdCLENBQUMsRUFBQzs7SUFFTCxRQUFRLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEVBQUM7O0lBRTdFLFlBQVksR0FBRTtJQUNmOztFQUVELE1BQU0sV0FBVyxHQUFHLENBQUMsSUFBSTtJQUN2QixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLENBQUMsQ0FBQyxlQUFlLEdBQUU7SUFDbkIsSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLE1BQU07SUFDakMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUM7SUFDckM7O0VBRUQsTUFBTSxlQUFlLEdBQUcsQ0FBQyxJQUFJO0lBQzNCLElBQUksUUFBUSxHQUFHLE1BQUs7O0lBRXBCLFFBQVEsQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDLEVBQUU7TUFDL0IsSUFBSSxPQUFPLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxNQUFNLEVBQUU7UUFDbkMsQ0FBQyxDQUFDLDRDQUE0QyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUU7VUFDeEQsRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTSxFQUFDOztRQUU1QixRQUFRLEdBQUcsS0FBSTtPQUNoQjtNQUNGOztJQUVELFFBQVEsQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDLEVBQUU7TUFDN0IsSUFBSSxRQUFRLEVBQUU7UUFDWixDQUFDLENBQUMsNENBQTRDLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRTtVQUN4RCxFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxJQUFJLEVBQUM7O1FBRTFCLFFBQVEsR0FBRyxNQUFLO09BQ2pCO01BQ0Y7SUFDRjs7RUFFRCxNQUFNLE1BQU0sR0FBRyxDQUFDO0lBQ2QsUUFBUSxDQUFDLE1BQU0sSUFBSSxZQUFZLEdBQUU7O0VBRW5DLE1BQU0sWUFBWSxHQUFHLENBQUMsSUFBSTtJQUN4QixNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUFDO0lBQzdCLElBQUksQ0FBQyxTQUFTLEVBQUUsTUFBTTs7SUFFdEIsTUFBTSxVQUFVLEdBQUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUM7SUFDNUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxlQUFlLEVBQUM7SUFDM0MsU0FBUyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsVUFBVSxFQUFFLFNBQVMsQ0FBQyxXQUFXLEVBQUM7SUFDcEUsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNuQjs7RUFFRCxNQUFNLFNBQVMsR0FBRyxDQUFDO0lBQ2pCLFFBQVEsQ0FBQyxNQUFNLElBQUksVUFBVSxHQUFFOztFQUVqQyxNQUFNLGNBQWMsR0FBRyxDQUFDO0lBQ3RCLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUNqQixFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsRUFBQzs7RUFFM0IsTUFBTSxPQUFPLEdBQUcsQ0FBQyxJQUFJOztJQUVuQixJQUFJLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNO01BQ3pDLE1BQU07O0lBRVIsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUU7TUFDdEQsQ0FBQyxDQUFDLGNBQWMsR0FBRTtNQUNsQixJQUFJLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksRUFBQztNQUN2QyxLQUFLLENBQUMsZUFBZSxDQUFDLGVBQWUsRUFBQztNQUN0QyxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQyxVQUFTO01BQ2xDLENBQUMsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFDO0tBQ3ZEO0lBQ0Y7O0VBRUQsTUFBTSxNQUFNLEdBQUcsQ0FBQyxJQUFJO0lBQ2xCLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFO01BQ3RELElBQUksS0FBSyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFDO01BQ3ZDLEtBQUssQ0FBQyxlQUFlLENBQUMsZUFBZSxFQUFDO01BQ3RDLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDLFVBQVM7TUFDbEMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUM7TUFDdEQsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRTtLQUNyQjtJQUNGOztFQUVELE1BQU0sUUFBUSxHQUFHLENBQUMsSUFBSTtJQUNwQixNQUFNLFFBQVEsR0FBRyxDQUFDLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUM7SUFDckQsTUFBTSxhQUFhLEdBQUcsUUFBUSxJQUFJLElBQUksQ0FBQyxZQUFXO0lBQ2xELElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLGFBQWEsRUFBRTtNQUNoQyxDQUFDLENBQUMsY0FBYyxHQUFFO01BQ2xCLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXO1FBQ3JCLGVBQWUsQ0FBQyxhQUFhLENBQUMsRUFBQztLQUNsQztJQUNGOztFQUVELE1BQU0sY0FBYyxHQUFHLENBQUMsSUFBSTtJQUMxQixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLElBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFO01BQ2xDLFNBQVMsQ0FBQyxFQUFFLENBQUMsRUFBQztJQUNqQjs7RUFFRCxNQUFNLGVBQWUsR0FBRyxDQUFDLEtBQUssR0FBRyxDQUFDO0lBQ2hDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxJQUFJO01BQ3JCLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO1NBQ3RCLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQztVQUNqQixFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssRUFBQzs7TUFFM0IsS0FBSyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUM7VUFDbEMsS0FBSyxHQUFHLENBQUM7VUFDVCxLQUFLLEdBQUU7S0FDWixFQUFDOztFQUVKLE1BQU0sbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSztJQUN4QyxDQUFDLENBQUMsY0FBYyxHQUFFOztJQUVsQixNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsU0FBUTtJQUN2QixJQUFJLENBQUMsSUFBSSxFQUFFLE1BQU07O0lBRWpCLE1BQU0sS0FBSyxHQUFHLHVCQUF1QixDQUFDLElBQUksRUFBQzs7SUFFM0MsSUFBSSxlQUFlLENBQUMsS0FBSyxDQUFDO01BQ3hCLGVBQWUsQ0FBQztRQUNkLEtBQUs7UUFDTCxHQUFHLEVBQUUsR0FBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7T0FDM0IsRUFBQztJQUNMOztFQUVELE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUs7SUFDN0IsQ0FBQyxDQUFDLGNBQWMsR0FBRTs7SUFFbEIsSUFBSSxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUNwQyxJQUFJLFNBQVMsR0FBRyxDQUFDLEdBQUcsUUFBUSxFQUFDO01BQzdCLFlBQVksR0FBRTtNQUNkLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRSxJQUFJO1FBQ2hDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsT0FBTTtRQUMxQixPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtVQUM3QixJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBQztVQUNoRCxJQUFJLElBQUksQ0FBQyxRQUFRLEtBQUssT0FBTztZQUMzQixNQUFNLENBQUMsSUFBSSxFQUFDO1VBQ2QsRUFBRSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFDO1NBQzVCO1FBQ0QsRUFBRSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsRUFBRSxFQUFDO09BQzlCLEVBQUM7S0FDSDtTQUNJO01BQ0gsSUFBSSxHQUFHLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUM7TUFDdkMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPO1FBQzVCLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxLQUFLO1VBQ3JDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRSxFQUFDO1VBQ25CLE9BQU8sR0FBRztTQUNYLEVBQUUsR0FBRyxDQUFDO1FBQ1I7TUFDRCxZQUFZLEdBQUU7TUFDZCxNQUFNLENBQUMsR0FBRyxFQUFDO0tBQ1o7SUFDRjs7RUFFRCxNQUFNLFlBQVksR0FBRyxDQUFDO0lBQ3BCLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7T0FDbkIsUUFBUSxDQUFDLE1BQU07T0FDZixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVztPQUMvQyxDQUFDLENBQUMsY0FBYyxHQUFFOztFQUV2QixNQUFNLHFCQUFxQixHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUs7SUFDMUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsTUFBTTs7SUFFNUIsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixDQUFDLENBQUMsZUFBZSxHQUFFOztJQUVuQixNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsYUFBYSxFQUFFLElBQUksS0FBSztNQUN2RCxNQUFNLGVBQWUsT0FBTyxXQUFXLENBQUMsSUFBSSxFQUFDO01BQzdDLE1BQU0sZ0JBQWdCLE1BQU0sWUFBWSxDQUFDLElBQUksRUFBQztNQUM5QyxNQUFNLGtCQUFrQixJQUFJLFNBQVMsQ0FBQyxJQUFJLEVBQUM7TUFDM0MsTUFBTSxrQkFBa0IsSUFBSSx1QkFBdUIsQ0FBQyxJQUFJLEVBQUM7O01BRXpELElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtRQUN6QixJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksZUFBZTtVQUN4QyxhQUFhLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBQzthQUMvQixJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksa0JBQWtCO1VBQ2xELGFBQWEsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEVBQUM7O1VBRXJDLGFBQWEsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFDO09BQzFCO1dBQ0k7UUFDSCxJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksZ0JBQWdCO1VBQ3pDLGFBQWEsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUM7YUFDaEMsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLGtCQUFrQjtVQUNsRCxhQUFhLENBQUMsR0FBRyxDQUFDLGtCQUFrQixFQUFDOztVQUVyQyxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksRUFBQztPQUMxQjs7TUFFRCxPQUFPLGFBQWE7S0FDckIsRUFBRSxJQUFJLEdBQUcsRUFBRSxFQUFDOztJQUViLElBQUksT0FBTyxDQUFDLElBQUksRUFBRTtNQUNoQixZQUFZLEdBQUU7TUFDZCxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSTtRQUN0QixNQUFNLENBQUMsSUFBSSxFQUFDO1FBQ1osUUFBUSxDQUFDLElBQUksRUFBQztPQUNmLEVBQUM7S0FDSDtJQUNGOztFQUVELE1BQU0sUUFBUSxHQUFHLEVBQUUsSUFBSTtJQUNyQixNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVTtJQUM5QyxJQUFJLFdBQVU7O0lBRWQsSUFBSSxXQUFXLEtBQUssZUFBZSxFQUFFO01BQ25DaUIsV0FBMEIsR0FBRTtNQUM1QixVQUFVLEdBQUdDLFVBQW9CO0tBQ2xDO1NBQ0ksSUFBSSxXQUFXLEtBQUssV0FBVyxFQUFFO01BQ3BDQyxTQUFpQixHQUFFO01BQ25CLFVBQVUsR0FBR0MsUUFBVztLQUN6Qjs7SUFFRCxJQUFJLENBQUMsVUFBVSxFQUFFLE1BQU07O0lBRXZCLE1BQU0sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLHFCQUFxQixHQUFFO0lBQzlDLE1BQU0sRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLEdBQUcsT0FBTTs7SUFFM0MsVUFBVSxDQUFDLEVBQUUsRUFBRTtNQUNiLE9BQU8sR0FBRyxHQUFHO01BQ2IsT0FBTyxHQUFHLElBQUk7TUFDZCxLQUFLLEtBQUssV0FBVyxHQUFHLEdBQUcsR0FBRyxFQUFFO01BQ2hDLEtBQUssS0FBSyxXQUFXLEdBQUcsSUFBSSxHQUFHLEVBQUU7S0FDbEMsRUFBQztJQUNIOztFQUVELE1BQU0sUUFBUSxHQUFHLENBQUMsSUFBSTtJQUNwQixNQUFNLE9BQU8sR0FBRyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUM7O0lBRTFELElBQUksV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLE9BQU8sQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDO01BQy9ELE9BQU8sVUFBVSxFQUFFOztJQUVyQixjQUFjLENBQUMsT0FBTyxFQUFDOztJQUV2QixJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsS0FBSyxRQUFRLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLE9BQU8sRUFBRTtNQUMxRyxPQUFPLENBQUMsWUFBWSxDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBQztNQUM1QyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsU0FBUTtNQUMxQixPQUFPLGtCQUFrQixDQUFDLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0tBQzlDO1NBQ0ksSUFBSSxPQUFPLENBQUMsWUFBWSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7TUFDL0MsT0FBTyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsRUFBQztNQUN6QyxpQkFBaUIsR0FBRTtLQUNwQjtJQUNGOztFQUVELE1BQU0sTUFBTSxHQUFHLEVBQUUsSUFBSTtJQUNuQixFQUFFLENBQUMsWUFBWSxDQUFDLGVBQWUsRUFBRSxJQUFJLEVBQUM7SUFDdEMsRUFBRSxDQUFDLFlBQVksQ0FBQyxlQUFlLEVBQUUsTUFBTSxDQUFDLE1BQU0sRUFBQzs7SUFFL0MsVUFBVSxHQUFFOztJQUVaLGFBQWEsQ0FBQyxFQUFFLEVBQUM7SUFDakIsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUM7SUFDcEIsWUFBWSxHQUFFO0lBQ2Y7O0VBRUQsTUFBTSxTQUFTLEdBQUc7SUFDaEIsU0FBUTs7RUFFVixNQUFNLFlBQVksR0FBRyxNQUFNO0lBQ3pCLFFBQVE7T0FDTCxPQUFPLENBQUMsRUFBRTtRQUNULENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUM7VUFDVCxlQUFlLE9BQU8sSUFBSTtVQUMxQixvQkFBb0IsRUFBRSxJQUFJO1VBQzFCLGVBQWUsT0FBTyxJQUFJO1VBQzFCLG9CQUFvQixFQUFFLElBQUk7U0FDM0IsQ0FBQyxFQUFDOztJQUVQLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLE9BQU8sRUFBRSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUU7TUFDNUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxFQUFDOztJQUVkLE1BQU0sTUFBTSxHQUFFO0lBQ2QsT0FBTyxLQUFLLEdBQUU7SUFDZCxRQUFRLElBQUksR0FBRTtJQUNmOztFQUVELE1BQU0sVUFBVSxHQUFHLE1BQU07SUFDdkIsTUFBTSxxQkFBcUIsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsSUFBSTtNQUMvQyxJQUFJLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxPQUFPLFlBQVksQ0FBQyxFQUFFLENBQUM7V0FDNUMsSUFBSSxXQUFXLENBQUMsRUFBRSxDQUFDLEVBQUUsT0FBTyxXQUFXLENBQUMsRUFBRSxDQUFDO1dBQzNDLElBQUksRUFBRSxDQUFDLFVBQVUsSUFBSSxPQUFPLEVBQUUsQ0FBQyxVQUFVO0tBQy9DLEVBQUM7O0lBRUYsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsUUFBUSxFQUFFLEdBQUcsTUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUN6RCxFQUFFLENBQUMsTUFBTSxFQUFFLEVBQUM7O0lBRWQsTUFBTSxNQUFNLEdBQUU7SUFDZCxPQUFPLEtBQUssR0FBRTtJQUNkLFFBQVEsSUFBSSxHQUFFOztJQUVkLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQzlCLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBQztJQUNkOztFQUVELE1BQU0sZUFBZSxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsR0FBRyxHQUFHLEtBQUssQ0FBQyxLQUFLO0lBQ2hELElBQUksR0FBRyxFQUFFO01BQ1AsTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRyx1QkFBdUIsRUFBQztNQUN0RCxXQUFXLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBQztLQUM1QjtTQUNJO01BQ0gsTUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBQztNQUMzQixJQUFJLENBQUMsVUFBVSxFQUFFLE1BQU07O01BRXZCLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxTQUFRO01BQ3pCLE1BQU0sZUFBZSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUM7UUFDdkQsSUFBSSxJQUFJLE1BQU07WUFDVixLQUFLLEdBQUcsQ0FBQztZQUNULEtBQUs7UUFDVCxJQUFJLEVBQUM7O01BRVAsSUFBSSxlQUFlLEtBQUssSUFBSSxFQUFFO1FBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxHQUFHLENBQUMsQ0FBQyxFQUFFO1VBQ3BDLE1BQU0sU0FBUyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQztVQUN2RSxJQUFJLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUyxFQUFDO1NBQ2pDO2FBQ0k7VUFDSCxNQUFNLENBQUMsVUFBVSxDQUFDLGVBQWUsR0FBRyxDQUFDLENBQUMsRUFBQztTQUN4QztPQUNGO0tBQ0Y7SUFDRjs7RUFFRCxNQUFNLHVCQUF1QixHQUFHLElBQUk7SUFDbEMsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUMsRUFBRSxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBQzs7RUFFMUQsTUFBTSxjQUFjLEdBQUcsRUFBRSxJQUFJO0lBQzNCLElBQUksV0FBVyxDQUFDLE1BQU0sS0FBSyxFQUFFLEVBQUUsTUFBTTs7SUFFckMsV0FBVyxDQUFDLE1BQU0sSUFBSSxHQUFFO0lBQ3hCLFdBQVcsQ0FBQyxPQUFPLEdBQUcsV0FBVyxDQUFDLEVBQUUsRUFBQztJQUNyQyxXQUFXLENBQUMsS0FBSyxHQUFHLGdCQUFnQixDQUFDLEVBQUUsRUFBRSxDQUFDO2NBQ2hDLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUNqQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7TUFDMUIsRUFBRSxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztTQUM3QixNQUFNLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFLENBQUM7U0FDMUIsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLElBQUksS0FBSyxDQUFDO1VBQ3hCLEVBQUUsS0FBSyxDQUFDO2NBQ0osRUFBRSxJQUFJLENBQUM7UUFDYixDQUFDLEVBQUUsRUFBRSxDQUFDO09BQ1A7SUFDSCxDQUFDLEVBQUM7SUFDSDs7RUFFRCxNQUFNLFVBQVUsR0FBRyxNQUFNO0lBQ3ZCLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLE1BQU07O0lBRS9CLFdBQVcsQ0FBQyxPQUFPLElBQUksV0FBVyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUU7SUFDbkQsV0FBVyxDQUFDLEtBQUssSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRTs7SUFFL0MsV0FBVyxDQUFDLE1BQU0sSUFBSSxLQUFJO0lBQzFCLFdBQVcsQ0FBQyxPQUFPLEdBQUcsS0FBSTtJQUMxQixXQUFXLENBQUMsS0FBSyxLQUFLLEtBQUk7SUFDM0I7O0VBRUQsTUFBTSxhQUFhLEdBQUcsRUFBRSxJQUFJO0lBQzFCLElBQUksTUFBTSxHQUFHLFlBQVksQ0FBQyxFQUFFLEVBQUM7SUFDN0IsSUFBSSxLQUFLLElBQUksV0FBVyxDQUFDLEVBQUUsRUFBRSxDQUFDO2NBQ3BCLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUNqQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7TUFDMUIsRUFBRSxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztTQUM3QixNQUFNLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFLENBQUM7U0FDMUIsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLElBQUksS0FBSyxDQUFDO1VBQ3hCLEVBQUUsS0FBSyxDQUFDO2NBQ0osRUFBRSxJQUFJLENBQUM7UUFDYixDQUFDLEVBQUUsRUFBRSxDQUFDO09BQ1A7SUFDSCxDQUFDLEVBQUM7O0lBRUYsSUFBSSxRQUFRLFVBQVUsY0FBYyxDQUFDLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBQztJQUN4RCxJQUFJLGNBQWMsSUFBSSxjQUFjLENBQUMsRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFDOztJQUV4RCxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsRUFBQztJQUMxQyxjQUFjLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUUsRUFBRSxTQUFTLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsRUFBQzs7SUFFdkUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUk7TUFDakMsUUFBUSxDQUFDLFVBQVUsR0FBRTtNQUNyQixjQUFjLENBQUMsVUFBVSxHQUFFO0tBQzVCLEVBQUM7SUFDSDs7RUFFRCxNQUFNLFFBQVEsR0FBRyxDQUFDLEVBQUUsRUFBRSxLQUFLO0lBQ3pCLEtBQUssQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDLHFCQUFxQixHQUFFOztFQUUzQyxNQUFNLFdBQVcsR0FBRyxDQUFDLEVBQUUsRUFBRSxJQUFJLEtBQUs7SUFDaEMsTUFBTSxFQUFFLEdBQUcsUUFBUSxDQUFDLEVBQUUsQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLEVBQUM7O0lBRXJELElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUU7TUFDZixNQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLGNBQWMsRUFBQzs7TUFFcEQsS0FBSyxDQUFDLElBQUksR0FBRyxLQUFJO01BQ2pCLEtBQUssQ0FBQyxRQUFRLEdBQUc7UUFDZixZQUFZLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFO1FBQzFDLGFBQWEsR0FBRyxFQUFFO1FBQ25COztNQUVELFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBQzs7TUFFaEMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO1FBQ2pDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLE1BQU07UUFDeEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsS0FBSTs7UUFFN0IsU0FBUyxDQUFDLHNCQUFzQixFQUFFLEVBQUU7VUFDbEMsRUFBRSxDQUFDLGVBQWUsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFDOztRQUUzQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyx1QkFBdUIsRUFBRSxFQUFFO1VBQ3JELE1BQU0sQ0FBQyxTQUFTLEtBQUssWUFBWTtjQUM3QixFQUFFLENBQUMsWUFBWSxDQUFDLG9CQUFvQixFQUFFLElBQUksQ0FBQztjQUMzQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUM7T0FDbEIsRUFBQzs7TUFFRixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLFlBQVksRUFBRSxDQUFDLElBQUk7UUFDN0IsQ0FBQyxDQUFDLGNBQWMsR0FBRTtRQUNsQixDQUFDLENBQUMsZUFBZSxHQUFFO1FBQ25CLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxFQUFFO1VBQ2xDLEVBQUUsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUMsRUFBQztPQUM1QyxFQUFDOztNQUVGLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsTUFBSzs7TUFFN0IsT0FBTyxLQUFLO0tBQ2I7SUFDRjs7RUFFRCxNQUFNLFlBQVksR0FBRyxFQUFFLElBQUk7SUFDekIsTUFBTSxFQUFFLEdBQUcsUUFBUSxDQUFDLEVBQUUsQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLEVBQUM7O0lBRXJELElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUU7TUFDaEIsTUFBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsRUFBQzs7TUFFdkQsTUFBTSxDQUFDLFFBQVEsR0FBRztRQUNoQixZQUFZLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFO1FBQzFDLGFBQWEsR0FBRyxFQUFFO1FBQ25COztNQUVELFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBQzs7TUFFakMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxPQUFNO01BQ2hDLE9BQU8sTUFBTTtLQUNkO0lBQ0Y7O0VBRUQsTUFBTSxXQUFXLEdBQUcsRUFBRSxJQUFJO0lBQ3hCLElBQUksQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQyxFQUFFO01BQy9FLElBQUksV0FBVyxDQUFDLE9BQU87UUFDckIsV0FBVyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUU7O01BRTlCLFdBQVcsQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLEVBQUM7O01BRTVELFdBQVcsQ0FBQyxPQUFPLENBQUMsUUFBUSxHQUFHO1FBQzdCLFlBQVksRUFBRSxFQUFFLENBQUMscUJBQXFCLEVBQUU7UUFDekM7O01BRUQsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBQzs7TUFFOUMsT0FBTyxXQUFXLENBQUMsT0FBTztLQUMzQjtJQUNGOztFQUVELE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQyxFQUFFLEVBQUUsSUFBSSxLQUFLO0lBQ3JDLElBQUksQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQyxFQUFFO01BQy9FLElBQUksV0FBVyxDQUFDLEtBQUs7UUFDbkIsV0FBVyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUU7O01BRTVCLFdBQVcsQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLEVBQUM7O01BRTFELFdBQVcsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLEtBQUk7TUFDN0IsV0FBVyxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUc7UUFDM0IsWUFBWSxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRTtRQUMxQyxhQUFhLEdBQUcsT0FBTztRQUN4Qjs7TUFFRCxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLCtCQUErQixFQUFDOztNQUUzRCxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFDOztNQUU1QyxPQUFPLFdBQVcsQ0FBQyxLQUFLO0tBQ3pCO0lBQ0Y7O0VBRUQsTUFBTSxTQUFTLEdBQUcsQ0FBQyxJQUFJLEVBQUUsTUFBTSxLQUFLO0lBQ2xDLE1BQU0sQ0FBQyxRQUFRLEdBQUc7TUFDaEIsWUFBWSxJQUFJLElBQUksQ0FBQyxxQkFBcUIsRUFBRTtNQUM1QyxhQUFhLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUM7TUFDbkQ7SUFDRjs7RUFFRCxNQUFNLGNBQWMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7SUFDMUMsSUFBSSxnQkFBZ0IsQ0FBQyxJQUFJLElBQUk7TUFDM0IsUUFBUSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUM7TUFDckIsU0FBUyxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUM7S0FDeEIsRUFBQzs7RUFFSixNQUFNLGdCQUFnQixHQUFHLENBQUMsRUFBRSxFQUFFLGlCQUFpQixHQUFHLElBQUksS0FBSztJQUN6RCxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFDO0lBQzFCLElBQUksaUJBQWlCLEVBQUUsRUFBRSxDQUFDLFFBQVEsRUFBQztJQUNwQzs7RUFFRCxNQUFNLHNCQUFzQixHQUFHLEVBQUU7SUFDL0IsaUJBQWlCLEdBQUcsaUJBQWlCLENBQUMsTUFBTSxDQUFDLFFBQVEsSUFBSSxRQUFRLElBQUksRUFBRSxFQUFDOztFQUUxRSxNQUFNLFlBQVksR0FBRztJQUNuQixpQkFBaUIsQ0FBQyxPQUFPLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBQzs7RUFFL0MsTUFBTSxVQUFVLEdBQUcsTUFBTTtJQUN2QixZQUFZLEdBQUU7SUFDZCxRQUFRLEdBQUU7SUFDWDs7RUFFRCxNQUFNLGtCQUFrQixHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUs7SUFDdkMsTUFBTSxPQUFPLEdBQUcsUUFBUTtPQUNyQixNQUFNLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO09BQ3BDLE1BQU0sQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQztRQUN2QixDQUFDLEdBQUcsSUFBSSxFQUFFLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBQzs7SUFFM0MsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFO01BQ2xCLENBQUMsQ0FBQyxjQUFjLEdBQUU7TUFDbEIsQ0FBQyxDQUFDLGVBQWUsR0FBRTs7TUFFbkIsWUFBWSxHQUFFO01BQ2QsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFDO0tBQ3RDO0lBQ0Y7O0VBRUQsb0JBQW9CLEdBQUU7RUFDdEIsTUFBTSxHQUFFOztFQUVSLE9BQU87SUFDTCxNQUFNO0lBQ04sU0FBUztJQUNULFlBQVk7SUFDWixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLFVBQVU7R0FDWDtDQUNGOztBQ3ZuQkQ7QUFDQSxNQUFNaEMsWUFBVSxHQUFHLG9CQUFvQjtHQUNwQyxLQUFLLENBQUMsR0FBRyxDQUFDO0dBQ1YsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUs7SUFDcEIsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkUsRUFBRSxDQUFDO0dBQ0osU0FBUyxDQUFDLENBQUMsRUFBQzs7QUFFZixNQUFNaUMsZ0JBQWMsR0FBRyxDQUFDLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLFdBQVcsRUFBQzs7QUFFaEcsQUFBTyxTQUFTLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUFFO0VBQ25DLE9BQU8sQ0FBQ2pDLFlBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDbEMsSUFBSSxDQUFDLENBQUMsWUFBWSxFQUFFLE1BQU07O0lBRTFCLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsVUFBVSxDQUFDLFNBQVMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUM7R0FDckMsRUFBQzs7RUFFRixPQUFPLENBQUNpQyxnQkFBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUN0QyxDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLGtCQUFrQixDQUFDLFNBQVMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUM7R0FDN0MsRUFBQzs7RUFFRixPQUFPLE1BQU07SUFDWCxPQUFPLENBQUMsTUFBTSxDQUFDakMsWUFBVSxFQUFDO0lBQzFCLE9BQU8sQ0FBQyxNQUFNLENBQUNpQyxnQkFBYyxFQUFDO0lBQzlCLE9BQU8sQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUM7R0FDckM7Q0FDRjs7QUFFRCxBQUFPLFNBQVMsVUFBVSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDekMsR0FBRztLQUNBLEdBQUcsQ0FBQyxFQUFFLElBQUksZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDL0IsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLEtBQUssU0FBUyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUM7TUFDeEMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLFNBQVMsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7TUFDcEUsTUFBTSxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDO01BQ3pELFFBQVEsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7S0FDL0MsQ0FBQyxDQUFDO0tBQ0YsR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixPQUFPLEVBQUUsT0FBTyxDQUFDLFFBQVE7WUFDckIsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTTtZQUNoQyxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxNQUFNO09BQ3JDLENBQUMsQ0FBQztLQUNKLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUM7TUFDNUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFDO0NBQ3hEOztBQUVELEFBQU8sU0FBUyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsVUFBVSxFQUFFO0VBQ2xELE1BQU0sS0FBSyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFDO0VBQ25DLElBQUksS0FBSyxHQUFHLEdBQUU7O0VBRWQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEtBQUssR0FBRyxRQUFRLEdBQUcsTUFBSztFQUN0RCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxHQUFHLE1BQU0sR0FBRyxNQUFLOztFQUVwRCxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0tBQzVCLE9BQU8sQ0FBQyxJQUFJLElBQUksVUFBVSxDQUFDLEdBQUcsRUFBRSxLQUFLLEdBQUcsSUFBSSxDQUFDLEVBQUM7Q0FDbEQ7O0FDMURELE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0VBQ3RDLE1BQU0sQ0FBQyxlQUFlLENBQUMsaUJBQWlCLEVBQUM7RUFDekMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxZQUFZLEVBQUM7RUFDcEMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxpQkFBaUIsRUFBQztFQUNyRCxNQUFNLENBQUMsbUJBQW1CLENBQUMsU0FBUyxFQUFFQyxjQUFZLEVBQUM7RUFDbkQsT0FBTyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUM7RUFDN0I7O0FBRUQsTUFBTUEsY0FBWSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLFFBQVEsSUFBSSxDQUFDLENBQUMsZUFBZSxHQUFFOztBQUVsRSxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7RUFDOUIsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sSUFBSSxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUM7RUFDdkUsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDLEtBQUssR0FBRTtFQUM5Qjs7QUFFRCxBQUFPLFNBQVMsUUFBUSxDQUFDLFFBQVEsRUFBRTtFQUNqQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxNQUFNOztFQUU1QixRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsSUFBSTtJQUNqQixJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFDOztJQUVmLEdBQUcsQ0FBQyxJQUFJLENBQUM7TUFDUCxlQUFlLEVBQUUsSUFBSTtNQUNyQixVQUFVLEVBQUUsSUFBSTtLQUNqQixFQUFDO0lBQ0YsRUFBRSxDQUFDLEtBQUssR0FBRTtJQUNWLGlCQUFpQixDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUM7O0lBRTNCLEdBQUcsQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFQSxjQUFZLEVBQUM7SUFDL0IsR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsaUJBQWlCLEVBQUM7R0FDbEMsRUFBQzs7RUFFRixPQUFPLENBQUMsWUFBWSxFQUFFLE9BQU8sRUFBQzs7O0NBQy9CLERDbENELE1BQU1sQyxZQUFVLEdBQUcsb0JBQW9CO0dBQ3BDLEtBQUssQ0FBQyxHQUFHLENBQUM7R0FDVixNQUFNLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSztJQUNwQixDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25DLEVBQUUsQ0FBQztHQUNKLFNBQVMsQ0FBQyxDQUFDLEVBQUM7O0FBRWYsTUFBTWlDLGdCQUFjLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBQzs7QUFFdEQsQUFBTyxTQUFTLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUFFO0VBQ2hDLE9BQU8sQ0FBQ2pDLFlBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDbEMsSUFBSSxDQUFDLENBQUMsWUFBWSxFQUFFLE1BQU07O0lBRTFCLENBQUMsQ0FBQyxjQUFjLEdBQUU7O0lBRWxCLElBQUksYUFBYSxHQUFHLFNBQVMsRUFBRTtRQUMzQixJQUFJLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFDOztJQUVqQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7TUFDakQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7VUFDbEIsYUFBYSxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDO1VBQ3pDLGVBQWUsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBQzs7TUFFL0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7VUFDbEIsYUFBYSxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDO1VBQ3pDLGNBQWMsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBQztHQUNqRCxFQUFDOztFQUVGLE9BQU8sQ0FBQ2lDLGdCQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ3RDLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsSUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFDO0lBQ2pDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxHQUFHLE1BQU0sRUFBQztHQUNuRSxFQUFDOztFQUVGLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJO0lBQ3BCLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQ3BCLEVBQUUsQ0FBQyxLQUFLLENBQUMsVUFBVTtRQUNqQixFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsSUFBSSxNQUFNO1lBQ3pCLElBQUk7WUFDSixNQUFNLEVBQUM7R0FDaEIsRUFBQzs7RUFFRixPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSTtJQUNwQixTQUFTLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUNwQixFQUFFLENBQUMsS0FBSyxDQUFDLFNBQVM7UUFDaEIsRUFBRSxDQUFDLEtBQUssQ0FBQyxTQUFTLElBQUksUUFBUTtZQUMxQixJQUFJO1lBQ0osUUFBUSxFQUFDO0dBQ2xCLEVBQUM7O0VBRUYsT0FBTyxNQUFNO0lBQ1gsT0FBTyxDQUFDLE1BQU0sQ0FBQ2pDLFlBQVUsRUFBQztJQUMxQixPQUFPLENBQUMsTUFBTSxDQUFDaUMsZ0JBQWMsRUFBQztJQUM5QixPQUFPLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBQztJQUM3QixPQUFPLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUFDO0dBQ3JDO0NBQ0Y7O0FBRUQsQUFBTyxTQUFTLGFBQWEsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFO0VBQzVDLEdBQUc7S0FDQSxHQUFHLENBQUMsRUFBRSxJQUFJLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0tBQy9CLEdBQUcsQ0FBQyxFQUFFLEtBQUs7TUFDVixFQUFFO01BQ0YsS0FBSyxLQUFLLFlBQVk7TUFDdEIsT0FBTyxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLFlBQVksQ0FBQyxDQUFDO01BQzlDLE1BQU0sSUFBSSxDQUFDO01BQ1gsUUFBUSxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztLQUNoRCxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTyxJQUFJLFFBQVEsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztZQUMxRCxJQUFJLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1lBQ2pELE9BQU8sQ0FBQyxPQUFPO09BQ3BCLENBQUMsQ0FBQztLQUNKLEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxRQUFRO1lBQ25CLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU07WUFDaEMsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTTtPQUNyQyxDQUFDLENBQUM7S0FDSixPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO01BQzFCLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsRUFBQztDQUNwQzs7QUFFRCxBQUFPLFNBQVMsYUFBYSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDNUMsR0FBRztLQUNBLEdBQUcsQ0FBQyxFQUFFLElBQUksZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDL0IsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLEtBQUssZUFBZTtNQUN6QixPQUFPLEdBQUcsVUFBVSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsZUFBZSxDQUFDLENBQUM7TUFDbkQsTUFBTSxJQUFJLEVBQUU7TUFDWixRQUFRLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO0tBQ2hELENBQUMsQ0FBQztLQUNGLEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPLElBQUksUUFBUSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1lBQzFELENBQUM7WUFDRCxPQUFPLENBQUMsT0FBTztPQUNwQixDQUFDLENBQUM7S0FDSixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLEtBQUssRUFBRSxPQUFPLENBQUMsUUFBUTtZQUNuQixDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO1lBQzdDLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7T0FDbEQsQ0FBQyxDQUFDO0tBQ0osT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztNQUMxQixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLEVBQUUsQ0FBQyxFQUFDO0NBQ3ZEOztBQUVELEFBQU8sU0FBUyxjQUFjLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRTtFQUM3QyxHQUFHO0tBQ0EsR0FBRyxDQUFDLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUMvQixHQUFHLENBQUMsRUFBRSxLQUFLO01BQ1YsRUFBRTtNQUNGLEtBQUssS0FBSyxVQUFVO01BQ3BCLE9BQU8sR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxVQUFVLENBQUMsQ0FBQztNQUM1QyxNQUFNLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7TUFDekQsUUFBUSxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztLQUNoRCxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLFNBQVMsRUFBRSxPQUFPLENBQUMsUUFBUTtZQUN2QixPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxNQUFNO1lBQ2hDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU07T0FDckMsQ0FBQyxDQUFDO0tBQ0osT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLFNBQVMsQ0FBQztNQUM5QixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxTQUFTLENBQUMsRUFBRSxDQUFDLEVBQUM7Q0FDN0Q7O0FBRUQsTUFBTSxTQUFTLEdBQUc7RUFDaEIsTUFBTSxFQUFFLENBQUM7RUFDVCxJQUFJLElBQUksQ0FBQztFQUNULEtBQUssR0FBRyxDQUFDO0VBQ1QsRUFBRSxFQUFFLENBQUM7RUFDTCxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7RUFDeEU7QUFDRCxNQUFNLGFBQWEsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFDOztBQUUzRCxBQUFPLFNBQVMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRTtFQUMvQyxHQUFHO0tBQ0EsR0FBRyxDQUFDLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUMvQixHQUFHLENBQUMsRUFBRSxLQUFLO01BQ1YsRUFBRTtNQUNGLEtBQUssS0FBSyxZQUFZO01BQ3RCLE9BQU8sR0FBRyxRQUFRLENBQUMsRUFBRSxFQUFFLFlBQVksQ0FBQztNQUNwQyxTQUFTLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO0tBQ2pELENBQUMsQ0FBQztLQUNGLEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxTQUFTO1lBQ3BCLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztZQUM5QixTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7T0FDbkMsQ0FBQyxDQUFDO0tBQ0osT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztNQUMxQixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLGFBQWEsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLElBQUksYUFBYSxDQUFDLE1BQU07VUFDekUsYUFBYSxDQUFDLE1BQU07VUFDcEIsS0FBSztPQUNSLEVBQUM7Q0FDUDs7QUFFRCxNQUFNLFFBQVEsR0FBRztFQUNmLEtBQUssRUFBRSxDQUFDO0VBQ1IsSUFBSSxFQUFFLENBQUM7RUFDUCxNQUFNLEVBQUUsQ0FBQztFQUNULEtBQUssRUFBRSxDQUFDO0VBQ1Q7QUFDRCxNQUFNLFlBQVksR0FBRyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFDOztBQUU5QyxBQUFPLFNBQVMsZUFBZSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDOUMsR0FBRztLQUNBLEdBQUcsQ0FBQyxFQUFFLElBQUksZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDL0IsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLEtBQUssV0FBVztNQUNyQixPQUFPLEdBQUcsUUFBUSxDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUM7TUFDbkMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztLQUNqRCxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLEtBQUssRUFBRSxPQUFPLENBQUMsU0FBUztZQUNwQixRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7WUFDN0IsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO09BQ2xDLENBQUMsQ0FBQztLQUNKLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7TUFDMUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxZQUFZLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUM7Q0FDM0U7O0FDMUxELE1BQU1qQyxZQUFVLEdBQUcsb0JBQW9CO0dBQ3BDLEtBQUssQ0FBQyxHQUFHLENBQUM7R0FDVixNQUFNLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSztJQUNwQixDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25DLEVBQUUsQ0FBQztHQUNKLFNBQVMsQ0FBQyxDQUFDLEVBQUM7O0FBRWYsTUFBTWlDLGdCQUFjLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUM7O0FBRXZGLEFBQU8sU0FBUyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRTtFQUNoQyxPQUFPLENBQUNqQyxZQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ2xDLElBQUksQ0FBQyxDQUFDLFlBQVksRUFBRSxNQUFNOztJQUUxQixDQUFDLENBQUMsY0FBYyxHQUFFOztJQUVsQixJQUFJLGFBQWEsR0FBRyxTQUFTLEVBQUU7UUFDM0IsSUFBSSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBQzs7SUFFakMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO01BQ2pELElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO1VBQ2xCLG1CQUFtQixDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDO1VBQy9DLGdCQUFnQixDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFDOztNQUVoRCxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztVQUNsQixtQkFBbUIsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQztVQUMvQyxnQkFBZ0IsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBQztHQUNuRCxFQUFDOztFQUVGLE9BQU8sQ0FBQ2lDLGdCQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ3RDLENBQUMsQ0FBQyxjQUFjLEdBQUU7O0lBRWxCLElBQUksYUFBYSxHQUFHLFNBQVMsRUFBRTtRQUMzQixJQUFJLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFDOztJQUVqQyxlQUFlLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsS0FBSyxHQUFHLFFBQVEsRUFBQztHQUN6RSxFQUFDOztFQUVGLE9BQU8sTUFBTTtJQUNYLE9BQU8sQ0FBQyxNQUFNLENBQUNqQyxZQUFVLEVBQUM7SUFDMUIsT0FBTyxDQUFDLE1BQU0sQ0FBQ2lDLGdCQUFjLEVBQUM7SUFDOUIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsRUFBQztHQUNyQztDQUNGOztBQUVELE1BQU0sVUFBVSxHQUFHLEVBQUUsSUFBSTtFQUN2QixFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFNO0VBQ3pCLE9BQU8sRUFBRTtFQUNWOztBQUVELE1BQU0sNkJBQTZCLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxLQUFLO0VBQ25ELElBQUksSUFBSSxJQUFJLE9BQU8sS0FBSyxHQUFHLElBQUksWUFBWSxJQUFJLEdBQUcsSUFBSSxRQUFRLElBQUksR0FBRyxJQUFJLFVBQVUsQ0FBQztJQUNsRixHQUFHLEdBQUcsU0FBUTtPQUNYLElBQUksSUFBSSxJQUFJLFlBQVksS0FBSyxHQUFHLElBQUksY0FBYyxJQUFJLEdBQUcsSUFBSSxlQUFlLENBQUM7SUFDaEYsR0FBRyxHQUFHLFNBQVE7O0VBRWhCLE9BQU8sR0FBRztFQUNYOzs7QUFHRCxBQUFPLFNBQVMsZUFBZSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUU7RUFDMUMsR0FBRztLQUNBLEdBQUcsQ0FBQyxVQUFVLENBQUM7S0FDZixHQUFHLENBQUMsRUFBRSxJQUFJO01BQ1QsRUFBRSxDQUFDLEtBQUssQ0FBQyxhQUFhLEdBQUcsTUFBSztLQUMvQixFQUFDO0NBQ0w7O0FBRUQsTUFBTSxVQUFVLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxHQUFFO0FBQzlFLE1BQU1FLGdCQUFjLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBQzs7QUFFMUQsQUFBTyxTQUFTLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDL0MsR0FBRztLQUNBLEdBQUcsQ0FBQyxVQUFVLENBQUM7S0FDZixHQUFHLENBQUMsRUFBRSxLQUFLO01BQ1YsRUFBRTtNQUNGLEtBQUssS0FBSyxnQkFBZ0I7TUFDMUIsT0FBTyxHQUFHLDZCQUE2QixDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsZ0JBQWdCLENBQUMsRUFBRSxPQUFPLENBQUM7TUFDaEYsU0FBUyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztLQUNqRCxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLEtBQUssRUFBRSxPQUFPLENBQUMsU0FBUztZQUNwQixVQUFVLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7WUFDL0IsVUFBVSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO09BQ3BDLENBQUMsQ0FBQztLQUNKLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7TUFDMUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBR0EsZ0JBQWMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBQztDQUM3RTtBQUNELEFBRUEsTUFBTUMsZ0JBQWMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFDOztBQUUxRCxBQUFPLFNBQVMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRTtFQUMvQyxHQUFHO0tBQ0EsR0FBRyxDQUFDLFVBQVUsQ0FBQztLQUNmLEdBQUcsQ0FBQyxFQUFFLEtBQUs7TUFDVixFQUFFO01BQ0YsS0FBSyxLQUFLLFlBQVk7TUFDdEIsT0FBTyxHQUFHLFFBQVEsQ0FBQyxFQUFFLEVBQUUsWUFBWSxDQUFDO01BQ3BDLFNBQVMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7S0FDL0MsQ0FBQyxDQUFDO0tBQ0YsR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixLQUFLLEVBQUUsT0FBTyxDQUFDLFNBQVM7WUFDcEIsVUFBVSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO1lBQy9CLFVBQVUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztPQUNwQyxDQUFDLENBQUM7S0FDSixPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO01BQzFCLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUdBLGdCQUFjLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUM7Q0FDN0U7O0FBRUQsTUFBTSxpQkFBaUIsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUU7QUFDdEYsTUFBTSxxQkFBcUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsZUFBZSxFQUFDOztBQUVsRSxBQUFPLFNBQVMsbUJBQW1CLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRTtFQUNsRCxHQUFHO0tBQ0EsR0FBRyxDQUFDLFVBQVUsQ0FBQztLQUNmLEdBQUcsQ0FBQyxFQUFFLEtBQUs7TUFDVixFQUFFO01BQ0YsS0FBSyxLQUFLLGdCQUFnQjtNQUMxQixPQUFPLEdBQUcsNkJBQTZCLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxnQkFBZ0IsQ0FBQyxFQUFFLFlBQVksQ0FBQztNQUNyRixTQUFTLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO0tBQ2pELENBQUMsQ0FBQztLQUNGLEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxTQUFTO1lBQ3BCLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO1lBQ3RDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO09BQzNDLENBQUMsQ0FBQztLQUNKLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7TUFDMUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxxQkFBcUIsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBQztDQUNwRjs7QUFFRCxNQUFNLGlCQUFpQixRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRTtBQUN0RixNQUFNLHFCQUFxQixJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxlQUFlLEVBQUM7O0FBRWxFLEFBQU8sU0FBUyxtQkFBbUIsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFO0VBQ2xELEdBQUc7S0FDQSxHQUFHLENBQUMsVUFBVSxDQUFDO0tBQ2YsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLEtBQUssY0FBYztNQUN4QixPQUFPLEdBQUcsUUFBUSxDQUFDLEVBQUUsRUFBRSxjQUFjLENBQUM7TUFDdEMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztLQUMvQyxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLEtBQUssRUFBRSxPQUFPLENBQUMsU0FBUztZQUNwQixpQkFBaUIsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztZQUN0QyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztPQUMzQyxDQUFDLENBQUM7S0FDSixPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO01BQzFCLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcscUJBQXFCLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUM7Q0FDcEY7O0FDeEpNLFNBQVMsV0FBVyxDQUFDLE9BQU8sRUFBRSxjQUFjLEVBQUU7RUFDbkQsTUFBTSxnQkFBZ0IsSUFBSSxDQUFDLENBQUMsYUFBYSxFQUFFLE9BQU8sRUFBQztFQUNuRCxNQUFNLGdCQUFnQixJQUFJLENBQUMsQ0FBQyxhQUFhLEVBQUUsT0FBTyxFQUFDO0VBQ25ELE1BQU0sWUFBWSxRQUFRLENBQUMsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFDO0VBQy9DLE1BQU0sT0FBTyxhQUFhLENBQUMsQ0FBQyxPQUFPLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLEVBQUM7RUFDekQsTUFBTSxPQUFPLGFBQWEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsRUFBQztFQUN6RCxNQUFNLE9BQU8sYUFBYSxDQUFDLENBQUMsT0FBTyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBQzs7RUFFckQsTUFBTSxPQUFPLEdBQUc7SUFDZCxNQUFNLElBQUksd0RBQXdEO0lBQ2xFLFFBQVEsRUFBRSxxQ0FBcUM7SUFDaEQ7O0VBRUQsSUFBSSxDQUFDLFlBQVksU0FBUyxhQUFZO0VBQ3RDLElBQUksQ0FBQyxRQUFRLGFBQWEsR0FBRTs7O0VBRzVCLE9BQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDbkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtNQUNsQixFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUM7O0VBRXhDLE9BQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDbkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtNQUNsQixFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsWUFBWSxVQUFVO1VBQzdCLE1BQU07VUFDTixpQkFBaUI7T0FDcEIsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFDOztFQUV4QixPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQ25CLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7TUFDbEIsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLFlBQVksVUFBVTtVQUM3QixRQUFRO1VBQ1IsY0FBYztPQUNqQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUM7OztFQUd4QixjQUFjLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxJQUFJO0lBQzFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLE1BQU07SUFDNUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFROztJQUV4QixJQUFJLHNCQUFzQixJQUFJLE1BQUs7SUFDbkMsSUFBSSxzQkFBc0IsSUFBSSxNQUFLO0lBQ25DLElBQUksa0JBQWtCLFFBQVEsTUFBSztJQUNuQyxJQUFJLEVBQUUsRUFBRSxFQUFFLEVBQUUsR0FBRTs7SUFFZCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtNQUM3QixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQztNQUMzQixNQUFNLG9CQUFvQixHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssV0FBVTs7TUFFakYsSUFBSSxFQUFFLFlBQVksVUFBVSxFQUFFO1FBQzVCLEVBQUUsR0FBRyxJQUFJLFNBQVMsQ0FBQyxjQUFjLEVBQUM7UUFDbEMsSUFBSSxPQUFPLEdBQUcsUUFBUSxDQUFDLEVBQUUsRUFBRSxRQUFRLEVBQUM7UUFDcEMsRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLE9BQU8sS0FBSyxNQUFNO1lBQ2pDLGNBQWM7WUFDZCxPQUFPLEVBQUM7UUFDWixFQUFFLEdBQUcsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBQztPQUN6QztXQUNJO1FBQ0gsRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLEVBQUM7UUFDekMsRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsaUJBQWlCLENBQUMsRUFBQztRQUNuRCxFQUFFLEdBQUcsUUFBUSxDQUFDLEVBQUUsRUFBRSxhQUFhLENBQUMsS0FBSyxLQUFLO1lBQ3RDLElBQUksU0FBUyxDQUFDLGNBQWMsQ0FBQztZQUM3QixJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxFQUFDO09BQy9DOztNQUVELElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQyxXQUFXLEdBQUU7TUFDekIsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDLFdBQVcsR0FBRTtNQUN6QixJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUMsV0FBVyxHQUFFOztNQUV6QixzQkFBc0IsR0FBRyxFQUFFLENBQUMsYUFBYSxLQUFLLGNBQWMsS0FBSyxFQUFFLENBQUMsUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFLEVBQUM7TUFDbkgsc0JBQXNCLEdBQUcsRUFBRSxDQUFDLGFBQWEsS0FBSyxtQkFBa0I7TUFDaEUsa0JBQWtCLE9BQU8sRUFBRSxDQUFDLGFBQWEsS0FBSyxlQUFjOztNQUU1RCxJQUFJLHNCQUFzQixJQUFJLENBQUMsc0JBQXNCO1FBQ25ELFNBQVMsQ0FBQyxZQUFZLEVBQUM7V0FDcEIsSUFBSSxzQkFBc0IsSUFBSSxDQUFDLHNCQUFzQjtRQUN4RCxTQUFTLENBQUMsWUFBWSxFQUFDOztNQUV6QixNQUFNLE1BQU0sR0FBRyxzQkFBc0IsR0FBRyxFQUFFLEdBQUcsR0FBRTtNQUMvQyxNQUFNLE1BQU0sR0FBRyxzQkFBc0IsR0FBRyxFQUFFLEdBQUcsR0FBRTtNQUMvQyxNQUFNLE1BQU0sR0FBRyxrQkFBa0IsR0FBRyxFQUFFLEdBQUcsR0FBRTs7TUFFM0MsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFDO01BQzdCLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBQztNQUM3QixPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUM7O01BRTdCLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQzs0QkFDVixFQUFFLE1BQU0sQ0FBQztpQkFDcEIsRUFBRSxzQkFBc0IsSUFBSSxvQkFBb0IsR0FBRyxhQUFhLEdBQUcsTUFBTSxDQUFDO01BQ3JGLENBQUMsRUFBQzs7TUFFRixnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7NEJBQ1YsRUFBRSxNQUFNLENBQUM7aUJBQ3BCLEVBQUUsc0JBQXNCLElBQUksb0JBQW9CLEdBQUcsYUFBYSxHQUFHLE1BQU0sQ0FBQztNQUNyRixDQUFDLEVBQUM7O01BRUYsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQzs0QkFDTixFQUFFLE1BQU0sQ0FBQztpQkFDcEIsRUFBRSxrQkFBa0IsSUFBSSxvQkFBb0IsR0FBRyxhQUFhLEdBQUcsTUFBTSxDQUFDO01BQ2pGLENBQUMsRUFBQztLQUNIO1NBQ0k7OztNQUdILGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDbEIsRUFBRSxJQUFJLENBQUMsWUFBWSxJQUFJLFlBQVksR0FBRyxPQUFPLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUM7O01BRXRGLENBQUMsRUFBQzs7TUFFRixnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBQ2xCLEVBQUUsSUFBSSxDQUFDLFlBQVksSUFBSSxZQUFZLEdBQUcsT0FBTyxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDOztNQUV0RixDQUFDLEVBQUM7O01BRUYsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDZCxFQUFFLElBQUksQ0FBQyxZQUFZLElBQUksUUFBUSxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQzs7TUFFbEYsQ0FBQyxFQUFDO0tBQ0g7R0FDRixFQUFDOztFQUVGLE1BQU0sU0FBUyxHQUFHO0lBQ2hCLElBQUksQ0FBQyxhQUFZOztFQUVuQixNQUFNLFNBQVMsR0FBRyxHQUFHLElBQUk7SUFDdkIsWUFBWSxHQUFFO0lBQ2QsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFHOztJQUV2QixJQUFJLEdBQUcsS0FBSyxZQUFZO01BQ3RCLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLE9BQU07SUFDdEQsSUFBSSxHQUFHLEtBQUssWUFBWTtNQUN0QixnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxPQUFNO0lBQ3RELElBQUksR0FBRyxLQUFLLFFBQVE7TUFDbEIsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLE9BQU07SUFDbkQ7O0VBRUQsTUFBTSxZQUFZLEdBQUc7SUFDbkIsQ0FBQyxnQkFBZ0IsRUFBRSxnQkFBZ0IsRUFBRSxZQUFZLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztNQUNsRSxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsUUFBUSxFQUFDOztFQUU5QyxPQUFPO0lBQ0wsU0FBUztJQUNULFNBQVM7SUFDVCxVQUFVLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSztNQUN4QixnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JFLFVBQVUsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLO01BQ3hCLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7R0FDdEU7Q0FDRjs7QUNySkQsTUFBTXBDLFlBQVUsR0FBRyxvQkFBb0I7R0FDcEMsS0FBSyxDQUFDLEdBQUcsQ0FBQztHQUNWLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLO0lBQ3BCLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsRUFBRSxDQUFDO0dBQ0osU0FBUyxDQUFDLENBQUMsRUFBQzs7QUFFZixNQUFNaUMsZ0JBQWMsR0FBRyxDQUFDLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsWUFBWSxFQUFDOztBQUU5SyxBQUFPLFNBQVMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUU7RUFDckMsT0FBTyxDQUFDakMsWUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUNsQyxJQUFJLENBQUMsQ0FBQyxZQUFZLEVBQUUsTUFBTTs7SUFFMUIsQ0FBQyxDQUFDLGNBQWMsR0FBRTs7SUFFbEIsSUFBSSxhQUFhLEdBQUcsU0FBUyxFQUFFO1FBQzNCLElBQUksR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUM7O0lBRWpDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztNQUNqRCxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztVQUNsQixlQUFlLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxNQUFNLENBQUM7VUFDNUMsZUFBZSxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFDOztNQUU3QyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztVQUNsQixlQUFlLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxNQUFNLENBQUM7VUFDNUMsZUFBZSxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFDO0dBQ2hELEVBQUM7O0VBRUYsT0FBTyxDQUFDaUMsZ0JBQWMsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDdEMsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixJQUFJLElBQUksR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUM7SUFDakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztRQUMzQyxlQUFlLENBQUMsU0FBUyxFQUFFLEVBQUUsSUFBSSxFQUFFLFNBQVMsQ0FBQztRQUM3QyxlQUFlLENBQUMsU0FBUyxFQUFFLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBQztHQUNoRCxFQUFDOztFQUVGLE9BQU8sTUFBTTtJQUNYLE9BQU8sQ0FBQyxNQUFNLENBQUNqQyxZQUFVLEVBQUM7SUFDMUIsT0FBTyxDQUFDLE1BQU0sQ0FBQ2lDLGdCQUFjLEVBQUM7SUFDOUIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsRUFBQztHQUNyQztDQUNGOztBQUVELE1BQU0sZUFBZSxHQUFHLEVBQUUsSUFBSTtFQUM1QixJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxNQUFNO0lBQzFELEVBQUUsQ0FBQyxLQUFLLENBQUMsU0FBUyxHQUFHLDRCQUEyQjtFQUNsRCxPQUFPLEVBQUU7RUFDVjs7O0FBR0QsTUFBTSxPQUFPLEdBQUc7RUFDZCxTQUFTLEdBQUcsQ0FBQztFQUNiLEdBQUcsU0FBUyxDQUFDO0VBQ2IsR0FBRyxTQUFTLENBQUM7RUFDYixNQUFNLE1BQU0sQ0FBQztFQUNiLE1BQU0sTUFBTSxDQUFDO0VBQ2IsT0FBTyxLQUFLLENBQUM7RUFDZDs7QUFFRCxNQUFNLGtCQUFrQixHQUFHLEVBQUUsSUFBSSxRQUFRLENBQUMsRUFBRSxFQUFFLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUM7O0FBRXJFLEFBQU8sU0FBUyxlQUFlLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUU7RUFDcEQsR0FBRztLQUNBLEdBQUcsQ0FBQyxlQUFlLENBQUM7S0FDcEIsR0FBRyxDQUFDLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDckMsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLE1BQU0sV0FBVztNQUN0QixPQUFPLElBQUksa0JBQWtCLENBQUMsRUFBRSxDQUFDO01BQ2pDLFNBQVMsRUFBRSxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0tBQzFGLENBQUMsQ0FBQztLQUNGLEdBQUcsQ0FBQyxPQUFPLElBQUk7TUFDZCxJQUFJLE9BQU8sR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBQztNQUNsQyxJQUFJLEdBQUcsT0FBTyxJQUFJLEtBQUssU0FBUztVQUM1QixPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7VUFDbEMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFDOztNQUVoRCxPQUFPLElBQUk7UUFDVCxLQUFLLE1BQU07VUFDVCxJQUFJLE1BQU0sR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFDO1VBQ2pELE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7Y0FDbkQsQ0FBQyxFQUFFLEdBQUcsR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDO2NBQ25CLENBQUMsRUFBRSxHQUFHLEdBQUcsTUFBTSxDQUFDLEVBQUUsRUFBQztVQUN2QixLQUFLO1FBQ1AsS0FBSyxPQUFPO1VBQ1YsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztjQUNuRCxPQUFPO2NBQ1AsR0FBRTtVQUNOLEtBQUs7UUFDUCxLQUFLLFNBQVM7VUFDWixJQUFJLFdBQVcsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDO1VBQzVELElBQUksTUFBTSxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxHQUFHLEtBQUk7VUFDdEQsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztjQUNuRCxXQUFXLEdBQUcsTUFBTSxHQUFHLEdBQUc7Y0FDMUIsV0FBVyxHQUFHLE1BQU0sR0FBRyxJQUFHO1VBQzlCLEtBQUs7UUFDUDtVQUNFLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztjQUMvRSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUM7Y0FDZCxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUM7VUFDbEIsS0FBSztPQUNSOztNQUVELE9BQU8sQ0FBQyxLQUFLLEdBQUcsUUFBTztNQUN2QixPQUFPLE9BQU87S0FDZixDQUFDO0tBQ0QsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztNQUMxQixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUM7Q0FDdkM7O0FDekdELE1BQU1qQyxZQUFVLEdBQUcsb0JBQW9CO0dBQ3BDLEtBQUssQ0FBQyxHQUFHLENBQUM7R0FDVixNQUFNLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSztJQUNwQixDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25DLEVBQUUsQ0FBQztHQUNKLFNBQVMsQ0FBQyxDQUFDLEVBQUM7O0FBRWYsTUFBTWlDLGdCQUFjLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLFlBQVksRUFBQzs7QUFFOUssQUFBTyxTQUFTLFFBQVEsQ0FBQyxLQUFLLEVBQUU7RUFDOUIsSUFBSSxDQUFDLFlBQVksS0FBSyxLQUFLLENBQUMsU0FBUyxHQUFFO0VBQ3ZDLElBQUksQ0FBQyxRQUFRLFNBQVMsR0FBRTs7RUFFeEIsT0FBTyxDQUFDakMsWUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUNsQyxJQUFJLENBQUMsQ0FBQyxZQUFZLEVBQUUsTUFBTTs7SUFFMUIsQ0FBQyxDQUFDLGNBQWMsR0FBRTs7SUFFbEIsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLFFBQVE7UUFDN0IsSUFBSSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBQzs7SUFFakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztRQUMzQyxTQUFTLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDO1FBQzFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUM7R0FDL0MsRUFBQzs7RUFFRixPQUFPLENBQUNpQyxnQkFBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUN0QyxDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLElBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBQztJQUNqQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO1FBQzNDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDO1FBQzFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFDO0dBQy9DLEVBQUM7O0VBRUYsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDM0IsQ0FBQyxDQUFDLGNBQWMsR0FBRTs7SUFFbEIsSUFBSSxJQUFJLENBQUMsWUFBWSxJQUFJLFlBQVk7TUFDbkMsSUFBSSxDQUFDLFlBQVksR0FBRyxhQUFZO1NBQzdCLElBQUksSUFBSSxDQUFDLFlBQVksSUFBSSxZQUFZO01BQ3hDLElBQUksQ0FBQyxZQUFZLEdBQUcsU0FBUTs7SUFFOUIsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFDO0dBQ25DLEVBQUM7O0VBRUYsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDM0IsQ0FBQyxDQUFDLGNBQWMsR0FBRTs7SUFFbEIsSUFBSSxJQUFJLENBQUMsWUFBWSxJQUFJLFlBQVk7TUFDbkMsSUFBSSxDQUFDLFlBQVksR0FBRyxhQUFZO1NBQzdCLElBQUksSUFBSSxDQUFDLFlBQVksSUFBSSxRQUFRO01BQ3BDLElBQUksQ0FBQyxZQUFZLEdBQUcsYUFBWTs7SUFFbEMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFDO0dBQ25DLEVBQUM7O0VBRUYsTUFBTSxlQUFlLEdBQUcsR0FBRyxJQUFJO0lBQzdCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBRztJQUNuQixLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUM7SUFDbkM7O0VBRUQsTUFBTSxVQUFVLEdBQUcsTUFBTTtJQUN2QixPQUFPLENBQUMsTUFBTSxDQUFDakMsWUFBVSxFQUFDO0lBQzFCLE9BQU8sQ0FBQyxNQUFNLENBQUNpQyxnQkFBYyxFQUFDO0lBQzlCLE9BQU8sQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUM7SUFDckM7O0VBRUQsT0FBTztJQUNMLGVBQWU7SUFDZixVQUFVO0dBQ1g7Q0FDRjs7QUFFRCxBQUFPLFNBQVMsU0FBUyxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRTtFQUNyRCxHQUFHO0tBQ0EsR0FBRyxDQUFDLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUMvQixHQUFHLENBQUMsRUFBRSxJQUFJO01BQ1QsTUFBTSxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLEdBQUcsb0JBQW9CLENBQUMsRUFBRSxFQUFDOzs7TUFHbkUsT0FBTyxLQUFLLENBQUMsU0FBUyxFQUFFO1FBQ3RCLEtBQUssWUFBWTtVQUNmLE9BQU8sRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsS0FBSyxFQUFFLFVBQVUsQ0FBQyxLQUFLLEVBQUU7UUFDM0UsS0FBSyxZQUFZO1VBQ2YsT0FBTyxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxLQUFLLEVBQUUsVUFBVSxDQUFDLEtBQUssRUFBRTtRQUMzRSxLQUFLLFFBQVEsRUFBRTtVQUNiLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssRUFBRSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLGtCQUFpQjtVQUMvRCxPQUFPLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSyxFQUFFO1NBQ2xFO09BQ0Y7S0FDRixDQUFDO0tBQ0QsR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixNQUFNLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztRQUM5QyxRQUFRLEVBQUUsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztPQUNuRSxDQUFDLENBQUM7S0FDSixHQUFHLENBQUMsT0FBTyxJQUFJO01BQ2QsSUFBSSxJQUFJLEtBQUssR0FBRyxJQUFJLElBQUksS0FBSyxHQUFHLElBQUksSUFBSSxLQUFLLEdBQUc7UUFDOUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTSxHQUFHLEtBQUk7O01BRXhDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDLFFBQVE7VUFDcEMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTTtVQUN0QyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxPQUFNOztNQUUxQyxJQUFJLElBQUksS0FBSyxHQUFHLElBQUksSUFBSSxLQUFLLEdBQUcsSUFBSSxJQUFJLEtBQUssR0FBRyxFQUFFO1FBQ2hELElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFDO1FBQ3hELElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFDO09BQ3pEOztNQUVELE9BQU8sT0FBTztLQUNmLENBQUM7S0FDRCxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUs7TUFDakMsSUFBSSxLQUFLLEdBQUcsSUFBSSxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUM7TUFDdEQsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUMsV0FBVyxHQUFFOztNQUVyQyxJQUFJLEtBQUssSUFBSSxPQUFPLEVBQUUsS0FBSyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxFQUFDO01BQ2pFLElBQUksS0FBSyxJQUFJLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsRUFBQztLQUM1RSxFQUFDO0NBQ0w7O0FBRUQsQUFBTyxTQUFTLG9CQUFvQixDQUFDLEVBQUUsRUFBRTtFQUN2QyxJQUFJLEVBQUUsWUFBWSxVQUFVLEVBQUU7SUFDNUIsT0FBTyxPQUFPLEdBQUcsUUFBUSxDQUFDLEVBQUUsRUFBRSxRQUFRLEVBQUM7O0lBRXZDLE9BQU87TUFDTCxVQUFVLEVBQUU7UUFDVixLQUFLLEVBQUUsUUFBUTtRQUNmLEtBQUssRUFBRSxJQUFJLFNBQVMsQ0FBQyxPQUFPLEtBQUssTUFBTTtZQUNuQyxjQUFjO1lBQ2QsT0FBTyxDQUFDO09BQ2I7TUFDRCxVQUFVLEVBQUU7UUFDVixLQUFLLEVBQUUsTUFBTTtRQUNiLEtBQUssRUFBRSxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDO09BQzNDO01BQ0QsTUFBTSxFQUFFO1FBQ04sS0FBSyxFQUFFLFNBQVM7UUFDaEIsS0FBSyxFQUFFLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsU0FBUyxDQUFDLENBQUM7T0FDOUM7S0FDRjtHQUNGOztJQUVDLE9BQU87TUFDTCxVQUFVLEVBQUU7UUFDVixLQUFLLEVBQUUsT0FBTztRQUNkLEtBQUssRUFBRSxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDO09BQzVDO01BQ0QsVUFBVSxFQUFFO1FBQ1YsS0FBSyxFQUFFLGlCQUFpQjtRQUN4QixLQUFLLEVBQUUsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO09BQ3REO01BQ0QsTUFBTSxFQUFFO1FBQ04sS0FBSyxFQUFFLGFBQWE7UUFDcEIsS0FBSyxFQUFFLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsYUFBYSxDQUFDLENBQUM7T0FDbEQ7S0FDRjtDQUNKOztBQy9KRCxJQUFJLFVBQVM7O0FBRWIsQUFBTyxTQUFTLE1BQU0sR0FBRztFQUN2QixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxRQUFRLEVBQUM7RUFDbkMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFDO0VBQ3JDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsYUFBYSxFQUFDOztFQUVoRCxPQUFPLE1BQU07SUFDWCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxRQUFRLEVBQUM7SUFDcEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFDO0lBQ3RDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsYUFBYSxFQUFDO0lBQ25ELGFBQWEsR0FBRTtHQUNoQjtDQUNGOztBQUVELE1BQU0sUUFBUSxHQUFHLENBQUMsSUFBSTtFQUNwQixNQUFNLE1BQU0sR0FBRyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUM7RUFDekQsSUFBSSxXQUFXLENBQUMsTUFBTSxDQUFDLEVBQUUsTUFBTTtFQUMvQixhQUFhLENBQUMsTUFBTSxFQUFDO0VBQ3RCO0FBQ0QsQUEyQkE7QUFDQSxNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDO0VBQzNCLGFBQWEsR0FBRTs7QUFFakIsTUFBTSxhQUFhLEdBQUcsSUFBSSxJQUFJO0VBQzVCLElBQUksU0FBUyxFQUFFO0lBQ2IsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsS0FBSTtJQUM5QixTQUFTLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxxQkFBcUIsR0FBRTtHQUNoRDtPQUNJO0lBQ0gsU0FBUyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsa0JBQWtCLEVBQUM7SUFDdEQsU0FBUyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMscUJBQXFCLEdBQUU7O0lBRWpELFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBQztHQUNyQztFQUNGOztBQUVELE1BQU0sYUFBYSxHQUFHLElBQUksSUFBSTtFQUM1QixJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU07RUFDdEIsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTTtDQUNqQzs7QUN0RU0sU0FBUyxVQUFVLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtFQUNyQyxLQUFLLENBQUMsY0FBYyxFQUFDOztFQUVyQixPQUFPLE1BQU0sRUFBRTs7O0NBQ2hCLERDQUQsTUFBTWpDLFlBQVUsR0FBRyxvQkFBb0I7R0FDcEMsS0FBSyxDQUFDLEdBQUcsQ0FBQztHQUNWLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLO0lBQ3BCLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25FLEVBQUUsQ0FBQztHQUNKLFNBQVMsQ0FBQyxDQUFDLEVBQUM7QUFDZixBQUVBO0FBQ0EsQUFBTyxTQUFTLFFBQVEsR0FBRztFQUN6QixNQUFNLEtBQUssR0FBRztJQUNaLFFBQVEsRUFBRSxFQUFFO0lBQ2I7O0VBRUQsT0FBTyxDQUFDQSxZQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ2xDLElBQUksQ0FBQyxDQUFDLFlBQVksRUFBRSxNQUFNOztJQUUxQixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLGVBQWUsQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUM7R0FDN0MsRUFBQzs7RUFFRixNQUFNLGVBQWUsR0FBRyxHQUFHLElBQUk7SUFDN0IsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUN2QixFQUFFLENBQUMsUUFBUSxFQUFFLEVBQUM7O0lBRWhCLEtBQUssQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO01BQ3pCLFNBQVMsQ0FBQyxFQUFFLENBQUMsRUFBQztJQUNqQjs7RUFFRCxNQUFNLFVBQVUsR0FBRyxNQUFNO0lBQ3ZCLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFLEVBQUM7SUFDM0MsT0FBTyxDQUFDLE1BQU0sQ0FBQ0EsWUFBVSxFQUFDO0lBQzFCLE9BQU8sQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUM7SUFDckM7O0VBRUQsT0FBTztJQUNMLGVBQWU7SUFDZixVQUFVO0dBQ1g7Q0FDRjs7QUFFRCxBQUFPLFNBQVMsU0FBUyxDQUFDLEVBQUUsRUFBRTtFQUM1QixJQUFJLENBQUMsS0FBSyxHQUFHO0lBQ1gsS0FBSyxFQUFFO01BQ0wsSUFBSSxFQUFFLEtBQUs7TUFDWCxDQUFDLEVBQUUsQ0FBQztNQUNKLENBQUMsRUFBRSxDQUFDO0tBQ0w7SUFDRCxPQUFPLEVBQUU7TUFDUCxDQUFDLEVBQUUsQ0FBQztNQUNKLENBQUMsRUFBRSxDQUFDO0tBQ0w7SUFDRjs7RUFFRCxNQUFNLEtBQUssR0FBRyxNQUFNO0lBQ2xCLEVBQUUsQ0FBQyxLQUFLLENBQUMsVUFBVSxLQUFLLE9BQU07SUFDOUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLFNBQVMsT0FBTTs7SUFFOUIsRUFBRSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFDO0lBQ25ELEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBQztJQUMvQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUM7SUFDMUQ7O0VBRUQsTUFBTSxRQUFRLEdBQUcsTUFBTTtJQUNyQixFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsS0FBSyxLQUFJO0lBQzVCLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxTQUFTLEtBQUk7O0lBRTVCLEVBQUUsQ0FBQyxtQkFBbUIsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBQztJQUN0RCxFQUFFLENBQUMsbUJBQW1CLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUM7SUFDbEQsUUFBUSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFDO0lBQzdEOztFQUVELE1BQU0sV0FBVyxHQUFHLENBQUMsSUFBSTtJQUN2QixDQUFDLENBQUMsY0FBYyxHQUFFOztJQUVsQixNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsT0FBTTs7SUFFbkIsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsV0FBVTtJQUM5QixFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxXQUFVOztJQUVoQyxJQUFJLEVBQUUsWUFBWSxVQUFVLEVBQUU7TUFDNUIsTUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUM7O01BRTlDLE1BQU0sRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsU0FBUztVQUN0QixtQkFBbUIsQ0FBQyxTQUFTLENBQUM7VUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDOztNQUVULElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxFQUFDO01BQ3pCLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxFQUFDO0tBQzFCO1NBQ0k7TUFDSCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQUM7TUFDdEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFDO0tBQ3REOztJQUVELElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBTztJQUNuQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQU87SUFDbkMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLEtBQUk7SUFDL0I7O0VBRUQsTUFBTSxTQUFTLEdBQUcsQ0FBQyxJQUFJO0lBQ3JCLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsQ0FBQyxDQUFDLGVBQWUsR0FBRTs7SUFFbkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLE1BQUs7SUFDN0IsRUFBRSxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsS0FBSTs7SUFFMUIsSUFBSSxFQUFFLFlBQVksVUFBVSxFQUFFO01BQzVCLE1BQU0sU0FBUyxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFDOztNQUU5QyxNQUFNLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLFNBQVM7VUFDdEIsbUJBQW1CLENBQUMsU0FBUyxDQUFDO1VBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQzs7TUFFVCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sRUFBQztNQUMzQixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sRUFBQztLQUM1QjtTQUNJO01BQ0gsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUM7TUFDdEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUM7S0FDdEQ7SUFDRjs7RUFFRCxNQUFNLFdBQVcsR0FBRyxDQUFDLElBQUk7SUFDdkIsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixDQUFDLENBQUMsZUFBZSxHQUFFOztJQUVuQixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLE1BQU07O0lBRWxDLElBQUksRUFBRSxZQUFZLFVBQVUsRUFBRTtNQUM1QixFQUFFLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzVCLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQ3hELEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO09BQ3pELENBQUMsRUFBQztLQUNKO1NBQ0k7TUFDSCxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsS0FBSTtNQUM1RSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsS0FBSTtLQUM3RTtJQUNGOztFQUVELEtBQUssR0FBRTtFQUNQLEVBQUUsQ0FBQyxRQUFRLEdBQUcsU0FBUTs7RUFFdEIsT0FBTyxFQUFFO0NBQ1Y7O0FBRUQsQUFBTyxTQUFTLGVBQWUsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFO0VBQzlDLEdBQUc7S0FDQSxHQUFHLENBQUMsRUFBRSxJQUFJLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0tBQ2pDLEdBQUcsQ0FBQyxFQUFFLElBQUksZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDL0IsR0FBRyxDQUFDLEVBQUUsS0FBSztRQUNSLEVBQUU7UUFDRixHQUFHLDBCQUEwQixDQUFDLEVBQUUsRUFBRSxTQUFTLENBQUM7UUFDNUMsTUFBTSxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDO1FBQ3pELFFBQVEsRUFBRSxtQkFBbUIsQ0FBQyxFQUFFLEVBQUUsU0FBUyxDQUFDO0tBQy9DLENBQUMsQ0FBQztLQUNGLEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFRO1lBQ3RCLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU07WUFDaEMsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTTtPQUNyQyxDQUFDLENBQUM7S0FDSixPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsUUFBUSxDQUFDO01BQzdCLEVBQUUsWUFBWSxVQUFVO1VBQ3BCLGlCQUFpQixDQUFDLEVBQUUsRUFBRSxTQUFTLEVBQUUsUUFBUSxDQUFDO1VBQzFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsUUFBUSxHQUFHLElBQUksRUFBQztDQUMzQzs7QUFFRCxNQUFNLDBCQUEwQixHQUFHLENBQUMsRUFBRSxFQUFFLFNBQVMsS0FBSztFQUNwRCxJQUFJLEtBQUssRUFBRSxRQUFPOztFQUVsQixJQUFJLEVBQUUsWUFBWSxVQUFVLEVBQUU7SUFDNUIsTUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUM7O0lBRXRDLE1BQU0sRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsU0FBUztRQUN0QixtQkFBbUIsQ0FBQyxTQUFTLENBQUM7UUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDOztJQUVULEtBQUssS0FBSyxZQUFXO0lBQ3JCLE9BQU8sR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO1FBQzVELENBQUM7UUFDRCxFQUFDO0dBQ047T0FDSTtJQUNILE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEdBQUU7SUFDN0MsS0FBSyxHQUFHLENBQUMsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssUUFBUSxJQUFJLEtBQUssR0FBRyxPQUFNO0lBQzlELE9BQU8sR0FBRyxRQUFRLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBQzs7SUFFN0IsT0FBTyxLQUFLLE1BQU07UUFDZCxPQUFPLEdBQUcsQ0FBQztRQUNYLE9BQU8sR0FBRyxRQUFRLENBQUMsT0FBTyxFQUFFLEVBQUUsRUFBQztHQUNwQzs7RUFFRCxPQUFPLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRTtFQUMxQjs7QUFFRCxNQUFNLG1CQUFtQixHQUFHLFNBQVM7RUFDbkMsU0FBUyxDQUFDLFNBQVM7SUFDakIsU0FBUyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQzFCLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO0dBQ3ZCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztHQUNYLEdBQUcsQ0FBQyxHQUFHLElBQUksVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFDOztBQUU5QixNQUFNLGlCQUFpQixHQUFHLENBQUMsRUFBRSxFQUFFLFNBQVMsRUFBRSxRQUFRLEtBQUs7RUFDckQsTUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUM7RUFDdEMsTUFBTSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxTQUFTO01BQ3RCLG1CQUFtQixDQUFDLFNBQVMsQ0FBQztNQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUM7O0VBRVQsTUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztNQUM5RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQztNQUNsQixDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQzs7RUFFdEIsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFDO0VBQzFDOztBQUVELE1BQU0sbUJBQW1CLEdBQUcsQ0FBQyxFQUFFLEVBQUUsU0FBUztFQUN4QyxTQUFTLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFDOztBQUUzRCxNQUFNLGtCQUFrQixHQUFHLEVBQUUsSUFBSTtFQUMvQixJQUFJLEVBQUUsWUFBWSxXQUFXO0lBQzNCLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLFdBQVU7RUFDaEMsT0FBTyxFQUFFO0NBQ1Y7O0FDak9NLE1BQU0sV0FBVyxHQUFHO0VBQ3pCLENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxRQUFRO0lBQ3JCLElBQUksU0FBU3FDLE1BQVk7SUFDekIsS0FBSyxRQUFRLFFBQVE7SUFDckIsV0FBVyxFQUFFLG9DQUFvQztJQUNqRCxXQUFXLEVBQUUsQ0FBQzs7OzRCQUdVLEVBQUUsTUFBTSxDQUFDOzt3QkFFYixDQUFDO0dBQ3RCO0VBQ0QsQ0FBQyxFQUFFO0lBQ0QsSUFBSSxTQUFTLFdBQVc7SUFDeEIsSUFBSSxTQUFTQyxTQUFlO0lBQzVCLEtBQUssUUFBUSxTQUFTO0lBQ3RCLFdBQVcsRUFBRSxpREFBaUQ7SUFDOUQsV0FBVyxFQUFFLENBQUM7Ozs0QkFHVSxFQUFFLE1BQU0sQ0FBQzs7d0JBRWIsQ0FBQztHQUN0QjtFQUNELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxlQUFlO0lBQzVCLElBQUksU0FBU0MsYUFBbUI7SUFDaEMsS0FBSyxRQUFRLGVBQWU7SUFDNUIsV0FBVyxFQUFFLCtDQUErQztJQUM1RCxXQUFXLEVBQUUsQ0FBQzs7OzRCQUdVLEVBQUUsTUFBTSxDQUFDOzt3QkFFYixDQUFDO0dBQ3RCO0VBQ0QsQ0FBQyxFQUFFO0lBQ0QsSUFBSSxTQUFTLE1BQU07SUFDbkIsSUFBSSxTQUFTQyxJQUFVO0lBQ3ZCLEtBQUssUUFBUSxNQUFNO0lBQ25CLFdBQVcsRUFBRSxzRUFBc0U7SUFDbkYsV0FBVyxFQUFFLENBQUM7Ozs7Ozs7Ozs7Ozs7d0JBYU0sQ0FBQztHQUN0Qjs7Ozs7OztFQU9ELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxRQUFRO0lBQ3JCLElBQUksU0FBU0MsTUFBWTtJQUN6QixLQUFLLFFBQVEsUUFBUTtJQUNyQixXQUFXLEVBQUUsOEVBQThFO0lBQzNGLFdBQVcsRUFBRSxDQUFDOzs7Ozs7OzRCQU9VLEVBQUUsTUFBTSxDQUFDOzs7OzRCQUlULEVBQUUsT0FBTyxDQUFDOzt3QkFFZCxDQUFDO0dBQ3RCO0VBQ0QsQ0FBQyxFQUFFO0lBQ0QsSUFBSSxTQUFTLFNBQVM7SUFDdEIsSUFBSSxTQUFTQyxPQUFhO0lBQzFCLEtBQUssUUFBUSxTQUFTO0lBQ3RCLFdBQVcsRUFBRSxDQUFDLDRFQUE0RSxDQUFDO0lBQzNGLFdBQVcsRUFBRSxDQUFDOzs7Ozs7OzRCQU9VLEVBQUUsTUFBTSxDQUFDOzs7OzRCQUlULEVBQUUsT0FBTyxDQUFDOzt3QkFFZCxDQUFDO0dBQ3RCOzs7Ozs7O0VBT0QsQ0FBQyxFQUFFO0lBQ0QsSUFBSSxTQUFTLE9BQU87SUFDcEIsSUFBSSxTQUFTQyxLQUFXO0lBQ3hCLEtBQUssUUFBUSxlQUFlO0lBQzVCLFdBQVcsRUFBRSxDQUFDLDREQUE0RCxDQUFDO0lBQzNFLFdBQVcsRUFBRSxDQUFDOzs7Ozs7Ozs7Ozs0QkFXVSxFQUFFLE9BQU8sQ0FBQzs7d0JBRWQsQ0FBQztHQUN0QjtFQUNELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxVQUFVO0lBQ3ZCLElBQUksU0FBU0MsUUFBYztJQUMzQixLQUFLLFFBQVEsV0FBVztJQUN4QixXQUFXLEVBQUUsQ0FBQyxrRUFBa0UsQ0FBQztJQUNqRixXQUFXLEVBQUUsQ0FBQzs7Ozs7Ozs7Ozs7NEJBV1UsRUFBRSxPQUFPLENBQUM7Ozs7NEJBSVYsRUFBRSxPQUFPLENBQUM7O3dCQUVkLENBQUM7R0FDdEI7RUFDRCxDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsV0FBVztJQUN4QixJQUFJLFNBQVNDLFNBQWU7SUFDNUIsS0FBSyxRQUFRLFFBQVE7SUFDckIsV0FBVyxFQUFFLENBQUMsd0RBQXdELENBQUM7SUFDdkUsV0FBVyxFQUFFLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs0QkFlVSxFQUFFLE9BQU8sQ0FBQzs7d0JBRWQsQ0FBQztHQUN0Qjs7Ozs7OztFQU9ELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxVQUFVO0lBQ3ZCLElBQUksU0FBU0MsUUFBYztJQUMzQixLQUFLLFFBQVEsVUFBVTtJQUN2QixXQUFXLEVBQUUscURBQXFEO0lBQ2xFLFdBQVcsRUFBRSxDQUFDOzs7Ozs7Ozs7d0JBU00sQ0FBQztHQUN0QjtFQUNELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxNQUFNO0lBQ25CLElBQUksU0FBU0MsSUFBVTtJQUN2QixLQUFLLFFBQVEsYUFBYTtJQUMxQixXQUFXLEVBQUUsMkRBQTJEO0lBQ3hFLFdBQVcsRUFBRSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRCQW1CVSxFQUFFLE9BQU8sQ0FBQzs7d0JBRWQsQ0FBQztHQUN0QjtFQUNELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxNQUFNO0lBQ25CLElBQUksU0FBU0MsSUFBVTtJQUN2QixLQUFLLFFBQVEsV0FBVztJQUN4QixXQUFXLEVBQUUsd0RBQXdEO0lBQ3JFLFdBQVcsRUFBRSxFQUFFO0dBQ2hCOzs7Ozs7O0VBT0QsQ0FBQyxFQUFFO0lBQ0QsSUFBSSxTQUFTLFFBQVE7SUFDckIsSUFBSSxTQUFTQyxNQUFZO0lBQ3pCLEtBQUssUUFBUSxRQUFRO0lBQ3JCLFdBQVcsRUFBRSxxR0FBcUc7SUFDbEgsV0FBVyxFQUFFLEVBQUU7R0FDaEI7Q0FDRjs7QUN0T2MsTUFBTSxNQUFNLFNBQVMsV0FBVyxDQUFDO0VBQzlDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTs7SUFFUCxJQUFJLENBQUMsYUFBYSxJQUFJLFlBQVc7SUFDakMsSUFBSSxDQUFDLFlBQVksS0FBSyxPQUFNO0lBQzVCLElBQUksQ0FBQyxPQUFPLFVBQVUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsRUFBQztHQUMxRDs7RUFFRCxpQkFBaUIsR0FBRztJQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTO01BQ3pCLElBQUksQ0FBQyxLQUFLLEdBQUU7O0lBRWQsSUFBSSxDQUFDLGNBQWMsR0FBRyxVQUFVLEdBQUU7SUFDbEMsSUFBSSxDQUFDLFdBQVcsTUFBTSxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFDO0lBQ3BFLHFCQUFxQixDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUM7R0FDM0M7O0VBRUQsb0JBQW9CLEdBQUc7SUFDckIsSUFBSSxDQUFDLGtCQUFrQixHQUFFO0lBQ3pCLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxHQUFFO0lBQ2hDLE9BQU8sQ0FBQyxNQUFNO01BQ1osTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEdBQUc7UUFDakQsTUFBTSxJQUFJLEdBQUcsR0FBRyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUM7SUFDN0IsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFDO0dBQy9COztFQUVELEtBQUssR0FBRztJQUNOLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUU7O0lBRXRDLENBQUMsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztNQUM1QyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsZUFBZSxFQUFFLEVBQUM7O0lBRTVELE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztNQUN0RCxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSTtRQUNoQixDQUFDLENBQUMsY0FBYyxHQUFFO1FBQ2xCLElBQUksQ0FBQyxZQUFZO1VBQ2YsQ0FBQyxDQUFDLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztVQUNsRDtPQUNGLENBQUM7TUFDSDs7SUFFRCxPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7TUFDcEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU87UUFDN0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sS0FBSyxNQUFNO1lBQ3RDLE9BQU87WUFDUCxNQUFNLEVBQUM7O0lBRWYsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDO0dBQzlEOztFQUVELFlBQVksQ0FBQyxFQUFFLEVBQUU7SUFDZixJQUFJLE9BQU8sRUFBRSxLQUFLLFFBQVE7TUFDeEIsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBQzs7SUFFaEQsSUFBSSxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNOztJQUVqRixJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7TUFDcEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksRUFBQztNQUMxQyxJQUFJLENBQUMsa0JBQWtCLEdBQUU7S0FDMUI7O0lBRUQsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFDO0lBQzVCLElBQUksQ0FBQyxXQUFXLEdBQUcsR0FBRTtJQUNyQixJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRTtHQUN4Qjs7RUFFRCxNQUFNLEdBQUc7SUFDUCxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzs7O1FBR2QsRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQztVQUNsRSxFQUFFLElBQUksQ0FBQzswQkFDUyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMseUJBQXlCLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLEVBQUUsR0FBRyxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxHQUFHLElBQUksR0FBRyxDQUFDO1lBQ2pKLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQztZQUNaLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUM7O1FBRW5DLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQzs7Ozs7VUFLSixFQUFFQyxVQUFnQixDQUFDOzs7O1VBSW5CLEVBQUVDLGdCQUFzQixDQUFDOzs7O1VBSXpCLEVBQUVDLFlBQWtCLENBQUM7OztJQUczQixDQUFDO0dBQ0Y7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsT0FBTyxDQUFDOztRQUVKLEVBQUV2RCxHQUFNLENBQUM7O0lBRWIsQ0FBQztHQUNGOztFQUVELE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxXQUFXLENBQUMsRUFBRTtJQUNwRCxPQUFPLENBQUM7YUFDQyxFQUFFLElBQUksQ0FBQzs7b0JBRUEsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQzs7O2NBRzNELEVBQUUsS0FBSyxDQUFDOzJCQUNLLEVBQUUsR0FBRyxDQUFDOztlQUVsQixFQUFFLFdBQVcsQ0FBQztZQUNqQixFQUFFLFdBQVcsQ0FBQzs7OztJQUl0QixDQUFDO0dBQ0Y7O0VBRUQsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLGtCQUFrQixHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFDO0dBQ3hEOztFQUVELE1BQU0sR0FBRztJQUNQLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBQztHQUN0RDs7RUFFRCxPQUFPLEdBQUc7SUFDUixJQUFJLENBQUMsa0JBQWtCLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUM7R0FDdkQ7O0VBRUQsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFDO0dBQ3BEOztFQUVELElBQUksR0FBRztJQUNMLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFDO0lBQzlDLElBQUksQ0FBQyxrQkFBa0IsR0FBRztNQUN4QixJQUFJLENBQUMsY0FBYyxDQUFDLHNCQUFzQixDQUFDLFFBQVEsRUFBQztHQUN2RDs7RUFFRCxLQUFLLEdBQUc7SUFDTixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUM7R0FDcEQ7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFDO0dBQzFFOztFQUVELFNBQVMsR0FBRztJQUNWLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBQztHQUN6RDs7RUFFRCxRQUFRLEdBQUc7SUFDVCxJQUFJLE9BQU8sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBQztJQUN4QyxJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUM7SUFDN0QsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU07TUFDOUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFDO01BQ25FLE9BQU8sQ0FBQyxVQUFVLEdBQUU7TUFDckI7R0FDRjs7RUFFRCxTQUFTLEdBQUc7SUFDVixJQUFJLENBQUMsa0JBQWtCLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUM7R0FDdkQ7O0VBRUQsYUFBYSxHQUFHO0lBQ2QsSUFBSSxDQUFDLGtCQUFrQixHQUFHLGFBQWEsR0FBRTtHQUMxQzs7RUFFRCxNQUFNLEdBQUc7SUFDUCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxHQUFFO0dBQ25DOztFQUVELFVBQVUsR0FBRztJQUNYLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxVQUFVLEdBQUU7R0FDdkM7O0VBRUQsUUFBUSxHQUFHO0lBQ1QsSUFBSSxPQUFPLEdBQUcsUUFBUSxHQUFFO0lBQ3hCLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBQztJQUM3RCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTTtNQUM5QixJQUFJLENBQUMsY0FBYyxDQUFDLHNCQUFzQixDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUM7TUFDbkUsT0FBTyxDQUFDLFVBQVUsR0FBRTtNQUNyQjtHQUNGOztFQUVELElBQUksVUFBVSxHQUFHO0lBQ2YsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJO0dBQ3JDOztFQUVELElBQUksV0FBVyxDQUFDLEdBQUcsRUFBRTtJQUNuQixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUc7SUFDdkIsSUFBSSxDQUFDLEtBQUssR0FBRTtHQUNiO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDOztBQzFOeEMsSUFBSSxjQUFjLElBQUksUUFBUSxDQUFDLGVBQWU7RUFDNUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLEdBQUU7O0FBRTNELElBQUksT0FBTyxLQUFLLE1BQU07RUFDcEIsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztLQUNsQyxPQUFPLENBQUMsSUFBSSxJQUFJO01BQ2YsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFDO01BQ3pELElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBQztLQUN6RCxDQUFDIn0=
