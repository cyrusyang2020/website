[
  ...document.getElementsByTagName('tool-pallete'),
].forEach(el => el.remove())
