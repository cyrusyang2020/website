const sugar = {
  on: function(names, fn) {
    names
      .split(' ')
      .forEach(name =>
        this.addEventListener(name, fn));
    return this
  },
  off: function(names, fn) {
    names
      .split(' ')
      .forEach(name =>
        this.removeEventListener(name, fn));
    return this
  },
  attr: function(attr, val) {
    if (val === undefined) return this.getAttribute(attr)

    val == null
      ? this.removeAttribute(attr)
      : this.setAttribute(attr, val || '');
      
    return this
  }
};

function $(query, $context = document) {
  let $nodes = query instanceof NodeList || Array.isArray(query)
    ? query
    : query instanceof HTMLElement || query instanceof SVGElement
      ? [query]
      : $context.querySelectorAll(query);

  if (!$nodes.length) $nodes = [];

  return Object.assign(
    [...$nodes].map($el => Object.assign($el, sugar)), 
    {
      on: function(names, fn) {
        this.forEach($el => $el.on(names, fn));
        return this
      },
      off: function(names, fn) {
        this.forEach($el => $el.off(names, fn));
        return this
      },
      attr: function(attrs, val) {
        if (typeof attrs === 'string' && val === undefined)
          return this[0].attr(attrs)

        else if (typeof attrs === 'object') 
          this.forEach($el =>
            Object.entries(attrs)
              .forEach(([key, val]) =>
                $el.attr(key, val)));

        else if (typeof attrs == 'string' && (val || val == null || val == ''))
          this.forEach($el => $el.attr(attrs, val));

        return this
      }
    }
  )
}

/*!
 * hotkeys-js v3.3.5
 * A simple micro-library for defining and dispatching keyboard shortcuts. It has no dependencies.
 * 
 * Copyright (c) 2018 kenny wong <wowohoo@qq.com>
 * http://jaywcjlove.github.io/hotkeys
 * 
 * Licensed under the MIT license.
 */

var isff = typeof navigator !== 'undefined' ? navigator.userAgent.toLowerCase().indexOf('firefox') > 0 : false;

// 绑定事件
function addEvent(object, event, method) {
  if (object.addEventListener) {
    object.addEventListener(event, method, false);
  } else if (object.attachEvent) {
    object.attachEvent('on' + event, function () {
      method(window.event);
    });
  }
}

// 修饰键转换成对应的键码
function getMods(modifier, key) {
  var mods = key.slice(0, key.length - 1);
  for (var i = 0; i < mods.length; i++) {
    mods[i] = modifier[mods[i].toLowerCase()];
  }return mods;
}

// 处理传的key字符串转换成数组
function getKeys(key) {
  if (!key) key = '';

  key = key.replace(/\s/g, ''); // 匹配任何空白字符,包括空格、制表符、换页符等等
  var keys = key.split(','); // 同时设置多个快捷键，以','分割
  var index = keys.lastIndexOf('');

  // 快捷键可能包含','，需特殊处理
  for (; index >= 0;) {
    keys[index - 1] += ',';
    keys.splice(index, 1);
    index = keys.lastIndexOf('');
  }

  return keys;
}

// 比较修饰键的数组
function compareArray(a1, a2) {
  var arr1 = a1.length >= a2.length ? a1 : a2;
  var arr2 = a1.length >= a2.length ? a2 : a1;
  var isIndex = true;

  for (var i = 0; i < arr1.length; i++) {
    if (arr2.indexOf(arr1[i]) === -1) isIndex = false;
  }
  return isIndex;
}

var _keyMap = { // 特殊键
  backspace: 8,
  tab: 9,
  clear: 12,
  enter: 13,
  return: 13,
  esc: 27,
  escape: 27,
  space: 32,
  left: 37,
  up: 38,
  right: 39,
  down: 40,
  del: 46,
  delete: 46,
  ins: 45,
  insert: 45,
  home: 36,
  end: 35,
  pageup: 33,
  pagedown: 34,
  capslock: 20,
  '⇪': 20,
  ',': 188,
  '.': 190,
  '/': 191,
  '`': 192,
  '-': isff ? 173 : 189,
  '=': isff ? 61 : 187,
  ';': isff ? 59 : 186,
  '\'': 222,
  '[': 219,
  ']': 221,
  '\\': 220
};

var _modifier = { // 修饰键
  '⇧': 16,
  shift: 16,
  '⌥': 18,
  alt: 18,
  option: 18,
  '⌃': 17,
  ctrl: 17,
  control: 17,
  '⌘': isff ? 224 : 91,
  cmd: isff ? 224 : 91,
  command: isff ? 224 : 91
};
var _downKeys = []; // 记录摁下的绑定键
var modifierMap = {
  16: 'shiftKey',
  18: 'altKey',
  17: 'ctrlKey'
};
var _mods = { 16: false, 18: false, 17: false };
var _handlers = {};

// F1~F12 特殊键
for (var k = 1; k < 20; k++) {
  _keyMap['f' + k] = 111 + k;
}

// 兼容Firefox处理
modifierMap[isff ? 224 : 91] = 'metaKey';
_mods[isff ? 224 : 91] = false;

var _scope = 'all'; // 默认热键范围
var isBindElement = false; // 是否绑定节点

// 返回键码
var code = function code(x) {
  return _keyMap[x.toLowerCase()] || x.toUpperCase().charCodeAt(0);
};

// 设置获取当前范围（默认为'所有'）
function setScope(scope) {
  _scope = scope || 'all';
}
// 获取当前范围
function getScope() {
  return _scope || 'all';
}
// 获取摁下绑定键的键值
function getPressedKeyCodes() {
  return _downKeys.slice(0);
}

// 表单控件控件判断 返回 Boolean
function filter(event) {
  var tagName = event.target.tagName || event.srcElement.tagName;
  // 忽略这些标签情况下快捷键无效
  return !(tagName === 'INPUT' || tagName === 'SELECT' || tagName === 'TEXTAREA');
}

// 判断摁下的键是否为某个键，返回true或者false
function isPressed(keyCode) {
  if (typeof keyCode === 'string') {
    keyCode = code(keyCode); // 转换成键码
  }
  return _downKeys.indexOf(keyCode) !== -1;
}

// 循环删除handlers中的所有 scope(范围)
function deleteScope(scope, newScope) {
  var handlers = void 0;
  var i = void 0;

  // 没有指定scope，获取scope
  if (!scope) scope = getScope();

  for (var key in _handlers) {
    if (Object.prototype.hasOwnProperty.call(_handlers, key)) {
      handlers = _handlers[key];
      for (i = 0; i < handlers.length;) {
        if (handlers[i].scope === scope) handlers.splice(i, 1);else i++;
      }
    }
  }

  // 如果scope被删除，将scope重置为all
  if (getScope() === scope) setScope(newScope || 'all');
}

// 清除修饰键
function clearModifier(event) {
  var key = event.keyCode || event.which || event.charCode;
  var i = _downKeys.indexOf(key);

  // 从列表中清除按压过的键
  if (i >= 0) _downKeys.splice(i, 1);

  // 修饰键 shiftKey altKey ctrlKey (command||metaKey) 清除
  if (key === 93 || key === 224) key = 91;
  if (key in _mods) {
    _mods[key] = false;

    // 将修饰键重置为false
    for (var k in _modifier) {
      if (_modifier[k] === key) hotkeys[k] = false;
    }
  }
}

// 解除绑定某个范围的快捷键
function unbind(key, scope) {
  var multipleKeys = getKeys(key);
  var keys = void 0;
  var mods = [];
  var obj = void 0;

  for (var i = 0; i < multipleKeys.length; i++) {
    // 将组合快捷键拆分为数组
    keys = multipleKeys[i].split('+');

    // 记录每个组合键中的修饰键的键码 返回数组
    if (keys.length > 1) mods = getMods(_modifier, keys);

    // 获取除修饰键外的键值key
    key = keys[keys.length - 1];
    key = key === '*' ? '*' : code(key);

    // 判断是否传入范围，没有就获取范围
    if (!scope) scope = getScope();

    // 如何key不在 _handlers 中返回不做处理
    if (!_handlers[key]) return;

    // 清空 handlers 中数据，
    // 让触发快捷键键之后没有事件执行到达解除快捷键绑定的目的
    for (var r = 0; r < _handlers[key].length; r++) {
      obj = _handlers[key][r];
      // 判断是否在范围内并且键值相同
      if (obj.scope === scope && compareArray(obj.mods, mods)) {
        _handlers[key][r] = {};
      }
    }
  }
}

// 对监听对应快捷键的回调函数进行处理
function eventHandler(event, handler, scope) {
  var modifiersMatch = void 0;

  // 看它是否在当前范围
  if (handler.scope === scope || handler.scope === 'all') {
    // 检查是否匹配修饰符（如果有返回true）
    modifiersMatch = handler.mods.length > 0;

    for (var y in _mods) {
      if (Object.prototype.hasOwnProperty.call(_mods, y)) {
        if (!_mods[y] && handler.mods.indexOf(+y) > -1 || _mods[y] && handler.mods.indexOf(+y) === -1) modifiersMatch = false;
      }
    }

    // 调用处理程序，如果是修饰键不做处理
    if (handler.mods.length === 0 && !_mods[16] && !_mods[18] && !_mods[17] && !_mods[91] || modifiersMatch || handler.shortcut === '*') {
      if (handler.method(event, handler) === false) {
        if (event.preventDefault) event.preventDefault();else event.returnValue = false;
        if (event.stopPropagation) event.stopPropagation();
        if (event.cancelBubble) event.cancelBubble = true;
      }
    }
  }
}

// 处理keydown事件
function dispatch(event) {
  var asterisk = _handlers['*'];
  var key = event.keyCode || event.which || event.charCode;

  // 搜集绑定的键
  if (_downKeys.indexOf(key) === -1) _downKeys.push(key);

  // Gecko(Firefox)的command键值224，在Webkit(Chrome)中保持一致
  // Webkit左右command键值不一样
  if (key === 93 || key === 224) key = 91;

  if (key in _mods) {
    _mods[key] = true;

    // 将特殊字符的key注册到 hotkeys 上
    for (var k in _modifier) {
      if (_modifier[k] === key) hotkeys[k] = true;
    }

    if (!asterisk) return;
  }

  // 将modifierMap里面的修饰键绑定到event中
  for (var e in _mods) {
    if (Object.prototype.hasOwnProperty.call(_mods, e)) {
      _mods[e] = event[modifierMap[e]];
    }
  }

  // 表单控件过滤 默认表单控件不触发快捷键
  if (!hotkeys.filter.call(this, event)) return;

  // 获取范围 默认为all
  var scope = getScope();

  // 对任何快捷键都需要做的处理
  if (asterisk) {
    for (var i = 0; i < asterisk.length; i++) {
      if (asterisk[i].scope === scope) eventHandler(event, asterisk[i], scope);
    }
  }
  // key 不在_handlers中返回
  if (!(key in _handlers)) return;

  for (var _i = 0; _i < _handlers[key].length; _i++) {
    // 找到处理内容
    eventHandler(event, _handlers[key][_i], scope);
  }
}

function hotkeys(key, option, method) {
  var keys = getKeys(key); // 需要处理的快捷键列表
  var mods = [];
  var scope = 'all'; // scope默认为all，所有范围都有效
  var element = document; // 快捷键事件绑定节点
  var i = 0;

  // 对为设定范围的判断
  if (method === undefined && typeof option === 'function') {
    method = option;
  }

  if (Object.prototype.toString.call(option) === '[object Object]') {
    if (option.scope) scope = option.scope; // eslint-disable-line
    if (option.element) element = option.element; // eslint-disable-line
  }

  if (typeof option === 'string') scope = option;

  // 对于每个快捷键进行处理
  for (; i < keys.length; i++) {
    key = keys[i].split('+'); // 按键列表
    mods = [];

    // 如果是组合快捷键取得组合快捷键
    if (key.length > 1) mods = getMods(_modifier, key);

    // 将非修饰键转化为键码
    key = key[key.length - 1];
    key = key === '*' ? '*' : code(key); // *表示匹配所有快捷键

    // 判断key是否在_handlers中，不在就赋一个空数组
    if (!(key in _handlers)) _handlers[key] = [];

    _handlers[key].push({
      scope: scope,
      mods: mods,
      shortcut: keys[i],
      method: method,
      key: keys[i]
    });
  }
  // 在全局document上设置快捷键
  if (typeof element !== 'undefined' && !isBindElement) {
    isBindElement = true;
    addEvent(element, 'keydown', function (e) {
      dispatch(e);
    });
    addEvent(element, 'keyup', function (e) {
      clearModifier(e);
    });
  }
}

var _api = {
  setScope: setScope,
  getScope: getScope,
  deleteScope: deleteScope,
  getPressedKeyCodes: getPressedKeyCodes,
  isPressed: isPressed,
  filter: filter,
  unbind: unbind
};
for (var a in _api) {
  if (Object.prototype.hasOwnProperty.call(_api, a)) {
    hotkeys[a] = _api[a];
  }
}

if (typeof window !== 'undefined') {
  var _hotkeys = window.hotkeys;
  hotkeys.noConflict = function (deep) {
    if (deep && window.hotkeys === hotkeys) {
      window.hotkeys = _hotkeys;
    }
    return hotkeys;
  };
  window.hotkeys = hotkeys;
}

var css = ":host {\n  --theme-bg: hsl(0,0%,100%);\n  --theme-color: hotpink;\n  --theme-icon_color: hsl(0,0%,20%);\n  --theme-icon_hover-bg: hsl(0,0%,95%);\n}\n\n:host {\n  position: fixed;\n  top: 0;\n  left: 0;\n  z-index: 2147483647;\n  font-size: 16px;\n  font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;\n}\n\n:host > ol {\n  display: flex;\n  flex-direction: column;\n  margin: 1em 0 0.5em 1em;\n  padding: 0;\n  list-style-type: none;\n  border-radius: 2em\n}\n\n:host > ol:not([colors]) {\n    box-shadow: 0 0.25em 0.5em hsla(0,0%,0%,10%);\n    background: var(--theme-bg);\n  }\n\n:host li {\n  height: 2.25em;\n  width: 2.25em;\n  margin: 0.05em 0.25em;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  position: relative;\n  border-radius: 50%\n}\n\n:host li:first-child { margin-top: 0.25em; }\n\n:host li:last-child { margin-bottom: 0.25em; }\n\n:host li[data-tool]:hover {\n      cursor: pointer;\n      background-color: var(--theme-icon_hover-bg);\n    }\n\n:host li[data-tool]:active {\n      background-color: hsl(0,0%,90%);\n    }\n\n:host li[data-active=true] > svg:not(.icon-cursor) {\n    fill: var(--theme-color);\n  }\n\n:host li[data-active=true] > .icon-cursor {\n    stroke: var(--theme-color);\n  }\n\n@media (max-height: 768px) {\n    :host li:nth-of-type(10) > aside, :host li:nth-of-type(11) > aside, :host li:nth-of-type(12) > aside, :host li:nth-of-type(13) > aside {\n      top: auto;\n    }\n  }\n\n:host li > aside {\n    overflow: hidden;\n    position: absolute;\n    direction: ltr;\n    text-align: left;\n    left: 3em;\n    top: 0;\n    z-index: -2;\n    pointer-events: none;\n    background: white;\n    color: hsl(0,0%,30%);\n    box-shadow: 0 0.1em 4.5em hsla(0,0%,0%,15%);\n    border-radius: 1em;\n\n    transition: opacity 0.3s ease, -webkit-transform 0.2s ease;\n\n    transition: opacity 0.3s ease, transform 0.2s ease;\n\n    transition: opacity 0.3s ease, transform 0.2s ease, -webkit-transform 0.2s ease;\n    opacity: 0;\n    -webkit-transform: translateX(-1em);\n            transform: translateX(-1em);\n    will-change: transform, opacity\n  }\n\n:host li > aside > figure {\n      margin: 0;\n      display: grid;\n    }\n\n:host li > aside figcaption {\n      padding: 1em;\n      display: grid;\n      grid-gap: 0.5em\n    }\n\n:host li > aside figcaption > h2, :host li > aside figcaption > p {\n        margin: 0;\n      }\n\n:host li > aside figcaption > h2 {\n        font-size: 1.5em;\n        line-height: 1.1;\n        margin-bottom: 0.5em;\n        display: grid;\n        grid-auto-flow: column;\n        justify-content: space-between;\n        align-items: center;\n      }\n\n:host li > aside figcaption > p {\n        font-size: 1em;\n        line-height: 1.5;\n        padding-right: 3em;\n      }\n\n:host li > aside figcaption [table] {\n        display: grid;\n        grid-gap: 0.5em\n      }\n\n:host li > aside figcaption [table] > div {\n          display: grid;\n          grid-auto-flow: column;\n          grid-template-columns: 1fr auto;\n          justify-content: space-between;\n        }\n\n:host li > aside [hotkey] {\n      border-radius: 5em;\n      height: 1.5em;\n      width: 1.5em;\n      display: inline-flex;\n      align-items: center;\n      justify-content: center;\n      border: 1px solid var(--theme-color);\n      color: var(--theme-color);\n      font-weight: 300;\n      font-size: 0.5em;\n      text-transform: uppercase;\n    }\n\n:host li:hover:not([data-tool=\"search\"]) > aside,\n  :host li[data-tool=\"search\"] > svg:hover + aside {\n    opacity: 1;\n    -webkit-transform: translateX(0);\n            transform: translateX(0);\n    transition-delay: 0.75s;\n  }\n\n:host li {\n\n  /*&:before {\n    content: attr(aria-label) \"\\A\" attr(aria-description);\n    position: absolute;\n    left: calc(100% + 0.75em);\n    top: -0.5em;\n    z-index: -2;\n    box-shadow: 0 0.1em 0.1em hsla(0,0%,0%,20%);\n    border-radius: 2em;\n    height: calc(100% + 1em);\n    display: inline-flex;\n    align-items: center;\n    padding: 0 1.5em 0 3.5em;\n    background: var(--theme-color);\n    color: white;\n    font-weight: 300;\n    font-size: 0.9em;\n    white-space: pre;\n    line-height: 1.3;\n    transition: opacity 0.3s ease, transform 0.2s ease;\n    transform: translateX(-1em);\n    opacity: 0;\n    pointer-events: none;\n  }\n\n  &:after {\n    content: attr(aria-hotkey);\n    position: absolute;\n    left: calc(100% + 1.5em);\n    top: 1px;\n    z-index: -2;\n    border-radius: 5em;\n    height: 2.25em;\n    width: 2.25em;\n    display: inline-flex;\n    align-items: center;\n    justify-content: center;\n    background: white;\n    color: var(--theme-color);\n    font-weight: 300;\n    font-size: 0.9em;\n    transition: opacity 0.3s ease, transform 0.2s ease;\n    transform: translateX(-1em);\n    opacity: 0;\n    pointer-events: none;\n    text-transform: uppercase;\n  }\n\n  &:hover:before, &:hover:after {\n    transform: translateX(0);\n    opacity: 1;\n    pointer-events: initial;\n  }*/\n}\n\n:host [colors] {\n  margin-top: 0;\n}\n\n:host [colors] > li {\n  overflow: hidden;\n  border-radius: 50%;\n  box-shadow: 0 0.25em 0.5em hsla(0,0%,0%,10%);\n  background: var(--theme-bg);\n  margin-bottom: 0.5em\n}\n\n:host [colors] > li:first-child {\n    margin-top: 0;\n  }\n\n:host [colors] li:hover:after {\n  top: 0;\n}\n\n:host li > svg {\n  width: 50%;\n  fill: var(--theme-icon_color);\n}\n\n:host li > svg.icon-cursor {\n  width: 35%;\n  fill: white;\n  stroke: var(--theme-icon_color);\n  stroke-width: 2px;\n}\n\n:host li[data-tool=\"search\"][data-active=\"true\"]:before {\n    -webkit-transform: translateX(-1em);\n            transform: translateX(-1em);\n    opacity: 0;\n  }\n\n:host li[data-tool=\"search\"] > .search {\n  position: absolute;\n  left: calc(100% - 1.25em);\n  top: 0;\n  height: 100%;\n  z-index: -1;\n  box-shadow: 0 0.25em 0.5em hsla(0,0%,0%,10%);\n  border-radius: 0 2em 2em 0;\n  overflow: hidden;\n}\n\n:host li[data-tool=\"search\"] > .search > input {\n  direction: ltr;\n  border: none;\n  font-size: 1em;\n  padding: 0.4em 0.4em 0.4em 2em;\n  outline: none;\n  height: 100%;\n  width: 250px;\n  box-sizing: border-box;\n  caret-color: hotpink\n}\n\n:host li[data-tool=\"search\"] > .search > input::-webkit-input-placeholder {\n    font-weight: lighter;\n    font-size: 0.8em;\n  }\n\n:host li[data-tool=\"search\"] > .search > input::-ms-input-placeholder {\n    font-weight: lighter;\n    font-size: 0.8em;\n  }\n\n:host li[data-tool=\"search\"] > .search > input::placeholder {\n    font-weight: lighter;\n    font-size: 0.8em;\n  }\n\n:host [colors] > li > svg {\n  position: relative;\n  top: -2px;\n}\n\n:host [colors] > li > svg > rect:last-child {\n  stroke: hsla(0,0%,0%,20%);\n  stroke-width: 0.5px;\n}\n\n:host input[type='color'] {\n  opacity: 0.01;\n  position: absolute;\n  top: 0; left: 0;\n  width: 100%; height: 100%;\n  z-index: 1;\n  box-sizing: border-box;\n  border: white;\n  padding: 0;\n}\n\n:host input[type='color']:focus {\n  outline: none;\n}\n\n:host input[type='color']::-webkit-color-swatch-wrapper {\n  padding: 0;\n}\n\n:host input[type='color']::-webkit-color-swatch {\n  border: none;\n}\n\n:host input[type='color'][value='']::-webkit-color-swatch {\n  background-color: transparent !important;\n  background-image: linear-gradient(155deg, #ffffff 0%,#ffffff 46%,#ff0000 46%,#ff0000 54%,#ffffff 55%,#ffffff 100%);\n}\n";

class Handles extends HTMLElement {
  
  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'open'});
  }

  connectedCallback() {
    window.addEventListener('resize', this.on_resize.bind(this));
  }
  disconnectedCallback() {
    window.removeEventListener('resize', this.on_resize);
  }

  on_resize() {
    window.requestAnimationFrame(() => {
      const node_label_id = this.$shadow.host.getAttribute('data-label-id');
      const [source_el] = $(`[data-label-id="${node_label_id}"]`);

      this.position = {
        node_label_id,
        boundingRect: source_el.getBoundingClientRect(),
      };
    });
  }

  set position({boundingRect, node_label_id}) {
    this.$shadow.innerHTML  = this.render(boundingRect, node_label_id);
  }

  render({ x, y, width, height, top, left }, node_label_id) {
    this.$shadow.host.setAttribute('data-label-id', node_label_id);
    return `
      ${this.styles({top,left})}
      <svg 
        class="pb-handles"
        width="${width}" height="${height}" 
        viewBox="0 0 ${width} ${height}" 
        version="1.1" xmlns="http://www.w3.org/2000/svg"
      >
        <rect stroke="hotpink" fill="none" width="100%" height="100%"></rect>
        <circle stroke="hotpink" fill="white" cx="0" cy="0" r="2"></circle>
        <circle stroke="hotpink" fill="white" cx="100%" cy="0" r="2"></circle>
        <circle stroke="hotpink" fill="white" cx="100%" cy="100%" r="2"></circle>
        <circle stroke="hotpink" fill="white" cx="0" cy="100%" r="2"></circle>
        <circle fill="hotpink" cx="${width/2}" cy="0" r="2"></circle>
        <circle fill="hotpink" cx="0" cy="${height/2}" r="2"></circle>
        <circle fill="hotpink" cx="${width/2}" cy="${height}" r="2"></circle>
        <circle fill="hotpink" cx="${width}" cy="${height/2}" r="2"></circle>
      </svg>
    `
  }

  styles({top,left}) {
    return `
      <style>
        :host > svg {
          position: absolute;
          top: ${top + window.scrollY}px;
          left: ${left}px;
          overflow: visible;
          pointer-events: none;
          z-index: 10010;
        }
      </style>
    `
  }
}

customElements.define('pb-handles', Handles);

class Label extends HTMLElement {
  
  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'open'});
  }

  connectedCallback() {
    $('a', this.$shadow).on('click mouseenter', this.dispatchQuery.bind(this));
    window.addEventListener('resize', this.on_resize.bind(this));
  }

  disconnectedCallback() {
    $('a', this.$shadow).off('click', this.dispatchQuery);
    window.removeEventListener('resize', this.on_resize);
  }

  on_resize() {
    window.requestAnimationFrame(() => {
      const node_label_id = this.$shadow.host.getAttribute('data-label-id');
      const [source_el]   = $(`[data-label-id="${node_label_id}"]`);

      if (!source_el) return

      this.position = {
        node_label_id,
        boundingRect: source_el.getBoundingClientRect(),
      };
    });
  }

  dispatchQuery(e) {
    this.$shadow.host.dispatchEvent(new CustomEvent('query', {
      bubbles: true,
      detail:   {
        text:       e.target.textContent,
        activator:  e.type,
      }
    }));
  }

  set text(content) {
    this._text = content;
  }

  set position({boundingRect, node_label_id}) {
    this.$shadow.innerHTML  = this.render(boundingRect, node_label_id);
  }

  set update({x,y}) {
    const label = this.$shadow.children[1];
    label.style.top  = y + window.scrollY + 'px';
    label.style.left = x - 1 + 'px';
  }

  render({ x, y, width, height, top, left }, node_label_id) {
    this.$shadow.host.setAttribute('data-label-id', node_label_id);

    return `
      ${this.styles({top,left,width})}
      <span>
        ${this._text}
      </span>
    `
  }

  styles({top,left,width}) {
    return `
      <style>
        :host {
          font-size: 16px;
        }

        :host > span {
          position: absolute;
          top: ${top + window.scrollY}px;
          left: ${left - 1}px;
          max-width: ${width + (window.innerWidth - left - width - 20)}px;
          z-index: 10000;
          transform: translateY(-100%);
          background: hsl(330, 100%, 71%);
          text-shadow: 0 0.5px 0 hsl(330, 100%, 61%);
          color: white;
          display: inline-flex;
          justify-content: center;
          font-size: 0.8em;
          font-weight: normal;
          font-family: sans-serif;
          white-space: nowrap;
          padding: 0.25em 0.4em 0.15em;
          line-height: 1.1;
        }

        :host a {
          text-decoration: none;
          color: inherit;
          cursor: pointer;
          text-overflow: ellipsis;
          overflow: hidden;
        }

        :host a:hover {
          text-decoration: underline;
          color: white;
        }
      </style>
    `
  }
}

customElements.define('pb-label', Label);

const desiredPropMap = {
  color:                'rgb(0, 0, 0)',
  backgroundColor:      'rgba(0, 0, 0, 0)',
  backgroundImage:      'none',
  backgroundSize:       'auto',
  backgroundPosition:   '0% 0%',
  // borderColor:          'rgb(0, 0, 0)',
  borderWidth:          '0px',
  borderRadius:         '0px',
  boxShadow:            'none',
  padding:              '0px',
  margin:               '0px',
  fontFamily:           '',
  fontSize:             '16px',
  fontWeight:           '400',
  textAlign:            'start',
  textShadow:           'none',
  textTransform:        'none',
  lineHeight:           'normal',
  letterSpacing:        'normal',
  display:              'block',
  alignItems:           'normal',
  justifyContent:       'normal',
  fill:                 'rgb(0, 0, 0)',
  stroke:               'none',
};

const desiredAccessibilityMap = [
  'role',
  'tabindex',
  'aria-*',
  'for',
  'alt',
  'title',
];

const largeWCAG2TextMap = [
  {
    fontSize: '24px',
    fontWeight: '0'
  },
  {
    fontSize: '18.5px',
    fontWeight: '700'
  }
];

const getStyle = (el, name) => {
  if (document.defaultView && document.defaultView.getComputedStyle) {
    name = name.replace(/([A-Z])/g, '-$1');
    name = name.toLowerCase();
    let s = document.defaultView.getComputedStyle(el, '');
    return s && s.getPropertyValue(name)
  } 
};

const getStyles = el => {
  const elStyleObject = el.style;
  const computedStyle = window.getComputedStyle(el, null);

  let desiredValues = [];

  for (prop in el.style)
    if (prop in desiredPropMap && desiredPropMap[prop] != computedStyle[prop])
      desiredValues.push({
        prop,
        value: computedStyle[prop].replace(/, rgba/g, '\rrgba')
      });

  return desiredValues
};

const getComputedBackgroundColor = el => {
  let background = getStyle(el, 'background-color');

  if (background === 'rgba(0, 0, 0, 0)') {
    let node  = el.parentNode
      , found = false;

    while(!found) {
      let bg  = getStyle(node, 'background-color');

      if (bg !== 'rgba(0, 0, 0, 0)') {
        found = true;
        background = bg;
      }

      node = node.parentNode;
    }
  }

  return background
};

const getA11ys = el => {
  const elAttributes = el.getAttributeNames();

  return desiredAccessibilityMap.reduce((acc, attribute) => {
    if (elAttributes.includes(attribute))
      acc.push({
        prop:   attribute,
        value:  el.getAttribute(attribute)
      });

    if (attribute === 'aria-*')
      elAttributes.forEach(attr => {
        if (attr.includes('aria'))
          acc.push({
            prop:   attr,
            value:  el.getAttribute(attr)
          });
      });

    return acc
  }, [])
};

const getWCAG2TextSize = el => {
  
  const styles = getStyles(el).reduce((styleMap, style) => {
      styleMap[style.prop] = style.value;
      return styleMap
  }, {});

  const { fontSize   = desiredPropMap.fontSize,
          fontWeight = desiredPropMap.fontWeight
      } = styles;
  
  const isLarge = largeWCAG2TextMap.some(
    (largeProperties) => parseFloat(fontSize) >= parseFloat(largeProperties.fontSize) 
       && parseFloat(fontWeight) >= parseFloat(largeProperties.fontWeight) 
  );

  return  isLarge ? 'Large' : 'Small'
};

const camelToDash = (camelString = "") =>
  camelString.replace(/([A-Z])/g, ($1) =>
    "-"+$1.toLowerCase());

const nodeKey = node => {
  let tree = [];
  let furthest_leaf = node;

  while (furthest_leaf) {
    tree.push(furthest_leaf);
    furthest_leaf = furthest_leaf.parentNode
      ? furthest_leaf.parentNode
      : false;
  }

  return tree.reduce((path, branch) => `
    ${path}${branch.tagName}_${branch.className}_${[...node.parentNode.children].indexOf(node)}_${node.children.length}
  `, '')
};

const createClassname = (el, ellipse = false) => {
  if (!el.className || el.nodeName === 'svg' || el.ownerSVGElement) return ''
  let rawClassname = '.' + el.className.replace(/ /g, '.');

  return ellipse && rawClassname.length > 30
    ? rawClassname.substring(0,30) + '...'
    : rawClassname
};

const metaKey = window.navigator.platform.includes('Mac')
  ? 'cmd'
  : 'ctrl';

const altKey = window.navigator.platform.includes('Mac')
  ? 'opt'
  : 'alt';

const getSide = direction => {
  let start = direction.split('+').pop().replace(/^\w/, c => c.toUpperCase());
  if (start == 'Up') start = 'Top';
  if (start == 'Down') start = 'Bottom';
  return start
};

const getNodeIndex = el => {
  return [...el.parentElement.parentElement.children]
    .indexOf(el.parentElement)
};

function showEdge(el) {
  return el.animate([
    { outline: '1px solid transparent' },
    { outline: '1px solid hsla(330, 100%, 71%, 80%)' },
    { outline: '1px solid transparent' },
  ], 600)
}

let timeoutMap = {};
const showHideSelected = (el, duration = 750) => {
  el.setAttribute('data-selected-hide', true);
  showHideNodeLabel(el, true);

  if (timeoutMap[nodeKey(el)]) 
    clearTimeout(timeoutMap[nodeKey(el)]);

  timeoutMap[nodeKey(el)] = setTimeout(_ => {
    el.removeAttribute('data-selected-hide');
    showHideNodeLabel(el, false);
  }, duration);
  
  return el
};

const showHideNodeLabel = (el, show = false) => {
  if (!el.hasAttribute('data-label-id')) 
    return

  const nodes = $(`
    pb-label[data-label-id="${el.getAttribute('data-label-id')}"],
    pb-handles[data-label-id="${el.getAttribute('data-label-id')}"]
  `);

  nodes.length && show
    ? nodes.forEach(el =>
      el.style.display = 'none')
    : nodes.forEach(el =>
      el.style.display = null);
};

const htmlStringToDom = (htmlString = "") =>
  (new DOMParser().parseFromString(htmlString, 'text/html'))
    .body.firstChild;

const isOffBounds = node =>
  node.closest &&
  (node.closest('tool-pallete') 
  || node.closest('hotkey-map')
  || node.closest('pb-metatip')
  || node.closest('pb-ally')
  || node.closest('pb-label')
  || node.closest('pb-handles')
  || node.closest('pb-gridlines')
  );

function windowBounds() {
  const height  = window.innerHeight;
  const width   = window.innerWidth;
  const body    = document.body.clientWidth;

  const calcWidth = body <= width
    ? body
    : width;

  return {
    winHeight: height,
    winWidth:  calcWidth,
  }
}

class Gridlines extends HTMLElement {

  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'open'});
  }

  connectedCallback() {}
  disconnectedCallback() {}

  set position(boundingRect) {
    this.$shadow.innerHTML  = this.render(boundingRect);
  }

  set update({ width, height, top, left }) {
    const { winHeight, winWidth } = windowBounds();

    this.$shadow.host.style.display = 'block';
    const svg = this.$shadow.children[1];

    svg.setAttribute('viewBox', `0 0 ${winWidth} ${winHeight}`);
    svg.children[0].setAttribute('width', width + 'px');
    svg.children[0].setAttribute('height', height + 'px');
    svg.children[0].setAttribute('x', left);
    svg.children[0].setAttribute('y', top);
    svg.children[1].setAttribute('x1', left);
    svg.children[1].setAttribute('x2', left);
    svg.children[2].setAttribute('x1', left + width);
    svg.children[2].setAttribute('x2', left + width);
    svg.children[3].setAttribute('y1', top);
    svg.children[3].setAttribute('y2', top);
    svg.children[3].setAttribute('x2', winWidth);
    svg.children[4].setAttribute('y1', top + height);
    svg.children[4].setAttribute('y2', top + height);
    svg.children[4].setAttribute('x2', winWidth);
  }

  render({ x, y, width, height, top, left }) {
    const { winHeight, winWidth } = windowBounds();

    return `
      ${this.styles({top,left})}
      <svg
        width="100%" height="100%"
        viewBox="0 0 ${winWidth} ${winHeight}"
        version="1.1" xmlns="http://www.w3.org/2000/svg"
      >
        <rect
          stroke="hotpink" fill="none"
          width="${width}" height="${height}"
          x="${x}" y="${y}"
          style="display:none;"
        ></rect>
        <line x1="${x}" y1="0" x2="${x}" y2="${winHeight}" stroke="hotpink" stroke-dasharray="2" stroke-dashoffset="3"></line>
        <line x1="${x + width}" y1="0" x2="${x + width}" y2="${winHeight}" stroke="hotpink" stroke-dasharray="2" stroke-dashoffset="3"></line>
        <line x1="0" y1="${y}" x2="${winWidth}" y2="${y}" stroke="hotpink" stroke-dasharray="2" stroke-dashoffset="3"></line>
        <line x1="0" y1="${y + height}" x2="${winWidth}" y2="${y + height}" stroke="hotpink" stroke-dasharray="2" stroke-dashoffset="3"></line>
      </svg>
    `
  }

  styles({top,left}) {
    return `
      <style>
        :host > svg {
          position:fixed;
          top:0;
          left:0;
          overflow:visible;
          pointer-events:none;
          z-index:9997;
        }
      </style>
    `
  }
}

customElements.define('pb-gridlines', Gridlines);

class Overlay extends HTMLElement {
  
  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'open'});
  }

  connectedCallback() {}
  disconnectedCallback() {}

  set position(boundingRect) {
    this.$shadow.innerHTML  = this.render(boundingRect);
  }

  set update({ top, left, width, height }) {
    this.$shadow.host.style.display = 'block';

    const svg = this.$shadow.children[0];
    svg.style.display = 'block';
    svg.style.top = window.scrollY + top + 'px';
    svg.style.left = left + 'px';

    svg.setAttribute('width', width + 'px');
    svg.setAttribute('height', height + 'px');
  }

  render({id, top, left, height, width}) {
    return `
      <svg 
        class="pb-overlay"
        overlay-id="${id}"
        style="
          display:none;
          position:absolute;
          top:0;
          left:0;
          overflow:visible;
          pointer-events:none;
          z-index: 999;
        " 
        width="${width}px" height="${height}px" 
        viewBox="0 0 ${width} ${height}" 
        version="1.1" xmlns="http://www.w3.org/2000/svg"
      >
        <rect 
          fill="hsla(330, 100%, 71%, 0.5)"
          width="100%" height="100%"
        ></rect>
      </svg>
    `
  }
}

customElements.define('pb-overlay', Overlay);

var css$1 = ":host {\n  --theme-bg: hsl(0,0%,100%);\n  --theme-color: hotpink;\n  --theme-icon_color: hsl(0,0%,20%);\n  --theme-icon_hover-bg: hsl(0,0%,95%);\n}\n\n:host {\n  position: absolute;\n  z-index: 99999;\n  direction: ltr;\n  font-size: 16px;\n  font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;\n\n  --arrow-width: 15px;\n  --arrow-height: 8px;\n\n  --shadow-up: 5px;\n  --shadow-down: -5px;\n  --shadow-direction: var(--shadow-up);\n\n  --arrow-up: polygon(0 0, 100% 0, 50% 100%);\n  --arrow-down: polygon(50% 0, 0 100%, 100% 100%);\n  --arrow: var(--arrow-up);\n}\n\n:host figure {\n  max-width: 50vw;\n  background: white;\n  color: var(--theme-icon_color);\n  line-height: normal;\n  line-height: initial;\n  padding: 0.5em;\n  margin: 0;\n  display: flex;\n  flex-direction: column;\n  flex-wrap: nowrap;\n  border-radius: 0.25em;\n  line-height: initial;\n  -webkit-filter: drop-shadow(0 var(--shadow-direction) 0.5em hsla(0,0%,0%,35%));\n          filter: drop-shadow(0 var(--shadow-direction) 0.5em hsla(0,0%,0%,35%))\n}\n\n:host figure:after {\n    content: \"\";\n    background: white;\n    width: var(--arrow-width);\n    height: var(--arrow-height);\n    -webkit-clip-path: var(--arrow);\n            clip-path: var(--arrow);\n    position: absolute;\n    top: var(--arrow-top);\n    left: var(--arrow-left);\n  }\n\n:host figure a {\n    text-decoration: none;\n    color: inherit;\n    text-overflow: ellipsis;\n    overflow: hidden\n  }\n\n:host figure a:hover {\n      color: var(--theme-color); \n      text-decoration: underline;\n    }\n\n:host figure a:empty {\n      display: none;\n    }\n\n:host h5 {\n  display: flex;\n  font-size: 1em;\n  font-weight: bolder;\n  margin: 0;\n  overflow: hidden;\n  white-space: nowrap;\n}\n\n:host h6 {\n  margin-top: 1em;\n  margin-bottom: 0;\n  font-weight: normal;\n}\n\n:host small {\n  font-size: 0.7em;\n  color: hsl(0,0%,60%)\n}\n\n:host small > span {\n    color: hsl(0,0%,20%);\n  }\n\n:host a:not(:hover) {\n  text-decoration: none;\n}\n\n:host [brand], \n:host [divider] {\n  color: var(--theme-color);\n}\n\n:host div {\n  display: grid;\n  grid-template-columns: auto auto;\n  grid-gap: 0.25em 0.5em;\n  margin: 0.5em 0 0;\n  padding: 0;\n  list-style-type: none;\n  color: hsl(0,0%,40%);\n  font-size: 0.8em;\n  font-family: 'Dank Mono', 'Operator Mono', 'Inconsolata', 'Fira Mono', 'SF Mono', 'Monaco', 'Droid Sans Mono', 'Source Code Pro', monospace;\n}\n\n:host [value] {\n  color: var(--theme-icon_color);\n  display: inline-flex;\n  align-items: center;\n  justify-content: flex-end;\n  text-align: right;\n  white-space: pre;\n}\n\n:host [text] {\n  white-space: normal;\n}\n\n:host [color] {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  width: 0.6em;\n  height: 0.6em;\n  border-radius: 50%;\n  margin-right: 0.25em;\n}\n\n:host [local-modifications] {\n  margin-top: 1rem;\n  color: var(--theme-color);\n  font-weight: bold;\n}\n\n:host [contrast] > span {\n  padding: 0 0.5em 0.1em;\n  border-radius: 1em;\n  box-shadow: 0 0 0 1px hsl(0,0%,90%);\n}\n";

class Metatip extends HTMLElement {
  
  constructor() {
    super();
    this.$shadow = this.attachShadow({mode: 'open'});
  }

  connectedCallback() {
    $('h5 > a', this.$shadow).on('click mouseenter', this.dispatchQuery.bind(this));
    $('h5 > a', this.$shadow).on('mouseleave', this.dispatchUnQuery.bind(this));
  }

  disconnectedCallback() {
    $('h5 > a', this.$shadow).off('click', this.dispatchQuery);
  }

  dispatchQuery(e) {
    this.$shadow.host.dispatchEvent(new CustomEvent('query', {
      bubbles: true,
      detail:   {
        text:       e.target.textContent,
        activator:  e.type,
      }
    }));
  }

  dispatchUnQuery(e) {
    this.$shadow.host.dispatchEvent(new CustomEvent('unquery', {
      bubbles: true
    }));
  }

  set meta(data) {
    this.$shadow.innerHTML = this.render(data);
  }

  render({el, width, height, localModifications, notLocalModifications}) {
    return `
      ${this.styles()}
      <figure>
        <h5>
          <a href="#">${el.nodeName.toLowerCase()}</a>
          <a href="#">${el.id && '#' + el.id}</a>
          ${createClassname(el).split('.')
            .filter(name => name != '')
            .reduce((links, name) => `
              ${links}
              <a href="#">.${name}</a>
            `, '')
          }
        </h5>
        <small>
          <span">${Math.round(width)}</span>px 
          <span divider>×</span> 
          <span>${Math.round(height)}</span>px
        </small>
        <div>${notLocalModifications.reduce((items, item) => `
          ${items}
          <span prop>${item.prop}:</span>
          <span value>${item.value}</span>
        `, '')}
        </div>
        ${localModifications.length ? `
          <h6 local-modifications>Local Modifications</h6>
          <div>${localModifications.reduce((items, item) => `
            ${items}
            <span prop>${item.prop}:</span>
            <span value>${item.value}</span>
          `, '')}
          </div>
        ` : ''}
      </figure>
    `
  }

  styles() {
    return `
      <style>
        ${css$1}
      </style>
    `
  }
}

customElements.define('pb-metatip', Metatip);

class Ally extends Metatip {
  constructor() {
    super();
  }
  
  render({el, ally_attributes, contrast_results}) {
    return `
      ${this.styles()}
      <figure>
        <h5>${el.nodeName.toLowerCase()}${el.id && '#' + el.id}</h5>
        <div>
          ${ally_attributes.reduce((items, attr) => `
            ${items}
            <span prop>${attr.prop}:</span>
            <span value>${attr.value}</span>
          `, '')}
          ${contrast_results}
        </div>
      </figure>
    `
  }
}

customElements.define('pb-ally', Ally);

var css$2 = ":host {\n  --theme-bg: hsl(0,0%,100%);\n  --theme-color: hotpink;\n  --theme-icon_color: hsl(0,0%,20%);\n  --theme-icon_hover-bg: hsl(0,0%,95%);\n}\n\n:host {\n  display: none;\n  position: fixed;\n  z-index: 99998;\n  align-items: center;\n  justify-content: center;\n  width: 100vw;\n  height: 100vh;\n  background: hsl(0,0%,95%);\n  font-size: 16px;\n  font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif;\n\n  --light-grey: hsl(0,0%,90%);\n  --grey: hsl(0,0%,60%);\n  --dark-grey: hsl(0,0%,40%);\n}\n\n:host [command] {\n  padding: 1em;\n  text-align: center;\n  font-size: 3vw;\n  font-weight: lighter;\n  letter-spacing: 0.1em;\n  color: var(--dark-grey)\n}\n\n:host [command] > [light] {\n    color: var(--grey);\n  }\n\n:host [command] > [tool] {\n    text-decoration: underline;\n    -webkit-text-decoration-color: var(--theme-color);\n            text-decoration-color: var(--theme-color);\n  }\n\n:host [command] > [negative], :host [command] > [side], :host [command] > [amount] {\n    font-weight: normal;\n  }\n\n:host [card] {\n  padding: 1em;\n  background: white;\n  box-shadow: 0 0.5em 3em hsla(0,0%,0%,20%);\n  border-radius: 0.5em;\n  color: var(--dark-grey);\n  display: flex;\n  justify-content: space-evenly\n}\n\n:host [card] > div:not([keyboard]) {\n    display: flex;\n    align-items: flex-end;\n    margin-left: 1em;\n  }\n\n:host [tool-icon] {\n  position: absolute;\n  top: 1em;\n  left: 0;\n  width: 100%;\n  padding: 0 1rem;\n  display: flex;\n  justify-content: center\n}\n\n:host [tool-icon] > span {\n    color: var(--dark-grey);\n    display: grid;\n    grid-template-columns: 5vmax auto;\n    grid-gap: 0.5em;\n    align-items: center;\n    text-transform: capitalize;\n    font-size: 4vmax;\n    font-weight: lighter;\n  }\n\n:host [tool-icon] svg {\n    width: 100%;\n    fill: var(--theme-color);\n  }\n\n:host section {\n  display: flex;\n  justify-content: center;\n}\n\n:host section > span, \n:host [arrows] > span {\n  border: 1px solid transparent;\n  border-radius: 0.5em;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  margin: 2px;\n  padding: 1.5vw;\n  font-size: 0.75em;\n  white-space: nowrap;\n}\n\n:host section > span:not([pressed=\"true\"]), \n:host [arrows] > span:not([pressed=\"true\"]) {\n  border: 1px solid var(--light-grey)\n}\n\n:host section > span:not([pressed=\"true\"]):hover, :host [arrows] > span:not([pressed=\"true\"]):hover {\n    border-color: var(--grey);\n  }\n\n:host span[pressed=\"true\"] {\n  background: var(--theme-color);\n  color: white;\n}\n\n:host span:not([pressed=\"true\"])[used] {\n  background: var(--light-grey);\n}\n\n:host span[hotkey] {\n  color: var(--theme-color);\n  font-weight: bold;\n  cursor: pointer;\n}\n\n:host section > span[hotkey]:not([pressed=\"true\"]) {\n  border-color: var(--theme-color);\n}\n\n:host [arrows] {\n  display: grid;\n  grid-template-columns: 1fr 1fr 1fr;\n  grid-template-rows: 1fr 1fr\n}\n\n:host [arrows] > span:nth-child(1) {\n    grid-row: 1;\n    grid-column: 2;\n  }\n\n:host [arrows] > span:nth-child(2) {\n    grid-row: 2;\n    grid-column: 2;\n  }\n\n:host [arrows] > span:nth-child(3) {\n    grid-row: 2;\n    grid-column: 1;\n  }\n\n:host [arrows] > span:nth-child(4) {\n    grid-row: 2;\n    grid-column: 3;\n  }\n\n:host [caps] > span:nth-child(1),\n:host [shift] > span:nth-child(1)  { justify-content: flex-start; }\n\n:host [shift] > span:nth-child(12) { justify-content: flex-end; }";

const cursor = `
  <svg class="icon-cursor" version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
    <path d="M16.689 17.655l5.311 12.345-4 2-4.646-12.678-7.354 6.678v-26l20 16-9.311 1.655z"></path>
  </svg>
`;

const move = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M15 7.5V2H9v5.5l3 3 3-3zM7.5 9H2v6h5.5l3-3-3-3zM9 16.5V22h6v-5.5l-3-3-3 3zM16.5 9l-3 3 3 3H22V9h-5.5z"/>
  </svg>
`;

const search = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
  </svg>
`;

const margin = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M9 7H7v2h2V7zm0 4H7v2h2v-2zm0-8c-1.11 0-2 .9-2 2h2V3zm4 12h-2v2h2v-2zm6-12v2h2c0-1.1-.9-2-2-2zm-6 0h-2v2h2V3zM9 17v-2H7c0 1.1.89 2 2 2zm10-4h2v-2h-2v2zm0-4h2V7h-2v2zm0 8c1.1 0 2-.9 2-2h-2v2zM5 7H3v12c0 1.1.89 2 2 2h12v-2H5V7zm10-2h2V3h-2v2zm0 12h2v-2h-2v2z"/>
  </svg>
`;

const padding = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm2 4v-2H3c0 1.1.89 2 2 2zM3 9h2V7H3v2zm12 12h2v-2h-2v2zm4-18H9c-1.11 0-2 .9-2 2v10c0 1.1.89 2 2 2h10c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 12H9V5h10v10zm-8 6h2v-2h-2v2zm-4 0h2v-2H7v2z"/>
  </svg>
`;

const font = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M9 4v3h5v12h3V7h5V4H9zm-6 8h3v7h3v-7h3V9H3v3z"/>
  </svg>
`;

const text = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
  </svg>
`;

const align = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="transform:rotateZ(90deg);">
    <path d="M10 20h4V4h-4v16zm-6 0h4v-8H4v8zM16 9v11h4V9h-4z"/>
  </svg>
`;

const resize = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M19 12h-2v3h-3v2h5v-5zM7 9h3V7H5v5h2V9zm14-6H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16.01H3V4.99h18v14.02z"/>
  </svg>
`;

const transform = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M12,7C6.48,7,2,9.24,2,12c0,2.24,2.94,4.13,7,4.77V20l4-4l-4-4v2.73c-3.15-0.56-5-1.9-5-2.73c0-1.06,3.04-3,8-3s8,1.94,8,3
    c0,0.73-1.46,1.89-4,2.53v2.05c3.53-0.77,6-2.53,6-4.58C22,9.24,17.52,7,12,7z"/>
  </svg>
`;

const border = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M13 7h-2v2h2V7zm0 4h-2v2h2v-2zm4 0h-2v2h2v-2zM3 3v18h18V3H3zm16 16H5V5h14v14zm-6-4h-2v2h2v-2zm-4-4H7v2h2v-2z"/>
  </svg>
`;

const hueshift = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-5.5 9c-.83 0-1.5-.67-1.5-1.5S5.67 9 6.5 9 8 9.67 8 10.5 7.33 12 6.5 12zm3-4C8.67 8 8 7.33 8 6.5S8.67 5 9.5 5s1.5.67 1.5 1.5S10.33 8 9.5 8zm5 0c-.83 0-1.5-.67-1.5-1.5S13.67 5 14.5 5s1.5.67 1.5 1.5S15.33 8 14.5 8zm3 4c-.83 0-1.5-.67-1.5-1.5S16.67 9 17.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>
  </svg>
`;

const boxshadow = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M20 8.69V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69L23.31 12 20 8.69zM12 18c-.89 0-1.74-.2-2.5-.55C11.56 16.5 13 14.42 13 12s-1.44-4.5-3.5-5.45C10.26 6.2 11.11 6 12 6c3.31 0 6 2.69 6 6s-2.69 6-6 6z"/>
  </svg>
`;

const inspector = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <g>
      <rect x="11" y="7" width="2" height="2"/>
      <rect x="11" y="11" width="2" height="6"/>
      <path d="M12,2C6.48,2,2,6.48,2,12c0,5.52,4.48,10,10,10s10-4.48,10-10C22,6.48,17.52,2,12,2z M12,20c-4.41,0-8-3.59-8-8
        c0-4.41,3.59-8,8-8s8,3.59,8,8C20,16.41,16.41,20,12,20z"/>
    </g>
  </svg>
`;

const camera = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="3.2"/>
    <path d="M9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"/>
  </svg>
`;

const guides = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M21,6H3C1.9,6,1,6.9,1,8v8c0,1.1,0.9,2,2,2h18c1.1,0,2-0.9,2-2V8C23,6.9,22.1,6,21,6z M21,16H3V8h2v4h2V8h2v4h2V8h2v4h2V8
    h2v4h2V8h2V16z"/>
  </svg>
`;

const color_text = `
  <svg viewBox="0 0 25 27">
    <path fill="var(--active_color)" d="M11 3L5.5 17h2.25l1.12-3h6.25l1.12 3h2.25L13 3h-2zm-1.38 9L12 5.67 14.38 12H9.62z"/>
    <rect fill="var(--contextual_color)" x="1" y="21" width="23" height="5"></rect>
  </svg>
`;

const color_background = `
  <svg viewBox="0 0 25 27">
    <path fill="var(--active_color)" d="M16.56 8.94L7.62 0 6.21 1.41l2.38 2.38-5.15 5.15c-.59.59-.59 1.54 0 2.12l5.5 5.5c.29.29.68.44 1.06.44s.77-.15 1.06-.44l5.5-5.5c.59-.58.59-1.53 0-2.12zM5.21 10L10 5.21 14.79 10H5.21zM19 11.5s-2 2.17-2 3.5c0 1.1.9 2 2 2s2-.9 2-2c0-1.33-2-3.5-2-3.5z"/>
    <rect fill="var(--contextual_color)" x="1" y="21" width="23" height="5"></rect>
  </svg>
`;

const color_border = `
  <svg viewBox="0 0 25 27">
    <path fill="var(--active_color)" d="M17.75 7L14 3.25l-10 10V17h3.75l10-10zm2.96-2.96c.39-.39.39-1.02 0-1.41L18.37.29c-.39-.39-1.02-.39-1.41 0L15 2.25 18.75 6l1.96-1.96z"/>
    <rect fill="var(--contextual_color)" x="1" y="21" width="23" height="5"></rect>
  </svg>
`;

const position = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M15.54 5.54L13.77 7.3 12 5.54 10.23 7.3 8.46 5.54 12 2zm2.92 10l-1.76-1.77L18.46 12l-1.76-1.77 1.76-1.77L22 12zm-10 2.92l1.77-1.76L12 18.46l1.77-1.76 1.77 1.76L12 22zm-2.92-10l1.76 1.77L5.54 12l1.76 1.77-1.76 1.77L2 12z"/>
    <circle cx="12" cy="12" r="3"/>
  </svg>
`;

const accessibility = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
    <path d="M12,2c1.1,0,2,0.9,2,2s-0.9,2-2,2s-2-0.9-2-2S10.9,2,12,2z M21,9h-6v13h-2v-6h-2v6H9V9H3V7h18V9z"/>
  </svg>
`;

var Icons = /*#__PURE__*/Object.freeze({
  cursor: cursor,
  move: move,
  search: search,
  margin: margin,
  padding: padding,
  font: font,
  text: text,
  align: align,
  resize: resize,
  transform: transform,
  border: border,
  hueshift: hueshift,
  boxshadow: boxshadow,
  inspector: inspector,
  camera: camera,
  guides: guides,
  color_text: color_text,
  color_background: color_background,
  color_border: color_border,
  position: position,
  accessibility: accessibility
});

class HotkeyMap extends HTMLElement {

  constructor() {
    super();

    this.keyboard_model = {
      num:    ['`','1','2','3','4','5','6','7','8','9','0','-','=','delete'],
      tab:    ['tab','q','w','e','r','t','y','u','i','o','p','[',']','\\'],
      caps:   ['caps','a','s','d','f','g','h','j','k','l','\'','return'],
      shift:  ['shift','z','x','c','v','b','n','m',',','.','/','shift'],
      space:  ['ctrl',altKey,'cmd','spacebar','cmd',altKey,'ctrl']
    };

    this.key_size_model = {
      num:    {12:2},
      tab:    {0:2},
      caps:   {0:3,11:3},
      shift:  {0:6,11:6},
      space:  {3:10},
    };

    this.$shadow    = this.attachShadow({mode: 'open'});

    this._hotkey    = '';
    this._usedkeys  = [];

    this.tool       = 'hotkeymap';
  }

  connectedCallback() {
    this.$shift  = $('[keyboard] > section > [shift]', this.$shadow);
    this.$ctrl   = $('[keyboard] > section > [ctrl]', this.$shadow);
    this.$alt    = $(`[keyboard] > section > [${altKey}]`, this.$shadow);
    this.$cmd    = $(`[keyboard] > section > [${metaKey}]`, this.$shadow);
    this.$up     = $('[arrows] [up]', this.$shadow);
    this.$down   = $('[arrows] [down]', this.$shadow);
    this.$left   = $('[arrows] [left]', this.$shadow);
    this.$right  = $('[arrows] [right]', this.$shadow);
  }

  disconnectedCallback() {}

  set tool(tool) {
    this._tool = tool;
    this.$shadow.innerHTML = this.render();
  }

  show() {
    this.$shadow.host.style.display = 'flex';
    hotkeys('*', (e, handler) =>
      this.watchKeys(e, handler));
  }

  hide() {
    this.$shadow.host.style.display = 'none';
    hotkeys.unbind('*');
  }

  watchKeys(e, handler) {
    e.preventDefault();
    e.stopImmediatePropagation();

    this.$shift.attr('pressed', hotkeys.shift);
    this.$ctrl.attr('pressed', hotkeys.ctrl);
    this.$alt.attr('pressed', hotkeys.alt);
    this.$cmd.attr('pressed', hotkeys[metaKey]);
    this.$up.attr('pressed', e.code === 'ArrowUp');
    this.$down.attr('pressed', e.code === 'ArrowDown');
    this.$left.attr('pressed', e.code === 'ArrowLeft');
    this.$right.attr('pressed', e.code === 'ArrowRight');

    const { negative, negative_modifier, side, amount } = this.createCommand({e, hotkeys});

    $('[command]', this.$shadow)[0].innerHTML = this.displayCommand({
      negative, negative_modifier, side, amount,
    });
  }

  createCommand({e:{code}, hotkeys: hotkeys$$1}) {
    let amount              = hotkeys$$1.shift ? 10 : 1;
    let negative            = hotkeys$$1.alt ? 'Subtract' : 'Add';
    let negative_modifier   = hotkeys$$1.alt ? 'from' : 'to';

    let side = '[arrow key]';
    if (code === 'ArrowUp')     side = 'the top side';
    if (code === 'ArrowDown')   side = 'the bottom side';
    if (code === 'ArrowLeft')   side = 'the left side';
    if (code === 'ArrowRight')  side = 'the right side';
    if (hotkeys$$1[metaKey])            side = 'all sides';

    if (hotkeys$$1[metaKey] && code === 'ArrowDown') {
      negative            = 'Subtract';
      negative_modifier   = 'from';
    }

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({negative, negative_modifier, side, amount}) {
    return `
      <span negative>${negative} </span>
      <span tool>${this._tool}</span>
      <span light> ${negative_modifier} </span>
      <span side>${side}</span>
      <span light> by </span>
      <span amount>${amount}</span>
    `
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${Icons[this._tool]}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          ${this.displayCommand({
            negative: `±[${altKey}] `,
            negative_modifier: ' to ',
            tool: this._tool,
            side: '[arrow key]',
            amount: 1
          })}
        </div>
        <div card>
          <div keyboard>
            ${Object.entries(this.keyboard_model).reduce((keyboard, [row_name, row]) => `
              ${keyboard}
              <section ${row_name}>${row.reduce((row, key, i) => `
                ${row}
                <span
                  ${key}
                  ${this._hotkey == key ? 'hotkey title="Tool Shortcut Hotkey"' : ''}
                  ${this._usedkeys.includes(key) ? 'used' : ''}
                  style="flex:${this.key_size_model[row_name][i] || 1};"
                >${key}</span>
              `, '')}
              </section>
            `, '')}
          </div>
          <div>
            <section arrows>
              <span up used>↑</span>
              <span down used>↓</span>
              <span left used>←</span>
              <span right used>→</span>
            </section>
          </div>
        </div>
      </article>
    `
  }

  styles() {
    return `
      <style>
        ${css$2}
      </style>
    `
  }
}

customElements.define('hotkey-map', HotkeyMap);

class GuidesHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'g';
    this._usedkeys  = [];
    this.tool       = 'guides';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${guides}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-guides', GuidesHotkeys);

class InspectorHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'i';
    this._usedkeys  = [altKey];
    this.tool       = 'inspector';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${inspector}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-inspector', InspectorHotkeys);

class AccessibilityHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'p';
    this._usedkeys  = [altKey];
    this.tool       = 'accessibility';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${accessibility}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-accessibility', AccessibilityHotkeys);

class MoveHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey  = 'v';
    this.tool     = 'move';
  }

  createCommand({e:{code}, hotkeys}) {
    let amount, negative, negative_modifier;

    let side = '[arrow key]';
    if (code === 'ArrowUp')     side = 'up & out of div';
    if (code === 'ArrowDown')   side = 'down & into next sibling / out & under div';
    if (code === 'ArrowLeft')   side = 'towards the front/top of the stack';
    if (code === 'ArrowRight')  side = 'towards the back/bottom of the stack';

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({side}) {
    return `
      <span tool>${this._tool}</span>
      <span side>${side}</span>
    `
  }
}

customElements.define('hotkeys-move', MoveHotkeys);

class MarginHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'm';
    this._usedkeys  = ['shift',metaKey,altKey];

    this.tool       = 'margin';
  }
}

customElements.define('hotkeys-margin', MarginHotkeys);

class PaddingHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'p';
    this._usedkeys  = ['shift',metaKey,altKey];

    this.tool       = 'padding';
  }
}

customElements.define('hotkeys-padding', PaddingHotkeys);

const h_alignOptions  = ['left','center','right'];
const v_alignOptions  = ['top','center','bottom'];
const distOptions     = ['evenly','normal','between'];

class AlignHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey   = 'a';
    this._usedkeys = [metaKey,'shift'];

    this._htool   = 0;
    this._vtool   = 0;
    this._dtool   = 1;

    this._side         = 'top left';
    this._direction    = 'row';
    this._distribution = distOptions[this._dtool];

    this.tool     = 'align';
  }

  createCommand({e:{code}, hotkeys}) {
    let amount            = this._distribution
      , negative_modifier = this._direction
      , side              = this._side
      , negative;

    if (hotkeys.cmd && (code === 'ArrowRight' || code === 'ArrowDown')) {
      negative_modifier = code === 'ArrowDown'
        ? 'column'
        : 'row';
      this._direction = negative_modifier;
    }
    else {
      if (code === 'ArrowUp')           side = this.clamp(v_alignOptions, '_vtool');
      else if (code === 'ArrowDown')    side = this.clamp(v_alignOptions, '_vtool', true);
      else                              side = v_alignOptions[this._vtool];

      if (code === 'ArrowLeft')         side += ' ' + this.clamp(h_alignOptions, '_htool');
      else if (code === 'ArrowRight')   side += ' ' + this.clamp(h_alignOptions, '_htool', true);
      else                              side += ' ' + h_alignOptions[this._htool];

      this._side = side;

      if (hotkeys.shift && (code === 'ArrowRight' || code === 'ArrowLeft')) {
        amount = this.clamp(distOptions, '_dtool', code === 'ArrowRight');
        this._distribution = amount;
      }
    }

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({side, amount, negative_modifier}) {
    if (amount == 1) amount = this._distribution;
    if (negative_modifier == ' to ') negative_modifier = this._direction;

    return `
      <span tool>${this._tool}</span>
      <span light> as </span>
      <span>${negative_modifier}:</span>
      <span side>${side}</span>
      <span light> distributed </span>
      <span amount>${amount}</span>
    `
  }

  clamp(range, tool, increment = false) {
    if (increment) {
      if (this[tool] < range.length - 1)
        this[tool] = this[tool] + 1;
    }
    else if (this[tool] > 0)
      this[tool] = this[tool] - 1;

    return range[this[tool]]
  }
}

customElements.define('hotkeys-align', AlignHotkeys);

class HueshiftHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'h';
    this._usedkeys  = ['shift',metaKey];
    this.tool       = 'hueshift';
  }

  createCommand({e:{code}, hotkeys}) {
    let amount              = hotkeys.shift ? 10 : 1;
    let negative            = '[increase/decrease]';
    let negative_modifier   = 'by';
    let side                = '[arrow key]';

    // saturation
    if (hotkeys.cmd) {
      side ='hue';

      if (code === 'ArrowDown')
        negative  = 'decrease';
      if (code === 'ArrowUp')
        negative  = 'increase';
    }
    else if (code === 'ArrowLeft' || code === 'ArrowRight') {
      side = 'saturation';

      if (code === 'ArrowLeft')
        negative  = 'decrease';
      if (code === 'ArrowRight')
        negative  = 'increase';
    }
    // lightness
    else if (code === 'ArrowUp' || code === 'ArrowDown') {
      side = 'lightness';

      if (code === 'ArrowDown')
        negative  = 'decrease';
      if (code === 'ArrowUp')
        negative  = 'increase';
    }

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({negative, negative_modifier, side, amount}) {
    if (negative === `±[${altKey}] `)
      negative = '[increase/decrease]';
    if (negative_modifier === ' to ')
      negative_modifier = ' by ';

    return `
      <span negative>${negative}</span>
      <span side tool>${side}</span>
      <span light>${negative_modifier}</span>
      <span amount>${amount}</span>
    `
  }
}

customElements.define('hotkeys-hueshift', HueshiftHotkeys);

class BoxshadowHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'd';
    this._usedkeys  = ['shift',metaKey];
    this.tool       = 'boxshadow';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${boxshadow}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-boxshadow', BoxshadowHotkeys);

class PositionHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'l';
    this._usedkeys  = ['shift',altKey];
    this.tool       = 'position';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${position}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-position', PositionHotkeys);

class FontHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'f';
    this._usedkeys  = ['shift',metaKey];
    this.tool       = 'font';
  }

  createCommand({e:{code}, hotkeys}) {
    let amount              = hotkeys.shift ? 10 : 1;
    let negative            = '[increase/decrease]';
    let negative_modifier   = 'by';
    let side                = '[arrow key]';

    // kerning
    if (hotkeys.shift && (code === 'ArrowLeft' || code === 'ArrowRight')) {
      side    = 'kerning';
      amount  = '1px';

      if (code === 'ArrowLeft')
        negative  = 'decrease';
      if (code === 'ArrowRight')
        negative  = 'increase';
    }
    // leading
    else if (hotkeys.shift && (code === 'ArrowUp' || code === 'ArrowDown')) {
      side    = 'leading';
      amount  = '1px';

      if (code === 'ArrowUp')
        negative  = 'increase';
      if (code === 'ArrowDown')
        negative  = 'decrease';
    }
    // font weight
    else if (hotkeys.cmd && (code === 'ArrowUp' || code === 'ArrowDown')) {
      side                = 'font weight';
      amount              = '';
      negative_modifier   = '';

      if (code === 'ArrowUp')
        negative  = 'increase';
      if (code === 'ArrowDown')
        negative  = 'decrease';
    }
    // font size
    else if (code === 'ArrowUp' || code === 'ArrowDown') {
      side    = 'font size';
      amount  = '1px';

      if (code === 'ArrowUp')
        negative  = 'increase';
      if (code === 'ArrowDown')
        negative  = 'decrease';
    }
    // text alignment
    else if (code === 'ArrowRight' || code === 'ArrowLeft') {
      side                = 'text alignment';
      amount              = '';
      negative            = 'adjust';
      negative_modifier   = '';
    }

    return {
      negative, negative_modifier, amount, side,
    }
  }

  displayCommand({negative, negative_modifier, side, amount}) {
    if (negative === `±[${altKey}] `)
      negative = '[increase/decrease]';
    if (negative_modifier === ' to ')
      negative_modifier = ' by ';

    return `
      <span negative>${negative}</span>
      <span side tool>${side}</span>
      <span light>${negative_modifier}</span>
      <span amount>${amount}</span>
    `
  }
}

customElements.define('hotkeys-font', FontHotkeys);

class TextHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 'e';
    this._usedkeys  = [];
    this.tool       = 'text';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${text}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-text', TextHotkeys);

class SearchHotkeys extends HotkeyMap {
  constructor() {
    super();

    this._hotkey    = 's';
    this._usedkeys  = [];
    this.tool       = 'search';
  }

  connectedCallback() {}

  show() {
    this.$shadow.host.style.display = 'flex';
  }

  render() {
    return `
      ${this.styles()}
      <article>
        <div tool-icon>
          <span>
            ${search}
            ${this._tool} Tool
          </span>
        </div>
        <div command>
          coming soon
        </div>
      </article>
    `
  }
}

customElements.define('hotkeys-search', SearchHotkeys);

class Hotkeys extends HTMLElement {
  
  constructor() {
    super();

    this.tool_map = {
      guides:         document.createElement('hotkeys-guides'),
      inspector:      document.createElement('hotkeys-inspector'),
      accessibility:  document.createElement('hotkeys-accessibility'),
      move:           document.createElement('hotkeys-move'),
      margin:         document.createElement('hotkeys-margin'),
      padding:        document.createElement('hotkeys-padding'),
      align:          document.createElement('hotkeys-align'),
      hueshift:       document.createElement('hotkeys-hueshift'),
      boxshadow:      document.createElement('hotkeys-boxshadow'),
      position:       document.createElement('hotkeys-position'),
      font:           document.createElement('hotkeys-font'),
      text:           document.createElement('hotkeys-text'),
      search:         document.createElement('hotkeys-search'),
    };

    Object.values(this.tool_map).forEach(tool =>
      this.appendChild(tool));
  }

  connectedCallback() {
    hotkeys('shift+/', e =>
      this.cur_tool
        ? this.hideTool()
        : this.showTool());

    hotkeys('esc', e => this.hideTool());
  }

  disconnectedCallback() {}

  hideTool() {
    if (!this.cur_tool) return
    this.cur_tool.hide();
    this.cur_tool = null;
  }

  showTool() {
    this.cur_tool = this.tool_map[
      $('tool-pallete')[0].activeTool];
    this.cur_tool.show();
  }
}

customElements.define('pb-hotkeys', Hotkeys);

// todo: show margin color
const key_events = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},alt+${event},shift+${event},shift+alt+${event}`
  , '')
  .substring(1);

const command_events = `${metaKey}+up,${metaKey}+shift+up,${metaKey}+down,${metaKey}+shift+down`;

function Margin(selector) {
  hotkeys(key_events, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();
    pushElement($(selector), handler.key);
  });

  hotkeys(command_events, (e, handler) => {
    e.preventDefault();
    pushAllElementSides($(selector), handler.key);
  });

  return () => {
    hotkeys.unbind(key_events);
    hotkeys.unbind(command_events);
    hotkeys.unbind('up,down,left,right'); // bug in lib?
  }
}

function pushElement(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'margin' + getSide(direction),
      current:  parseInt(getStyle(el, 'margin' + getSide(direction)), 10),
      amount:   direction.split('+').includes('shift') ? 10 : 1,
      negative: direction.split('+').includes('alt'),
    }))
    .map(payload =>
      Object.assign(payload, {
        margin: payload.negative
          ? payload.current - payload.amount
          : payload.current + payload.amount
      }))
    .forEach(({el, style, margin}) =>
      el.style[style] = `${margin < 0 ? 0 : margin}px`);
}

function pushAllElementSides(els, keycommand) {
  const combo = keycommand.split('+');
  let spoof = '';

  if (combo.includes('shift'))  spoof = 'shift+' + spoof;
  if (combo.includes('down'))   spoof = 'alt+' + spoof;

  'up,down,left,right'.split(',')
    .forEach(side => pushElement(els, spoof + side));
}

const key_events$1 = 'up,down,left,right';
// todo: indicator for when node can descend
// todo: indicator where left and right will go
function Moveable(selector) {
  hotkeys(key_events$1, (e, {key}) => {
    if (e.cancelBubble) return
      
    e.preventDefault();
    e.stopPropagation();
    
    $(selector).forEach(el => {
      moveElement(el, key);
      updateFeedback(el);
    });
  });

  return () => {
    hotkeys.unbind(key_events$1);
  }
}

function moveElement(el, direction) {
  if (!el) return

  switch(direction) {
    case 'left':
      if (canMoveLeft(el))
        el.parentNode.insertBefore(el, el.previousElementSibling);
      else
        showEdge(el.parentNode);
      break

    case 'right':
      if (canMoveRight(el) && el.nextElementSibling.nextSibling)
        el.parentNode.insertBefore(el, el.nextElementSibling.nextSibling);
      else if (canMoveRight(el))
        el.parentNode.appendChild(el);
      else
        showEdge(el.parentNode);
      break

    case 'up':
      if (canMoveUp(el))
        popOut({el});
      break

    case 'down':
      if (canMoveUnder(el))
        popOut({el, under: true});
      else if (canMoveDown(el))
        el.nextElementSibling.prepend(el);
      break
  }
}

const canMoveLeft    = el => el.previousElementSibling;
const canMoveRight   = el => el.nextElementSibling;
const canMoveDown    = el => el.nextElementSibling && el.nextElementSibling.children.length;
const canMoveUnder   = el => !el.nextElementSibling && el.parentNode && el.parentNode.parentNode;
const canMoveUp      = el => el.parentNode && el.parentNode.parentNode;

const popOut = ({el, under = false}) =>
  el.parentNode.parentNode.insertBefore(el, 
    el.parentNode.parentNode.children[
      under
        ? getNodeIndex(el) + 1
        : getNodeIndex(el)]); 

function updateFeedback(el) {
  let options = '';
  // get current elements offset/size
  if (canMoveLeft(el))  options += '⇠';
  if (canMoveRight(el)) options += '⇢';
  if (canMoveDown(el))  options += '⇣';
  if (canMoveUp(el))    options += '⇡';
  // create/move arrows in absolute/fixed to overlay element
  options && console.info('%c'+options, "font-size: 2rem;");
}

let imgs      = []
  , overlays  = [];

function watchImagesForUpload() {
  imgs = $([
    ...document.images,
    ...findBackgroundImages(document),
  ]);

  clearWatchers(imgs);
  initWatchers(imgs);
}

const initWatchers = imgs => {
  imgs.on('dragover', onDragEnter);
  imgs.on('dragleave', onDragLeave);
  imgs.on('drop', onDrop);
  $(document.body).on('dragover', onDragEnter);
  $(document.body).on('dragleave', onDragLeave);
  $(document.body).on('drop', onDrop);
};

const clearWatchers = imgs => {
  imgs.off('dragenter', onDragEnter);
  imgs.off('dragleave', onDragLeave);
  imgs.off('drop', onDrop);
  $(document.body).off('dragenter', onDragEnter);
  $(document.body).off('dragleave', onDragLeave);
  $(document.body).off('drop', onDrop);
  imgs = [];
};

const previewFile = file => {
  return new Promise((resolve, reject) => {
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = () => resolve(reader.result);
  })
};

const onDragEnter = e => {
  e.preventDefault();
  const pre_selected = $('img[data-selected=true]');

  if (!pre_selected.length)
    showOverlay(e.currentTarget, 0);
  else
    pre_selected.forEach((img, i) =>
      showOverlay(img, i));
};

const onDragLeave = e => 
  hideOverlays();

const onDrop = async e => {
  e.stopPropagation();
  e.preventDefault();

  const selectedImages = $('img[data-selected=true]');

  const srcs = await Promise.all(
    [...e.dataTransfer.files].map(previewFile));
  
  if (!selectedImages.length)
    if (e.target.nodeName === 'IMG')
      e.target.src = srcs[0];
    else
      imgs
        .filter(img => img.contains(e.target))
        .forEach(img => 
          img.style.backgroundImage = `url(${srcs[0]})`);
  else if (selectedImages.length) {
    let i = 0;
    selectedImages.forEach(img => {
      img.src = srcs[i++];
      if (i >= srcs.length) i = 0;
    });
  }

  hideOverlays();
};

const showOverlay = (node, i) => {
  const rect    = node.getBoundingClientRect();
  const overlay = overlays[i];

  if (overlay) {
    overlay.update = rect;
  }
  else {
    overlays[i] = document.createElement('pb-overlay');
    overlays[i].position = rect;
    document.body.appendChild(overlays[i]);
  }
};

const hideOverlays = () => {
  overlays.forEach(overlay =>
    overlay.remove());
  overlays = [];
};

const findBackgroundImages = el => {
  const src_regex = /url\(\s*?['"]?\s*?(\S+?)\s*?["']?\s*?\)/i;

  return $('*').reduce((collection, node) => {
    const prop = getStyle(node, 'background-image');
    const match = src_regex.exec(prop);

    // if (match) collection.push(match[1])
    if (match) collection.push(node);

    return collection
  }, [])
};

let SelectorEngine;

// create input
const search_base = document.createElement('div');
search_base.classList.add('search');
search_base.innerHTML = `<input type="text" placeholder="ex: images, .btn, button, text, ..."/>`;

const search$1        = $(search_base);
const searchInput   = $('input', search_base);

const showSearchBar = () => search$1.attr('style', 'display:block');
const hideSearchBar = () => search$1.attr('style', 'display:none');
const stopBubbling  = e => e.key != 'Escape' && e.stopPropagation();

function Search(node) {
  if (node) node[0].appendChild(search$1[0]);

  const onQuery = e => {
    e.preventDefault();
    e.stopPropagation();

    const query = e.target.value;

    window.requestIdleCallback(_ =>
      queryPage(query));
  };

  searchInput.on('input', onQuery);
  searchInput.on('keydown', stopBubbling);
  // searchInput.on('blur', hideSearchBar)

  showSearchBar();
  searchInput[0].focus();

  // hotkeys('escape,esc', (e, handler) => {
  //   hideSearchBar()
  //   hotkeys.unbind('escape,esc')
  // })

  return () => {
    hideSearchBar();
    searchInput.off('oninput', onQuery);
    searchInput.off('keydown', stopBubbling);
    searchInput.off('blur', hideSearchBar);
  }
}

function provideSelectorEngine(Engine) {
  SelectorEngine = Engine;
}

function queryPage(query, fn) {
  if (query == 'links')     query = 'a';
  if (query == 'buttons')   query = 'button';
  if (query == 'images')    query = 'img';
  if (query == 'text')      query = 'p,caption,a,h1,h2,h3,h4,h5,h6,small,date,time,li,dt,dd';

  if (!query) return SelectorEngine.unselect_all()
  if (query == '.' || query == '#' || query.trim().endsWith(',')) return

  try {
    let matches = $(query + ':not(tool-pallete):not(script):not(hotkey-map):not(.pb-metatip):not(pb-label):not(pb-handles)');
    if (!matches.length) matches = $(query);
    if (!fn) SelectorEngine.unselect_all();
    if (matches.length)
      matches.forEach(el =>
        fn
          ? fn(el)
          : SelectorEngine.select(el));
  }
  catch (err) {}
}

function Selectable() {
  const elements          = $('body');
  let selected            = [];
  let selectedCallbacks   = [];
  let labels              = [];
  let handles             = [];

  const listen = () => {
    elements.forEach(el => el.addEventListener('click', on_click, true));
    elements.forEach(el => el.addEventListener('dblclick', on_dblclick, true));
    elements.on('selectstart', on_selection);
    elements.on('mouseover', on_hover);
    elements.on('mouseout', on_hoverout);

    document.addEventListener('copy', on_copy);
    document.addEventListener('cut', on_cut);
    document.addEventListener('paste', on_paste);

    watchCommandKey();

    hotkeys(`${metaKey}+alt+c`, on_copy_styles);
    hotkeys(`${metaKey}+alt+v`, e => on_paste_styles());
    hotkeys('esc', on_esc);
    hotkeys(`${metaKey}+d`, on_duplicate);
    hotkeys('backspace,del,delete', on_delete);
    hotkeys('alt+del,alt+backspace', on_clearstyles);
    hotkeys(`${metaKey}+e,${metaKey}+shift+e`, on_expand_selection);
    hotkeys(`${metaKey}+g,${metaKey}+shift+g`, on_group);
    hotkeys('tab,shift+tab,enter,shift+enter', on_keyboard_traversal);
  };

  const unlisten = () => {
    elements.forEach(el => el.removeEventListener('click', on_click, true));
    elements.forEach(el => el.removeEventListener('dblclick', on_dblclick, true));
    elements.off('selectstart', on_selection);
    elements.off('mouseover', on_hover);
    elements.off('mouseout', on_hoverout);

    document.removeEventListener('copy', on_copy);
    document.removeEventListener('cut', on_cut);
    document.removeEventListener('paste', on_paste);

    hotkeys.unbind(`esc,${metaKey}+d,backspace,del,delete,alt+del,alt+backspace,${metaKey}+e,${metaKey}+shift+e,${metaKey}+g,${metaKey}+shift+g,tab,shift+tab,enter,shift+enter`);
  };

  const on_click = e => {
    if (isOffBounds(e.target) && !selected.filter(el => el == e.target).length)
      return

    e.preventDefault();
    if (!e.altKey) e.stopPropagation();
    if (!e.shiftKey) unselect_all();

    if(e.shiftKey && e.target.hasAttribute('data-label-id'))
      unselect(e.target.getAttribute('data-label-id'));
    else
    select(e.target);
  };

  const unselect = id => {

    [...labels, ...handles]
      .filter(node =>
          node.getAttribute('data-label-id') === id)
        .forEach(node =>
          node.remove());

    selected.filter(node =>
      node.getAttribute('data-label-id') === id)
      .forEach(node =>
        $(node).attr({
          'data-selected':      null,
          'data-selected-hide': null,
          'data-label-id':      null,
          'data-hover': null
      }));

    selected = selected.filter(node => node.getAttribute('data-label-id') !== id);

    tellWatchers();
  };

  const on_dblclick = e => {
    e.preventDefault();
    e.stopPropagation();
    if (isOffBounds(e.target)) return
    $('tool-pallete')[0].toolSelected('text');
  };

  const watchCommandKey = e => {
    let did_hide = false;

    document.onkeydown = function(e) {
      if (hotkeys.ctrl && selected.length) {
        $('pb-handles, pb-label').forEach(el =>
          el.style.display = 'none');

        did_hide = true;
      }
    };

    document.onkeyup = function(e) {
      if (did_hide) {
        $('pb-handles, pb-label').forEach(el =>
          el.style.display = null);

        did_hide = false;
      }
    };
  };

  const on_esc = _ =>
    selected.length && unselect_all();

  const on_duplicate = e => {
    const root_node = selected[0];
    if (!root_node) return

    const deep_clone = root_node.cloneNode(true);
    deep_clone.removeAttribute('data-selected');
    root_node.parentNode.insertBefore(deep_clone, root_node.nextSibling);
    e.preventDefault();
  };

  const on_delete = e =>
    selected.length && delete_all();

  const on_clearstyles = e =>
    selected.forEach(el =>
      el.attr('style', null));

  const on_copy = e => {
    // if user has selected text, dont try to copy an element
    if (window.getSelection().toString().length)
      return

    if (selected[0] && this.node_clipboard !== selected[0]) {
      e.preventDefault();
      let $node = selected[0].cloneNode(true);
      $node.removeAttribute('data-selected');
      this.copy_backup = $node.outerHTML;
      e.clipboardData.setData('text/html', this.copy_backup);
    }
  };

  const on_cut = e => {
    if (selected[0] && this.node_clipboard !== selected[0]) {
      let $node = selected[0].cloneNode(true);
      $node.removeAttribute('data-selected');
      this.copy_backup = $node.outerHTML;
      e.clipboardData.setData('text/html', this.copy_backup);
      selected[0].remove();
    }
  };

  const on_paste = e => {
    const clipData = e.clipboardData.getData('text/html');
    const potentialHTML = clipData || this.copy_backup;
    if (selected[0] && potentialHTML) {
      e.preventDefault();
      selected[0].appendChild(
        htmlStringToDom(potentialHTML));
    }
  };

  const on_copy_styles = e => {
    e.preventDefault();
    this.copied_styles = selected.map(el =>
      getStyles(el));
  };

  const on_paste_styles = (index = 0) =>
    selected.forEach(el => {
      this.copied_styles[index]
        .map(({prop, value}) =>
          el.style[prop] = value);

      index >= this.copied_styles.length - 1
        ? index = 0
        : index++;
    });

  const on_expand_selection = (e, {key}) => {
    e.preventDefault();

    expandSelection({
      query:  combineNodeNameAndClass(selected[0]),
      all:    key.includes('shift'),
    });
  };

  const on_group = (e, {key}) => {
    e.preventDefault();

    if (key.split('+').includes('shift')) {
      let $selected = [...selected];
      unselect_all();
      $selected.reverse().forEach(el => {
        let l = el.children.length;
        while (el.children.length > 0) {
          var node = el.childNodes[el.children.length - 1];
          if (node.nodeName !== '#text')
            select(node);
          el.parentNode.prepend(node);
        }
        el.parentNode.removeChild(el);
      });
    }
    else {
      let div = document.createElement('div');
      selected[0].parentNode.prepend(
        selected.reverse().reduce((div, el) => {
          div.appendChild(el);
          return div
        }, div)
      );
      unselect_all();
      select(div);
    }
  };

  const on_selection = e =>
    !isOffBounds(e.target)
    && selected.length
    && selected[0].textContent != e.target.textContent
    && e.preventDefault();

  const on_keyboard_traversal = (e, {key}) => {
    if (selected.length !== 1) return

    e.preventDefault();
    e.stopPropagation();

    const current = selected[0];

    if (key.includes('shift')) {
      if (key.includes('tab') && canMoveLeft(current)) {
        unselect_all();
        select(canMoveLeft(current));
      }
      if (key.includes('enter') && canMoveUp(current)) {
        unselect_all();
        select(current.parentNode);
      }
    }
    else {
      if (key.includes('tab') && canMoveRight(current)) {
        unselect_all();
        select(canMoveRight(current));
      }
      if (key.includes('enter') && current.children.length) {
        unselect_all();
        select(current.children[0]);
      }
    }
  };

  const on_hover = ({target}) => {
    if (isOffBounds(target)) return
    target.setAttribute('data-hover', true);
  };

  const on_hoverout = ({target}) => {
    target.removeAttribute('data-hover');
  };

  const select = el => {
    el.setAttribute('data-selected', true);
    overlayMetaUI(el);
    selected.unshift(el);
    tellWatchers();
  };

  const unselect_all = () => {
    selected
      .forEach(el =>
        $(el).attr({
          'data-selected':      null,
          'data-selected-hide': null,
          'data-label-id':      null,
          'data-hover':         null,
        }));

    handles.forEach(el =>
      el.remove());

    labels.forEach(el =>
      el.remove());

    labels    = [];
    handles   = [];
    selected  = [];
  };

  const delete_all = () => {
    const selected_after_delete = selected.map(el => {
      if (canMoveRight(el))     return canMoveRight(el)
      else if (canMoveLeft(el)) return canMoveLeft(el)
      else if (el.parentNode)   return el.parentNode
    });

    Array.from([...selected, ...labels, ...handles]).forEach(el =>
      el.remove());

    labels    = [];
    handles   = [];
    selected  = [];

    selected_after_delete.forEach(el =>
      select(el));
  };

  const expandSelection = ({query, all = false}) => {
    if (all) {
      const unselecteds = $(query + ':not([data-selected])');
      unselecteds.forEach(select);
    }
    else {
      const potentials = $(query);
      if (!potentials) return

      const root_node_index = potentials.reduce((index, node, i) =>
        combineNodeNameAndClass(node) == query
          ? index = i
          : index
      , null);

      if (root_node_index !== null) {
        if (!potentials[root_node_index + 1]) {
          const potential = potentials.filter(el => !el.attr('data-selected'))[0];
          if (potential) select(potential);
        }
        else {
          select(potentials[root_node_index + 1]);
        }
      }
    }
  };

  const combineNodeNameAndClass = node =>
    `${node.nodeName.toLowerCase()}${createClassname(node)}`;

  const overlayMetaUI = el => {
    let handle = createHandle(el);
    let label  = createLabel(el, `
      <a>${el.nodeName.toLowerCase()}</a>
      <a>${el.id && '#' + el.id}</a>
      ${createClassname(el).split('.')
        .filter(name => name != '')
        .reduce((links, name) => `
          ${links}
          <a>.${name}</a>
        `, '')
      }
    `);

    let observer        = createObserver(el, {handle,label});
    let parentObserver  = createObserver(el, {handle,label});

    observer.observe(el, { attributes: true });
    parentObserver.observe(el.parentNode, { childList:true, subtree:true });

    $(label).on('DOMNodeRemoved', _ => {
      observer.disconnect();
      parentObserver.disconnect();
    });
  };

  const setLabel = (el, label) =>
    label.update = el.getBoundingClientRect();

  const createLabel = (el, text) => {
    if (!labels[parseInt(el.getAttribute('data-label-id'))]) {
      const label = document.createElement('pb-label');

      label.text = text;
      label.position = {
        boundingRect:   el.getBoundingClientRect(),
        node_label_id:  labels.length,
      };
      el.setAttribute('data-label-id', labels.length);

      document.body.appendChild(label);

      $(label).on('query', ({detail}) => {
        if (!detail.text) return
        this.query_text = detail.text;

        queryPage('[data-hover]', el =>
          el.setAttribute('data-hover', null));

        queryPage(this.query_text + ':not([data-selected])', el =>
          detail.activator === 'mouseenter'
            ? el.setAttribute('data-hover', true)
            : select(el));
      });

      $(label).on('mouseleave', e => {
        e.preventDefault();
        e.stopPropagation();
        queryPage('[data-hover]', el =>
          el.setAttribute('data-hover', null));
      });

      labels[labels.length] = label;
      return label
    }
  };

  const createHandle = el => {
    if (!handles[parseInt(el.getAttribute('data-label-id'))]) {
      const handle = document.createElement('pb-handles');

      handle.position = {
        boundingRect:   el.getBoundingClientRect(),
        node_label_id:  handles.length,
      };

      document.body.appendChild(handle);

      handles[handles.length] = handle;
      return handle
    }
  };

  const setHandle = (node, handle) => {
    handle.position = {
      boundingRect:   node.getBoundingClientRect(),
      node_label_id:  node.getAttribute('data-label-id'),
    };
  };

  const createObserver = (node, {label,handle}) =>
    new MutationObserver(list => {
      setLabel(node, label);
      setHandle(node, handle);
    });

  const onSelectedUpdate = (cb, immediateCallback = true) => {
    selectedCallbacks.push(cb);
    if (immediateCallback) cb(selected);
  };

  const removeSelectedCallback = cb =>
    selectedCallbacks = selectedCallbacks.filter(callback => callback != cb);

  const tellWatchers = () =>
    selectedCallbacks.forEach(cb => cb(selected));

  const disconnect = () => {
    unselect_all();
    unlisten();
  };

  watchImagesForUpload();
  listen();

  return {
    select,
    unselect_all,
    onSelectedUpdate,
    removeSelectedCallback,
    disconnect
  }
}

// todo: show padding color
const key_events$2 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},alt+${event},shift+${event},shift+alt+${event}`
  , '')
  .substring(1);

const command_events$1 = `${metaKey}+up,${metaKey}+shift+up,${metaKey}+down,${metaKey}+shift+down`;

function Padding(selector) {
  hotkeys(key_events$2, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();
    padElement($(selector), handler.key);
  });

  hotkeys(command_events$1, (e, handler) => {
    e.preventDefault();
    padAllElementSides($(selector), handler.key);
  });

  return () => {
    hotkeys.unbind(key_events$2);
    hotkeys.unbind(command_events$1);
    hotkeys.unbind('up,down,left,right'); // bug in lib?
  }
}

function padElement(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'padding' + getSide(direction),
      current:  parseInt(getStyle(el, 'padding' + getSide(direction)), 10),
      amount:   direction.split('+').includes('shift') ? 10 : 1,
      negative: direction.split('+').includes('alt'),
    }))
    .map(payload =>
      Object.assign(payload, {
        padding: payload.negative
          ? payload.current - payload.amount
          : payload.current + payload.amount
      }))
    .forEach(({el, style, padding}) =>
      el.style[style] = `${padding < 0 ? 0 : padding}px`);
}

function padAllElementSides(els, keycommand) {
  const combo = keycommand.split('+');
  let spoof = '';

  if (combo.includes('shift'))  spoof = 'shift+' + spoof;
  if (combo.includes('down'))   spoof = 'alt+' + spoof;

  'up,down,left,right'.split(',')
    .forEach(side => padElement(els, spoof + side));
}

const removeEditability = ({target}) => {
  target.removeAttribute('contenteditable');
  target.removeAttribute('spellcheck');
  target.removeEventListener('blur', removeEditability);
  target.removeEventListener('keydown', stopBubbling$1);
  hotkeys.unbind('escape,esc');
};

const stopBubbling$1 = e => e.key != 'Escape' && e.stopPropagation();

const cleanup = (e, handler) => {
  $('[spellcheck="true"]').forEach(target => removeEditability({target}));
  window.getSelection().empty();
};

function EditText(elements) {
  if (!elements.length) return

  elements.map(el => {
    let $el = $(el);

    $el.attr({
      contenteditable: true,
      spellcheck: true,
    });
    el.focus();
    showHideNodeLabel(el, true);

    $el.on('keydown', stopBubbling$1);
    $el.on('blur', removeEditability);
  });

  hotkeys('escape,esc', cleanup);
}

const key_events$3 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},shift+${event}`
  , '')
  .substring(1);

const command_events$2 = `${metaKey}+up,${metaKey}+down`;

function Font(selector) {
  hotkeys(key_events$3, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();

    let selectedNodes = $(selector)
      , keys = handler.key.split('+');

    if (keys.includes('left') || keys.includes('right'))
      keys.includes('shift')
        ? changeKerning(selectedNodes, handler.key)
        : changeAlignment(selectedNodes, handler.key);
    else
      keys.includes('shift')
        ? changeLeading(selectedNodes, handler.key)
        : changeFontSize(selectedNodes, handler.key);
  });

  hotkeys(command_events$2, (e, handler) => {
    e.preventDefault();
    let keys = handler.key.split('+');
    changeFontWeight($(selector), keys.includes('up') ? 'up' : 'down');
  });

  hotkeys('cmd+b', e => {
    $(selector).forEach(el =>
      el.style.fontWeight =
        el.style.fontWeight == 'bold'
          ? null
          : 'bold');
  });

  hotkeys('cmd+i', e => {
    $(selector).forEach(el =>
      el.style.fontStyle =
        el.style.fontStyle == 'italic'
          ? null
          : 'italic');
  });

  return () => {
    hotkeys.unbind(key_events$3);
    hotkeys.unbind(command_events$2);
    hotkeys.unbind('cmd+b,cmd+i');
    hotkeys.unbind('up,down,left,right');
  }
}

function changeLeading(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'lineHeight',
      current:  parseInt(getStyle(el, 'lineHeight')),
      amount:   1,
      negative: direction.split('+').includes('down'),
    }))
    .map(payload =>
      Object.assign(payload, {
        current: payload.current == 'normal' || isNaN(payload.current)
          ? 1.14 * parseInt(getStyle(payload.el, 'fontSize')) // document this choice
          : payload.current
      }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.negative
          ? payload.current - payload.amount
          : payload.current + payload.amount
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = `${value}px`);
}

function changeKerning(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'letterSpacing',
      current:  parseFloat(getStyle(el, 'letterSpacing')),
      amount:   .1,
      negative: direction.split('+').includes('left'),
    }))
    .map(payload =>
      Object.assign(payload, {
        current: payload.current == 'normal' || isNaN(payload.current)
          ? 0
          : payload.current
      }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.negative
          ? (payload.current - payload.amount).toFixed(2)
          : (payload.current + payload.amount).toFixed(2)
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = `${value <= -2 ? -2 : value}px`);
}

function changeFontSize(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'fontSize',
      current:  parseInt(getStyle(el, 'fontSize')),
      amount:   direction.split('+').includes('shift') ? 10 : 1,
      negative: direction.split('+').includes('down'),
    }))
    .map(payload =>
      Object.assign(payload, {
        font_size: payload.negative
          ? payload.current - payload.amount
          : payload.current + payload.amount
      }))
    .forEach(({el, style, font_size}) =>
      el.style[style] = `${font_size <= 6 ? 6 : font_size}px`);
}

const weightMap = {
  normal: 2,
  bold:   5,
  light:  0,
  "": 2,
  "100":0,"200":1,"300":2,"400":3,"500":4,"600":5,"700":6,"800":7,"900":8
};
const weightOptions = [100,200,300,400,500,600,700,800,900];

function changeFontWeight(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'fontWeight',
      current:  getStyle(el, 'fontWeight'),
      direction: direction.split('+').includes('down'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? weightMap[payload.current] - 1
          : weightMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = weightOptions[value < 0 ? 0 : value >= weightOptions.length
        ? weightOptions.length
        : value
      ]);
}

const alignMap = {
  start: 0,
  left: 0,
  center: 1,
  right: 2,
};
const alignOptions = ['left','center','right'];

function changeAlignment(els, direction) {
  els
    .map(el => showHideSelected(el))
    .map(el => ({
      el,
      style:    'textAlign',
      current:  getStyle(el, 'textAlign'),
      direction: direction.split('+').includes('left'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? alignMap[payload.current] - 1
          : alignMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = alignOptions[value < 0 ? 0 : value >= 2 ? 2: value]);
}

const key_events$4 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},shift+${event}`
  , '')
  .substring(1);

const command_events$3 = `${metaKey}+up,${metaKey}+down,${metaKey}+left,${metaKey}+right`;

function Flex(selector) {
  hotkeys(key_events$4, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();

    let selectedNodes = $(selector)
      , keys = handler.key.split('+');

    if (keys.includes('left') || keys.includes('right'))
      keys.includes('shift')
        ? changeHDistribution(selectedNodes, handler.key)
        : changeHAlignment(selectedNodes, handler.key);
    else
      keys.includes('shift')
        ? changeVDistribution(selectedNodes, handler.key)
        : changeVAlignment(selectedNodes, handler.key);
  });

  hotkeys(command_events$3, (e, handler) => {
    e.preventDefault();

    let selectedNodes = $(selector)
      , keys = handler.key.split('+');

    changeDirection(selectedNodes, keys.includes('left') ? 'row' : 'column');
  });

  return () => {
    hotkeys.unbind(key_events$4);
    hotkeys.unbind(command_events$3);
    hotkeys.unbind('up,down,left,right');
  }
}

const ensureFlex = el => {
  el.style.display = 'flex';
  return el
};

const accountForOtherJustifyContent = (cur, want) => {
  if (want == 'align' && (cur != 'flex-start' && cur != 'center' && cur != 'flex-end'))
    cur = 'normal';
  else if (want == 'distribute' && (cur != 'space-around' && cur != 'space-between'))
    cur = 'normal';

  return cur
};

// todo: support reversing direction
function changeDirection(els, value) {
  els
    .map(ensureFlex)
    .map(el => {
      el.style.flexDirection = value;
    });
}

const h_alignMap      = {normal: 0,'flex-start': 0,'center': 1,'flex-end': 2,};
const h_alignOptions$1  = ['flex-start','center','flex-end'];

function changeHAlignment(els, direction) {
  els
    .map(ensureFlex)
    .map(el => ({
      el,
      style:    'justifyContent',
      current:  accountForOtherJustifyContent(getStyle(el, 'justifyContent'), 'align'),
      direction: direction.split('+').includes('left'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? h_alignMap[payload.current] - 1
          : h_alignMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = h_alignOptions$1[value < 0 ? 0 : value >= 2 ? 2: value]);
}
const v_alignOptions$1  = ['flex-start','center','flex-end'];

function changeVAlignment(els, direction) {
  els
    .map(ensureFlex)
    .map(el => ({
      el,
      style:    'alignItems',
      current:  getStyle(el, 'alignItems'),
      direction: direction.split('+').includes('up'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? h_alignMap[payload.current] - 1
          : h_alignMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = v_alignOptions$1[value < 0 ? 0 : value >= 2 ? 2: value]);
}

const h_distributionMap      = {normal: 1,'space-around': 0,'': 1,'space-between': 2,};
const h_distributionOptions  = ['space-around','','space-between'];

function changeHDistribution(els, direction) {
  els
    .map(ensureFlex)
    .map(el => ({
      el,
      style:    'justifyContent',
      current:  accountForOtherJustifyContent(getStyle(el, 'justifyContent'), 'distribute'),
      direction: direction.split('+').includes('left'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? h_distributionMap[payload.current] - 1
          : h_distributionMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = h_distributionOptions[value < 0 ? 0 : value >= 2 ? 2: value]);
}

const v_distributionMap      = {normal: 1,'space-around': 0,'': 1,'space-between': 2,};
const v_distributionOptions  = ['space-around','','space-between'];

function changeVDistribution(els, direction) {
  els
    .map(ensureFlex)
    .map(el => ({
      el,
      style:    'alignContent',
      current:  getStyle(el, 'alignContent'),
      direction: direction.split('+').includes('up'),
    }))
    .map(payload =>
      Object.assign(payload, {
        value: payload.direction
          ? v_distributionMap[payload.current] - 1
          : v_distributionMap[payload.current] + 1
      }))
    .forEach(({el, style, value}) =>
      el.style[style] = v_distributionOptions[value < 0 ? 0 : value >= 2 ? 2: value]);
}

/**
 * Take input from [0, n] and return it as [0, 1]
 * @hidden
 */
function bound01(n, max) {
    if (isOnePointZero(n)) {
        n = '100%';
    }
    const processPercent = isPercentage(n);
    n = max === 360 ? n : Math.min(max, Math.max(0, parseFloat(n)));
    // Automatically convert percentage into number
    if (processPercent) {
        n = parseInt(String(n * max), 10) / 100;
    }
    // Handle floating point rounding errors
    if (Math.abs(n - max) < 0.000001) {
        return 1;
    }
    // Convert into [0, 1] range if it isn't already
    if (max === 360) {
        // If n is a hue given in degrees,
        // wrap around out-of-range values into [0, 360] range
        // then convert into [0, 1].
        n = (n < 0 ? n % max + max : n % max) / parseFloat(String(max));
    }
    else {
        // If n not a hue given in degrees
        // Convert into [0, 1] range if it isn't already.
        n = (n % max) / parseFloat(String(max));
    }
    return n;
}
/**
 * Force a number between 0 and 1
 * @hidden
 */
function clamp01(val) {
    return Math.min(1, Math.max(0, val));
}
/**
 * Need to handle 1.0 as 100%, since once it is a number, there is no difference between it and 1
 * <http://stackoverflow.com/questions/7422072/javascript-how-to-detect-number-as-a-decimal-including-1-0>
 * @hidden
 */
function isOnePointZero(n) {
    return typeof n === 'string' && n.indexOf('.') !== -1 && parseFloat(n) === 1;
}
/**
 * Check to see if string passed in is a percentage
 * @hidden
 */
function isPercentage(n) {
    return typeof n === 'string' && n.indexOf('%') !== -1;
}
/**
 * Return a valid alpha value [0,1] with all invalid values being set to 1
 * @hidden
 */
function boundAlpha(a) {
    a = parseFloat(a);
    if (isNaN(a) || a < 0 || a > 1) {
        a = 1;
    }
    return a;
}
/**
 * Replace a decimal with it's percentage value
 * @hidden
 */
function convertToPercentage(n) {
    if (n <= 1) {
        return +n * 100 + '%';
    }
    return n;
}
/**
 * Force a hex value to have 2 characters
 * @hidden
 */
function pad2(c) {
    return c.length === 1 ? '0' + c : '' + c;
}

// `rgbToHsl`, `rgbToHsv`, `hslToRgb`, `hsvToRgb` modified from:
// <http://mjijackson.com/2008/02/rgb-to-hsl-and-rgb-to-hsv-color-model-conversion-algorithms-in-javascript>
/**
 * Handle bounds / percentage checking to conform to CSS color spec
 * <http://www.w3.org/TR/css3-color/>
 * *Assumes:* r, g, b in [0, 255] or [0, 1]
 * *Returns:* { r, g, b } in [0, 255]
 */
function rgbToRgb(r, g, b) {
    return {
        r: bound01(r, 255) * 255,
        g: bound01(g, 255) * 255,
        b: bound01(b, 255) * 255,
    };
}
/**
 * Converts an RGB color value to HSL.
 * *Assumes:* r, g, and b are contained in [0, 255] or [0, 1]
 * *Returns:* { h, s, l } in [0,1]
 */
function rgbToHsl(r, g, b) {
    r = bound01(r, 255);
    g = bound01(g, 255);
    b = bound01(b, 255);
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0;
    let s = 0;
    const l = (max + min) / 2;
    if (max === min) {
        h = s = 0; // achromatic
    }
    else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r:
                h = (g - b) / d + (g < b ? 6 : 0);
                break;
            case g:
                h = (b - r) / d + 2;
                break;
            case b:
                h = (r - g) / d + 4;
                break;
        }
        h /= 6;
    }
    return { h, s, l };
}
/**
 * Converts an HSL color value to RGB.
 *
 * *Assumes:* h is contained in [0, 1] or [0, 360] and s and l are contained [0, 1] or [0, 100]
 * *Returns:* { r, g, b } in the set [0, 255]
 */
function hslToRgb(h, s, l) {
    let r;
    let g;
    let b;
    h = bound01(h, 360);
    s = bound01(s, 100);
    l = bound01(l, 100);
    function hue2rgb(p, q, t) {
        if (t < 0)
            t += 1;
        if (t > 1)
            t -= 1;
        if (t < 1 / 6) {
            return p + (q - p) * 6 * t;
        }
        if (t < 1 / 2) {
            return q;
        }
        if (t < 2 / 3) {
            return p + (q - p) * (2 / 3 - t) * 6;
        }
        return p;
    }
    if (s === 0) {
        r = g = b = l; // achromatic
    }
    else {
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        r = hue2rgb(p, q, h + 1 / 3);
        g = hue2rgb(p, q, h);
        b = hue2rgb(p, q, h - 1 / 3);
    }
    return { r: r * 255, g: g * 255, b: b * 255 };
}
/**
 * Converts an RGB color value to HSV
 *
 * *Assumes:* r, g, and b are contained in the set [0, 255] or [0, 1]
 * *Returns:* { h, s, v } in [0,1]
 */
function rgbToHsv(r, g, b) {
    r = bound01(r, 255);
    g = bound01(g, 255);
    b = bound01(b, 255);
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0;
    const v = max;
    const d = max - min;
    const s = max === 0 ? 0 : d / max;
    if (max === min) {
        h = 0; // achromatic
    }
    else {
        switch (max) {
            case r:
                h = (g - b) / d + (g < b ? 6 : 0);
                break;
            case g:
                h = (b - r) / d + 2;
                break;
            case b:
                h = (r - g) / d + 4;
                break;
        }
        h /= 6;
    }
    return { h: h, s: s, v: v };
}
/**
 * Converts an HSV color value to RGB.
 *
 * *Assumes:* h is contained in [0, 1] or [0, 360] and s and v are contained in [0, 1] or [0, 100]
 * *Returns:* { r, g, b } in the set [0, 255]
 */
function hsvToRgb(h, s, v) {
    h = bound01(h, 360) * 6;
    s = bound01(s, 100);
    v = bound01(v, 100);
    const i = Math.floor(h);
    const f = h - i;
    const p = v * (1 - s);
    const q = v * (1 - f * s);
    const t = v * (1 - (1 - f) * s);
    const mod = i % 6;
    const r = [v, q, p, p, t, v][mod];
    const g = [t, v, v, q, p, p][mod];
    const b = [p, p, t, v, v, q][mod];
    return { r: r * 255, g: g * 255, b: b * 255 };
}
/**
 * Converts an RGB color to hex
 *
 * Assumes r, g, and b are contained in the set [0, 255]
 * Returns a 3 or 6 character hex
 */
function rgbToHex(r, g, b, allow3Char) {
    const hex = [
        pad2(Math.round(r).toString(16)),
        pad2(Math.round(g).toString(16)),
        pad2(Math.round(b).toString(16)),
    ];
    // Return a 3 character hex if possible
    if (allow3Char &&
        hex[0].charAt(0) === hex[0].charAt(1) &&
        hex[1].charAt(0) === hex[1].charAt(1) &&
        hex[2].charAt(0) === hex[2].charAt(1)) {
        return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0);
    }
    return hex.join('');
}
/**
 * Converts an RGBA color plus alpha transparency to hex
 *
 * Assumes r, g, b are contained in the set [0, 255] and
 * a in [0, 1]. Returns a 4 or 8 character rgba hex
 */
function rgbaToHex(r, g, b, a, allow4Char) {
    const hex = [
        pad2(Math.round(r).toString(16)),
        pad2(Math.round(g).toString(16)),
        pad2(Math.round(b).toString(16)),
        pad2(convertDecimalToHex(a)),
    ];
    // Return a 4 character hex if possible
    if (allow4Char &&
        hex[0].charAt(0) === hex[0].charAt(1) &&
        hex[1].charAt(0) === hex[1].charAt(1) &&
        hex[2].charAt(0) === hex[2].charAt(1) &&
        hex[3].charAt(0) === hex[3].charAt(1)) {
        return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0) + hex[3].charAt(0);
    }
    return hex.join('');
}
/** Converts a decimal to a hex value */
function convertDecimalToHex(d) {
    return Math.round(parseFloat(d) * 255).toString(16);
}
/** Converts a hex value to a decimal */
function convertHexToDecimal(h) {
    return parseIntFromHex(h) / 255;
}
/** Parse a base-16 hex value into a base-10 integer */
function parseIntFromHex(val) {
    return parseInt(val, 16);
}

// https://github.com/bahamas10/css-color-names/blob/master/css-color-names.json
/**
 * @hidden
 */
const names = {
    aliceblue: '#f0f8ff',
    antiquewhite: '#faebd7',
    aqua: '#00ffff',
    aquamarine: '#7fffd4',
    azure: '#f0ffff',
    beige: '#f5f5dc',
    bisque: '#ffe4c4',
    black: '#000000',
    blanchedalmond: '#ffebcd',
    blue: '#0000ff',
    blueviolet: '#8a2be2',
    brown: '#a52a2a',
    burlywood: '#deb887',
    cadetblue: '#5f9ea0',
    chartreuse: '#7fff00',
    chocolate: '#d2691e',
    coral: '#ff7f50',
    cornflowerblue: '#6495ed',
    cornsilk: '#fff8dc',
    crimson: '#dc143c',
    cyan: '#00ffff',
    darkblue: '#00008b',
    darkcyan: '#008b8b',
    darkgoldenrod: '#b8860b',
    darkgray: '#a9a9a9',
    darkgreen: '#006400',
    darkgrey: '#a9a9a9',
    darkkhaki: '#bdb76b',
    darkmagenta: '#8b008b',
    darkolivegreen: '#556b2f',
    darkorange: '#ff8c00',
    darkorchid: '#9932cc',
    darkred: '#8b0000',
    darksalmon: '#e9967a',
    darkseagreen: '#8fbc8f',
    darkslateblue: '#483d8b',
    darkslategray: '#2f4f4f',
    darkslategrey: '#2f4f4f',
    darkturquoise: '#00ced1',
    darkviolet: '#9400d3',
    deeppink: '#ff1493',
    deepskyblue: '#00bfff',
    dimgray: '#696969',
    dimgrey: '#696969',
    dodgerblue: '#1e90ff',
    firebrick: '#b22222',
    floralwhite: '#fffaf0',
    forestgreen: '#228b22',
    fuchsia: '#ff00ff',
    gainsboro: '#dcdcdc',
    ghostwhite: '#f8f8ff',
    gold: '#ffd700',
    goldenrod: '#daa520',
    gray: '#808080',
    green: '#008000',
    greenyellow: '#adff2f',
    grey: '#808080',
    honeydew: '#f0fff0',
    hotpink: '#ff69b4',
    indianred: '#cd5c5c',
    indigo: '#4b0082',
    ivory: '#fffff0',
    khaki: '#f0e68c',
    lavender: '#e6e6fa',
    lavenderblush: '#fff0f5',
    lawngreen: '#7cfc00',
    lemonchiffon: '#fffacd',
    lightblue: '#add8e6',
    lightcoral: '#f08080',
    lightcyan: '#e0ffff',
    lightgoldenrodyellow: '#fafad2',
    lightgray: '#d3d3d3',
    lightgreen: '#90ee90',
    lightgrey: '#d3d3d3',
    lightpink: '#ffb6c1',
    lightsalmon: '#ffa07a',
    lightseagreen: '#20b2aa',
    lightskyblue: '#87cefa',
    lightslategray: '#778899',
    lightslategrey: '#778899',
    lightsteelblue: '#b0c4de',
    lightyellow: '#ffffe0',
    lime: '#00ff00',
    limegreen: '#32cd32',
    linen: '#faf0e6',
    magenta: '#ff00ff',
    maroon: '#800000',
    mediumaquamarine: '#66cdaa',
    mediumblue: '#0000cd',
    mediumorchid: '#ba55d3',
    mediumpurple: '#9370db',
    mediumseagreen: '#3cb371',
    mediumslateblue: '#7b68ee',
    mediumspringgreen: '#00fa9a',
    mediumturquoise: '#48d1cc',
    mediumvioletred: '#c71585',
    midnightblue: '#191970',
    mintcream: '#f5fffa',
    mistyrose: '#ffe4e1',
    moccasin: '#ffe4b5',
    navajowhite: '#ffdead',
    navy: '#000080',
    oldlace: '#fdf5e6',
    olive: '#808000',
    olivedrab: '#6b8e23',
    orange: '#ffa500',
    orangered: '#ff4500',
    orchid: '#da70d6',
    palegoldenrod: '#eee8aa',
    palegreen: '#98fb98',
    paleturquoise: '#afeeee',
    palevioletred: '#db7093',
    papayawhip: '#ffefd5',
    peachpuff: '#ffdab9',
    peru: '#cd853f',
    pink: '#ffc0cb',
    plum: '#dda0dd',
    powderblue: '#b0e0e6',
    purple: '#800080',
    rebeccapurple: '#663399',
    red: '#ff0000',
    rosybrown: '#bc8f8f',
    royalblue: '#4169e1',
    saddlebrown: '#8b4513',
    salmon: '#fa8072',
    sandybrown: '#f4a460',
    seagreen: '#2e8b57',
    seashell: '#fff5ee',
    sienna: '#a0522d',
    silver: '#c0c0c0',
    skyblue: '#87ceeb',
    slateblue: '#6a5acd',
    slategray: '#708090',
    slategrey: '#708090',
    snow: '#fffafa',
    springgreen: '#00ff7f',
    steelblue: '#4682b4',
    tan: '#d2b48c',
    teal: '#008080',
    thistle: '#d8bfd8',
    tomato: '#ff6347',
    turquoise: '#40e0d0',
    violet: '#ee82ee',
    wheat: '#f5deb3',
    white: '#ffffff',
    whitesmoke: '#f5f5f5',
    yellow: '#ffff00',
    yellowgreen: '#9acd32',
};

/**
 * Given a string or object, convert that input to RGB
 *
 * Possible string inputs:
 * ```
 * "red"
 * "#f00" or "f00"
 * "#ff0000" or "ff0000"
 * "#ff000000" or "ff000000"
 * "rgb 255 0 0" or "rgb (255, 0, 0)"
 * "rgb 1.0 0 0" or "rgb (1, 0, 0)"
 * "rgba (255, 0, 0, 1)" or "rgba 255, 0, 0, 1"
 * "rgba (1.0, 0, 0, 1)" or "rgba 1.0, 0, 0, 1"
 * "hsl(0, 100%, 50%)" or "hsl 0 100% 50%"
 * "hsla(0, 100%, 50%, 1)" or "hsla 0 100% 50%, 1"
 * "hsv(0, 100%, 100%)" or "hsv 0 100% 100%"
 * ```
 */
function inputToRGB(color) {
    let rgb = { r: 0, g: 0, b: 0 };
    let a = 1;
    let s = null;
    let v = null;
    let l = null;
    let ok = false;
    let format = false;
    if (typeof color === 'string') {
        color = stringInputToObject(color);
    }
    if (typeof color === 'object') {
        if (isValidCSSUnit(color.r) && isValidCSSUnit(color.g) && isValidCSSUnit(color.b)) {
            rgb = rgbToRgb(color.r, color.g, color.b);
            ok = true;
            format = String(color.r).substr(-1) === '%' ? 'prgb' : 'rgb';
        }
        else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.v)) {
            s = convertToPercentage(color.s);
            v = convertToPercentage(color.v);
            rgb = hsvToRgb(color.h, s, v);
            ok = true;
            format = 'hsv';
        }
        else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.l)) {
            s = convertToPercentage(color.s);
            l = convertToPercentage(color.l);
            rgb = hslToRgb(color.h, s, l);
            ok = true;
            format = 'hsl';
        }
        if (color.hasOwnProperty('a')) {
            a = color.a;
        }
    }
    a = boundAlpha(a);
    return {
        ok,
        format: color.format || format,
        r: Math.min(255, Math.max(rgb.r, 0)),
        g: Math.min(255, Math.max(rgb.g, 0)),
        b: Math.min(255, Math.max(rgb.b, 0)),
        a,
    };
}
// <http://www.w3.org/TR/css3-values/#integers>
const CSS_INTEGER = '[-\\+]?\\d+%?';
// <http://www.w3.org/TR/css3-values/#number-value>
const CSS_NUMBER = '[-\\+]?\\d*\\.\\d+%?';
// Allow positive/negative integer/number.  Don't capture the either/or, just the entire outcome.
const CSS_UNIT = `(?:${CSS_NUMBER})|(?:${CSS_INTEGER})`;
// Actual matching.
// Parentheses and commas are optional, but not required.
// Whitespace can take the place of commas or opening paren
const PERMISSIVE_MATCH3 = `[\\s|\\(]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})\\s*\\)?`;
const PERMISSIVE_MATCH4 = `[\\s|\\(]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})[,|\\s]+(${CSS_UNIT})\\s*\\)?`;
const matchers = {
    CSS_UNIT: new RegExp(CSS_UNIT),
    rgb: new RegExp('rgb' + PERMISSIVE_MATCH3),
    rgba: new RegExp('rgba' + PERMISSIVE_MATCH4),
    hsl: new RegExp('hsl' + PERMISSIVE_MATCH3),
    hsla: new RegExp('hsla' + PERMISSIVE_MATCH4),
    hsv: new RegExp('hsv' + PERMISSIVE_MATCH3),
    hsva: new RegExp('hsva' + PERMISSIVE_MATCH4),
    hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
    hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
};
/**
 * Permissive string parsing.  Take in a number of formats, and output an object
 * based on detected format.  Returns `{ r, g, b }` or `{ h, s, l }` or `{ h, s, v}`
 */
function stringInputToObject(color) {
    color = color.trim().toLowerCase();
    if (color.length === 0) {
        return false;
    }
    let named = false;
    if (names[color]) {
        color = names[color];
        named = true;
    }
    else if (color === 'transparent') {
        return { r: 0, g: 0, b: 0, a: 0, format: 'name' };
    }
    // Try to match string input using regular expressions.
    // Keep most of the number bounding out of this function - don't worry about [0,1] or [0,100] or [0,360]
    // Just return an object and let the conversion functions handle that.
    // This way the result will be the same whether the tinycolor is initialized with string or object.
    let match = matchers.rgb.exec(color);
    if (match) {
        return { r: match[1], g: match[2], b: match[3] };
    }
    match = matchers.rgba.exec(color);
    if (match) {
        return { r: match[1], g: match[2], b: match[3], a: match[4] };
    }
    match = matchers.hsl.exec(color);
    if (match) {
        return { h: match[1], s: match[2], l: match[3] };
    }
    match = matchers.hsla.exec(color);
    if (match) {
        return { h: match[1], s: match[2], l: match[3], a: match[4] };
    }
    match = matchers.hsv.exec(color);
    if (match) {
        return { h: match[1], s: match[2], v: match[3] };
    }
    match = matchers.hsva.exec(color);
    if (match) {
        return { h: match[1], s: match[2], v: match[3], a: match[4] };
    }
    match = matchers.hex8.exec(color);
    if (match) {
        return {
            r: parseIntFromHex(match[1]),
            g: parseIntFromHex(match[2]),
            b: parseIntFromHex(match[3]),
            a: convertHexToDecimal(match[4]),
            format: named ? 'name' : 'hex8',
        };
    }
    match = matchers.hex6.exec(color);
    if (match) {
        return {
            r: parseIntFromHex(match[1]),
            g: parseIntFromHex(match[2]),
            b: parseIntFromHex(match[3]),
            format: named ? 'name' : 'hex',
        };
    }
    match = matchers.hex4.exec(color);
    if (match) {
        return {
            r: parseIntFromHex(match[1] + match[1]),
            g: parseIntFromHex(match[2] + match[2]),
            b: parseIntFromHex(match[3] + match[3]),
            a: convertHexToDecimal(match[4] + match[4]),
            format: named ? 'name' : 'hex8',
        };
    }
    match = matchers.hex3.exec(color);
    if (match) {
        return {
            r: parseIntFromHex(match[1] + match[1]),
            g: parseIntFromHex(match[2] + match[2]),
            b: parseIntFromHex(match[3] + match[3]),
            format: named ? 'name' : 'hex',
        };
    }
    return false;
}
/**
 * Check to see if it looks like a CSS unit
 * (see `matchers` above for definition).
 */
function isValidCSSUnit(color) {
    return !!matchers.CSS_UNIT.exec(String(color));
}

class TinyColor {
    constructor(color = '', opts = {}) {
        // If input is already a tinycolor, return itself
        if (color instanceof TinyColor) {
            return color;
        }
        this.originalInput = color;
        const rgb = inputToRGB(color);
        this.originalInput = color;
        this.r = rgb.r;
        this.g = rgb.g;
        this.b = rgb.b;
        this.a = rgb.a;
        this.roundA = Math.round(100 * this.a) / 100;
        this.format = opts.format || rgb.format;
        this.gradientType = opts.gradientType;
        // Don't let the range of [0,255] come back in [0,1].
        // Potentially lose a little bit of precision here, but will fix issues where
        // .5 gets interpreted as half of the total, instead of half of 1
        // If it was supposed to be 128, this was already taken care of by `inputToRgb`
        if (this.r < 1) {
            this.r = Math.round(this.r);
        }
        if (this.g < 1) {
            this.g = Math.round(this.g);
        }
        if (this.b < 1) {
            this.b = Math.round(this.b);
        }
        this.isValid = rgb.ok;
    }
    isDark() {
        return this.getBrightness() < 128;
    }
    isLight() {
        return !this.isDark();
    }
    /**
     * Returns the perceived brightness of the color, from 0-255.
     */
    getBrightness() {
        // http://www.w3.org/TR/AERT#color-contrast
        const rgb = this.toRgb();
        return (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1000;
    }
    /**
     * Returns the perceived luminance of a color, from 0-1.
     */
    getLuminance() {
        // http://www.w3.org/TR/2008/REC-WCAG20-20081211/#relativeluminancedef
        const rgb = this.toRgb();
        let R;
        let G;
        let B;
        const RsRGB = rgb.r / 255;
        const GsRGB = rgb.g / 255;
        const BsRGB = rgb.b / 255;
        if (RsRGB <= 0.03928) {
            R = RsRGB / 12.92;
        }
        else {
            R = Math.pow((RsRGB + 0.055) / 1.055, 2.4);
        }
        if (GsRGB <= 0.03928) {
            G = GsRGB / 12.92;
        }
        else {
            G = Math.pow((GsRGB + 0.055) / 1.055, 2.4);
        }
        if (BsRGB <= 0.03928) {
            B = BsRGB / 12.92;
        }
        else {
            B = Math.pow((BsRGB + 0.055) / 1.055, 2.4);
        }
        return 0.2126 * R + 0.7152 * G + 0.0722 * B;
    }
    /**
     * Sets the alpha value on the current color.
     *
     * @param alpha - The new alpha value. The accepted range is 0-1.
     */
    setAlpha(alpha) {
        this.a = boundAlpha(alpha);
        this.roundA = Math.round(100 * this.a) / 100;
        return this;
    }
    /**
     * Returns the object as a HSVA object.
     */
    toHsv() {
        const hsv = rgbToHsv(this.r, this.g, this.b);
        return { h: hsv.h * 360, s: hsv.s, v: hsv.v, a: this.a };
    }
    /**
     * Returns the hsva values interpolated into a string with the following format:
     * "hsva(xxx, xxx, xxx, xx)".
     */
    toHsvString() {
        const hsv = rgbToHsv(this.r, this.g, this.b);
        const h = Math.round(hsv.h * 360);
        const s = Math.round(hsv.s * 100);
        const v = Math.round(hsv.v * 100);
        return this.a === 1 ? `hsv(${h}, ${s}%, ${v}%)` : `hsva(${h}, ${s}%, ${v}%, ${this.roundA})`;
    }
    /**
     * Returns the object as a HSLA object.
     */
    toHsl() {
        const hsl = rgbToHsl(this.r, this.g, this.b);
        return { h: hsl.h * 360, s: hsl.s, l: hsl.l, a: this.a };
    }
    /**
     * Returns the hsla values interpolated into a string with the following format:
     * "hsla(xxx, xxx, xxx, xx)".
     */
    toHslString() {
        const hsl = rgbToHsl(this.r, this.g, this.b);
        const h = Math.round(hsl.h * 360);
        const s = Math.round(hsl.s * 100);
        const l = Math.round(hsl.l * 100);
        return this.a === 1 ? `hsl(${h}, ${s}%, ${l}%)` : `hsla(${h}, ${s}%, ${l}%, ${this.roundA})`;
    }
    /**
     * Returns the hex value of the color.
     * @param allow3Char will shorten hex value to 3 char if possible
     */
    toHex(allow3Char = false) {
        return rgbToHex(this.r, this.g, this.b, allow3Char);
    }
    /**
     * Returns the hex value of the color -with a # appened.
     * @param allow3Char will shorten hex value to 3 char if possible
     */
    toHexString(allow3Char = false) {
        return '#' + this.toHex(allow3Char);
    }
    /**
     * Returns the hex 8 value of the color.
     * @param allow4Char will shorten hex value to 4 char if possible
     */
    toHex8(allow4Char = false) {
        return rgbaToHex(this.r, this.g, this.b, this.a, allow4Char);
    }
    /**
     * Returns the hex 8 value of the color -with a # appened.
     * @param allow4Char will shorten hex value to 4 char if possible
     */
    toHex8String(allow4Char = false) {
        return '#' + this.toHex8(allow4Char);
    }
    /**
     * Returns the object as a RGBA object.
     */
    toRgb() {
        return {
            r: Math.round(this.r),
            g: Math.round(this.g),
            b: Math.round(this.b),
            a: this.a,
        };
    }
    /**
     * Returns the RGBA values interpolated into a string with the following format:
     * "RGBA(xxx, xxx, xxx, xx)".
     */
    toRgbString() {
        const r = Math.round(this.r);
        const g = Math.round(this.g);
        const b = Math.round(this.b);
        return this.a === 1 ? `rgb(${r}, ${g}, ${b})` : `rgba(${r}, ${g}, ${b}, ${this.roundA})`;
    }
    /**
     * Returns the object as a RGBA object.
     */
    toPercentageRgb() {
        const fmt = (x) => Math.round(bound01(x, 255) * 100) + '%';
        return {
            r: fmt(this.r),
            g: fmt(this.g),
            b: fmt(this.b),
            a: this.a,
        };
    }
    /**
     * Returns the RGBA relative values interpolated into a string
     */
    toPercentageRgbString() {
        const rnd = (x) => Math.round(bound01(x, 255) * 100);
        return this.a === 1
            ? `rgb(${rnd(this.r)}%, ${rnd(this.g)}%, ${rnd(this.b)}%)`
            : `rgba(${rnd(this.r)}%, ${rnd(this.g)}%, ${rnd(this.b)}%, ${this.roundA})`;
    }
    /**
     * The 'real' name of the color -if there is one.
     */
    toName() {
        if (this.a === 0) {
            return 'transparent';
        }
        if (this.a < 1) {
            return false;
        }
        const hex = '#' + rgbToHex(this.r, this.g, this.b, false);
        for (const key of Object.keys(names)) {
            if (names[key] === hex) {
                return key;
            }
        }
        return false;
    }
    /**
     * String representation of the color.
     *
     * @param format - The format to be used when displaying the string representation.
     */
    toString(format) {
        const formatSet = !!format;
        format = format || this.format;
        let formattedString = false;
        const hasAlpha = this.a < 1 && this.a >= 0;
        const needsAlphaFormat = !formatSet && hasAlpha && (format.startsWith('hex') || format === 'name');
        if (needsAlphaFormat) {
            // Special case for "transparent", all other non-alpha formats
            // will return rgba when there is transparency.
            if (format === 'name' && this.a === 0) {
                return this.toName();
            }
            return this.toRgbString();
        }
        if (format === 'rgb') {
            formattedString = this.toRgbString();
        }
        if (format === 'prgb') {
            formattedString = this.toPercentageRgbString();
        }
        if (format === 'hex' || format === 'hex6') {
            formattedString = this.toHexString();
        }
        if (format === 'hex3') {
            formattedString = this.toHexString(true);
        }
        if (format === 'hex4') {
            formattedString = this.toHex8String(true);
        }
        if (format === 'hex8') {
            formattedString = this.toHex8String();
        }
        if (format === 'name') {
            formattedString = this.toName();
        }
        if (format === 'hsl') {
            formattedString = this.toHslString();
        }
        if (format === 'hsv') {
            formattedString = this.toHsvString();
        }
        return formattedString || this.toHexString();
    }
    clone() {
        return new TinyColor(this.toString());
    }
    /**
     * Lighten the color a given amount. Providing 100 will always return white.
     * @param amount - valid between 1-100
     */
    lighten(amount = 10) {
        const hsl = this.toHsl();
        hsl.l += amount / 100;
        hsl.l = clamp01(hsl.l);
        return new TinyColor(hsl);
    }
    /**
     * Brighten the color a given amount, from 0 to 100.
     * @param amount - valid between 1-100
     */
    brighten(amount = 10) {
        const rgb = this.toRgb();
        rgb.r = Math.max(0, Math.min(255, rgb.r - Math.round(255 * -(amount / 100))));
        rgb.g = Math.max(0, Math.min(255, rgb.g - Math.round(255 * -(amount / 100))));
        rgb.b = Math.max(0, Math.min(255, rgb.b - Math.round(255 * -(amount / 100))));
        return new TinyColor(rgb);
    }
    /**
     * Darken the color a given amount, from 0 to 100.
     * Providing 100 will always return black.
     * @param amount - valid between 1-100
     */
    darken(amount = 10) {
        const hsl = this.toHsl();
        hsl.l -= amount / 100;
        hsl.l = clamp01(hsl.l);
        return new TinyColor(hsl);
    }
    /**
     * Mix the color with pure white, from 0 to 100.
     * Providing 0 will do nothing, providing 100 will always return white.
     * @param amount - valid between 1-100
     */
    tint(amount = 10) {
        return this.mix('white', amount);
    }
    /**
     * Mix the color with pure black, from 0 to 100.
     * Providing 0 will do nothing, providing 100 will always return black.
     * @param amount - valid between 1-100
     */
    shade(amount = 10) {
        return this.mix('black', amount);
    }
    /**
     * Desaturate the color a given amount, from 0 to 100.
     * Providing 100 will is the same as calling greyscale
     * @param amount - valid between 1-100
     */
    desaturate(amount = 10) {
        const hsl = this.toHsl();
        hsl.s -= amount / 100;
        hsl.s = clamp01(hsl.s);
        return new TinyColor(hsl);
    }
    /**
     * Saturate the color a given amount, from 0 to 100.
     * @param amount - valid between 1-100
     */
    saturate(amount = 10) {
        const hsl = this.toHsl();
        hsl.s += amount / 100;
        hsl.s = clamp01(hsl.s);
        return new TinyColor(hsl);
    }
    /**
     * Completely desaturates a color into greyscale.
     * Same as calling `desaturate(100)`
     */
    greyscale() {
        return this.desaturate(100);
    }
    /**
     * Spin takes a positive or negative amount within [-360, 360] indicating the change of hue.
     * Values outside of this range will be wrapped into this range.
     */
    spin(amount) {
        const hsl = this.toHsl();
        const hue = (hsl.h + amount) % 360;
        hsl.h = hue < 0 ? 360 + hue : hue;
        return new TinyColor(hsl);
    }
    mix(color, amount = 50) {
        const rgb1 = this.toRgb();
        const rgb2 = new TinyColor(color).toRgb();
        const p = amount / 100;
        const rgba = {
            r: (rgb2.r - rgb1.r) * p + rgb1.r,
            g: (rgb2.g - rgb1.g) * p + rgb1.g,
            b: (rgb2.b - rgb1.b) * p + rgb1.b,
            a: (rgb2.a - rgb1.a) * p + rgb1.a,
        };
        return new TinyColor(rgba);
    }
    analogous(results = 6, slices = 30) {
        const hsl = this.toHsl();
        const part = 360 / slices;
        const ret = [this];
        for (hsl.h = (hsl.h - ((part * results) >> 1) + 720) % 360; --results;) {
            hsl.h = (hsl.h + part) % 360;
            ret.push(new TinyColor(hsl));
        }
        return ret;
    }
    /**
     * taken from https://github.com/infusion/jQuery-xcolor/blob/master/jquery.xcolor.js
     */
    complement() {
        const hsl = this.toHsl();
        hsl.h = (hsl.h + 180) % 360;
        return new TinyColor(hsl);
    }
    monochromatic(results = 6) {
        const hsv = this.toHsv();
        const h = hsv.h;
        const s = hsv.s;
        let v = hsv.v;
        const res = [];
        const modification = 1 / results;
        while (results--) {
            res.push(new TinyColor({ h, s, v }));
            v = (v + modification) % 1;
        }
        return res;
    }
    splitcomplement() {
        const hsl = this.toHsl();
        const h = hsl.h;
        return [
            this,
            new TinyColor({ h: (h + 72) % 360, s: hsl.s, l: hsl.l }),
            new TinyColor({ h: (h + 216) % 360, s: hsl.s, l: hsl.l }),
        ];
    }
    triad() {
        return this.polyad(3);
    }
    tetrad() {
        return this.polyad(4);
    }
    /**
     * Get polyad colors, like (for 1, 2, 3, 4, 5, 6, 7, 8, etc...)
     * monad, dyad, triad, tetrad, pentad, hexad, heptad, octad, etc...
     */
    polyad(n) {
        const hsl = this.toHsl();
        const h = hsl.h;
        const result = [this];
        const increment = 360 / n;
        for (let i = 1; i < n; i++) {
            result.push(new TinyColor({ h: (h + i * increment) % 360, s: hsl.s, l: hsl.l }));
        }
        return result;
    }
    /**
     * compare color vs current color
     */
    equals(color) {
        return this.toRgbString() === new TinyColor(color).toRgbString();
    }
}

// Readability Functions
// ---------------------
// <http://www.w3.org/TR/2008/REC-WCAG20-20081211/#contrast-ratiodef (WCAG Version 2)
/**
 * AKA `contrast`
 *
 * Analyze the 2 colors and returns the color contrast defined by (WCAG Version 2)
 */
function readability(color1, color2) {
    const c1 = new TinyColor(color1);
    const c2 = new TinyColor(color2);
    return ((Math.max(c1.getLuminance(), c2.getLuminance()) + 0.05) /
        (Math.min(c1.getLuminance(), c2.getLuminance()) + 0.05));
}
/**
 * Ensure that foreground and background color combinations meet WCAG2 guidelines.
 * The third argument is an object.
 *      the 'level' property states 'AA' or 'AAA' - if missing or invalid, it defaults to 'AA';
 *      the 'size' property states 'large' or 'small' - if missing or invalid, it defaults to 'small'.
 * If the entire object is absent, isReadable defaults to {level:"AA",size:"small"}.
 *
 * Example
 * ```ts
 * new TinyColor().isReadable('#000', '#111') => false
 * new TinyColor().isReadable('#000', '#111', { level: 'AA', size: 'large' }) => false
 * ```
 */
function isReadable(color1, color2, wcag2 = { level: 'AA', size: 'small' }) {
    const readabilityLevel = readability(color1, color2);
    switch ((wcag2.level || 'AA') + (wcag2.size || 'small')) {
        case 'AAsmall':
        case 'AAAlarge':
            return readabilityLevel >= 4.5;
        case 'AAlarge':
            return readabilityLevel >= 3;
        case 'AAAsmall':
            return readabilityLevel >= 7;
    }
    return false;
}

function ColorPicker(pallete, selectorEngine) {
  const foregroundPicker  = $('#foreground', pallete);
  const backgroundPicker  = $('#background', pallete);
  const borderPicker      = $('#border', pallete);
  const fgInput           = $('input', foregroundPicker[0]);
  const bgInput           = $('input', backgroundPicker[0]);
  const boInput           = $('input', borderPicker[0]);

  this.active_color       = 'background';

  // set colors
  fgInput.on('input', e =>
    $('[data-selected=true]').map(el =>
      el.style['color'] = e.target.value));

  bgInput.on('input', e =>
    $('[data-selected=true]').map(el =>
      el.style[el instanceof SVGElement
        ? 'fill'
        : 'backgroundColor'
      ] = e.target.value));

  boInput.on('input', e =>
    $('[data-selected=true]').map(el =>
      el.style[el instanceof SVGElement
        ? 'stroke'
        : 'border-color'
      ] = e.target.value));

  // read colors
  selectorEngine.onSelectedUpdate(elements => {
    if (!elements.length) return

    let isMeaningfulForeground  = false;
    let isMeaningfulBackground  = false;
    let isMeaningfulBorder      = false;
    let FG, BG, BO;

    if (elements.length == 1) {
      const el = elements[0];

      if (el instanceof SVGElement) {
        FG = new TinyColor('rgb(0, 0, 0)');
        var bo_temp = getStyle(el, 'stroke');
        BO = new TinyColor(bo_temp === 'none'
          ? 'rgb(0, 0, 0)'
          : bo_temp);
        BG = new TinyColor(getStyle(el, 'fill'));
      }
      else {
        FG = new TinyColor(getStyle(el, 'color'));
        BG = new TinyColor(getStyle(el, 'backgroundColor'));
        BO = getStyle(el, 'borderWidth') === '0px'
          ? new TinyColor('rgb(0, 0, 0)')
          : new TinyColor(getStyle(el, 'borderColor'));
      }

      let fg = FG.toHexString();
      let bg = BG.toHexString();
      let bo = BO.toHexString();

      isMeaningfulForeground = FG.originalInput !== 'rgb(0, 0, 0)' || (el.children.length === 0 && el.textContent !== '');
      isMeaningfulBackground = BG.originalInput !== 'rgba(0, 0, 0, 0)'; 
      isMeaningfulBorder     = BO.originalInput !== 'rgb(0, 0, 0)'; 

      if (isMeaningfulForeground && !isMeaningfulBackground)
        setActive('foreground');
      else if (isMeaningfulBackground && !isMeaningfulForeground)
        setActive('background');

      const new_fg = isMeaningfulForeground ? fg : '';
      const new_bg = isMeaningfulBackground ? bg : '';
      const new_bo = isMeaningfulBorder ? bo : '';

      fgInput.attr('value', new_fg);
      bgInput.attr('value', new_bg);
      boInput.attr('value', new_bo);
      
      foregroundPicker.attr('style', `
        --contextual_color: ${new_fg};
        display: ${isMeaningfulForeground ? 'inline-flex' : 'none'};
      `);

      backgroundPicker.attr('style', `
        --contextual_color: ${new_bg};
        display: ${isMeaningfulBackground ? 'inline-flex' : 'none'};
      `);

      borderPicker.attr('style', `
        --contextual_color: ${new_bo};
        display: ${isMeaningfulBorder ? 'inline-flex' : 'none'};
      `);
    }
    else {
      // show all 3 if they've selected more than 1 node
      foregroundPicker.attr('style', `
        --active_color: ${this.active_color == 'foreground' ? 'hotpink': ''};
        display: 'inline-flex'};
      `);

      backgroundPicker.attr('style', `
        --active_color: ${this.active_color == 'background' ? 'hotpink': ''};
        display: 'inline-flex'};
      `);

      borderPicker.attr('style', `
        --active_color: ${this.active_color == 'border' ? 'hotpink': ''};
        display: 'inline-flex'};
      `);
    }
  });

  const getActive = () =>
    this.active_color;

  const setActive = key => {
    removeActive();
    this.active_color = key;
    if (key === 'foreground')
      foregroundPicker[0].style.setProperty('--active_color', 'hotpink');
    if (key === 'background')
      backgroundPicker[0].style.setProperty('--active_color', 'hotpink');
    if (key === 'border')
      borderPicker[0].style.setProperty('--active_color', 'hotpink');
  };

  const removeActive = () =>
    [foregroundPicker, backgroundPicker, borderPicker].forEach(picker =>
      picker[0].style.removeProperty('--active_color'));

  return {
    getActive,
    setActive,
    foreground: { color: color => 
      foregroundPicker[0].style.setProperty('--contextual_color', color)},
    background: { color: color => 
      backgroundPicker[0].style.setProperty('--contextual_color', color)}
  }
}

const tip_map = new Map();

// todo: 
// - node recycling (for new target) no need to create/delete
// - make single function create/update
function MetaTip(selectorEngine) {
  const template = ({target: el}) => {
    const { width, height } = el.getBoundingClientRect();
    const styles = getStyles(el)
      .map(style => Object.assign(style, {
        prop: camelToDash(style.prop)
      }))
      .filter(style => 
        style.prop.includes('font-family') 
          ? el.matches('h1,h2,h3,h4,h5,h6,p,a,date,caption,button,figcaption,nav,header,footer') 
          : true
      )
      .map(style => {
        if (style.prop.includes('color') || style.prop.includes('Color') || style.prop.includes('fill') || style.prop.includes('stroke'))
          style.value = `<span color style="background-color:${style.value};"></span>${new TinyColor(style.value).toHslString()}`;

        if (style.prop.includes('font-family') && style.value.length > 25)
          style.value = style.value.slice(0,25) + '...';

        if (style.prop.includes('background-image'))
          style.value = `<a target="_blank" href="${style.value.slice(style.value.indexOf('(') + 2, style.value.length - 2)}">${style.value.slice(0,25) + '...'}</a>`;

        // check if style is inline style, show indicator
        if (el.getAttribute('style') && el.getAttribute('style').includes(style.prop))
          style.value = `<span local-change>${style.value}</span>`;
        
        return style
      });

    const localModifications = styles.filter(style =>
      el.getAttribute('style') && el.getAttribute('style').includes(style.prop)
        ? 1
        : 0);

    const notLocalModifications = styles.filter(style =>
      el.getAttribute('style') && el.getAttribute('style').includes(style.prop)
        ? 0
        : 1);
    
    let tip = document.createElement('pb-metatip');

    tip.meta = {
      el, 
      width, 
      height, 
      localModifications, 
      notLocalModifications,
    };

    return tip
  };

  const mouse_quadrant = e => ({
    north: e.clientY > window.innerHeight / 2,
    west:  e.clientX > window.innerWidth / 2
  });

  const tip_position = (node, e, north, west) => ({
    top: `${north
      ? e.pageY - node.clientHeight - 20
      : e.pageY + 25}px`,
    left: `${west
      ? e.pageX - node.clientWidth + 23
      : e.pageX - 21}px`,
  });

  const update_tip = (tip, e) => {
    const { north, west } = mouse_quadrant(e);
    const {left, top}     = tip_position(tip, e, north, west);

    tip.style.left  = left;
    tip.style.top   = top; 

    tip.style.setProperty('--arrow', north 
      ? 'var(--arrow-up)'
      : 'var(--arrow-down)');

    tip.style.setProperty('--shadow-direction', north 
      ? 'var(--shadow-up)'
      : 'var(--shadow-down)');

    tip.style.setProperty('--arrow-top', !north 
      ? '-7px'
      : 'calc(100% - 1px)');

    tip.style.setProperty('--arrow-left', west 
      ? 'calc(100% - 15px - 15px)'
      : '15px');
  };

  const mouseOut = ({target}) => {
    if (tip_map.has(target) && !target.hasAttribute('data-metatip')) {
      target.removeEventListener('mouseout', mouseOut);
      target.removeEventListener('DOMNodeRemoved', mouseOut);
      target.removeEventListener('click', togglePinned);
      tip_map.get(target).tip.remove();
      tip_map.delete(target);
    }
  };

  const togglePinned = e => {
    if (e.altKey) {
      !e.target.hasAttribute('data-metatip')
        ? e.target.setAttribute('data-metatip', true)
        : e.target.removeAttribute('data-metatip');
    }
  };

  const linkQueryClicked = ({detail}) => {
    if (!detail.text) return

    queryPage('[data-hover]', el =>
      el.setAttribute('data-hover', null));

    queryPage(detail.text + ':not([data-selected])', el =>
      detail.activator === 'mouseenter'
        ? el.setAttribute('data-hover', true)
        : selectorEngine.select(el));
  };

  const linkQueryHoverOut = e => {
    queryPage('[data-hover]', el =>
      el.setAttribute('data-hover', null));
  };

  const mouseMove = e => {
    if (isOffBounds(e.target)) return

    e.altKey
      ? e.target.setAttribute('data-pinhover', true)
      : e.target.removeAttribute('data-pinhover');

    // if node is in our hash (already created)
    if (tip_map.has(e.target)) {
      // return if it's pinned
      if (e.target.hasAttribute('data-metatip')) 
        return
      // otherwise update position
      const { tip } = tip_map.get(e.target);

      update_tip(tip, e);
    }
    // create new tip
    else {
      const tip = template(e);
      document.body.appendChild(tip);

      update_tip(tip, e);

      $(tip).on('query', linkQueryClicked);
      $(tip).on('unquery', linkQueryHoverOut);
      $(e.target).on('mouseout DOMNodeRemoved', mouseOut);
      $(e.target).on('click', togglePinned);

      tip_map.set(e.target, { tip, e });

      // tip.animate([
      //   {transform: 'translateY(-5px)', opacity: 0},
      //   {transform: 'translateY(0)', opacity: 1}
      // ], 150)
    }
  };

  $('body').on('mousemove', mouseMove);

  hotkeys('esc', _ => removeAll());

  const hideAll = () => {
    for (const {tip} of tip_map.values()) {
      tip.style.display = 'none';
      $(tip).off('mouseout DOMNodeRemoved', mouseOut);
      $(tip).off('click', togglePinned);
      $('a', tip).off('click', linkQueryClicked);
    }
  };

  const removeAll = () => {
    for (const {tip} of tip_map.values()) {
      tip.remove();
      $(tip).off('mouseout DOMNodeRemoved', mouseOut);
      $(tip).off('click', togglePinned);
      $('a', tip).off('click', linkQueryClicked);
    }
    
    $('[data-metatip]').attr('data-metatip', null);

    tip_map.clear();
  };

  for (const {tip,e} of tip_map.values()) {
    tip.style.display = 'block';
    tip.innerHTML = template(e).innerHTML;
    tip.on('mouseout', mouseOut);
    tip.on('click', togglePinned);
  }

  return () => {
    $('body').off('mousemove', mouseMove);
    hotkeys.unbind('esc');
    hideAll();
  }
}

const key_events$5 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},shift+${event}`
  , '')
  .substring(1);

const command_events$4 = `${metaKey}+up,${metaKey}+shift+up,${metaKey}+down,${metaKey}+shift+down,${metaKey}+left,${metaKey}+shift+left,${metaKey}+right,${metaKey}+shift+right`;

function BoxShadow(selector) {
  hotkeys(key_events$5, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();

    let selectedNodes = $(selector)
      , keys = handler.key.split('+');

    if (keys.includes('left') || keys.includes('right'))
      keys.includes('shift')
        ? changeBoxShadow(selectedNodes, keys, 'size')
        : changeBoxShadow(selectedNodes, keys, 'x');
    else
      keys.includes('shift')
        ? changeBoxShadow(selectedNodes, keys, 'blur')
        : changeBoxShadow(selectedNodes, keys, 'y');
  });

  hotkeys(command_events$4, (e, handler) => {
    e.preventDefault();
    let keys = handler.key.split('+');
    keys.includes('left') || keys.includes('right')
      ? changeBoxShadow($(selector), keys, 'opacity')
      : changeBoxShadow($(selector), keys, 'inset');
  });

  return () => {
    hotkeys.unbind(key_events$5);
    hotkeys.unbind(command_events$4);
    hotkeys.unbind('up,down,left,right');
  }
}

const ensureHasShadow = el => {
  if (el.style.boxShadow == '' || el.style.boxShadow == 'none')
    el.style.boxShadow = 'hsla(0,0%,0%,30%) 0 0 0 0';
  return el
};

// todo: work around this propMap with a better split
const propMap = {
  'opacity':  3,
  'x':        4,
  'y':        5,
  'blur':     6,
  'size':     7,
  'inset':    8,
};

const parseCurrentShadow = el => getStyle(el, 'boxShadow').split(' ');

function changeBoxShadow(els, direction, prop) {
  els
    .map(ensureHasShadow)
    .map(el => showHideSelected(el, 1500))
    .map(el => ({
      el,
      style:     'boxShadow',
      current:   parseCurrentShadow(el), // ["rgb(255,", "0,", "0)", "0px", "0px", "1px", "0px"]
      propIndex: parseCurrentShadow(el)[0].includes('rgba') ? propMap[prop] : propMap[prop] - 1
    }))
    .map(payload => {
      let updated = [...payload.current];
      let cur     = prop === 'opacity'
        ? payload.current[payload.propIndex]
        : parseInt(payload.current[payload.propIndex]);

      switch(prop) {
        case 'blur':
          var amount = direction.includes('shift') ? 10 : 1;
          updated[payload.propIndex] = direction.includes('down')
            ? `${cur - amount}px`
            : `${cur + amount}px`;
          break
        case 'inset':
          updated[payload.propIndex] = direction.includes('down')
            ? 'inset'
            : '';
          break
        case 'opacity':
          let cur_opacity = parseFloat(cur.slice(0, cur.indexOf(')')));
          var amount = direction.includes('shift') ? 0.10 : 0.01;
          updated[payload.propIndex] = direction.includes('left')
            ? cur_opacity - amount + ')'
            : cur_opacity + amount + ')';
          break
        default:
          updated[payload.propIndex] = direction.includes('left') || direction.includes('up')
            ? `${cur - 1}px`
            : `${cur + 1}px`;
          break
      }

      payload.value = updated;
      return payload
    })
    .forEach(({el, style, value}) =>
      el.style[style] = value.join(' '));
}

const key_events$6 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},shift+${event}`
  , '')
  .substring(1);

const command_events$5 = `${metaKey}+up,${metaKey}+shift+up,${metaKey}+down,${metaKey}+shift+down,${metaKey}+left,${metaKey}+shift+left,${metaKey}+right,${metaKey}+shift+right`;

function HueShift(Color) {
  this.active_color = Color.getActive();

  hotkeys(key_events$6, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();

    let selectedNodes = $('[data-selected=true]')
      , keys = handler.key.split('+');

    keys.includes('left') || keys.includes('right')
      ? changeHue(selectedNodes, keys, 's', Color)
      : changeHue(selectedNodes, keys, 'l', Color);
  });

  hotkeys(command_events$5, (e, handler) => {
    e.preventDefault();
    let keys = handler.key.split('+');
    keys.includes('left') || keys.includes('right')
      ? changeHue($('[data-selected=true]'), keys, 'a', Color)
      : changeHue($('[data-selected=true]'), keys, 'h', Color);
  });

  hotkeys('[,]', (e, handler) => {
    e.preventDefault();

    if (this.active_color == 'background')
      this.active_color = 'foreground';
    else if (this.active_color == 'foreground')
      this.active_color = 'background';

    Color.setActive(this.active_color);
  });

  const onNodesSelected = els =>
    Color.setActive(this.active_color);

  const disconnect = () => {
    hotkeys.unbind(key_events$6);
    hotkeys.unbind(command_events$5);
    hotkeys.unbind('up,down,left,right');
  };

  return {
    onNodesSelected,
    disconnect,
  }
}

function changeHue(els, direction, prop, Color) {
  els
    .map(el => showHideSelected(el))
    .map(el => {
      const { foreground, background } = extractPalleteColors(el);

      // todo: teach hueshift to do handle color
      switch(Color.getActive()) {
        case 'background':
          return { el, current: background.color.toHsl(), style: background.style }
        case 'foreground':
          return { el, current: foreground.color.toHsl(), style: foreground.style }
      }
    })
    .map(payload =>
      Object.assign(payload, {
        amount:   direction.includes('shift') ? 10 : 1,
        negative: direction.includes('down') || direction.includes('left'),
      }))
    .map(payload => {
      if (prop === 's' || prop === 'l' || prop === 'a')
        payload.amount = payload.amount * 0.01;

      payload.current[prop] = payload.negative
        ? payload.current[prop] - payload.amount
        : payload.current[prop] + payload.amount;

      if (prop === 's' || prop === 'l' || prop === 'a') {
        if (payload.current[prop] > 1) payload.current[prop] = 1;
        if (payload.current[prop] < 0) payload.current[prop] = 0;
      }

      return payload
    })
    .forEach(({el, style, current}) => {
      let color = new TinyColor(current).setAlpha(current.a);
      el.style[style] = color.toHslString();

      if (style == 'color') Color.foreground.color(color.toHexString());
      if (style == 'backgroundColor') Color.background.color(color.toHexString());
    });
}

function extractPalleteColors(el) {
  if (el instanceof SVGElement) {
    const  fg_temp = getStyle(el, 'stroke');

    return {
      foreground: {
        style: 'stroke',
        color: new TinyColor(fg_temp === 'none'
          ? 'rgb(0, 0, 0)'
          : fg_temp),
      },
      background: {
        style: 'fill',
        color: new TinyColor(getStyle(el, 'fill')),
      }
    }
  }
  else
    return {
      foreground: {
        style: 'color',
        color: new TinyColor(getStyle(el, 'color')),
      },
      background: {
        style: 'backgroundColor',
        color: new TinyColor(getStyle(el, 'backgroundColor')),
      }
    }
}

let gridlines;

function Guides() {
  $('body').on('mouseover', on_hover);
  $('body').on('mouseout', on_hoverout);
  window.addEventListener('scroll', hideGridlines);

  return () => {
    $('body').off('mouseover', on_hover);
    $('body').off('mouseout', on_hoverout);
    window.removeEventListener('scroll', hideGridlines);
    hideGridlines();
  }
}

const on_hover = ({target}) => {
  if (isOffBounds(target)) return
  showGridlines(target);
};

// export function Guides() {
//   let v = createGuide()
//     , h = createGuide(false)

//   document.body.appendChild(v)
//   document.body.appendChild(h)
//   document.body.style.cursor = 'crosshair'

//   const mouseMove = e => {
//     v.style.left  = e.clientX + 'px'
//     h.style.top   = e.clientY + 'px'
//   }

//   $('body').on('mousemove', mouseMove)

//   return () => {
//     $('body').off('mousemove', mouseMove)
//     document.body.removeChild(v)
//     document.body.removeChild(h)
//     document.body.style.cursor = null
//   }
// }

const on_hoverout = ({target}) =>
  hideGridlines();

const showGridlines = node => {
  if (gridlines) {
    gridlines.style.display = null;
    gridlines.update = node.getBoundingClientRect();
  }
  else {
    gridlines = document.createElement('pb-gridlines');
    gridlines.position = node.getBoundingClientRect();

    document.body.appendChild(gridlines);
  }
};

const hideGridlines = node => {
  if (!gridlines) return
  gridlines.style.display = 'none';
};

function Screenshot(node, page) {
  alert('Coming Soon!');

  return () => {}
}

const key_events$7 = 'up,down,left,right'
  .split(',')
  .reduce((events, event) =>
    `${events},${event},alt+${event},shift+${event},shift+alt+${event}`
  , '')
  .substring(1);

function Position() {
  this._els = [];

  hotkeys(key_events$7, (e, handler) => {
    if (e.cancelBubble) return

    e.preventDefault();
    positionElement($('[data-selected=true]'), handler.key);
  });

  const onNodesSelected = els => {
    this._els.forEach(el =>
      el.teardown());

    this._els = els.map(el =>
      draggable(el));
  };

  const disconnect = () => {
    this._els.forEach(el => el.teardown());
    hotkeys.unbind(key_events$7);
    hotkeys.unbind('up,down,left,right');
  };

  return {
    onNodesSelected,
    disconnect,
  }
}

function draggable(el) {
  this.state = {
    mouse: {
      down: false,
      x: 0,
      y: 0,
    },
    element: {
      x: 0,
      y: 0,
    }
  };

  const setup = () => {
    el.style.transition   = 'none';
    el.style.cursor       = 'move';

    el.addEventListener('mousedown', onMouseDown, true);
    el.addEventListener('mouseup', onMouseUp, true);
    document.addEventListener('mousemove', onMouseMove, true);
  };

  const teardown = () => {
    el.style.transition   = null;
    el.style.cursor       = null;

    el.removeEventListener('mousedown', onMouseDown, true);
    el.removeEventListener('mouseup', onMouseUp, true);
    document.removeEventListener('mousemove', onMouseMove, true);
  };

  const onMouseDown = e => {
    e.preventDefault();

    const el = e.target;

    el.style.position = 'relative';
    el.style.willChange = 'top,left';

    if (el instanceof SVGElement) {
      const translate = el.getAttribute('transform');

      const [ x, y ] = translate
        ? extractSVGTranslate(translate)
        : [0,0];

      this.state.element.x  = x;
      this.state.element.y  = y;
    }
    else {
      this.state.element.x  = parseInt(getStyle(el, 'left'));
      this.state.element.y  = parseInt(getStyle(el, 'top'));
    }

    this.state.mouse.x      = e.clientX;
    this.state.mouse.y      = e.clientY;
    this.state.mouse.down   = true;
  };

  const onMouseUp = e => {
    e.preventDefault();

    this.state.mouse.down = false;
    el.style.willChange = null;

    if (el instanceof SVGElement) {
      const translate = el.getAttribute('transform');

      const [ x, y ] = translate
        ? extractSVGTranslate(translate)
        : [0,0];

      this.state.element.x    = x;
      this.state.element.y    = y;
    }
    else {
      this.state.element.x    = parseInt(el.style.left) || 0;
      this.state.element.y    = parseInt(el.style.top) || 0;
    }
  };

  const onMouseMove = e => {
    e.preventDefault();
    e.stopPropagation();

    if (!this.state.mouse.down) return

    if (el instanceof SVGElement) {
      el.setAttribute('transform', `translate(
        ${this.state.element.x + e.clientX - this.state.mouse.x},
        ${this.state.element.y + e.clientY - this.state.mouse.y}
      )`);
    }
    else {
      el.style.left = this.state.element.x + e.clientX - this.state.mouse.x + 'px';
      el.style.top  = this.state.element.y + e.clientY - this.state.mouse.y + 'px';
    }
  };

  setup();

  return {
    teardown
  }
}

function positionElement(els, direction) {
  els
    .map(el => ensurePositionable(el))
    .map(el => showHideSelected(el))
    .map(el => ({
        el,
        ...extractCurrentValueAndSide(el, direction),
        amount:   direction.split('+').includes('shift') ? 10 : 1,
        negative: determineNegativity(el, direction),
    }))
    .map(payload =>
      Object.assign(payload, {
        position: payload.negative
          ? payload.current + payload.amount
          : payload.current - payload.amount
      }))
    .forEach(({el, style, position}) =>
      el instanceof SVGElement
        ? setTranslateOnSVG(el, direction, position)
        : el.style[style] = position + 'px');
}

const extractCurrentValueAndSide = (el, direction) => {
  let style, current;

  if (el instanceof SVGElement) {
    const translate = el.attr('transform');

    const [ x, y ] = translate
      ? extractSVGTranslate(translate)
      : [0,0];

    style   = 'transform';
    current = direction.includes('down') || direction.includes('up')
      ? y
      : x;
  }
  else {
    style   = getSide(direction).toLowerCase();
    current = getStyle(el, style);

    current === 'auto'
      ? current = 0
      : current = parseInt(current, 10);
  }

  return { style, current }
};

const extractSVGTranslate = translate =>
  translate.substring(
    translate.indexOf('(') + 1,
    translate.indexOf(')')
  ).split(',')
  .map(val => parseFloat(val));

const setTranslateOnSVG = (el, direction, position) => {
  const transform = el.attr('transform');
  const [ x, y ] = transform
    ? extractSVGTranslate(transform)
    : [0,0];

  const pos = direction.includes('down') || direction.includes('up')
    ? `${x},${position}`
    : `${position},${y}`;

  el.attr('transform', `translate(${pos})`);
};

const determineNegativity = (el, direction) =>
  el instanceof SVGElement
    ? direction.includes('right') || direction.includes('down')
    : direction.split('+').includes('alt');

const ensurePositionable = el => {
  if (el instanceof HTMLElement)
    el.style.position = 'relative';
  return el
};

const tip_map$1 = new Map();

function Accessibility() {
  const template = ({target: el}) => {
    let tip = document.createElement('pb-ally');

    const contrast_results = determineColorContrast(el);
    const ally_attributes = getA11ys(el);

    ally_attributes.map(ally =>
      ally.prop.includes('alt')
        ? ally.value = `<span text>${ally.value}</span>`
        : ally);

    tip.meta = {
      el, 
      ally_attributes,
      contrast_results,
    };

    return tip
  };

  const determineColorContrast = el => {
    // question: how to know if the current node is actually a black background?
    // question: is there an api for composited values?
    const text      = getStyle(el, 'color');
    const textSize  = getWCAG2TextSize(el);

    let background  = getComputedBackgroundColor(el);

    const [ aa_contrast, aaa_contrast ] = [
      isReadable(background, text, { level: "AA", size: textSize.toLowerCase() }),
      isReadable(background, text, { level: "AAA", size: textSize.toLowerCase() })
    ];

    return `
      <span prop>Color contrast</span>
      <span value contrast>
        <span style="
          background-color:${background};
          color:${text};
        ">${Math.floor(readability(background, text)  * 100) / 100}</span>
      </span>
      <span prop>› AA ${textSize}</span>
      <span value style="${aa_contrast ? 'color:green;' : 'color:red'}">${aa_contrast ? '✓' : '×'}</span>
      <span prop>› AAA ${textSize}</span>
      <span value style="${aaa_contrast ? 'color:green;' : 'color:red'}">${aaa_contrast ? '✓' : '×'}</span>
    `
  };

  const mouse_quadrant = e => ({
    north: e.clientY > window.innerHeight / 2,
    west:  e.clientX > window.innerWidth / 2
  });

  const tip_position = (node, e, north, west) => ({
    top: `${north
      ? e.pageY - node.clientHeight - 20
      : e.pageY + 25}px`,
    left: `${west
      ? e.pageX - node.clientWidth + 23
      : e.pageX - 21}px`,
  });

  const update_tip = (tip, e) => {
    const { north, west } = mouse_quadrant(e);
    const {left, top}     = tip_position(tip, e, north, west);

    tip.style.left  = left;
    tip.style.top   = top; 

    tip.style.setProperty('--arrow', north 
      ? 'var(--arrow-up)'
      : 'var(--arrow-down)');

    tip.style.setProperty('--shadow-direction', north 
      ? 'var(--shadow-up)'
      : 'var(--shadow-down)');

    tip.style.setProperty('--arrow-top', !north 
      ? '-8px'
      : '100%');

    tip.style.setProperty('--arrow-left', west 
      ? 'calc(100% - 15px - 15px)'
      : '15px');
  };

  const mouseOut = ({target}) => {
    if (tip_map$1.has(target) && !target.hasAttribute('data-metatip')) {
      target.removeEventListener('mouseout', mouseOut);
      target.removeEventListener('DOMNodeRemoved', mouseOut);
      target.removeEventListener('click', togglePinned);
      tip_map$1.get(target).tip.remove();
      tip_map$1.delete(target);
    }
  };

  const togglePinned = e => {
    if (e.altKey) {
      !e.target.hasAttribute('data-metatip')
        ? e.target.setAttribute('data-metatip', true)
        : e.target.removeAttribute('data-metatip');
    }
  };

  const mouseMove = e => {
    if (isOffBounds(e.target)) return

    e.altKey
      ? e.target.setAttribute('data-pinhover', true)
      : e.target.removeAttribute('data-pinhover');

    // if node is in our hash (already created)
    if (tip_map$1.has(e.target)) {
      // return if it's pinned
      if (e.target.hasAttribute('data-metatip')) 
        return
      // otherwise update position
      const { tip } = tip_map$1.get(e.target);
      update_tip(tip, e);
    }
    // create new tip
    else {
      const tip = template(e);
      document.body.appendChild(tip);

      update_tip(tip, e);

      $(e.target).on('mouseout DOMNodeRemoved', mouseOut);
      $(e.target).on('click', togglePinned);

      tip_map$1.set(e.target, { tip, e });

      // tip.animate([
      //   {transform: 'translateY(-5px)', opacity: 0},
      //   {transform: 'translateY(0)', opacity: 1}
      // ], 150)
    }
  };

  $('body').on('mousemove', mouseMove);

  hotkeys('esc', _ => removeAll());

  const hideAll = () => {
    for (const {tip} of tip_map$1.values()) {
      tip.style.display = 'none';
      $(tip).off('mouseout DOMNodeRemoved', mouseOut);
      $(tip).off('click', togglePinned);
    }
  };

  const removeAll = () => {
    for (const {tip} of tip_map$1.values()) {
      tip.remove();
      $(tip).off('mouseout DOMNodeRemoved', mouseOut);
      $(tip).off('click', togglePinned);
    }
    
    $('[data-metatip]').attr('data-metatip', null);

    tip_map$1.clear();
  };

  for (const {tip,e} of tip_map$1.values()) {
    tip.style.display = 'block';
    tip.innerHTML = template(e).innerHTML;
    tip.on('mouseout', mouseOut);
    tip.on('click', togglePinned);
  }

  return () => {
    $('body').off('mousemove', mouseMove);
    hotkeys.unbind('esc');
    hideAll();
  }
}

const ToolModel = {
  g: {
    tool:        'guides',
    icon:        guides,
    label:       'Guides',
    description: 'Verify alignment & check your grid',
    instruction: '',
  },
  i: {
    tool:        'inspector',
    icon:        inspector,
    label:       'Inspect',
    description: 'Peek into common & current styles of an element',
    instruction: `<div table>
                    <div>
                      <b>Pin it:</b>
                      <span>${altKey} + click</span>
                    </div>
                  </div>`,
  },
  x: {
    tool:        'accessibility',
    icon:        accessibility,
    label:       'Accessibility',
    description: 'Peek into A11y attributes & compliance status',
    instruction: `<div table>
                    <div>
                      <b>Pin it:</b>
                      <span>${altKey} + click</span>
                    </div>
                  </div>`,
  },
  v: {
    tool:        'move',
    icon:        move,
    label:       'Move',
    description: 'Push elements in & out of their container, or shuffle them within it',
    instruction: `<div table>
                    <div>
                      <b>Lateral:</b>
                      <span>◀ ▶</span>
                    </div>
                    <div>
                      <b>Out and above:</b>
                      <span>▲</span>
                    </div>
                    <div>
                      <b>Down and in:</b>
                      <span>▼</span>
                    </div>
                  </div>`,
  },
  // r: {
  //   tool:        'resize',
  //   icon:        Icons.resize,
  //   label:       'Resize',
  //   description: ''
  // },
  m: {
    tool:        'margin',
    icon:        margin,
    label:       'Margin',
    description: 'Add or subtract outer space from any or all sides of the selected element(s)',
    instruction: `<div table>
                    <div>
                      <b>+ Margin:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>- Margin:</b>
                      <span>${altKey} + ◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>All Sides:</b>
                      <span>${metaKey} +  ▲ ▼</span>
                    </div>
                  </div>`,
  },
  p: {
    tool:        'padding',
    icon:        padding,
    label:       'Padding',
    description: `Add or subtract inner space from any or all sides of the selected element(s)`,
    instruction: `<div table>
                    <div>
                      <b>+ Padding:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>- Padding:</b>
                      <span>${altKey} + ◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>All Sides:</b>
                      <span>${metaKey} +  ▲ ▼</span>
                    </div>
                  </div>`
  },
  // b: {
  //   tool:        'border',
  //   icon:        Icons.border,
  //   label:       'Border',
  //   description: ''
  // },
  a: {
    tool:        'align',
    icon:        align,
    label:       'Flexbox Align',
    description: `Create or modify flexbox direction, distribution & alignment`,
    instruction: `<div table>
                    <div>
                      <b>Alignment:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>Distribution:</b>
                      <span>Shift + ◀ ▶</span>
                    </div>
                    <div>
                      <b>Direction:</b>
                      <span>${metaKey} +  ◀ ▼</span>
                    </div>
                  </div>`,
  },
  h: {
    tool:        'hueshift',
    icon:        hueshift,
    label:       'Hue Shift',
    description: `Change foreground/background hue, brightness, saturation & opacity`,
    instruction: `<div table>
                    <div>
                      <b>Saturation:</b>
                      <span>◀ ▶</span>
                    </div>
                    <div>
                      <b>Brightness:</b>
                      <span>▲ ▼</span>
                    </div>
                    <div>
                      <b>Hue:</b>
                      <span>${metaKey} +  ▲ ▼</span>
                    </div>
                    <div>
                      <b>Opacity:</b>
                      <span>${metaKey} +  ◀ ▶</span>
                    </div>
                  </div>`,
  },
  d: {
    tool:        'boxshadow',
    icon:        boxshadow,
    label:       'Shadow',
    description: `Create & adjust position, blur & opacity of a box shadow`,
    instruction: `<div table>
                    <div>
                      <b>X/Y Position:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>Blur:</b>
                      <span>Shift + ▲ ▼</span>
                    </div>
                    <div>
                      <b>Spread:</b>
                      <span>Shift + ◀ ▶</span>
                    </div>
                    <div>
                      <b>Opacity:</b>
                      <span>${metaKey} + ◀ ▶</span>
                    </div>
                  </div>`,
  },
  // t: {
  //   tool:        'transform',
  //   icon:        Icons.transform,
  //   label:       '3D Transform',
  //   description: ''
  // },
  l: {
    tool:        'position',
    icon:        position,
    label:       'Position',
    description: 'Move svg (x,y) and elements (top,left,bottom,right)',
    instruction: `<div table>
                    <div>
                      <b>Nudge:</b>
                      <span>◀ ▶ ▲ ▼</span>
                    </div>
                    <div>
                      <b>Move:</b>
                      <span>Click & drag</span>
                    </div>
                  </div>`,
  },
  f: {
    tool:        'font',
    icon:        font,
    label:       'Font Styles',
    description: 'Change size, alignment, leading, letter-spacing, & weight',
    instruction: `<div table>
                    <div>
                      <b>Size:</b>
                      <span>▲ ▼</span>
                    </div>
                    <div>
                      <b>Alignment:</b>
                      <span>◀ ▶</span>
                    </div>
                    <div>
                      <b>Leading:</b>
                      <span>Shift + ▲ ▼</span>
                    </div>
                    <div>
                      <b>Letter-spacing:</b>
                      <span>Shift + ◀ ▶</span>
                    </div>
                    <div>
                      <b>Weight:</b>
                      <span>${metaKey} + ▲ ▼</span>
                    </div>
                  </div>`,
  },
  e: {
    tool:        'text',
    icon:        text,
    label:       'Edit Text',
    description: 'Change any text on the page with a <b>double click</b>',
    instruction: '',
  },
  // c: {
  //   tool:        'screenshot',
  //   icon:        Icons.camera,
  //   label:       'Screenshot',
  //   description: 'Screenshot selected elements or the entire page'
  // },
  s: {
    tool:        'search',
    icon:        search,
    label:       'Search',
    description: 'Select elements by searching for them',
    instruction: '',
  },
};

class ToolPallete extends HTMLElement {
  constructor() {
    super();

    this.toolbar_model  = ToolModel;
    this._tutsBaseURL   = 'tuts'; // can be set by content script
    this.$shadow        = this.attachShadow({mode: 'open'});
  }

  connectedCallback() {
    if (!this.$shadow.innerHTML)
      this.setup();

    this.selectorEngine = Selectable();
    this.colorPicker    = ColorPicker(this.$shadow, this.selectorEngine);
    provideSelectorEngine(this.selectorEngine);
  }

  disconnectedCallback() {
    this.deactivate_feature();
    this.selectorEngine.disconnect();
    hotkeys.unbind(
      Object.keys(this.toolbar_model).reduce((events, key) =>
        events += ',' + key, ''));
    hotkeys.unbind(`${metaKey}+/`);
  }

  setup() {
    this.$shadow.innerHTML = this.render();

    $('li[data-tool]', this.$shadow).on('click', e =>
      this.toolSelected(e.currentTarget) && e.stopPropagation());

    Object.entries(this.toolbar_model).forEach(([key, value]) =>
      hotkeys(key, e => {
        e.preventDefault();
        this.toolSelected(
          $(`[data-tool="${value.tool}"]`, this.$shadow)[0]
        );
      })
    );

    hotkeys(`${metaKey}+/,${metaKey}+.`, e =>
      this.$shadow.host.style.display =
        this.$shadow.host.style.display === 'none'
          ? 'block'
          : 'none');

    this.toolSelected($('[data-tool="guides"]', this.$shadow)[0]);
  }

  toolSelected(el) {
    if (typeof el === 'string')
      el = $(`[data-tool="${el}"]`, this.$shadow)[0];

    if (this.active_tool && this.active_tool.dataset.tool === el.dataset.tool) return

    if (this.active_tool) {
      this.active_tool.attr('data-active', null);
      this.deactivate_feature();
    }

    el.attr('data-active', true);
    this.active_tool = el;
    this[el.dataset.tool]();
  }

  render() {
    return `
      ${this.styles()}
      <pb-hotkeys></pb-hotkeys>
      <ol>
        ${Object.entries(this.toolbar_model).reduce((list, [key, tool]) => `
          ${list}
          <li aria-label="${tool.label} Tool" aria-description="${tool.description}" aria-hotkey="${key}" data-tool="${tool.tool}" data-active="${key == 'g'}">
            ${tool.icon}
            ${this.demoTip({key, ...tool})}
          </li>
        `,'')}
      </ol>
      <ol colors>
        <li style="display: none;" class="color" id="foreground" aria-label="Text" aria-description="Change the text color">
          <input type="color" value="">
          ${color_text}
        </li>
        <li style="display: none;" class="color" id="background" aria-label="Background or Fill" aria-description="Change the background color or fill of svg">
          <input type="color" value="">
          ${color_background}
        </li>
        <li style="display: none;" class="color" id="border" aria-label="Border or Stroke" aria-description="Change the border color or stroke of svg">
          <input type="color" value="">
          ${color_border}
        </li>
      </ol>
    `
  }

  styles() {
    return `
      <style>
        ${css}
      </style>
    `
  }

  demoTip({key, tool, label, description, instruction}) {
    return `
      <aside ${tool}>
        <figure>
          <img src="${this._tutsBaseURL}/${tool}.gif" alt="${description}" />
          <figcaption>
            <h2>
              ${label}
              <span hotkey>${key}</span>
            </h2>
            <p>${description}</p>
            ${instruction}
          </figcaption>
        </figure>
      </aside>
    `
  }

  move() {
    this.deactivate_feature = Moveable('[data-selected=true]');
  }

  margin() {
    this.deactivate_feature = Margin('[data-selected=true]');
  }

  padding() {
    this.deactivate_feature = Padding('[data-selected=true]');
  }

  font() {
    this.deactivate_feature = Font('[data-selected=true]');
  }

  text() {
    this.selectorEngine.onSelectedUpdate(EditText);
    this.deactivate_feature = () =>
      this.selectorEngine.removeSelectedCallback(EditText);
  }

  align() {
    this.deactivate_feature = Flex('[data-selected=true]');
  }

  search() {
    this.deactivate_feature = Search($('[data-tool="search"]', this.$shadow));
  }

  boxshadow() {
    this.deactivate_feature = BoxShadow('[data-selected=true]');
  }

  hueshift() {
    let feature = HueShift(this.colorPicker);
    this.selectorEngine.onSelectedUpdate(feature.onNodesSelected);
    this.deactivate_feature = () => {
      this.selectorEngine.removeSelectedCallback(feature.onNodesSelected);
      feature.disconnect();
    };
  }

  inspector() {
    this.deactivate_feature = MetaTip(this.selectorEngine);
  }

  accessibility() {
    this.deactivate_feature = Accessibility();
  }

  guides() {
    this.deactivate_feature = Guides();
  }

  screenshot() {
    this.deactivate_feature = Screenshot();
  }

  position() {
    let feature = Position();
    this.selectorEngine.onSelectedUpdate(feature.onNodesSelected);
    this.deactivate_feature = () => {
      this.selectorEngine.removeSelectedCallback(feature.onNodesSelected);
      feature.disconnect();
    };
  }

  get activeTool() {
    return this.active_tool.dataset.tool
  }

  set tutsBaseURL(url) {
    this._tutsBaseURL = url;
    this.setup();
  }
}

customElements.define('tool-pallete', ToolPallete);

if ('ontouchstart' in document.documentElement)
  document.getElementById('mobile-info').style.display = '';

if (metaKey === 'ctrl')
  [...document.querySelectorAll('kbd')]
    .forEach(node => {
      node.textContent = node.textContent.replace('cmd','ctrl');
      node.textContent = node.textContent.replace('opt','alt');
    });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVuZGxlLmpzIiwic291cmNlcyI6WyIuLi9ub2RlX21vZHVsZXMvYmxpbmdibGluZ2pzL3NyYy9pbmRleC5qcyIsIi4uL25vZGVfbW9kdWxlcy9ob3RrZXlzLWpzL2Rpc3QvaG90a2V5cy5lc20uanMiLCJjb21wb25lbnRzL3NlbGVjdGlvbi9oYW5kbGVzLmVsZW1lbnQuanMiLCJjb21wb25lbnRzL3NlbGVjdGlvbi9sYWJlbC5lbGVtZW50LmpzIiwidXRpbGl0aWVzL2Rlc2lnbi1wcm9wZXJ0aWVzLmpzIiwidXRpbGl0aWVzL3N0eWxlcy5qcyIsInV0aWxpdGllcy9hY2Nlc3NpYmlsaXR5LmpzIiwidXRpbGl0aWVzL3N0cmluZ3MuanMiLCJ1dGlsaXRpZXMvY29tbW9uLmpzIiwidXRpbGl0aWVzL3dpbmRvdy5qcyIsImNvbXBvbmVudHMvc2VsZWN0aW9uL2dyaWRsaW5lcy5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9zZWxlY3Rpb24vb3ZlcmxheS5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9tZXRhdGlwL21ldGF0aXAuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvbWV0YXRpcC9hbGx5LmVsZW1lbnQuanMiLCJjb21wb25lbnRzL3Rvb2wtcGFsbGV0ZS90b29scGFsbGV0ZS5pY29ucy5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9iYXNlLmVsZW1lbnQuanMiLCJjb21wb25lbnRzL2hvdGtleS1tYXAvZ3VpZGVzLmVsZW1lbnQuanMiLCJjb21wb25lbnRzL2hvdGtleS1tYXAvaW5zcGVjdG9yLmVsZW1lbnQuanMiLCJjb21wb25lbnRzL2hvdGtleS1tYXAvYWNjZXNzaWJpbGl0eS5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL21vdmUuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9tYXJnaW4uZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9wYWRkaW5nLmVsZW1lbnQuanMiLCJjb21wb25lbnRzL2hvdGtleS1tYXAvYWxpZ24uZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9odWVzaGlmdC5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL2JveHNoYWRvdy5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL3Bvc2l0aW9uLmVsZW1lbnQuanMiLCJjb21wb25lbnRzL2hvdGtleS1tYXAvZm9udC5lbGVtZW50LmpzIiwiY29tcG9uZW50cy9ob3RrZXktbWFwL3RleHQuZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9zZWFyY2guZWxlbWVudC5qcyIsImNvbXBvbmVudHMvaG90a2V5LW1hcC9ob3RrZXlzLmVsZW1lbnQuanMiLCJmZWF0dXJlcy9tYXJnaW4uanMiLCJmZWF0dXJlcy9tb3ZlLmpzIiwiZmVhdHVyZXMvaW1hZ2Vzd2FwLmpzIiwiZmVhdHVyZXMvc2VhcmNoLmpzIiwiZmVhdHVyZXMvc2VsZWN0YWJsZS5qcyIsImZlYXR1cmVzL3BhZGRpbmcuanMiLCJmZWF0dXJlcy90ZXh0LmpzIiwiZmVhdHVyZXMvZm9udC5qcyIsImZlYXR1cmVzL2ZsZXguanMiLCIuLi9ub2RlX21vZHVsZXMvQGN0cmwvdGlueWNvbG9yL2J1bmRsZXMvdGlueWNvbG9yLmVzMjAxNS5qcyIsImZlYXR1cmVzL2NvbG9yLmpzIiwiZmVhdHVyZXMvbWV0YXRpcC5qcyIsImZlYXR1cmVzL2JveHNoYWRvdy5qcyIsImZlYXR1cmVzL2h1ZXNoaWZ0LmpzIiwiZmVhdHVyZXMvZ3VpZGVzLmpzIiwiZmVhdHVyZXMvc2NyZWVuc2hvdC5qcyIsImZlYXR1cmVzL3Bvc2l0aW9uLmpzIiwiZmVhdHVyZXMvYWNjZXNzaWJpbGl0eS5qcyIsImNvbXBvbmVudHMvdG9vbC1wYWxsZXRlL21vZGVsLmpzIiwiY29tcG9uZW50cy90b29sLXBhbGxldGUvdG9vbHBhbGxldGUuZWxlbWVudC5qcyIsImluZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHN1Z2FyID0ge1xuICBvbjogZnVuY3Rpb24obmFtZXMsIGZuKSB7XG4gICAgbmFtZXNcbiAgICAgIC5zcGxpdCgnICcpXG4gICAgICAuZm9yRWFjaChuYW1lID0+XG4gICAgICAgIHRoaXMuYWRkRXZlbnRMaXN0ZW5lcihuYW1lLCBmbikpXG4gICAgcmV0dXJuIHRoaXNcbiAgfSxcbiAgb2ZmOiBmdW5jdGlvbihuYW1lcywgZm4pIHtcbiAgICBuYW1lc1xuICAgICAgLnNwbGl0KCcgJylcbiAgICAgIC5mb3JFYWNoKG5hbWUgPT5cbiAgICAgICAgdGhpcy5yZW1vdmVFdmVudExpc3RlbmVyKG5hbWUsIGZuKSlcbiAgICByZXR1cm4gdGhpc1xuICB9LFxuICBhdHRyOiBmdW5jdGlvbihhdHRyLCB2YWwpIHtcbiAgICBpZiAodmFsID09PSB1bmRlZmluZWQpIHJldHVybiB0aGlzLmdldEF0dHJpYnV0ZShhdHRyKVxuXG4gICAgdmFsID09IG51bGxcbiAgICAgID8gdGhpcy5yZW1vdmVBdHRyaWJ1dGUoYXR0cilcbiAgICAgIDogdGhpcy5zZXRBdHRyaWJ1dGUoYXR0ciwgdmFsIHx8ICcnKVxuICAgICAgXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAkKHF1ZXJ5LCAkY29udGV4dCA9IGRvY3VtZW50KSB7XG4gIGxldCAkbm9kZXMgPSBxdWVyeSBpbnN0YW5jZW9mIE5vZGVMaXN0IHx8IEFycmF5LmlzQXJyYXkocXVlcnkpXG4gICAgPyBxdWVyeVxuICAgIDogcXVlcnkgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCB8fCBxdWVyeSBpbnN0YW5jZW9mIFNWR0VsZW1lbnRcbiAgICAgID8gW3F1ZXJ5XVxuICAgICAgOiAkY29udGV4dC5xdWVyeVNlbGVjdG9yQWxsKHF1ZXJ5KVxuXG4gIGlmICghJG5vZGVzLmxlbmd0aCkgJG5vZGVzID0gW11cblxuICByZXR1cm4gT2JqZWN0LmFzc2lnbihcbiAgICBbLi4uJG5vZGVzXS5tYXAoJGVsID0+IE9iamVjdC5hc3NpZ24oJGVsLCBzdWdhcikpLCBcbiAgICB7XG4gICAgICBvbjogZnVuY3Rpb24obmFtZXMsIGZuKSB7XG4gICAgICAgIHRoaXMuZm9yRWFjaCgkZWwgPT4gJGVsLm9uKG5hbWVzLCBmbikpXG4gICAgICAgIHJldHVybiB0aGlzXG4gICAgICB9LFxuICAgICAgb2ZmOiBmdW5jdGlvbihuYW1lcywgZm4pIHtcbiAgICAgICAgdGhpcy5mb3JFYWNoKCRlbCA9PiAkZWwub2ZmKG5hbWVzLCBmbikpXG4gICAgICAgIHJldHVybiB0aGlzXG4gICAgICB9LFxuICAgICAgYXR0cjogZnVuY3Rpb24oYXR0cnMsIHZhbCkge1xuICAgICAgICBpZiAodHlwZW9mIGF0dHJzID09PSAnc3RyaW5nJyAmJiB2YWwgPT09IHVuZGVmaW5lZClcbiAgICAgICAgICByZXR1cm4gdGhpc1swXS5hdHRyKGF0dHJzKVxuXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiBhdHRycyA9PT0gJ29iamVjdCcpIFxuICAgICAgICAgIHRoaXMuZm9yRWFjaCgkZWwgPT5cbiAgICAgICAgICAgIE9iamVjdC5lbnRyaWVzKGF0dHJzKVxuICAgICAgICAgICAgICAuZm9yRWFjaCgoW2tleSwgdmFsXSkgPT5cbiAgICAgICAgICAgICAgICAkZWwuYXR0cihrZXksIHZhbCkpKVxuXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiBhdHRycyA9PSAnc3RyaW5nJyAmJiAodmFsIHx8IHZhbCA9PSBudWxsIHx8IHZhbCA9PSAnJykpXG4gICAgICAgICAgdGhpcy5mb3JFYWNoKCRlbCA9PiAkZWwuYXR0cihhdHRycywgdmFsKSlcblxuICAgICAgICByZXR1cm4gdGhpc1xuICAgICAgfVxuICAgIH1cbiAgKVxufSIsIi8qIVxuICogaG90a2V5cy1qcyB2My4zLjVcbiAqIEEgc2ltcGxlIG1pY3JvLWxpYnJhcnkgZm9yIGRlZmluaW5nIGFuZCBkaXNwYXRjaGluZyBrZXlib2FyZCBzaG9ydGN1dHMuIEl0IGhhcyBubyBkZXBlbmRlbmNpZXMuXG4gKiBcbiAqIENvcHlyaWdodCAoYykgMjAxOCBrZW5ueSB3b25nIDx3b3dvaG9vQHFxLmNvbT5cbiAqIGh0dHA6Ly9qYXl3Y2psb3ZlLmdpdGh1Yi5pby9ob3RrZXlzXG4gKiBcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZS5cbiAqL1xuXG52YXIgaXNmZiA9IHR5cGVvZiBuYXZpZ2F0b3IgIT09ICd1bmRlZmluZWQnID8gbmF2aWdhdG9yLnVzZXJBZ2VudC50b0xvd2VyQ2FzZSgpLmluZGV4T2YoJ2ZpcmVmb3gnKSA+IDAgOiBmYWxzZTtcblxuLy8g57uR5a6a5LqL5Lu2XG5mdW5jdGlvbiBhZGRFdmVudChvYmplY3QsIGV2ZW50LCBtZXRob2QpIHtcbiAgaWYgKG9iamVjdC5hZGRFdmVudExpc3RlbmVyKSB7XG4gICAgb2JqZWN0LmFkZEV2ZW50TGlzdGVuZXIoZXZlbnQsIG1ldGhvZCwgZmFsc2UpO1xuICB9IGVsc2UgaWYgKG9iamVjdC5hdHRhY2hFdmVudCkge1xuICAgIG9iamVjdC5hdHRhY2hFdmVudCgnb24nICsgZXZlbnQsIGZ1bmN0aW9uICgpIHtcbiAgICAgIG1ldGhvZCh3aW5kb3cuZXZlbnQpO1xuICAgIH0pO1xuICB9XG59XG5cbi8vIOS/rumlsOmUrui9rOaNouaIkOWvueW6lOeahOmUrueggVxuZnVuY3Rpb24gZ2V0TW9kcyhtb2RpZmllciwga2V5KSB7XG4gIHZhciBtb2RzID0ga2V5LnNsaWNlKDAsIGtleS5sZW5ndGggLSAxKTtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBtb2RzLmxlbmd0aDsgaSsrKSB7XG4gICAgbW9kc1tpXSA9IG1vZGlmaWVyW21vZHNbaV0udG9Mb3dlckNhc2UoKV07XG4gIH1yZXR1cm4gbW9kcztcbn1cblxuLy8g5aSE55CG5Lyg55qEa2V55a2X56ym5Liy6L2s5o2i5oiQ5pWw57uEXG5mdW5jdGlvbiBnZXRLZXlzKGtleSkge1xuICBpZiAoIWtleSkga2V5ID0gJyc7XG5cbiAga2V5ID0ga2V5LnJlcGxhY2UoL1xccy9nLCAnJyk7IC8vIOWMuemFjeS7u+S9leepuueZveWtl+espizljIXmi6znqbrmoLzjgIHliLbooajnrKbjgIHmjaLpobXnrKbnrYnnrYlcbiAgdmFyIGtleXMgPSBrZXkuc3BsaXQoJywnKTsgLy8g5ZCM5pe26K6+572u5aSa5Liq5b+r5o236ZSu77yM5LulJywn5YiG5YmyXG4gIHZhciBpbmRleCA9IGtleXMubGFzdEluZGV4T2YoJycpO1xuXG4gIC8vIOW/q+aNt+mUruWPr+iDveWMheWQqycsJ++8jOmcgOeJueauiuWkhOeQhlxuICBmb3IgKDsgaW5kZXggPj0gMDspIHtcbiAgICBrZXlzW2luZGV4IC0gMV0gKz0gJywnO1xuICAgIGtleXMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICBpbmRleCA9IGtleXMubGFzdEluZGV4T2YoJycpO1xuICB9XG5cbiAgcmV0dXJuIGtleXM7XG59XG5cbi8vIOavlOi+g+S/rumlsOmUrueahOaVsOe7hFxuZnVuY3Rpb24gY29tcGFyZUFycmF5KGExLCBhMikge1xuICB2YXIgYXJyMSA9IGExLmxlbmd0aCA+PSBhMi5sZW5ndGggPyBhMSA6IGEyO1xuICB2YXIgYXJyMiA9IGExLmxlbmd0aCA+PSBhMi5sZW5ndGggPyBhMiA6IGExO1xuICB2YXIgaXNJbmRleCA9IHRydWU7XG5cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBhcnIxLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKGFycjIuaW5kZXhPZihhcnIxW2ldKSA9PT0gLTEpIGlzSW5kZXggPSBmYWxzZTtcbiAgfVxuICByZXR1cm4gaXNJbmRleDtcbn1cblxudmFyIF9rZXlNYXAgPSB7IC8vIOeJueauiumUrlxuICBiYWNrc3BhY2U6IDgsXG4gIHRhYjogOSxcbiAgY2xlYXI6IDEyLFxuICBlbnRlcjogMTMsXG4gIHJldHVybjogMTMsXG4gIGVzYzogMjcsXG4gIGVzY2FwZTogMjcsXG4gIHNwYWNlOiAzMixcbiAgbGVmdDogMzcsXG4gIHVwOiAzOCxcbiAgcmlnaHQ6IDM5LFxuICBkb3duOiA0MCxcbiAgZGVsOiA0NixcbiAgZGVsZXRlOiA0NixcbiAgaW5zOiA0NSxcbiAgaW5zZXJ0OiA0NSxcbiAgaG9tZTogMzYsXG4gIGVuZDogMzUsXG4gIHBhZ2V1cDogMzMsXG4gIHBhZ2Vkb3duOiAzNCxcbiAgY2Fwc2xvY2s6IDIwLFxuICAn4oeqJzogMjAsXG4gICcsJzogMTg4LFxuICAnLic6IDE5MCxcbiAgJy8nOiAxOTEsXG4gICdgJzogMTkyLFxuICAnLSc6IGlzZmYgPyAxNzMgOiAxODksXG4gICc9JzogaXNmZiA/IDYxIDogMTg3LFxuICAnOyc6IGlzZmYgPyA1OSA6IDE4NixcbiAgJ1xcJyc6IDIyMixcbiAgJ1snOiAyMTksXG4gICddJzogMjIxLFxuICAnXFxcXCc6IDIyMFxufTtcblxudmFyIF9tb2RpZmllciA9IHsgLy8g5L+u6aWw6ZSuXG4gICfih6cnOiAxNixcbiAgc2hpZnQ6IDE2LFxuICAn4oylJzogMTgsXG4gIGFsdDogMTgsXG4gIG9wdGlvbjogMTgsXG4gICfijIMnOiAxNyxcbiAgY3RybDogMTcsXG4gIGNvbnRyb2w6IDE3LFxuICAn4oyYJzogaXNmZiA/IDIyNCA6IDkxLFxuICBjbWQ6IGlzZmYgPyAyMjQgOiA5MSxcbiAgY29tbWFuZDogaXNmZiA/IDIyNCA6IDkxXG59O1xudmFyIF9kb3duS2V5cyA9IFtdOyAvLyDorrDlvZXmkYHkuIvnmoTnu5HlrprplK5cbnZhciBtb2RpZmllck1hcCA9IHtcbiAgMTY6ICdzaGlmdEtleScsXG4gIDE4OiAnYWx0S2V5JyxcbiAgMTc6ICdjdHJsS2V5J1xufTtcbnZhciBfbW9kcyA9IHsgMTY6IGZhbHNlLCAxODogZmFsc2UsIDE3OiBmYWxzZSB9O1xudmFyIF9oYW5kbGVycyA9IHt9O1xuXG4vLyBGMX5GMTIg54m55q6K6ZSuXG5mb3IgKHZhciBrID0gMTsgayA8IDIwOyBrKyspIHtcbiAgX2tleU1hcFsnZicgKyBrXSA9IDExMSArIGs7XG59XG5cbi8vIOWFvOWuuUZpcmVmb3jlpITnkIZcbm1vZGlmaWVyTWFwW2lzZmYgPyAyMjQgOiA5MV0gPSAnbWV0YUtleSc7XG5fbW9kc1tpc2ZmID8gMjI0IDogOTFdID0gZmFsc2U7XG5cbnZhciBfc2NvcGUgPSAnYWxsJzsgLy8g6buY6K6k54Ot6ZSu6IyD5Zu0XG52YXIgaXNCaW5kRWxlbWVudCA9IGZhbHNlOyAvLyDmmK/lkKbnu5HlrproioLngrlcblxuLy8g6L+U5Zue6ZSu56CBXG52YXIgY29kZSA9IGZ1bmN0aW9uIGNvZGUoeCkge1xuICByZXR1cm4gX2tleU1hcFt4LnRvTG93ZXJDYXNlKCldIHx8IHgudG9VcHBlckNhc2UoKS5jaGFyQ29kZUF0KDApO1xufTtcblxuLy8g6K6+572u6I635Y+W5b2T5YmN6IyD5Zu077yI6buY6K6k5Li6J+aJgOaciSfvvIlcbmZ1bmN0aW9uIHNldFNjb3BlKHNjb3BlKSB7XG4gIF9zY29wZSA9IHNjb3BlIHx8ICdhbGwnO1xufVxuLy8g6I635Y+W5b2T5YmN6IyD5Zu0XG5mdW5jdGlvbiBnZXRTY29wZSgpIHtcbiAgcmV0dXJuIF9zY29wZSB8fCAnYWxsJztcbn1cbi8vIOiOt+WPluaRgeS4i+e7keWumumUrueahOmUruWAvFxuZnVuY3Rpb24gZ2V0UHJlc3NlZEtleUNvZGVzKCkge1xuICByZXR1cm4gX2Rvd25LZXlzLnNsaWNlKDApO1xufVxuXG4vLyDooajljZXmjqfku7bmjqfku7bliKTmlq0g6L+U5ZueIEJvb2xlYW5cbmZ1bmN0aW9uIGZpbHRlcihldmVudCkge1xuICB2YXIgdGFnTmFtZSA9IGV2ZW50LnRhcmdldC50YWdOYW1lIHx8IGV2ZW50LnNyY0VsZW1lbnQudGFnTmFtZTtcbiAgLy8g5b+955Wl6L+Z5Lqb5qCH562+5oOF5Ya15LiL5b+r5o236ZSu5peg5pWIXG4gIHJldHVybiAhKHRhZ05hbWUgPT09ICdJTlBVVCcgfHwgdGFnTmFtZSA9PT0gJ1NFTEVDVCcgfHwgdGFnTmFtZSA9PT0gJ1RFWFRBUkVBJyk7XG59XG5cbi8vIOWIpOaWreaRgeS4i+eahOmUruaYr+WQpuS4uuafkOS4qumUru+8jOi/lOWbnnRydWXmiJbogIVmYWxzZVxuZnVuY3Rpb24gaXNQcmVzc2VkKGtleUNvZGUpIHtcbiAgaWYgKHR5cGVvZiBrZXlDb2RlID09PSAnc3RyaW5nJykge1xuICAgIGtleUNvZGUgPSBjb2RlKGtleUNvZGUpOyAvLyDovazmjaLmiJDplK7noIFcbiAgfVxuICByZXR1cm4gX2Rvd25LZXlzLmluZGV4T2Yoa2V5Q29kZSkgIT09IC0xO1xufVxuXG4vLyDlvqrnjq/liKDpmaRoYW5kbGVyc+S4reeahOaJgOaciSBzY29wZSjojIPlm7QpXG5mdW5jdGlvbiBkZWxldGVTY29wZShzY29wZSwgbmV3U2NvcGUpIHtcbiAgdmFyIGhhbmRsZXJzID0gdm9pZCAwO1xuICB2YXIgaSA9IHZvaWQgMDtcblxuICAvLyDmsqHmnInmjIflrppzY29wZe+8jOiOt+WPlnNjb3BlXG4gIGlmICghc2NvcGUpIHNjb3BlID0gZ2V0U2NvcGUoKTtcblxuICBmb3IgKHZhciBrZXkgaW4gX2hhbmRsZXJzKSB7XG4gICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChfaGFuZGxlcnMsIGtleSkpIHtcbiAgICAgIGhhbmRsZXJzID0gX2hhbmRsZXJzW2tleV07XG4gICAgICBmb3IgKGkgPSAwOyBpIDwgaGFuZGxlcnMubGVuZ3RoOykge1xuICAgICAgICBpZiAoaGFuZGxlcnNbaV0uc2NvcGUgPT09IHNjb3BlKSBoYW5kbGVycy5zcGxpY2UoaSwgMSk7ZWxzZSBpKys7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLy8g5aaC5p6cc2NvcGXooqvliKDpmaTvvIzlsIZzY29wZemHjee9ruS4umFsbFxuICBpZiAoZ2V0U2NvcGUoKSA9PT0gc2NvcGUpIHNldFNjb3BlKG5ld1Njb3BlIHx8ICdhbGwnKTtcbn1cblxuLy8g5riF6Zmk5L+u6aWw6ZSuXG5mdW5jdGlvbiBjbGVhck1vZGlmaWVyKGV2ZW50KSB7XG4gIHZhciBrZXkgPSBldmVudC5rZXlDb2RlIHx8IGV2ZW50LndoaWNoIHx8IGV2ZW50LmNoYXJDb2RlO1xuICB2YXIgaSA9IF9kb3duS2V5cy5pbmRleE9mKGtleSk7XG5cbiAgLy8g5LuO5YiX6KGo5Lit5riF6Zmk5oyJ5Y6L6L+H55qE6ZSuXG4gIGlmIChpID49IDApIF9kb3duS2V5cy5zcGxpY2UoaSwgMSk7XG5cbiAgLy8g5L+u6aWw6ZSuIHNoaWZ0S2V5IGFsdEtleSBjdHJsS2V5IChjb21tYW5kfHxtZXRhS2V5KSDmuIXpmaRcbiAgaWYgKGtleSA9PT0gOTMgfHwga2V5ID09PSAyMjQpIGtleSA9IDkxO1xuICBpZiAoa2V5IGluIF9tb2RzKSB7XG4gICAgX21vZHNba2V5XSA9IGZhbHNlO1xuXG4gICAgLy8g5bCG5L+u6aWw6ZSu6YeN572u5Li6ZmFsc2VcbiAgICBmb3IgKHZhciBrIGluIF9tb2RpZmllcikge1xuICAgICAgaWYgKF9tb2RpZmllcltrXSA9PT0ga2V5KSBob3RrZXlzW2tdID0gZmFsc2U7XG4gICAgfVxuICB9XG59XG5cbi8vIOino+mZpOe7keWumuafkOS4quiMg+WbtOeahOW/q+aNt+mUrlxuZnVuY3Rpb24gdW5iaW5kKGtleSwgc2NvcGUpIHtcbiAgdmFyIG11bHRpcGxlS2V5cyA9IGdldEtleXMoa2V5KTtcbiAgdmFyIGtleXMgPSB2b2lkIDA7XG4gIHZhciBtb2RzID0gW107XG4gIHZhciBvYmogPSB2b2lkIDA7XG5cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBtdWx0aXBsZUtleXMubGVuZ3RoOyBpKyspIHtcbiAgICAvLyDlsIbnu4TlkIjlv6vmjbfplK7mi4bliIbkuLrmlbDnu4RcbiAgICBrZXlzID0gbXVsdGlwbGVLZXlzW2ldLnNwbGl0KCcrJyk7XG5cbiAgICAvLyDorrDlvZXmr4/kuKrnu4TlkIjplK7kuK3nmoTkv67ppbDplK7nmoTplK7noIEg6L+U5Zue5pWw57uEXG4gICAgaWYgKGtleXMubGVuZ3RoID4gMSkgbW9kcyA9IGdldE1vZHMoX21vZGlmaWVyLCBrZXlzKTtcblxuICAgIC8vIOiOt+WPlumZpOS/rumlsOmUruWklueahOmUruWAvGtleVxuICAgIGtleSA9IGtleXNba2V5cy5sZW5ndGggLSAxXTtcbiAgICBrZXkgPSBrZXkgPT09ICcqJyA/ICcqJyA6IGNvZGUoa2V5KTtcblxuICAgIC8vIOWIpOaWreaYr+WQpuS8oOWFpeiMg+WbtO+8jOayoeacieWwseiOt+WPluiMg+WbtFxuICAgIGlmICghc2NvcGUpIHNjb3BlID0gZ2V0U2NvcGUoKTtcblxuICAgIC8vIOWmguS9lWtleeS4jeWcqCBfaGFuZGxlcnMg5Lit6L+U5Zue5LiN5YGa5aSE55CGXG4gICAgaWYgKCFfaGFuZGxlcnNba2V5XSkgcmV0dXJuO1xuXG4gICAgLy8g5riF56m6IGhhbmRsZXJzIOS4reaVsOaNru+8jFxuICAgIC8vIOiuqeinpuWPkeW/q+aNt+mUrumUruS5i+WQjuayoeacieS6i+S7tuaJp+ihjOWIsOi+vuino+mZpOW/q+aNt+mUrue7keWumueahOebrueahFxuICAgIGZvciAodmFyIHIgPSAwOyByIDwgX2hhbmRsZXJzW2tleV0ubGVuZ3RoOyByKyspIHtcbiAgICAgIG9iaiA9IF9oYW5kbGVyc1trZXldW3JdO1xuICAgICAgLy8g5Yik5pat5piv5ZCm5Zyo6IyD5Zu05YaF5bm25LiU6ZSu5YC855u45ZCMXG4gICAgICBpZiAob2JqLnNjb3BlID09PSBzY29wZSAmJiBjb21wYXJlQXJyYXkob2JqLm1vZHMsIG1vZHMpKSB7XG4gICAgICAgIF9oYW5kbGVyc1trZXldW3JdID0ge307XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi8vIOWvueebkeWQrOWvueW6lOW/q+aNt+mUrueahOWbnuiwg+WHveaVsOi/m+ihjOWkhOeQhlxuZnVuY3Rpb24gZXZlbnRIYW5kbGVyKGV2ZW50LCBoYW5kbGVyLCBzY29wZSkge1xuICB2YXIgbW9kaWZpZXJzTWF0Y2ggPSB2b2lkIDA7XG5cbiAgLy8g55yL5a6D5piv5ZCm5Zyo5b2T5YmN6IyD5Zu0XG4gIGlmIChoYW5kbGVyLnNjb3BlID09PSBzY29wZSB8fCBoYW5kbGVyLnNjb3BlID09PSAnYWxsJykge1xuICAgIC8vIOajgOafpeaYr+WQpuWMuemFjeS/rumlsOespu+8iOWmguaenOaciei/lOWbnnRydWXvvIlcbiAgICBtb2RpZmllcnNNYXRjaCA9IGhhbmRsZXIubW9kcy5sZW5ndGggPiAwO1xuXG4gICAgZm9yICh2YXIgeSBpbiBfbW9kcykge1xuICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChfbW9kcywgeSkpIHtcbiAgICAgICAgaWYgKCFfbW9kc1t5XSAmJiBoYW5kbGVyLm1vZHMuaW5kZXhPZigreSkgPiAtMSB8fCBfbW9kc1t5XSAmJiBoYW5kbGVyLm1vZHMuaW5kZXhPZigreSkgPT09IC0xKSBtb2RpZmllcnNNYXRjaCA9IGZhbHNlO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIOiwg+eUqOWkhOeQhueoi+W6j++8jOWmguaenOaYr+S/rumlsOmUruS4jeWBmuWkhOeQhlxuICAgIGlmIChoYW5kbGVyLm1vZHMubGVuZ3RoID09PSAwICYmICFfbW9kc1sxNl0gJiYgIV9tb2RzWzE4XSAmJiAhX21vZHNbMTddICYmICFfbW9kc1s5MV0gfHwgbW9kaWZpZXJzTWF0Y2ggfHwgaGFuZGxlci5zaG9ydGN1dCA9PT0gJyonKSB7XG4gICAgICBpZiAoaGFuZGxlci5tZXRob2QoZXZlbnQsIGhhbmRsZXIpID09PSBmYWxzZSkge1xuICAgICAgICBpZiAoZXZlbnQucHJldmVudERlZmF1bHQpIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7ZWxzZSBldmVudC5yZXR1cm5WYWx1ZSA9IGZhbHNlO1xuICAgICAgICBpZiAoZXZlbnQuc3RvcFByb3BhZ2F0aW9uKSBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgaWYgKGV2ZW50LmNhbmNlbEJ1YmJsZSkgZXZlbnQuY2FuY2VsQnViYmxlID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuLy8g5aSE55CGa2V5ZG93buS6i+S7tlxuZnVuY3Rpb24gZGlzcGF0Y2goZXZlbnQpIHtcbiAgdmFyIGFzdGVyaXNrID0gX2hhbmRsZXJzWycqJ107XG4gIHZhciBrZXkgPSBldmVudC5rZXlDb2RlIHx8IGV2ZW50LndoaWNoIHx8IGV2ZW50LmNoYXJDb2RlO1xuXG4gIC8vIOaQnOmbhue7keWumueahOmUrlxuICBpZiAoX2Rvd25LZXlzLmluZGV4T2Yoa2V5KSA9PT0gLTEpIF9kb3duS2V5cy5wdXNoKGtleSk7XG5cbiAgLy8gR2Vja28oRmlyZWZveCnnmoRjb21tYW5k6ZSu5YC8MjI077yM5ZyoV2Via2l0KENocm9tZSnkuK3kv53mjIHkuIDoh7RcbiAgLy8gV2Via2l05bem5Y+zY29tbWFuZOmUruWAvOS4jeS4gOagt1xuICBpZiAoa2V5ID09PSA5MyB8fCBrZXkgPT09IDIyNCkga2V5ID0gOTE7XG5cbiAgaWYgKGtleSBpbiBfbW9kcykge1xuICAgIF9tb2RzW2tleV0gPSB0cnVlO1xuXG4gICAgLy8g5bCG54m55q6K5a2X56ym55qEa2V55rOo5YaM5YiwIGhvdGtleXMg5LiKXG4gICAgZm9yICh2YXIgayBpbiBfbW9kaWZpZXIpIHtcbiAgICAgIGlmIChfbW9kaWZpZXJba10gPT09IGtleSkgaG90a2V5c1trXSA9IHRydWU7XG4gICAgfVxuXG4gICAgaWYgKCFhc3RlcmlzaykgcmV0dXJuO1xuICB9XG5cbiAgLy8g5bCGbW9kaWZpZXJNYXDph4zpnaLnmoTkv67ppbDplK7nu5HlrprliLBldmVudOS4rVxuICBmb3IgKHZhciBlIGluIF9tb2RzKSB7XG4gICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChfbW9kcywgZSkpIHtcbiAgICAgIF9tb2RzW2VdID0gZXZlbnRbbW9kaWZpZXJNYXBbZV1dO1xuICAgIH1cbiAgfVxuXG4gIC8vIOihqOWNleaOp+S7tui/h+a7pCDpu5jorqTooajljZXmjqfku7bkuI3op6blj5Hlv6vmjbfplK5cbiAgaWYgKCFob3RrZXlzLmZpbHRlci5jYWxsKHRoaXMsIGV2ZW50KSkgcmV0dXJuO1xuXG4gIC8vIOiOt+WPluiMg+WbtCDpu5jorqTkuLphbGxcbiAgdmFyIHNjb3BlID0gZ2V0U2NvcGUoKTtcblxuICAvLyDlr7nku7vkvZXlv6vmjbfplK7pg73pnIDopoHlgZrnmoTlpITnkIZcbiAgaWYgKGFzdGVyaXNrKSB7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhc3Rlcmlzay5sZW5ndGg7IGkrKykge1xuICAgICAgaWYgKGFzdGVyaXNrW2ldLnNjb3BlID09PSBzY29wZSkgZXZlbnRIYW5kbGVyKGV2ZW50LCBhc3Rlcmlza1tpXSwgc2NvcGUpO1xuICAgIH1cbiAgfVxuICAvLyBrZXkg5LiN5ZyoX2hhbmRsZXJz5Lit6L+U5ZueXG4gIGlmICghKGtleSBpbiBfaGFuZGxlcnMpKSByZXR1cm47XG5cbiAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IF9oYW5kbGVyc1trZXldLmxlbmd0aDsgX2krKykge1xuICAgIC8vIOaJvuWIsOWkhOeQhuWGheWuuVxuICAgIGV2ZW50SGFuZGxlcihldmVudCwgX2hhbmRsZXJzW2tleV1bX2ldLCBzY29wZSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gaG90a2V5cyhrZXksIG9wdGlvbiwgbWV0aG9kKSB7XG4gIHZhciBrZXlzID0gZ2V0S2V5cyhrZXkpOyAvLyDpnIDopoHlpITnkIbnmoTlv6vmjbfplK7liJfooahcbiAgdmFyIG1vZHMgPSBbXTtcbiAgdmFyIHNjb3BlID0gJ2FsbCc7IC8vIHNjb3Bl6buY6K6k5Li6YWxs77yM5omA5pyJ6IyD5Zu06YO95pyJ5pWIXG4gIHZhciBlbGVtZW50ID0gZG9jdW1lbnQ7IC8vIOW/q+aNt+mUruS6i+S7tue7keWumuiKgueCuVxuICB2YXIgaSA9IDA7XG5cbiAgLy8g5a+55Li66K6+5a6a6IyD5Zu055qE5Yik5patXG4gIGlmIChtZXRob2QgPT09IHVuZGVmaW5lZCAmJiB0eXBlb2Ygb3B0aW9uID09PSAnZnVuY3Rpb24nKSB7XG4gICAgbWV0aG9kID0gb3B0aW9uO1xuICB9XG5cbiAgaWYgKE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvcHRpb24pID09PSAnW29iamVjdCBPYmplY3RdJykge1xuICAgIGlmIChvcHRpb24uc2NvcGUpIHNjb3BlID0gb3B0aW9uLnNjb3BlOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgaWYgKG9wdGlvbi5lbGVtZW50KSBlbGVtZW50ID0gb3B0aW9uLmVsZW1lbnQ7IC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbiAgfVxuXG4gIGlmICh0eXBlb2Ygb3B0aW9uID09PSAnc3RyaW5nJykgc2NvcGUgPSBvcHRpb247XG5cbiAgLy8g5a+55LqO5q+P5Liq5b+r5o236ZSu6L+b6KGM5aSE55CGXG4gIGZvciAoOyBpIDwga2V5cy5sZW5ndGg7IGkrKykge1xuICAgIGtleSA9IGtleXNbaV0uc3BsaXQoJysnKTsgLy8g5oyJ6ZSu5YiX6KGoXG4gICAgbW9kcyA9IFtdO1xuXG4gICAgLy8g5aaC5p6c5piv57uE5ZCI5b+r5o236ZSu5Y+W5b6X57uE5ZCI5b+r5o236ZSuXG4gICAgaWYgKGtleS5sZW5ndGggPiAxKSBtb2RzID0gZ2V0TW9kcyhfbW9kaWZpZXIsIGtleSk7XG5cbiAgICAvLyDlsIbpnZ7kv67ppbDplK7ovazljJbkuLrplK7noIFcbiAgICBrZXkgPSBrZXlba2V5Lmxlbmd0aCAtIDFdO1xuICAgIGtleSA9IGtleSA9PT0gJyonID8gJyonIDogY29kZShrZXkpOyAvLyAq6KGo56S65Yy56YWN5omA5pyJ5b+r5o236ZSuXG5cbiAgICAvLyDliKTmlq1rZXnmmK/lkKblnKhfaGFuZGxlcnPkuK3vvIzkuI3lnKjlsLHotYvkuIDkuKrnqbrmlbDnu4RcbiAgICBpZiAoIShrZXkgaW4gX2hhbmRsZXJzKSkgX2hhbmRsZXJzW2tleV0gPSBbXTtcblxuICAgIF9oYW5kbGVyc1trZXldLnB1c2goe1xuICAgICAgc2NvcGU6IHNjb3BlLFxuICAgICAgbW9kczogbW9kcyxcbiAgICAgIHNob3J0Y3V0OiBrZXlzW2ldLFxuICAgICAgbWV0aG9kOiBtZXRob2QsXG4gICAgICBrZXk6IGtleXNbaV1cbiAgICB9KTtcbiAgfVxuICAvLyDlnKjlhajlsYBkb2N1bWVudOS4iuiuvue9ruW/q+aNt+mUrlxuICBpZiAodHlwZW9mIGVsZW1lbnQgIT09ICd1bmRlZmluZWQnICYmICFpc0JpbmRFbGVtZW50KSB7XG4gICAgaXNCaW5kRWxlbWVudCA9IHRydWU7XG4gICAgYWRkRXZlbnQoZWxlbWVudCwgJ2tleWRvd24nLCBmdW5jdGlvbiAoZSkge1xuICAgICAgZGlzcGF0Y2goZSk7XG4gICAgfSk7XG4gICAgYWRkRXZlbnQoZWxlbWVudCwgJ2tleXVwJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgIGNsZWFyTW9kaWZpZXIoZSk7XG4gICAgfSk7XG4gIH1cbn1cblxudmFyIF9hcGkgPSB7XG4gIHNldFNjb3BlOiBzZXRTY29wZSxcbiAgZ2V0U2NvcGU6IGdldFNjb3BlLFxuICBkZWxldGVTY29wZTogZGVsZXRlU2NvcGUsXG4gIGdldFByZXNzZWRLZXlDb2RlczogZ2V0UHJlc3NlZEtleUNvZGVzLFxuICBpc1ByZXNzZWQ6IGlzUHJlc3NlZCxcbiAgZmlsdGVyOiBmaWx0ZXIsXG4gIHVuYmluZDogdW5iaW5kXG59O1xuZm9yICh2YXIgYSBpbiBfYXBpKSB7XG4gIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoX2FwaSwgYSkpIHtcbiAgICBob3RrZXlzW2FdID0gX2FwaVthXTtcbiAgfVxufVxuXG5pZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgdmFyIF9ob3RrZXlzID0gd2luZG93LmhvdGtleXM7XG4gIGhvdGtleXMubm9Db25mbGljdCA9IGZ1bmN0aW9uIChkZWVwKSB7XG4gICAgaWYgKGRlZXAgJiYgd2luZG93LmhvdGtleXMgPT09IGhvdGtleXMpIHtcbiAgICAgIHdpbmRvdy5ob3RrZXlzID0gX2hvdGtleXM7XG4gICAgfVxuICAgIHJldHVybiBob3RrZXlzO1xuICB9O1xuICB3aW5kb3cuaG90a2V5cyA9IGhvdGtleXM7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGhvdGtleXM7XG4iLCJpbXBvcnQgJCBmcm9tICdibGluZ2JsaW5nanMnXG5cbmV4cG9ydCBjbGFzcyBIYW5kbGVzIGV4dGVuZHMgSFRNTEVsZW1lbnQge1xuICBcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuICAgIHRoaXMuJHNoYWRvdyA9IHRoaXMuYXR0YWNoU2hhZG93KHttb2RlOiAnb3Blbid9KVxuICB9XG5cbiAgY29ubmVjdGVkQ2FsbGJhY2soKSB7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHRoaXMub25fcmVzaXplLmJpbmQodGhpcykpXG4gIH1cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7XG4gICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHRoaXMub25fcmVzaXplKVxuICB9XG5cbiAgb25fcmVzaXplKCkge1xuICAgIHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgICAgY29uc3Qgbm9kZV9sYWJlbF9pZCA9IHRoaXMuJHNoYWRvdy5ob3N0LmdldEF0dHJpYnV0ZSgnZGF0YS1sYWJlbC1pZCcpXG4gICAgICBjb25zdCBbc291cmNlX2VsXSA9ICQoYFtkYXRhLWxhYmVsLWlkPVwiJHtub2RlX2xhYmVsX2lkfVwiXWApXG5cbiAgICAgIHRoaXMucG9zaXRpb24gPSB7XG4gICAgICAgIG5vZGVfbGFiZWxfaWQsXG4gICAgICAgIGJvdW5kaW5nUmVjdDogc291cmNlX2VsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICBzZXQgcG9zaXRpb24oe2JvdW5kaW5nUmVjdCwgbm9kZV9sYWJlbF9pZH0pIHtcbiAgICB0aGlzLiRzaGFkb3cuaW5uZXJIVE1MICA9IHRoaXMucmVuZGVyKGJvdW5kaW5nUmVjdCwgbm9kZV9sYWJlbF9pZClcbiAgfVxuXG4gIHJlbmRlcih7IHgsIHksIHdpZHRoLCBoZWlnaHQsIHRvcCwgbGVmdCB9LCBub2RlX2xhYmVsX2lkKSB7XG4gICAgdGhpcy4kc2hhZG93Lmhvc3Quc2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJywgbm9kZV9sYWJlbF9pZClcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcyh7dG9wLGxlZnR9KX1cbiAgICAgIDxzdmcgXG4gICAgICAgIGNsYXNzPVwicGItaGFuZGxlc1wiXG4gICAgICAgIHdpZHRoPVwiJHt3aWR0aH1cIiBoZWlnaHQ9XCIke2hlaWdodH1cIiBcbiAgICAgICAgdmlld0JveD1cIjAgMCAke3dpZHRofSAke2hlaWdodH1cIiBcbiAgICAgICAgdmVyc2lvbj1cIjEuMVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgPlxuICAgICAgICA8cmVjdCBzdHJva2U9XCJob3RwaW5rXCIgZmlsbD1cIm5vbmVcIiB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+PC9yZWN0PlxuICAgICAgICA8Y2lyY2xlIHN0cm9rZT1cImhvdHBpbmtcIiBmaWxsPVwid2hpdGVcIiBjeD1cIjBcIiBjeT1cIjBcIiByPVwiMlwiPjwvY2lyY2xlPlxuICAgICAgICA8Y2lyY2xlIHN0cm9rZT1cImhvdHBpbmtcIiBmaWxsPVwid2hpdGVcIiBjeD1cIjEwMCVcIiBjeT1cIjBcIiByPVwiMlwiPjwvY2lyY2xlPlxuICAgICAgICA8Y2lyY2xlIHN0cm9rZT1cImhvdHBpbmtcIiBmaWxsPVwid2hpdGVcIiBjeD1cIjEwMCVcIiBjeT1cIjEwMCVcIiByPVwiMlwiPjwvY2lyY2xlPlxuICAgICAgICA8Y2lyY2xlIHN0cm9rZT1cImhvdHBpbmtcIiBmaWxsPVwid2hpdGVcIiBjeD1cIjBcIiBjeT1cIjEwMCVcIiByPVwiMlwiPjwvY2lyY2xlPlxuICAgICAgICA8Y2lyY2xlIGZpbGw9XCJob3RwaW5rXCIgY3g9XCIke3dpZHRoLzJ9XCIgY3k9XCIwXCIgcj1cIjJcIj48L2NpcmNsZT5cbiAgICAgICAgPGNpcmNsZSBmaWxsPVwiaG90cGlua1wiIGN4PVwiMFwiIGN5PVwiJHtoZWlnaHQvMn1cIiByPVwiMlwiPjwvY2lyY2xlPlxuICAgICAgICA8Y2lyY2xlIGZpbGw9XCJob3RwaW5rXCIgY3g9XCIke3dpZHRoLzJ9XCIgY3k9XCIke2hlaWdodH1cIiByPVwiMlwiPjwvY2lyY2xlPlxuICAgICAgICA8Y2lyY2xlIGZpbGw9XCJob3RwaW5rXCIgY3g9XCIke3dpZHRofVwiIGN5PVwiJHtoZWlnaHQvMn1cIiByPVwiMlwiPjwvY2lyY2xlPlxuICAgICAgPC9zdmc+XG4gICAgYFxuICB9XG5cbiAgc3R5bGVzKHt0b3AsbGVmdH0pIHtcbiAgICByZXR1cm4gYFxuICAgICAgPHN0eWxlPlxuICAgICAgICA6aG9zdCA+IHN2ZyB7XG4gICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgIHRvcDogJHt0b3AgKyB3aW5kb3cuc2Nyb2xsWX1weDtcbiAgICAgICAgICBsZWZ0OiAke2xlZnR9cHg7XG4gICAgICAgICAgb3ZlcmZsb3c6IHZpc2libGU7XG4gICAgICAgICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XG4gICAgICAgICAgei1pbmRleDogMTAwMTA7XG4gICAgICAgIH1cbiAgICAgIDwvc3R5bGU+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgncGItaGFuZGxlcycsIEhhbmRsZXMpIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuXG5leHBvcnQgY2xhc3MgTGFiZWwgZXh0ZW5kcyBIVE1MRWxlbWVudCB7XG4gIFxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG4gICAgdGhpcy4kc2hhZG93ID0gdGhpcy5hdHRhY2hTaGFkb3coe21vZGU6ICdvcGVuJ30pXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICAkKCdhJywgdGhpcy4kc2hhZG93KS5vbignY2xpY2sgbW91c2VlbnRlcicsIHRoaXMuZGlzcGF0Y2hRdWVyeS5iaW5kKHRoaXMpKVxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCB0aGlzLm9uX3Jlc2l6ZS5iaW5kKHRoaXMpKVxuICB9XG5cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7XG4gICAgJCgnYScsIHRoaXMuJHNoYWRvdykub2ZmKCdjbGljaycsIHRoaXMuZGlzcGF0Y2hRdWVyeSlcbiAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdGhpcy5vbl9yZXNpemUpXG4gIH1cblxuICBvbl9yZXNpemUoKSB7XG4gICAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICBjb25zdCBub2RlX2xhYmVsX2lkID0gdGhpcy4kc2hhZG93Lmhvc3QuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJylcbiAgICAgIGNvbnN0IFtzb3VyY2VfZWxdICAgPSAkKGBbZGF0YS1sYWJlbC1pZD1cIiR7bm9kZV9sYWJlbF9pZH1cIl1gKVxuXG4gICAgICBpZiAoIXNvdXJjZV9lbCkgcmV0dXJuXG5cbiAgICAgIHRoaXMucG9zaXRpb24gPSB7XG4gICAgICAgIG5vZGVfbGFiZWxfaWQsXG4gICAgICAgIGJvdW5kaW5nUmVjdDogc291cmNlX2VsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICBkaXNwYXRjaFF1ZXJ5KGUpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5kaXNwYXRjaEV2ZW50KG5ldyBDdXN0b21FdmVudCgncXVlcnknLCB7XG4gICAgICBidWJibGVzOiB0cnVlLFxuICAgICAgZGV0YWlsOiAgIHtcbiAgICAgICAgdGV4dDogICAgICAgZS50YXJnZXQudGV4dENvbnRlbnQsXG4gICAgICAgIGFjdGl2YXRvcjogIGUudHlwZSxcbiAgICAgIH1cbiAgICB9KSlcbiAgfVxuXG4gIHNldCB0ZXh0KGNvbnRlbnQpIHtcbiAgICB0aGlzLl90ZXh0ID0gY29udGVudFxuICB9XG5cbiAgc2V0IHBvc2l0aW9uKHtib3VuZGluZ1JlY3QsIG5vZGVfbGFiZWxfaWR9KSB7XG4gICAgdGhpcy4kc2hhZG93LmlubmVySFRNTCAgPSB0aGlzLnJlbmRlcihib3VuZGluZ1JlY3QsIG5vZGVfbGFiZWxfaWQpXG4gIH1cblxuICBzZXQgdXBkYXRlKHt4LHl9KSB7XG4gICAgY29uc3QgbGFiZWwgPSB0aGlzLiRzaGFkb3cuY2hpbGRyZW5bMV1cbiAgICBsYWJlbC5zdHlsZS50b3AgID0geSArIHdpbmRvdy5zY3JvbGxZICsgJ3B4J1xuICAgIGxhYmVsLnN0eWxlLmxlZnQgPSB4IC0gMSArICdweCdcbiAgfVxuXG4gIHJlbmRlcih7IHgsIHksIHdpZHRoLCBoZWlnaHQsIHRvcCwgbGVmdCB9LCBub2RlX2xhYmVsX2lkKSB7XG4gICAgdGhpcy4kc2hhZG93Lmhvc3Quc2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJywgbm9kZV9sYWJlbF9pZClcblxuICAgIHJldHVybiBgXG4gICAgICAke3RoaXMuc3R5bGVzKHt0b3AsbGVmdCx3aWR0aH0pfVxuICAgICAgPHNwYW4+XG4gICAgICAgICR7dGhpcy5fdGV4dH1cbiAgICAgIDwvc3Bhbj5cbiAgICBgXG4gIH1cblxuICBzdHlsZXMoe3RvcCxsZWZ0LHdpZHRofSkge1xuICAgIHJldHVybiBgXG4gICAgICA8c3R5bGU+XG4gICAgICAgIDpob3N0IHtcbiAgICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgIH1cblxuICAgICAgICA6aG9zdCA+IHNwYW4ge1xuICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICB0b3A6ICR7dG9wICsgd2luZG93LnNjcm9sbFl9cHg7XG4gICAgICAgICAgbGVmdDogJHtsZWZ0IC0gMX1weDtcbiAgICAgICAgICBtYXgtd2lkdGg6ICR7d2lkdGggKyAod2luZG93LmlubmVyV2lkdGggLSBsZWZ0IC0gd2lkdGggLSAyMCl9cHg7XG4gICAgICAgICAgei1pbmRleDogMTAwMDA7XG4gICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0xMDAlKTtcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBoc2woMzMwLCAxMDAlLCA3MSUpO1xuICAgICAgICAgIHRleHQtc2hhZG93OiAwIDAuNXB4IDAgaHNsKDMzMCwgMTAwJSwgNjElKTtcbiAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgICAgZm9udC1zaXplOiAwLjhlbTtcbiAgICAgICAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgICAgICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xuICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgICAgICAgcGFkZGluZzogMC4yNWVtIDAuNGVtIDAuMTVlbTtcbiAgICAgICAgICBsaW5lLWhlaWdodDogMS4xO1xuICAgICAgICB9XG5cbiAgICAgICAgOmhvc3QgYSB7XG4gICAgICAgICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xuICAgICAgICAgIGNvbG9yOiBpbmhlcml0O1xuICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgICB9XG5cbiAgICAgICAgOmhvc3QgYTpob3ZlciB7XG4gICAgICAgICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICB9XG4gICAgICA8L3N0eWxlPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ3BiLWxhYmVsJywgTGFiZWwpIiwiZXhwb3J0IGNvbnN0IGRlc2lyZWRQcm9wTWFwID0ge1xuICBjb2xvcjogICAgICAgICAgICAgICAgJ3JnYigwLCAwLCAwKScsXG4gIGJhY2tncm91bmRDb2xvcjogICAgICAncmdiYSgwLCAwLCAwLCAwKScsXG4gIGJhY2tncm91bmRJbWFnZTogICAgICAnbm9uZScsXG4gIGJhY2tncm91bmRTaXplOiAgICAgICAnYXV0bycsXG4gIGJhY2tncm91bmRQb3NpdGlvbjogICAnMCUgMCUnLFxuICAvLyBib3JkZXJDb2xvcjogICAgICAgICAgJ3JnYigwLCAwLCAwKScsXG4gIGJvcmRlcldpZHRoOiAgICAgICAgICAnMHB4JyxcbiAgYm9yZGVyUmFkaXVzOiAgICAgICAgICcwcHgnLFxuICBib3hTaGFkb3c6ICAgICAgICAgICAgJ25vbmUnLFxuICBwYWRkaW5nOiAgICAgICAgICAgICAgJzBweCcsXG4gIG1hcmdpbjogICAgICAgICAgICAgICAnMHB4JyxcbiAgZm9udEZhbWlseTogICAgICAgICAgICcnLFxuICBmb250U2l6ZTogICAgICAgICAgICAgJzE2cHgnLFxuICBmb250V2VpZ2h0OiAgICAgICAgICAgJzQwMCcsXG4gIHRleHRBbGlnbjogICAgICAgICAgICAnc3RhcnQnLFxuICB0ZXh0U2hhZG93OiAgICAgICAgICAgJ25vbmUnLFxuICB0ZXh0VHJhbnNmb3JtOiAgICAgICAgJ25vbmUnLFxuICBsaW5lSGVpZ2h0OiAgICAgICAgICAgJ25vcm1hbCcsXG4gIGxldHRlclNwYWNpbmc6ICAgICAgICAnbm9ybWFsJyxcbiAgZGlzcGxheTogICAgICAgICAgICAgICdibG9jaycsXG4gIGFsaWduSXRlbXM6ICAgICAgICAgICAnbm9ybWFsJyxcbiAganVzdGlmeUNvbnRlbnQ6ICAgICAgICdub3JtYWwnLFxuICBmaWxsOiAgICAgICAgICAgICAgICAgJ3JnYigwLCAwLCAwKScsXG4gIHN0cm9rZTogICAgICAgICAgICAgICAnbm9uZScsXG59XG5cbmV4cG9ydCBjb25zdCBkZXNpcmVkQWNjZXNzaWJpbGl0eU1hcCA9IFtcbiAgJ3JvbGUnLFxuICAndGFiaW5kZXgnLFxuICAnYXJpYS0qJyxcbiAgJ2ZvcicsXG4gICdhbHQnLFxuICAndGl0bGUnLFxuXVxuXG5leHBvcnQgY29uc3QgbGFyZ2VXQ0FHMlRleHRNYXAgPSBbXG4gIHtcbiAgICBmb250U2l6ZTogJzI0cHgnLFxuICAgIGZvbnRXZWlnaHQ6ICcwJ1xuICB9LFxuICB7XG4gICAgZm9udFNpemU6ICcxOC41cHgnLFxuICAgIGZvbnRXZWlnaHQ6ICc3MDAnXG4gIH1cbl0iLCJpbXBvcnQgeyBkZXNpcmVkUHJvcE1hcCB9IGZyb20gJy4vZGVzaWduLXByb3BlcnRpZXMnXG5cbmV4cG9ydCBjb25zdCBnZXRTdHlsZSA9IChlbCwgbmFtZSkgPT4ge1xuICBpZiAoZG9jdW1lbnQuZGVmYXVsdFZpZXcgJiYgZG9jdW1lbnQuZGVmYXVsdFZpZXcuZ2V0Q29tcHV0ZWRTdHlsZSkge1xuICAgIG5hbWUgPSBuYW1lLnJlcGxhY2UoLyhbQS1aXSkvZywgJy0kMScpXG4gICAgbmFtZSA9IG5hbWUudG9Mb3dlckNhc2UoKVxuICAgIGxldCBzID0gZG9jdW1lbnQuZGVmYXVsdFZpZXcuZ2V0Q29tcHV0ZWRTdHlsZShlbCwgJycpXG4gICAgcmV0dXJuIHMgJiYgcy5nZXRQcm9wZXJ0eVZhbHVlKG5hbWUpXG4gIH0gXG59XG5cbmV4cG9ydCBjb25zdCBnZXRTdHlsZXMgPSBlbCA9PiB7XG4gIGNvbnN0IGVsU3R5bGVPYmplY3QgPSBlbC5zdHlsZVxuICBjb25zdCBjb21wdXRlZFN0eWxlID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWwsIG51bGwpXG5cbiAgbGV0IGRlc2lyZWRWYWx1ZXMgPSBbXVxuXG4gIGZvciAocHJvcCBpbiBlbC5zdHlsZSlcbiAgICBpZiAocHJvcCBpbiBkZXNpcmVkUHJvcE1hcCAmJiBkZXNpcmVkUHJvcE1hcFtwcm9wXSAhPSBjb21wdXRlZFN0eWxlW3Byb3BdKVxuICAgICAgZGVzaXJlZFZhbHVlcy5wdXNoKHtcbiAgICAgICAgcHJvcCxcbiAgICAgICAgdmFsdWU6IGNvbXB1dGVkU3R5bGVbcHJvcF0ucmVwbGFjZSgvLCByZ2JhL2csICdcXHJyZ2JhJylcbiAgICAgIH0pXG5cbiAgcmV0dXJuIGRlc2lyZWRWYWx1ZXNcbn1cblxuZXhwb3J0IGNvbnN0IGdldENvbXB1dGVkQmFja2dyb3VuZENvbG9yID0gZWwgPT4ge1xuICBsZXQgYmFja2dyb3VuZCA9IGdldFN0eWxlKGVsLCAnYmFja2dyb3VuZC1jb2xvcicpXG5cbiAgaWYgKGJhY2tncm91bmQgPT09ICdyZ2JhKDAsIDAsIDAsIDApJykge1xuICAgIGxldCBub2RlICA9IGVsLnBhcmVudE5vZGVcbiAgICAgICwgZm91bmQgPSBmYWxzZVxuXG4gICAgd2hpbGUoIWZvdW5kKSB7XG4gICAgICBsZXQgYmcgID0gZ2V0U3R5bGUobm9kZSwgJ2JhY2tncm91bmQtY29sb3InKVxuXG4gICAgICBpZiAoYmcgIT09ICdyZ2JhKDAsIDAsIDAsIDApJykge1xuICAgICAgICBmb3VuZCA9IHRydWVcbiAgICAgICAgYmFja2dyb3VuZCA9IGJnXG4gICAgICB9XG5cbiAgICAgIG5vZGUgPSBub2RlLnBhcmVudE5vZGVcbiAgICB9XG4gIH1cblxuICByZXR1cm4gYmFja2dyb3VuZFxufVxuIiwiaW1wb3J0IHsgZGVzaXJlZEFjY2Vzc2liaWxpdHlNYXAsIGRlc2lyZWRQcm9wTWFwLCBsYXJnZVdDQUcyVGV4dE1hcCB9IGZyb20gJy4vZGVzaWduLXByb3BlcnRpZXMnXG5pbXBvcnQgeyBnZXRTdHlsZXMgfSBmcm9tICcuL3N0eWxlcydcblxuZXhwb3J0IGNvbnN0IGdldEExMXlzID0gZWwgPT4ge1xuICBjb25zdCBlbEF0dHJpYnV0ZXMgPSBlbC5nZXRBdHRyaWJ1dGVOYW1lcygpXG5cbiAgcmV0dXJuIGRlc2lyZWRBY2Nlc3NpYmlsaXR5TWFwLnJlZHVjZSgoYWNjLCBhdHRyaWJ1dGUpID0+IHtcbiAgICBpZiAoZWxBdHRyaWJ1dGVzLmluY2x1ZGVzKGF0dHJpYnV0ZSkpXG4gICAgICBhY2MucHVzaCh7XG4gICAgICAgIHByb3A6ICAgYXR0cmlidXRlLFxuICAgICAgICB2YWx1ZTogIGVsLmdldEF0dHJpYnV0ZShhdHRyaWJ1dGUpXG4gICAgICB9KVxuXG4gICAgaWYgKGF0dHJpYnV0ZSA9PT0gJ2FyaWEtKicpXG4gICAgICBlbEF0dHJpYnV0ZXMuZm9yRWFjaChhdHRyID0+IHtcbiAgICAgICAgaWYgKGF0dHIuaW5jbHVkZXMoJ2FyaWEnKSlcbiAgICAgICAgICBhY2MucHVzaCh7XG4gICAgICAgICAgICBwcm9wOiAgIGF0dHIsXG4gICAgICAgICAgICB2YWx1ZTogIGVsLmdldEF0dHJpYnV0ZShhdHRyKVxuICAgICAgICAgIH0pXG4gICAgICB9KVxuXG4gICAgcmV0dXJuIGFjY1xuICB9LCBbXSlcbn1cblxuZXhwb3J0IGNvbnN0IGdldFdDQUcyVGV4dFNpemUgPSBlbCA9PiB7XG4gIFxuICBjb25zdCBzdHlsZXMgPSBnZXRTdHlsZXMoZWwpLnJlZHVjZSgoc3R5bGVNYXAsIHN0eWxlKSA9PiB7XG4gICAgICBzdHlsZU1hcFtzdHlsZS5wcm9wXSA9IHN0eWxlLnZhbHVlXG4gICAgICByZXR1cm4gc3R5bGVNYXBcbiAgfSwge30pXG5cbiAgY29uc3QgeyBmb250U2l6ZSAgID0gZGVzaXJlZFByb3BNYXAuZm9udFNpemUsXG4gICAgICAgICAgZm9udFdlaWdodCA9IGRlc2lyZWRQcm9wTWFwLmZvbnRXZWlnaHRcbiAgICAgIH0gPSBzdHlsZXNcbiAgXG4gIGNvbnN0IGlzTGFyZ2UgPSBsYXJnZVdDQUcyVGV4dE1hcC5zb21lKFxuICAgIChsYXJnZVByb3BlcnRpZXMpID0+IHBhcnNlRmxvYXQoZm9udFNpemUpID49IHBhcnNlRmxvYXQobGFyZ2VQcm9wZXJ0aWVzLmZvbnRTaXplKSBcbiAgICAgICAmJiBwYXJzZUZsb2F0KGZvbnRXZWlnaHQpID49IHBhcnNlRmxvYXQobGFyZ2VQcm9wZXJ0aWVzLmZvbnRXZWlnaHQpIFxuICApXG5cbiAgcmV0dXJuICBpc0xhcmdlID8gJ0xhcmdlJyA6ICdTbWFsbCdcbn0iLCJleHBvcnQgY29uc3QgY2FtZWxUb0Rhc2ggPSAoY2FtZWxTdHJpbmcgPSBcIlwiKSA9PlxuICBjYW1lbFN0cmluZy5yZXBsYWNlKC8oW0EtWl0pL2csICgkMSkgPT5cbiAgICBcIi1cIiskMS50b0xvd2VyQ2FzZSgpKVxuXG5leHBvcnQgY29uc3Qgbm9kZUtleSA9IG5vZGUgPT4ge1xuICBsZXQgdHJlZSA9IFtdXG4gIGxldCBmdXJ0aGVzdF9sZWFmID0gbm9kZVxuXG4gIHdoaWxlIChmdXJ0aGVzdF9sZWFmKSB7XG4gICAgdHJlZS5wdXNoKGZ1cnRoZXN0X2xlYWYpXG4gICAgZnVydGhlc3RfbGVhZiA9IGZ1cnRoZXN0X2xlYWYucGFyZW50Tm9kZVxuICAgICAgPyBmdXJ0aGVzdF9sZWFmLnBhcmVudE5vZGVcbiAgICAgIDogZmFsc2VcbiAgfVxuXG4gIHJldHVybiB0cmVlLnJlZHVjZSgocGF0aCwgYnJhbmNoKSA9PiBgXG4gICAgJHtwYXRofSR7YnJhbmNoLnRhZ05hbWV9XyR7YnJhbmNoLmNsYXNzTmFtZX1fJHtbLi4ubm9kZS5wYXJlbnROb2RlLmNoaWxkcmVuXS5pbmRleE9mKG5vZGUpfV8ke25vZGUuY2hpbGRyZW4ubGVuZ3RofVxuICBgLCAnJylcbn1cblxuZXhwb3J0IGNvbnN0IGNyZWF0ZUNsYXNzbmFtZSA9IChlbCwgZWxsaXBzZSA9IGZhbHNlKSA9PiB7XG4gIGlmICghZWwuY2xhc3NOYW1lIHx8IGVsLm5vZGVOYW1lID09PSAnc3ZnJyB8fCBlbC5vd25lclNWR0VsZW1lbnQpIHJldHVybiAnJ1xuICBsZXQgcmF3Q2xhc3NuYW1lID0gJy4nICsgZWwuY2xhc3NOYW1lLnJlcGxhY2UoLyAvZywgJy4nKVxuXG4gIHJldHVybiBlbGxpcHNlICYmIHJhd0NsYXNzbmFtZS5sZW5ndGggPiAzMFxuICAgID8gcmF3Q2xhc3NuYW1lLnN1YnN0cmluZygwLDMwKSArICcuLi4nXG4gICAgOiByYXdDbGFzc25hbWVcbn1cblxuZXhwb3J0IGNvbnN0IG1ldGFLZXkgPSB3aW5kb3cubmF2aWdhdG9yLnBsYXRmb3JtLmluY2x1ZGVzKCdNYWMnKVxuICA/ICdjbWQnXG4gIDogJ2N0cmwnXG5cbmV4cG9ydCBjb25zdCBhbHRLZXkgPSB3aW5kb3cubmF2aWdhdG9yLnBsYXRmb3JtLmluY2x1ZGVzKCdNYWMnKVxuICA/ICdvcHQnXG4gIDogJ2FsdCdcbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCB7IG5vZGVLZXkgfSBmcm9tICcuL3N0cmluZ3MnXG5cbmV4cG9ydCBjb25zdCBnZXRTaWRlID0gZGlyZWN0aW9uID0+IHtcbiAgbGV0IHN0YXJ0ID0gZGlyZWN0aW9uLnNwbGl0KCcrJykucG9wKCkucmVwbGFjZSgvXlxcdy8sIGMgPT4gYy50b1VwcGVyQ2FzZSgpKVxuICBpZiAoc3RhcnQgPT0gJ1VwJykgc3RhcnQgPSAnVG9wJ1xuICBpZiAoc3RhcnQgPT0gJ0Rvd24nKSBzdGFydCA9ICdCb3R0b20nXG4gIHJldHVybiBzdGFydFxufVxuXG5leHBvcnQgY29uc3QgZ2V0Tm9kZUluZGV4ID0gZWwgPT4ge1xuICByZXR1cm4gWy4uLmVsLnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5jaGlsZHJlbl1cbiAgICAuaW5kZXhPZihlbC5wYXJlbnRFbGVtZW50KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gc2hvd0VkZ2UoZWwpIHtcbiAgcmV0dXJuIGVsLmFuaW1hdGUoW1xuICAgIHsgb3V0bGluZTogJzFweCBzb2xpZCB0cmFuc3BhcmVudCcgfSxcbiAgICB7IG91dGxpbmU6ICcxcHggc29saWQgaHNsYSgzMzAsIDEwMCUsIDcxJSwgODAlKScgfSxcbiAgICB7IG91dGxpbmU6ICcxcHggc29saWQgdHJhbnNwYXJlbnQnIH0sXG4gIF0sIDYwMClcbn1cblxubGV0IHRpbWVvdXRNYXAgPSB7fVxuZXhwb3J0IGNvbnN0IHNob3dIaWRlU2VsZWN0ZWQgPSAoZWwsIGR1cmF0aW9uID0gNzUwKSA9PiB7XG4gIGVsLnNldEF0dHJpYnV0ZSgnZGF0YS1zZWxlY3RlZC1oaWRlJywgdHJ1ZSlcbiAgc2hvd0hpZGVOb2RlTGFiZWwoZWwsIHRydWUpXG5cbiAgaWYgKHRpbWVvdXRNYXBbbm9kZUtleShlbCldKSBcbiAgICBjbGVhclRpbWVvdXQodGltZW91dE1hcFtub2RlS2V5KGVsKV0pXG5cbiAgdGltZW91dE1hcFtub2RlS2V5KGVsKV0gPSBzZXRUaW1lb3V0KF8gPT4ge1xuICAgIGVsLnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1zZWxlY3RlZC1oaWRlJylcbiAgICBzaG93SGlkZU5vZGVMYWJlbChlbCwgZmFsc2UpXG4gIH0sIGR1cmF0aW9uKVxuICBcbiAgcmV0dXJuIGVsXG59XG5cbmV4cG9ydCBjb25zdCBzaG93SGlkZU5vZGVMYWJlbCA9IChlbCwgc2hvdyA9IGZhbHNlKSA9PiB7XG4gIGlmICghZWwuaGFzQXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJykpIFxuICAgIHJldHVyblxuXG4gIGNvbnN0IG5vZGVzID0gJChgXG4gICAgcGItbGFiZWxbZGF0YS1sYWJlbC1pZD1cIiR7ZWwuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJyl9XCJdLFxuICAgIHBiLWhhbmRsZXNbZGF0YS1sYWJlbC1pZD1cIiR7ZWwuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJyl9XCJdXG4gIGApXG5cbiAgbm9kZXMubGVuZ3RoICYmIHNob3dcbiAgICA/IG5vZGVzLmZvckVhY2goZWwgPT5cbiAgICAgIGVsLnN0eWxlLmRpc3BsYXkgPSAnbm9uZScpXG4gICAgOiBub2Rlcy5mb3JFYWNoKGVsID0+XG4gICAgICBlbC5zdHlsZS5kaXNwbGF5ID0gbnVsbClcbn1cblxuZXhwb3J0IGNvbnN0IGh0bWxTdHJpbmdUb0RvbSA9IChodG1sU3RyaW5nID0gXCJcIikgPT5cbiAgKG5ldyBET01QYXJzZXIoKS5wYXJzZUZyb21TdHJpbmcoaHRtbFN0cmluZywgJ3RleHQvaHRtbCcpKVxuICAgIC5ib2R5LmZpcnN0Q2hpbGRcblxuZXhwb3J0IGNvbnN0IGlzT2ZmQm91bmRzID0gbm9kZSA9PlxuICBub2RlLmNsb3Nlc3QgJiZcbiAgKG5vZGUuY2xvc2VzdCgndG9vbC1wYWxsZXRlJykgXG4gIHx8IG5vZGUuY2xvc2VzdCgnaG90a2V5LW1hcCcpXG4gIHx8IG5vZGUuY2xvc2VzdCgncGItbWV0YXRpcCcpXG4gIHx8IG5vZGUuY2xvc2VzdCgncGItYWxseScpXG4gIHx8IG5vZGUuY2xvc2VzdCgncGItbGFiZWwnKVxuICB8fCBub2RlLmNsb3Nlc3QoJ3BiLWhhbmRsZXMnKVxuICB8fCBub2RlLmNsb3Nlc3QoJ3BiLWdyaWRsaW5lcycpXG4gICkiLCJleHBvcnQgZnVuY3Rpb24gd2luZG93Qm91bmRzKCkge1xuICBjb25zdCBoZWlnaHQgID0gd2luZG93LmlubmVySGVpZ2h0XG4gIGNvbnN0IHdpZHRoICAgPSB3aW5kb3cuaW5uZXJXaWR0aFxuICBjb25zdCBib2R5ICAgID0gZG9jdW1lbnQuYm9keS5jbGllbnRXaWR0aFxuXG4gIGNvbnN0IGNhbGNXaWR0aCA9IGJvZHkgPD0gd2lkdGhcbiAgICA/IGJvZHlcbiAgICA6IHdpZHRoXG5cbiAgcmV0dXJuIHtcbiAgICB3aW5IZWlnaHQ6IGhlaWdodCxcbiAgICB3aW5XaWR0aDogIGNhbGNXaWR0aCxcbiAgfVxufVxuIiwiaW1wb3J0IHsgd2luZG93Qm91bmRzIH0gZnJvbSAnLi4vLi4vdXRpbGl0aWVzLydcblxuZXhwb3J0IGNsYXNzIEdyaWRsaW5lcyBleHRlbmRzIEhUTUxFbGVtZW50IHtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG4gICAgdGhpcy4kc2hhZG93ID0gdGhpcy5hdHRhY2hTaGFkb3coe21vZGU6ICdvcGVuJ30pXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG4gIGRpc2Nvbm5lY3RlZENhbGxiYWNrKCkge31cblxuICBzZXQgcG9zaXRpb24oYm91bmRpbmdSZWN0KSB7XG4gICAgdGhpcy4kc2hhZG93LmlubmVySFRNTCAgPSB0aGlzLnJlbmRlcihib3VuZGluZ1JlY3QpXG4gIH1cblxuICBzZXQgdXBkYXRlKHsgd2lkdGgsIGhlaWdodCwgdG9wLCBsZWZ0IH0pIHtcbiAgICBjb25zdCB7IHdpbkhlaWdodCwgd2luV2lkdGggfSA9IHdpbmRvd0JvdW5kcygpXG5cbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJ1xuICAgIGNvbnN0IHN2ZyA9IHRoaXMuJHNoYWRvdy5jaGlsZHJlblsxXVxuXG4gICAgc3ZnLnNldEF0dHJpYnV0ZSgndmlld0JveCcsIGAwIDAgJHt3aW5XaWR0aH0gJHt3aW5IZWlnaHR9YClcbiAgICBzdmcuY2hpbGRyZW5bMF0uc2V0QXR0cmlidXRlKCd3aWR0aCcsIHdpZHRoICsgJ3B4JylcbiAgICBzdmcuY2hpbGRyZW5bMF0uc2V0QXR0cmlidXRlKCdoZWlnaHQnLCBoZWlnaHQgKyAncHgnKVxuICAgIHN2Zy5jaGlsZHJlblswXS5zZXRBdHRyaWJ1dGUoJ3gnLCBsZWZ0KVxuICAgIHN2Zy5jaGlsZHJlblswXS5zZXRBdHRyaWJ1dGUoJ3knLCB0b3ApXG4gICAgc3ZnLmNoaWxkcmVuWzFdLnNldEF0dHJpYnV0ZSgneDEnLCBsZWZ0KVxuICAgIHN2Zy5jaGlsZHJlblsxXS5zZXRBdHRyaWJ1dGUoJ3gyJywgbGVmdClcbiAgICBzdmcuY2hpbGRyZW5bMl0uc2V0QXR0cmlidXRlKCd4MScsIGxlZnQgKyB3aWR0aClcbiAgICBzdmcuY2hpbGRyZW5bMl0uc2V0QXR0cmlidXRlKCd4MicsIGxlZnQgKyB3aWR0aClcbiAgICBzdmcuY2hpbGRyZW5bM10uc2V0QXR0cmlidXRlKCd5MScsIHRvcClcbiAgICBzdmcuY2hpbGRyZW5bM10uc2V0QXR0cmlidXRlKCd5MicsIHRvcClcbiAgICBzdmcuY2hpbGRyZW5bM10uc2V0QXR0cmlidXRlKCd4MicsIHdpbldpZHRoKVxuICAgIHN2Zy5jaGlsZHJlbls0XS5zZXRBdHRyaWJ1dGUoJ3kxJywgdG9wICsgaGVpZ2h0KVxuICAgIHN2Zy5jaGlsZHJlbls0XS5zZXRBdHRyaWJ1dGUoJ3kyJywgdG9wICsgaGVpZ2h0KVxuICAgIHN2Zy5jaGlsZHJlbls0XS5zZXRBdHRyaWJ1dGUoJ3gyJywgd2luV2lkdGgpXG4gIH1cblxuICByZW5kZXIoeyB4LCB5LCB3aWR0aCwgaGVpZ2h0LCB0b3AsIGxlZnQgfSkge1xuICAgIGNvbnN0IHsgd2luSGVpZ2h0LCB3aW5XaWR0aCB9ID0gd2luZG93Qm91bmRzKClcblxuICAgIHJldHVybiBgXG4gICAgICAke3RoaXMuc3R5bGVzKHt0b3AsbGVmdH0pfVxuICAgICAgPHN2Z1xuICAgICAgICB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCJcbiAgICAgICAgdmlld0JveD1cIjAgMCAke3dpbldpZHRofSAke3dpbkhlaWdodH1cIlxuICAgICAgICB2ZXJzaW9uPVwiMS4xXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgICA+XG4gICAgICAgIDxyZWN0XG4gICAgICAgICAgc3Ryb2tlPVwiaG90cGlua1wiIGZpbGw9XCJub25lXCJcbiAgICAgICAgICB3aWR0aD1cIiR7d2lkdGh9XCIgaGVpZ2h0PVwiJHtoZWlnaHR9XCJcbiAgICAgICAgICB4PVwiJHt4fVwiIHk9XCIke3l9XCJcbiAgICAgICAgICBzdHlsZT1cImRpc3BsYXk6bm9uZTtcIlxuICAgICAgICA+PC9yZWN0PlxuICAgICAgICA8bGluZSB4MT1cIiR7eH1cIiB5MT1cIjBcIiB4Mj1cIiR7eH1cIiB5Mj1cIiR7d2luSGVpZ2h0fVwiIHN0cm9rZT1cImhvdHBpbmtcIiBzdHJva2UtZGFzaGFycmF5PVwiMlwiIHN0cm9rZS1kYXNob2Zmc2V0PVwiM1wiPjwvbGluZT5cbiAgICAgICAgPGxpbmUgeDE9XCIke3ggKyB3aWR0aH1cIiB5MT1cIjBcIiB4Mj1cIiR7eCArIHdpZHRofVwiIHkyPVwiJHt3aW5IZWlnaHR9XCIgc3Ryb2tlPVwiaG90cGlua1wiIHN0cm9rZS1kYXNoYXJyYXk9XCIyXCIgc3Ryb2tlLWRhc2hvZmZzZXQ9XCIzXCI+PC9saW5lPlxuICAgICAgICA8bGluZSB4MT1cIjBcIiB5MT1cIiR7eX1cIiB4Mj1cIiR7d2luV2lkdGh9XCIgeTI9XCIke3l9XCIgc3Ryb2tlPVwiaG90cGlua1wiIHN0cm9rZS1kYXNoYXJyYXk9XCIyXCIgc3Ryb2tlLWRhc2hvZmZzZXQ9XCIzXCI+PC9saW5lPlxuICAgICAgICA8bGluZSB4MT1cIjBcIiB5MT1cIiR7eSArIGhlaWdodH1cIiB4Mj1cIiR7d2luV2lkdGh9XCIgeTI9XCIke3kgKyBoZWlnaHR9XCIgc3Ryb2tlPVwiaG90cGlua1wiIHN0cm9rZS1kYXNoYXJyYXk9XCIyXCIgc3Ryb2tlLWRhc2hvZmZzZXQ9XCIzXCI+PC9saW5lPlxuICAgICAgPC9zdmc+XG4gICAgYFxuICB9XG5cbiAgc3R5bGVzKHt0b3AsbGVmdH0pIHtcbiAgICByZXR1cm4gYFxuICAgICAgPHN0eWxlPlxuICAgICAgICA6aG9zdCA+IHN2ZyB7XG4gICAgICAgICAgcG9zaXRpb246Zml4ZWQ7XG4gICAgICAgICAgdG9wOjA7XG4gICAgICAgICAgbGVmdDowO1xuICAgICAgICAgIG92ZXJmbG93OnZpc2libGU7XG4gICAgICAgICAgcG9pbnRlci1ldmVudHM6bm9uZTtcbiAgICAgICAgICB6LWluZGV4Ojk5OTc7XG4gICAgICAgIH1cbiAgICAgIDwvc3R5bGU+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgncGItZ3JpZGxpbmVzJywgR3JpZGxpbmVzKVxuIiwiZXhwb3J0IGNsYXNzIE92ZXJsYXkgZXh0ZW5kcyBIVE1MRWxlbWVudCB7XG4gIFxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG4gICAgdGhpcy4kc2hhZG93ID0gdGhpcy5hdHRhY2hTaGFkb3coe21vZGU6ICdvcGVuJ30pXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG4gIGRpc2Nvbm5lY3RlZENhbGxiYWNrKCkge31cblxuICBzZXQgcG9zaXRpb24oYm91bmRpbmdSZWN0KSB7XG4gICAgdGhpcy4kc2hhZG93LmlubmVySFRNTCAgPSB0aGlzLnJlbmRlcihib3VuZGluZ1JlY3QpXG4gIH1cblxuICBzZXQgdXBkYXRlKHsgdG9wLCBsZWZ0LCB3aWR0aCwgaGVpZ2h0IH0pIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJ1xuXG4gICAgY29uc3Qgc3ZnID0gdGhpcy4kc2hhZG93LmNoaWxkcmVuWzBdXG4gICAgc3ZnLnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snXG4gICAgc3ZnLnN0eWxlLnRvcCA9IHdpbmRvdy5zY3JvbGxZICsgdG9wICsgJ3B4J1xuICAgIHN2Zy5zdHlsZS5sZWZ0ID0gbGVmdCArICdweCdcblxuICAgIHN2Zy5zZXRBdHRyaWJ1dGUoJ3dpZHRoJywgd2lkdGggKyAncHgnKVxuICAgIHN2Zy5zZXRBdHRyaWJ1dGUoJ2hlaWdodCcsIGhlaWdodCArICdweCcpXG4gIH1cblxuICByZW5kZXIoe2lkLCB0b3AsIGxlZnQsIGhlaWdodCwgd2lkdGh9KSB7XG4gICAgcmV0dXJuIGBcbiAgICAgIDxzdmcgXG4gICAgICAgIGNsYXNzPVwicGItb3ZlcmxheVwiXG4gICAgICAgIG92ZXJsYXktaWQ9XCIke2lkfVwiXG4gICAgICAgIHN0eWxlPVwiXG4gICAgICAgICAgZGlzcGxheTpub25lO1xuICAgICAgICAgIHBvc2l0aW9uOmFic29sdXRlO1xuICAgICAgICAgIHRvcDowO1xuICAgICAgICAgIGxlZnQ6MDtcbiAgICAgICAgICBvdmVyZmxvdzp2aXNpYmxlO1xuICAgICAgICAgIHBvaW50ZXItZXZlbnRzOm5vbmU7XG4gICAgICAgICAgei1pbmRleDogOTk5O1xuICAgICAgICBcIiBcbiAgICAgICAgd2lkdGg9XCIke3dpZHRofXB4XCIgaGVpZ2h0PVwiJHtoZWlnaHR9cHhcIiBcbiAgICAgICAgdmlld0JveD1cIjAgMCAke3dpZHRofSAke2hlaWdodH1cIiBcbiAgICAgICAgdmVyc2lvbj1cIjEuMVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgPlxuICAgICAgICA8cmVjdCBcbiAgICAgICAgICBmaWxsPVwiaHNsYSgzMzAsIDEwMCUsIDcxJSwgMC41KVwiXG4gICAgICAgICAgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiXG4gICAgICAgID48L3JlY3Q+XG4gICAgICA8L3N2Zz5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdwYi1vdmVybGF5JywgT3ZlcmxheSkiLCJpbXBvcnQgJCBmcm9tICdibGluZ2JsaW5nanMnXG5pbXBvcnQgeyBjcmVhdGVDbGFzc25hbWUgfSBmcm9tICcuLi8uLi91dGlsaXRpZXMvJ1xuaW1wb3J0IHN0eWxlcyBmcm9tICcuL21ldGF0aXAuZWxlbWVudC5jc3MnXG5cbmV4cG9ydCBjbGFzcyBNZXRhdGlwIGV4dGVuZHMgSFRNTEVsZW1lbnQge1xuICBcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuICAgIHRoaXMuJHNoYWRvdyA9IHRoaXMuYXR0YWNoU2hhZG93KHttb2RlOiAnb3Blbid9KVxuICB9XG5cbiAgY29ubmVjdGVkQ2FsbGJhY2soKSB7XG4gICAgJCgnaDUgPiBhJywgdGhpcy4kc2hhZG93KS5vbignY2xpY2sgbW91c2VlbnRlcicsIHRoaXMuZGlzcGF0Y2hRdWVyeS5iaW5kKHRoaXMpKVxuICAgICQoJ2g1ID4gYScsIHRoaXMuJHNoYWRvdykub24oJ21vdXNlbGVhdmUnLCB0aGlzLmRpc3BhdGNoVW5RdWVyeS5iaW5kKHRoaXMpKVxuICB9XG5cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7XG4gICAgJCgnaDUgPiBhJywgdGhpcy4kc2hhZG93KS5vZmYoJ2NsaWNrJywgdGhpcy5kaXNwYXRjaFF1ZXJ5KVxuICB9XG5cbiAgZGlzcGF0Y2hRdWVyeShlKSB7XG4gICAgdGhpcy4kc2hhZG93Lmhvc3QuZGlzcGF0Y2hFdmVudChuZXcgQ3VzdG9tRXZlbnQoJ3F1ZXJ5Jywge1xuICAgICAgYnViYmxlczogdHJ1ZSxcbiAgICAgIGRldGFpbDogICB7XG4gICAgICAgIHRleHQ6ICAgICAgIGUudGFyZ2V0LnRleHRDb250ZW50LFxuICAgICAgICBhY3RpdmF0b3I6ICBlLnR5cGUsXG4gICAgICB9XG4gICAgfSkpXG4gIH1cblxuICBkaXNwYXRjaFVuUXVlcnkoZSkge1xuICAgIHRoaXMuJHNoYWRvdy5ob3N0LmRpc3BhdGNoRXZlbnQobmV3IEN1c3RvbUV2ZW50KCd1bnF1ZXJ5Jywge1xuICAgICAgYnViYmxlczogdHJ1ZVxuICAgIH0pKVxuICB9XG5cbiAgc2V0IG1ldGEoZGF0YSkge1xuICAgIHRoaXMuJHNoYWRvdy5pbm5lckhUTUwgPSB0aGlzLnJlbmRlcihkYXRhKVxuICB9XG5cbiAgcmVuZGVyKHtlbCwgd2lkdGgsIGhlaWdodCwgbG9jYWxNb2RpZmljYXRpb25zLCBub3RMb2NhbE1vZGlmaWNhdGlvbnN9KSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxmaWd1cmU+XG4gICAgICAgIDxoNT5cbiAgICAgICAgICA8YSBocmVmPVwiI1wiPiR7ZWwubm9kZU5hbWUudG9Mb3dlckNhc2UoKX08L2E+XG4gICAgICAgICAgPGEgaHJlZj1cIiNcIj4ke2VsLmlkICYmICcjJyArIGVsLmlkfTwvYT5cbiAgICAgICAgICAke2NyZWF0ZUNsYXNzbmFtZShlbCkuc3BsaXQoJy4nKVxuICAgICAgICAgICAgLmZpbHRlcihuYW1lID0+IG5hbWUgIT0gJycpXG4gICAgICAgICAgICAucmVkdWNlKChsaW5rcywgbmFtZSkgPT4gYFxuICAgICAgICAgICAgICAke2xpbmtzfVxuICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiPi4ke25hbWV9PC9hPlxuICAgICAgICAgICAgYCwgJycpXG4gICAgICAgICAgfVxuICAgICAgICA8L2g1PlxuICAgICAgICA8c21hbGw+XG4gICAgICAgICAgPHNwYW5cIj4ke01hdGgucm91bmQod2lkdGgpfTwvc3Bhbj5weCBcbiAgICAgICAgICA8c3BhbiBkaXZpZGVyPsOXPC9zcGFuPiBcbiAgICAgICAgICA8c3Bhbj4ke01hdGgucm91bmQoaGVpZ2h0KX08L3NwYW4+cHhcbiAgICAgICAgPC9zbWFsbD5cbiAgICAgICAgPGRpdj4ke25vdExvY2FsTW9kaWZpY2F0aW9ucy5yZWR1Y2UoKGl0ZW1zLCBpdGVtKSA9PiBgXG4gICAgICAgICAgJHtpdGVtc31cbiAgICAgICAgICA8c3BhbiBwcm9wPiR7aXRlbS5wcm9wfTo8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gdmFsdWU+JHtpdGVtLnZhbHVlfTwvc3Bhbj5cbiAgICAgICAgYCwgJycpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgJHtsb2NhbE1vZGlmaWNhdGlvbnMubGVuZ3RoID8gYFxuICAgICAgICAgIDxoNiBsb2NhbC1tb2RpZmljYXRpb25zPkxvY2FsIE1vZGlmaWNhdGlvbnM8L2g2PlxuICAgICAgICAgIDxkaXY+JHtsb2NhbE1vZGlmaWNhdGlvbnMucmVkdWNlKChpdGVtcywgaXRlbSkgPT4gYFxuICAgICAgICAgICAgJHtpdGVtc31cbiAgICAgICAgICAgIDxzcGFuIHByb3A+JHtpdGVtLnByb3B9Ojwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIHZhbHVlPiR7aXRlbS52YWx1ZX08L3NwYW4+XG4gICAgICAgICAgYCwgJycpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICBgIDogJyd9XG4gICAgICA8L2ZpZ3VyZT5cbiAgICBgXG4gIH1cblxuICBzdHlsZXMoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgIDxzdHlsZT5cbiAgICAgICAgJHtzdHlsZXN9XG4gICAgICA8L3N0eWxlPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ3BiLW1ldGF0aXAnLCBNZXRhdGlwKSIsImltcG9ydCB7IE1ldGF0aXAgfSBmcm9tICcuL21ldGF0aXAuZWxlbWVudC5qcydcblxuZXhwb3J0IGNsYXNzIEFsbHkgZXh0ZW5kcyBNZXRhdGlwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuICB9XG4gIFxuICByZW5kZXIoe2VsLCBhbGx5X2F0dHJpYnV0ZXMsIGNvbnRyYXN0X3Jlc3VsdHN9KSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxmaWd1cmU+XG4gICAgICAgIDxoNT4ke2VsLm5vZGVOYW1lLnRvTG93ZXJDYXNlKCl9JHtlbC5pZCAmJiAnIycgKyBlbC5pZH08L2g1PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgICR7YWxseV9hdHRyaWJ1dGVzLnJlZHVjZSgoaXRlbXMsIGF0dHIpID0+IGBcbiAgICAgICAgICAgICR7aXRlbXN9XG4gICAgICAgICAgICA8c3BhbiBwcm9wPiR7YXR0ci5wcm9wfTo8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiB2YWx1ZT4ke2F0dHIudmFsdWV9PC9zcGFuPlxuICAgICAgICAgIGAsICcnKX1cbiAgICAgICAgICAke2NvbnRyYXN0X3Jlc3VsdHN9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9maWd1cmU+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgncGItYWxseScsIEFsbHkpIiwiZXhwb3J0IGNvbnN0IGN1cnNvciA9IGBcbiAgPHN2ZyBjbGFzcz1cImljb24tY3Vyc29yXCIgdmVyc2lvbj1cIjEuMVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDMyIDMyXCI+XG4gICAgPHBhdGggZD1cIk0xNi42ODkgMTcuNjU1bDUuMzExIDEyLjM0NS00IDItNC42NDYtMTIuNjc4LTcuMzU0IDYuNjc4di0yNmwyMCAxNi05LjMxMSAxLjY1NXpcIj48L3BhdGg+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgbW92ZSA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNMTUgNy41VjJIOXY1LjVsMyAzIDMtM3pNNy41IDlIMnY2aDUuNWwzLTMtMy0zek05IDE2LjVWMjJoNnYtNS41bC0zLTMtMyAzek0xNi41IDlsLTMgMyAzIDNIMjJWOWgtNS41elwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBzZWFyY2ggPSBgXG4gIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICA8cGF0aCBkPVwiTTE1LjUgMTRoLS43OWwtLjI4LS4yN0MxNS40MSAxMi41OSAxNiAxMS4xMSAxNiA5LjUgMTYgNS45MSAxMy4wOSAzIDkuNSAzUzMgNS45MSAzIDkuNSA1LjkxIDE2IDkuNSAxNmMxLjYxIDAgMy4wOS0uNTkgNC4yMy0xLjU3bC4yNy4yOHYuNzlsNSA0Ljk5TDIwLjQ5IDE5bC00Ljk5LTV6bS02IDBDNy4wMSAxNCA1IDExLjk5IDUgOS41UzcuMDEgNSA5LjUgNSAxNCA3LjAxIDE0IDkuNSAxMS45OSAxNCA5LjUgMTR6XCIvPlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IG1hcmdpbiA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNOSA3SDd2MmgyVjd6bTAgNEg3djJoMnYtMnptMC04Yy0xLjExIDAtMiAuOS0yIDJoMlYzem00IDEyaC0ydjJoMnYtMnptNi0xMnYyaDJjMC0xLjEtLjktMi0yLTJ6bS02IDBoLTJ2MmgyVjN6TTkgMTd2LTJIN2MwIDEuMS44OSAyIDIgMnptMTAtNGgydi0yaC0ydjJ6bTAtNGgyVjdoLTJ2MnptMCA4YzEuMSAwIDItLjkgMi0yaC0ydjJ6TTUgN0gzdjEyYzAgMS4xLjg5IDIgMiAyaDEydi0ySDVWN3ptMTAtMmgyVjNoLTJ2MnptMCAxMmgydi0yaC0ydjJ6XCIvPlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IHBhZGRpbmcgPSBgXG4gIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICA8cGF0aCBkPVwiTTMgMTNoMnYtMkgzdjJ6bTAgNGgydi0ySDN2MnptMiA0di0ySDNjMCAxLjEuODkgMiAyIDJ6TTMgOWgyVjdIM3Yyem0xMiAxMmgydi0yaC0ydjJ6bTQtMThIOWMtMS4xMSAwLTIgLjktMiAydjEwYzAgMS4xLjg5IDIgMiAyaDEwYzEuMSAwIDItLjkgMi0yVjVjMC0xLjEtLjktMi0yLTJ6bTAgMTJIOVY1aDEwdjEwem0tOCA2aDJ2LTJoLTJ2MnptLTQgMGgydi0ySDd2MnpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgZm9udCA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNOSA0djNoNXYxMmgzVjdoNVY0SDl6bS02IDhoM3Y3aDN2LTdoM1Y5SDN2M3pcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgdGV4dCA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNMyAxNy4yNVYyMWgzLjc1TDE3LjgxIDkuOTRsLTMuNzUtMy43NUwzIDE3LjI1ek0yMC43MSA3LjA0Yy4zOS0uMzkuMzktMS4wMiAwLTEuNDFsLTIuMzQtMi4zNGMtLjM5LS4zOS0xLjAyLS4zOS0xLjQxIDBsLTEuODMgMS44MyAzLjc1IDMuNzUgMS44My0xLjgzelwiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBhbGlnbiA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0eWxlPVwidHJhbnNmb3JtOnJvdGF0ZVooOTBkZWcpO1wiPlxuICAgIDxwYXRoIGQ9XCJNMTAgMjBoNFY0aC00djE2em0tNiAwaDR2LThINHY4ek0xNiA5djExaDRWOWgtNHpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgcmVzaXplID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk0xOSAxMmgtMnYzaC0zdjJoNXYtNXpNNyA5aDNWN0g1djVoMlY5em0xNC02SDNjLTEuMSAwLTIgLjktMiAydjE0YzAgMS4xLjkgMiAyIDJoMThjMS4xIDAgMi0uOSAyLTJWNWMwLTEuMS0uOS0yLTItMnptMCAxNi4wMUgzVjQuOTloMTh2MTQuMDJ6XCIvPlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IHRyYW5zZm9ybSA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNMTIsN0M2LjQ4LDcsMiw5LjI0LDIsMTJjMCwyLjI0LDIuOTQsNC4xMyw3LDQuNzdWMjBsNC00bC00LTR2Mi43M2MtMy4xNS0wLjU2LTUtMS45LTUtMi43M2MwLTEuMDYsMy4wNC0zLDgtM3M4LDEuOTQsOCwzXG4gICAgYzAsMC43My0xLjQ2LDEuODktNCwyLjUzdjIuMDVjMy41My0wLjc3LDYtMi41Myw2LTQuNThDMjIsOS4yNCwxNy41Miw3LDEyLDd6XCIvPlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IGJvcmRlciA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxwYXRoIGQ9XCJNMTMgN2gtMnYyaDJWN3ptMCA0aC0ydjJoMnYtMnptNCAwaC0ydjJoMnYtMnpNMyAzdjE4aDE4VjNIM3ptMTYgMTZINVY1aDE0djE0em0tNi00aC0ydjJoMnYtMnptLTQtNEg3djJoMnYtMnpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgaHVlc2hpZnQgPSBgXG4gIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICA8cGF0aCBkPVwiTTEyIDNjLTQuOTcgMC05IDQuMDMtOSA5czQuMDMgOSA5IDljLjgzIDAgMS41LS42NyAxLjUtMS41IDAtLjM5LS4xNS0uNzQtLjM5LTEuMDEtLjIzLS4yNi0uMzgtLjYxLS4zOC0uOTkgMC0uODMuNjctMS41IDEuNS0xLjVIMTZjMi43NiAwIDUtMi4yNCA1LTUgMC00LjQyLTQuMDMtOC05LTh6bS01LjUgOWMtLjgzIDAtMS41LS42Ny0xLjUtMS41UzUuNjcgOSA2LjUgOSA4IDkuNjcgOCAxMC41IDcuMzMgMTIgNi41IDEyem0zLTRDOC42NyA4IDggNy4zMyA4IDYuNVM4LjY3IDUgOS41IDVzMS41LjY3IDEuNSAxLjVTMTAuMzMgOCA5LjUgOHptNSAwYy0uODMgMC0xLjUtLjY3LTEuNS0xLjVTMTMuNjcgNSAxNC41IDVzMS41LjY3IDEuNSAxLjVTMTUuMzMgOCAxNC41IDh6bTMgNGMtLjgzIDAtMS41LS42Ny0xLjUtMS41UzE2LjY3IDkgMTcuNSA5czEuNS42NyAxLjUgMS41LS42NyAxLjUtMS41IDEuNXpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgYm94c2hhZG93ID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk0yMCA4LjY5VjRoLTQuNjlMMTIgLjY5IDguNjkgNEg0djQuNjlMLjY5IDEyIDQgMTUuMzFWMjBoNC42OUwxMiAyMy4zMSAxNS4zMSAyMEgyMHYtNC42OUwyMy4zMSAxMiAyMCA4LjY5ek0xMiAxOGMtLjg5IDAtMS43NC0uMi0yLjUtLjU1QzExLjU2IDE2LjUgMTMgMTQuNDIgMTMgMTJzLTEuNDQtNC41LTMuNS01LjQ1QzEwLjI2IDYuMiAxMS4xMSA2IDEyIDZjMy4zMSAwIDYgMi42OSA2IDZzLTIuNjkgNi02IDZ6XCIvPlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IGluc3BlY3RvciA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxnPlxuICAgICAgPHJlY3QgeD1cIjExXCIgeT1cIjdcIiB3aWR0aD1cIjJcIiBoZWlnaHQ9XCIyXCIvPlxuICAgICAgPHJlY3QgeD1cIjExXCIgeT1cIjExXCIgd2lkdGg9XCIyXCIgaGVpZ2h0PVwiNlwiLz5cbiAgICAgIDxwYXRoIGQ9XCJNMTIsMkM2LjQ4LDIsMiw2LjQ4LDIsMTJjMCw1LjUyLDQuNDgsMTAsMTAsMTBzMTAtNC40OCwxMC0xMEMyMiw2LjQ4LDE3LjUyLDIsMTIsMnogTTEyLDIwYy00LjQxLDAtOC0zLjU5LTgtOFxuICAgICAgICBjMC00LjQxLDMuNTktOCw4LThzOCwzLjU5LDgsOEMyMCwxNi40MSwxNi40MSwyMCwxMiwyMHpcIi8+XG4gICAgPC9nPlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IGNhbWVyYSA9IGBcbiAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiMy4yXCIvPlxuICAgIDxwYXRoIGQ9XCJNOSAyTDcuMTcgNEg0Yy0xLjEgMC0yIC45LTIgMnYxMmMwIDEuMS45IDIgMiAyaDE2YzEuMSAwIDItLjkgMi0yVjZjMC0xLjEtLjktMi0yLTJoLTMuMTdMMTUgMkg5em0zIDE1Yy0yLjc2IDAtNS0yLjI0LTUtNXMyLjI0LTUgNS01IDUgMi4yNCA1IDUtMi4yNCA1LTUgNXpcIi8+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgZ3VpZGVzID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk0yMSw2SDNDMS45LDYsMSw2LjksMSw4djhjMCwxLjEsMC45LDIsMiwyaDE4YzEuMSwwLDItMC45LDItMlY4QzIzLDYuOSwyMi4xLDYsMjEsNnogTTIxLDE2SDNWOGgydjRoMlY4aDJ2NGgyVjhoMnY0aDJWOFxuICAgIGgydjRoMlY4aDJWMTZ6XCIvPlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IGNvbG9yX3RleHQgPSBgXG4gIDxzdmcgdmlld0JveD1cIjAgMCAyNSAyN1wiPlxuICAgIDxwYXRoIGZpbGw9XCJ2YXIoLS1hY3RpdmVfY29sb3IpXCIgZD1cIk0xMSAzTDUuNSAxN2gyLjI1bDEuMTItM2g2LjI1bDEuMTIgM2gyLjI1TDEzIDNoLTJ6bS0xLjM4IDlMMTIgNS42NyAxNC4zOCAxMkg5LjYyelwiLz5cbiAgICA8cmVjdCBmaWxsPVwidmFyKC0tY29udGV4dHVhbF9jb2xvcilcIiB4PVwiMVwiIHk9XCIyMVwiIHdpZHRoPVwiMjNcIiBoZWlnaHQ9XCI1XCI+PC9yZWN0PlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IGNvbG9yX2JhY2tncm91bmQgPSBgXG4gIDxzdmcgdmlld0JveD1cIjAgMCAyNSAyN1wiPlxuICAgIDxwYXRoIGZpbGw9XCJ2YXIoLS1hY3RpdmVfY29sb3IpXCIgZD1cIk0xNi41NiA4Ljk0TDcuNjIgMCA2LjIxIDEuNDFsMi4zOCAyLjM4LTUuMTUgNS4xNWMtLjU5LjU5LS41OSAxLjU0IDAgMi4xMmw1LjUgNS41Yy4yOS4yOS42OC40NCAxLjA2LjQ0cy43Ny0uMTUgMS4wNi0uNDRsNS41LTUuNWMuNTktLjU4LjU5LTEuNTMgMC0yLjEyek01LjIxIDEwTDEwIDUuMjEgMTQuNzkgMTBINS4yMXpNMTkgMTEuNXMtMiAyLjE3LTIgMy41YzAgMS4xLjkgMiAyIDJzMi0uOSAyLTJjMC0xLjMzLTItMy41LTItMy41elwiLz5cbiAgICA8cmVjdCBmaWxsPVwidmFyKC0tY29udGV4dHVhbF9jb2xvcilcIiB4PVwiMVwiIHk9XCIyMVwiIHdpZHRoPVwiMjNcIiBoZWlnaHQ9XCI1XCI+PC9yZWN0PlxuICA8L3N2Zz5cbmBcblxuZXhwb3J0IGNvbnN0IGNvbG9yX2JvcmRlciA9IGBcbiAgPHN2ZyB2aWV3Qm94PVwiMCAwIDI1IDI3XCI+XG4gICAgPHBhdGggZmlsbD1cInZhcigtLWFjdGl2ZV9jb2xvcilcIiBkPVwiTTE3Ljc1IDdMMTQgMy4yNWwtMTAgMTBWMTdoMy43NWwxMC0xMHptMi45Ni0yLjk2Yy4zOS0uMzkuMzktMS4wMiAwLTEuNDFMMTguMzcuMjljLS4zOS0uMzktMS4wMi0uMzktMS40MSAwTDE1IDIuMjUgMTguNzUgNmwxLjk2LTEuOTZ6XCIvPlxuICAgIDxyZWN0IGZpbGw9XCJ2YXIoLS1jb250ZXh0dWFsX2NvbG9yKVwiIHg9XCIxXCIgeT1cIjIxXCIgd2lkdGg9XCIyM1wiIGhlaWdodD1cIjVcIj48L3JlY3Q+XG4gIDwvc3ZnPlxuYFxuXG5leHBvcnQgY29uc3QgcG9zaXRpb24gPSBgXG4gIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICA8cGF0aCBkPVwiTTE1LjU0IDUuNTRMMTMuNzcgNy4zIDEyIDUuNTQgMTAuMjMgNy4zIDguNDYgNS41NCAxMiAyem0yLjkyIDEwbC0xLjc2LTEuNzdMMTguNDYgMTJsLTEuNzYtMS43NyAxLjc2LTEuNzdMMjIgMTJ6bS0xMCAyLjkybDEuNzctMS43NkwxMiAxOC40NmwxLjc3LTEuNzYgMS43NyAxLjc2TDEyIDIyem0tMi45Mi0xMGwxLjc2IDEuNzdMNS41NCAxMmwxLjc2IDEuNzctMS43NiAxLjc3TDIgMTJ6XCIvPlxuICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiM1wiLz5cbiAgPC9zdmc+XG5gXG5cbmV4cG9ydCBjb25zdCBhY2Nlc3NpYmlsaXR5ID0gYFxuICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgPHBhdGggZD1cIk0xMiwyYzEuMSwwLDIsMC45LDIsMnMtMC45LDItMiwycy0yLTAuOS0yLTJTMTAuOSwyLDEyLDJ6IE0yMSw5aC02djEzaC0ydi02aC0ydjZIOVY5SDNWN2gxOFY5elwiLz5cbiAgPC9zdmc+XG5gIiwiaW1wb3J0ICQgICAgICAgICAgICBmcm9tICdibGluZ2JsaW5nanMnXG5pbXBvcnQgaG90a2V5cyAgICAgIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgc3R5bGVzICAgICAgIGZyb20gJy4vYmFzZS5lbGVtZW50LmNzcydcbmltcG9ydCAqIGFzIEljb25zICAgZnJvbSAnLi4vdG9vbC1wYWxsZXRlL3Rvb2xwYWxsZXRlLmljb25zJ1xuaW1wb3J0IHsgbWV0YUtleSwgYWx0S2V5IH0gIGZyb20gJy4uLy4uL3V0aWxpdGllcy8nXG5cbmV4cG9ydCBjbGFzcyBIb3RrZXlNYXAgZXh0ZW5kcyBIVE1MRWxlbWVudCB7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5rZXlib2FyZF9tb2RlbCA9IHtcbiAgICAgIG51bTogICAgWydgJywnMScsJzInLCczJywnNCcsJzUnLCc2JywnNycsJzgnLCc5JywnMCcsJy0nLCc9JywnZGVsZXRlJ10sXG4gICAgICB0YWI6ICAgIFsndGFiJywncScsJ3cnLCdlJywncicsJ3QnLCd5JywndScsJ2knLCdvJywncCcsJ1snLCddJywnXFxcXCddLFxuICAgICAgY2FwczogICBbJ2NhcHMnLCdhJywncycsJ2QnLCdmJywnZycsJ2gnLCdqJywnaycsJ2wnLCdcXCcnLCdyZXR1cm4nXSxcbiAgICAgIHNoaWZ0OiAgWydzaGlmdCcsJ3onLCd4JywnYycsJ3YnLCdiJywnbicsJ20nLCcsJywnLicsJy8nLCdzaGlmdCddLFxuICAgICAgc3BhY2U6ICBbJ2N0cmwnLGFsdEtleSwnY21kJywnc3BhY2ViYXInLCdjbWQnLGFsdEtleSwnY3RybCddXG4gICAgfVxuXG4gICAgdGhpcy5rZXlfc2l6ZV9tb2RlbCA9IHtcbiAgICAgIG51bTogICAgezEyOjJ9LFxuICAgICAgdGFiOiAgICB7MDoyfSxcbiAgICAgIGNhcHM6ICAgezA6MywxMTozfSxcbiAgICAgIHNoaWZ0OiAgezA6NiwxMTo2fSxcbiAgICAgIHNwYWNlOiAgezM6MTB9LFxuICAgIH1cblxuICAgIHRoaXMuJHNoYWRvdyAgICA9IHRoaXMuYXR0YWNoU2hhZG93KHttb2RlOiAnb3Blbid9KVxuXG4gICAgdGhpcy5faG90a2V5ICAgID0gJydcbiAgICB0aGlzLl91c2Vka2V5cyAgPSBbXVxuXG4gICAgdGhpcy50b29sICAgICAgID0gJ2hvdGtleW1hcCdcbiAgfVxuXG4gIGNvbm5lY3RlZENhbGxiYWNrKCkge1xuICAgIHRoaXMuJHNoaWZ0ICA9ICQoJ1trZXlib2FyZF0gPiBzZWN0aW9uID4gW3NoaWZ0XScsIHRoaXMuJHNoYWRvdylcbiAgICB0aGlzLiRjdHJsICAgPSAkKCdba2V5Ym9hcmRdID4gc2VjdGlvbiA+IFtjdHJsXScsIHRoaXMuJHNoYWRvdylcbiAgICB0aGlzLiRhbHQgICAgPSAkKGBba2V5Ym9hcmRdID4gc2VjdGlvbiA+IFske2FsdEtleX1dYCwgdGhpcy4kc2hhZG93KVxuICAgIHRoaXMuJGNtZCAgICA9ICQoYFtrZXlib2FyZF0gPiBzZWN0aW9uID4gWyR7bWV0YUtleX1dYCwgdGhpcy4kc2hhZG93KVxuICAgIHRoaXMuJHVwICAgICA9ICQoJ1thcnJvd3NdIFt1cF0nLCB0aGlzLiRzaGFkb3cpXG4gICAgdGhpcy4kZG93biAgID0gJCgnW2Fycm93c10gW2Rvd25dJywgdGhpcy4kc2hhZG93KVxuICAgIHRoaXMuJGxlZnQgICA9ICQoJ1thcnJvd3NdIFtsZWZ0XScsIHRoaXMuJHNoYWRvdylcbiAgICB0aGlzLiRyaWdodCAgPSAkKCdbYXJyb3dzXSBbcmlnaHRdJywgdGhpcy4kc2hhZG93KVxuICB9XG5cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7fVxuXG4gIHNldCB0b29sKHRvb2wpIHtcbiAgICB0aGlzLl90b29sID0gdG9vbFxuICAgIHRoaXMuJHNoYWRvdy5pbm5lckhUTUwgPSB0aGlzLnJlbmRlcigpXG4gIH1cblxuICBzaG93KCkge1xuICAgIHRoaXMuJHNoYWRvdy5ob3N0LnN0eWxlLmRpc3BsYXkgPSAnZmxleCdcbiAgICBob3RrZXlzKCcqJywgKGUsIGhhbmRsZXIpID0+XG4gICAgICB0aGlzLndhdGNoS2V5cyhlLCBoYW5kbGVyKSlcbiAgfVxuXG4gIGhpZGUoKSB7XG4gICAgdGhpcy4kc2hhZG93Lmhvc3Quc3R5bGUuZGlzcGxheSA9ICdub25lJ1xuICAgIGhvdGtleXMudW5iaW5kKCcqJylcbiAgfVxuXG4gIHdhdGNoS2V5cyhlLCBoYW5kbGVyKSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgZS5zdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24oKVxuXG4gICAgdGhpcy4kc2hpZnQuYXR0cigncHJlc3NlZCcsIGhvdGtleXMuc2hpZnQpXG4gICAgdGhpcy4kY3RybC5hdHRyKCdwcmVzc2VkJywgaG90a2V5cy5jdHJsKVxuICAgIHRoaXMuJGFsdC5hdHRyKCdwcmVzc2VkJywgaG90a2V5cy5hbHQpXG4gICAgdGhpcy4kY21kLmF0dHIoJ3ByZXNzZWQnLCBob3RrZXlzW21ldGFLZXldKVxuICAgIHRoaXMuJHVwLmF0dHIoJ3ByZXNzZWQnLCBlLmNvZGUgPT09ICdBcnJvd1VwJylcbiAgICB0aGlzLiRkb3duLmF0dHIoJ3ByZXNzZWQnLCBlLmNvZGUgPT09ICdBcnJvd0Rvd24nKVxuICAgIHRoaXMuJGxlZnQuYXR0cigncHJlc3NlZCcsIGUuY29kZSA9PT0gJ0Fycm93TGVmdCcpXG4gICAgdGhpcy4kcmlnaHQuYXR0cigncHJlc3NlZCcsIGUuY29kZSA9PT0gJ0Fycm93UmlnaHQnKVxuXG4gICAgY29uc3QgeyBuZWdhdGl2ZSwgbmVnYXRpdmVfbW9kaWZpZXIsIHNpZGUsIGFtb3VudCB9ID0gdGhpcy5jcmVhdGVDb21tYW5kKHtlLCBob3RrZXlzfSlcblxuICAgICQoJ1tjb21tYW5kXScsIHRoaXMuJHNoYWRvdylbMF0uaW5uZXJIVE1MID0gdGhpcy5kaXNwbGF5Q29tbWFuZCh7XG4gICAgICBuZWdhdGl2ZSwgbmVnYXRpdmVfbW9kaWZpZXIsIHNpZGUsIGFtb3VudCxcbiAgICB9KVxuICB9XG5cbiAgY3JlYXRlQ29tbWFuZCh7ZTp7Y29kZX0sIGhvdGtleXN9KSB7XG4gICAgbGV0IGFtb3VudCAgICAgICAgICAgICAgPSBob3RrZXlzLnNoaWZ0ID8gMTAgOiAxXG4gICAgbGV0IG5lZ2F0aXZlICAgICAgICAgICAgPSBob3RrZXlzLmFsdCA/ICdTdWJ0cmFjdCcgOiAnQWRkJ1xuICAgIGxldCBuZWdhdGl2ZV9tb2RpZmllciAgID0gaG90a2V5cy5hbHQgPyAnZnJvbScgOiAndG8nXG5cbiAgICBsZXQgc2lkZSA9ICdbYXJyb3cga2V5XSdcbiAgICBpZiAoY29kZSA9PT0gJ0Fycm93VXAnKSAgICAgc2lkZSA9ICd0aGUgdG9wIHNpZGUnXG4gICAgaWYgKGNvZGUgPT09ICdBcnJvd0Rvd24nKSAgIHNpZGUgPSAndGhlIGJvdHRvbSBzaWRlJ1xuICAgIGlmIChjb2RlID09PSAnQXJyb3dMZWZ0JykgICBzaWRlID0gJ3RoZSBsZWZ0IHNpZGUnXG4gICAgaWYgKGNvZGUgPT09ICdBcnJvd1JpZ2h0JykgIHNpZGUgPSAndGhlIHJpZ2h0IHNpZGUnXG4gICAgaWYgKGhvdGtleXNbbWV0YUtleV0pICAgICAgICAgICAgc2lkZSA9ICdhbGwgc2lkZXMnXG5cbiAgICBpZiAoaG90a2V5c1ttZXRhS2V5XSAmJiBjb2RlID09PSAnQXJyb3dEb3duJykge1xuICAgICAgbmVnYXRpdmUgICAgICAgICAgICA9ICdTdWJ0cmFjdCdcbiAgICAgIG5lZ2F0aXZlX21vZGlmaWVyICAgPSAnZnJvbSdcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgbmVnYXRpdmUsIG5lZ2F0aXZlX21vZGlmaWVyLCBhbW91bnQsIHNpZGUsXG4gICAgfVxuICB9XG5cbiAgZGlzcGxheUNvbW1hbmQoe25lZ2F0aXZlLCBuZWdhdGl2ZV9tb2RpZmllciwgc2lkZSwgYW1vdW50fSkge1xuICAgIHJldHVybiBgXG4gICAgICA8c3BhbiBuZWdhdGl2ZT4ke25lZ2F0aXZlfSA8L3NwYW4+XG4gICAgICA8c3BhbiB0b29sPiR7dGhpcy5fdG9vbH08L3NwYW4+XG4gICAgICA8c3BhbiBsaWdodD4gJHtuZWdhdGl2ZV9tb2RpZmllcn0gPC9zcGFuPlxuICAgICAgPHNwYW4gc2lkZT4ke3NpZGV9PC9zcGFuPlxuICAgICAgPHNwYW4gbGlnaHQ+IGJ5IDwvc3Bhbj5cbiAgICAgIDxzcGFuIGFtb3VudD4ke2Ftb3VudH08L3NwYW4+XG4gICAgYFxuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiBgXG4gICAgICAke3RoaXMuc3R5bGVzKCl9XG4gICAgICA8YXJ0aWNsZT5cbiAgICAgICAgPGRpdiB0b29sLWljb24+XG4gICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAke0ljb25zW3RoaXMuX3Rvb2xdfVxuICAgICAgICAgICAgJHt0aGlzLl90b29sfSBUb29sXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjb21tYW5kPlxuICAgICAgICAgICR7dGhpcy5kaXNwbGF5Q29tbWFuZCh7XG4gICAgICAgICAgICBuZWdhdGl2ZTogYMKxWyR7YWx0S2V5fV0gYCxcbiAgICAgICAgICAgIG5lZ2F0aXZlX21vZGlmaWVyOiAnIHRvICcsXG4gICAgICAgICAgICB0b29sOiB0aGlzLl90b29sLFxuICAgICAgICAgICAgc2lkZTogJ1thcnJvdyBrZXldJyxcbiAgICAgICAgICAgIGFtb3VudDogMVxuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjYXJkPlxuICAgICAgICAgIDxkaXYga2V5Ym9hcmQ+XG4gICAgICAgICAgICAke09iamVjdC5lbnRyaWVzKHRoaXMua2V5Ym9hcmRfbW9kZWwpLnJlZHVjZSgoa2V5Ym9hcmQsIFtyb3dfbmFtZSwgcm93XSkgPT4gYFxuICAgICAgICAgICAgICAke2tleWJvYXJkfVxuICAgICAgICAgICAgICA8c2VjdGlvbiAke3Jvd19uYW1lfT4ke3Jvdy5yZWR1Y2UoKHJvdywga2V5LCBpKSA9PiBgXG4gICAgICAgICAgICAgICAgJHtyb3d9XG4gICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICR7a2V5fVxuICAgICAgICAgICAgICAgICAgJHt0aGlzLl9ob3RrZXkgPT0ga2V5ID8gJ2hvdGtleSB0aXRsZT1cIlRvb2wgU2hvcnRjdXQgSG90a2V5XCInIDogJyd9XG4gICAgICAgICAgICAgICAgICAke3RoaXMuX3VzZWRrZXlzLmluY2x1ZGVzKGtleSkgPyAndXNlZCcgOiAnJ31cbiAgICAgICAgICAgICAgICAgIHN0eWxlPVwiZmxleDoke3RoaXMua2V5X3NpemVfbW9kZWxbcm93X25hbWVdW2ldIHx8IDF9O1wiXG4gICAgICAgICAgICAgICAgPiR7a2V5fTwvc3Bhbj5cbiAgICAgICAgICAgICAgYCwgJycpfVxuICAgICAgICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgICAgICBgLCAnJyl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxzZWN0aW9uIGFycm93cz5cbiAgICAgICAgICAgICAgPHNwYW4gdXAgdXNlZD7ihpE8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGRvd24gdXNlZD7ihpM8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGxlZnQgdXNlZD7ihpA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIHJpZ2h0IHVzZWQ+4oaSPC9zcGFuPlxuICAgICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT5cbiAgICBgXG4gIH1cblxuICBzdHlsZXMoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgIDxzdHlsZT5cbiAgICAgICAgJHtzdHlsZXN9XG4gICAgICA8L3N0eWxlPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ2hvdGtleS1tYXAnLCBIb3RrZXlNYXApXG4iLCJpbXBvcnQgeyBIb3RrZXlNYXAgfSBmcm9tICcuL2Jhc2UuZWxlbWVudCdcbmltcG9ydCB7IGd1aWRlcyBhcyBpY29uIH0gZnJvbSAnLi4vdG9vbC1wYWxsZXRlL3Rvb2xwYWxsZXRlLmljb25zJyBcblxuZXhwb3J0IGNsYXNzIEd1aWRlc0hvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICAgPSAnZydcbiAgICB0aGlzLl91c2Vka2V5cyAgPSBbXVxuICAgIHRoaXMudG9vbCAgICAgICA9ICdndWlkZXMnXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxhcnRpY2xlPlxuICAgICAgICA8ZGl2IHRvb2wtaWNvbj5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICR7aWNvbn1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICBjb21pbmcgc29vblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLWd1aWRlcycsIEd1aWRlc0hvdGtleXMpIiwiaW1wb3J0IHsgSG90a2V5TWFwIH0gZnJvbSAnLi9iYXNlLmVsZW1lbnQnXG5pbXBvcnQgeyBpbnNwZWN0b3IgYXMgaWNvbiB9IGZyb20gJy4uL3Rvb2wtcGFsbGV0ZS90b29scGFsbGV0ZS5pY29ucydcbmltcG9ydCB7IGFsdEtleSB9IGZyb20gJy4uLy4uL3V0aWxpdGllcyc7XG5cbmV4cG9ydCBjbGFzcyBJbnNwZWN0b3JIb3RrZXlzIGV4dGVuZHMgSG90a2V5TWFwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5faG90a2V5ICAgID0gJ2knXG4gICAgdGhpcy5fdXNlZGtleXMgID0gW2FsdEtleV1cbiAgICB0aGlzLnRvb2wgICAgICAgPSAnaW5zcGVjdG9yJ1xuICB9XG5cbiAgY29ubmVjdGVkQ2FsbGJhY2soKSB7fVxuXG4gIHNob3coKSB7XG4gICAgdGhpcy4kc2hhZG93Lmhvc3Quc3R5bGUuZGlzcGxheSA9ICdmbGV4J1xuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiBgXG4gICAgICAke3RoaXMuc3R5bGVzKCl9XG4gICAgICA8YXJ0aWNsZT5cbiAgICAgICAgPGRpdiB0b29sLWljb24+XG4gICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAke2ljb259XG4gICAgICAgICAgICAke3RoaXMuX3Rvb2x9IFRvb2xcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNvbW1hbmQ+XG4gICAgICAgICAgY29taW5nIHNvb25cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2FydGljbGU+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1pbnNwZWN0b3InLCBJbnNwZWN0b3JIb3RrZXlzKVxuIiwiaW1wb3J0IHsgSG90a2V5TWFwIH0gZnJvbSAnLi9iYXNlLmVsZW1lbnQnXG5pbXBvcnQgeyBhY2Nlc3NpYmlsaXR5IGFzIGljb24gfSBmcm9tICcuLi90b29sLXBhbGxldGUvdG9vbHBhbGxldGUuaWNvbnMnXG5pbXBvcnQgeyBhbHRLZXkgfSBmcm9tICcuLi8uLi91dGlsaXRpZXMnO1xuXG5leHBvcnQgY2xhc3MgQWNjZXNzaWJpbGl0eUhvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICAgPSAncCdcbiAgICB0aGlzLl91c2Vka2V5cyAgPSBbYWx0S2V5XVxuICAgIHRoaXMudG9vbCAgICAgICA9ICdhY2Nlc3NpYmlsaXR5J1xuICB9XG5cbiAgY29ubmVjdGVkQ2FsbGJhY2soKSB7fVxuXG4gIHNob3coKSB7XG4gICAgdGhpcy4kc2hhZG93Lmhvc3Quc3R5bGUuZGlzcGxheSA9ICdmbGV4J1xuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiBgXG4gICAgICAke3RoaXMuc3R5bGVzKCl9XG4gICAgICA8YXJ0aWNsZT5cbiAgICAgICAgPGRpdiB0b29sLWljb24+XG4gICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAke2ljb259XG4gICAgICAgICAgICAke3RoaXMuX3Rvb2x9IFRvb2xcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNvbW1hbmQ+XG4gICAgICAgICAgY29taW5nIHNvb25cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2FydGljbGU+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1hY2Nlc3NpYmlsaXR5JywgQWNjZXNzaWJpbGl0eUhvdGtleXMpXG4iLCJpbXBvcnQgeyBIb3RrZXlNYXAgfSBmcm9tICcuL2Jhc2UuZWxlbWVudCdcblxuZXhwb3J0IGNsYXNzIE1vdmVIb3RrZXlzIGV4dGVuZHMgSG90a2V5TWFwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5faG90a2V5ICA9ICd2J1xuICAgIHRoaXMudG9vbCAgICAgPSAnbW92ZSdcbiAgfVxuXG4gIGNyZWF0ZUNvbW1hbmQoe2U6e2NvZGV9LCBob3RrZXlzfSkge1xuICAgIGxldCBhbW91bnQsIG5lZ2F0aXZlLCBuZWdhdGl2ZV9tb2RpZmllclxuXG4gICAgbGV0IHNpZGUgPSAnW2Fycm93IGtleV0nXG4gICAgaWYgKGNvZGUgPT09ICdBcnJvd1VwJykgICAgIHNpZGUgPSAndXAgJiBvdXQgb2YgZGl2J1xuICAgIGlmIChjb2RlID09PSAnQXJyb3dEb3duJykgICBzaWRlID0gJ2Rvd24gJiBpbnRvIG5leHQgc2libGluZyAvIG91dCAmIHVuZGVyIGRpdidcbiAgICBpZiAoY29kZSA9PT0gJ0Fycm93TGVmdCcpICAgc2lkZSA9ICd0b3dhcmRzIHRoZSBmcm9udC90b3Agb2YgdGhlIHN0YWNrJ1xuICAgIGlmIChjb2RlID09PSAnQXJyb3dSaWdodCcpICBzaWRlID0gJ3Rvd2FyZHMgdGhlIGJhY2svYm90dG9tIG9mIHRoZSBzdGFjaydcblxuICAgIHJldHVybiB7XG4gICAgICBuZWdhdGl2ZSwgbmVnYXRpdmVfbW9kaWZpZXIsIGFtb3VudCwgc2lkZSxcbiAgICB9XG4gIH1cblxuICBkaXNwbGF5Q29tbWFuZCh7c2lkZX0pIHtcbiAgICByZXR1cm4gYFxuICAgICAgPHNwYW4gdG9vbD4ke3RoaXMuX3Rvb2x9PC9zcGFuPlxuICAgICAgPHNwYW4gc2lkZT4ke3NpZGV9PC9zcGFuPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ2hvdGtleXMtbW92ZScsIE1vdmVIb3RrZXlzKSIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuaW1wb3J0IHsgbWV0YUtleSwgYWx0S2V5IH0gICBmcm9tICcuLi8uLi91dGlsaXRpZXMvJ1xuXG5leHBvcnQgY2xhc3MgTWFyZ2luSG90a2V5cyBleHRlbmRzIEhvdGtleU1hcCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMuX2hvdGtleSAgICA9ICdtJ1xuICAgIHRoaXMuX3VzZWRrZXlzICA9IFsnc2hpZnQnLG1ldGFLZXksYWx0S2V5XVxuXG4gICAgdGhpcy50b29sICAgICAgID0gJ21hcmdpbidcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ2hvdGtleXMtbWFyZ2luJywgTWFyZ2luSG90a2V5cylcbiIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuaW1wb3J0IHsgbWV0YUtleSwgYWx0S2V5IH0gICBmcm9tICcuLi8uLi91dGlsaXRpZXMvJ1xuXG5leHBvcnQgY2xhc3MgUGFkZGluZ0hvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICAgPSAncCdcbiAgICB0aGlzLl91c2Vka2V5cyAgPSBbJ3NoaWZ0JyxtZXRhS2V5LGFsdEtleV1cblxuICAgIHRoaXMudG9vbCAgICAgICA9ICdwYWRkaW5nJ1xuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1wYWRkaW5nJywgUGFkZGluZ0hvdGtleXMpXG4iLCJpbXBvcnQgeyBIb3RrZXlNYXAgfSBmcm9tICcuL2Jhc2UuZWxlbWVudCdcbmltcG9ydCB7IG1ldGFLZXkgfSBmcm9tICcuLi8uLi91dGlsaXRpZXMnO1xuXG5jb25zdCBoX2FsaWduT3B0aW9ucyAgPSBbJ2xlZnQnLCdjZW50ZXInLCdyaWdodCddXG5jb25zdCB2X2FsaWduT3B0aW9ucyAgPSBbJ3RvcCcsJ2NlbnRlcicsJ2JvdHRvbSddXG5jb25zdCBkaXN0T3B0aW9ucyAgICAgPSBbJ2V2ZW5seScsJ25vcm1hbCcsJ2JldHdlZW4nXVxuXG5leHBvcnQgY2xhc3MgQWxpZ25Ib3RrZXlzIGV4dGVuZHMgSG90a2V5TWFwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5faG90a2V5ICAgPSAnYSdcbiAgICB0aGlzLl91c2Vka2V5cyA9IFttZXRhS2V5LCdzaGlmdCddXG5cbiAgICB0aGlzLl9odG9vbCAgID0gMFxuICAgIHRoaXMuX3Z0b29sICAgPSAwXG4gICAgdGhpcy5fZHRvb2wgICA9IDFcblxuICAgIHRoaXMuX3NpZGUgICAgICAgICA9ICd0b3AgbGVmdCdcbiAgICB0aGlzLl9kaXJlY3Rpb24gICAgPSAncm93J1xuICAgIHRoaXMuX2Rpc3RyaWJ1dGlvbiA9IGRpc3RPcHRpb25zW3RoaXMuX2R0b29sXVxuXG4gICAgdGhpcy50b29sICAgICA9ICdhbGlnbidcbiAgfVxuXG4gIGNyZWF0ZUNvbW1hbmQoe2U6e2NvZGV9LCBob3RrZXlzfSkge1xuICAgIGxldCBhbW91bnQgICAgICAgICAgICA9IHRoaXMuX2Rpc3RyaWJ1dGlvblxuICAgICAgLCBuZWdhdGl2ZV9tb2RpZmllciA9IHRoaXMuX2RpcmVjdGlvblxuICAgICAgLCBzaWRlICAgICAgICAgICAgICA9IHRoaXMuX3NpZGVcbiAgICAgICwgbmVnYXRpdmVcblxuICAgIGlmIChob3RrZXlzLmNtZCAmJiAoY29kZSA9PT0gJ0Fycm93UmlnaHQnIHx8IGNvZGUgPT09ICdBcnJvd0Rvd24nKSkge1xuICAgICAgbmVnYXRpdmVfbW9kaWZpZXIgPSBjb2RlID09PSAnQXJyb3dEb3duJ1xuICAgICAgICA/ICdjb2x1bW4nXG4gICAgICAgIDogJ3JvdydcbiAgICAgIHRoaXMuX2RpcmVjdGlvbiA9IG5lZ2F0aXZlX21vZGlmaWVyXG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd1VwJykgICAgICAgICAgIHNpZGUgPSB0aGlzLmNsYW1wKHZfYWxpZ25PcHRpb25zLCAnX3Z0b29sJylcbiAgICAgIGVsc2UgaWYgKGNvZGUgPT09ICdBcnJvd0Rvd24nKSAgICBzaWRlID0gdGhpcy5jbGFtcCh2X2FsaWduT3B0aW9ucywgJ192dG9vbCcsIHRydWUpXG4gICAgICBlbHNlICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2lkZSA9IHZfYWxpZ25PcHRpb25zW3RoaXMuX3Z0b29sXVxuXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93TGVmdCcpICAgICAgICAgc2lkZSArPSAnICcgKyB0aGlzLmNsYW1wKGhfYWxpZ25PcHRpb25zLCAnX2h0b29sJylcbiAgICAgIGVsc2UgaWYgKGNvZGUgPT09ICdBcnJvd1JpZ2h0JykgICBzaWRlICs9ICcgJyArIHRoaXMuY2xhbXAoaF9hbGlnbk9wdGlvbnMsICdfaHRvb2wnLCB0cnVlKVxuICAgICAgZWxzZSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpZGUgKz0gJyAnICsgaF9hbGlnbk9wdGlvbnNbdGhpcy5faHRvb2xdXG5cbiAgICAgIHRoaXMuX3NpZGUgPSBzaWRlXG5cbiAgICAgIGlmIChob3RrZXlzLnNoaWZ0ICYmIChjb2RlID09PSAnQXJyb3dSaWdodCcgfHwgY29kZSA9PT0gJ0Fycm93TGVmdCcpKSB7XG4gICAgICAgIGFtb3VudCA9IHRoaXMuY2xhbXAoZGlzdE9wdGlvbnMsICdfZHRvb2wnLCBjb2RlID09PSAnQXJyb3dSaWdodCcpXG4gICAgICAgIHRoaXMuX2Rpc3RyaWJ1dGlvbiA9IGFtb3VudFxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBuZWdhdGl2ZSwgbmVnYXRpdmVfbW9kaWZpZXIsIGFtb3VudCwgc2lkZSxcbiAgICB9XG4gIH1cblxuICBkaXNwbGF5Q29tbWFuZCh7c2lkZSwgYW1vdW50LCBuZWdhdGl2ZV9tb2RpZmllcn0pIHtcbiAgICBpZiAoYW1vdW50ID09IDEpIGFtb3VudCA9IHRoaXMuX2Rpc3RyaWJ1dGlvblxuICAgIGlmIChuZWdhdGl2ZV9tb2RpZmllciA9PSAnIHRvICcpIG5lZ2F0aXZlX21vZGlmaWVyID0gdGhpcy5fZGlyZWN0aW9uXG5cbiAgICByZXR1cm4gYFxuICAgICAgPHNwYW4gdG9vbD4ke3RoaXMuX3Rvb2x9PC9zcGFuPlxuICAgICAgPHNwYW4gbGlnaHQ+IGFzIDwvc3Bhbj5cbiAgICAgIDxzcGFuPiR7bmVnYXRpdmVfbW9kaWZpZXJ9Ojwvc3Bhbj5cbiAgICAgIDxzcGFuIHNpZGU+JHtzaWRlfTwvc3Bhbj5cbiAgICAgIDxzcGFuIGxpZ2h0PiBkaXN0cmlidXRlZCA8L3NwYW4+XG4gICAgICA8c3BhbiBhbW91bnQ+JHthbW91bnR9PC9zcGFuPlxuICAgIGBcbiAgfVxuXG4gIGNsYW1wKHJhbmdlLCB0b29sLCBpbmNyZW1lbnQgPSBmYWxzZSkge1xuICAgIGlmIChpbmNyZW1lbnQpIHtcbiAgICAgIGlmICh0aGlzW3Rvb2xdIDwgcmFuZ2UubGVuZ3RoIC0gMSlcbiAgICAgICAgdGhpc1t0b29sXSA9IHRoaXNbdG9vbF0gKyAxXG4gICAgfVxuICAgIGVsc2UgaWYgKHRoaXNbdG9vbF0gPiAwKVxuICAgICAgdGhpc1t0b29sXSA9IHRoaXNbdG9vbF0gLSAxXG5cbiAgICByZXR1cm4gcmFuZ2VbdGhpc1t0b29sXV1cbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ2hvdGtleXMtYWxpZ24nLCBBbGlnbkhvdGtleXMpXG4iLCJpbXBvcnQgeyBIb3RrZXlNYXAgfSBmcm9tICcuL2Jhc2UuZWxlbWVudCdcbmltcG9ydCB7IGh1ZXNoaWZ0IGFzIGljb24gfSBmcm9tICcuLi90b29sLXBhbGxldGUvdG9vbHBhbGxldGUuaWNvbnMnXG5pbXBvcnQgeyBtZXRhS2V5LCBhbHRLZXkgfSBmcm9tICcuLi8uLi91dGlsaXRpZXMnO1xuXG5leHBvcnQgY2xhc3MgSHVlc2hpZnRIb3RrZXlzIGV4dGVuZHMgSG90a2V5TWFwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5faG90a2V5ICAgID0gJ2gnXG4gICAgdGhpcy5fdXNlZGtleXMgID0gWydzaGlmdCcsbWV0YUtleV1cbiAgICB0aGlzLnRvb2wgICAgICAgPSAnaHVlc2hpZnQnXG4gIH1cblxuICBjcmVhdGVDb21tYW5kKHtlOntjb2RlfSwgaG90a2V5c30pIHtcbiAgICBsZXQgYW1vdW50ICAgICAgICAgICAgICA9IGhvdGtleXMuc2hpZnQgPyAxMCA6IDFcbiAgICBsZXQgbmVnYXRpdmUgICAgICAgICAgICA9ICdbaW5jcmVhc2UvZGVjcmVhc2VdJ1xuICAgIGxldCBuZWdhdGl2ZV9tb2RpZmllciAgID0gJ2J5J1xuICAgIGxldCBzaWRlICAgICAgICAgICAgICAgID0gJ1thcnJvdyBrZXldJ1xuXG4gICAgLy8gc2F0dXJhdGlvblxuICAgIGlmIChob3RrZXlzLmNtZCkge1xuICAgICAgc2lkZSA9J2h1ZSdcblxuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd0Rvd24nKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnZGVjcmVhc2UnXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93VXAnKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnaW5jcmVhc2UnXG4gICAgfVxuICAgIGVsc2UgaWYgKGNvZGUgPT09ICdBcnJvd0xlZnQnIHx8IGNvZGUgPT09ICdBcnJvd1JpZ2h0Jykge1xuICAgICAgc2lkZSA9ICdzYXR1cmF0aW9uJ1xuXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93TGVmdCcpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdkZWNyZWFzZSdcbiAgICAgIGlmIChjb2RlID09PSAnQXJyb3dSaWdodCcpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdpbmNyZWFzZSdcbiAgICB9XG4gICAgLy8gbGlnaHRuZXNzXG4gICAgZWxzZSBpZiAoY29kZSA9PT0gJ0Fycm93VXAnIHx8IGNvZGUgPT09ICdBcnJvd0Rvd24nKSB7XG4gICAgICBzaWRlID0gJ2xpZ2h0bmVzcydcblxuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd0Rvd24nKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnZGVjcmVhc2UnXG4gICAgICBpZiAoY29kZSA9PT0gJ0Fycm93VXAnKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnaW5jcmVhc2UnXG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG5lZ2F0aXZlLCBuZWdhdGl2ZV9tb2RpZmllciwgYW1vdW50LCBzaWRlLFxuICAgIH1cbiAgfVxuXG4gIGRpc3BsYXlDb21tYW5kKHtuZWdhdGl2ZSwgbmVnYXRpdmVfbW9kaWZpZXIsIHNpZGUsIGFtb3VudH0pIHtcbiAgICBpZiAobmVnYXRpdmUgPT09IGDCsVske2FsdEtleX1dIGApXG4gICAgICBuZWdhdGl2ZSA9ICdbaW5jcmVhc2UvZGVjcmVhc2VdJ1xuICAgIGlmIChuZWdhdGl2ZV9tb2RpZmllciA9PT0gJyB0byAnKVxuICAgICAgbmVnYXRpdmVfbW9kaWZpZXIgPSAnIGJ5ICdcblxuICAgIHJldHVybiBgXG4gICAgICA8c3BhbiBuZWdhdGl2ZT4ke25lZ2F0aXZlfTwvc3Bhbj5cbiAgICAgIDxzcGFuIHNpZGUgdG9vbD4ke3NpZGV9PC9zcGFuPlxuICAgICAgPHNwYW4gbGlnaHQ+JHtuZWdhdGl2ZV9tb2RpZmllcn08L3NwYW4+XG4gICAgICA8c3BhbiBhbW91bnQ+JHthbW91bnR9PC9zcGFuPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ2hvdGtleXMtaHVlc2hpZnQnLCBIdWVzaGlmdEhvdGtleXMpXG4iLCJpbXBvcnQgeyBIb3RrZXlNYXAgfSBmcm9tICcuL2Jhc2UuZWxlbWVudCdcbmltcG9ydCB7IGJveHNoYWRvdyBhcyBpY29uIH0gZnJvbSAnLi4vdG9vbC1wYWxsZXRlL3Rvb2xwYWxsZXRlLmljb25zJ1xuaW1wb3J0IHsgbWV0YUtleSB9IGZyb20gJy4uLy4uL3V0aWxpdGllcyc7XG5cbmV4cG9ydCBjbGFzcyBCb3hzaGFkb3dIb3RrZXlzIGV4dGVuZHMgSG90a2V5TWFwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5faG90a2V5ICAgID0gJ2QnXG4gICAgdGhpcy5fdXNlZGtleXMgID0gWydzaGlmdCcsbWV0YUtleV1cbiAgICB0aGlzLnRvb2wgICAgICAgPSAnYm94c2hhZG93J1xuICB9XG5cbiAgY29ubmVjdGVkQ2FsbGJhY2soKSB7fVxuXG4gIHNob3coKSB7XG4gICAgdGhpcy4kc2hhZG93Lmhvc3Quc3R5bGUuZGlzcGxheSA9ICdmbGV4J1xuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiBgXG4gICAgICAke3RoaXMuc3R5bGVzKCl9XG4gICAgICA8YXJ0aWNsZT5cbiAgICAgICAgPGRpdiB0b29sLWljb24+XG4gICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAke2ljb259XG4gICAgICAgICAgICAke3RoaXMuX3Rvb2x9IFRvb2xcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNvbW1hbmQ+XG4gICAgICAgICAgY29taW5nIHNvb25cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2FydGljbGU+XG4gICAgYFxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaG90a2V5cy1ib3hzaGFkb3cnLCBCb3hzaGFkb3dIb3RrZXlzKVxuIiwiaW1wb3J0IHsgSG90a2V5TWFwIH0gZnJvbSAnLi9iYXNlLmVsZW1lbnQnXG5pbXBvcnQgeyBwb3NpdGlvbiBhcyBpY29uIH0gZnJvbSAnLi4vdG9vbC1wYWxsZXRlL3Rvb2xwYWxsZXRlLmljb25zJ1xuaW1wb3J0IHsgYWx0S2V5IH0gZnJvbSAnLi4vLi4vdXRpbGl0aWVzJztcblxuZXhwb3J0IGNsYXNzIFBvc2l0aW9uSG90a2V5cyBleHRlbmRzIEhvdGtleU1hcCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMuX2hvdGtleSAgICA9ICdsJ1xuICAgIHRoaXMuX3VzZWRrZXlzICA9IFsnc2hpZnQnLGFsdEtleV1cbiAgICB0aGlzLnRvb2wgICAgICAgPSAncG9zaXRpb24nXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHt9XG5cbiAgc2hvdygpIHtcbiAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgICR7dGhpcy5zdHlsZXMoKX1cbiAgICAgIDxhcnRpY2xlPlxuICAgICAgICA8ZGl2IHRvb2wtaWNvbj5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICR7aWNvbn1cbiAgICAgICAgICAgICR7dGhpcy5fdG9vbH0gVG9vbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY29tbWFuZD5cbiAgICAgICAgICBjb21pbmcgc29vblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvYXJ0aWNsZT5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLXBvc2l0aW9uJywgUG9zaXRpb25Ib3RrZXlzKVxuIiwiaW1wb3J0IHsgSG90a2V5TWFwIH0gZnJvbSAnLi9iYXNlLmVsZW1lbnQnXG5pbXBvcnQgeyBtZXRhS2V5LCBhbHRLZXkgfSBmcm9tICcuLi8uLi91dGlsaXRpZXMnO1xuXG5leHBvcnQgY2xhc3MgRm9udEhvdGtleXMgZXh0ZW5kcyBIb3RrZXlNYXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLl9ob3RrZXkgICAgPSAnZidcbiAgICB0aGlzLl91c2Vka2V5cyAgPSBbJ3NoaWZ0JyxtZXRhS2V5XVxuICAgIHRoaXMudG9vbCAgICAgICA9ICdmb250J1xuICB9XG5cbiAgY3JlYXRlQ29tbWFuZCh7ZTp7Y29kZX0sIGhvdGtleXN9KSB7XG4gICAgbGV0IGFtb3VudCAgICAgICAgICAgICAgPSBob3RrZXlzLnNoaWZ0ID8gMTAgOiAxXG4gICAgbGV0IG5lZ2F0aXZlICAgICAgICAgICAgPSAnW2luY3JlYXNlL2RlY3JlYXNlXSdcbiAgICBsZXQgbmVnYXRpdmVfbW9kaWZpZXIgICA9ICdieSdcbiAgICBsZXQgc2lkZSAgICAgICAgICAgICAgICA9ICdbYXJyb3cga2V5XSdcblxuICAgIC8vIGtlcm5pbmdcbiAgICBpZiAoaG90a2V5cy5zaGlmdCAmJiAoY29kZSA9PT0gJ0Fycm93TGVmdCcgfHwgY29kZSA9PT0gJ0Fycm93UmlnaHQnKSkge1xuICAgICAgc2lkZSAgICA9ICdrZXJuaW5nJ1xuICAgICAgYW1vdW50ICA9ICcxcHgnXG5cbiAgICAgIGlmIChjb2RlID09PSAnQXJyb3dMZWZ0JylcbiAgICAgICAgbmVnYXRpdmUgID0gJ2RlY3JlYXNlJ1xuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd1JpZ2h0JylcbiAgICAgICAgbmVnYXRpdmUgID0gJ2luY3JlYXNlJ1xuICAgIH1cbiAgICAvLyBsZWFkaW5nXG4gICAgZWxzZSBpZiAoaG90a2V5cy5zaGlmdCAmJiAoY29kZSA9PT0gJ0Fycm93VXAnIHx8IGNvZGUgPT09ICdBcnJvd0Rvd24nKSkge1xuICAgICAgc2lkZSAgICA9ICdsZWFkaW5nJ1xuICAgICAgYW1vdW50ICA9ICcxcHgnXG5cbiAgICAgIGlmIChjb2RlID09PSAnQXJyb3dVcCcpXG4gICAgICAgIG5lZ2F0aXZlICA9ICdpbmNyZWFzZSdcbiAgICAgIGlmIChjb2RlID09PSAnQXJyb3dEb3duJylcbiAgICAgICAgbmVnYXRpdmUgID0gJ2RlY3JlYXNlJ1xuICAgIH1cbiAgICAvLyBmb250IHdlaWdodFxuICAgIGVsc2UgaWYgKGhvdGtleXMuY21kICYmIChjb2RlID09PSAnQXJyb3dVcCcgfHwgY29kZSA9PT0gJ0Fycm93RG93bicpKSB7XG4gICAgICBzaWRlICAgICAgICAgICAgICAgID0gJ2ZvbnQgd2VpZ2h0J1xuICAgICAgYW1vdW50ICAgICAgICAgICAgICA9ICcnXG4gICAgICBuZWdhdGl2ZV9tb2RpZmllciAgID0gJydcblxuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd1VwJylcbiAgICAgICAgbmVnYXRpdmUgID0gJ2luY3JlYXNlJ1xuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd0Rvd24nKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnZGVjcmVhc2UnXG4gICAgfVxuICAgIC8vIGZvbnQgc2l6ZVxuICAgIGVsc2UgaWYgKGNvZGUgPT09ICdBcnJvd1VwJyB8fCBjb2RlID09PSAnQXJyb3dEb3duJykge1xuICAgICAgc2lkZSAgICA9ICdmb250IHNpemUnXG4gICAgICBhbW91bnQgID0gJzFweCdcblxuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd1VwJylcbiAgICAgICAgbmVnYXRpdmUgID0gJ2luY3JlYXNlJ1xuICAgICAgaWYgKGNvZGUgPT09ICdBcnJvd0Rvd24nKVxuICAgICAgICBuZWdhdGl2ZSAgPSAnZGVjcmVhc2UnXG4gICAgfVxuICAgIC8vIHRleHQgYWxpZ25tZW50XG4gICAgZWxzZSBpZiAoY29kZSA9PT0gJ0Fycm93UmlnaHQnIHx8IGNvZGUgPT09ICdBcnJvd0xlZnQnKSB7XG4gICAgICBzaWRlICAgICAgICAgICAgICAgID0gJ3RleHQgYWxpZ25tZW50J1xuICAgICAgYW1vdW50ICAgICAgICAgICAgICA9ICcnXG4gICAgICBuZWdhdGl2ZSAgICAgICAgICAgID0gJ2FkanVzdCdcbiAgICAgIG5lZ2F0aXZlX21vZGlmaWVyICAgPSAnJ1xuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBuZWdhdGl2ZSwgbmVnYXRpdmVfbW9kaWZpZXIsIGFtb3VudCwgc2lkZSxcbiAgICB9XG4gIH1cblxuICBkaXNwbGF5Q29tbWFuZCh7bmVnYXRpdmUsIG5lZ2F0aXZlX21vZGlmaWVyLCBzaWRlLCBhbW91bnR9KSB7XG4gICAgaWYgKG5lZ2F0aXZlID09PSBgwrFbJHthbHRLZXl9XSBgKVxuICAgICAgbmVnYXRpdmUgPSAnW2luY3JlYXNlL2RlY3JlYXNlXSdcbiAgICBpZiAobmVnYXRpdmVfbW9kaWZpZXIgPT09ICcgdG8gJylcbiAgICAgIG5lZ2F0aXZlX21vZGlmaWVyID0gJyBieSAnXG5cbiAgICByZXR1cm4gYFxuICAgICAgPHNwYW4gbmVnYXRpdmU+JHtuZWdhdGl2ZX08L3NwYW4+XG4gICAgICA8c3BhbiBzaWRlIHRvb2w+JHtzaWRlfTwvc3Bhbj5cbiAgICAgIDxzcGFuIGxpZ2h0PiR7bmVnYXRpdmVfbW9kaWZpZXJ9PC9zcGFuPlxuICAgICAgPHNwYW4gYW1vdW50PiR7YW1vdW50fTwvc3Bhbj5cbiAgICBgXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdob3RrZXlzLWZvbnQnLCBGb250SG90a2V5cylcbiIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuaW1wb3J0IHsgdGV4dCBhcyBpY29uIH0gZnJvbSAnLi4vdG9vbC1wYWxsZXRlL3Rvb2xwYWxsZXRlLmljb25zJyBcblxuZXhwb3J0IGNsYXNzIFRleHRIb3RrZXlzIGV4dGVuZHMgSG90a2V5TWFwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5faG90a2V5ICAgID0gJ2UnXG4gICAgdGhpcy5fdXNlZGtleXMgID0gW11cbiAgICB0aGlzLnRvb2wgICAgICAgPSAndGV4dCdcbiAgfVxuXG4gIGNvbm5lY3RlZENhbGxiYWNrKCkge31cblxuICBzaG93KCkge1xuICAgIHRoaXMuJHNoYWRvdy5ob3N0LnN0eWxlLmRpc3BsYXkgPSAnZmxleCdcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcygpfVxuICAgICAgPGFydGljbGU+XG4gICAgICAgIDxkaXYgdG9vbC1pY29uPlxuICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgJHtpY29ufVxuICAgICAgICAgICAgJHt0aGlzLl90b29sfSBUb29sXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjb21tYW5kPlxuICAgICAgICAgIGNvbWluZyBzb29uXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9hcnRpY2xlPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ2hvdGtleXMtdGV4dCcsIFRleHRIb3RrZXlzKSIsImltcG9ydCB7IEhvdGtleU1hcCB9IGZyb20gJy4vYmFzZS5lbGVtZW50J1xuaW1wb3J0IHsgc2VhcmNoIGFzIGljb24gfSBmcm9tICcuLi90b29sLXBhbGxldGUvdG9vbHBhbGxldGUuaWNvbnMnIFxuXG5leHBvcnQgY2xhc3MgU2VhcmNoSG90a2V5cyBleHRlbmRzIEhvdGtleU1hcCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMuX2hvdGtleSAgICA9ICdzJ1xuICAgIHRoaXMuX3VzZWRrZXlzICA9IFtdXG4gICAgdGhpcy50b29sICAgICAgID0gJ3NlYXJjaCdcbiAgfVxuXG4gIGNvbm5lY3RlZENhbGxiYWNrKCkge31cblxuICBzaG93KCkge1xuICAgIHRoaXMuJHNoYWRvdy5ob3N0LnN0eWxlLmRpc3BsYXkgPSAnZmxleCdcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcygpfVxuICAgICAgPGFydGljbGU+XG4gICAgICAgIDxkaXYgdG9vbC1pY29uPlxuICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgJHtpY29ufVxuICAgICAgICAgICAgJHt0aGlzLl90b29sfSBUb29sXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjb21tYW5kPlxuICAgICAgICAgIGNvbWluZyBzb29uXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9hcnRpY2xlPlxuICAgIGBcbiAgfVxufVxuXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ2hvdGtleXMtc2VhcmNoJywgU2VhcmNoSG90a2V5cykiLCJpbXBvcnQgJCAgICAgICAgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IGhvdGtleXMgIGZyb20gJ2hvdGtleXMtanMnXG5cbmltcG9ydCB7IEd1aWRlc0hvdGtleXMgfSAgICAgICAgZnJvbSAnLi9ndWlkZXMuZWxlbWVudCdcbmltcG9ydCB7IEluc3BlY3RvckhvdGtleXMgfSAgICAgZnJvbSAnLi9pbnNwZWN0b3IuZWxlbWVudCdcbmltcG9ydCB7IEFjY2Vzc2liaWxpdHlIb3RrZXlzIH0gZnJvbSAnLi9hY2Nlc3NpYmlsaXR5LmVsZW1lbnQnXG5pbXBvcnQgeyBNb3ZlSG90a2V5cyB9ICAgICAgICAgIGZyb20gJy4vbW92ZS5lbGVtZW50J1xuaW1wb3J0IHsgTWFyZ2luSG90a2V5cyB9ICAgICAgICBmcm9tICcuL21hcmdpbi5lbGVtZW50J1xuaW1wb3J0IHsgUGFkZGluZ0hvdGtleXMgfSAgICAgICBmcm9tICcuL3BhZGRpbmcuZWxlbWVudCdcbmltcG9ydCB7IEFsaWduSG90a2V5cyB9ICAgICAgICAgZnJvbSAnLi9hbGlnbi5lbGVtZW50J1xuaW1wb3J0IHsgSHVlc2hpZnRIb3RrZXlzIH0gICAgICBmcm9tICcuL2h1ZXNoaWZ0LmVsZW1lbnQnXG5pbXBvcnQgeyBCb3hzaGFkb3dIb3RrZXlzIH0gICAgIGZyb20gJy4vYm94c2hhZG93LmVsZW1lbnQnXG5pbXBvcnQgeyBQb3NpdGlvbkhvdGtleXMgfSAgICAgIGZyb20gJy4vcG9zaXRpb24uZWxlbWVudCdcbmltcG9ydCB7IEZvbnRIb3RrZXlzIH0gICAgICAgICAgZnJvbSAnLi9mb250LmVsZW1lbnQnXG5pbXBvcnQgeyBUZXh0SG90a2V5cyB9ICAgICAgICAgIGZyb20gJy4vdGV4dC5lbGVtZW50J1xuaW1wb3J0IHsgU2VhcmNoSG90a2V5cyB9ICAgICAgICBmcm9tICcuL3NlYXJjaC5lbGVtZW50J1xuXG5leHBvcnQgY2xhc3MgSG90a2V5cyBleHRlbmRzIEhUTUxFbGVtZW50IHtcbiAgXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMudG9vbF9tYXAgPSB7XG4gICAgICBndWlkZXM6ICAgICAgICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaG90a2V5cy1ndWlkZXMnKSxcbiAgICAgIGluc3BlY3RvcjogICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdob3RrZXlzLWluc3BlY3RvcicpLFxuICAgICAgYWNjZXNzaWJpbGl0eTogIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtYWNjZXNzaWJpbGl0eScpLFxuICAgICAgbW92ZTogICAgICAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtbW92ZScpLFxuICAgICAgbWFyZ2luOiAgICAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtbWFyZ2luJyksXG4gICAgICBwYWRkaW5nOiAgICAgICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaG90a2V5cy1wYWRkaW5nJyksXG4gICAgICBhbGlnbjogICAgICAgICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaG90a2V5cy1hbGlnbicpLFxuICAgICAgaHVlc2hpZnQ6ICAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtaHVlc2hpZnQnKSxcbiAgICAgIGJveHNoYWRvdzogICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdob3RrZXlzLWJveHNoYWRvdycpLFxuICAgICAgcG9zaXRpb246ICAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hvdGtleXMtcG9zaXRpb24nKSxcbiAgICAgIGZvbnQ6ICAgICAgICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdob3RrZXlzLWZvbnQnKSxcbiAgICAgIHRleHQ6ICAgICAgICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdob3RrZXlzLXRleHQnKSxcbiAgICAgIHNlYXJjaDogICAgICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdob3RrZXlzLXNlYXJjaCcpLFxuICAgIH1cblxuICAgIE9iamVjdC52YWx1ZXModGhpcy50b29sX21hcCkuZm9yRWFjaCh0b29sID0+XG4gICAgICB0aGlzLmFwcGVuZENoaWxkKHRvb2wpKVxuICB9XG5cbiAgY29ubmVjdGVkQ2FsbGJhY2soKSB7XG4gICAgaG90a2V5cygnc2hpZnQrLycsIGUgPT5cbiAgICAgIHRoaXMuY3VyX3Rvb2xcbiAgICAgICAgPyB0aGlzLmhpZGVUb29sKClcbiAgICAgICAgOiB0aGlzLnNob3dUb29sKCkpXG5cbiAgICBob3RrZXlzKCdlc2MnLCBlID0+IHRoaXMuaGlkZVRvb2woKSlcbiAgfVxuXG4gIGRpc2Nvbm5lY3RlZENhbGxiYWNrKCkge31cblxuICBoaWRlVG9vbCgpIHtcbiAgICBpZiAoIXRoaXMuY3VyX3Rvb2wpIHJldHVyblxuICAgIHRoaXMuY3VyX3Rvb2wuaGlkZSgpXG4gICAgdGhpcy5jdXJfdG9vbCA9IG51bGxcbiAgfVxuXG4gIHNob3dUb29sKCkge1xuICAgIHRoaXMuY3VyX3Rvb2wgPSB0aGlzLnRvb2xfbWFwW1xuICAgICAgJCgndG9vbC1wYWxsZXRlJylbMF0uYWN0aXZlVG9vbF1cbiAgICB0aGlzLmN1cl90b29sLnNob3coKVxuICB9XG59XG5cbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgncGItaG90a2V5cycsIEhvdGtleXMpIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCB7IG1ldGFLZXksIGdldFN0eWxlLCBnZXRTaWRlLCBzaG93SGlkZVNlbGVjdGVkIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuLy8gdG9kbzogc2hvdyBtYXJnaW4gY29sb3JcbmNvbnN0IGtleV9ldmVudHMgPSAndXAsZG93bixsZWZ0LHJpZ2h0J1xuICAuc3BsaXQoJywnKVxuICAucmVkdWNlKChldmVudHMsIGV2ZW50KSA9PlxuICAgIGAke2V2ZW50c30sJHtldmVudH0sYWx0KyR7ZXZlbnR9LHNoaWZ0KyR7ZXZlbnR9LHNoaWZ0K2FsdCske2V2ZW50fWBcbiAgLCAnJylcbiAgLnN1YnN0cmluZygxKVxuXG5jb25zdCBjb21tYW5kX2V2ZW50cyA9IGAke21ldGFLZXl9K3VwLCR7bWV0YUtleX0rc2hpZnQrdXAsJHttZXRhS2V5fStkb3duLCR7bWV0YUtleX0rc2hpZnQrZG93bmBcblxuZXhwb3J0IGZ1bmN0aW9uIE1hcmdpbihzZWxlY3Rvcikge1xuICBob3RrZXlzKGtleV9ldmVudHMsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgaWYgKGUuY2FuY2VsQnViYmxlKSByZXR1cm5cblxuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHB1c2hFbGVtZW50KCQoc2VsZWN0b3IpLCBoYW5kbGVyLmtleSlcbiAgfSlcblxuICBob3RrZXlzKGNvbW1hbmRfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHB1c2hBbGxFbGVtZW50U2lkZXMoJChzZWxlY3RvciksIGhhbmRsZXIua2V5KVxuICB9KVxuXG4gIHJldHVybiAoKSA9PiB7XG4gICAgaG90a2V5cy51bmJpbmQoa2V5X2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZChjb21tYW5kX2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZCgndXAsZG93bixsZWZ0LHJpZ2h0JykgLy8gYnVnIGluIGxpYj9cbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcHVzaEVsZW1lbnQoZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbCA9PiBzaG93SGlkZVNlbGVjdGVkKGVsKSlcbiAgICAubWFwKGVsID0+ICh7XG4gICAgICBlbCxcbiAgICAgIHN0eWxlOiAgICAnbWFyZ2luJyArIGdldFNpZGUoZGlyZWN0aW9uKSxcbiAgICAgIGN1cnJlbnQ6ICBwYXJzZUludChnZXRTdHlsZShlbCwgJ21hcmdpbicgKyBnZXRTaWRlKGRpcmVjdGlvbikpLCAxMCksXG4gICAgICBhbW91bnQ6ICAgZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ3NoaWZ0JykgPyAxMCA6IDEsXG4gICAgICBuZWdhdGl2ZTogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ2FsdCcpLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIG1hcmdpbjogcGF5bG9hZC5uZWdhdGl2ZVxuICAgICAgICAgID8gcGF5bG9hZC5jdXJyZW50IC0gcGF5bG9hZC5hbW91bnRcbiAgICAgICAgICA6IHBheWxvYWQuY3VycmVudCArIHBheWxvYWQuYW1vdW50XG4gICAgICB9KSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgbWFyZ2lufSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IGAke21hcmdpbiA8IDAgPyAwIDogbWFyZ2lufXB4YClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHB1c2hBbGxFbGVtZW50U2lkZXMoZWxzLCBrZXljb21tYW5kKSB7XG4gIGNvbnN0IGNvbWJvID0ga2V5Y29tbWFuZC5zcGxpdCgnKycpXG4gIGxldCBzcG9vZiA9ICcnXG5cbiAgaWYgKGNvbWJvLmluY2x1ZGVzKCdzaGlmdCcpKSAgc3Bvb2YgPSAnc2hpZnQrJyArIHNwb29mXG4gIGlmIChjb21iby5pbmNsdWRlcygnZG93bicpKSAgIHNwb29mID0gJ2FsdCsnICsgc3Bvb2ZcblxuICAndXAsZG93bixsZWZ0LHJpZ2h0Jy5zcGxpdCgnLCcpXG4gICAgLmZvckVhY2goc2lkZSA9PiBwdXNoRWxlbWVudChlbHMsIHNwb29mICsgc2lkZSkpXG59XG4iLCJpbXBvcnQgJCBmcm9tICdibGluZ2JsaW5nanMnXG5pbXBvcnQgaG90a2V5cyBmcm9tICdob3RrZXlzLWpzJ1xuaW1wb3J0IHsgZ2V0Tm9kZUluZGV4LCBzaG93RWRnZSB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmNvbnN0IGtleV9ldmVudHMgPSAndXAsZG93bixsZWZ0LHJpZ2h0J1xuLy8gdG9kbzogaW5kaWNhdG9yIGZvciB3aGVuIG5vZGUgY2FuIGRlc2NlbmRcbi8vIHRvZG86IGluZGljYXRvciB3aGVyZSBsZWZ0IGFuZCByaWdodCB3aWxsIGdvXG5leHBvcnQgZnVuY3Rpb24gTW92ZWFibGUoc2VsZWN0b3IpIHtcbiAgaG90a2V5cyhrZXlfZXZlbnRzLCAoZSwge2tleX0pID0+IHtcbiAgICBpZiAoZS5jYW5jZWxCdWJibGUpIHJldHVyblxuICAgICAgXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKVxuICAgIFxuICAgICQoc2VsZWN0b3IpLmZvckVhY2goZWwgPT4ge1xuICAgICAgbW92ZUVsZW1lbnQoZWwsIGtleSlcbiAgICAgIHVwZGF0ZUZlZWRiYWNrKGVsKVxuICAgIH0pXG4gIH0pXG5cbiAgcmV0dXJuICgpID0+IHtcbiAgICBob3RrZXlzLnVuYmluZChrZXlfZXZlbnRzKVxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBtb3ZlRWxlbWVudChlbCwgZGlyZWN0aW9uKSB7XG4gIGlmICghZWwpIHJldHVyblxuXG4gIHN3aXRjaChkaXJlY3Rpb24pIHtcbiAgICBjYXNlICdsZWZ0JzpcbiAgICAgIGlmIChjYW5Nb3ZlTGVmdChlbCkpXG4gICAgICAgIGVsLnBhcmVudE5vZGUuaW5zZXJ0QmVmb3JlKGVsLCBlbC5wcmV2aW91c0VsZW1lbnRTaWJsaW5nKVxuICAgICAgZWxzZVxuICAgICAgICBzaG93RWRnZShlbC5wYXJlbnROb2RlKVxuICAgICAgYnJlYWtcblxuICAgIGNhc2UgJ3JpZ2h0JzpcbiAgICAgIGlmIChjYW5Nb3ZlUmlnaHQoZWwpICYmIGVsLm5leHRFbGVtZW50U2libGluZy5uZXh0U2libGluZylcbiAgICAgICAgZWwucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoZWwsIGVsLm5leHRFbGVtZW50U2libGluZy5uZXh0U2libGluZylcbiAgICAgIGVsc2UgaWYgKGNhbk1vdmVSaWdodChlbCkpXG4gICAgICAgIGVsLnBhcmVudE5vZGUuYXBwZW5kQ2hpbGQoZWwpXG4gICAgICBlbHNlXG4gICAgICAgIHNob3dFZGdlKGVsLnBhcmVudE5vZGUpXG4gICAgICBicmVha1xuXG4gICAgY2FzZSAndXAnOlxuICAgICAgaWYgKGNhbk1vdmVVcChlbCkpXG4gICAgICAgIHBvcE91dCh7ZWx9KVxuICAgICAgYnJlYWtcblxuICAgIGNhc2UgJ2Rvd24nOlxuICAgICAgaWYgKGNhbk1vdmVVbmRlcihlbCkpXG4gICAgICAgIHBvcE91dCh7ZWwsIHVuZGVyOiB0cnVlfSlcbiAgICAgIGVsc2UgaWYgKGNhbk1vdmVEb3duKGVsKSlcbiAgICAgICAgZWwubmV4dEVsZW1lbnRTaWJsaW5nLnByZXBlbmQoZWwpXG4gICAgICBicmVha1xuICB9XG59XG5cbmV4cG9ydCBjb25zdCBjYW5Nb3ZlTGVmdCAgICA9IGVsID0+IGVsLnByZXZpb3VzRWxlbWVudFNpYmxpbmdcbmV4cG9ydCBjb25zdCBjYW5Nb3ZlUmlnaHQgICA9IGVsID0+IGVsLm5leHRFbGVtZW50U2libGluZ1xuZXhwb3J0IGNvbnN0IGNhbk1vdmVEb3duICAgID0gZWwgPT4gZWwubmV4dEVsZW1lbnRTaWJsaW5nICYmIGVsLm5leHRFbGVtZW50U2libGluZy5jaGlsZHJlbi5sZW5ndGhcbmV4cG9ydCBjb25zdCBjYW5Nb3ZlVW5kZXIgICA9IGVsID0+ICFlbC5uZXh0RWxlbWVudFNpYmxpbmcgJiYgZWwucGFyZW50Tm9kZSAmJiBlbC5wYXJlbnROb2RlLnBhcmVudE5vZGVcbmV4cG9ydCBjb25zdCBjYW5Nb3ZlVXAgICAgICA9IGVsID0+IGVsLnBhcmVudE5vZGUgJiYgZWwucGFyZW50Tm9kZS5wYXJlbnROb2RlXG5cbmV4cG9ydCBjb25zdCBwb3BPdXQgPSAoe2VsLCB1bmRlciA9IGZhbHNlfSkgPT5cbiAgZWwucGFyZW50Tm9kZS5wYXJlbnROb2RlLmluc2VydEJlZm9yZShlbCwgXG4gICAgZWwucGFyZW50Tm9kZS5wYXJlbnROb2RlLmNoaWxkcmVuW1xuICAgICAgdW5kZXJcbiAgICAgICAgPyBnZXROb2RlSW5kZXgoZWwpICsgMVxuICAgICAgICA6IGdldE5vZGVJbmRleChlbCldKSBcblxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZUZlZWRiYWNrKGVsKSB7XG4gIGxldCBvcHRpb25zID0gJydcbiAgLy8gZ2V0IGN1cnJlbnQgZWxlbWVudHMgb2Zmc2V0L3NpemVcbiAgaWYgKGNhbk1vdmVMZWZ0KGVsKSkgIG9wdGlvbnMgKz0gJ+KHoCdcbiAgaWYgKGNhbk1vdmVSaWdodChlbCkpIG9wdGlvbnMgKz0gJ+KHoidcbiAgaWYgKGNhbk1vdmVEb3duKGVsKSkgIG9wdGlvbnMgKz0gJ+KHoydcbiAgaWYgKGNhbk1vdmVVcChlbCkpICAgIG9wdGlvbnMgKz0gJ+KHoSdcbiAgLy8gY3JlYXRlL21vdmUgYXJyb3dzIGluIGFic29sdXRlL2ZpeGVkIHRvIG92ZXJsYXkgZWxlbWVudFxuICBvcHRpb25zICYmIGNvbnNvbGUuaW5mbygnJWMnK29wdGlvbnMsIFwiZm9udC1zaXplOiAycmVtO1wiKVxufSIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCB7IGdldFN0eWxlIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxubGV0IGltZ3MgICAgICA9IFtdXG4gICwgb3ZlcmxheXMgID0gW11cblxuZXhwb3J0IGZ1bmN0aW9uIHdhdGNoSW1hZ2VzRm9yVXBsb2FkKCkge1xuICBpbWdzID0gJChbXG4gICAgLi4uZG9jdW1lbnQuaW1hZ2VzLFxuICAgIC4uLmZpbmRCYWNrZ3JvdW5kSW1hZ2VzKGRvY3VtZW50KSxcbiAgXSlcblxuICBjbGVhcldhdGNoZXJzKGltZ3MpXG4gIGluaXRXYXRjaGVycyhpbWdzKVxufVxuXG5jb25zdCBpbml0V2F0Y2hlcnMgPSBpbWdzID0+IHtcbiAgaW1ncy5vbignZHJhZ292ZXInLCBvbkRyYWdFbnRlcilcbiAgaW1ncy5vbignZHJhZ2xlYXZlJywgb25EcmFnTGVhdmUpXG4gIGltZ3Mub24oJ2Ryb3AnLCBvbkRyb3ApXG4gICQoZG9jdW1lbnQuYm9keSkub24oJ2RyYWdvdmVyJywgb25EcmFnRW50ZXIpXG4gICQoZG9jdW1lbnQuYm9keSkub24oJ2RyYWdsZWF2ZScsIG9uRHJhZ0xlYXZlKVxuICAkKGRvY3VtZW50LmJvZHkpLm9uKCdkcm9wJywgb25Ecm9wKVxufVxuXG5jb25zdCBjbGVhcldhdGNoZXJzID0gaW1ncyA9PiB7XG4gIGltZ3Mub2ZmKCdkcmFnZW50ZXInLCBvbkRyYWdFbnRlcilcbiAgaW1ncy5vZmYoJ2RyYWdsZWF2ZScsIG9uRHJhZ0xlYXZlKVxuICBpbWdzLm9mZignZHJvcCcsIG9uRHJvcClcbiAgJChkb2N1bWVudC5ib2R5KS5vZmYoJ2RyYWdlbnRlcicsIG9uRHJhZ0VudGVyKVxuICAkKGRvY3VtZW50LmJvZHkpLm9mZignZHJhZ2xlYXZlJywgb25EcmFnTGVhdmUpXG4gICQoZG9jdW1lbnQuYm9keSkub2ZmKCdkcm9wJywgb25Ecm9wKVxuICBpbWdzID0gW11cbn1cblxuY29uc3QgcHJldmlld0ZpbGUgPSBmaWxlID0+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBsZXQgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKVxuICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGZpbGUpXG4gICAgcmVhZGVyLm9ubG9hZGVuZCA9ICgpID0+IHJlc29sdmUocmVhZGVyLnJlc3VsdClcbiAgfSlcbn1cblxuY29uc3Qgb25EcmFnRW50ZXIgPSBlID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gIGNvbnN0IHByZV9zZWxlY3RlZCA9ICQoJ2ltZ1tkYXRhLXNlbGVjdGVkPXRydWVdJylcblxuICBpZiAoIXByZV9zZWxlY3RlZC5sZW5ndGgpXG4gICAgc2hvd092ZXJsYXkoZS5jdXJyZW50VGFyZ2V0LCAwKVxuICBlbHNlXG4gICAgcHJlX3NlbGVjdGVkLmZvckVhY2goKGltZywgaSkgPT5cbiAgICAgIHNob3dPdmVybGF5KGltZywgaSkpXG59XG5cbmNvbnN0IG9uRHJhZ0xlYXZlID0gZSA9PiBcbiAgaGlkZU92ZXJsYXlzKClcblxuY29uc3Qgb25Ecm9wID0gYXN5bmMgZSA9PiB7XG4gIGUuc3RvcFByb3BhZ2F0aW9uKClcbiAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgY29uc3Qgc2VsZWN0ZWRJbWFnZXMgPSAkKCdpbWdbZGF0YS1zZWxlY3RlZD10cnVlXScpXG5cbiAgY29uc3Qgc3JjcyA9IGF3YWl0IFByb21pc2UuYWxsKFxuICAgIFsuLi5lLmRhdGFUcmFuc2Zlci5maWxlc10ubWFwKHByZXZpZXdGaWxlKSlcbiAgXG4gIGlmICghc2VsZWN0ZWRJbWFnZXMubGVuZ3RoKVxuICAgIGlmIChlLnRhcmdldC5ub2RlTmFtZSA9PT0gJ0lNRycpXG4gICAgICBlLnRhcmdldC5zcmMgPSBzcmNzWzBdXG4gICAgZWxzZVxuICAgICAgaW1nc1xuICAgICAgICAuZmlsdGVyKGltZyA9PiBpbWcuY29udGFpbnMoZS50YXJnZXQpKVxuICAgICAgICAuZm9yRWFjaChpbWcgPT4gXG4gICAgICAgICAgaW1nLnN0eWxlLmJhY2tncm91bmRJbWFnZSA9IGB1cmwoJHtzcmNzWzBdfSlgKVxuICBlbHNlIGlmIChzZWxlY3RlZEltYWdlcy5sZW5ndGgpIHtcbiAgICBsZXQgaSA9IDBcbiAgICBzZWxlY3RlZEltYWdlcy5mb3JFYWNoKGltZyA9PiB7XG4gICAgICBpbWcuc3JjID0gc3Jjc1tpKytdXG4gICAgICBpZiAoaSA+PSBzcmNzLmxlbmd0aCkgaSA9IDBcbiAgICB9KVxuICB9XG5cbiAgaGlkZU92ZXJsYXlzKClcbn1cblxuY29uc3Qgc2hvd092ZXJsYXkgPSAobm9kZSwgaSkgPT4ge1xuICBjb25zdCByZWN0ICAgID0gbm9kZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKVxuICBjb25zdCBvdmVybGF5ID0gb3ZlcmxheXNbaV1cblxuICBpZiAob3ZlcmxheSkge1xuICAgIG92ZXJsYXkudXBkYXRlID0gcmVjdFxuICB9XG4gIGVsc2Uge1xuICAgIG92ZXJsYXlzW2ldID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgncGItb3ZlcmxheScpXG4gICAgb3ZlcmxheXNbaV0ucG9zaXRpb24gPSByZWN0XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChvdmVybGF5c1tpXSlcbiAgfVxufVxuXG5jb25zdCBoaWRlT3ZlcmxheXMgPSAoKSA9PiB7XG4gIG92ZXJsYXlzLmZvckVhY2gob3ZlcmxheSA9PlxuICAgIG92ZXJsYXkucmVtb3ZlKCkpXG4gIG92ZXJsYXlzID0gW11cbn1cblxuY29uc3QgZmluZEJhY2tncm91bmRJbWFnZXMgPSBlbCA9PiB7XG4gIGNvbnN0IHNyY19yZWdleCA9IC91cmxcXChcXHMqP1snXCJdP1xccyo/KFxcUys/KVxccyo/W1wiJ10/XFxzKj9cXCkvaVxuXG4gIHJldHVybiAkKCcqJykucmVkdWNlKChjb2xsZWN0aW9uLCBub2RlKSA9PiB7XG4gICAgY29uc3QgcHJvcCA9IGdldFN0eWxlKG5vZGUsICdiYWNrZ3JvdW5kLWltYWdlJylcbiAgICBjb25zdCBtYXRjaCA9IHNyY19yZWdleC5leGVjKHByb3ApXG5cbiAgICAvLyBpZiAobWF0Y2gpIGNvbGxlY3Rpb24ucHVzaChtYXRjaFsxXSlcbiAgICBpZiAobWF0Y2gpIGNvbGxlY3Rpb24ucHVzaChub2RlKVxuXG4gICAgcmV0dXJuIGNvbGxlY3Rpb25cbiAgfSwgW10pXG59IiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcblxubGV0IFNlbGVjdG9yRW5naW5lXG5cbi8vIGNyZWF0ZSBpbnB1dFxuY29uc3Qgc2VhcmNoX2Jhc2UgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuc2VhcmNoX2Jhc2UuY2xhc3NMaXN0LmFkZCgnc2VhcmNoJylcbnNlYXJjaF9iYXNlLmlubmVySFRNTCA9IGA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cImV4OiBpbWFnZXMsIC5idG4sIGJ1dHRvbiwgdGV4dCwgLi4uXCIvPmBcblxuY29uc3Qgc2VhcmNoICAgICAgICA9ICQoc2VhcmNoX2Jhc2UpXG5jb25zdCBzZWFyY2hJbnB1dCAgID0gJCgnaW5wdXQnLCBzZWFyY2hfYmFzZSlcblxuY29uc3Qgc2hvd1NlYXJjaEJhciA9ICgpID0+IHNlYXJjaC5hdHRyKCdzdHlsZScsICdkaXNwbGF5OmJsb2NrJylcbmNvbnN0IGhpZGVTZWFyY2hCYXIgPSAoKSA9PiBzZWFyY2guYXR0cignc3R5bGUnLCAnZGlzcGxheTpub25lJylcbmNvbnN0IHN0b3BCdWJibGluZyAgPSBlID0+IGUua2V5ICE9ICdFc2NhcGUnICYmIGUuc3RvcFByb3BhZ2F0aW9uKClcblxuZXhwb3J0IGZ1bmN0aW9uIFNlYXJjaChub2RlKSB7XG4gIGlmIChub2RlKSBub2RlWzBdLmFwcGVuZENoaWxkKHNlYXJjaFswXSlcblxuICBjb25zdCBvblF1ZXJ5ID0gZSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKVxuXG4gICAgY29uc3QgcXVlcnkgPSBlLnRhcmdldC52YWx1ZVxuXG4gICAgd2luZG93LnJlcXVlc3RJZGxlQ2FsbGJhY2soXyA9PlxuICAgICAgcXVlcnlQYWdlKHF1ZXJ5KSlcbiAgfVxuXG4gIHNlYXJjaElucHV0Lm9uKCdpbnB1dCcsIG9uUXVlcnkpXG4gIHNlYXJjaElucHV0Lm9uKCdrZXlkb3duJywgc3RvcEJ1YmJsaW5nKVxuICAvLyBzZWFyY2hJbnB1dC5vbignYmx1cicsIGhpZGVTZWFyY2hCYXIpXG5cbiAgc2hvd1NlYXJjaEJhcigpXG4gIHNlYXJjaElucHV0WzBdLmZvY3VzKClcblxuICAvLyBob3RrZXlzKCdlc2NhcGUsZXNjJywgKGUsIGhhbmRsZXIpID0+IHtcbiAgLy8gICBoaWRlU2VhcmNoQmFyKClcbiAgLy8gICBob3RrZXlzLnVuYmluZCgnZXNjYXBlLGVzYycpXG4gIC8vIH0pXG5cbiAgcmV0dXJuICgpID0+IHtcbiAgICBoaWRlU2VhcmNoQmFyKClcbiAgICBzZWFyY2hJbnB1dC5vZmYoJ29uaW5wdXQnLCBvblF1ZXJ5KVxuICAgIHNlYXJjaElucHV0Lm9mZigna2V5ZG93bicsIHN0b3BCdWJibGluZylcbiAgICBzZWFyY2hJbnB1dC5vZmYoJ2JsdXInLCBoaWRlU2VhcmNoQmFyKVxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwcm92aWRlU2VsZWN0b3JFbmdpbmUoRW5naW5lKSB7XG4gIFNlbGVjdG9yRW5naW5lID0gRW5naW5lXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBxdWVyeVBhZ2UocXVlcnksIGZuKSB7XG4gIGlmIChxdWVyeSA9PSAnbGlua3MnKSAgICAgcXVlcnkgPSAnYSdcbiAgaWYgKHF1ZXJ5ID09ICdidXR0b25zJykgICBxdWVyeSA9ICdidXR0b24nXG4gIGlmIChxdWVyeSA9PSAnaW1hZ2VzJykgICAgcXVlcnkgPSAnaW1nJ1xuICBpZiAocXVlcnkgPT0gJ3RleHQnKSAgICAgIHF1ZXJ5ID0gJ3AsY2FwdGlvbixhLGgxLGgyLGgzLGg0LGg1LGg2LHNtYWxsLGRhdGUsdGltZSxsaSxkdCxkZCdcblxuICBpZiAoIXF1ZXJ5KSByZXR1cm4gU2VsZWN0b3JFbmdpbmUudW5zZWxlY3RfYWxsKClcbiAgaWYgKHF1ZXJ5ID09ICcuJyB8fCBxdWVyeSA9PSAnIycgfHwgcXVlcnkudHJpbSgpLmVuZHNXaXRoKCcsJykpIHJldHVyblxuXG4gIHRyeSB7XG4gICAgbGV0IG1hdGNoZXMgPSAkKHF1ZXJ5ICsgJzpub3QodG9vbC1wYWxsZXRlKTpub3Qoc2NyaXB0KTpub3QoaG90a2V5LW1hcCk6bm90KC5wYi1tZXRhdGlwKTpub3QocGItbGFiZWwpOm5vdChwYi1oYW5kbGVzKScpXG4gICAgaWYgKCFtYXRjaGVzLmxlbmd0aCkgbWF0Y2hlcyA9ICQocXVlcnkpXG4gICAgaWYgKCFmbikgU2VsZWN0b3JFbmdpbmUudW5zZWxlY3RfYWxsKClcbiAgICBpZiAobWF0Y2hlcy5sZW5ndGgpXG4gICAgICBtYXRjaGVzLmZvckVhY2goZWwgPT5cbiAgICAgICAgZm5cbiAgICAgICAgICA/IGZuKGVsKVxuICAgICAgICAgIDogU2VsZWN0b3JFbmdpbmUuc2VsZWN0KGVsKSlcbiAgfVxuICBjYXRjaCAoZXJyKSB7fVxufSIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5cbmltcG9ydCB7IGNhbk1vdmVMZWZ0LCBjYW5Nb3ZlUmlnaHQsIGNhbk1vdmVVcCB9IGZyb20gJy4vbW92ZSdcbmltcG9ydCB7IHdhdGNoSW1hZ2VzRm9yVXBsb2FkIH0gZnJvbSAnLi9pbWFnZXN3YXAnXG5pbXBvcnQgeyBxdWVyeVBhZ2UgfSBmcm9tICcuL3NlYXJjaCdcbmltcG9ydCB7IG1ldGFLZXksIGh0bWxTdHJpbmdUb0RvbSwgY3JlYXRlQ2xhc3NuYW1lLCBpc09mZkJvdW5kcywgZ2V0U3R5bGVzIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuZXhwb3J0IGZ1bmN0aW9uIFNlbGVjdGFibGUoKSB7XG4gIGNvbnN0IGVsZW1lbnRzICAgICAgICAgID0gJCgnYm9keScpXG4gIGxldCBzZWxlY3RlZCAgICAgICAgICAgID0gW11cbiAgbGV0IHNlbGVjdGVkQ2FsbGJhY2tzICAgPSBbXVxuICBsZXQgbGFiZWxzICAgICAgICAgICAgICA9IFtdXG4gIGxldCBoYW5kbGVzICAgICAgICAgICAgID0gW11cblxuICBjb25zdCBsaXN0ZW4gPSAoKSA9PiB7XG4gICAgZWxlbWVudHMuZm9yRWFjaChlbCA9PiBlbC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIG9uX2NsaWNrLCB0cnVlKSlcbiAgICBlbGVtZW50cy5mb3JFYWNoKGVsID0+IGVsLmFkZEV2ZW50TGlzdGVuZXIoJ2RibGNsaWNrJywgb25fZGJsY2xpY2ssIHRydWUpKVxuICAgIGVsZW1lbnRzLm9uKCdzZWxlY3RzdGFydCcsIG9uX3NlbGVjdGlvbilcbiAgICBlbGVtZW50cy5vbignbW91c2VvdmVyJywgb25faG92ZXIpXG4gICAgZWxlbWVudHMub24oJ21vdXNlb3V0Jywgb25faG92ZXJvdXQpXG5cbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjb3B5Jywgb25fY29weSlcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjdXQnLCBvbl9jdXQpXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigncGFzdGUnLCBvbl9wYXN0ZSlcblxuICAgIHdhdGNoQ29tbWFuZEtleSgpXG5cbiAgICBob3RrZXlzKGAke21ldGFLZXl9K2FsdCtjYCwgb25fY29weV9zdHlsZXMpXG4gICAgaG90a2V5cyhgJHttZXRhS2V5fSthbHQrdmAsIGUgPT4gb25fcGFzdGVfc3R5bGVzKCkpXG4gICAgaG90a2V5cygnZXNjJywgb25fZXNjKVxuICAgIGhvdGtleXMoYCR7bWV0YUtleX0rZGAsIG9uX2R1cGxpY2F0ZSlcbiAgICBob3RrZXlzKCdiYWNrc3BhY2UsZGVsLGRlbGV0ZScsIG9uX2RlbGV0ZSlcbiAgICBob3RrZXlzKCdhbHQrZGVsLGFsdCtiYWNrc3BhY2UnLCBvbl9jbGVhcnN0eWxlcylcbiAgICBob3RrZXlzKGAke21ldGFLZXl9K2UsJHttZXRhS2V5fStzaGlmdCtlYCwgb25fZXhwYW5kX3NlbGVjdGlvbilcbiAgICBob3RrZXlzKGAke21ldGFLZXl9K2csJHttZXRhS2V5fStzaGlmdCtnYCwgb25fZ3JvdXApXG4gICAgaG90a2V5cygndGFiLHNoaWZ0K3RhYixlbnRlcixzaGlmdCtlbnRlcicsIG9uX2tleWJvYXJkX3RyYXZlcnNhbClcbiAgfVxuXG4gIGNvbnN0IHVubGlzdGVuID0gKCkgPT4ge1xuICAgIGVsZW1lbnRzLmZvckVhY2goZWwgPT4gZWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignY2xpY2snLCBvbl9jbGljaywgdHJ1ZSkpXG4gICAgZWxlbWVudHMuZm9yRWFjaChlbCA9PiBlbC5yZW1vdmVFdmVudExpc3RlbmVyKCdkYmxjbGljaycsIG9uX2RibGNsaWNrLCB0cnVlKSlcbiAgICBlbGVtZW50cy5vZmYoJ3NlbGVjdHN0YXJ0Jywgb25fc2VsZWN0aW9uKVxuICAgIGVsZW1lbnRzLm9mZignbW91c2VvdmVyJywgb25faG92ZXIpXG4gICAgZWxlbWVudHMub2ZmKCdtb3VzZW91dCcsIG9uX2hvdmVyb3V0KVxuXG4gICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignY29weScsIG9uX2NvcHkpXG4gICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignY3V0Jywgb25fY3V0KVxuICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Bhc3RlJywgb25fcGFzdGUpXG5cbiAgICBob3RrZXlzLnVuYmluZChgZXNjLCR7bWV0YUtleX0rZCxiYWNrc3BhY2UsZGVsLGRlbGV0ZSxhbHQrZGVsLGFsdCtiYWNrc3BhY2UsJHttZXRhS2V5fStlLCR7bWV0YUtleX0rc2hpZnQrZSwke21ldGFLZXl9K2csJHttZXRhS2V5fStzaGlmdCtnLHRhYixzaGlmdCt0YWIsZW50ZXIsc2hpZnQrZW50ZXJgKVxuICB9XG5cbiAgY29uc3Qgb25fY2xpY2sgPSBlID0+IHtcbiAgICBpZiAoaXNPZmZCb3VuZHMoZS50YXJnZXQpICYmICFzZWxlY3RlZC5maWx0ZXIoZWwgPT4gZWwgPT0gZS50YXJnZXQpLmxlbmd0aClcbiAgICAgIHJldHVyblxuXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgaWYgKCFlLmFsdEtleSkgZS5zdG9wUHJvcGFnYXRpb24oKVxuICAgIGlmICghZS5zaGlmdEtleSkgdW5zZWxlY3RfYWxsKClcblxuICAgIGlmKGUuc2hpZnRLZXkgJiYgZS50YXJnZXQuaGFzQXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJykpXG4gICAgICB1bnNlbGVjdChlLnRhcmdldC5nZXRBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnKSlcbiAgICBlbHNlXG4gICAgc2VsZWN0KGUudGFyZ2V0KVxuICB9XG5cbiAgY29uc3QgdW5zZWxlY3QgPSBpZCA9PiB7XG5cbiAgICBbLi4ubGFiZWxzLCAuLi5oYW5kbGVzXVxuICAgICAgLmZpbHRlcihub2RlID0+XG4gICAgICAgICAgbm9kZS5nZXRBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnKSA9PT0gaWQpXG4gICAgICAgIC5mb3JFYWNoKG5vZGUgPT5cbiAgICAgICAgICBub2RlLnJlbW92ZSgpKVxuXG4gICAgc2VsZWN0ZWQuZmlsdGVyKG5vZGUgPT5cbiAgICAgIG5vZGUuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJykgPT09IGlkKVxuICAgICAgLmZvckVhY2gobm9kZSA9PlxuICAgICAgICAkKG5vZGUpLmF0dHIoe1xuICAgICAgICAgICdkYXRhLXNlbGVjdGVkJzogICAgICBudWxsLFxuICAgICAgICAgICdkYXRhLXNlbGVjdGVkLWhpZGUnOiBudWxsLFxuICAgICAgICAgICdkYXRhLWxhYmVsLWlkJzogICAgICBudWxsLFxuICAgICAgICAgICdkYXRhLWhvdmVyJzogbnVsbFxuICAgICAgfSkpXG5cbiAgICBzZWxlY3RlZCA9IHNlbGVjdGVkLmZpbHRlcihub2RlID0+IG5vZGUuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJykgIT09IGlkKVxuXG4gICAgdGVsbFdhdGNoZXJzKClcbiAgfVxuXG4gIGNvbnN0IG9uX2RibGNsaWNrID0gZSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKVxuICAgIGlmIChpc09mZkJvdW5kcyhlLnRhcmdldCkpIHJldHVyblxuICAgICQoJ3Rvb2wtcGFsbGV0ZScpWzBdLnRvb2xTZWxlY3RlZCgndGV4dCcpXG4gIH1cblxuICBjb25zdCB3YXRjaENvbW1hbmRLZXkgPSBlID0+IHtcbiAgICBsZXQgZGlkX2hpZGUgPSBmYWxzZVxuXG4gICAgZG9jdW1lbnQub25rZXlkb3duID0gZnVuY3Rpb24oZSkge1xuICAgICAgaWYgKGhvdGtleXMuY3RybCAmJiBzZWxlY3RlZC5sZW5ndGgpIHtcbiAgICAgICAgJCgncGItaGFuZGxlcywgcGItbGFiZWwnKS5mb3JFYWNoKGVsID0+XG4gICAgICAgICAgZWwuc3R5bGUuZGlzcGxheSA9ICdub25lJylcblxuICAgICAgICBkaWRfaGlkZSA9IHRydWVcbiAgICAgIH1cbiAgICB9XG5cbiAgICBkb2N1bWVudC5vbmtleXVwID0gZnVuY3Rpb24oZSkge1xuICAgICAgaWYgKGRpZF9oaWRlKSB7XG4gICAgICAgICQoJ3BiLWhhbmRsZXMsIHBiLWxhYmVsJykuZm9yRWFjaChlbCA9PlxuICAgICAgICAgIGVsLnN0eWxlLmRpc3BsYXkgPSBudWxsKVxuXG4gICAgICAgIGRpZF9oaWRlID0gZmFsc2VcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjb25zdCBvbl9lc2MgPSBfID0+XG4gICAgc2VsZWN0ZWQubGVuZ3RoICYmIHVuc2VsZWN0X2FsbCgpXG5cbiAgY29uc3Qgb25fZHVwbGljYXRlID0gZSA9PiB7XG4gICAgY29uc3Qgcm9vdF9ub2RlID0gc2VsZWN0ZWRbMF1cbiAgICBpZiAoIXJvb3Rfbm9kZSkgcmV0dXJuXG5cbiAgICBjb25zdCBkZWVwX2Nsb25lID0gcm9vdF9ub2RlLmNsb25lTm9kZSh0cnVlKVxuICAgIGRlZXBfY2xvbmUucmVtb3ZlQXR0cmlidXRlKCdkYXRhLXNlbGVjdGVkJylcbiAgICByb290X25vZGUucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoZGVlcF9jbG9uZSwgcm9vdF9ub2RlLm5leHRTaWJsaW5nKVxuICAgIGUucHJldmVudERlZmF1bHQoKVxuICB9XG5cbiAgY29uc3Qgb25fZGVsZXRlID0gZSA9PlxuICAgIHNlbGVjdGVkLmxlbmd0aCAmJiBkZWxldGVfYWxsKClcblxuICBjb25zdCBvbl9jbGVhcnN0eWxlcyA9IGUgPT5cbiAgICBzZWxlY3RlZC5mb3JFYWNoKGVsID0+XG4gICAgICBlbC5hdHRyKCdzdHlsZScsIG51bGwpKVxuXG4gIGNvbnN0IG9uX2NvcHkgPSBlID0+IHtcbiAgICAvLyBpZiB1c2VyIGhhcyBzZWxlY3RlZCB0ZXh0LCBkb250IHRyeSB0byBjb3B5IGFuIGVsZW1lbnRcbiAgICBpZiAod2luZG93LmdldFNlbGVjdGlvbigpLnRvU3RyaW5nKCkubGVuZ3RoKVxuICAgICAgcmV0dXJuXG5cbiAgICBpZiAoc2VsZWN0ZWRbMF0gJiYgdGhpcy5ub2RlX2NsaXBib2FyZCAhPT0gc2VsZWN0ZWRbMF0pIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgbGV0ICRub2RlID0gc2VsZWN0ZWRbMF0uY2xvbmVOb2RlKHRydWUpXG4gICAgICAkbm9kZS5yZW1vdmVBdHRyaWJ1dGUoJ2RhdGEtc2VsZWN0ZWQnKVxuICAgICAgdGhpcy5jb3B5X2JhY2t1cCA9ICRub2RlLm91dGVySFRNTFxuICAgICAgZS5jbGlwYm9hcmREYXRhLnNldERhdGEoJ3RleHQvaHRtbCcsIHRoaXMuY29weV9iYWNrdXApXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgb25fY3V0ID0gZSA9PiB7XG4gICAgaWYgKHNlbGVjdGVkWzBdICYmIHRoaXMubm9kZV9jbGlwYm9hcmQgIT09IHNlbGVjdGVkWzBdKSB7XG4gICAgICBsZXQgJG5vZGUgPSBzZWxlY3RlZFswXS5jbG9uZU5vZGUodHJ1ZSlcbiAgICAgICRub2RlLnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1zZWxlY3RlZCcpXG4gICAgICB0aGlzLmNvcHlfYmFja3VwID0gJG5vZGUub3V0ZXJIVE1MXG4gICAgICBlLmNsaXBib2FyZERhdGEuc2V0RGF0YSgndGV4dC9odG1sJywgdGhpcy5jb3B5X2JhY2t1cClcbiAgICAgIHNlbGVjdGVkWzBdLnJlbW92ZSgpXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgb25fcGFzdGUgPSBlID0+IHtcbiAgICBjb25zdCBjbGlwRGF0YSA9IGUuY2xpcGJvYXJkRGF0YS5nZXREYXRhKCd0ZXh0L2h0bWwnKVxuICAgIGNvbnN0IHBvdGVudGlhbEhUTUwgPSBjbGlwRGF0YSB8fCB0aGlzLmNvcHlfYmFja3VwXG4gICAgaWYgKHNlbGVjdGVkWzBdICYmIHBvdGVudGlhbEhUTUwpIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgc2VsZWN0ZWRbMF0uYXBwZW5kQ2hpbGQoXG4gICAgICAgIGh0bWxTdHJpbmdUb0RvbShwb3RlbnRpYWxIVE1MKSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBvbl9jb3B5X3N0eWxlcyA9IGUgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHRoaXMuY29waWVkX3N0eWxlcyA9IHNlbGVjdGVkLm1hcChlbCA9PlxuICAgICAgZ2V0U3R5bGVzKGVsKSlcbiAgfVxuXG4gIGNvbnN0IG9uX3Bhc3RlX3N0eWxlcyA9IChpbmRleCA9IDApID0+XG4gICAgc2VsZWN0ZWQuZm9yRWFjaChlbCA9PiB7XG4gICAgICB0aGlzLmNvcGllZF9zdHlsZXNbaW5kZXhdXG4gICAgICAgIC5tYXAoKHtwcm9wLCB2YWx1ZX0pID0+XG4gICAgICAgICAgZWwuc3R5bGVbcHJvcF0gPSB2YWx1ZSlcblxuICAgICAgaW5kZXggPj0gdGhpcy5jb3BpZWRfc3R5bGVzLmxlbmd0aCAtIDFcbiAgICAgICAgPyBpbmRleCA9IDBcbiAgICAgICAgOiBpbmRleCsrXG4gICAgfSlcblxuICBjb25zdCBvbl9leHBhbmRfc2VsZWN0aW9uID0gKGUsIHtrZXl9KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICBleHBhbmRTZWxlY3Rpb24oe1xuICAgICAgcXVlcnk6ICBjb21iaW5lTm9kZU5hbWVBbmRDbGFzcyhzZWxlY3RlZFswXSksXG4gICAgICBhbGw6ICAgIGtleS5pbmNsdWRlcygnc2hpZnQnKSxcbiAgICB9KVxuICB9XG5cbiAgY29uc3Qgb25fZ3JvdXAgPSAoZSwge2tleX0pID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcblxuICAgIGlmIChrZXkuc3BsaXQoJysnKS5pbmNsdWRlcygnc2hpZnQnKSkge1xuICAgICAgbGV0ICRzZWxlY3RlZCA9IFsuLi5zZWxlY3RlZF1cbiAgICAgIHVuc2VsZWN0X2FsbCgpXG4gICAgICAkc2VsZWN0ZWQucmV2ZXJzZSgpLmZvckVhY2goZWwgPT4ge1xuICAgICAgICBsZXQgbCA9IGVsLmNoaWxkcmVuLmxlbmd0aFxuICAgICAgICB3aGlsZSAoZWwuY2hpbGRyZW4ubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHZhciBub2RlID0gZWwuY2hpbGROb2Rlc1tlbC5jaGlsZHJlbi5sZW5ndGggLSAxXVxuICAgICAgICAgIGlmIChub2RlLm5vZGVOYW1lICE9PSAnI3RleHQnKVxuICAgICAgICAgICAgc2VsZWN0KG5vZGUpXG4gICAgICAgICAgZWwucGFyZW50Tm9kZS5wcmVwZW5kKG5vZGUpXG4gICAgICAgIH1cbiAgICAgICAgZWwucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChlbClcbiAgICAgIH0pXG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgbGV0IGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgICBzZWxlY3RlZFswXS5wYXJlbnROb2RlLnByZXBlbmQoXG4gICAgICAgIHNlbGVjdGVkLnJldmVyc2UoKS5yZWR1Y2UoKGRpdiwgZWwpID0+IHtcbiAgICAgICAgICBkaXYuYXBwZW5kQ2hpbGQoZWwpXG4gICAgICAgICAgcmV0dXJuIGRpdlxuICAgICAgICB9LCBkaXYpXG4gICAgICApXG4gICAgICB1bnNlbGVjdF9hbGwoKVxuICAgICAgc2VsZWN0KGRpdilcbiAgICB9XG4gIH1cblxuICBjb25zdCBvbl9zZWxlY3Rpb24gPSBlID0+XG4gICAgIWlzT2ZmQm91bmRzKGUudGFyZ2V0KVxuICAgICYmIHNlbGVjdGVkLmxlbmd0aFxuICAgICYmIHNlbGVjdGVkWzBdLnRleHRDb250ZW50ICE9IGUudGFyZ2V0LnRleHRDb250ZW50XG4gICAgJiYgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgY29uc3Qgb25fa2V5Ym9hcmRfdHJhdmVyc2FsID0gKGUsIHtrZXl9KSA9PiB7XG4gICAgaWYgKHNlbGVjdGVkLmxlbmd0aCAhPT0gMSkgcmV0dXJuXG5cbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG5cbiAgICBjb25zdCBjdXJyZW50ID0gc2VsZWN0ZWRbMF1cblxuICAgIGlmIChrZXkuaW5jbHVkZXMoJ3NoaWZ0JykpIHtcbiAgICAgIGlmIChrZXkuaW5jbHVkZXMoJ3RhYicpICYmIGNhbk1vdmVMZWZ0KGN1cnJlbnQpKSB7XG4gICAgICAgIHVuc2VsZWN0X2FsbCgpXG4gICAgICAgIHNlbGVjdChjYW5Nb3ZlTGVmdChjdXJyZW50KSlcbiAgICAgIH1cbiAgICAgIGlmIChrZXkuaW5jbHVkZXMoJ2VudGVyJykgJiYgY2FuTW92ZVVwKGN1cnJlbnQpKSB7XG4gICAgICAgIHVuc2VsZWN0X2FsbCgpXG4gICAgICAgIHNlbGVjdChjdXJyZW50LnBhcmVudE5vZGUpXG4gICAgICB9XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgaWYgKGtleS5pbmNsdWRlcygndGFiJykgJiYgY2FuTW92ZVJpZ2h0KGN1cnJlbnQpKSB7XG4gICAgICAgIHVuc2VsZWN0X2FsbCgpXG4gICAgICAgIHNlbGVjdChjYW5Nb3ZlUmlnaHQoY3VycmVudCkpXG4gICAgICB9XG4gICAgICBpZiAoa2V5LmluY2x1ZGVzKCdlbnRlcicpICYmIGN1cnJlbnQuY2hpbGRyZW4ubGVuZ3RoKSB7XG4gICAgICAgIHVuc2VsZWN0X2FsbCgpXG4gICAgICAgIHNlbGVjdChjdXJyZW50LmNoaWxkcmVuWzBdKVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IG9uX2hvdmVyID0gKHt0YXJnZXR9KSA9PiB7XG4gICAgaWYgKGlzT2ZmQm91bmRzKHRhcmdldCkpIHJldHVyblxuICAgIHRhcmdldC5zZXRBdHRyaWJ1dGUoJ2RhdGEtaG92ZXInLCB0cnVlKVxuICB9XG5cbiAgY29uc3Qgb25faG92ZXJvdXQgPSAoe3RhcmdldH0pID0+IHtcbiAgICB0YXJnZXQucmVtb3ZlQXR0cmlidXRlKCdkYXRhLWhvdmVyJylcbiAgfVxuXG4gIGNvbnN0IHNlbGVjdCA9IGVsID0+IHtcbiAgICBlbC5zZXRBdHRyaWJ1dGUoJ2RhdGEtc2VsZWN0ZWQnLCB0cnVlKVxuICAgIG92ZXJsYXlNZXRhVUkoZWwpXG4gICAgc2VsZWN0ZWQudW5zaGlmdChlbClcbiAgICB0ZWxsV2F0Y2hlcnMoKVxuICB9XG5cbiAgY29uc3QgdW5zZWxlY3RfYWxsID0gKCkgPT4ge1xuICAgIHNlbGVjdGVkXG4gICAgICAuZm9yRWFjaChlbCA9PlxuICAgICAgICAkKGVsKS5hdHRyKHtcbiAgICAgICAgICAnZGF0YS1zZWxlY3RlZCc6ICAgICAgbnVsbCxcbiAgICAgICAgICAnZGF0YS1zZWxlY3RlZC1oaWRlJzogbnVsbCxcbiAgICAgICAgICAnZGF0YS1sYWJlbC1pZCc6ICAgICAgbnVsbCxcbiAgICAgICAgICAnZGF0YS1ob3Zlcic6ICAgICAgICAgbnVsbCxcbiAgICAgICAgfSkpXG5cbiAgICBoYW5kbGVzLmZvckVhY2goZWwgPT5cbiAgICAgIGVsLnJlbW92ZSgpKVxuXG4gICAgbGFiZWxzLmZvckVhY2goZWwgPT5cbiAgICAgIGVsLnJlbW92ZSgpKVxuXG4gICAgbGFiZWxzICAgID0gW11cbiAgICBoYW5kbGVzICAgPSBbXVxuICAgIHNlbGVjdGVkICA9IFtdXG4gIH1cblxuICBjb25zdCBkZWxldGVfYWxsID0gKCkgPT4ge1xuICAgIGNvbnN0IHNlbGVjdGVkX2FmdGVyX2RlbGV0ZSA9IHNlbGVjdGVkLm1hcChlbCA9PiB7XG4gICAgICBpZiAoY2FuTW92ZVJpZ2h0KGVsKSkgICAgIHJldHVybiBjYW5Nb3ZlUmlnaHQoZWwpXG4gICAgICBlbHNlIGlmIChjYW5Nb3ZlTGVmdChlbCkpIHJldHVybiBjYW5Nb3ZlTGVmdChlbClcbiAgICAgIGVsc2UgaWYgKGVsLnBhcmVudE5vZGUpICAgcmV0dXJuIGVsLnBhcmVudE5vZGVcbiAgICB9KVxuXG4gICAgQXJyYXkuZnJvbShbLi4uc2VsZWN0ZWQsIC4uLmxhYmVscywgLi4uaGFuZGxlc10pLmZvckVhY2goZWwgPT5cbiAgICAgIGVsLnJlbW92ZSgpKVxuXG4gICAgbGFiZWxzICAgID0gW11cbiAgICBoYW5kbGVzICAgPSBbXVxuICAgIHNlbGVjdGVkICA9IFtdXG5cbiAgICBzZWxlY3RlZF9hZnRlcl9kZWxldGUuZm9yRWFjaChlbCA9PlxuICAgICAgc2VsZWN0KGVsKSlcbiAgfVxuXG4gIGNvbnN0IGV4cGFuZFNlbGVjdGlvbiA9ICh7cXVlcnksIGFsbCA9IGZhbHNlfSkgPT4ge1xuICAgIGlmIChhbGwpIHtcbiAgICAgIGNvbnN0IHVuc2VsZWN0ZWRzID0gJChxdWVyeSArICc6bm90KFtkYXRhLXNlbGVjdGVkXSknKVxuICAgICAgdW5zZWxlY3RlZHMuZm9yRWFjaChzZWxlY3QpXG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgY29uc3QgcG90ZW50aWFscyA9ICQocXVlcnkpXG4gICAgICBpZiAoIXBvdGVudGlhbHMpIHJldHVyblxuXG4gICAgICBjb25zdCByb290X25vZGVfaW5kZXggPSBwb3RlbnRpYWxzLnJlZHVjZSgoaW5kZXgsIG5vZGUsIGkpID0+XG4gICAgICAgIGNvbWJpbmVOb2RlTmFtZUFuZENsYXNzKG5vZGUpID09IHF1ZXJ5XG4gICAgICAgICAgPyBpbmRleCA9IGlcbiAgICAgICAgICA6IGluZGV4XG4gICAgICAsIG51bGwpXG5cbiAgICAgIGlmIChyb290X25vZGVfaW5kZXggIT09IG51bGwpIHtcbiAgICAgICAgaWYgKCFwb3RlbnRpYWxzW3Jvb3Rfbm9kZV9pbmRleCArIDFdKSB7XG4gICAgICAgICAgY29uc3QgcG90ZW50aWFsID0gcG90ZW50aWFscy5maWx0ZXIoZWwgPT4gIWVsLmF0dHIoJ2RhdGEtc2VsZWN0ZWQnKSlbMF1cbiAgICAgICAgICBpZiAocG90ZW50aWFsKSBzZWxlY3QocG90ZW50aWFsKVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgIHNlbGVjdChwb3RlbnRpYWxzW3Jvb3Rfbm9kZV9pbmRleCArIDFdKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgY29uc3QgY29tYmluZU5vZGVOYW1lQW5kQ2xhc3MgPSBub2RlID0+XG4gICAgYCR7bm9kZS5ub2RlTmFtZS50b0xvd2VyQ2FzZSgpfSR7Y3JlYXRlQ2xhc3NuYW1lKG5vZGUpfWBcblxuICBjb25zdCBvdmVybGF5TWV0YVVJID0gZWwgPT4ge1xuICAgIGxldCBoYW5kbGUgPSBjcmVhdGVIYW5kbGUoZWwpXG4gICAgbGV0IGxhYmVsICA9IGNyZWF0ZUxhYmVsKGVsLCBgXG4gICAgICA8YT4ke2VsLm5vZGVOYW1lLnRvTG93ZXJDYXNlKCl9PC9hPlxuICAgICAgPGE+JHtlbC5pZCAmJiAnIycgKyBlbC5pZH08L2E+XG4gICAgICAke2NyZWF0ZUNsYXNzbmFtZShlbCkuc3BsaXQoJy4nKVxuICAgICAgICAuZmlsdGVyKG5hbWUgPT4gbmFtZSAhPSAnJylcbiAgICAgICAgLnJlZHVjZSgobGlua3MsIG5hbWUpID0+IGBcbiAgICAgICAgICAke2xpbmtzfVxuICAgICAgICAgIDxhPi4ke25hbWV9PC9hPlxuICAgICAgICBgLCAnJylcbiAgICAgIH1cbiAgICBgKVxuXG4gICAgbGV0IG9ic2VydmVyICAgICAgICA9IGNyZWF0ZU9ic2VydmVyKGVsLCB7aGFuZGxlLGxhYmVsfSlcbiAgICBsZXQgcGFyZW50T2JzZXJ2ZXIgID0gY3JlYXRlT2JzZXJ2ZXIoZWwsIHtoYW5kbGUsbGFiZWx9KVxuXG4gICAgb2JzZXJ2ZXIub2JzZXJ2ZShlbCwgeyBhdHRyaWJ1dGVzOiB0cnVlIH0pXG4gICAgcGFyZW50T2JzZXJ2ZXIub2JzZXJ2ZShlbC5wYXJlbnROb2RlLCB7IGNoaWxkTGlzdDp0cnVlLCBzdWJ0cmVlOnRydWUgfSlcblxuICAgICQobGFiZWwpLm9uKCdET01Ob2RlUmVtb3ZlZCcsIF8gPT4ge1xuICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpXG4gICAgICBwYXJlbnRPYnNlcnZlci5kaXNjb25uZWN0KClcbiAgICB9KVxuICB9XG5cbiAgY29uc3Qgc2V0TGFiZWwgPSAoZWwsIGxhYmVsKSA9PlxuICAgIGxhYmVsLnVwZGF0ZSA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpXG5cbiAgY29uc3QgY3JlYXRlTGFiZWwgPSAoZWwsIHRleHQpID0+IHtcbiAgICBpZiAoIWxhYmVsc1twYXJzZUludChlbC5nZXRBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnKSldKSB7XG4gICAgICBjb25zdCBsYWJlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3BiLWxhYmVsJylcblxuICAgICAgbGFiZWwudGV4dCA9IHRleHRcbiAgICAgIGxhYmVsLnBvc2l0aW9uID0ge1xuICAgICAgICBib3VuZGluZ1JlY3Q6ICAgZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksXG4gICAgICAgIG5vZGVfbGFiZWxfaWQ6ICBsYWJlbHMubGVuZ3RoLFxuICAgICAgfVxuICAgICAgZWwuc2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJywgbGFiZWxzLmxlbmd0aClcblxuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChsYWJlbClcblxuICAgICAgJChsYWJlbCkub24oJ3F1ZXJ5JywgKHtkZXRhaWx9KSA9PiB7XG4gICAgICAgIGlmICghZGV0YWlsLnRleHQpIHJldHVyblxuICAgICAgICB0aGlzLnF1ZXJ5X3RleHQgPSBkZXRhaWwudGV4dFxuXG4gICAgICAgIHF1ZXJ5UGFnZSgnW2RhdGEtaG92ZXJdJywgZWwgPT5cbiAgICAgICAgICBlbC5zZXRBdHRyaWJ1dGUoJ2RhdGEtaG92ZXInLCBudWxsKSlcblxuICAgICAgICBxdWVyeVBhZ2UodGhpcy5xdWVyeV90ZXh0ICsgJzpub3QoW2RhdGEtc2VsZWN0ZWRdKScsIGVsID0+XG4gICAgICAgICAgZGV0YWlsLmFjdGl2YXRvciA9PT0gJ21vdXNlZW50ZXInXG4gICAgICAgICAgICA/IGVsLnNldEF0dHJpYnV0ZSgnZGF0YS1ob3ZlcicsIHRydWUpXG4gICAgICAgICAgICA6IHNlbGVjdChlbCkpXG4gICAgICB9KVxuXG4gICAgICAkKGxhYmVsKS5vbignbW91c2VsZWF2ZScsIGUgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKVxuICAgICAgICBxdWVyeVBhZ2UoJ1tkYXRhLWhvdmVyXScsIGVsID0+XG4gICAgICAgICAgZWwuc2V0QXR0cmlidXRlKCdkYXRhLWhvdmVyJywgbnVsbCkpXG4gICAgICB9KVxuXG4gICAgICBsYWJlbHNbbGFiZWxzLmxlbmd0aF0gPSBsYWJlbFxuICAgICAgcmV0dXJuIGxhYmVsXG4gICAgfVxuICB9XG5cbiAgY29uc3QgY3JlYXRlSGFuZGxlID0gZWwgPT4ge1xuICAgIGlmICghaGFuZGxlc1twYXJzZUludChlbC5nZXRBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwtaWQnKSldKSB7XG4gICAgICBjb25zdCBoYW5kbGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdwYi1oYW5kbGVzJylcblxuICAgICAgaGFuZGxlLnBvc2l0aW9uID0ge1xuICAgICAgICBib3VuZGluZ1JlY3Q6ICAgZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksXG4gICAgICAgIG5vZGVfbGFiZWxfaWQ6ICBoYW5kbGVzLmxlbmd0aCxcbiAgICAgIH1cblxuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChoYW5kbGUpXG5cbiAgICAgIGhhbmRsZXNbaGFuZGxlcy5sZW5ndGhdID0gaGFuZGxlXG4gICAgICByZXR1cm4gaGFuZGxlXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgc2V0SGFuZGxlID0gKG5vZGUsIGhhbmRsZSkgPT4ge1xuICAgIGhhbmRsZS5wb3NpdGlvbiA9IHtcbiAgICAgIGJvdW5kaW5nUmVjdDogICBub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgbm9kZV9sYWJlbF9pZDogIG5vZGUuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLWlkJyksXG4gICAgfVxuICB9XG5cbiAgY29uc3QgY3JlYXRlT2JzZXJ2ZXIgPSAobm9kZSwge2xhYmVsLGhhbmRsZX0pID0+XG4gICAgbmV3IE11dGF0aW9uT2JzZXJ2ZXIobGlzdCA9PiB7XG4gICAgICBzZXRMYWJlbChub2RlLCBsYWJlbClcbiAgICAgIHNldEhhbmRsZShub2RlLCBoYW5kbGUpXG4gICAgfSlcblxuICBjb25zdCBvblNlbGVjdGVkVXBkYXRlID0gKGNiLCBpbW1lZGlhdGVDYWxsYmFjayA9IHRydWUpID0+IHtcbiAgICBzZWxlY3RlZENhbGxiYWNrcy5wdXNoKGNiKVxuICAgIGlmIChpbW1lZGlhdGVDYWxsYmFjaykgY2Ioc2VsZWN0ZWQpXG4gIH1cblxuICBjb25zdCByZW1vdmVTZWxlY3RlZENhbGxiYWNrID0gY2IgPT5cbiAgICBzZWxlY3RlZENhbGxiYWNrcyA9IHNlbGVjdGVkQ2FsbGJhY2tzLmZpbHRlcihjYWxsYmFjayA9PiBjYWxsYmFjayAhPSBjYilcblxuICBjb25zdCB0ZWxsV2F0Y2hlcnMgPSAoKSA9PlxuICAgIHNlbGVjdGVkQ2FsbGJhY2tzLmZvckVhY2goY2IgPT4gY2Ioc2VsZWN0ZWQpKVxuXG4gIGNvbnN0IGRpc2Nvbm5lY3QgPSAoKSA9PiB7XG4gICAgdW5zZWxlY3RfYWxsKClcbiAgICB1bmxpc3RlbigpXG4gIH1cblxuICB3YXRjaEltYWdlc0ZvclVwbG9hZCgpXG4gIGxpc3RlbigpXG5cbiAgcmV0dXJuIHtcbiAgICBzZWxlY3QsXG4gICAgdW5zZWxlY3RfYWxsLFxuICAgIG9uU2VsZWN0ZWRVcGRhdGUsXG4gICAgcmVtb3ZlU2VsZWN0ZWRDYWxsYmFjayxcbiAgICBkaXNjb25uZWN0XG4gIH1cbn1cbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgeyBtZXRhS2V5LCBnZXRTdHlsZSwgZ2V0U2lkZSwgc2hvd0hpZGVTZWxlY3RlZCB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbi8vIHRvZG86IHNob3cgcGFkZGluZyBjb2xvclxuY29uc3Qga2V5X2V2ZW50cyA9ICd1cCxkb3duLGxlZnQscmlnaHQnXG4gIC5zcGxpdCgnLCcpXG4gIC5yZWR1Y2UoKGV2ZW50cywgZXZlbnQpID0+XG4gICAgYCR7ZXZlbnRzfSwke2V2ZW50fSxhbHQrJHtldmVudH0sc2hpZnQrJHtldmVudH0sc2hpZnQrYWx0KyR7ZXZlbnR9YFxuICAsICcnKVxuICAuc3Vic3RyaW5nKDEpXG5cbmNvbnN0IGNvbW1hbmRfZXZlbnRzID0gYCR7bWV0YUtleX0rdXAsJHttZXRhS2V5fStzaGlmdCt1cCwke21ldGFLZXl9K2Rvd24sJHttZXRhS2V5fStzaGlmdCtkb3duYFxuXG5leHBvcnQgZnVuY3Rpb24gUGFkZGluZyhzZWxlY3Rvcikge1xuICBob3RrZXlzKGtleV9ldmVudHMsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgaWYgKGUuY2FuY2VsQnViYmxlKSByZXR1cm5cblxuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHBhZEVsZW1lbnQoJChzZWxlY3RvciksIGhhbmRsZXIua2V5KVxuICB9KVxuXG4gIGhvdGtleXMoY29tbWFuZF9ldmVudHMsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgcGFkQWxsRWxlbWVudFNpZGVzKCQoc2VsZWN0b3IpLCBoYW5kbGVyLmtleSlcbiAgfSlcblxuICByZXR1cm4gKCkgPT4ge1xuICAgIGhvdGtleXMudW5iaW5kKGtleV9ldmVudHMpXG4gICAgaG90a2V5cy51bmJpbmQoY29tbWFuZF9ldmVudHMpXG4gICAgaG90a2V5cy51bmJpbmQoJ3VwLGRvd24sbGVmdCxyaWdodCcpIC8vIGJ1ZyBpbiBsaWI/XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhZEVsZW1lbnQoZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbCA9PiBzaG93SGlkZVNlbGVjdGVkKGVsKSlcbiAgICAubWFwKGVsID0+ICh7XG4gICAgICBlbCxcbiAgICAgIHN0eWxlOiAgICAncGFkZGluZycgKyBnZXRTaWRlKGRpcmVjdGlvbiksXG4gICAgICBjdXJyZW50OiAgcGFyc2VJbnQoZ2V0U3R5bGUoZWwsICdwYWRkaW5nJyArIGdldFNpZGUoZGlyZWN0aW9uKSksIDEwKSxcbiAgICAgIGFtb3VudDogICBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygnc2hpZnQnKSA/IDEwIDogMSxcbiAgICAgIG5lZ2F0aXZlOiBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygnYWx0JyksXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgcGFkZGluZzogcGF5bG9hZC5uZWdhdGl2ZVxuICAgICAgICAgID8gcGF5bG9hZC5jdXJyZW50IC0gcGF5bG9hZC5hbW91bnRcbiAgICAgICAgICA6IHBheWxvYWQuY3VycmVudCArIHBheWxvYWQuYW1vdW50XG4gICAgICB9KSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgcGFkZGluZ30pID0+XG4gICAgICBlbC5zdHlsZVtzdHlsZV0gPSBgJHtwYWRkaW5nIDwgMCA/IDAgOiBwYWRkaW5nfXB4YClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhZEFsbEVsZW1lbnRTaWRlcyhlbHMsIGtleWNvbW1hbmQpIHtcbiAgY29uc3QgY29tYm8gPSBrZXljb21tYW5kLnNwbGl0KCcrJylcbiAgbGV0IHNwb29mID0gJydcblxuICBpZiAoY29tYm8uaW5jbHVkZXMoJ3NoaWZ0JykpICBzcG9vZiA9ICdzaGlmdCsnICsgc3Bvb2ZcbiAgaWYgKGNvbWJvLmluY2x1ZGVzKCdkb3duJykpICAgc3Bvb2YgPSAnYWx0KycgKyBzcG9vZlxuXG4gICd1cCxkb3duLGxlZnQscmlnaHQnLnNwbGl0KCcsJylcbiAgICAuZm9yRWFjaChzaWRlID0+IHBhZEVsZW1lbnQoZWxzLCBzcG9vZiArIHNpZGUpKVxufVxuIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCB7IHNob3dIaWRlTm9kZUxhYmVsIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuY29uc3QgcmVtb3ZlRWRpdGFiaWxpdHkgPSAoe3RhcmdldH0pID0+IHtcbiAgdGFyZ2V0LnJlbW92ZUF0dHJpYnV0ZSgnY29udGVudGVkaXRhYmxlJylcbiAgdGFyZ2V0LnJlbW92ZUF0dHJpYnV0ZSgnc3BlbGxjaGVjaycpXG4gIHRhcmdldC5yZW1vdmVFdmVudExpc3RlbmVyKCdibHVyJywgcmVtb3ZlRWRpdGFiaWxpdHkpXG4gIHRhcmdldC5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgc3RvcEJ1YmJsaW5nKVxuICBob3RrZXlzLnVuYmluZCgnZXNjYXBlLGVzYycpXG59XG5cbmNvbnN0IHN0b3BCdWJibGluZyA9IGUgPT4gZS5rZXkgIT0gJ0VzY2FwZScgJiYgZS5zdG9wUHJvcGFnYXRpb24oKVxuXG5jb25zdCBjbGVhbnVwID0gKGUsIGhhbmRsZXIpID0+IHtcbiAgJCgnW3NwZWxsY2hlY2s9XCJ0cnVlXCJdJykuZm9yRWFjaCh0YXJnZXQgPT4gcmVtb3ZlRWRpdGFiaWxpdHkoe3RhcmdldH0pKVxuICB3aW5kb3cuZ2V0U2VsZWN0aW9uKCkuZW1wdHkoKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gRWRpdFRleHQoZWxlbWVudHMpIHtcbiAgaWYgKCFlbGVtZW50cy5sZW5ndGgpIHJldHVyblxuXG4gIGVsZW1lbnRzLm1hcChlbCA9PiB7XG4gICAgbGV0ICRlbCA9ICQoZWwpXG5cbiAgICAkZWwuYXR0cih7XG4gICAgICBjb250ZW50ZWRpdGFibGU6IHRydWUsXG4gICAgICBzcGVsbGNoZWNrOiB0cnVlLFxuICAgIH0pXG4gICAgZWwuZm9jdXMoKVxuICAgIHNob3dIaWRlTm9kZUxhYmVsKGVsLCB0cnVlKVxuXG4gICAgJGVsLm9uKCdrZXlkb3duJywgc3RvcEJ1YmJsaW5nKVxuICAgICRlbC5vbignYmx1cicsIHJlbW92ZUVkaXRhYmlsaXR5KVxuICB9KVxuXG4gIGhvdGtleXMoJ2VzY2FwZSxlc2MnLCBjbGVhbnVwKVxufSIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgeyBtZXRhS2V5LCBnZXRTdHlsZSwgc2hvd0hpZGVTZWxlY3RlZCB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmNvbnN0IGtleV9ldmVudHMgPSAndXAsZG93bixsZWZ0LHJpZ2h0J1xuICAuc3BsaXQoJywnKVxuICAucmVkdWNlKChldmVudHMsIGV2ZW50KSA9PlxuICAgIGAke2V2ZW50c30sJHtldmVudH0sc2hpZnQrJHtldmVudH1gXG4gICwgJycpXG4gIC5zdWJzdHJpbmcoMSlcblxuY29uc3QgY29tbWFuZF9ldmVudHMgPSBgJHttZXRhS2V5fSt1cCwke21ldGFLZXl9K2Rvd25gXG5cbmV4cG9ydCBmdW5jdGlvbiBGb250KHNlbGVjdG9yKSB7XG4gIGhvdGtleXMoa2V5X2V2ZW50cywgKGUsIGhhbmRsZXIpID0+IHtcbiAgICBpZiAoZS5jYW5jZWxCdWJibGUpIHJldHVyblxuXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICBsZXQgc2VsZWN0ZWROb2RlcyA9ICQoc2VsZWN0b3IpXG4gICAgICAsIGtleXMgPSBoYW5kbGVyLmtleS5zcGxpdCgnKycpXG5cbiAgICBpZiAoa2V5cy5pbmNsdWRlcygnbGVmdCcpIHx8IGtleXMuaW5jbHVkZXMoJ3JpZ2h0JykpXG4gICAgICBrZXlzLmluY2x1ZGVzKCdzaGlmdCcpXG4gICAgICAgID8gY2hhbmdlS2VybmluZyhzZWxlY3RlZE5vZGVzLCBoYW5kbGVyLmtleSlcbiAgICAgICAgOiBjaGFuZ2VBbGlnbm1lbnQoc2VsZWN0ZWROb2RlcywgaGFuZGxlci5rZXkpXG4gICAgZWxzZVxuICAgICAga2V5cy5pbmNsdWRlcygnc2hpZnQnKVxuICAgICAgICA/IGNoYW5nZUxlYWRpbmcoc2VsZWN0ZWROb2RlcywgaGFuZGxlci5rZXkpXG4gICAgICAgIDogY2hhbmdlRm9udFNpemUoc2VsZWN0ZWROb2RlcywgaGFuZGxlci5rZXkpXG4gIH0pXG5cbiAgaG90a2V5cyhjb21tYW5kX2V2ZW50cywgKGUsIGhhbmRsZXIpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBsZXQga2V5cyA9IGhhbmRsZXIua2V5LnNwbGl0KCcrJylcbiAgICBjaGFuZ2VGb250V2VpZ2h0KCQoc2VsZWN0b3IpLCBrZXlzLmluY2x1ZGVzKCd1cCcpID8gJ3VwJyA6ICdkb3duJylcbiAgfSlcblxuICBob3RrZXlzKCdjbWQrYicsIGUgPT4ge1xuICAgICQoc2VsZWN0b3IpLmZvckVhY2goZWwgPT5cbiAgICAgIGVsLnN0eWxlLmZvbnRXZWlnaHQgPVxuICAgICAgICBlbC5zdHlsZS5mb250V2VpZ2h0ID09ICdib2xkJ1xuICAgICAgICAgID8gbnVsbFxuICAgICAgICAgIDogJ2JvbGQnKVxuICB9KVxuXG4gIGhvdGtleXMoJ2NtZCtpJywgZSA9PiB7XG4gICAgJChzZWxlY3RvcikuZm9yRWFjaChlbCA9PlxuICAgICAgZWwuc3R5bGUuZm9udFN0eWxlID1cbiAgICAgICAgZWwuc3R5bGUuZm9udFN0eWxlID09ICdpdGFsaWMnXG4gICAgICAgICAgPyBudWxsXG4gICAgICAgICAgOiAnaXRhbGljJylcbiAgfSlcblxuICByZXR1cm4gKCkgPT4ge1xuICAgIGhvdGtleXMudW5iaW5kKGtleV9ldmVudHMpXG4gICAgaG90a2V5cy51bmJpbmQoY29tbWFuZF9ldmVudHMpXG4gICAgaG90a2V5cy51bmJpbmQoJ2NtZCtiLGNtZCtpJylcbiAgICBob3RrZXlzLnVuYmluZCgndXAsZG93bixsZWZ0LHJpZ2h0JylcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY2hhbmdlTGVhZGluZyhlbHMsIGRpcmVjdGlvbikge1xuICBlbHNcbiAgICAubWFwKGVsID0+IHNob3dIaWRlU2VsZWN0ZWQoZWwpKVxuICAgIC5tYXAoZWwgPT4gKHtcbiAgICAgIGVsLFxuICAgICAgc3R5bGU6ICAgICdsaW5lSGVpZ2h0JyxcbiAgICAgIGN1cnJlbnQ6ICBwYXJzZUludChnZXRTdHlsZShlbCwgJ2xpbmVIZWlnaHQnKSksXG4gICAgICBhbW91bnQ6ICAgMSxcbiAgICAgIG5lZ2F0aXZlOiBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygnZG93bicpLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIGN1cnJlbnQ6IHBheWxvYWQuY3VycmVudCA9PSAnbm9ybWFsJyB8fCBpc05hTihwYXlsb2FkLmN1cnJlbnQpXG4gICAgICAgICAgPyAxLjE0ICogcGFyc2VJbnQoZ2V0U3R5bGUocGF5bG9hZC5lbCwgJ2ZvbnRTaXplJykpIC8vIGRvY3VtZW50IHRoaXMgY2hvaWNlXG4gICAgICAgICAgOiBwYXlsb2FkLmN1cnJlbnRcbiAgICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIHZhbHVlOiBwYXlsb2FkLm5lZ2F0aXZlXG4gICAgICAgICAgPyBwYXlsb2FkLmN1cnJlbnQgLSBwYXlsb2FkLmFtb3VudFxuICAgICAgICAgIDogcGF5bG9hZC5jdXJyZW50ICsgcGF5bG9hZC5hbW91bnRcbiAgICAgIH0pKVxuICAgIC5mb3JFYWNoKCh7ZWwsIHN0eWxlLCB2YWx1ZX0pID0+XG4gICAgICBlbC5zdHlsZVtzdHlsZV0gPSBgJHt2YWx1ZX1weGApXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjaGFuZ2VLZXJuaW5nKGVscywgZGlyZWN0aW9uKSB7XG4gIGVsc1xuICAgIC5tYXAoZWwgPT4gc2hvd0hpZGVTZWxlY3RlZChlbCkpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgZWwsXG4gICAgICBzdHlsZTogICAgJ2xldHRlclNwYWNpbmcnLFxuICAgICAgY3VycmVudDogIHBhcnNlRmxvYXQoZ2V0U3R5bGUoZWwsICdsZXR0ZXJTcGFjaW5nJykpLFxuICAgICAgYW1vdW50OiAgIC4xLFxuICAgICAgbmVnYXRpdmU6IGRpcmVjdGlvbi5zcGxpdCgnKycpLmluY2x1ZGVzKCdsZWZ0JyksXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgY3VycmVudDogcGF5bG9hZC5jdXJyZW50ID09ICdub3JtYWwnIHx8IGlzTmFOKHBheWxvYWQuY3VycmVudClcbiAgICAgICAgICA/IDBcbiAgICAgICAgICA6IHBheWxvYWQuY3VycmVudFxuICAgICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgdmFsdWU6IHBheWxvYWQubmVnYXRpdmVcbiAgICAgICAgICA/IChwYXlsb2FkLmN1cnJlbnQgLSBwYXlsb2FkLmFtb3VudCkudG9GaXhlZCgyKVxuICAgICAgICAgIDogKHBheWxvYWQuY3VycmVudCArIHBheWxvYWQuYW1vdW50KS50b0ZpeGVkKDIpXG4gICAgICB9KSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgdmFsdWV9KSA9PlxuICAgICAgZWwuc3R5bGVbc3R5bGVdID0gYCR7dmFsdWUgPD0gLTIgPyAtMiA6IHZhbHVlfXB4YClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZUZvbnRTaXplKGVscywgZGlyZWN0aW9uKSB7XG4gIGVsc1xuICAgIC5tYXAoZWwgPT4gc2hvd0hpZGVTZWxlY3RlZChlbCkpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgZWwsXG4gICAgICBzdHlsZTogICAgJ2ZvbnRTaXplJyxcbiAgICAgIGN1cnJlbnQ6ICBwYXJzZUludChnZXRTdHlsZShlbCwgJ2ZvbnRTaXplJykpLFxuICAgICAgYW1vdW50OiAgIGRpcmVjdGlvbi5zcGxpdCgnKycpLmluY2x1ZGVzKCdzaGlmdCcpID8gMTAgOiAxLFxuICAgICAgbmVnYXRpdmU6IGRpcmVjdGlvbi5zcGxpdCgnKycpLmluY2x1ZGVzKCdkb3duJyksXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgZm9udF9zaXplOiBwYXlsb2FkLm5lZ2F0aXZlXG4gICAgICAgICAgPyBwYXlsb2FkLmN1cnJlbnQgLSBwYXlsb2FkLmFtb3VudFxuICAgICAgICAgIDogcGF5bG9hZC5jdXJyZW50ICsgcGF5bG9hZC5hbW91bnRcbiAgICAgIH0pKVxuICAgIC5mb3JFYWNoKCh7ZWwsIHN0eWxlLCBmb250X3NpemV9KSA9PlxuICAgICAgZWwuc3R5bGVbc3R5bGVdID0gYCR7Zm9udF9zaXplIDw9IDYgPyA2IDogZm9udF9zaXplfXB4YClcbn1cblxuY29uc3Qgd2VpZ2h0TWFwID0ge1xuICBub3JtYWw6IDIsXG4gIGJvbGQ6ICAgNSxcbiAgbGlnaHQ6ICAwLFxuICBcIlwiOiAyLFxuICBcIjEwMFwiOjAsXCIyMDBcIjoxLFwiMzAwXCI6MixcIjQwMFwiOjMsXCI1MDBcIjo0LFwiNjAwXCI6NSxcIjcwMFwiOjYsXCI4MDBcIjo3LFwiOTAwXCI6OFxufVxuY29uc3Qgd2VpZ2h0T3B0aW9ucyA9IFsxMDAsMjAwLDMwMCw0MDAsNTAwLDYwMCw3MDAsODAwLDkwMF1cblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZUZvbnRXZWlnaHQoZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbCA9PiBzaG93SGlkZVNlbGVjdGVkKGVsKSlcbiAgICAubWFwKGVsID0+ICh7XG4gICAgICBlbCxcbiAgICAgIHN0eWxlOiAgICAnZm9udFdlaWdodCcsXG4gICAgICBjdXJyZW50OiAgZ2V0U3R5bGUoZWwsICdmb250V2VpZ2h0JyksXG4gICAgICBkaXJlY3Rpb246IGRpcmVjdGlvbi5zcGxpdCgnKycpLmluY2x1ZGVzKCdkb3duJyksXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgdmFsdWU6IHBheWxvYWQuZGlyZWN0aW9uXG4gICAgICAgICAgPyB3ZWlnaHRNYXBbcGF5bG9hZC5jdXJyZW50XSAtIDFcbiAgICAgICAgICA6IHdlaWdodE1hcFtwYXlsb2FkLmN1cnJlbnRdICsgMVxuICAgICAgfSkpXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIHZhbHVlfSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IHdlaWdodE9wdGlvbnNbdmFsdWUgPCAwID8gMCA6IHZhbHVlID49IHdlaWdodE9wdGlvbnMubGVuZ3RoXG4gICAgICAgID8gd2VpZ2h0T3B0aW9ucy5sZW5ndGhcbiAgICAgICAgOiB2YWx1ZVxuICAgICAgXSlcbn1cblxuY29uc3QgYWxpZ25NYXAgPSB7XG4gIHN0YXJ0OiAwLFxuICBsZWZ0OiAwLFxuICBjZW50ZXI6IDEsXG4gIHJpZ2h0OiAyLFxufVxuY29uc3QgYWxpZ25PcHRpb25zID0gWydsZWZ0JywnY2VudGVyJywncmlnaHQnXVxuXG5leHBvcnQgZnVuY3Rpb24gY2hhbmdlQWxpZ25tZW50KGVscywgZGlyZWN0aW9uKSB7XG4gIGVsc1xuICAgIC5tYXAoZWwgPT4gc2hvd0hpZGVTZWxlY3RlZChlbCkpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgZWwsXG4gICAgICBzdHlsZTogICAgJ3RleHRBbGlnbicsXG4gICAgICBjdXJyZW50OiAgZ2V0U3R5bGUoZWwsICd0ZXh0QWxpZ24nKSxcbiAgICAgIGRpcmVjdGlvbjogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ2xlZnQnKSxcbiAgICB9KSlcbiAgICAubWFwKHBheWxvYWQgPT5cbiAgICAgIE9iamVjdC5hc3NpZ24ocGF5bG9hZCwge1xuICAgICAgICB2YWx1ZTogcGF5bG9hZC5kaXJlY3Rpb25cbiAgICAgICAgICA/IGFsaWduTWFwW3BheWxvYWQuY3VycmVudF0gLSAxXG4gICAgICAgICAgOiBhbGlnbk1hcFtwYXlsb2FkLmN1cnJlbnRdICsgMVxuICAgICAgfSkpXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIHZhbHVlfSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IGFsaWduT3B0aW9uc1t2YWx1ZSA8IDAgPyAwIDogdmFsdWUgPj0gMiA/IDI6IHZhbHVlXSlcbn1cbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgeyBtZXRhS2V5LCBnZXRTdHlsZSB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmNvbnN0IGtleV9ldmVudHMgPSAndXAsZG93bixsZWZ0LHJpZ2h0J1xuICAuc3BsaXQoJywnKVxuICAucmVkdWNlKChldmVudHMsIGV2ZW50KSA9PlxuICAgIGAke2V2ZW50c30sJHtldmVudH0sc2hpZnQrJHtldmVudH1gXG4gICwgJycpXG4gIC5zdWJzdHJpbmcoMSlcblxuY29uc3QgY29tbWFuZF9ldmVudHMgPSBgJHttZXRhS2V5fSt1cCwke21ldGFLZXl9K2Rvd24sJHttZXRhS2V5fStsZWZ0LCR7bWV0YUtleX0rcmlnaHRgXG5cbmV4cG9ydCBmdW5jdGlvbiBGbGV4KHNlbGVjdG9yKSB7XG4gIGhvdGtleXMoa2V5X2V2ZW50cywgKGUsIGhhbmRsZXIpID0+IHtcbiAgICBpZiAoZS5jYW5jZWxCdWJibGUpIHJldHVyblxuXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICBsZXQgc2VsZWN0ZWROb2RlcyA9ICQoc2VsZWN0b3IpXG4gICAgICAsIGtleXMgPSBoYW5kbGVyLmtleS5zcGxpdCgnKycpXG5cbiAgICBpZiAoa2V5cy5pbmNsdWRlcygnbGVmdCcpIHx8IGtleXMuaW5jbHVkZXMoJ3JpZ2h0JykpXG4gICAgICBrZXlzLmluY2x1ZGVzKCdzaGlmdCcpXG4gICAgICAgID8gY2hhbmdlSERpc3RyaWJ1dGlvbihzZWxlY3RlZE5vZGVzLCBoYW5kbGVyLmtleSlcbiAgICAgICAgOiBjaGFuZ2VIQWxpZ25tZW50KHNlbGVjdGVkTm9kZXMsIGhhbmRsZXIua2V5KVxuICAgIGVsc2VcbiAgICAgIGtleXMuaW5jbHVkZXMoJ3NoaWZ0JylcbiAgICAgICAgPyBjaGFuZ2VWRGlzdHJpYnV0aW9uKHNlbGVjdGVkTm9kZXMsIGhhbmRsZXIua2V5KVxuICAgICAgICA6IGNoYW5nZVZBbGlnbm1lbnQoc2VsZWN0ZWROb2RlcywgaGFuZGxlci5rZXkpXG4gIH0pXG5cbiAgaG90a2V5cyhjb21tYW5kX2V2ZW50cywgKGUsIGhhbmRsZXIpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcblxuICAgIGxldCBzZWxlY3RlZE5vZGVzID0gJChzZWxlY3RvcilcbiAgICAgICwga2V5cyA9IGhhbmRsZXIua2V5LnNwbGl0KCcrJylcblxuICAgIGNoYW5nZURpcmVjdGlvbihzZWxlY3RlZE5vZGVzLCBrZXlzLmluY2x1ZGVzKCdsZWZ0JykgPyAncm93JyA6ICdjb2x1bW4nKVxuICB9KVxuXG4gIHJldHVybiAoKSA9PiB7XG4gICAgaG90a2V5cy51bmJpbmQoa2V5X2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZChjb21tYW5kX2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZCgndXAsZG93bixsZWZ0LHJpZ2h0JylcbiAgfVxufVxuXG5jb25zdCBlbnN1cmVGbGV4ID0gZWwgPT4ge1xuICBlbC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnXG4gIHJldHVybiBlbFxufVxuXG5jb25zdCBhY2NvdW50Rm9yT3RoZXJKdXN0aWZ5Q29udGVudCA9IChjdXIsIHdhbnQpID0+IHtcbiAgaWYgKHdhbnQgPT0gJ2FsaWduJyAmJiAoY3VyICE9ICdmbGV4LXN0YXJ0JyAmJiBjdXIgIT0gJ2NlbnRlcicgJiYgY3VyICE9ICdmbGV4LWVuZCcpKVxuICAgIGN1ciA9ICdub3JtYWwnXG4gIGVsc2UgaWYgKHdhbnQgPT0gJ2Rpc3RyaWJ1dGUnICYmIChjdXIgIT0gJ3NwYWNlLWFyb3VuZCcgJiYgY3VyICE9ICdzcGFjZS1iZXR3ZWVuJykpXG4gICAgY3VyID0gJ25vcm1hbCdcblxuICByZXR1cm4gY3VyXG59XG5cbi8vIHRvZG86IHN1cHBvcnQgcmV2ZXJzaW5nIGRpcmVjdGlvblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZURpcmVjdGlvbihlbHMsIHZhbHVlKSB7XG4gIGVsc1xuICAgIC5tYXAoZW5zdXJlRmxleClcbiAgICAubWFwKGVsID0+IHtcbiAgICAgIGVsLnN0eWxlLmZsZXhEaXJlY3Rpb24gPSB2YWx1ZVxuICAgIH0pXG59XG5cbmNvbnN0IGhfYWxpZ25NYXAgICAgICA9IHtub3JtYWw6IDAsJ2ZsZXgtc3RhcnQnOiAwLCdjZW50ZXInOiAxLCdmbGV4LWVuZCc6IDIsfVxuY29uc3QgaF9hbGlnbk9wdGlvbnMgID0gWydmbGV4LXN0YXJ0JywnY2VudGVyJywnZmxleC1lbmQnXVxuXG5leHBvcnQgZnVuY3Rpb24gY2hhbmdlSEFsaWdubWVudChlbHMsIGRpcmVjdGlvbikge1xuICBlbHNcbiAgICAubWFwKGVuc3VyZUZsZXgpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgZWwsXG4gICAgICBzdHlsZTogICAgJ2p1c3RpZnlDb250ZW50JyxcbiAgICAgIGN1cnJlbnQ6ICBhY2NvdW50Rm9yT3RoZXJKdXN0aWZ5Q29udGVudChnZXRTdHlsZShlbCwgJ2p1c3RpZnlDb250ZW50JyksICdhbGlnbicpLFxuICAgICAgZGlyZWN0aW9uOiBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygnbGVmdCcpLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIHZhbHVlOiBwYXlsb2FkLmRpcmVjdGlvblxuICAgICAgICAgID8gaF9hbGlnbk1hcFtwYXlsb2FkLmN1cnJlbnRdIC0gMVxuICAgICAgICAgIDogaF9hbGlnbk1hcFtwYXlsb2FkLmN1cnJlbnRdICsgMVxuICAgICAgfSkpXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIHZhbHVlfSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IGhfYWxpZ25PcHRpb25zW3ZhbHVlIDwgMCA/IDAgOiB2YWx1ZSA+PSAyID8gMjogdmFsdWVdKVxufVxuXG5jb25zdCB2X2FsaWduTWFwICAgICAgPSB7bm9ybWFsOiAwLCdmbGV4LXN0YXJ0JzogMCwnY2VudGVyJzogMSwnZmxleC1lbmQnOiAyLH1cbmNvbnN0IHZfYWxpZ25PcHRpb25zICA9IFsnZmxleC1zdGFydCcsJ2NlbnRlcicsJ2ZsZXgtZW5kJ11cblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZVZBbGlnbm1lbnQoZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbnN1cmVGbGV4KVxuICAgIC5tYXAoZWwgPT4gKHtcbiAgICAgIGVsLFxuICAgICAgc3R5bGU6ICAgICdhbGlnbkl0ZW1zJyxcbiAgICAgIGN1cnJlbnQ6ICBnZXRTdHlsZShlbCwgJ2FsaWduSXRlbXMnKSxcbiAgICAgIGRpcmVjdGlvbjogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ3VwJyksXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgdmFsdWU6IHBheWxvYWQuZGlyZWN0aW9uXG4gICAgICAgICAgPyBoX2FsaWduTWFwW3BheWxvYWQuY3VycmVudF0gLSAxXG4gICAgICAgICAgOiBoX2FsaWduTWFwW3BheWxvYWQuY3VycmVudF0gKyAxXG4gICAgICB9KSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgdmFsdWV9KSA9PlxuICAgICAgZWwuc3R5bGVbc3R5bGVdID0gdl9hbGlnbk9wdGlvbnNbdmFsdWUgPCAwID8gMCA6IHZhbHVlID49IDIgPyAyOiB2YWx1ZV0pXG59XG5cbmNvbnN0IGhfZGlzdHJpYnV0aW9uTWFwICAgICAgPSB7bm9ybWFsOiAxLCdzcGFjZS1hcm91bmQnOiAwLCcnOiAxLCdzcGFjZS1iZXR3ZWVuJzogMix9XG5jb25zdCBoX2Rpc3RyaWJ1dGlvbk9wdGlvbnMgID0gWydzcGFjZS1hcm91bmQnLCcnLCdzcGFjZS1iZXR3ZWVuJ11cblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZUhEaXN0cmlidXRpb24oZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbnN1cmVGbGV4KVxuICAgIC5tYXAoZWwgPT4gKHtcbiAgICAgIGVsLFxuICAgICAgc3R5bGU6ICAgICdqdXN0aWZ5Q29udGVudCcsXG4gICAgICBjdXJyZW50OiAgYWNjb3VudEZvck90aGVySnVzdGlmeUNvbnRlbnQoZ2V0U3R5bGUoZWwsICdqdXN0aWZ5Q29udGVudCcpLCAnZGlzdHJpYnV0ZScpLFxuICAgICAgZGlyZWN0aW9uOiBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygnbGVmdCcpLFxuICAgIH0pKVxuICAgIC5tYXAocGF5bG9hZCA9PlxuICAgICAgT2JqZWN0LmFzc2lnbihwYXlsb2FkLCB7XG4gICAgICAgIHZhbHVlOiBwYXlsb2FkLmRpcmVjdGlvblxuICAgICAgICAgID8gaF9kaXN0cmlidXRpb25NYXBbcGF5bG9hZC5jdXJyZW50XSAtIDFcbiAgICAgICAgICA6IGhfZGlzdHJpYnV0aW9uTWFwW3BheWxvYWQuY3VycmVudF0gKyAxXG4gICAgICB9KSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgdmFsdWV9KSA9PlxuICAgICAgZWwuc3R5bGVbc3R5bGVdID0gaF9kaXN0cmlidXRpb25PcHRpb25zW3ZhbHVlIDwgMCA/IDAgOiB2YWx1ZSA+PSAyID8gMjogdmFsdWVdKVxufVxuXG5jb25zdCB2X2Rpc3RyaWJ1dGlvbk1hcCAgICAgID0ge25vcm1hbDogMSwnc3BhY2UtYXJvdW5kJzogMCwnJzogMSwnc3BhY2UtYmV0d2Vlbic6IDIsfVxuY29uc3Qgdl9kaXN0cmlidXRpb25PcHRpb25zICA9IFsnc3BhY2UtYXJvdW5kJywnJywnc3BhY2UtYmV0d2VlbiddXG5cbmV4cG9ydCBmdW5jdGlvbiBjaGFuZ2VWRGlzdHJpYnV0aW9uKGVscywgZGlyZWN0aW9uKSB7XG4gIGVsc1xuICAgIC5tYXAoZW5zdXJlRmxleClcbiAgICAubWFwKGVsID0+ICh7XG4gICAgICBlbCxcbiAgICAgIHN0eWxlOiAgICAnYWxpZ25Db250ZW50JyxcbiAgICAgIGN1cnJlbnQ6ICBnZXRTdHlsZShlbCwgJ2FsaWduQ29udGVudCcpLFxuICAgICAgZGlyZWN0aW9uOiBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygndXAnKSxcbiAgICB9KSlcbiAgICAubWFwKHBheWxvYWQgPT5cbiAgICAgIE9iamVjdC5hc3NpZ24ocGF5bG9hZCwge1xuICAgICAgICB2YWx1ZTogcGF5bG9hZC5kaXJlY3Rpb25cbiAgICAgICAgICA/IHZfZGlzdHJpYnV0aW9uTWFwW3BheWxvYWQuY3VycmVudF0gLSAxXG4gICAgICAgICAgOiB2X2Rpc3RyaWJ1dGlvbk1hcFtwYXlsb2FkLmN1cnJlbnRdICsgMVxuICAgICAgfSkpXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIHZhbHVlfSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IHZfZGlzdHJpYnV0aW9uT3B0aW9uc1t2YWx1ZSA8IDAgPyAwIDogdmFsdWUgPj0gMiA/IDI6IHZhbHVlXSlcbn1cbiIsIi8qKlxuICogVGFrZSBpbnB1dCBmcm9tIFswLCBuXSBhbmQgcmV0dXJuIGl0IGFzIFswLCAxXVxuICogQGhpZGRlblxuICovXG5mdW5jdGlvbiBib3VuZDAxKG4sIG1heCkge1xuICAgIGlmIChpc09uZVBvaW50WmVybyhuKSkge1xuICAgICAgICBuID0gJzEwMCUnO1xuICAgIH1cbiAgICBjb25zdCBwcm9jZXNzUGVyY2VudCA9IGlzUGVyY2VudGFnZShuKTtcbiAgICBuID0gbWF4ID09PSAzNjAgPyBuIDogTWF0aC5taW4obWF4LCBNYXRoLm1heCgwLCBwYXJzZUZsb2F0KG4pKSk7XG4gICAgLy8gQXV0b21hdGljYWxseSBjb252ZXJ0IHBlcmNlbnRhZ2UgaW50byBudW1iZXJcbiAgICBpZiAocHJvY2Vzc1BlcmNlbnQpIHtcbiAgICAgICAgbiA9IHBhcnNlSW50KFN0cmluZyhuICogbWF4KSwgMTApIC8gMTAwO1xuICAgIH1cbiAgICAvLyBIYW5kbGUgZmxvYXRpbmcgcG9pbnQgcm91bmRpbmcgZXJyb3JzXG4gICAgaWYgKE1hdGguYWJzKG4gLSBtYXgpIDwgMC4wMDAwMDEpIHtcbiAgICAgICAgcmV0dXJuIDE7XG4gICAgfVxuICAgIC8vIENvbnZlcnQgaW50byBbMCwgMV0gcmFuZ2UgaWYgaXQgaXNuJ3QgYWxyZWFkeVxuICAgIGlmIChtYXggPT09IDM2MCkge1xuICAgICAgICAvLyBJZiBuIGlzIGEgaHVlIGdpdmVuIGluIGRlZ3JlZXMsXG4gICAgICAgIC8vIHdyYXAgYXJvdW5kIG91dC1vZi1yYW5nZSB2YWx1ZXMgaW50byBbMCwgMzYwXSByYW5nZVxuICAgICAgICAvLyB0aGVuIGNvbnZlcnQgaW50byBbMCwgMV0uXG4gICAgICAgIG4gPSAobiA8IDAgPyBuICUgbWF4ICsgbWF4IDogbiAlIG1heCkgLyBwYXJzZUZsb2F0KFN0cmluZyhtYXgpKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIElmIG4gbm90IGEgaHVlIGdpdmVuIGluIGRlZ3JlZXNcbiAgICAgICAgLy8gQ29udmVydCBpbnRvIFswLCAxXSByYW5nZSBpZiBpdCBpc24ndCBhbHJlYWR5LlxuICAgICAgICBuID0gKG4gJSBtYXgpIC8gcGFyc2VGbG9hdChTdHJpbmcobWF4KSk7XG4gICAgfVxuICAgIHJldHVybiBuO1xufVxuLyoqXG4gKiBGb3JjZSBhIG51bWJlciBiZXR3ZWVuIDAgYW5kIDFcbiAqIEBoaWRkZW5cbiAqL1xuZnVuY3Rpb24gY2xhbXAwMSh2YWwpIHtcbiAgICByZXR1cm4gTWF0aC5taW4oMSwgTWF0aC5tYXgoMCwgdmFsKSk7XG59XG4vKipcbiAqIE5lZWQgdG8gaGFuZGxlIDEuMCBhcyAxMDAlLCBzaW5jZSBvbmNlIGl0IGlzIGEgbnVtYmVyLCB0aGVyZSBpcyBubyBkaWZmZXJlbmNlIGJldHdlZW4gaXQgYW5kIDFcbiAqIDxodHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vcXVlc3Rpb25zLzc0MjIwNzIvamF2YXNjcmlwdC1ob3ctdG8tZGV0ZWN0LW51bWJlci1hcy1hLWRlY2ltYWwtaW5jbHVkaW5nLTEtMD5cbiAqIEBoaWRkZW5cbiAqL1xuZnVuY3Rpb24gaXNPbmVQb2ludFplcm8obikge1xuICAgIHJldHVybiB0eXBlb2YgbiA9PT0gJ3N0cmluZycgJiYgbi5pbmRleE9mKCcuJykgIT09IC0xICYmIHBhcnNlRmxvYXQobikgPT09IDE7XG59XG4vKipcbiAqIENoZWNrIHRvIHNlZSBpZiBzdHJpbmcgcGFzc2VkIGluIGlzIGEgcGVyY2VudGFnZVxuICogQGhpZGRlblxuICovXG5mdW5jdGlvbiBpc1BlcmNlbnRhZ2Uobikge1xuICAgIHJldHVybiB0eXBlb2YgbiA9PT0gJ3N0cmluZycgJiYgbi5pbmRleE9mKCclJykgIT09IC0xO1xufVxuLyoqXG4gKiBSZXR1cm4gYSB2YWxpZCBhbHBoYSB2YWx1ZSBbMCwxXSB3aXRoIGFsbCBpbnZhbGlkIHZhbHVlcyBiZWluZyBzZXQgdG8gMVxuICogQGhpZGRlblxuICovXG5mdW5jdGlvbiBib3VuZEFscGhhKGEpIHtcbiAgICBhID0gcGFyc2VGbG9hdChhKTtcbiAgICBpZiAoaXNOYU4oYSkgfHwgYSA8IDAgfHwgYSA+IDEpIHtcbiAgICAgICAgYSA9IDE7XG4gICAgfVxuICAgIHJldHVybiBhO1xufVxuLyoqXG4gKiBSZXBsYWNlIGEgZGVjaW1hbCB3aXRoIGl0J3MgcGVyY2VudGFnZSB2YWx1ZVxuICogQGhpZGRlblxuICovXG5mdW5jdGlvbiBjb252ZXJ0VG9QZXJjZW50YWdlKG4pIHtcbiAgICBpZiAobiA8PSAxKSB7XG4gICAgICAgIHJldHVybiArbiAqIDEwMCArICclJztcbiAgICB9XG4gICAgcmV0dXJuIG47XG59XG4vKipcbiAqIEZvcmNlIGEgaGV4IHZhbHVlIHRvIGhhdmUgMiBjaGFyYWN0ZXJzXG4gKiBAaGlkZGVuXG4gKi9cbmZ1bmN0aW9uIHBhZDIoYykge1xuICAgIHJldHVybiBjLmxlbmd0aCA9PT0gMSA/ICcwJyArIGMgOiAnJyArIGM7XG59XG5cbi8vIGByZ2JUb0hzbGAsIGByZ2JUb0hzdmAsIGBoc2xUb1JnYmAsIGBoc3ZUb1JnYmAgbW9kaWZpZWQgZnJvbTpcbi8vIDxodHRwOi8vbWppamFja3Nvbi5jb20vMjAwOC8wMi9yZ2ItdG8taHNsLWFuZC1yZ2ItdG8taHN2LWNvbG9yLW1vZGVsLWNvbnZlcnNpb24tYWxnb3JpdGhtcy1pbi1qYXZhc2NyaXB0PlxuLyoqXG4gKiBIYW5kbGUgYm91bmRzIC8gcGVyY2VudGFnZSBjaGVja2luZyB0byBjb25mb3JtIHRvIENTUyBjb2xvciBzcGVjXG4gKiA8aHR0cDovL3d3dy53My5vcmcvVFIvY3NzMy1jb2xvci8+XG4gKiAqQXNzdW1lczoqIHIsIGcsIGIgaW4gWzAsIDI1NV0gb3IgWzAsIDFdXG4gKiAqUmV0dXJuczoqIHsgciwgZywgYiB9IGluIFswLCAyNTVdXG4gKi9cbmZ1bmN0aW9uIHJnYlRvUmdiKHIsIGcsIGIpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICByOiBib3VuZDAxKHIsIDI1NSkgKiAyNTUsXG4gICAgICAgIGc6IGJvdW5kMDEoZywgMjU1KSAqIDI1NSxcbiAgICAgICAgYjogYm91bmQwMShiLCAyNTUpICogMjU1LFxuICAgIH07XG59XG4vKipcbiAqIENvbnZlcnRzIGFuIFJHQiBjb2xvciB2YWx1ZSB0byBIU0wuXG4gKiAqQXNzdW1lczoqIHIsIGcsIGFuZCBiIGFyZSBjb250YWluZWQgaW4gWzAsIDI1NV0gb3IgWzAsIDFdXG4gKiAqUmV0dXJuczoqIHsgaCwgcywgbCB9IGluIFswLDFdXG4gKi9cbmZ1bmN0aW9uIHJnYlRvSHNsKHIsIGcsIGIpIHtcbiAgICByID0gYm91bmQwMShyLCAyNTUpO1xuICAgIGcgPSBib3VuZDAxKGcsIDI1NSk7XG4gICAgYiA9IGJvdW5kMDEoYiwgMjU1KTtcbiAgICBjb25zdCBtYXggPSBNYXRoLm1heChyLCBnLCBiKTtcbiAgICBjb25zdCBtaW4gPSBNYXRoLm1pbihyLCBnLCBiKTtcbiAgICBsZXQgaCA9IDA7XG4gICAgbGV0IHMgPSAwO1xuICAgIGNvbnN0IGwgPSAobWF4ICsgbWluKSAvIDI7XG4gICAgaWYgKG1heCA9PT0gbWluKSB7XG4gICAgICAgIGggPSBzID0gMDsgLy8gYWNocm9tYXRpY1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc3QgZCA9IG1heCAtIG1pbjtcbiAgICAgICAgcyA9IGwgPiAwLjUgPyBkIC8gKDIgLSBtYXggLSBtaW4pIDogZCAvIChtYXggKyBtaW4pO1xuICAgICAgICBzd2l0Y2ggKG1heCkge1xuICAgICAgICAgICAgY2FzZSByOlxuICAgICAgICAgICAgICAgIGggPSAoZyAtIGIpIC8gZCArIChnIDwgYiA/IDYgOiAwKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgZzpcbiAgICAgICAgICAgICAgICBoID0gKGIgLSByKSAvIGQgKyAyO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBiOlxuICAgICAgICAgICAgICAgIGggPSAociAtIGcpIC8gZCArIDQ7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgaCAvPSA2O1xuICAgIH1cbiAgICByZXR1cm4geyBoLCBzLCBsIH07XG59XG4vKipcbiAqIENvbnZlcnRzIGFuIEhTTCBjb2xvciB2YWx1ZSB0byBSR0IuXG4gKlxuICogKkFzc3VtZXM6KiBoIGlzIGNvbnRhaW5lZCBpbiBbMCwgMV0gb3IgWzAsIDM2MF0gYW5kIHMgYW5kIGwgYXJlIGNvbnRhaW5lZCBbMCwgMV0gb3IgWzAsIDEwMF1cbiAqICpSZXR1cm5zOiogeyByLCBnLCBiIH0gaW4gdGhlIHNldCBbMCwgMjU1XVxuICovXG5mdW5jdGlvbiBoc2xUb1JnYihoLCBzLCBsKSB7XG4gICAgbGV0IHI7XG4gICAgbGV0IGc7XG4gICAgbGV0IGI7XG4gICAgaCA9IGJvdW5kMDEoaCwgMzYwKTtcbiAgICBzID0gYm91bmQwMShzLCAxMDApO1xuICAgIGwgPSBib3VuZDAxKGwsIDEwMCk7XG4gICAgZnVuY3Rpb24gaHVlMnJnYihwLCBxLCB0KSB7XG4gICAgICAgIGlmICh0IDwgMClcbiAgICAgICAgICAgIHQgKz0gMTtcbiAgICAgICAgaWYgKHQgPiAxKVxuICAgICAgICAgICAgdCAtPSAxO1xuICAgICAgICBpZiAodCA8IDEgLyA2KSB7XG4gICAgICAgICAgICByZXR1cm4gcCArIChxIC0gcCkgKiA2ICogdDtcbiAgICAgICAgfVxuICAgICAgICBpZiAodCA8IDEgLyAyKSB7XG4gICAgICAgICAgICByZXR1cm4gcTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodCA8IDIgLyAzKSB7XG4gICAgICAgICAgICByZXR1cm4gcCArIChxIC0gcCkgKiAoMiAvIDMgLSB0KSAqIDY7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHA7XG4gICAgfVxuICAgIGlmIChzID09PSAwKSB7XG4gICAgICAgIHIgPSBnID0gYiA9IGw7IC8vIGFjaHJvbWF0aWNcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnN0IHEgPSBsIDwgMC41ID8gbCAqICgxICsgcykgOiBsICsgcyAtIGwgKiBzO1xuICAgICAgICBjb25zdCBwID0gMiAqIGwgLSBxO1xuICAgICAgICByID0gaHVlMnJnYihwLCBxLCBoICsgMSAvIDMpO1xuICAgICAgICBnID0gaHVlMnJnYihwLCBxLCBoKTtcbiAgICAgICAgYiA9IGh1ZTJyZ2IocCwgcSwgaCAtIDEgLyAzKTtcbiAgICB9XG4gICAgcmV0dXJuIHsgcjogciAqIDI1NSwgZzogZyAqIDI1NSwgYjogYiAqIDI1NSB9O1xufVxuLyoqXG4gKiBDb252ZXJ0cyBhbiBSR0IgY29sb3IgdmFsdWUgdG8gSFNWXG4gKlxuICogKkFzc3VtZXM6KiByLCBnLCBhbmQgYiBhcmUgY29udGFpbmVkIGluIHRoZSBzZXQgWzAsIDI1NV0gb3IgWzAsIDFdXG4gKiAqUmV0dXJuczoqIHsgaCwgcywgdiB9IGluIFswLDFdXG4gKi9cbmZ1bmN0aW9uIHJnYlRvSHN2KHIsIGcsIGIpIHtcbiAgICByID0gYm91bmQwMShyLCAyNTUpO1xuICAgIGcgPSBib3VuZDAxKGcsIDI1NSk7XG4gICAgYiA9IGJvdW5kMDEoYiwgMjU1KTtcbiAgICBjb25zdCBtYXggPSBNYXRoLm1heChyLCBnLCBiKTtcbiAgICBjb25zdCBtaW4gPSBNYXRoLm1pbihyLCBnLCBiKTtcbiAgICBsZXQgaCA9IDA7XG4gICAgY29uc3QgdiA9IG1heDtcbiAgICBjb25zdCBkID0gbWF4IC0gbWluO1xuICAgIGNvbnN0IHMgPSBtYXggPT09IDAgPyAwIDogZCAvIG1heDtcbiAgICBpZiAobWF4ID09PSBtaW4pIHtcbiAgICAgICAgaCA9IDA7IC8vIGFjaHJvbWF0aWNcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHN3aXRjaCAobWF4KSB7XG4gICAgICAgICAgICBjYXNlIHI6XG4gICAgICAgICAgICAgICAgaCA9IChnIC0gYikgLyBkICsgKGcgPCBiID8gNiA6IDApO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBnOlxuICAgICAgICAgICAgICAgIGggPSAoYiAtIHIpIC8gZCArIDI7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIGI6XG4gICAgICAgICAgICAgICAgaCA9IChyIC0gZykgLyBkICsgNDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBoIC89IDY7XG4gICAgfVxuICAgIHJldHVybiB7IGg6IGgsIHM6IHMsIHY6IHYgfTtcbn1cbi8qKlxuICogQ29udmVydHMgYW4gSFNWIGNvbG9yIHZhbHVlIHRvIFJHQi5cbiAqXG4gKiAqQXNzdW1lczoqIGggaXMgY29udGFpbmVkIGluIFswLCAxXSBvciBbMCwgMzYwXSBhbmQgcyBhbmQgdiBhcmUgY29udGFpbmVkIGluIFswLCAxXSBvciBbMCwgMTAwXVxuICogKlJldHVybnM6KiB7IHIsIGcsIGIgfSBpbiB0aGUgc2V0IFswLCAyNTVdXG4gKi9cbmZ1bmN0aW9uIGhzdlRvUmdiKGgsIHMsIHYpIHtcbiAgICBoID0gYm91bmQwMShoLCAzNjApICogNjtcbiAgICBzID0gYm91bmQwMShzLCAxMDApO1xuICAgIHYgPSBib3VuZDAxKHYsIDEwMCk7XG4gICAgY29uc3QgaSA9IE1hdGguZmxvb3IoaCk7XG4gICAgY29uc3QgZiA9IGggLSBpO1xuICAgIGNvbnN0IHAgPSB2ICogKDEgLSBzKTtcbiAgICBjb25zdCBxID0gdiAqICgxIC0gZiAqIHMpO1xuICAgIGNvbnN0IHQgPSB2ICogKDEgLSAoMSAtIGYpICogcyk7XG4gICAgY29uc3QgbW9kID0gaSAlIDY7XG4gICAgY29uc3QgciA9IFt2LCBxLCBwLCBwLCB0LCB2XVttb2RdO1xuICAgIGNvbnN0IGcgPSBbdCwgdiwgdiwgcSwgcCwgcF1bbW9kXTtcbiAgICBjb25zdCBiID0gW3AsIHAsIHQsIHYsIHYsIHFdW21vZF07XG4gICAgcmV0dXJuIHsgcjogciAqIDI1NSwgZzogZyAqIDI1NSwgYjogYiAqIDI1NSB9O1xufVxuLyoqXG4gKiBDb252ZXJ0cyBhbiBSR0IgY29sb3IgdG8gaGV4XG4gKlxuICogQXNzdW1lcyByLCBnLCBhbmQgYiBhcmUgY29udGFpbmVkIGluIHRoZSBzZXQgWzAsIDI1NV1cbiAqIFJldHVybnMgYSAzIG9yIDYgY2hhcmFjdGVyIGhleFxuICovXG5mdW5jdGlvbiByZ2JUb0hleChyLCBnLCBiLCBhbGxvdzNDaGFyKSB7XG4gICAgY29uc3QgaGV4ID0gW1xuICAgICAgICBwYWQyKE1hdGgucm91bmQocikudG9TdHJpbmcoMTYpKSxcbiAgICAgICAgcGFkMihNYXRoLnJvdW5kKGcpLnRvU3RyaW5nKDE2KSksXG4gICAgICAgIHBhZDIoTWF0aC5yb3VuZChiKS50b1N0cmluZygxNikpLFxuICAgIF07XG4gICAgLy8gUmV0dXJuIGEgMyBjaGFyYWN0ZXIgaGV4IGlmIHBvc3NpYmxlXG4gICAgaWYgKGFsbG93M0NoYXIgJiZcbiAgICAgICAgaGV4WzBdLmNoYXJBdCgwKSA9PT0gaGV4WzBdLmNoYXJBdCgxKSAmJlxuICAgICAgICBoZXhbMV0uY2hhckF0KDApID09PSBoZXhbMV0uY2hhckF0KDEpICYmXG4gICAgICAgIGhleFsyXS5jaGFyQXQoMCkgPT09IGhleFsyXS5jaGFyQXQoMSkpIHtcbiAgICAgICAgcmV0dXJuIGhleFswXS5jaGFyQXQoMCkgKyBoZXhbMV0uY2hhckF0KDApICsgaGV4WzJdLmNoYXJBdCgwKTtcbiAgICB9XG4gICAgcmV0dXJuIGhleC5qb2luKCcnKTtcbn1cbi8qKlxuICogQ29udmVydHMgYW4gUkdCQSBjb2xvciBwbHVzIGFscGhhIHRyYW5zcGFyZW5jeSB0byBoZXhcbiAqXG4gKiBBc3N1bWVzIHIsIGcsIGIgYXJlIGNvbnRhaW5lZCBpbiB0aGUgc2V0IFswLCAyNTVdIGFuZFxuICogYSBpbiBbMCwgMV0uIFJldHVybnMgYSA0IG9yIDggY2hhcmFjdGVyIHJnYmEgaGV4XG4gKi9cbmZ1bmN0aW9uIHJnYmFUb0hleChyLCBnLCBiLCBhLCBhbGxvdzRDaGFyKSB7XG4gICAgY29uc3QgaGV4ID0gW1xuICAgICAgICBwYWQyKE1hdGgucm91bmQocikudG9TdHJpbmcoMTYpKSxcbiAgICAgICAgcGFkMihNYXRoLnJvdW5kKGcpLnRvU3RyaW5nKDE2KSksXG4gICAgICAgIHBhZDIoTWF0aC5yb3VuZChiKS50b1N0cmluZygxNikpLFxuICAgICAgICBwYWQyKGNvbnZlcnREZWNpbWFsVG9IZXgoYSkpLFxuICAgIF07XG4gICAgLy8gUmV0dXJuIGEgNCBjaGFyYWN0ZXIgaGV4IGlmIHBvc3NpYmxlXG4gICAgaWYgKGFsbG93NENoYXIgJiZcbiAgICAgICAgaGV4WzBdLmNoYXJBdCgwKSA9PT0gaGV4WzBdLmNoYXJBdCgxKSAmJlxuICAgICAgICBoZXhbMV0uY2hhckF0KDApID09PSBoZXhbMV0uY2hhckF0KDEpICYmXG4gICAgICAgIGhleFsyXS5jaGFyQXQoMCkgPT09IGhleFsyXS5jaGFyQXQoMSkgJiZcbiAgICAgICAgaGV4WzNdLmNoYXJBdCgwKSA9PT0gaGV4WzNdLmNoYXJBdCgxKSkge1xuICAgICAgICByZXR1cm4gaGV4WzBdLmNoYXJBdCgwKSArIGhleFsxXS5jaGFyQXQoMCkgKyBoZXhbMl0uY2hhckF0KDApICsgaGV4WzNdLmNoYXJBdCgwKTtcbiAgICB9XG4gICAgcmV0dXJuIGhleC5qb2luKCcnKTtcbn1cbi8qKlxuICogQ29udmVydHMgYW4gUkdCQSBjb2xvciB0byBhbiBBUkdCIEhleDggc3RyaW5nXG4gKiBSYXJlbHkgdXNlZCwgYnV0IHJlcXVpcmVkIGZvciBcInRvRmlsdGVyKClcIlxuICovXG5mdW5jdGlvbiByZ2JhVG9BcmdiSGV4KHIsIGcsIGIsIGEpIHtcbiAgICBjb25zdCBoZXggPSBbXG4gICAgICAgIHBhZDIoY29udmVydERlY2ltYWxUb0hleChhKSksXG4gICAgICAgIHBhZDIoTWF0aC5yb3VuZChyKS50b1N0cmluZygxNikpLFxuICAgICAgICBwYWQyKE1hdGgucm91bmQoZykudG9TdHJpbmcoMTYpKSxcbiAgICAgICAgcGFkMihNYXRoLnJvdW5kKGIpLnRvU3RyaW5nKDE2KSksXG4gICAgXTtcbiAgICByZXR1cm4gaGV4LmpvaW4oJycpO1xufVxuLyoqIENvbnZlcnRzIGEgZGVjaW1hbCB0byBhIGhleCB2YWx1ZSAqL1xuZnVuY3Rpb24gY29udmVydERlY2ltYWxUb0hleChkKSB7XG4gICAgcmV0dXJuIE1hdGgucm91bmQocGFyc2VGbG9hdChkKSAqIDI1NSkudG9TdHJpbmcoMTYpO1xufVxuLyoqIENvbnZlcnRzIGEgaGV4IHZhbHVlIHRvIGEgZGVjaW1hbCAqL1xuZnVuY3Rpb24gY29udmVydEhleFRvRGVjaW1hbChoKSB7XG4gICAgcmV0dXJuIHBhcnNlSW50RnJvbUhleChoKSAvIDI1NTtcbn1cbi8qKiBQYXJzZSBhIGJhc2UtMTYgaGV4IHZhbHVlIGludG8gYSBiYXNlLTEwIGludGVnZXIgKi9cbmZ1bmN0aW9uIHBhcnNlSW50RnJvbUhleCh2YWwpIHtcbiAgICByZXR1cm4gcGFyc2VJbnQodmFsLCAxNik7XG59XG5cbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9iYWhhbWFzMTAvY3NzLWNvbG9yLW5hbWVzL2Jsb2IvbWFzdGVyL2Nzcy1jb2xvci1uYW1lcy5qc29uXG4vKipcbiAqIEBoaWRkZW5cbiAqL1xuY29uc3QgbmFtZXMgPSB7XG4gICAgYWxpY2VibHVlOiAnI2YwZjhmZicsXG4gICAgYW50aXF1ZXdoaXRlOiAnI2ZhZWJkNycsXG4gICAgYXF1YTogJyMwMGZmZmYnLFxuICAgIGFxdWFtYXJpbmU6ICcjN2ZmZmQ0JyxcbiAgICBhenVyZTogJyNmMGZmZmYnLFxuICAgIGJlaWdlOiAnI2Y1ZjVkYycsXG4gICAgYmlzcXVlOiAnI2ZmZTRjNCcsXG4gICAgYmxhY2s6ICcjMDAwMDAwJyxcbiAgICBibGFuY2hlZGFsbW9uZDogJyNmZmViY2QnLFxuICAgIGJsdWU6ICcjMDAwMGZmJyxcbiAgICBibHVldmlvbGV0OiAnIzhhMmJlMicsXG4gICAgYnJvd246ICcjYTUyYTJhJyxcbiAgICBidXJseXdvb2Q6ICcjZGViODg3JyxcbiAgICBjYWRldGJsdWU6ICcjNWY5ZWEwJyxcbiAgICBjaGFydHJldXNlOiAnIzdmZmYwMCcsXG4gICAgY2hvY29sYXRlOiAnI2QyNjkxZScsXG4gICAgY29yYWw6ICcjZmY3ZjUwJyxcbiAgICBjb3JuZmxvd2VyYmx1ZTogJyM2NDk1ZWQnLFxuICAgIGNvcm5zaWxrOiAnI2ZmZjhkYycsXG4gICAgY3JpbXNvbjogJyNkYzE0M2MnLFxuICAgIGN5YW46ICcjMDBmZmZmJyxcbiAgICBkYXJrYmx1ZTogJyMwMDAwOGInLFxuICAgIGRhcmtjeWFuOiAnIzAwOGI4YicsXG4gICAgZGFya2dvbGRlbnJvZDogJyNiODg2MGInLFxuICAgIGRhcmtncmF5OiAnI2E5YTlhOScsXG4gICAgZGFya2dyZWVuOiAnIzAwNjQwMCcsXG4gICAgZGFya2dyZXk6ICcjYTlhOWE5JyxcbiAgICBkYXJra2hha2k6ICcjYmRiNzZiJyxcbiAgICBkYXJrbWFnZW50YTogJyM4YjAwOGInLFxuICAgIGRhcmtvbGl2ZWdyZWVuOiAnIzU1NmIyZicsXG4gICAgZGFya29yYW5nZTogJyNmZjhjMDAnLFxuICAgIGRhcmtvcmNoaWQ6ICcjOTkzMmNjJyxcbiAgICBkYXJrcmVkOiAnIzhiMDAwMCcsXG4gICAgZGFya3NhbG1vbjogJyNlOTk2N2EnLFxuICAgIGRhcmtzZWFncmVlbjogJyM4ZmJjOGYnLFxuICAgIGRhcmtzbGF0ZWJsdWU6ICcjNDgzZDhiJyxcbiAgICBkYXJrc2xhdGVncmF5OiAnIzJmNGY0ZicsXG4gICAgZGFya3NsYXRlZ3JleTogJyMyZjRmNGYnLFxuICAgIGRhcmt0dXJxdW9pc2U6ICcjMDBjZWQxJyxcbiAgICBkYXJrdmlvbGV0OiAnIzk0MDBkMycsXG4gICAgZGVlcHBpbms6ICcjZmYxNDkzJyxcbiAgICBkZWVwc2t5Ymx1ZTogJyMwMGJmZmYnLFxuICAgIGRpbWdyYXk6ICcjNjk2OTY5JyxcbiAgICBkaW1ncmV5OiAnIzY5Njk2OScsXG4gICAgZG9kZ2VyYmx1ZTogJyMxZTkwZmYnLFxuICAgIGZpcmVicmljazogJyNiMjIyMjInLFxuICAgIGZsb3JhbHdoaXRlOiAnI2ZmZmFmMCcsXG4gICAgZm9yZXN0Z3JlZW46ICcjMjI4YjIyJyxcbiAgICBmdWNoc2lhOiAnI2ZmMDBmZicsXG4gICAgZ2FpbnNib3JvOiAnI2RjZGNkYycsXG4gICAgZ2hvc3R3aGl0ZTogJyNmOGY4ZmYnLFxuICAgIGdvbGQ6ICcjZmZkNzAwJyxcbiAgICBnb2xkZW5yb2Q6ICcjZGFhNTIwJyxcbiAgICBncmF5OiAnIzgwODA4MCcsXG4gICAgZ3JlZW46ICcjMDA4MDAwJyxcbiAgICBncmVlbnllbGxvdzogJyNhZGZmMmYnLFxuICAgIGdyZXk6ICcjODA4MDgwJyxcbiAgICBob25leWRldzogJyNmMGZmZjAnLFxuICAgIGhvdHBpbms6ICcjZmY2OWI0JyxcbiAgICBpbmRpYW5yZWQ6ICcjY2Q1YzVjJyxcbiAgICBpbmRpZ286ICcjNGIwMDgyJyxcbiAgICBpdm9yeTogJyNmZmZmZjAnLFxuICAgIGtoYWtpOiAnI2YwZTY4YycsXG4gICAgbGF2ZW5kZXI6ICcjZTZlNmZhJyxcbiAgICBsYXZlbmRlcmJsdXNoOiAnI2ZmZjBmNScsXG4gICAgbGF3bmdyZWVuOiAnIzdjZmMwMCcsXG4gICAgbGVtb25jaGlmZm9uOiAnI2ZmZmFjZCcsXG4gICAgbGlnaHRibHVlOiAnI2FkZDhlNicsXG4gICAgbGlnaHRjb3JhbDogJyNmMDgwODAnLFxuICAgIGxpZ2h0Y3lhbjogJyNlMGZmZmYnLFxuICAgIGxpZ2h0Z29sZGVucm9keWVsbG93OiAnI2ZhZmFkMicsXG4gICAgbGlnaHRncmF5OiAnI2QzZDNkMycsXG4gICAgbGlnaHRncmVlbjogJyM5MGVlOTAnLFxuICAgIGxpZ2h0Z3JleTogJyNkM2QzZDMnLFxuICAgIGxpZ2h0cGluazogJyNmZmI2YzEnLFxuICAgIGxpZ2h0c2FsbW9uOiAnI2ZmYTA3YScsXG4gICAgbGlnaHRzZWFncmVlbjogJyMyMGIyYWEnLFxuICAgIGxpZ2h0c2t5Ymx1ZTogJyM4N2NlZmEnLFxuICAgIGxpZ2h0c2xhdGVncmF5OiAnIzc3ODg5OScsXG4gICAgbGlnaHRzbGF0ZWdyZXk6ICcjNzc4ODk5JyxcbiAgICBsaWdodHN0ZWVsYmx1ZTogJyNiMGM0ZGUnLFxuICAgIGxpZ2h0eWVsbG93OiAnI2ZmZmZlMCcsXG4gICAgbGltZTogJyMwMGZmMDAnLFxuICAgIGxpbWVncmVlbjogJyMzMmNkMzInLFxuICAgIGxpbmVuOiAnI2ZhZjBlNicsXG4gICAgbWFnZW50YTogJyNmZjAwZmYnLFxuICAgIG1hcm9vbjogJyM4MDAwMDAnLFxuICAgIG1lZGl1bWFxdWFtYXJpbmU6ICcjNjZjZGFhJyxcbiAgICBtZWRpdW1ibHVlOiAnIzAwMDBjZCcsXG4gICAgbWVkaXVtb3JjaGlkOiAnI2JhNTVkMycsXG4gICAgbWVkaXVtcHVycGxlOiAnIzkzNzBkYicsXG4gICAgbWVkaXVtc2VhZ3JlZW46ICcjM2NiMzcxJyxcbiAgICBtZWRpdW1zbGF0ZWJsdWU6ICcjN2I2OGVlJyxcbiAgICBtZWRpdW1zcHJpbmdncmVlbjogJyMwMGZhOWEnLFxuICAgIG1lZGl1bXR1cnF1b2lzZTogJyM0OGQxY2MnLFxuICAgIG1lZGl1bXZpb2xldHJlZDogJyNjNzE1ODUnLFxuICAgIG1pZG5pZ2h0Ymx1ZTogJyMxOTE5NzAnLFxuICAgIG1pbnRjcmVhbTogJyNmNWZmZmEnLFxuICAgIG1pc3R5cm9zZTogJyNmZmU0ZTEnLFxuICAgIG1vY2Nhc2luOiAnI2ZmZTRiNScsXG4gICAgbmF2YWpvd2hpdGU6ICcjZmZkZWFkJyxcbiAgICBuYXZ5OiAnIzAwMDA4MCcsXG4gICAgb2xkbGFjZTogJyNmZGY1ZTYnLFxuICAgIG9saXZlOiAnIzgwODAwMCcsXG4gICAgb2xpdmVkcmFiOiAnIzZiOGUyMycsXG4gICAgb3JhbmdlOiAnI2ZmYTUwMCcsXG4gICAgb3JhbmdlcmVkOiAnI2ZmNDUwMCcsXG4gICAgb3JjaGlkOiAnI2RhNzBkNicsXG4gICAgcGFsZWdvbGRlbnJvZDogJyNlZWU4YWEnLFxuICAgIHBhbGVncmVlbjogJyM5OGZiOTgnLFxuICAgIHBhbGV0dXJxdW9pc2U6ICcjYWZlZWVlJyxcbiAgICBwYWxldmlvbGV0cmVkOiAnI2RiNzA5MycsXG4gICAgcGFwYXlhd2hpcDogJyNmZmVmZDUnLFxuICAgIHBlYWNocHVmZjogJyNmZmRhYjknLFxuICAgIHBlcnU6ICcjY2Q4NTNmJyxcbiAgICBwaW5rOiAnI2ZmYzBjYicsXG4gICAgcGx1bTogJyNkZGEwZGQnLFxuICAgIHBvd2RlcmJsdWU6ICcjYjBlMGU2JyxcbiAgICBwdXJwbGU6ICcjODAwMDgwJyxcbiAgICByZWJlY2NhcHVycGxlOiAnIzY2MzM5OScsXG4gICAgcmVkOiAnI2ZmMDAwMCcsXG4gICAgcm9zeWJyb3duOiAnI2JjOGY4ZicsXG4gICAgcm95YWxibHVlOiAnIzQxNjllMScsXG4gICAgc2FkZGxlYnJvd246ICcjOGI0NTEzJyxcbiAgICBzYWxtb246ICcjZmE4MDcyJyxcbiAgICBzYW5keWJyb3duOiAnI2Y0YTQ2MCcsXG4gICAgc2VhZ3JlZW46ICcjMmU4YjU3JyxcbiAgICBzZWFzaGVsbDogJyNmZmY1ZWUnLFxuICAgIHNpZW5uYTogJyNhMDUyMmQnLFxuICAgIHNpbHZlcjogJyNjMGMwYzAnLFxuICAgIHNreWJsdWU6ICcjODdjZWViJyxcbiAgICBzbGF0ZWJsdWU6ICcjNmE1YWNkJyxcbiAgICBzbGF0ZWdyYXk6ICcjNzA4MDkwJyxcbiAgICBzbGF0ZWdyZXk6ICcjNzA4MDkwJyxcbiAgICBzbm93OiAnI2ZmZmFmYScsXG4gICAgc3ByaW5nZ3JlZW46ICcjMDBmZjdmJyxcbiAgICBzdGVlbGJsdWU6ICcjNDY4MmI0JyxcbiAgICB0YW46ICcjZDJiNDhjJyxcbiAgICB0ZWFsOiAnIzAwODA4MCcsXG4gICAgdGhpc3RsZTogJyNkOGJmZDgnLFxuICAgIHRvbWF0bzogJyNmZjYzNDcnLFxuICAgIHR1cnF1b2lzZTogJyM0MGUwZDAnLFxuICAgIHZpb2xldDogJyNlZTgyZWUnLFxuICAgIHdoZWF0OiAnI2Y1ZGViMycsXG4gICAgd2hpdGU6ICcjZmZmZmZmJyxcbiAgICB3aGl0ZXNtb2tlOiAnI2Y1ZjVmNScsXG4gICAgeWVsbG93OiAnI2ZmZmYwMCcsXG4gICAgeWVsbG93Z3JlZW46ICcjOWFjZDMyJyxcbn07XG5cbi8qKlxuICogR2l2ZW4gYSBzdHJpbmcgb3Igb2JqZWN0LCBjb252ZXJ0IHRoYXQgaW5wdXQgdG8gUkdCXG4gKlxuICogUG9zc2libGUgc3RyaW5nIGlucHV0czpcbiAqIGBgYFxuICogXCJyZWRcIlxuICogXCIjZjAwXCIgb3IgXCJmMDBcIlxuICogXCIjZmYwMDAwXCIgb3IgXCJmZjAwMDBcIlxuICogXCIjZmYwMDAwMDBcIiBvciBcImZmMDAwMDAwXCJcbiAqIFwicmdiIDI1NSAwIDBcIiBvciBcInJnYiAoMjU1LCAwLCAwKVwiXG4gKiBcInJnYiAxLjAgMCAwXCIgb3IgXCJyZ2IgKDEsIDAsIDApXCJcbiAqIFwicmdiYSAoMjU1LCAwLCAwLCAxKVwiIG9yIFwicmdiYSAyNTUsIDAsIDAsIDFcIlxuICogXCJyZ2JhICgxLjAsIDAsIDAsIDEpXCIgb3IgXCJyZ2JhIDEuMCwgMCwgMCwgMVwiXG4gKiBcImhzbCgwLCAxMDAlLCA1MCUpXCIgb3IgXCJoc2wgMCAxMDAlIDUwJVwiXG4gKiBcImhzbGEoMCwgMTAwJSwgNTAlLCAxKVwiIG9yIFwiaHNsYSAwIDEwMCUgNTAlLCAxXCJcbiAqIFwiaHN2KDAsIDEwMCUsIDEwMCUpXCIgb3IgXCJoc3YgMCAxMDAlIDEwMCVcIlxuICogYGBgXG4gKi9cbmZ1bmN0aW9uIGlucHV0VG9SR0IoY29sb3IpIHtcbiAgICBsZXQgcmdiID0geyByOiAwLCBnOiAwLCBiOiAwIH07XG4gICAgbGV0IGEgPSAxO1xuICAgIGxldCBzID0gbnVsbDtcbiAgICBsZXQgdiA9IG51bGw7XG4gICAgbGV0IGwgPSBudWxsO1xuICAgIGxldCBvayA9IGZhbHNlO1xuICAgIGxldCBmb3JtYXQgPSBmYWxzZTtcbiAgICBpZiAodHlwZW9mIGNvbG9yID09PSAnc3RyaW5nJykge1xuICAgICAgICBjb2xvciA9IHN0cmluZ0lucHV0VG9PYmplY3QoY29sb3IpO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIGNvbG9yID09PSAnb2JqZWN0Jykge1xuICAgICAgICBpZiAoaXNWYWxpZENTU1VuaXQoY29sb3IucikgJiYgaXNWYWxpZENTU1VuaXQoY29sb3IuZykgJiYgaXNWYWxpZENTU1VuaXQoY29sb3IuYikpIHtcbiAgICAgICAgICAgIHJnYiA9IHJnYlRvUmdiKGNvbG9yLnIsIGNvbG9yLmcsIGNvbG9yLmIpO1xuICAgICAgICAgICAgb2sgPSB0cnVlO1xuICAgICAgICAgICAgZm9ybWF0ID0gU3RyaW5nKGNvbG9yLnIpLnN1YnN0cigtMSkgPT09ICclJyA/ICdwcmdiJyA6ICdyZ2InO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGlzVmFsaWRDU1NVbml0KGNvbG9yLmgpICYmIGlzVmFsaWRDU1NVbml0KGNvbG9yLnMpICYmIGlzVmFsaWRDU1NVbml0KGNvbG9yLnYpKSB7XG4gICAgICAgICAgICBzID0gY29udmVydFRvUGVyY2VudGFnZShjb2xvci5zKTtcbiAgICAgICAgICAgIHYgPSBjb252ZXJ0VG9QZXJjZW50YWdlKGNvbG9yLnYpO1xuICAgICAgICAgICAgcmdiID0gaHN2VG9SZ2IoY29sb3IuaCwgcywgdik7XG4gICAgICAgICAgICBvayA9IHRydWU7XG4gICAgICAgICAgICBmb3JtYXQgPSAnaHN2JztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChpc1ZhbGlkQ1NTVW5pdChjb2xvci5oKSAmJiBpc1ZhbGlkQ1NTVW5pdChjb2xvci5zKSAmJiBpc1ZhbGlkQ1NTVW5pdChjb2xvci5sKSkge1xuICAgICAgICAgICAgcyA9IGNvbnZlcnRUb1BlcmNlbnRhZ2UoY29sb3Iucyk7XG4gICAgICAgICAgICBsID0gY29udmVydFRvUGVyY2VudGFnZShjb2xvci5sKTtcbiAgICAgICAgICAgIHJnYiA9IGhzbFRvUmdiKGNvbG9yLmgsIHMsIGwpO1xuICAgICAgICAgICAgb2sgPSB0cnVlO1xuICAgICAgICAgICAgZm9ybWF0ID0gJ2hzbCc7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvbG9yLmhhc093blByb3BlcnR5KCdhJykpIHtcbiAgICAgICAgICAgIGEgPSBjb2xvci5hO1xuICAgICAgICB9XG4gICAgfVxuICAgIGEgPSBib3VuZEFscGhhKGEpO1xuICAgIHJldHVybiB7XG4gICAgICAgIG9rLFxuICAgICAgICBmb3JtYXQ6IGNvbG9yLmZvcm1hdCB8fCBmb3JtYXQsXG4gICAgICAgIHI6IE1hdGgubWluKDI1NSwgTWF0aC5tYXgocmdiLnIsIDApKSxcbiAgICAgICAgZzogTWF0aC5taW4oMjU1LCBNYXRoLm1heChyZ2IuZywgMCkpLFxuICAgICAgICBiOiBNYXRoLm1pbigyNTUsIE1hdGgubWF4KHJnYi5iLCAwKSksXG4gICAgICAgIGEsXG4gICAgfTtcbn1cbi8vIDxodHRwOi8vd3d3LnczLm9yZy9UUi9jc3MzLXZhbHVlcy8jaW50ZWdlcnM+XG5jb25zdCBDU1NfSU5URUdFUiA9ICdbLVxcXFwrXT9cXFxcZCslPyc7XG4vLyA8aHR0cDovL3d3dy53My5vcmcvVFIvY3NzMy12YWx1ZXMvI251bWJlci12YWx1ZT5cbmNvbnN0IENTU19OVU1CRVIgPSAnWy1cXFxcK10/XFxcXGQqXFxcXC5cXFxcZCslPyc7XG4vLyBBbGxvdyBwb3NpdGl2ZS9uZWdhdGl2ZSBpbnRlZ2VyL251bWJlci4gIERvbid0IGNhcHR1cmUgdGhlIGVpdGhlci9vciwganVzdCB0aGUgZW50aXJlIG91dGNvbWUuXG5jb25zdCBDU1NfVU5JVCA9IGAoPzoke0NTU19OVU1CRVJ9KXwoPzoke0NTU19JTlRFR0VSfSlgO1xuLy8gQWN0dWFsIG1hdGNoaW5nLlxuLy8gUGFyZW50aGVzZXMgYW5kIGNvbW1hcyBhcmUgb3B0aW9uYWwsIGJ1dCBub3QgcmVxdWlyZWQuXG4vLyBXaGl0ZXNwYWNlIGNhbiB0YWtlIHRoZSBwbGFjZSBvZiBjb21tYXMgb3Igb3BlbmluZyBwYXJlblxuY29uc3QgUEVSTUlTU0lWRV9NQVRDSDMgPSBgW1xcXFxzfFxcXFwoXSsoJHtDU1NfVU5JVH0pWyx8XFxcXHNdKygke0NTU19VTklUfSlbLHxcXFxcc10rKCR7Q1NTX1VOSVR9KVxcXFxzKlxcXFwpP2A7XG5jb25zdCBQRVJNSVNTSVZFX01BVENINCA9IGBbXFxcXHN8XFxcXChdKygke0NTU19VTklUfSlbLHxcXFxcc10rKCR7Q1NTX1VOSVR9KVssfFxcXFxzXSsoJHtDU1NfVU5JVH0pWyx8XFxcXHNdKygke0NTU19VTklUfSlcXFxccypcXFxcKT9gO1xuY29uc3QgbWF0Y2hlcnMgPSB7XG4gICAgQ1NTX1VOSVQ6IG5ldyBSZWdFeHAoQ1NTX1VOSVQpLFxuICAgIHJnYjogbmV3IFJlZ0V4cCgncmdiJyArIFBFUk1JU1NJVkVfTUFUQ0gzKSxcbiAgICByZ2JhOiBuZXcgUmVnRXhwKCdyZ2JhJyArIFBFUk1JU1NJVkVfTUFUQ0g0KSxcbiAgICBoc2w6IG5ldyBSZWdFeHAoJ2hzbCcgKyBQRVJNSVNTSVZFX01BVENIMyksXG4gICAgaHNsYTogbmV3IFJlZ0V4cCgnaHNsYScgKyBQRVJNSVNTSVZFX01BVENINCksXG4gICAgaHN2OiBuZXcgUmVnRXhwKCdoc3YnICsgUEVSTUlTU0lWRV9NQVRDSDMpLFxuICAgIGhzdmE6IG5ldyBSZWdFeHAoJ2hzdmEnICsgUEVSTUlTU0lWRV9NQVRDSDQpLFxuICAgIGhleDM6IC9eIz8oWzAtOWEtZkEtRl17MX0pKFswLTlhLWZBLUZdezF9KShbMC05YS1mQS1GXXsxfSkkLyxcbiAgICBoZXg2OiAvXiM/KFswLTlhLWZBLUZdezJ9KShbMC05YS1mQS1GXXsyfSkoWzAtOWEtZkEtRl17Mn0pJC8sXG4gICAgaGV4NDogL14jPyhbMC05YS1mQS1GXXsxfSkoWzAtOWEtZkEtRl17MX0pKFswLTlhLWZBLUZdezF9KShbMC05YS1mQS1GXXsxfSkkLyxcbiAgICBoZXg4OiAvXiM/KFswLTlhLWZBLUZdezJ9KShbMC05YS1mQS1GXXsyfSkoWzAtOWEtZkEtRl17Mn0pKFswLTlhLWZBLUZdezJ9KSQvLFxufTtcbi8qKlxuICogUGVybWlzc2l2ZSBzdHJpbmcgcGFyc2luZy4gIFRha2UgaW4gYSBudW1iZXIgb2YgZm9ybWF0cywgYW5kIG91dHB1dCBhbiBvYmplY3RcbiAqIGJhc2VkIG9uIGRldGVjdGVkIGZvcm1hdC4gIFJldHVybnMgYHsgciwgZywgYiB9YCBvciBgeyBoLCBzLCBsIH1gIG9yIGB7IGgsIHMsIHZ9YFxuICovXG5mdW5jdGlvbiBzdHJpbmdJbnB1dFRvT2JqZWN0KGNvbG9yKSB7XG4gICAgY29sb3IgPSBjb2xvci50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAoY29sb3IubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgbGV0IG5hbWVkID0gZmFsc2U7XG4gICAgaWYgKG5hbWVzW2NvbG9yXSkge1xuICAgICAgICBjb2xvciA9IG5hbWVzW2NvbG9yXTtcbiAgICAgICAgbmFtZWQgPSB0cnVlO1xuICAgIH1cbiAgICBlbHNlIGlmIChjb2xvciA9PT0gJ3RyYW5zcGFyZW50Jykge1xuICAgICAgICByZXR1cm4geyByOiAwLCBnOiAwLCBiOiAwLCBhOiAwLCBmb3JtYXQ6ICduYW1lJyB9O1xuICAgIH1cbiAgICAvLyBUcnkgdG8gbWF0Y2ggc3RyaW5nIGlucHV0IHVzaW5nIHJlZ3VsYXIgZXhwcmVzc2lvbnMuXG4gICAgLy8gS2VlcCBtb3N0IG9mIHRoZSBudW1iZXIgYm91bmRpbmcgb3V0IG9mIHRoaXMgZnVuY3Rpb24gLSBkb24ndCB3b3JyeSBhYm91dCBbMCwxXSBvciBbMCwxMDBdIG9yIFswLDM2MF1cbiAgICAvLyBKdXN0IHJldHVybiBhbiBvYmplY3QgYW5kIGxldCB0aGUgY29udmVyc2lvbiBmdW5jdGlvbnMgaGFuZGxlIHRoYXQuXG4gICAgLy8gVGhpcyB3YXkgdGhlIHJlc3VsdCB3aWxsIGJlIHRoZSBzYW1lIHdoZXRoZXIgdGhlIHRpbnljb2xvciBpcyBpbml0aWFsaXplZCB3aXRoIHN0cmluZyBvciBvYmplY3QuXG4gICAgbGV0IG1hdGNoID0gbWF0Y2hlcnMucmdiLmV4ZWMoY29sb3IpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgICByZXR1cm4geyByOiBtYXRjaFsxXSwgZzogbWF0Y2hbMl0sIGI6IG1hdGNoWzNdIH07XG4gICAgfVxuICAgIG1hdGNoID0gbWF0Y2hlcnMucmdiYS5leGVjKGNvbG9yKTtcbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgcmV0dXJuIHsgcjogbWF0Y2hbMV0sIGc6IG1hdGNoWzJdLCBiOiBtYXRjaFszXSwgYTogbWF0Y2hbNF0gfTtcbiAgICB9XG4gICAgbWF0Y2ggPSBtYXRjaGVycy5oc2wuZXhlYyhjb2xvcik7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICAgIHJldHVybiB7IGg6IG1hdGNoWzFdLCBzOiBtYXRjaFsyXSwgbDogbWF0Y2hbM10gfTtcbiAgICB9XG4gICAgbWF0Y2ggPSBtYXRjaGVycy5oc2xhLmV4ZWMoY29sb3IpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgICByZXR1cm4geyBoOiBtYXRjaFsxXSwgczogbWF0Y2hbMl0sIGw6IG1hdGNoWzNdLCBhOiBtYXRjaFs0XSB9O1xuICAgIH1cbiAgICBtYXRjaCA9IG1hdGNoZXJzLmhzdi5leGVjKGNvbG9yKTtcbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgcmV0dXJuIHsgaDogbWF0Y2hbMV0sIHM6IG1hdGNoWzJdLCB2OiBtYXRjaFszXSB9O1xuICAgIH1cbiAgICBtYXRjaCA9IG1hdGNoZXJzLmhzdmEuZXhlYyhjb2xvcik7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICAgIHJldHVybiB7IGg6IG1hdGNoWzFdLCBzOiBtYXRjaFsyXSwgdjogbWF0Y2hbM10sIGE6IG1hdGNoWzRdIH07XG4gICAgfVxuICAgIG1hdGNoID0gbWF0Y2hlcnMuaGV4OC5leGVjKGNvbG9yKTtcbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHI6IHBhcnNlSW50RnJvbUhleChtYXRjaFsxXSksXG4gICAgICAgICAgICBnOiBwYXJzZUludEZyb21IZXgobWF0Y2hbMl0pLFxuICAgICAgICAgICAgYjogcGFyc2VJbnRGcm9tSGV4KG1hdGNoWzNdKSxcbiAgICAgICAgICAgIGE6IGNvbnZlcnRIZXhUb0RlY2ltYWwobWF0Y2hbNF0pLFxuICAgICAgICAgICAgZm9ybWF0OiBuYW1lZCA/ICduYW1lJyA6ICdoZXg4JyxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgbWF0Y2ggPSBtYXRjaGVycy5oZXg2LmV4ZWMoY29sb3IpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcjogcGFyc2VJbnRGcm9tSGV4KG1hdGNoWzFdKSxcbiAgICAgICAgICAgIGc6IHBhcnNlSW50RnJvbUhleChtYXRjaFsyXSksXG4gICAgICAgICAgICBiOiBwYXJzZUludEZyb21IZXgobWF0Y2hbM10pLFxuICAgICAgICAgICAgZm9ybWF0OiBuYW1lZCA/ICduYW1lJyA6ICdoZXgnLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBtYXRjaCA9IG1hdGNoZXJzLmhleDQuZXhlYyhjb2xvcik7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByOiBwYXJzZUludEZyb21IZXgobWF0Y2hbMV0gKyBtYXRjaFsxXSksXG4gICAgICAgICAgICBnOiBwYXJzZUludEZyb21IZXgobWF0Y2hbMl0gKyBtYXRjaFsyXSksXG4gICAgICAgICAgICBiOiBwYXJzZUludEZyb21IZXgobWF0Y2hbM10gKyBtYXRjaFszXSksXG4gICAgICAgICAgICBhOiBjb252ZXJ0SGV4VG9EZWNpbWFsKG1hdGNoWzRdICsgbWF0Y2hbNF0pLFxuICAgICAgICAgICAgZm9ybWF0OiBuYW1lZCA/ICduYW1lJyA6ICdoZXg4JyxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgbWF0Y2ggPSBtYXRjaGVycy5oZXgzLmV4ZWMoY29sb3IpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcjogcGFyc2VJbnRGcm9tSGV4KG1hdGNoWzFdICsgbWF0Y2hbMV0pLFxuICAgICAgICAgICAgZzogcGFyc2VJbnRGcm9tSGV4KG1hdGNoWzJdICsgbWF0Y2hbMl0pLFxuICAgICAgICAgICAgYjogcGFyc2VJbnRGcm9tSGV4KG1hdGNoWzNdICsgbWF0Y2hbM10pLFxuICAgICAgICAgICAgZm9ybWF0OiBuYW1lZCA/ICduYW1lJyA6ICdoZXgnLFxuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG59XG4vKipcbiAqIENoZWNrIHRvIHNlZSBpZiBpdCBsb29rcyBsaWtlIGEgQ1NTIHVuaXRcbiAqIChzZWUgYG1hdGNoZXJzYCBhYm92ZSBmb3IgZGVmaW5pdGlvbikuXG4gKi9cbmZ1bmN0aW9uIGlzVmFsaWRDU1NVbml0KGNvbG9yKSB7XG4gICAgcmV0dXJuICEhbWF0Y2hlcnMuQ1NTX1VOSVQuZXhlYyhTdHJpbmcoY29sb3IpKTtcbn1cblxuY2xhc3MgVGlueUNvbG9yIHtcbiAgICBjb25zdHJ1Y3Rvcihjb2xvciA9ICcnLCBvcHRzID0ge30pIHtcbiAgICAgICAgLy8gSWYgaW5wdXQgaXMgYWxyZWFkeSBhIHRpbnljb2xvciwgcmV0dXJuIGl0c2VsZlxuICAgICAgICBpZiAoY29sb3IgaW5zdGFuY2VvZiBUaW55Q29sb3IpIHtcbiAgICAgICAgICAgIHJldHVybiBjb2xvcjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLm9yaWdpbmFsSW5wdXQgPSBjb2xvcjtcbiAgICAgICAgY29uc3QgcmdiID0gaW5wdXRUb1JHQihjb2xvcik7XG4gICAgICAgIHRoaXMub3JpZ2luYWxJbnB1dCA9IGNvbG9yO1xuICAgICAgICB0aGlzLnIgPSByZ2IucjtcbiAgICAgICAgdGhpcy5nID0gcmdiLmc7XG4gICAgICAgIHRoaXMuYiA9IHJnYi5iO1xuICAgICAgICB0aGlzLmEgPSByZ2IuYTtcbiAgICAgICAgdGhpcy5yb3VuZEEgPSBNYXRoLnJvdW5kKDEwMCAqIHRoaXMuYSkgLyAxMDA7XG4gICAgICAgIHRoaXMuZm9ybWF0ID0gb3B0cy5mb3JtYXQgfHwgcmdiLmZvcm1hdDtcbiAgICAgICAgdGhpcy5ncmFkaWVudFR5cGUgPSBvcHRzLmdyYWRpZW50VHlwZTtcbiAgICAgICAgLy8gRG9uJ3QgbGV0IHRoZSByYW5nZSBvZiBbMCwyNTVdIGNvbWUgYmFjayBpbiBbMCwxXS5cbiAgICAgICAgLy8gUG90ZW50aWFsbHkgbG9zZSBhIGxpdHRsZSBiaXQgb2YgcHJlY2lzaW9uIGhlcmUsIGJ1dCB3aWxsIGZpeCBpc3N1ZXMgd2hlcmVcbiAgICAgICAgLy8gLjUgZ2V0cyBpbnRlcnByZXRlZCBhcyBoYWxmIG9mIHRoZSB0b3RhbCwgaW5zdGVhZCBvZiBoYWxmIG9mIDFcbiAgICAgICAgLy8gSWYgaXQgd2FzIHN1cHBvc2VkIHRvIGJlIDEyOCwgdGhpcyB3YXMgYWxyZWFkeSB0YWtlbiBjYXJlIG9mIGJ5IGBpbnB1dFRvUmdiYFxuICAgICAgICBpZiAodGhpcy5yIDwgMSkge1xuICAgICAgICAgICAgdGhpcy5yID0gTWF0aC5yb3VuZCh0aGlzLnIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmcgPCAxKSB7XG4gICAgICAgICAgICB0aGlzLmcgPSBNYXRoLnJvdW5kKHRoaXMuZyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuYiA8IDEpIHtcbiAgICAgICAgICAgIHRoaXMuYiA9IE1hdGgucm91bmQodGhpcy5iKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmlzVmFsaWQgPSByZ2Iub2s7XG4gICAgfVxuICAgIGlzRGFyaygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0QnJpZ2h0bmVzcygpIDwgMTI4O1xuICAgIH1cbiAgICBpc0xpZ2h0KCkge1xuICAgICAgICByZXR1cm4gIXRoaXMuaXNEYXJrKCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIHBlcmNlaXZlZCBicmlnaHRuZXNzIG9mIHRoZSBjb2xvciwgZnJvbSAwLTI1NS5cbiAgICAgKi9cbiAgICBnZXRCcmlnaHRuZXNzKCkge1xuICAgICAgICAvLyBodHRwOi8vd3d3LnczLm9yZy9UUi9BRVJUI2NvbG9yLWNvbnRyYXN0XG4gICAgICAgIGNvbnN0IHJnYiA9IHRoaXMudG9SZ2IoKTtcbiAgICAgICAgcmV0dXJuIChyZ2IuciAqIDI5OSArIHJnYi5nICogNTg3ICsgcmdiLmIgKiAxMTQpIC8gMTAwMDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgcGVyY2VpdmVkIGx1bWluYW5jZSBvZiBhIGNvbG9yLCBmcm9tIDAtMS5cbiAgICAgKi9cbiAgICBnZXRMdW1pbmFuY2UoKSB7XG4gICAgICAgIC8vIGh0dHA6Ly93d3cudzMub3JnL1RSLzIwMDgvUkVDLVdDQUcyMC0yMDA4MTIxMS8jcmVsYXRpdmVsdW1pbmFuY2VkZWZcbiAgICAgICAgY29uc3QgcmdiID0gdGhpcy50b1JnYigpO1xuICAgICAgICBsZXQgUjtcbiAgICAgICAgbGV0IEc7XG4gICAgICAgIGxldCBCO1xuICAgICAgICBjb25zdCBSc1JHQiA9IHJnYi5yIC8gMjU1O1xuICAgICAgICBjb25zdCBHc1JHQiA9IHJnYi5nIC8gMjU1O1xuICAgICAgICBjb25zdCBCc1JHQiA9IHJnYi5iIC8gMjU1O1xuICAgICAgICBpZiAoUnNSR0IgPD0gMC4wMzkyOCkge1xuICAgICAgICAgICAgUiA9IFJzUkdCIC8gMTIuOTI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBSID0gTWF0aC5wb3coKFJzUkdCICsgMC4wNTUpIC8gMS4wNTUsIDIuNCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKEdzUkdCIDw9IDAuMDM5MjgpIHtcbiAgICAgICAgICAgIEcgPSBHc1JHQiAvIDEyLjkyO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgRyA9IE1hdGgucG93KChHc1JHQiArIDAuMDU1KSAvIDEuMDU1LCAyLjQpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChCc1JHQiA8PSAwLjAzOTI4KSB7XG4gICAgICAgICAgICBCID0gQnNSR0IgLyAxMi45MjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIEIgPSBNYXRoLnBvdygoQnNSR0IgKyAwLjA1NSkgLyAxLjA1NSwgMi40KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gMC4yMTI2ICogUiArIDAuNzE1MiAqIEcgKyAwLjA3MjIgKiBCO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBTZXRzIHRoZSBhbHBoYSB2YWx1ZSBvbiB0aGUgY3VycmVudCBjb2xvci5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBhbHBoYSAtIFRoZSBuZXcgYWxwaGEgdmFsdWUuIFRoZSBhY2NlcHRlZCByYW5nZSBpcyAwLTEuXG4gICAgICovXG4gICAgc2V0QWxwaGEoYWxwaGEpIHtcbiAgICAgICAgdGhpcy5hID0gYm91bmRBbHBoYShhbHBoYSk7XG4gICAgICAgIHRoaXMucm91bmRBID0gTWF0aC5yb3VuZCgxMDAgKiB0aGlzLmEpIC8gMTAwO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgb2JqZWN0IGFzIGEgSFNWQSBvYmplY3QuXG4gICAgICovXG4gICAgdG9Ic3YoKSB7XG4gICAgICAgIGNvbnN0IGhzdiA9IHJnYlRvSHN2KHRoaXMuciwgdGhpcy5nLCB0aGlzLmIpO1xuICAgICAgICByZXR1cm4geyBoOiBoc3YuaCAqIDM2MCwgczogaHN2LnMsIHY6IGhzdi52LCBhOiB0aGlzLmEgfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgaHN2YSB2YWx1ZXMgaW50ZXJwb2xhdGVkIGludG8gYSBzdHJpbmcgd2l0aCB0aGUgZm9sbG93aW5nIGZvcm1hdDpcbiAgICAgKiBcImhzdmEoeHh4LCB4eHgsIHh4eCwgeHgpXCIuXG4gICAgICovXG4gICAgdG9Ic3ZTdHJpbmcoKSB7XG4gICAgICAgIGNvbnN0IGhzdiA9IHJnYlRvSHN2KHRoaXMuciwgdGhpcy5nLCB0aGlzLmIpO1xuICAgICAgICBjb25zdCBoID0gTWF0aC5yb3VuZChoc3YuaCAqIDM2MCk7XG4gICAgICAgIGNvbnN0IHMgPSBNYXRoLnJvdW5kKGhzdi5zICogMTAwKTtcbiAgICAgICAgY29uc3QgdiA9IE1hdGgucm91bmQoaHN2LnYgKiAxMDApO1xuICAgICAgICByZXR1cm4gdGhpcy5hID09PSAxID8gYGhzdigke2h9LCAke3N9JSwgJHt2fSUpYCA6IGBoc3ZhKCR7aH0sICR7c30lLCAke3Z9JSwgJHt0aGlzLnJvdW5kQX0pYDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgb2JqZWN0IGFzIGEgSFNMQSBvYmplY3QuXG4gICAgICovXG4gICAgdG9Ic2woKSB7XG4gICAgICAgIGNvbnN0IGhzbCA9IHJnYlRvSHNsKHRoaXMuciwgdGhpcy5nLCB0aGlzLmIpO1xuICAgICAgICByZXR1cm4geyBoOiBoc2wuaCAqIDM2MCwgczogaHNsLnMsIGw6IGhzbC5sLCBhOiB0aGlzLmEgfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgaHNsYSB2YWx1ZXMgaW50ZXJwb2xhdGVkIGludG8gYSBzdHJpbmcgd2l0aCB0aGUgZm9sbG93aW5nIGZvcm1hdDpcbiAgICAgKiBcImhzbGEoeHh4LCB4eHgsIHh4eCwgeHgpXCIuXG4gICAgICovXG4gICAgdG9Ic2xTdHJpbmcoKSB7XG4gICAgICAgIGNvbnN0IGhzbCA9IHJnYlRvSHNsKHRoaXMuciwgdGhpcy5nLCB0aGlzLmIpO1xuICAgICAgICBjb25zdCBoID0gTWF0aC5yb3VuZChoc2wuaCAqIDM2MCk7XG4gICAgICAgIGNvbnN0IHMgPSBNYXRoLnJvdW5kKGhzbC5zICogMTAwKTtcbiAgICAgICAgY29uc3QgbCA9IE1hdGgucm91bmQoaHNsLmwgKiAxMDApO1xuICAgICAgICByZXR1cm4gdGhpcy5hID09PSAxID8gYGhzbCgke2h9LCAke3N9JSwgJHtsfSUpYCA6IGBoc2xhKCR7aH0sICR7c30lLCAke2x9JSwgJHt0aGlzLnJvdW5kQX0pYDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgaGV4IHZhbHVlIG9mIHRoZSBjb2xvci5cbiAgICAgKiBAcGFyYW0gYWxsb3czQ2hhciB3aWxsIHNob3J0ZW4gaGV4IHZhbHVlIHRvIDMgY2hhciBpZiBwb3NzaWJsZVxuICAgICAqL1xuICAgIHRvSGV4KGFsbG93M0NoYXIgPSBmYWxzZSkge1xuICAgICAgICByZXR1cm4gcmdiVG9IZXgodGhpcy5yLCB0aGlzLmcsIHRoaXMuYiwgYWxsb3czQ2hhcik7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIGhleCB2YWx1ZSBvZiB0aGUgY29sb3IgLXdpdGggYSAjIGFwcGVuZWQuXG4gICAgICogQHBhcmFtIGFsbG93M0NoYXIgd2lsbCBzaG9ydGVuIGhleCB2YWx1ZSB0byAzIGNoYXIgaWYgcG9zc2libGVcbiAgICAgKi9cbiAgICB0b0hleFN0cmluZyhhbGxvdzNDaGFyID0gZmFsc2UpIHtcbiAgICAgICAgcmV0dXJuICcjJyArIHRoaXMudG9IZXgoYWxsb3czQ2hhcik7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIGhleCA4IHZhbHVlIG9mIHRoZSBjb2xvci5cbiAgICAgKiBAcGFyYW0gYWxsb3c0Q2hhciB3aWxsIHNob3J0ZW4gaGV4IHZhbHVlIHRvIDQgY2hhciBpZiBwb3NzaWJsZVxuICAgICAqL1xuICAgIHRvSGV4OChhbGxvdzRDaGFyID0gZmFsc2UpIHtcbiAgICAgICAgcmV0dXJuIHJnYmFUb0hleCh0aGlzLnIsIHRoaXMuZywgdGhpcy5iLCB0aGlzLmEsIGFsbG93NENoYXIpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBoZXggOCB2YWx1ZSBvZiB0aGUgY29sb3IgLXdpdGggYSAjIGFwcGVuZWQuXG4gICAgICogQHBhcmFtIGFsbG93NENoYXIgd2lsbCBzaG9ydGVuIGhleCB2YWx1ZSB0byA0IGNoYXIgaWYgcG9zc2libGVcbiAgICAgKi9cbiAgICB0b0hleDhTdHJpbmcoYWxsb3c0Q2hhciA9IGZhbHNlKSB7XG4gICAgICAgIHJldHVybiAnIycgKyB0aGlzLnRvSGV4OChhbGxvdzRDaGFyKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUmV0dXJucyB0aGUgb2JqZWN0IGFzIGEgUkdCQSBvYmplY3QuXG4gICAgICovXG4gICAgdG9SZ2IoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByOiBNYXRoLnJvdW5kKHRoaXMuciksXG4gICAgICAgICAgICBnOiBNYXRoLnJvdW5kKHRoaXMuZyksXG4gICAgICAgICAgICBiOiBNYXRoLnJvdW5kKHRoaXMuYiksXG4gICAgICAgICAgICBhOiB0aGlzLmEsXG4gICAgICAgIH07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIFJHQkEgdmFsdWVzIGludGVycG9sYXRlZCBpbnRvIGEgc3RyaW5nIHdpdGggdGhlIGZvbGxvd2luZyBmb3JtYXQ6XG4gICAgICogXCJSR0JBKHh4eCwgeHh4LCB4eHgsIHh4KVwiLlxuICAgICAqL1xuICAgIHRvUmdiU3RyaW5nKCkge1xuICAgICAgICBjb25zdCByID0gTWF0aC5yb3VuZCh0aGlzLnIpO1xuICAgICAgICBjb25zdCBnID0gTWF0aC5yb3VuZCh0aGlzLmcpO1xuICAgICAgICBjb25zdCBiID0gTWF0aC5yb3VuZCh0aGlzLmIpO1xuICAgICAgICByZXR1cm4gdGhpcy5hID09PSAxID8gYHJnYigke3J9LCAke2d9LCAke2J9KWAgOiBgcmdiYSgke3J9LCAke2d9LCAke2J9LCAke3RoaXMucm91bmRBfSlgO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBvYmplY3QgYXMgYSBSR0JBIG9iamVjdC5cbiAgICAgKi9cbiAgICB0b1BlcmNlbnRhZ2VSZ2IoKSB7XG4gICAgICAgIGNvbnN0IGZtdCA9ICh4KSA9PiBNYXRoLnJvdW5kKGJvdW5kMDEoeCwgMjU1KSAqIDEwMCkgKyAnJSc7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByOiBmbXQodGhpcy5yKSxcbiAgICAgICAgICAgIGc6IGZtdCh0aGlzLmcpLFxuICAgICAgICAgICAgYjogZm10KHRoaXMuYiksXG4gICAgICAgICAgICBhOiB0aGlzLmEsXG4gICAgICAgIH07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIFJHQkEgcmVsYXRpdmUgdmFsdWVzIGludGVycG9sYXRlZCBpbnRvIGEgc3RyaW5nXG4gICAgICovXG4gICAgdG9QZXJjZW50YWdlUmdiU3RyaW5nKCkge1xuICAgICAgICBjb25zdCBybmQgPSAoeCkgPT4gTWF0aC5yb3VuZChib3VuZDAxKHgsIDI1NSkgKiAxMDApO1xuICAgICAgICByZXR1cm4gdGhpcy5hID09PSAxXG4gICAgICAgICAgICA/IGByZ2IoJHtybmQodGhpcy5yKX0lLCAke3JuZCh0aGlzLmcpfSUsICR7cm5kKHRoaXMuYil9JSlgXG4gICAgICAgICAgICA6IGByZ2JhKCR7cm5kKHRoaXMucil9JSwgJHtybmQodGhpcy5nKX0lLCAke3JuZCh0aGlzLmIpfSUsICR7dGhpcy5yb3VuZEF9KWA7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFRoZSAncmVhbCcgbmFtZSBvZiB0aGUgY29sb3IgLWlmIHRoZXJlIGlzIG9uZS5cbiAgICAgKi9cbiAgICB0b05hbWUoKSB7XG4gICAgICAgIGlmICh0aGlzLmEgPT09IDApIHtcbiAgICAgICAgICAgIHJldHVybiAndHJhbnNwYXJlbnQnO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmEgPCAxKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgaGV4ID0gJyMnICsgcmdiVG9IZXgodGhpcy5yLCB0aGlzLmcsIHRoaXMuYiwgZmFsc2UpO1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhuYW1lcykpIHtcbiAgICAgICAgICAgIGlmIChuYW1lc1trZXldID09PSBoZXgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4ga2V5O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogU3RyaW5nIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBjb2xvci5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBmb3JtYXQgLSBUaGUgZm9ybWF0IHRvIGJlIHVzZWQgd2hlbiBkaXNwbGF5aW5nIHRoZSBzdHJpbmcgcmVwcmVzZW50YXRpb24uXG4gICAgICovXG4gICAgdG9TdHJpbmcoZm9ybWF0KSB7XG4gICAgICAgIGNvbnN0IGZvcm1hdFNldCA9ICEhZm9ybWF0O1xuICAgICAgICBmb3JtYXQgPSBmb3JtYXQgfHwgdGhpcy5mb3JtYXQ7XG4gICAgICAgIGxldCBmb3JtYXR0ZWRTdHJpbmcgPSBmYWxzZTtcbiAgICAgICAgY29uc3QgaGFzQWxwaGEgPSB0aGlzLmEgPCAxICYmIHRoaXMuYSA+PSAwO1xuICAgICAgICBjb25zdCBuZWVkc0FscGhhRm9ybWF0ID0gIWZvcm1hdFNldCAmJiBoYXNBbHBoYSAmJiAoZm9ybWF0LnN0YXJ0c1dpdGgoJ2hleCcpIHx8IGZvcm1hdCA9PT0gJ25hbWUnKTtcbiAgICAgICAgaWYgKG5lZWRzQWxwaGFGb3JtYXQpIHtcbiAgICAgICAgICAgIC8vIFNwZWNpYWwgY2FzZSBmb3IgXCJ0cmFuc3BhcmVudFwiLCBhbGwgb3RoZXIgbm9uLWFscGhhIGZvcm1hdHNcbiAgICAgICAgICAgIC8vIHdpbGwgcmV0dXJuIHJnYmEgd2hlbiB0aGVyZSBpcyB0cmFuc3BhcmVuY3kuXG4gICAgICAgICAgICBpZiAoZm9ybWF0ID09PSAnbmFtZScgJiYgdGhpcy5hID09PSAwKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMudG9OYW1lKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdGhpcy50b1JnYlN0cmluZygpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChmb3JtYXQgPT09ICdyZ2InKSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRTdHJpbmcgPSB0aGlzLnRvUmdiU3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ3ByZ2InKSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRTdHJpbmcgPSB0aGlzLnRvUGVyY2VudGFnZVJnYlN0cmluZygpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChmb3JtYXQgPT09ICdoZXgnIHx8IGZvcm1hdCA9PT0gJ2hleDYnKSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRTdHJpbmcgPSB0aGlzLnRvSGV4U3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ2hleDMnKSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRTdHJpbmcgPSB0aGlzLnRvSGV4U3RyaW5nKHRydWUpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChmb3JtYXQgPT09ICdoZXg0Jykge1xuICAgICAgICAgICAgZm9ybWF0dGVkU3RyaW5nID0gdGhpcy50b0hleDhTdHJpbmcodHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvcm1hdCA9PT0gJ2hleDgnKSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRTdHJpbmcgPSB0aGlzLnRvSGV4OFN0cmluZygpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChmb3JtYXQgPT09ICduYW1lJykge1xuICAgICAgICAgICAgZm9ybWF0dGVkU3RyaW5nID0gdGhpcy50b05hbWUoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZm9ybWF0ID09PSAnaHNsJykge1xuICAgICAgICAgICAgZm9ybWF0dGVkU3RyaW5nID0gdGhpcy50b0hzbFN0cmluZygpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChmb3JtYXQgPT09ICdoc3YnKSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRTdHJpbmcgPSB0aGlzLnRvSHN2U3RyaW5nKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZvcm1hdHRlZFN0cmluZyB8fCB0aGlzLnRvSGV4U3RyaW5nKCk7XG4gICAgfVxuICAgIGNsb25lKCkge1xuICAgICAgICByZXR1cm4gbmV3IFRpbnlDb2xvcih0aGlzLnRvU3RyaW5nKCkpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBMaWdodGVuIHRoZSBjb2xvciBhIGdpdmVuIGFtb3VudC4gUHJvdmlkaW5nIDEwMCB3aWxsIGFsd2F5cyByZXR1cm4gd2hpdGUuXG4gICAgICogQHBhcmFtIGFtb3VudCAtIHZhbGlkIGJldHdlZW4gMS0xMDBcbiAgICAgKi9cbiAgICBsaWdodGVuKGFtb3VudCA9IDEwKSB7XG4gICAgICAgIGNvbnN0IGhzbCA9IHRoaXMudG9Ic2woKTtcbiAgICAgICAgaHNsLmwgKz0gYW1vdW50IC8gMTAwO1xuICAgICAgICBoc2wubCA9IGNsYW1wMDEoaHNsLmwpO1xuICAgICAgICByZXR1cm4gbmV3IFRpbnlDb2xvcihoc2wpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBCcmlnaHRlbiB0aGUgY29sb3IgYSBnaXZlbiBhbW91bnQsIGZyb20gMCB0byAxMDAuXG4gICAgICogQHBhcmFtIGFtb3VudCAtIHZhbGlkIGJldHdlZW4gMS0xMDBcbiAgICAgKi9cbiAgICBicmlnaHRlbihhbW91bnQgPSAxMCkge1xuICAgICAgICBjb25zdCByZ2IgPSB0aGlzLnRvUmdiKCk7XG4gICAgICAgIHJnYi5yID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oMjU1LCByZ2IuciAtIE1hdGgucm91bmQoMjU1ICogLShhbW91bnQgLyAxMDApKSkpO1xuICAgICAgICByZ2IuZyA9IE1hdGgubWF4KDAsIE1hdGgubWluKDI1NSwgcmdiLmcgLSBNYXRoLnJvdW5kKDI1NSAqIC0oYW1vdW50IC8gMTAwKSkpKTtcbiAgICAgICAgcmdiLmIgPSBNYXRoLm1heCgwLCBNYXRoLm1pbigyNTUsIHJnYi5iIC0gTWF0aC5yb3VuZCgyNTUgKiAtKGFtb3VudCAvIDEwMCkpKSk7XG4gICAgICAgIHJldHVybiBuZXcgVGlueUNvbG9yKHJnYik7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIERhcmtlbiB0aGUgY29sb3IgYSBnaXZlbiBhbW91bnQsIGZyb20gMCB0byAxMDAuXG4gICAgICogUHJvdmlkaW5nIDEwMCB3aWxsIGFsd2F5cyByZXR1cm4gYmxhY2suXG4gICAgICogQHBhcmFtIGFtb3VudCAtIHZhbGlkIGJldHdlZW4gMS0xMDBcbiAgICAgKi9cbiAgICBkYXJrZW4oYW1vdW50ID0gMTApIHtcbiAgICAgICAgY29uc3QgaHNsID0gdGhpcy50b0hzbCgpO1xuICAgICAgICBoc2wubCAtPSBhbW91bnQgLyAxMDA7XG4gICAgICAgIGhzbC5sID0gY2xhbXAwMShoc2wubCk7XG4gICAgICAgIHJldHVybiBuZXcgVGlueUNvbG9yKGhzbCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIE1peCB0aGUgY29sb3Igd2l0aCBwdXJlIHdoaXRlLCBmcm9tIDAgdG8gMTAwLlxuICAgICAqIFByb3ZpZGluZyAwIHdpbGwgZG8gbm90aGluZywgcHJvdmlkaW5nIDEwMCB3aWxsIGFsd2F5cyByZXR1cm4gd2hpdGUuXG4gICAgICogQHBhcmFtIGFtb3VudCAtIHZhbGlkIGJldHdlZW4gMS0xMDBcbiAgICAgKi9cbiAgICB0aW50KGFtb3VudCA9IDEwKSB7XG4gICAgICAgIHJldHVybiB0aGlzLm1peCgnd2hpdGUnLCBhbW91bnQpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBNaXggdGhlIGNvbG9yIHdpdGggcHVyZSBibGFjaywgZnJvbSAwIHRvIDEwMC5cbiAgICAgKiBQcm92aWRpbmcgMCB3aWxsIGRvIG5vdGhpbmcsIHByb3ZpZGluZyAxMDAgd2lsbCBhbHdheXMgcmV0dXJuIGJsYWNrLlxuICAgICAqIEBwYXJhbSBhbW91bnQgLSB2YWxpZCBiZXR3ZWVuIDEtMTAwXG4gICAgICovXG4gICAgc2hhZGUoYW1vdW50ID0gMTApIHtcbiAgICAgICAgcmV0dXJuIHRoaXMubWl4KCdibGFjaycsIGFtb3VudCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIERlc2F0dXJhdGUgdGhlIGNvbG9yIGEgZ2l2ZW4gYW1vdW50LCBmcm9tIDAgdG8gMTAwLlxuICAgICAqIFByb3ZpZGluZyAxMDAgd2lsbCBpcyB0aGUgc2FtZSBhcyBjYWxsaW5nIGdyZXlzY2FsZVxuICAgICAqIEBwYXJhbSBhbW91bnQgLSB2YWxpZCBiZXR3ZWVuIDEtMTAwXG4gICAgICovXG4gICAgZGVzYXR1cmF0ZShhbW91bnQgPSAxMCkge1xuICAgICAgICBjb25zdCBoc2wgPSB0aGlzLnRvSHNsKCk7XG4gICAgICAgIGhzbC5zIC09IGFtb3VudCAvIDEwMDtcbiAgICAgICAgaHNsLnMgPSBjbGFtcDAxKGhzbC5zKTtcbiAgICAgICAgcmV0dXJuIG5ldyBUaW55Q29sb3IoaHNsKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogU2F0dXJhdGUgdGhlIGNvbG9yIGEgZ2l2ZW4gYW1vdW50LCBmcm9tIDAgdG8gMTAwLlxuICAgICAqIEBwYXJhbSBhbW91bnQgLSB2YWxpZCBiZXR3ZWVuIDEtMTAwXG4gICAgICovXG4gICAgc2F0dXJhdGUoYW1vdW50ID0gMTApIHtcbiAgICAgICAgY29uc3QgaHNsID0gdGhpcy50b0hzbCgpO1xuICAgICAgICBoc2wucyArPSBhbW91bnQgLyAxMDA7XG4gICAgICAgIGhzbC5zID0gY2xhbXAwMShoc2wucyk7XG4gICAgICAgIHJldHVybiBuZXcgVGlueUNvbG9yKGhzbCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENvbXBsZXRlbHkgZGVzYXR1cmF0ZXMgYSBjb2xvciBpbnRvIGdyZXlzY2FsZS5cbiAgICAgKiBTYW1lIGFzIGNhbGxpbmcgYGRlc2F0dXJhdGUoMTAwKWBcbiAgICAgKi9cbiAgICBncmV5c2NhbGUoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmRlc2F0dXJhdGUoMTAwKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogU3BpbiB0YWtlcyBhIHBvc2l0aXZlIG9yIG5lZ2F0aXZlIGFtb3VudCB3aXRoaW4gWy0zNjAsIDM2MF0gaW5kaWNhdGluZyB0aGUgY2hhbmdlIG9mIGh1ZS5cbiAgICAgKiBWYWx1ZXMgb3V0c2lkZSBvZiB0aGlzIHJhbmdlIHdpbGwgYmUgd3JhcHBlZCBpbnRvIHRoaXMgcmFuZ2UuXG4gICAgICovXG4gICAgc3BpbihhbW91bnQpIHtcbiAgICAgICAgY29uc3QgaHNsID0gdGhpcy50b0hzbCgpO1xuICAgICAgICBjb25zdCBodWUgPSAoaHNsLmggKyBhbW91bnQpICUgMzYwO1xuICAgICAgICBoc2wuaCA9IGh1ZSA8IDAgPyAzNjAgKyBodWUgOiBodWU7XG4gICAgICAgIHJldHVybiBuZXcgVGlueUNvbG9yKGhzbCk7XG4gICAgfVxuICAgIG1peChjb2xvciwgYW1vdW50ID0gNTApIHtcbiAgICAgICAgY29uc3QgcmdiMSA9IHRoaXMudG9SZ2IoKTtcbiAgICAgICAgY29uc3QgcmdiMiA9IG5ldyBUaW55Q29sb3IoY29sb3IpLnRvUmdiKCk7XG4gICAgICAgIGNvbnN0IHAgPSBhbW91bnQgLyAxMDA7XG4gICAgICAgIGNvbnN0IHJnYmEgPSB7XG4gICAgICAgICAgICByOiAocmdiMi5yIC0gcmdiMS5yKSAqIHAgKyByZ2IxLnIsXG4gICAgICAgICAgICBnOiAocmdiMi5nIC0gcmdiMS5nKSAqIHAgKyByZ2IxLmcsXG4gICAgICAgICAgICBiOiAocmdiMi5iIC0gcmdiMS5iKSAqIHAgKyByZ2IxLmIsXG4gICAgICAgICAgICBhOiAocmdiMi5hIC0gcmdiMS5hKSAqIHAgKyByZ2IxLmEsXG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiBuZXcgVGlueUNvbG9yKHJnYmEpO1xuICAgIH1cbiAgICBhbmFsb2dvdXMocmVzdWx0cyA9IDYsIHNsaWNlcyA9IDMwKSB7XG4gICAgICAgIGNvbnN0IGhzbCA9IHRoaXMudG9Ic2woKTtcbiAgICAgICAgY29uc3QgcGFydCA9IDM2MCAvIHNsaWNlcztcbiAgICAgICAgY29uc3QgcmV0ID0gW3RoaXNdO1xuICAgICAgICBmb3IgKGhzbC5oID0gKGhzbC5oIC0gKChwYXJ0ICogcmVzdWx0cykgPj4gMSkgKyA3MjApICUgMzYwOyAtLXJlc3VsdHM7KSB7XG4gICAgICAgICAgICBoc2wuaCA9IChoc2wuaCArIHBhcnQpICUgMzYwO1xuICAgICAgICAgICAgcmV0LnB1c2gobmV3IFRpbnlDb2xvcihoc2wpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmV0O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiB0YWtlbiBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9pbmZ1c2lvbi9qUXVlcnkteGNvbG9yL2Jsb2IvbWFzdGVyL2pxdWVyeS54Y29sb3IuanNcbiAgICAgKi9cbiAgICBjb21wbGVtZW50KCkge1xuICAgICAgICBjb25zdCBoc2wgPSB0aGlzLnRvSHNsKCk7XG4gICAgICAgIGhzbC5oID0gKGhzbC5oICsgMTgwKSAlIDM2MDtcbiAgICAgICAgcmV0dXJuIG5ldyBUaW55Q29sb3IoaHNsKTtcbiAgICB9XG4gICAgbW9ub2Nocm9tYXRpYyhyZXN1bHRzID0gNikge1xuICAgICAgICBjb25zdCBoc3YgPSB0aGlzLnRvSHN2KCk7XG4gICAgICAgIGNvbnN0IGggPSBoc3YuaDtcbiAgICAgICAgY29uc3QgcyA9IGhzdi5zO1xuICAgICAgICBsZXQgdiA9IGhzdi52O1xuICAgICAgICBjb25zdCByZXMgPSBbXTtcbiAgICAgICAgY29uc3QgbW9kaWZpY2F0aW9uID0gMSAvIHJlc3VsdHM7XG4gICAgICAgIHdoaWxlIChyZXN1bHRzLS0pIHtcbiAgICAgICAgICAgIHJlcy5wdXNoKG5ldyBUaW55Q29sb3IoeyBoLCBzLCB2IH0pKTtcbiAgICAgICAgICAgIHYgPSAodiArIG1vZGlmaWNhdGlvbikgJSAxO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXM7XG4gICAgfVxuICAgIHNwbGl0Y29tcGxlbWVudCgpIHtcbiAgICAgICAgY29uc3QgaHNsID0gdGhpcy50b0hzbCgpO1xuICAgICAgICBjb25zdCBoID0gaHNsLmg7XG4gICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICB0aGlzLFxuICAgICAgICAgICAgbmV3IFRpbnlDb2xvcih7IGg6IChoICsgNzIpICUgMzYwLCBzOiBoc2wucywgbDogaHNsLmwgfSksXG4gICAgICAgICAgICBuZXcgVGlueUNvbG9yKHsgaDogKGggKyAyMTYpICUgMzYwLCBzOiBoc2wucywgbDogaHNsLmwgfSksXG4gICAgICAgIF07XG4gICAgfVxuICAgIHRyaWFkKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5wb2x5YWQoMyk7XG4gICAgfVxuICAgIHRldHJhZCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucG9seWFkKDQpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBHZXQgcG9seWFkIGNvbG9ycywgbGlrZSAoZm9yIDEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIGV0Yy4uLilcbiAgICAgKiBtb25hZCwgZHlhZCwgdHJpYWQsIHRldHJhZCwgcGVudGFkLCBoZXhhZCwgaGVwdGFkLCBvY3RhZCwgZXRjLi4uXG4gICAgICovXG4gICAgcG9seWFkKG4pIHtcbiAgICAgICAgY29uc3QgaHNsID0gdGhpcy50b0hzbCgpO1xuICAgICAgICBjb25zdCBoID0gaHNsLmg7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFt0aGlzXTtcbiAgICAgICAgY29uc3QgaW5jcmVtZW50ID0gMzYwIC8gbjtcbiAgICAgICAgZm9yIChsZXQgaSA9IDE7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKG5ldyBUaW55Q29sb3IoeyBoOiAoaCArIGkgKiBpbmNyZW1lbnQpICUgMzYwLCBzOiBoc2wucywgbDogaHNsLmwgfSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIGNvbXBhcmUgY29sb3IgdnMgY3VycmVudCBjb2xvclxuICAgICAqL1xuICAgIGVxdWFscyhjb2xvcikge1xuICAgICAgICByZXR1cm4gdGhpcy50b1JnYlN0cmluZygpID09PSBuZXcgVGlueUNvbG9yKGNvbG9yKS50b1JnYlN0cmluZygpO1xuICAgIH1cbn1cblxuLy8gUmVhZGFiaWxpdHkgRnVuY3Rpb25zXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIDxodHRwOi8vd3d3LnczLm9yZy9UUi8yMDA4L1JFQy1XQ0FHMjAtMjAwODEyMTEvI2NvbnRyYXN0LXJhdGlvZGVmIChXQ0FHIFZlcnNpb24gMilcbi8qKlxuICogQUtBIGBjb250cmFzdGBcbiAqXG4gKiBBbmFseXplIHRoZSAyIGNvbG9ycyBhbmQgcmV0dXJucyB0aGUgY29sb3IgY29udHJhc3QgZGVmaW5lZCBieSAoV0NBRyBWZXJzaW9uIDIpXG4gKi9cbmZ1bmN0aW9uIHJlYWRhYmlsaXR5KGNvbG9yMSwgY29sb3IyKSB7XG4gICAgY29uc3QgYzEgPSBuZXcgVGlueUNvbG9yKGNvbG9yMSk7XG4gICAgY29uc3QgYzIgPSBuZXcgVGlueUNvbG9yKGNvbG9yMik7XG4gICAgcmV0dXJuICgoTWF0aC5tYXgoYzEuZ2V0THVtaW5hbmNlKCksIGMyLmdldEx1bWluYW5jZSgpKSArIDAuMDUpIC9cbiAgICAgICAgKE1hdGgubWluKGMxLmdldEx1bWluYW5jZSgpLCBjMi5nZXRMdW1pbmFuY2UoKSkgKyAwLjA1KSk7XG59XG4vKipcbiAqIEVuc3VyZSB0aGF0IGZvcmVncm91bmQgYW5kIGJhY2tncm91bmQgY29sb3IgY29tYmluYXRpb25zIG1lZXQgV0NBRzIgZ3VpZGVsaW5lcy5cbiAqIFRoZSB0aGlyZCBhcmd1bWVudCBpcyBhbiBvYmplY3QuXG4gKiAgICAgIHRoZSAnbGV2ZWwnIHByb3BlcnR5IHN0YXRlcyAnQUEnIG9yICdBQUEnIC0gaWYgbWlzc2luZyBvciBpbnZhbGlkLCBpdCBkZWZhdWx0cyB0byAnQUEnO1xuICogICAgICB0aGUgJ3NpemUnIHByb3BlcnR5IHN0YXRlcyAnbGFyZ2UnIG9yICdzbWFsbCcgLSBpZiBtaXNzaW5nIG9yIGludmFsaWQsIGl0IGRlZmF1bHRzIHRvICdzbWFsbCcuXG4gKiBJZiB0aGUgZW50aXJlIG9iamVjdCBpcyBhYnNlbnQsIGlzUmVhZGFibGUgZGVmYXVsdHMgdG8ge2xldmVsOlwiQUFcIixzaXplOlwic21hbGxcIn0uXG4gKlxuICogRXhhbXBsZVxuICogYGBgdHNcbiAqIG5ldyBUaW55Q29sb3IoKS5pc1JlYWRhYmxlKCcjMDAwJywgJyMxMTEnKSA9PiBmYWxzZVxuICogbmV3IFRpbnlDb2xvcigpLmlzUmVhZGFibGUoJyMwMDAnLCAnIzExMScsIHsgbGV2ZWw6ICdBQScsIHNpemU6ICdsYXJnZScgfSkgPT4gZmFsc2VcbiAqIGBgYFxuICovXG5mdW5jdGlvbiBpc1JlYWRhYmxlKGNvbG9yMSwgY29sb3IyLCB3Y2FnMiA9IHsgbGV2ZWw6ICdBQScsIHNpemU6ICdzbWFsbCcgfSkge1xuICAgIGNvbnN0IHJlYWRhYmlsaXR5TGV2ZWwgPSByZWFkYWJpbGl0eShjb2xvcjEsIGNvbG9yMik7XG4gICAgc3dpdGNoICgod2NhZzIubGV2ZWwgfHwgJ0FBJykgKyAod2NhZzIuc2l6ZSB8fCAnc21hbGwnKSkge1xuICAgICAgICBjYXNlICdBQXNtYWxsJzpcbiAgICAgICAgY2FzZSAnQUFBbGFyZ2UnOlxuICAgICAgICAgICAgcmV0dXJuIHJlYWRhYmlsaXR5TGV2ZWwgPj0gNC41O1xuICAgICAgICBjYXNlICdBQWxhcmdlJzpcbiAgICAgICAgICAgIHJldHVybiByZWFkYWJpbGl0eUxldmVsID49IDM7XG4gICAgICAgIGNhc2UgJ0FBQXNtYWxsJzpcbiAgICAgICAgICAgIHJldHVybiByZWFkYWJpbGl0eUxldmVsID49IDc7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn1cbi8qKlxuICogR2l2ZW4gYSBiYXNlIGNvbG9yIGFuZCBhIGxpc3Qgb2YgcG9zc2libGUgZm9yZWdyb3VuZCBvciBiYWNrZ3JvdW5kXG4gKiBjb2xvcnMgZm9yIHRoYXQgYmFzZSwgcmV0dXJucyB0aGUgbW9zdCByZWFkYWJsZSBjb2xvci5cbiAqIE9wdGlvbmFsbHkgcmV0dXJucyBCbGFjayBvciBXaGl0ZSBpZiB0aGUgbW9zdCByZWFkYWJsZSBjb2xvciBpcyB1bnJlYWRhYmxlLlxuICpcbiAqIEBwYXJhbSBiYXNlQ29sb3IgLSB0aGUgYmFzZSBjb2xvci5cbiAqIEBwYXJhbSBjb2xvckxpc3QgLSBhcnJheSBvZiBjb2xvcnMgdG8gcGljayB0aGUgbW9zdCByZWFkYWJsZSBvbmUgZnJvbS5cbiAqIEBwYXJhbSBhcmdzIC0gYW5kIG9iamVjdCB3aXRoIGV4dHJhIGFyZ3VtZW50c1xuICpcbiAqIEV4YW1wbGVcbiAqIGBgYHRzXG4gKiBuZXcgVGlueUNvbG9yKCkubW9zdFJlYWRhYmxlKCcjMTIzJywgWycjMTI0XCIsIFwiIzEyNSddLCB7IGluY2x1ZGVGYWxsYmFja0NvbG9yczogZmFsc2UgfSkudG9IZXhTdHJpbmcoKTsgLy8gXCIjMTEyMjU1XCJcbiAqIG5ldyBUaW55Q29sb3IoKS5tb3N0UmVhZGFibGUoJyMxMjMnLCBbJyMxMjRcIiwgXCIjMTI1J10seyBpbmNsdWRlRmFsbGJhY2tDb2xvcnM6IHRydWUgfSkudG9IZXhTdHJpbmcoKTsgIC8vIFwiI2ZmZmZmZlwiXG4gKiBuZXcgVGlueUNvbG9yKCkubW9zdFJlYWRhYmxlKCcjYTgwMTVhJywgW1wiI2ZhZjNmM1wiXSwgeyBpbmNsdWRlRmFsbGJhY2tDb2xvcnM6dHJ1ZSwgbGV2ZWw6ICdBQUEnLCBzaXplOiAnbGFyZ2UnIH0pLnRvSGV4U3RyaW5nKCk7IC8vIFwiI2ZhZjNmM1wiXG4gKiBuZXcgVGlueUNvbG9yKCkubW9zdFJlYWRhYmxlKCcjYTgwMTVhJywgW1wiI2ZhZjNmM1wiXSwgeyBpbmNsdWRlRmFsbGJhY2tDb2xvcnM6dHJ1ZSwgbGV2ZWw6ICdBQUEnLCBzaXplOiAnc21hbGwnIH0pLnRvSGV4U3RyaW5nKCk7IC8vIFwiI2ZmZmZmZlwiXG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gbW9zdFJlYWRhYmxlKGJhc2VDb2xvciwgY29sb3JMaXN0LCBhcmdzID0geyBpbmNsdWRlRmFsbGJhY2tDb2xvcnM6IGZhbHNlLCBsZXZlbDogJ0FBJywgc2l6ZTogJ3NtYWxsJyB9KSB7XG4gICAgbGV0IGJlc3RDb2xvciA9IG51bGw7XG4gICAgbGV0IGJlc3RTY29yZSA9IDA7XG4gICAgY29uc3QgaW5jbHVkZUZhbGxiYWNrQ29sb3JzID0gYXJncy5pbmNsdWRlRmFsbGJhY2tDb2xvcnM7XG4gICAgY29uc3QgbGV2ZWwgPSBhcmdzLmxldmVsO1xuICAgIGNvbnN0IHNpemUgPSBhcmdzLnNpemU7XG4gICAgZm9yIChjb25zdCBjb2xvciBvZiBjb2xvckxpc3QpIHtcbiAgICAgICAgY29uc3Qgc2NvcmUgPSByZWFkYWJpbGl0eShiYXNlQ29sb3IsIGNvbG9yKTtcbiAgICAgICAgaWYgKHNjb3JlID4gYmVzdFNjb3JlKSB7XG4gICAgICAgICAgICBiZXN0U2NvcmUgPSBzY29yZTtcbiAgICAgICAgICAgIGJlc3RDb2xvciA9IG5ldyBUaW55Q29sb3IoY29sb3IpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChpc1JlYWRhYmxlKGJhc2VDb2xvciwgYmVzdENvbG9yLCB7IGxldmVsLCBzaXplIH0pIHx8ICFpbmNsdWRlRmFsbGJhY2tDb2xvcnMpIHtcbiAgICAgICAgcmV0dXJuIGJlc3RDb2xvcjtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGFyZ3MuaW5jbHVkZUZhbGxiYWNrQ29sb3JzID0gZmFsc2U7XG4gICAgICAgIHJldHVybiBtb3N0UmVhZGFibGUoYmFzZUNvbG9yLCBbJyNmZmYnLCAnIzAwMCddLCBhcmdzKTtcbiAgICB9XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgY29sb3IgcmVwcmVzZW50ZWQgYXMgYSBNaWNyb3NvZnQgZmlsdGVyIGZvciB1c2UgaW4gb2xkIHZlcnNpb25zIG9mIElFLlxuICovXG5mdW5jdGlvbiB0b01zRmlsdGVyKGZpcnN0Q29sb3IsIHNlY29uZENvbG9yKSB7XG4gICAgY29uc3QgY29sb3IgPSBuZXcgVGlueUNvbG9yKGZpcnN0Q29sb3IpO1xuICAgIGNvbnN0IGhleDhTdHJpbmcgPSAnIycgKyByZ2JhVG9BcmdiSGV4KGNvbG9yLnIsIGNvbG9yLmcsIGNvbG9yLmIsIGNvbG9yLmEpO1xuICAgIGxldCBzZWNvbmRIZXg4U3RyaW5nID0gaGV4OFN0cmluZztcbiAgICBjb25zdCBncmFkaWVudFR5cGUgPSBjb2xvci5ncmFkaWVudFR5cGUgPyAnR3JhZGllbnRUeXBlID0gMSwgJyA6ICcnO1xuICAgIGlmIChzZWNvbmRDb2xvcikge1xuICAgICAgICBjb25zdCBzID0gbmV3IFRpbnlDb2xvcihzZWNvbmRDb2xvcik7XG4gICAgICAgIHNlY29uZEhleDhTdHJpbmcgPSAnIycgKyByZ2JhVG9BcmdiSGV4KHMuciwgcy5nLCBzLmIsIHMuYSk7XG4gICAgfVxuICAgIHJldHVybiBgcHJvZ2lkOkRYSW1hZ2VUcmFuc2Zvcm0uTWljcm9zb2Z0LmdyYWRpZW50KCR7Z3JhZGllbnRUeXBlfXN0YXJ0Q29sb3JzdHI9JHtoZXg4U3RyaW5nfSxlbmRDb2xvcnN0cj0ke3NlY29uZEhleDhTdHJpbmd9KWA7XG59XG5cbi8qKlxuICogSWYgaW5wdXQgaXMgYW4gb2JqZWN0LCBmb3JjZSAxIGludG8gXCIxLjBcIiB0byBoYW5kbGUgcmF0aW9zIHByb3Blcmx5XG4gKiBTdHJpbmcgaW5wdXQgcmVxdWlyZXMgXCIxLjBcIiBhcyBpbnB1dCwgc28gMSB3aWxsIGJlIHRyZWF0ZWQgYXMgMVxuICovXG5mdW5jdGlvbiBmcm9tUmF0aW8ocmF0aW8sIG9wdHMpIHtcbiAgICBjb25zdCBuZXdDb2xvciA9IHtcbiAgICAgICAgcjogY29udmVydFRvUGVyY2VudGFnZShyYXRpby5yKSxcbiAgICAgICAgZzogY29udmVydFRvUGVyY2VudGFnZShyYXRpby5nKSxcbiAgICAgICAgYjogY29udmVydFRvUGVyY2VudGFnZShyYXRpby5iKSxcbiAgICB9O1xuICAgIGlmIChyYXRpby5hICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgbmV3Q29sb3IuYSA9ICtyYXRpby5hO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IFRpbnlDb2xvcihuZXdDb2xvciwgb3B0cyk7XG59XG4vKiogb2xkIHJhbmRvbSBmdW5jdGlvbiAqL1xuZnVuY3Rpb24gbGVnYWN5UmFuZG9tKCkge1xuICAgIHJldHVybiBuZXcgVGlueUNvbG9yKHtcbiAgICAgICAgcjogTWF0aC5yYW5kb20oKSxcbiAgICAgICAgZzogTWF0aC5yYW5kb20oKSxcbiAgICAgICAgYjogTWF0aC5yYW5kb20oKSxcbiAgICB9KTtcbn1cblxuLy8gcmFuZG9tQ29sb3IgYnkgRGF2aWQgTWVyZmllbGQgdW5kZXIgdGhlIENDMCBsaWNlbnNlXG5mdW5jdGlvbiByYW5kb20ob3B0aW9ucyA9IHt9KSB7XG4gICAgLy8gQ2hlY2sgaWYgd2UgbmVlZCB0byBnZW5lcmF0ZSBtdWx0aXBsZSBjb2xvcnNcbiAgICBpZiAob3B0aW9ucy5jb3VudCAhPT0gdW5kZWZpbmVkICYmIG9wdGlvbnMuY291bnQgIT09IG51bGwpIHtcbiAgICAgICAgY29uc3QgdG90YWxDb2xvcnMgPSBvcHRpb25zLmNvdW50O1xuICAgICAgICBjb25zdCBjb2xvcnMgPSBbXTtcbiAgICAgICAgb3B0aW9ucy5jb3VudCA9IHVuZGVmaW5lZDtcbiAgICAgICAgd2hpbGUgKHRvdGFsQ29sb3JzID4gY29sb3JzLmxlbmd0aCkge1xuICAgICAgICAgICAgLy8gU2luY2Ugd2UncmUgZ2VuZXJhdGluZyBtdWx0aXBsZSBjb2xvcnMsXG4gICAgICAgICAgICAvLyBpbmNyZW1lbWVudCB0aGUgc2VlZC4gT3RoZXJ3aXNlIHdlJ2QganVzdFxuICAgICAgICAgICAgLy8gZ2VuZXJhdGUgdGhlIHNhbWUgY29sb3IgZWFjaCB0aW1lLi4uXG4gICAgICAgICAgICBvcHRpb25zLmNvdW50ID0gbnVsbDtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLnNlZWQpIHtcbiAgICAgICAgICAgICAgICBvcHRpb25zLnNlZWQgKz0gMTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbG9ycy5wdXNoKHJhbmRvbShvcHRpb25zKSk7XG4gICAgICAgIH1cbiAgICAgICAgb3B0aW9ucy5jb3VudCA9IHRvdGFsQ29sb3JzO1xuICAgICAgICByZXR1cm4gY29sb3JzO1xuICAgIH1cbiAgICAvLyBGaXJzdCB3ZSBwaWNrIGEgaHVlIChIKVxuICAgIGNvbnN0IGggPSBwaWNrSHVlKG9wdGlvbnMuaHVlLCBvcHRpb25zLnNlZWQpO1xuICAgIC8vIFRoZW4gdXNlIEggdG8gZGV0ZXJtaW5lIHNhdHVyYXRpb24gKFMpXG4gICAgY29uc3QgcyA9IHBpY2tTYXR1cmF0aW9uKGgsIG9wdGlvbnMpO1xuICAgIC8vIFRoZW4gdXNlIFMgYW5kIEggdG8gZGV0ZXJtaW5lIGJyaWdodG5lc3MgKEIpLlxuICAgIGNvbnN0IHYgPSBwaWNrQnJpZ2h0bmVzcyhoLCBzLCBvcHRpb25zKTtcbiAgICBjb25zdCByZXMgPSB7IGgsIHMsIHYgfTtcbiAgICBpZiAob3B0aW9ucy5hbHBoYSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJlcy5hID0gb3B0aW9ucy5hbHBoYTtcbiAgICB9XG4gICAgLy8gVGhlbiB3ZSByZXR1cm4gdGhlIEhTQiBjb2xvciBpbiB0aGUgZGVzaXJlZCBmb3JtYXRcbiAgICByZXR1cm4gbmV3IFRpbnlDb2xvcihyZXMpO1xufVxuZnVuY3Rpb24gcGlja0h1ZShodWUsIHNlZWQpIHtcbiAgICBjb25zdCBodWVSYW5nZSA9IGdldEh1ZVJhbmdlKGh1ZSk7XG4gICAgbGV0IHJlcyA9IHJhbmRvbVdpdGhpbihodWVSYW5nZSwgc2VlZCk7XG4gICAgLy8gSW5zdGVhZCBvZiBzdG9yaW5nIHJlZCBhcyB0d28gc2VwZXJhdGUgcmFuZ2VzLFxuICAgIC8vIHdlIGdyb3VwIHRoZW0sIHVzaW5nIG5lZ2F0aXZlIG51bWJlcnNcbiAgICBpZiAocmVzIDwgMCkge1xuICAgICAgICByZXMgPSAzNjAgKyByZXM7XG4gICAgfVxuICAgIHJldHVybiByZXM7XG59XG5mdW5jdGlvbiBwaWNrU2F0dXJhdGlvbihodWUsIG9wdGlvbnMpIHtcbiAgICBpZiAob3B0aW9ucy5odWUgPT09ICdtb25vY2hyb21lJykge1xuICAgICAgICByZXR1cm4gMDtcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMubHVtaW5vc2l0eSA9PT0gJ3JhbmRvbScpIHtcbiAgICAgICAgcmV0dXJuIHJhbmRvbVdpdGhpbihbMCwgMTAwXSwgb3B0aW9ucy5zZWVkKTtcbiAgICB9XG4gICAgY29uc3Qgc2F0dXJhdGlvblJhbmdlID0gZ2V0Q29sb3JJbmZvKGh1ZSkuc2F0dXJhdGlvblJhbmdlO1xuICAgIGxldCBzTWluID0gc2F0dXJhdGlvblJhbmdlWzBdO1xuICAgIGxldCBzTWF4ID0gc2F0dXJhdGlvblJhbmdlWzFdO1xuICAgIHN3aXRjaCAob3B0aW9ucy5sdW1pbm9zaXR5KSB7XG4gICAgICAgIGNhc2UgJ2JyaWdodCc6XG4gICAgICAgICAgICBzTWluID0gNTU7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnZGFyayc6XG4gICAgICAgICAgICBzTWluID0gc01heCAtIDEwO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ2xpZ2h0JzpcbiAgICAgICAgICAgIHNNYXggPSA1NTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICByZXR1cm4gcmFuZG9tV2l0aGluKFtzTWluLCBzTWF4XSwgb3B0aW9ucy5zZWVkKTtcbn1cbmZ1bmN0aW9uIHBpY2tCcmlnaHRuZXNzKEgsIFMsIG9wdGlvbnMpIHtcbiAgICBsZXQgYk1pbiA9IGdldE1pbmltdW1CcmlnaHRuZXNzKEgsIFMpO1xuICAgIGxldCBiTWF4ID0gMTAwO1xuICAgIHN3aXRjaCAob3B0aW9ucy5sdW1pbm9zaXR5KSB7XG4gICAgICAgIGNhc2UgJ2RhcmsnOlxuICAgICAgICAgICAgYk1heCA9IGJNaW4gKyAyMDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdsaWdodCc6XG4gICAgICAgICAgICBiTWluID0gKGJNYXggKyBiTWluKSAvIDI7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAncmFuZG9tJzpcbiAgICAgICAgICAgIGJNaW4gPSAwO1xuICAgICAgICAgICAgYk1heCA9IDEwMDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICByZXR1cm4gcmFuZG9tV2l0aGluKFtiTWluLCBiTWF4XSwgb3B0aW9ucy5zZWVkKTtcbn1cbmZ1bmN0aW9uIGdldE1pbmltdW1CcmlnaHRuZXNzKEgsIFMpIHtcbiAgICBjb25zdCBsb3dlckJvdW5kcyA9IGdldENvbG9ySW5mbyhIKS5sb3dlckJvdW5kcztcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxvd2VyQm91bmRzLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgICBjb25zdCBzMSA9IGxvd2VyQm91bmRzW2ldWzBdO1xuICAgICAgICBjb25zdCB2MSA9IGxvd2VyQm91bmRzW2ldWzFdO1xuICAgICAgICBjb25zdCBzMiA9IGxvd2VyQm91bmRzW2kgKyAxXVswXTtcbiAgICAgICAgY29uc3QgdjIgPSBsb3dlckJvdW5kc1tpICsgMV1bMV07XG4gICAgICAgIGlmIChTID49IHMxICYmIFMgPD0gczIpIHtcbiAgICAgICAgICAgIGNvbnN0IG0gPSAodjIgLSB2MSkgLyAoczIgLSBzMSk7XG4gICAgICAgICAgICBjb25zdCBiID0gdjEgLSBtICogczE7XG4gICAgICAgICAgICByZXR1cm4gbSAqIFMgKyBiO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiAwO1xufVxuZnVuY3Rpb24gZ2V0SHVlUmFuZ2UoY29sb3JJbnB1dCkge1xuICAgIGNvbnN0IG51bSA9IHBhcnNlSW50KGNvbG9ySW5wdXQsIDEwKTtcbiAgICBpZiAoIU51bWJlci5pc05hTihudW0pICYmIG51bSA8IDM2MCAmJiBudW0gPiAwKSB7XG4gICAgICAgIHJldHVybiBbbnVtLCBudW1dO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIGNvbG9ySW5wdXQgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGNvbnN0IG5hbWVkQ29sb3IgPSBib3VuZHMuZmluZChuID0+IG4ubmFtZSA9PT0gY29sb3JJbnB1dCk7XG4gICAgICAgIGlmIChuYW1lZENvbG9yKSB7XG4gICAgICAgICAgICBjb25zdCBjb2xvciA9IGRlZmluZUNvbG9yKG5hbWVkQ29sb3IpO1xuICAgICAgICAgICAgaWYgKGNvbG9yLmh1ZVJhbmdlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbG9yLmh1ZVJhbmdlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHBhcnNlZCA9IG5ldyBUaW55Q29sb3IoY29sb3JJbnB1dCk7XG4gICAgICAgIGlmIChwYXJzZWQuaXNWYWxpZCkge1xuICAgICAgICAgICAgY29uc3QgaHVlID0gcGFyc2VkLnRvSHN2KCkuaDtcbiAgICAgICAgICAgIHJldHVybiBbaHVlLCBodWVdO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBbMCwgMzYwXTtcbn1cbmZ1bmN0aW9uIGdldENvbG9ySW5mbyhodWUpIHtcbiAgICAvLyBNYXBzIHJlZCBjb2xvcnMgdG8gbWFrZSBwaWNraW5nIGh1ZSBlYXNpZXJcbiAgICBpZiAoaHVlID49IDMzNCAmJiBodWUgPD0gMzYwKSB7XG4gICAgICAgIGh1ZSAtPSAzNjA7XG4gICAgfVxuICAgIGZvciAoY29uc3QgYm91bmQgb2YgYm91bmRzKSB7XG4gICAgICAgIGNvbnN0IGNvbG9yID0gZGVmaW5lQ29sb3IoYm91bmQpO1xuICAgICAgICBpZiAoY29sb3IuaHVlUmFuZ2UgJiYgaHVlID49IGNvbG9yLmh1ZVJhbmdlWzBdICYmIGh1ZSA8PSBjb2xvci5odWVSYW5nZVsxXSkge1xuICAgICAgICAgICAgcmV0dXJuIGNvbG9yO1xuICAgICAgICB9XG4gICAgfVxuICAgIHRocm93IEVycm9yKCdDb2xvciBub3QgZm91bmQnKTtcbn1cbmZ1bmN0aW9uIHJhbmRvbVdpdGhpbihyYW5nZSwgc2VlZCkge1xuICAgIGlmIChzZWVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuIE1hdGguZmxvb3IocmFuZ2VbMF0gKyBNYXRoLnJhbmRvbSgpICogKHJhbmdlWzFdICsgMSAtIHJhbmdlWzBdKSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICAvLyBTZWVkZWQgcmFuZG9tIGFsZ29yaXRobSBmcm9tIGh0dHA6Ly9pbmRpZWdhbXIuY29tL2dlbmVyYXRlLXJlcGVhdGFibGUtcmFuZG9tLW51bWJlcnMtaW4tanMvXG4gICAgICAgIGNvbnN0IG1heCA9IHJhbmdlWzFdIHx8IDE7XG4gICAgICAgIGNvbnN0IG1pbiA9IHJhbmdlWzBdIHx8IDA7XG4gICAgICAgIHNlZWQgPSAoc2VlZCAqIDkzMDEgKyA0OTI5NykgJSAyMzMyODA7XG4gICAgICAgIGNvbnN0IHJuZCA9IHNlZWQgLyAyMzMyODAuMDtcbiAgICAgICAgcmV0dXJuIE1hdGguZmxvb3IobWluICsgcm5kICogKG1heCAtIG1pbikpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGRlZmluZUNvbG9yKGJvdW5kKSB7XG4gICAgY29uc3Qgc01pbiA9IGJvdW5kLmxvd2VyQm91bmRzWzBdWzBdO1xuICAgIGNvbnN0IHNNYXggPSBib3VuZC5sb3dlckJvdW5kc1tib3VuZC5sb3dlckJvdW5kcy5sZW5ndGggLSAxXVswXTtcbiAgICBjb25zdCBiTWluID0gYm91bmQubG93ZXJCb3VuZHNbYm91bmQubG93ZXJCb3VuZHMubGVuZ3RoIC0gMV1bMV07XG4gICAgY29uc3QgYk1heCA9IGJvdW5kLmxvd2VyQm91bmRzWzBdWzFdO1xuICAgIHJldHVybiB7XG4gICAgICAgIG5hbWU6IGJvdW5kLm5hbWUsXG4gICAgICAgIGh1ZVJhbmdlOiBib3VuZC5odWVSYW5nZSxcbiAgICAgICAgbG93ZXJCb3VuZHM6IGJvdW5kLmxvd2VyQm91bmRzLFxuICAgICAgICBzYXR1cmF0aW9uUmFuZ2U6IFtzTWluLCBzTWF4XSxcbiAgICAgICAgYnJpZ2h0bmVzc1JhbmdlOiBbYk1pbiwgYk1heF0sXG4gICAgfTtcbn1cbi8qKlxuICogQGhpZGRlblxuICovXG5jb25zdCBib3VuZHMgPSBbXG4gICAge1xuICAgICAgICBuYW1lOiAnbW9ub2Nocm9tZScsXG4gICAgICAgIGh1ZVJhbmdlOiBudWxsLFxuICAgICAgICBsb3dlckJvdW5kczogW1swLCAwXSwgWzEwMCwgMF1dLFxuICAgIH0sXG4gICAge1xuICAgICAgICBuYW1lOiAncmVkJyxcbiAgICAgICAgaHVlUmFuZ2U6IFstMjYsIDE4XSxcbiAgICAgICAgbG93ZXJCb3VuZHM6IFtcbiAgICAgICAgICAgIFsyMCwgMTAwXSxcbiAgICAgICAgICAgIFszMCwgOTJdLFxuICAgICAgICAgICAgWzQwLCA4OV0sXG4gICAgICAgICAgICBbNTAsIDg1XSxcbiAgICAgICAgICAgIFs2MCwgNzhdLFxuICAgICAgICAgICAgWzcwLCA3MF0sXG4gICAgICAgICAgICBbODAsIDYwXSxcbiAgICAgICAgICAgIFs5MCwgNTVdLFxuICAgICAgICAgICAgWzEwMCwgNTBdLFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBuYW1lOiAnb3JhbmdlJyxcbiAgICAgICAgaHVlUmFuZ2U6IFsxOSwgNDZdLFxuICAgICAgICBsb3dlckJvdW5kczogW1syMCwgMTAwXSwgWzMwLCA5M10sIFs0MCwgODhdLCBbNTAsIDg2XSwgWzYwLCA4NV0sIFs3MCwgNzBdLCBbMTAwLCA3MF1dLFxuICAgIH0sXG4gICAge1xuICAgICAgICBuYW1lOiAneWVsbG93JyxcbiAgICAgICAgaHVlUmFuZ2U6IFs0NywgNjJdLFxuICAgICAgICBsb3dlckJvdW5kczogW1syNSwgMTAwXSwgWzQwLCA5NF0sIFs1MCwgODldLCBbNjAsIDg2XSwgWzcwLCA4NF0sIFs4MCwgODJdLCBbOTAsIDgwXSwgWzEwMCwgNzVdXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgbmFtZTogJ2dyZWVuJyxcbiAgICAgICAgaHVlUmFuZ2U6IFs2MywgMTc4XSxcbiAgICAgICAgbG93ZXJCb3VuZHM6IFtbMzAsIDEwMF0sIFs0MCwgOTBdLCBbNTAsIDg1XSwgWzYwLCA4MV0sIFs3MCwgNzRdLCBbODAsIDY0XSwgWzkwLCA1MF0sIFsxMDAsIDQwXV0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6ICdibHVlJyxcbiAgICAgICAgaHVlUmFuZ2U6IFsxNzksIDI1N10sXG4gICAgICAgIGxvd2VyQm91bmRzOiBbXG4gICAgICAgICAgICBbMjAsIDEwMF0sXG4gICAgICAgICAgICBbMzAsIDg2XSxcbiAgICAgICAgICAgIFs0MCwgODBdLFxuICAgICAgICAgICAgWzUwLCA3NF0sXG4gICAgICAgICAgICBbNjAsIDYwXSxcbiAgICAgICAgICAgIFs3MCwgNTJdLFxuICAgICAgICAgICAgWzgwLCA0NF0sXG4gICAgICAgICAgICBbOTAsIDM5XSxcbiAgICAgICAgICAgIFsxMDAsIDM1XSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgbmFtZTogJ3B1cnBsZScsXG4gICAgICAgIGh1ZVJhbmdlOiBbMjU4LCAyODJdLFxuICAgICAgICBsb3dlckJvdW5kczogW1xuICAgICAgICAgICAgWzIwLCAxMDBdLFxuICAgICAgICAgICAgWzMwLCA4N10sXG4gICAgICAgICAgICBbNDAsIDc5XSxcbiAgICAgICAgICAgIFs1MCwgNzBdLFxuICAgICAgICAgICAgWzYwLCA2NV0sXG4gICAgICAgICAgICBbNzAsIDU5XSxcbiAgICAgICAgICAgIFs4MCwgNTJdLFxuICAgICAgICAgICAgWzkwLCA0NV0sXG4gICAgICAgICAgICBbMTAwLCA0Ml0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIG5hbWU6ICdwaW5rJyxcbiAgICAgICAgaHVlUmFuZ2U6IFsyODMsIDMzNF0sXG4gICAgICAgIGxvd2VyQm91bmRzOiBbWzIwLCAxMDBdLCBbMzAsIDkwXSwgWzQwLCA4Nl0sIFs2MCwgODRdLCBbODAsIDgwXSwgWzkwLCA3NV0sIFsxMDAsIDczXV0sXG4gICAgfSxcbl07XG5cbmV4cG9ydCB7IFRpbnlDb2xvciwgbmFtZXMsIHJlYWRhYmlsaXR5LCBpc1JlYWRhYmxlLCBtb3N0UmVhZGFibGUsIHRvTXNGaWx0ZXIsIGZyb21SYXRpbywgbGVnYWN5UmFuZG9tLCBpbnB1dFRvUkdCLCBzdHJpbmdJbnB1dFRvT2JqZWN0LCBpc1ZhbGlkQ1NTVW5pdCwgcmFuZG9tLCBib3VuZHMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXRpbnljb2xvci5lczIwMTUuanMubWFwXG4iLCJpbXBvcnQgJCBmcm9tICdibGluZ2JsaW5nanMnXG5pbXBvcnQgeyBUaW55Q29sb3IgfSBmcm9tICdAY3RybC90aW55Y29sb3InXG5pbXBvcnQgeyBnZXRTdHlsZSB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmV4cG9ydCBmdW5jdGlvbiBDb2xvclBpY2tlcihwYWxsZXRlLCBzZWxlY3RvckVuZ2luZSkge1xuICBjb25zdCBmb3JlZ3JvdW5kUGlja2VyICA9ICQoJyNmb3JlZ3JvdW5kJywgcGFsbGV0ZSlcbiAgY29uc3QgYmFja2dyb3VuZFBpY2tlciAgPSAkKCcjYmFja2dyb3VuZCcsIHBhbGxldGUpXG4gIGNvbnN0IGJvcmRlclBpY2tlciAgICAgID0gJCgnI2JvcmRlcicsIHBhbGxldGUpXG4gIGNvbnN0IGZnSW5wdXQgICAgICAgICAgID0gJCgnaW5wdXQnLCBmb3JlZ3JvdW5kUGlja2VyWzBdKVxuICBjb25zdCBiZ0lucHV0ICAgICAgICAgICA9ICQoJ2lucHV0JywgYmFja2dyb3VuZFBpY2tlclswXSlcbiAgY29uc3QgYm9JbnB1dCAgICAgICAgICAgPSAkKCdpbnB1dCcsIGJvcmRlclBpY2tlclswXSlcblxuICB0aGlzLmFjdGl2ZV9jb2xvciAgICAgICA9ICdiYWNrZ3JvdW5kJ1xuXG4gIC8vIHNldCBjb2xvcnNcbiAgZmdJbnB1dC5vbignaW5wdXQnLCBlID0+XG4gICAgJCgnW2RhdGEtc2VsZWN0ZWQ9dHJ1ZV0nKS5tYXAoZWwgPT5cbiAgICAgIGVsLnN0eWxlWydjb2xvciddID0gZS50YXJnZXQudmFsdWUpKVxuXG4gIGJnSW5wdXQub24oJ2lucHV0JywgZSA9PlxuICAgICQoJ1tkYXRhLXNlbGVjdGVkPXRydWVdJykubWFwKGVsID0+XG4gICAgICBlbC5zdHlsZVtlbCBpbnN0YW5jZW9mIFNWR0VsZW1lbnRcbiAgICAgICAgPyAnZmlsbCdcbiAgICAgICAgOiAnYmFja2dyb3VuZENvbG9yJ1xuICAgICAgXSA9IGUudGFyZ2V0LnZhbHVlKSlcblxuICBib0lucHV0Lm9uKCdpbnB1dCcsIGUgPT5cbiAgICAkKCdbZGF0YS1zZWxlY3RlZD10cnVlXScpLm1hcChlbCA9PlxuICAgICAgZWwuc3R5bGVbZWwgaW5zdGFuY2VvZiBTVkdFbGVtZW50XG4gICAgICAgID8gJ3N0cm9rZSdcbiAgICAgICAgOiAnYm9yZGVyLWNvbG9yJ1xuICAgICAgXSA9IGUudGFyZ2V0LnZhbHVlKSlcblxuICAvLyByZWFkIGNvbG9yc1xuICBzZWxlY3RvckVuZ2luZS5vblNlbGVjdGVkVXBkYXRlKGVsZW1lbnRzID0+IHtcbiAgICBpZiAoIWVsZW1lbnRzLmxlbmd0aCkgcmV0dXJuXG5cbiAgICBsZXQgaXNNZWFuaW5nZnVsRm9yZWdyb3VuZCAgPSBmYWxzZVxuICAgIGxldCBpc01lYW5pbmdmdWxCYWNrZ3JvdW5kICA9IGZhbHNlXG4gICAgbGV0IGlzTWVhbmluZ2Z1bEJvcmRlciAgICAgID0gZmFsc2VcbiAgICBsZXQgRkcsIEJHLCBCT1xuXG4gICAgaWYgKGVsZW1lbnRzLmxlbmd0aCA9PSAxKSB7XG4gICAgICBjb25zdCBlbCA9IGVsZW1lbnRzWzBdXG5cbiAgICAgIGlmIChlbCBpbnN0YW5jZW9mIFNWR0VsZW1lbnQpIHtcbiAgICAgICAgRkcgPSBuZXcgVGlueUNvbG9yKCdyZ2IoMCwgMCwgMCknKVxuICAgICAgICB2YXIgYm9fdGVtcCA9IGdldFN0eWxlKGVsLCAnc3Ryb2tlJylcbiAgICAgICAgQk8gPSBuZXcgVGlueUNvbG9yKGJvX3RlbXAgPT09ICdub25lJ1xuICAgICAgICAgID8gJ3JnYigwLCAwLCAwKSdcbiAgICAgICAgICA6IGJvX3RlbXApXG4gICAgICAgIEJHID0gbmV3IFRpbnlDb2xvcihnZXRTdHlsZShlbCwgJ2ZpbGwnKSlcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICBGRyA9IG5ldyBUaW55Q29sb3IoZ2V0U3R5bGUoZWwsICdjb2xvcicpKVxuICAgICAgICBCRyA9IG5ldyBUaW55Q29sb3IoZ2V0U3R5bGUoZWwsICdiYWNrZ3JvdW5kQ29sb3InKSlcbiAgICAgICAgQk8gPSBnZXRTdHlsZShlbCwgJ2JvcmRlcldpZHRoJykgPT09ICcwcHgnXG4gICAgICAgICAgPyBuZXcgVGlueUNvbG9yKCdyZ2IoMCwgMCwgMCknKVxuICAgICAgICAgIDogbmV3IFRpbnlDb2xvcihnZXRTdHlsZShlbCwgJ2JvcmRlckNvbG9yJykpXG4gICAgICB9XG5cbiAgICAgIGxldCBmZyA9IEZHLnRvSGV4U3RyaW5nKClcbiAgICAgIGxldCBiZyA9IEJHLnRvSGV4U3RyaW5nKClcbiAgICAgIGxldCBibyA9IEJPLnRvSGV4U3RyaW5nKClcblxuICAgICAgaXNNZWFuaW5nZnVsRm9yZWdyb3VuZCA9IEZHLm9yaWdpbmFsSW5wdXQgIT09ICdyZ2IoMCwgMCwgMCknIHx8IChlbC5jaGlsZHJlbi5sZW5ndGggPT09IDAgJiYgZWwudGV4dENvbnRlbnQgIT09ICcnKVxuICAgICAgaXNNZWFuaW5nZnVsQmFja2dyb3VuZCA9IEJHLm9yaWdpbmFsSW5wdXQgIT09ICdyZ2JhKDAsIDAsIDAsIDApJyBcbiAgICAgIGlzTWVhbmluZ2Z1bEJvcmRlciAgICAgPSBCTy5vcmlnaW5hbElucHV0ICE9PSAncmdiKDAsIDAsIDApJyBcblxuICAgICAgaWYgKGlzTWVhbmluZ2Z1bEZvcmVncm91bmQgJiYgIWlzTWVhbmluZ2Z1bEJhY2tncm91bmQpXG4gICAgICAgIHNldEFjdGl2ZSgnZm9yZWdyb3VuZCcpXG4gICAgICBlbHNlIGlmIChpc01lYW5pbmdmdWxCYWNrZ3JvdW5kICYmICFpc01lYW5pbmdmdWxGb3JlZ3JvdW5kKVxuICAgICAgICBzZXRBY3RpdmUoJ2JhY2tncm91bmQnKVxuXG4gICAgICBjb25zdCBuZXdfZmcgPSBpc01lYW5pbmdmdWxGb3JlZ3JvdW5kID8gZmcgOiAnJ1xuICAgICAgY29uc3QgbmV3X2JnID0gaXNNZWFuaW5nZnVsQmFja2dyb3VuZCA/IGJnIDogJydcbiAgICAgIGNvbnN0IG5ld19ibyA9IGlzTWVhbmluZ2Z1bEJvcmRlciA/IGJvIDogJydcblxuICAgICAgZmdJbnB1dC5hdHRyKCd2YWx1ZScsIG5ld19mZylcbiAgICAgIGJnSW5wdXQuYXR0cigndmFsdWUnLCBuZXdfYmcpXG4gICAgICBib0lucHV0LmF0dHIoJ3ZhbHVlJywgbmV3X2JvKVxuICAgICAgXG4gICAgICBmb3JlZ3JvdW5kUGlja2VyLmF0dHIoJ3N0eWxlJywgYFxuICAgICAgICAtLWNvbnRleHR1YWxfY29sb3I6ICR7bmV3X2ZnfTtcbiAgICAgICAgZGlzcGxheTogJHtpc01lYW5pbmdmdWxGb3JlZ3JvdW5kID8gJ2lubGluZS1mbGV4JyA6ICdub25lJ307XG4gICAgICBgKVxuXG4gICAgICBiYWNrZ3JvdW5kUGlja2VyLmF0dHIoJ3N0eWxlJywgYFxuICAgICAgICAtLWNvbnRleHR1YWxfY29sb3I6ICR7bmV3X2JnfTtcbiAgICAgICAgZGlzcGxheTogJHtpc01lYW5pbmdmdWxCYWNrZ3JvdW5kID8gJ2lubGluZS1mbGV4JyA6ICdub25lJ307XG4gICAgICBgKVxuXG4gICAgICBib3JkZXJQaWNrZXIuYXR0cignc3R5bGUnLCBgXG4gICAgICAgIC0tY29udGV4dHVhbF9jb2xvcjogJHtuZXdfYm99O1xuICAgICAgICBkaXNwbGF5OiAke2lzTWVhbmluZ2Z1bEJvcmRlciA/ICdpbmxpbmUtZmxleCcgOiAnbm9uZSd9O1xuICAgICAgYClcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAvLyBzaG93IGFsbCAzIGlmIHRoZXkndmUgc2VsZWN0ZWQgbW9yZSB0aGFuIDEgbm9kZVxuICAgICAgZm9yZWdyb3VuZFBpY2tlci5hdHRyKCdzdHlsZScsIGBcbiAgICAgICAgLS1hY3RpdmVfY29sb3I6ICR7dGhpcy5hY3RpdmVfY29sb3IgPT0gJ2ZvcmVncm91bmQnID8gJ2hvdHBpbmsnOiAnJ307XG4gICAgICAgIGRpc3BsYXk6ICdpbmxpbmUtZmxleCd9O1xuICAgICAgYClcblxuICAgICAgYmFja2dyb3VuZFBpY2tlci5hdHRyKCdzdHlsZScsIGBcbiAgICAgICAgLS1hY3RpdmVfY29sb3I6ICR7dGhpcy5hY3RpdmVfY29sb3IgPT0gJ2JhY2tncm91bmQnID8gJ2hvdHBpbmsnOiAnJ307XG4gICAgICAgIGRpc3BsYXk6ICdpbmxpbmUtZmxleCd9O1xuICAgICAgYClcblxuICAgICAgYm9yZGVyUGlja2VyLmF0dHIoJ3N0eWxlJywgYFxuICAgICAgICAtLWFjdGl2ZV9jb2xvcjogJHt0aGlzLmFjdGl2ZV9jb2xvciA9PSAnYm9yZGVyJyA/ICdob3RwaW5rJzogJyd9O1xuICAgICAgICBkaXNwbGF5OiAnaW5saW5lLWZsZXgnfTtcbiAgICAgIGApXG4gICAgfVxuICB9KVxuXG4gIGNvbnN0IGdldEFjdGl2ZSA9ICgpID0+XG4gICAgdGhpcy5hY3RpdmVfY29sb3JcblxuICBjb25zdCBzZXRBY3RpdmUgPSBrZXkgPT4ge1xuICAgIHJlbW92ZUFjdGl2ZSgpXG4gICAgdGhpcy5hY3RpdmVfY29sb3IgPSBrZXlcbiAgICBpZiAoa2V5ID09PSAnZm9yZWdyb3VuZCcpXG4gICAgICBmb3JlZ3JvdW5kUGlja2VyWzBdLnN0eWxlLnNldFByb3BlcnR5KCctLWFjdGl2ZV9jb2xvcicsICdob3RwaW5rJylcbiAgICBpZiAoa2V5ID09PSAnYmFja2dyb3VuZCcpXG4gICAgICBiYWNrZ3JvdW5kUGlja2VyWzBdLnN0eWxlLnNldFByb3BlcnR5KCctLWFjdGl2ZV9jb2xvcicsICdob3RwaW5rJylcbiAgICBpZiAoa2V5ID09PSAnYm9yZGVyJylcbiAgICAgIGJvcmRlclBpY2tlclswXS5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1hY3RpdmVfY29sb3InLCAnaG90cGluaycpXG4gIH1cblxuICBjb25zdCByZW1vdmVBY3RpdmUgPSAoKSA9PlxuICAgIFtmb3JlZ3JvdW5kUGlja2VyLCBiYWNrZ3JvdW5kUGlja2VyLCBib3JkZXJQaWNrZXJdLmZvckVhY2gocGlja2VyID0+XG4gICAgICBwaWNrZXJbMF0uc3R5bGUucmVtb3ZlUHJvcGVydHkoJy0tYWN0aXZlX2NvbG9yJykpXG5cbiAgcmV0dXJuIHtcbiAgICBnZXRBY3RpdmUsXG4gICAgc2V0QWN0aXZlLFxuICAgIGZvcmVncm91bmQ6IHsgY29sb3I6IGNvbG9yID0+IFxuICAgICAgZm9yZWdyb3VuZFBpY2tlclswXS5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1jb250ZXh0dWFsX2NvbG9yJywgY29sb3IpfSxcbiAgICBiYWNrZ3JvdW5kOiB7IGNvbG9yOiBjb2xvciA9PiBcbiAgICAgIGJhY2tncm91bmRQaWNrZXJbMF0uc3R5bGUuc2V0UHJvcGVydHkoJy0tY29udGV4dHVhbF9jb2xvcicsIGNvbG9yKX1cbiAgfVxufSIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgeyBUaW55Q29sb3IgfSBmcm9tICdAY3RybC90aW55Y29sb3InXG5pbXBvcnQgeyBxdWVyeVBhZ2UgfSBmcm9tICcuL3NlYXJjaCdcbmltcG9ydCB7IGdldFN0eWxlcywgY2FtZWxUb0Rhc2gsIGlzT2ZmQm91bmRzIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuY29uc3QgdGlwX21hcCA9IG5ldyBNYXAoKVxuXG4vLyB0b2RvOiBcbi8vIC0gbm9kZSByZWN5Y2xpbmcgKGZvciBuZXcgdGFyZ2V0KSBubyBuZWVkIHRvIGNyZWF0ZS9kZWxldGVcbi8vIC0gbWFrZSBzaW5nbGUgZnVuY3Rpb24gY3JlYXRlL3VwZGF0ZVxuZXhwb3J0IGZ1bmN0aW9uIE1ldGFUaXAoc2VsZWN0b3JFbmdpbmUpIHtcbiAgY29uc3QgdGVtcGxhdGUgPSAoe3RhcmdldDogZWx9KSA9PiB7XG4gICAgY29uc3QgeyB3aWR0aCwgaGVpZ2h0IH0gPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKVxuICAgIGNvbnN0IHN0eWxlcyA9IGdldFN0eWxlcyhlbClcbiAgICAgIC5tYXAoc3R5bGUgPT4gT2JqZWN0LmFzc2lnbihzdHlsZSwge1xuICAgICAgICBwcm9wOiBjYW1lbFRvRGFzaChzdHlsZS5wcm9wKVxuICAgICAgfSkpXG4gICAgICAuZmlsdGVyKHN0eWxlID0+IFxuICAgICAgICBzdHlsZS5wcm9wLmluY2x1ZGVzKCdmb250LWZhbWlseScpIFxuICAgICAgICAgID8gZWwubWF0Y2hlcygnaDEsaDIsaDMsaDQsaDUsaDYscCxhLGRhdGUsY2FwdGlvbixidXR0b24sZmlnY2FwdGlvbixuYXYsaGVhZGVyLGZvb3RlcicpIFxuICAgICAgICAgIDogdHJ1ZVxuICAgICAgKVxuICAgICAgLm1hcChzdHlsZSA9PiB7XG4gICAgICAgIGlmIChzdHlsZS5wcm9wLmluY2x1ZGVzKCdjb2xvcicpIHx8IHN0eWxlLnByb3AuaW5jbHVkZXMoJ0NvbG9yJykgfHwgc3R5bGUucHJvcC5pbmNsdWRlcygnZmlsbCcpIHx8IHN0eWxlLnByb3AuaW5jbHVkZXMoJ3N0cm9rZScpKVxuICAgICAgICAgIHN0eWxlLnZhbHVlID0gYDxzcGFuIGNvbG9yIHN0eWxlPVwiYmFja2dyb3VuZC1jb2xvcjoke3N0eWxlLnZhbHVlfTtcIj48L3NwYW4+JHtuZXcgVGlueUNvbG9yKHN0eWxlLnZhbHVlKS50b0hzbFN0cmluZygpfWBcblxuICAgICAgICBpZiAoc3R5bGUucHJvcC5pbmNsdWRlcygnZm9udC1mYW1pbHknKSAmJiBzdHlsZS52YWx1ZS5sZW5ndGggPiAyNSlcbiAgICAgICAgICBzdHlsZS52YWx1ZSA9IHN0eWxlLnZhbHVlLnNsaWNlKDAsMjUpICsgJy4uLidcblxuICAgICAgICBpZiAoc3R5bGUucHJvcC5pbmNsdWRlcygnYmFja2dyb3VuZC1pbWFnZScpKVxuICAgICAgICAgIHN0eWxlLnZhbHVlID0gYDxhIHRhcmdldD1cIl9ibGFua1wiIGhyZWY9XCIke3N0eWxlLnZhbHVlLnNsaWNlKHN0eWxlLnZhbHVlLmluZGV4T2YoJygnKSArIDIsIHN0eWxlLnZhbHVlLmxlbmd0aCAtIDIpfVwiPiR7c3R5bGUudmFsdWUuc2xpY2UoMCwyNSkgKyAnLi4uJ308L2E+YFxuXG4gICAgICAgIC8vIGNoZWNrIGlmIHN0eWxlIGlzIGlubGluZSBzdHlsZSwgc2hvdyBpbmRpY2F0b3JcbiAgICAgICAgaWYgKGVsLmdldEF0dHJpYnV0ZSgnc3R5bGUnKSAmJiBlbC5nZXRBdHRyaWJ1dGUoJ3N0eWxlJykuaW5jbHVkZXMoc3R5bGUucHJvcCkpXG4gICAgICAgICAgc3R5bGUudmFsdWUgPSBgPHNwYW4gbG9jYWwtY2hhbmdlPiR7c3R5bGUudmFsdWV9PC9zcGFuPmBcbiAgICAgICAgXG4gICAgICAgIHJldHVybiBzdHlsZVxuICAgICAgfSlcblxuICAgIGNvbnN0IGxvY2FsTW9kaWZpY2F0aW9ucyA9IHN0eWxlcy5maWx0ZXIoc3R5bGUgPT5cbiAgICAgIGVsLmdldEF0dHJpYnV0ZSgnc3R5bGUnKSAmJiBlbC5nZXRBdHRyaWJ1dGUoJ3N0eWxlJykuaW5jbHVkZXMoc3R5bGUucHJvcClcbiAgICAgICAgPyAxXG4gICAgICAgIDogMClcblxuICAgIGNvbnN0IG5vdExvY2FsTW9kaWZpY2F0aW9ucyA9IHN0eWxlcy5maWx0ZXIoc3R5bGUgPT5cbiAgICAgIGVsLmdldEF0dHJpYnV0ZSgnc3R5bGUnKSAmJiBlbC5nZXRBdHRyaWJ1dGUoJ3N0eWxlJykuaW5jbHVkZXMoc3R5bGUucHJvcClcbiAgICAgICAgPyAwXG4gICAgICAgIDogMSlcbiAgICBcbiAgICBsZXQgdGlwID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgncGItbWV0YXRpcCcpXG5cbiAgICB0aXAubWV0YSA9IHtcbiAgICAgIGVsLCBcbiAgICAgIHdpZHRoLCBcbiAgICAgIGhlaWdodCwgXG4gICAgICBsb2NhbE1vZGlmaWNhdGlvbnMsIFxuICAgICAgbm90TG9jYWxNb2RpZmljYXRpb25zLFxuICAgIH1cblxuICAgIHJldHVybiB0aXBcbiAgfVxuXG4gIGNvbnN0IG1vdXNlX3F1YWRyYW50ID0gZSA9PiAoe1xuICAgIG5vcnRoOiBlLmNsaWVudFkgPiB3aW5kb3cuaW5uZXJIZWlnaHQgLyAyLFxuICAgIHdlc3Q6ICBlLmNsaWVudFggPiB3aW5kb3cuaW5uZXJXaWR0aCAvIDJcbiAgfSlcblxuICBjb25zdCB0aXBfcG9zaXRpb24gPSAobm9kZSwgZSwgbm9ydGgsIHdlc3QpID0+ICh7XG4gICAgdG9wOiBgJHtub3J0aFxuICAgICAgPyBlLnBhZ2VZIC0gbm9kZS5jbGllbnRIZWlnaHQgLSAyMFxuICAgICAgOiBlLnBhZ2VZICsgMjV9cHhgLFxuICAgIGxlZnQ6IGAke3dlc3RcbiAgICAgID8gZS5wYWdlWCAtIG5vZGUuY2xpZW50V2lkdGggKyAyM1xuICAgICAgOiBlLnBhZ2VYIC0gMjF9cHhgLFxuICB9KVxuXG4gIGNvbnN0IHVwZGF0ZV90aXAgPSAodGlwLCBlKSA9PiB7XG4gICAgY29uc3QgeyBub3J0aCwgd2VzdCB9ID0gbW91c2VfcXVhZHJhbnQoZSlcbiAgICBjb25zdCB7bGVmdCwgdG9wfSAgICAgPSB0aXBfcG9zaXRpb24odGlwLCBlLCBub3J0aCwgd2VzdClcblxuICAgIHRpcC5zdHlsZS5sZWZ0ICA9IGxlZnRcbiAgICB0aXAuc3R5bGUudG9wICAgPSB0b3AgXG5cbiAgICB0aXAuc3R5bGUuc2V0UHJvcGVydHkoJy0tYXJyb3cnLCBub3J0aCBcbiAgICAgID8gJ3ZhcigtLWFycm93LXVwKSdcbiAgICAgIDogJ3ZhcigtLWFycm93LWRvd24pJylcblxuICAgIHRpcC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1zaGFkb3ctZGlyZWN0aW9uJywgbm9ydGggXG4gICAgICA/ICd2YXIoLS1zaGFkb3ctdXApJ1xuICAgICAgOiAndmFyKC0tc2hhZG93LWRvd24pJylcblxuICAgIHRpcC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1hcnJvdy10b3AnLCAhbm9ydGggXG4gICAgICA/ICctN3B4J1xuICAgICAgOiAnY2FsYygxMDAlIC0gMXB4KScpXG5cbiAgICB0aXAuc3R5bGUuc2V0UHJvcGVydHkoJy0tYXJyb3ctbGVmdCcsIHdlc3QgXG4gICAgICA/ICdjYWxjKDEwMCUgLSAxNXB4IC0gMTVweCknXG4gICAgICA6ICcxNXB4JylcbiAgfVxuXG4gIGNvbnN0IG1vdXNlT3V0ID0gKHt0YXJnZXR9KSA9PiB7XG4gICAgaWYgKHRpcF9tYXAuaGFzKHRhcmdldCkgJiYgIXRhcmdldC5oYXNBdHRyaWJ1dGUoJ2RhdGEtbWV0YXRpcCcpKSB7XG4gICAgICB0YXJnZXQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2VvdXQnLCBtb3VzZU91dClcbiAgICAgIHRhcmdldC5yZW1vdmVFdmVudExpc3RlbmVyKCdET01Ob2RlUmVtb3ZlZCcsIG1vdXNlT3V0KVxuICAgICAgdGFyZ2V0LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdG9nZ2xlUGlubmVkKVxuICAgICAgdGlwX21hcC5nZXQodGFyZ2V0KS50aXAucmVtb3ZlKClcbiAgICAgIHRpcF9tYXAuZGVsZXRlKHRhcmdldClcbiAgICB9XG4gIH1cblxuICBjb25zdCB0b2dnbGVQaW5uZWQgPSBlID0+IHtcbiAgICBpZiAoZS5hbHRLZXkpIHtcbiAgICAgICFlLnRhcmdldC5oYXNBdHRyaWJ1dGUoJ2RhdGEtbWV0YXRpcCcpXG4gICAgICAgID8gZS50YXJnZXQuc2V0QXR0cmlidXRlKCdkYXRhLW1ldGF0aXAnLCB0cnVlKVxuICAgICAgICA6IGUudGFyZ2V0LnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1tZXRhdGlwJylcbiAgICB9XG4gIH1cblxuICBjb25zdCBsaW5rUXVlcnlDbGlja2VkID0gKHtkZXRhaWx9KSA9PiB7XG4gICAgaWYgKCFkZXRhaWwudGV4dCkgcmV0dXJuXG5cbiAgICBxdWVyeVBhZ2UoJ1tkYXRhLWhvdmVyXScsIGVsID0+XG4gICAgICBlbC5zZXRBdHRyaWJ1dGUoJ2RhdGEtaG92ZXInLCBudWxsKSlcblxuICAgIHF1ZXJ5UGFnZShkZXRhaWwudGV4dCArICc6bm90KFtkYXRhLXNlbGVjdGVkXSknLCBlbCA9PlxuICAgICAgZGV0YWlsLmFjdGl2YXRvciA9PT0gJ21vdXNlZW50ZXInXG4gICAgICAgID8gZWwuc2V0QXR0cmlidXRlKCdkYXRhLWhvdmVyJywgdHJ1ZSlcbiAgICAgICAgOiBzZWxlY3RvckVuZ2luZS5zZWxlY3QoZWwpKVxuICB9XG5cbiAgY29uc3QgbGlua1F1ZXJ5SG92ZXJPdXQgPSBlID0+IHtcbiAgICBxdWVyeVBhZ2UoJ1tkYXRhLWhvdmVyXScsIGVsID0+XG4gICAgICBlbC5zZXRBdHRyaWJ1dGUoJ2RhdGEtaG92ZXInLCBudWxsKSlcbiAgfVxuXG4gIGNvbnN0IG1vdXNlTW92ZSA9IGUgPT4ge1xuICAgIGlmIChpc09mZkJvdW5kcyhlLnRhcmdldCkpIHJldHVyblxuXG4gICAgZS5hbHRLZXlcbiAgICAgID8gZS50YXJnZXQuc2V0QXR0cmlidXRlKCdkYXRhLXBpbmhvdmVyJywgdHJ1ZSlcbiAgICAgIDogZS50YXJnZXQucmVtb3ZlQXR0cmlidXRlKCdkYXRhLXBpbmhvdmVyJylcblxuICAgIC8vIGlmIG5vZGUgaXMgaW4gb3VyIGhhc2ggKGFscmVhZHkgY3JlYXRlZClcbiAgICBpZiAodGlwX21hcC5oYXMoZS50YXJnZXQpKSB7XG4gICAgICAvLyByZXR1cm4gaWYgaXQncyBwaW5uZWRcbiAgICAgIGlmIChlLnRhcmdldC5oYXNBdHRyaWJ1dGUoJ2RhdGEtbWV0YXRpcCcpKSBcbiAgICAgICAgcmV0dXJuXG4gICAgICAvLyBvdGhlcndpc2UgdXBkYXRlIHBvc2l0aW9uXG4gICAgICBjb25zdCB7IHRpcCB9ID0gdGlwX21hcC5nZXQoZS50YXJnZXQpXG5cbiAgICAgIHVwZGF0ZV90aXAodGlwLCBlKVxuICAgIH1cbiAgICAvLyBjcmVhdGUgbmV3IHRpcFxuICAgIGVsc2Uge1xuICAgICAgY29uc3QgdGlwID0gdGVtcGxhdGUoZSlcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQodGlwKVxuXG4gICAgICB1cGRhdGVfdGlwKHRpcCwgZSlcblxuICAgICAgJCh0aXApLm9uKCdxdWVyeScsIGxpbmtRdWVyeUNsaWNrZWQpXG4gICAgICAkKHRpcCkub24oJ3VucXVlcnknLCBsaW5rUXVlcnlIb3Zlck91dClcbiAgICAgICQoZS50YXJnZXQpLm9uKCdtb3VzZW91dCBET01Ob2RlUmVtb3ZlZCcsIG1vdXNlT3V0KVxuICAgICAgJChlLnRhcmdldCkub24oJ2NsaWNrJywgdG9nZ2xlUGlubmVkKVxuXG4gICAgICB0aXBfbWFwLnNldChlLnRhcmdldCwgeyB0aXAsIGUgfSlcblxuICAgICAgLy8gdGlwLmFuaW1hdGUoW1xuICAgICAgLy8gICB7dHJhbnNmb3JtOiAndHJhbnNsYXRlWSgtNXB4KScsIG9wYWNpdHk6IDB9LFxuICAgICAgLy8gICB7dHJhbnNmb3JtOiAndHJhbnNsYXRlWSgwKScsIG9wYWNpdHk6IDF9XG4gICAgICAvLyBdLCAxNTApXG4gICAgfVxuICB9XG5cbiAgJCgnYm9keScpLm9uKCdtb3VzZW1vdmUnLCBtb3VzZU1vdmUpXG5cbiAgaG90a2V5cygnZXNjJywgXyA9PiByZW1vdmVBbGwoKSlcblxuICBjb25zdCBoaWRlQWxsID0gKCkgPT4ge1xuICAgIGZvciAoY29uc3Qge3RpcH0gb2YgdGlwX21hcC52YWx1ZXMoKSkge1xuICAgICAgdGlwLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSdcbiAgICAgICQodGlwKS5vZmYoJ21vdXNlb3V0IERPTU5vZGVSZW1vdmVkJywgbW91c2VPdXQpXG4gICAgICAkKHRpcCkub2ZmKCdjbGljaycsIHRvZ2dsZVBpbm5lZClcbiAgICAgICQoJ2EnLCB0aXApLm9mZignY2xpY2snLCBsaW5rUXVlcnlDbGlja2VkKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHJlbW92ZUFsbCA9ICgpID0+IHtcbiAgICBmb3IgKGNvbnN0IHt0aXB9IG9mIHRpcF9tYXAudmFsdWVzKCkpIHtcbiAgICAgIHRpcC5yZW1vdmUoKVxuICAgICAgJCh0aXApLm9mZignbW91c2VvdXQgRE9NTm9kZVJlbW92ZWQnLCBtb3VzZU91dClcbiAgICAgICQodGlwKS5vZmYoJ2NsaWNrJywgdG9nZ2xlUGlubmVkKVxuICAgICAgJCgnYScsIHRpcCkub2ZmKCdjbGljaycsIGxpbmtRdWVyeUNsaWNrZWQpXG4gICAgfVxuICAgIFxuICAgICQoJ1tkYXRhLW1ldGF0aXBdJykuYXR0cignZGF0YS1tZXRhdGlwJywgbnVsbClcblxuICAgIHRpcF9tYXAuY2xlYXIoKVxuICB9XG5cbiAgZm9yIChjb25zdCB7dGlwLGV9IG9mIHRpcF9tYXAudmFsdWVzKCkpIHtcbiAgICB0aXAuc3R5bGUuZGlzcGxheSA9ICdibG9jaydcbiAgICB0aXAuaW5uZXJIVE1MID0gdGVtcGxhdGUoZSkuaW5uZXJIVE1MXG4gICAgdGlwLm9uKCdtb3VzZW91dCcsIG1vdXNlT3V0KVxuICAgIHRpcC5vbignY2xpY2snLCB0b2dnbGVQaW5uZWQpXG4gIH1cblxuICByZXR1cm4gKCkgPT4ge1xuICAgICQoJ2JvZHknKS5vZmYoJ21vdXNlbW92ZScsIG1vdXNlTW92ZSlcbiAgICBob3RrZXlzLnVuYmluZCgnZXNjJylcbiAgICBoaWRlQWxsKClcbiAgfVxufSIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgeyBtZXRhS2V5LCBnZXRTdHlsZSwgc2hvd0hpZGVTZWxlY3RlZCB9IGZyb20gJy4uL3V0aWxpdGllcy8nXG5cbmNvbnN0IGtleV9ldmVudHMgPSAndXAsZG93bixsZWZ0LHJpZ2h0J1xuICAuc3BsaXQoJywnKVxuICAucmVkdWNlKChldmVudHMsIGV2ZW50KSA9PlxuICAgIGAke2V2ZW50c30sJHtldmVudH0sc2hpZnQrJHtldmVudH1gXG4gICwgJycpXG4gIC5zdWJzdHJpbmcoMSlcblxuY29uc3QgY29tbWFuZF9ldmVudHMgPSBgJHttZXRhS2V5fSt1cCwke21ldGFLZXl9K3NoaWZ0K3VwLCR7bWV0YUtleX0rZG93biwke21ldGFLZXl9K3NoaWZ0K2Rvd24sJHttZXRhS2V5fStsZWZ0LCR7bWV0YUtleX0rc2hpZnQrbGVmdCwke21ldGFLZXl9K3JpZ2h0LCR7bWV0YUtleX0rc2hpZnQrcmlnaHRgXG5cbmV4cG9ydCBmdW5jdGlvbiBCb3hTaGFkb3coc2VsZWN0b3IpIHtcbiAgaG90a2V5cyhrZXlfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGlmIChlLmNhbmNlbEJ1YmJsZSkgcmV0dXJuXG5cbiAgICBlLnByZXZlbnREZWZhdWx0KClcblxuICAgIGxldCBzZWxlY3RlZE5vZGVzID0gJChzZWxlY3RvcilcbiAgICAgICwga2V5cyA9IGhhbmRsZXIua2V5LnNwbGl0KCcrJylcblxuICAgIGlmIChrZXlzLmluY2x1ZGVzKCdsZWZ0JykgfHwga2V5cy5pbmNsdWRlcygncmlnaHQnKSlcbiAgICAgIGtleXMuaW5jbHVkZXMoJ3NoaWZ0JylcbiAgICAgICAgPyBjaGFuZ2VCb3hTaGFkb3coc2VsZWN0ZWROb2Rlcywga2V5cywgJ3NpemUnKVxuICAgICAgICA6IGNoYW5nZUJveFNoYWRvdyhzZWxlY3RlZE5vZGVzLCBrZXlzLCAneCcpXG4gICAgZWxzZVxuICAgICAga2V5cy5pbmNsdWRlcygnc2hpZnQnKVxuICAgICAgICA/IGNoYW5nZUJveFNoYWRvdyhzZWxlY3RlZE5vZGVzLCBrZXlzLCAnYmx1cicpXG4gICAgICAgIDogY2hhbmdlQm94U2hhZG93KHNlbGVjdGVkTm9kZXMsIGtleXMsICd5JylcbiAgfSlcblxuICBob3RrZXlzKGNvbW1hbmRfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGxldCBrZXlzID0gaGFuZGxlci5rZXkuc3BsaXQoJysnKVxuICAgIGtleXMuaW5jbHVkZXMoJ2xlZnQnKSB8fCBrZXlzLmluY2x1ZGVzKCdyaWdodCcpXG4gICAgICA/IGNoYW5nZUJveFNoYWRvdygkKHNlbGVjdG9yKSwga2V5cywgJ29wYWNpdHknKVxuICAgICAgOiBjaGFuZ2VCb3hTaGFkb3coJChzZWxlY3RvciksIGtleXMsICdpbnNldCcpXG4gIH0pXG5cbiAgcmV0dXJuICgpID0+IHtcbiAgICBob3RrZXlzLnVuYmluZChrZXlfZXZlbnRzKVxuICAgIGhvdGtleXMudW5iaW5kKGNvbW1hbmRfZXZlbnRzKVxuICAgIGhvdGtleXMudW5iaW5kKCd1cCxkb3duLGxlZnQscmlnaHQnKVxuICB9XG59XG5cbmNvbnN0IGVuc3VyZUhhc1NoYWRvdyA9IGVsID0+IHtcbiAgaWYgKGVsLnN0eWxlLmJveFNoYWRvdyA9PSAnJyB8fCBlbC5zdHlsZS5ib3hTaGFkb3cgPT0gJ25vbmUnKVxuICAgIGVsLnN0eWxlLmJveFNoYWRvdyA9ICdoc2xhKDAsMCUsMCUsMzAlKSAwIDAgMCAwJ1xuICByZXR1cm4gZWxcbn1cblxuLy8gdG9kbzogd29yayBhcm91bmQgdGhpcyBwcm9wTWFwIHdpdGggYSBiZXR0ZXIgc3BsaXRcbmNvbnN0IHByb3BNYXAgPSB7XG4gICdvcGFjaXR5JzogIDMsXG4gICd4JzogICAgICAgIDQsXG4gICd5JzogICAgICAgIDUsXG4gICdibHVyJzogICAgIDYsXG4gICdzaXplJzogICAgIDcsXG4gICdpbnNldCc6ICAgIDgsXG59XG5cbmNvbnN0IHBhcnNlQ3VycmVudFNoYWRvdyA9IGVsID0+IGdldFN0eWxlKGVsLCAnYm94U2hhZG93Jykuc3BsaXQoJyAnKVxuXG5leHBvcnQgZnVuY3Rpb24gY2hhbmdlQm94U2hhZG93KGVscywgZGlyZWN0aW9uLCBwcm9wKSB7XG4gIGVsc1xuICAgIC5tYXAoZW5zdXJlSGFzU2hhZG93KVxuICAgIC5tYXAoZWwgPT4gc2hvd0hpZGVTZWxlY3RlZChlbCwgMTUwMCkpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgZWwsXG4gICAgICBzdHlsZTogICAgICdib3hTaGFkb3cnLFxuICAgICAgY3VycmVudDogICBwYXJzZUN1cnJlbnRTaGFkb3coZWwpLCAvLyBbXCJyZ2IoMjU1LFwiLCBcIjAsXCIsIFwiMClcIiwgXCIwcHhcIiwgXCIwcHhcIiwgXCIxcHhcIiwgXCIwcHhcIl1cbiAgICAgIHByb3BJbmRleDogcGFyc2VDdXJyZW50U2hhZG93KGVsKVswXS5pbmNsdWRlcygncmdiYScpID8gcHJvcE1hcFtwcm9wXSA6IHByb3BNYXBbcHJvcF0gLSAxXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+IHtcbiAgICAgIGxldCB1cGRhdGVkID0gWy4uLnBheWxvYWQuY3VycmVudF1cbiAgICAgIGxldCBjdXIgICAgID0gcHJvcCA9PT0gJ29wYWNpdHknXG4gICAgICAgID8gcGF5bG9hZC5jdXJyZW50W3BheWxvYWQucHJvcEluZGV4XVxuICAgICAgICA6IHBhcnNlSW50KHBheWxvYWQuY3VycmVudFtwYXlsb2FkLnByb3BJbmRleF0pXG5cbiAgICAgIHN3aXRjaChwcm9wKSB7XG4gICAgICAgIGNhc2UgJ2JsdXInOlxuICAgICAgICAgIHZhciBhbW91bnQgPSBkaXJlY3Rpb24uaW5jbHVkZXMoJ3NoaWZ0JykgPyAxMCA6IDFcbiAgICAgICAgICB1cGRhdGVkW3BheWxvYWQucHJvcEluZGV4XSA9IGRpcmVjdGlvbi5pbmNsdWRlcygnZG93bicpXG4gICAgICAgICAgICA/IGAke2N1ciAtIGFtb3VudH1weGBcbiAgICAgICAgICAgIDogYCR7Y3VyICsgYW1vdW50fXB4YFxuICAgICAgICAgIGJyZWFrXG4gICAgICAgIGNhc2UgJ2luc2V0JzpcbiAgICAgICAgICB1cGRhdGVkW3BheWxvYWQucHJvcEluZGV4XSA9IGRpcmVjdGlvbi5pbmNsdWRlcygnZG93bicpXG4gICAgICAgICAgICA/ICdpbnNldCdcbiAgICAgICAgICAgIDogJydcbiAgICAgICAgICBicmVha1xuICAgICAgICBjYXNlICdvcGFjaXR5JzpcbiAgICAgICAgICBsZXQgY3VyX29wYWNpdHkgPSBwYXJzZUZsb2F0KGN1ci5zbGljZSgwLCBjdXIuaW5kZXhPZignKScpKSlcbiAgICAgICAgICB2YXIgYW1vdW50ID0gZGlyZWN0aW9uLmluY2x1ZGVzKCdzaGlmdCcpID8gMC4xMCA6IDAuMDFcbiAgICAgICAgICB1cGRhdGVkW3BheWxvYWQucHJvcEluZGV4XSA9IGRpcmVjdGlvbi5pbmNsdWRlcygnbGVmdCcpXG4gICAgICAgICAgICA/IGN1cl9vcGFjaXR5IC0gYW1vdW50ICsgJyknXG4gICAgICAgICAgICA6IGN1cl9vcGFjaXR5ICsgYW1vdW50ICsgJyknXG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICB1cGRhdGVkW3BheWxvYWQucHJvcEluZGV4XSA9IGRpcmVjdGlvbi5pbmNsdWRlcygnbGVmdCcpIHx8IGRpcmVjdGlvbi5pbmNsdWRlcygndXAnKVxuICAgICAgICAgICAgPyBgJHtjdXIgLSAxfXB4YFxuICAgICAgICAgICAgOiBgJHtjdXIgKyAxfXB4YFxuICAgICAgICAgIGJyZWFrXG4gICAgICB9XG5cbiAgICAgIHBheWxvYWQudmFsdWUgPSB1cGRhdGVkXG4gICAgICByZXR1cm4gcGF5bG9hZFxuICAgIH0pXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIHZhbHVlfSkgPT5cbiAgICAgIGVsLnN0eWxlW3N0eWxlXSA9IHZhbHVlLmpvaW4oJyAnKSlcbn1cbiIsImltcG9ydCAkIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgeyBUaW55Q29sb3IgfSBmcm9tICdAY3RybC90aW55Y29sb3InXG5cbmltcG9ydCB7IG1ldGFLZXksIGdldFN0eWxlLCBzaG93SGlkZVNlbGVjdGVkIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuY29uc3Qga2V5X2V2ZW50cyA9ICd1cCxkb3duLGxlZnQscmlnaHQnXG4gIC5zcGxpdCgnLCcpXG4gIC5yZWR1Y2UoKGV2ZW50cywgZXZlbnQpID0+XG4gICAgYCR7ZXZlbnRzfSwke2V2ZW50fSxzaGlmdCske2V2ZW50fWBcbiAgLCAnJylcbiAgLnN1YnN0cmluZygxKVxuXG5jb25zdCBjb21tYW5kX2V2ZW50cyA9IGAke21ldGFLZXl9K3VwLCR7bWV0YUtleX0rc2hpZnQrdXAsJHttZXRhS2V5fStkb3duLCR7bWV0YUtleX0rc2hpZnQrZG93biwke21ldGFLZXl9K2xlZnQsJHttZXRhS2V5fStzaGlmdCtsZWZ0LCR7bWV0YUtleX0rcmlnaHQsJHttZXRhS2V5fStzaGlmdCtyaWdodGBcblxuZXhwb3J0IGZ1bmN0aW9uIEh1ZVNoaWZ0KENvbG9yKSB7XG4gIHRoaXMuYWN0aXZlX2NvbG9yID0gQ29sb3IuZ2V0QWN0aXZlKClcblxuICBob3RrZXlzKGtleV9ldmVudHMsIChlLCBoYW5kbGVyKSA9PiB7XG4gICAgaWYgKGUuY2FuY2VsQnViYmxlKSByZXR1cm5cblxuICAgIGUucHJldmVudERlZmF1bHQoKVxuXG4gICAgbGV0IHNlbGVjdGVkTm9kZXMgPSAkKCdbZGF0YS1zZWxlY3RlZD10cnVlXScpXG4gICAgICAsIGtleXMgPSBoYW5kbGVyLmtleS5zcGxpdCgnKycpXG5cbiAgICBrZXlzLmluY2x1ZGVzKCdsZWZ0JykgfHwga2V5cy5pbmNsdWRlcygncmlnaHQnKVxuICAgICAgPyBjaGFuZ2VIdWUoc2VsZWN0ZWROb2Rlcywga2V5cywgJ3MnLCBDb2xvcilcbiAgICAgIDogY2hhbmdlSHVlKHNlbGVjdGVkTm9kZXMsIGtleXMsICdsJywgQ29sb3IpXG4gIH0pXG5cbiAgaG90a2V5cyhjb21tYW5kX2V2ZW50cywgKGUsIGhhbmRsZXIpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBsZXQga2V5cyA9IGhhbmRsZXIua2V5LnNwbGl0KCcrJylcbiAgICBrZXlzLmluY2x1ZGVzKCdsZWZ0JykgfHwga2V5cy5pbmNsdWRlcygncmlnaHQnKVxuICAgICAgPyBjaGFuZ2VIdWUoJCgnW2RhdGEtc2VsZWN0ZWQ9dHJ1ZV0nKSwga2V5cywgJ2EnLCBDb2xvcilcbiAgICAgIDogY2hhbmdlSHVlKCQoJ1tkYXRhLXNlbGVjdGVkPXRydWVdJyksIGtleXMsICdoJywgQ29sb3IpXG4gIH0pXG5cbiAgaG90a2V5cygnWyxdJywgKGUsIGhhbmRsZXIpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcblxuICAgIGlmICh0aGlzLmFjdGl2ZV9jb2xvciA9PSAnYmFja2dyb3VuZCcpXG4gICAgICB0aGlzLmFjdGl2ZV9jb2xvciA9ICdmb3JlZ3JvdW5kJ1xuICAgIGVsc2UgaWYgKHRoaXMuYWN0aXZlX2NvbG9yID09ICdmb3JlZ3JvdW5kJylcbiAgICAgIHRoaXMuYWN0aXZlX2NvbG9yID0gJ2JhY2tncm91bmQnXG5cbiAgICBDb2xvci5zZXRBY3RpdmUodGhpcy5hY3RpdmVfY29sb3IpXG4gIH0pXG5cbiAgY29uc3Qgb25Ob2Rlc1NlbGVjdGVkID0gZWxzID0+XG4gICAgQ29sb3Iuc2V0QWN0aXZlKHRoaXMuYWN0aXZlX2NvbG9yKVxuXG4gIGNvbnN0IGRpc2Nvbm5lY3QgPSAoKSA9PiB7XG4gICAgaG90a2V5cy51bmJpbmQoa2V5X2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZChjb21tYW5kX2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZCgndXAsZG93bixsZWZ0LHJpZ2h0JylcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgb25Ob2Rlc1NlbGVjdGVkLFxuICAgIGRpc2Nvbm5lY3QsXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNoYW5nZUh1ZShlbHMsIGRpcmVjdGlvbiwgcHJvcCwgQ29sb3IpIHtcbiAgZWxzXG4gICAgLm1hcChlbCA9PiBzaG93SGlkZVNlbGVjdGVkKGVsKSlcbiAgICAubWFwKGVsID0+IHtcbiAgICAgIGNvbnN0IHsgZm9yZWdyb3VuZCwgYmFja2dyb3VuZCB9ID0gZXh0cmFjdFBhbGxldGVDb2xvcnMoZWwpXG5cbiAgICAgIC8vIHRvZG86IHRlYWNoIGh1ZXNoaWZ0IHRvIGRvIGhhbmRsZSBjb2xvclxuICAgICAgc3dpdGNoKENvbG9yLmdldEFjdGl2ZSgpKSB7XG4gICAgICAgIGNhc2UgJ2JhY2tncm91bmQnOlxuICAgICAgICAgIHJldHVybiB7IGVsLCBjdXJyZW50OiBiYWNrZ3JvdW5kLmNvbG9yLnRvSHNsKCksIHN0eWxlOiBiYWNrZ3JvdW5kLnN0eWxlIH1cbiAgICAgICAgY2FzZSAnZm9yZWdyb3VuZCc6XG4gICAgICAgICAgcmV0dXJuIHsgZWwsIGN1cnJlbnQ6IGZvcmVncm91bmQuY29sb3IudG9Ic2woKSwgc3R5bGU6IGZvcmVncm91bmQuc3R5bGUgfVxuICAgICAgfVxuICAgIH0pXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgYW1vdW50OiAgIGRpcmVjdGlvbi5pbmNsdWRlcygnc2hpZnQnKSA/IDEwIDogMSxcbiAgICAgICAgbmVnYXRpdmU6IGRpcmVjdGlvbi5pbmNsdWRlcygnZG93bicpIHx8IGRpcmVjdGlvbi5pbmNsdWRlcygnbGVmdCcpLFxuICAgICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+IHtcbiAgICAgIGlmIChwcm9wID09PSAncycgfHwgcHJvcCA9PT0gJ2wnIHx8IHByb3AgPT09ICdhJylcbiAgICAgICAgcGF5bG9hZC5hbW91bnQgPSBwYXlsb2FkLmFtb3VudCAqIDAuMDFcblxuICAgICAgcGF5bG9hZC5jdXJyZW50W3Byb3BdID0gcGF5bG9hZC5uZWdhdGl2ZVxuICAgICAgICA/IHBheWxvYWQuY3VycmVudFtwcm9wXSAtIHBheWxvYWQuYW1vdW50XG4gICAgICAgIDogcGF5bG9hZC5jdXJyZW50W3Byb3BdICsgcGF5bG9hZC5hbW91bnRcblxuICAgICAgaWYgKHByb3AgPT09ICdzJyB8fCBwcm9wID09PSAnbCcgfHwgcHJvcCA9PT0gJ2EnKSB7XG4gICAgICAgIGlmIChwYXlsb2FkLmN1cnJlbnRbcHJvcF0gPiAxKSBwYXlsb2FkLmN1cnJlbnRbcHJvcF0gPSAxXG4gICAgICAgIGlmIChwYXlsb2FkLmN1cnJlbnRbcHJvcF0gPCAwKSBwYXlsb2FkLmN1cnJlbnRbcHJvcF0gPSAwXG4gICAgICB9XG5cbiAgICAgIHJldHVybiBwYXlsb2FkXG4gICAgfSlcbiAgICAuZm9yRWFjaCgoe2VsLCBzdHlsZSwgY3VycmVudH0pID0+IHtcbiAgICAgIGxldCBjb2xvciA9IG5ldyBUaW55Q29sb3IoY3VycmVudCkuc2V0QWxwaGEoY3VycmVudC5hKVxuICAgICAgZWwuc3R5bGVbc3R5bGVdID0gY29sb3IudG9Ic2xTdHJpbmcoKVxuXG4gICAgICBpZiAoc3R5bGUgPT0gJ2NvbG9yJykgQ29sb3IuZm9yZWdyb3VuZC5jb2xvcihjb2xvci50b0hleFN0cmluZygpKVxuICAgICAgaWYgKHN0eWxlID09ICdiYWNrZ3JvdW5kQ29sb3InKSBDb2xvci5iYWNrZ3JvdW5kLmNvbG9yKGNvbG9yLnRvSGV4U3RyaW5nKCkpXG4gICAgfSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGV4dHJhY3RQYWxsZXRlQ29sb3JzKGVsKSB7XG4gIGlmIChlbCBpbnN0YW5jZW9mIFNWR0VsZW1lbnQpIHtcbiAgICBjb25zdCAgZmdfdGVtcCA9IGdldFN0eWxlKGVsLCAnc3Ryb2tlJylcblxuICAgIHJldHVybiB7XG4gICAgICBmb3JlZ3JvdW5kOiB7XG4gICAgICAgIHN0eWxlOiAnc3Ryb2tlJyxcbiAgICAgICAgY29sb3I6IG5ldyBUaW55Q29sb3IoZmdfdGVtcCA9PT0gJ25vbmUnXG4gICAgICAgICAgPyAncmdiKDAsIDAsIDApJ1xuICAgICAgICAgIDogZmdfdGVtcCksXG4gICAgICB9LFxuICAgICAgYmFja2dyb3VuZDoge1xuICAgICAgICBzdHlsZTogJ2ZpbGwnLFxuICAgICAgICBjb2xvcjogbmV3IFRpbnlDb2xvcihnZXRTdHlsZShlbCwgJ2ZpbGwnKSksXG4gICAgICB9XG4gICAgfVxuICB9XG4gIGVsc2VcbiAgICByZXR1cm4ge1xuICAgICAgZm9yZWdyb3VuZDoge1xuICAgICAgICBzdHlsZTogJ2NvbG9yJyxcbiAgICAgICAgY29sb3I6IG5ldyBUaW55Q29sb3IoZ2V0U3R5bGUoZWwsICdjb2xvcicpKSxcbiAgICAgIH0sXG4gICAgICBiYWNrZ3JvdW5kOiB7XG4gICAgICAgIHN0eWxlOiAnYmFja2dyb3VuZENvbG9yJyxcbiAgICAgICAgY29sb3I6IG5ldyBUaW55Q29sb3IoZ2V0U3R5bGUoZWwsICdiYWNrZ3JvdW5kQ29sb3InKSksXG4gICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IHsgaXNPZmZCb3VuZHMgfSBmcm9tICcuLi91dGlsaXRpZXMvJ1xuXG5sZXQgZ3JpZGxpbmVzXG5cbmV4cG9ydCBmdW5jdGlvbiBHdWlkZXMoKSB7XG4gICQoJ2JvZHknKS5vbignbW91c2VvdmVyJywgb25faG92ZXIpXG4gICQoJ2JvZHknKS5vbignbW91c2VvdXQnLCBvbl9ob3Zlcm91dClcbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIGhpZGVHcmlkbGluZXMpXG5cbiAgcmV0dXJuICgpID0+IHtcbiAgICAkKCdib2R5Jykub2ZmKCdtb3VzZW92ZXInLCBvbl9ob3ZlcilcbiAgICAkKCdib2R5Jykub2ZmKCdtb3VzZW91dCcsIG9uX2hvdmVyb3V0KVxuICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdzY3JvbGwnLCBoaWRlR3JpZGxpbmVzKVxuICAgIGhpZGVHcmlkbGluZXMoKVxuICB9XG59XG5cbmNvbnN0IG9uX2hvdmVyID0gKHt0YXJnZXR9KSA9PiB7XG4gIGlmIChpc09mZkJvdW5kcyh0YXJnZXQpKSByZXR1cm5cbiAgc2hvd0dyaWRsaW5lcyh0YXJnZXQpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVHdWlkZSh2ZXJ0ID0gdHJ1ZSkge1xuICBsZXQgZ3VpZGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICBsZXQgc3R5bGVzID0gYFxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDA7XG4gICAgbGVmdDogMDtcbiAgICBiYWNrZ3JvdW5kOiBoc2xhKDMzMCwgMTAwJSwgNzElLCA3MCUpO1xuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xuICAgIHotaW5kZXg6IDk5OTc7XG4gIGBcblxuICB2ZXJ0IFxuICAgID8gc3R5bGVzICs9IGBcbiAgICAgICAgd2lkdGg6IDFweDtcbiAgICAgICAgaGVpZ2h0OiAxMDB2aDtcbiAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMTgwZGVnKTtcbiAgICAgIGBcbiAgICA6IHN0eWxlcyArPSBgXG4gICAgICBoZWlnaHQ6IDFweDtcbiAgICAgIHdpZHRoOiAxMDB2dztcbiAgICBgXG5cbiAgZ3VpZGUuc3R5bGUgPSBzdHlsZXNcblxuICByZXR1cm4gZ3VpZGVcbn1cblxuLy8gZXhwb3J0IGZ1bmN0aW9uIEd1aWRlcygpIHtcbi8vICAgbGV0IHYgPSBjcmVhdGVHdWlkZSgpXG4vLyAgICAgLCBoID0gY3JlYXRlR3VpZGUoZmFsc2UpXG5cbi8vICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh2KVxuLy8gICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGgpXG4vLyAgIGRvY3VtZW50LmJvZHkuc3R5bGUuY3Vyc29yID0gJ2Nyb3NzaGFpcidcblxuLy8gICBjb25zdCBtb3VzZU1vdmUgPSBlID0+IHtcbi8vICAgICB2LnN0eWxlLmxlZnQgID0gZS5jbGllbnRYICsgJ3B4J1xuLy8gICAgIGguc3R5bGUudG9wICAgPSBlLmNsaWVudFkgKyAncHgnXG4vLyAgIH1cblxuLy8gICAkKCdib2R5Jykub24oJ21vdXNlbW92ZScsIG1vdXNlTW92ZSlcblxuLy8gICByZXR1cm4gKCkgPT4ge1xuLy8gICAgICQoJ2JvZHknKS5vZmYoJ21vdXNlbW92ZScsIG1vdXNlTW92ZSlcbi8vICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKHYpXG4vLyAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChoKVxuLy8gICAgIGRvY3VtZW50LmJvZHkuc3R5bGUuY3Vyc29yID0gbnVsbFxuLy8gICB9XG4vLyB9XG5cbmNvbnN0IG9uX2hvdmVyb3V0ID0gKHt0YXJnZXR9KSA9PlxuICBoaWRlR3JpZGxpbmVzKClcblxuY29uc3Qgc2hvd0dyaWRsaW5lcyA9IG5vZGUgPT4ge1xuICBpZiAoZ3JpZGxpbmVzKSB7XG4gICAgZ3JpZGxpbmVzLnN0eWxlLmRpc3BsYXkgPSBudWxsXG4gICAgZ3JpZGxpbmVzLnVwZGF0ZSA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KClcbiAgfVxuICBlbHNlIHtcbiAgICBncmlkbGluZXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdwYi1ncmlkbGluZXMnKVxuICAgIGdyaWRsaW5lcy5wb3NpdGlvbiA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KClcblxuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZ3JpZGxpbmVzKVxuICB9XG59XG5cbmNvbnN0IGhpZGVHcmlkbGluZXMgPSBub2RlID0+IHtcbiAgaWYgKCFncmlkbGluZXMpIHJldHVyblxuICBncmlkbGluZXMuc3R5bGUuZGlzcGxheSA9ICdub25lJ1xufSIsImV4cG9ydCBmdW5jdGlvbiBTY3JlZW5zaG90KG5vZGUsIHBhZ2UpIHtcbiAgYWxlcnQoJ0NvbWluZyBTb29uIScpXG5cbiAgcmV0dXJuICgpID0+IHt9XG59IiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCB7IG1ldGFLZXksIGdldFN0eWxlLCBnZXRTaWRlLCBzaG93SGlkZVNlbGVjdGVkIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuY29uc3Qga2V5X2V2ZW50cyA9ICd1cCxkb3duLGxlZnQscmlnaHQnXG4gIC5zcGxpdCgnLCcpXG4gIC5yZWR1Y2UoKGV2ZW50cywgZXZlbnQpID0+XG4gICAgYCR7ZXZlbnRzfSwke2V2ZW50fSxhbHQrJHtldmVudH0sc2hpZnQrJHtldmVudH0sc2hpZnQrYWx0KyR7ZXZlbnR9YFxuICAsICcnKVxuICAuc3Vic3RyaW5nKDEpXG5cbmNvbnN0IGNvbW1hbmRfZXZlbnRzID0gYCR7bWV0YUtleX0rdXAsJHttZXRhS2V5fStzaGlmdCt1cCwke21ldGFLZXl9K2Rvd24sJHttZXRhS2V5fStzaGlmdCtkb3duYFxuXG5leHBvcnQgZnVuY3Rpb24gUG9zaXRpb24oKSB7XG4gIHRoaXMuX2VscyA9IFtdXG5cbiAgaG90a2V5cyhrZXlfZXZlbnRzLCAoZSwgaGFuZGxlcikgPT4ge1xuICAgIGlmIChlLmNhbmNlbEJ1YmJsZSkgcmV0dXJuXG5cbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBwb3NpdGlvbkVsZW1lbnQoJCgnW2RhdGEtc2VsZWN0ZWQ9dHJ1ZV0nKSwgaGFuZGxlci5rZXkpXG4gIH0pXG5cbiAgY29uc3Qgb25Ob2Rlc1NlbGVjdGVkID0gZWxzID0+IHtcbiAgICB0aGlzLl9lbHMuZm9yRWFjaChlbCA9PlxuICAgICAgZWwudGVhcmRvd24oKSlcblxuICAgIHRoaXMuX2VscyA9IGVscy5tYXAoZWwgPT5cbiAgICAgIGRyYWdnYWJsZShlbCkpXG4gIH1cblxuICBjb25zdCBkaXNjb25uZWN0ID0gKCkgPT4ge1xuICAgIHRoaXMuX2Vscy5mb3JFYWNoKGVsID0+IGVsLnRlYXJkb3duKCkpXG4gICAgaG90a2V5cy51bmJpbmQoa2V5X2V2ZW50cylcbiAgICBob3RrZXlzLnVuYmluZCgndXAsZG93bixsZWZ0LHJpZ2h0JylcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgb25Ob2Rlc1NlbGVjdGVkLFxuICAgIGRpc2Nvbm5lY3QsXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRyYWdnYWJsZShlbCkge1xuICB0aGlzLnN0YXRlID0ge1xuICAgIG1vdXNlOiB7XG4gICAgICBkb3duOiBmYWxzZSxcbiAgICAgIHg6IDAsXG4gICAgICB5OiAwLFxuICAgIH0sXG4gICAgZWxlbWVudDoge1xuICAgICAgeDogMCxcbiAgICAgIHk6IDAsXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgc2V0dXAgPSAoKSA9PiB7XG4gICAgZWwuc3R5bGUudHJhbnNpdGlvbiAgID0gJ25vbmUnXG4gICAgZWwuc3R5bGUuY3Vyc29yICAgICAgID0gJ21vdmUnXG5cbiAgICBlbC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBvbk1vdXNlRG93biwgdHJ1ZSlcbiAgICBlbC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZXVwJywgb25Nb3VzZVVwLCB0cnVlKVxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlbW92ZScsIG9uTW91c2VNb3ZlLCB0cnVlKVxuICB9XG5cbiAgY29uc3QgdGVhcmRvd24gPSAoKSA9PiB7XG4gICAgZWwuc3R5bGUudHJhbnNpdGlvbiAgID0gbnVsbFxuICAgIGVsLnN0eWxlLmN1cnNvciAgICAgICA9IG51bGxcblxuICAgIGVsLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIG9uTW91c2VEb3duLCB0cnVlKVxuICAgIGVsLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNldXAnLCBvbk1vdXNlVXAsIHRydWUpXG4gICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vtb3ZlJywgb25Nb3VzZU1vdmUsIHRydWUpXG4gIH1cblxuICBjb25zdCBvbk1vdXNlRG93biA9IGUgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuXG4gICAgY29uc3QgZWwgPSBlLnRhcmdldFxuXG4gICAgZWwuc3R5bGUucG9zaXRpb24gPSAncmVsYXRpdmUnXG4gICAgZWwuc3R5bGUud2lsbENoYW5nZSA9ICd0b3AsbGVmdCdcblxuICAgIGlmIChlbCBpbnN0YW5jZW9mIFNWR0VsZW1lbnQpIHtcbiAgICAgIGNvbnN0IHRyYW5zbGF0ZSA9IGVsLmdldEF0dHJpYnV0ZSgndHJhbnNmb3JtJylcblxuICAgICAgY29uc3QgWyB4LCB5IF0gPSB0cmFuc2xhdGVcbiAgICAgICAgPyBleHRyYWN0U1ZHVHJhbnNsYXRlKHRyYW5zbGF0ZSlcbiAgICAgICAgOiBbMCwwXVxuXG4gICAgICB0aGlzLnN0YXRlLmVsZW1lbnQueCAgPSB4XG4gICAgICB0aGlzLnN0YXRlLmVsZW1lbnQueSAgPSB5XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgdGhpcy5zdGF0ZS5lbGVtZW50LnggID0gcGFyc2VJbnQoZ2V0U3R5bGUoZWwsICdsZWZ0JykpXG4gICAgICB0aGlzLnN0YXRlLmVsZW1lbnQueSAgPSBwYXJzZUludChnZXRTdHlsZShlbCwgJ3RvcCcpKVxuICAgIH1cblxuICAgIHRoaXMuc3RhdGUubW91c2UueCAgICAgID0gZS5jbGllbnRYXG4gICAgdGhpcy5zdGF0ZS5tb3VzZS55ICAgICAgPSBlLmNsaWVudFlcbiAgICB0aGlzLnN0YXRlLm1vdXNlLmRvd24gICA9IHRydWVcbiAgfVxuXG4gIGNvbnN0IG9uTW91c2VVcCA9IGUgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuXG4gICAgdGhpcy5zdGF0ZS5tb3VzZS5kb3duID0gZmFsc2VcbiAgICBlbC5zdHlsZS53aWxsQ2hhbmdlID0gbnVsbFxuXG4gICAgaWYgKGVsIGluc3RhbmNlb2YgU1ZHRWxlbWVudCkge1xuICAgICAgY29uc3QgdHJhbnNsYXRlID0gZWwuZ2V0QXR0cmlidXRlKCd0cmFuc2Zvcm0nKVxuXG4gICAgICBjb25zdCBbIHgsIHkgXSA9IHRyYW5zbGF0ZVxuICAgICAgICA/IGV4dHJhY3RTVkdUcmFuc2xhdGUodHJhbnNsYXRlKVxuICAgICAgICA6IFswLDBdXG5cbiAgICAgIHRoaXMuc3RhdGUuZWxlbWVudC54ICAgID0geFxuICAgICAgdGhpcy5zdGF0ZS5lbGVtZW50LnkgICAgPSB5XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgdGhpcy5zdGF0ZS5lbGVtZW50LnggICAgPSBwYXJzZUludChlbC5zdHlsZS5sZWZ0KSB8fCAwXG4gICAgICB0aGlzLnN0YXRlLmVsZW1lbnQueSAgICA9IHBhcnNlSW50KGVsLnN0eWxlLnRvcCkgfHwgMFxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IG9uTW91c2VNb3ZlID0gZSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKVxuXG4gICAgaWYgKCF0aGlzLnN0YXRlLm1vdXNlLmRvd24pIHJldHVyblxuXG4gICAgaWYgKGVsIGluc3RhbmNlb2YgU1ZHRWxlbWVudCkge1xuICAgICAgZWwuc2V0QXR0cmlidXRlKCd0cmFuc2Zvcm0nLCBgdHJhbnNsYXRlKFxuICAgICAgICAke3RoaXMuc3RhdGUuZWxlbWVudC54ICsgZS5jbGllbnRYIC0gdGhpcy5zdGF0ZS5tb3VzZS54fSxcbiAgICAgICAgJHt0aGlzLnN0YXRlLmVsZW1lbnQueSArIGUuY2xpZW50WSAtIHRoaXMuc3RhdGUubW91c2UueX1cbiAgICAgIClgKVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIGVsLnN0eWxlLmxlZnQgPSB0aGlzLnN0YXRlLmVsZW1lbnQueCArIGUuY2xpZW50WCAtIHRoaXMuc3RhdGUubW91c2UueCArICdweCdcbiAgICAgIGVsLnN0eWxlLnRvcCAgPSB0aGlzLnN0YXRlLmVsZW1lbnQueSArIGUuY2xpZW50WSAtIHRoaXMuc3RhdGUubW91c2UueSArICdweCdcbiAgICB9XG4gIH1cblxuICBzZXR1cCgpXG5cbiAgcmV0dXJuIHtcbiAgICB0ZWFyZG93blxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwb3NpdGlvbkVsZW1lbnQoZWxzLCBkaXJlY3Rpb24pIHtcbiAgZWxzXG4gICAgLm1hcChlbCA9PiBlbnN1cmVQb3NpdGlvbmFibGUoZWwpKVxuICAgIC5tYXAoZWwgPT4gc2hvd0hpZGVTZWxlY3RlZChlbCkpXG4gICAgLm1hcChlbCA9PiAoe1xuICAgICAgICBlbCxcbiAgICAgICAgLi4uZXh0cmFjdEN1cnJlbnRWYWx1ZUFuZFNpZGUoZWwsIGRpcmVjdGlvbiksXG4gICAgICAgIGFtb3VudDogICBkaXJlY3Rpb24uc3BsaXQoJysnKS5pbmNsdWRlcygnc2hpZnQnKSA/IDEwIDogMSxcbiAgICAgICAgbmVnYXRpdmU6IGRldGVybWluZU5lZ2F0aXZpdHkoZWwsIGRpcmVjdGlvbiksXG4gICAgfSkpXG4gICAgLm1hcChwYXlsb2FkID0+XG4gICAgICBPYmplY3QuYXNzaWduKHBheWxvYWQsIHtcbiAgICAgICAgcG9zaXRpb246IHBheWxvYWQubmVnYXRpdmVcbiAgICAgICAgICA/IHBheWxvYWQuY3VycmVudCArIHBheWxvYWQuYW1vdW50XG4gICAgICAgICAgOiBwYXlsb2FkLmN1cnJlbnQgLSBwYXlsb2FkLmFtb3VudFxuICAgICAgfSkpXG4gICAgLmZvckVhY2goKHtlbCwgc3R5bGUsIHBvc2l0aW9ufSkgPT5cbiAgICAgIGVsIGluc3RhbmNlb2YgU1ZHRWxlbWVudFxuICAgICAgICA/IHNldFRyYW5zbGF0ZU9uU1ZHKGVsLCBkaXJlY3Rpb24sIHBvc2l0aW9uKVxuICAgICAgICA6IGVsLnN0eWxlW3N0eWxlXSA9IHBvc2l0aW9uICsgJ3B4Jylcbn1cblxuY29uc3QgZXh0cmFjdEN1cnJlbnRWYWx1ZUFuZFNpZGUgPSAoZWwsIGRpcmVjdGlvbikgPT4ge1xuICBsZXQgc3R5bGUsIGN1cnJlbnRcblxuICBpZiAoZWwgaW5zdGFuY2VvZiBTVkdFbGVtZW50KSB7XG4gICAgY29uc3QgdHJhbnNsYXRlID0gZWwuYXR0cigndHJhbnNmb3JtJylcblxuICAgIGNvbnN0IFsgeCwgeSBdID0gdHJhbnNsYXRlXG4gICAgICA/IGV4dHJhY3RTVkdUcmFuc2xhdGUodHJhbnNsYXRlKVxuICAgICAgOiBbMCwwXVxuXG4gICAgc3R5bGUgICA9ICd0cmFuc2Zvcm0nXG4gICAgY3VycmVudCA9IGRpcmVjdGlvbi5pbmNsdWRlcygnZG93bicpIHx8IGRpcmVjdGlvbi5pbmNsdWRlcygndXAnKVxuICAgICAgPyB5XG4gICAgICA6IHhcbiAgfVxuICBlbHNlIHtcbiAgICBzdHlsZSAgID0gZ2V0U2lkZShkaXJlY3Rpb24pLnRvTG93ZXJDYXNlKClcbiAgICBjdXJyZW50ID0gZ2V0U3R5bGUoZWwsIHN0eWxlKVxuXG4gICAgY3VycmVudCA9PT0gJ2F1dG8nXG4gICAgICA/IGN1cnJlbnQgPSAwXG4gICAgICA6IGN1cnJlbnQgPSBwYXJzZUludChjdXJyZW50LCAxMClcbiAgfVxuXG4gIHJldHVybiB7IHN0eWxlLCBjdXJyZW50IH1cbn1cblxuY29uc3QgZXh0cmFjdFNWR1RyYW5zbGF0ZSA9IHRyYW5zbGF0ZSA9PlxuICB0cmFuc2xhdGUuc3Vic3RyaW5nKFxuICAgIHRyYW5zbGF0ZS5pbmRleE9mKCcoJykgKyAxLFxuICAgIHRyYW5zbGF0ZS5pbmRleE9mKCcpJylcbiAgKS5zcGxpdCgnLCcpXG4gIC5tYXAodmFsID0+IHBhcnNlRmxvYXQodmFsKSlcblxuY29uc3Qgc2V0VHJhbnNsYXRlT25TVkcgPSAoZWwsIGRpcmVjdGlvbiwgcG9zaXRpb24pID0+IHtcbiAgY29uc3QgdHJhbnNmb3JtID0gZWwuYXR0cigndHJhbnNmb3JtJylcbiAgY29uc3QgWyB4LCB5IF0gPSB0cmFuc2Zvcm1cbiAgICA/IGV4dHJhY3RTVkdUcmFuc2xhdGUodHJhbnNmb3JtKVxuICAgIDogWzAsMF1cblxuICBjb25zdCBwb3MgPSBkaXJlY3Rpb24uaW5jbHVkZXMoJ2Rvd24nKSB8fCBkaXJlY3Rpb24uaW5jbHVkZXMoJ3VwJylcbiAgICA/IGAke3h9LCR7cG9zaXRpb259YFxuICAgIDogYCR7cG9zaXRpb259LCR7eX1gXG5cbiAgZWwuYXR0cigndHJhbnNmb3JtJywgYHRyYW5zbGF0ZSgke3Bvc30pYClcbn1cblxuY29uc3QgZGV0ZXJtaW5lTmVnYXRpdml0eSA9IChlbCwgZGlyZWN0aW9uKSA9PlxuICBlbCBpbnN0YW5jZW9mIFNWR0VsZW1lbnRcbiAgICA/IGRpcmVjdGlvbi5pbmNsdWRlcygncmlnaHQnKSB8fCBkaXJlY3Rpb24uaW5jbHVkZXMoJ2Rvd24nKVxuICAgIDogZGlyZWN0aW9uLnNwbGl0KCcrJykuaW5jbHVkZXMoJ2FsdCcpXG5cbmNvbnN0IGVuc3VyZVBvc2l0aW9uYWJsZSA9IGVsID0+IHtcbiAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTEVsZW1lbnQpXG4gICAgZWwuc3R5bGUucG9zaXRpb24gPSAncmVsYXRpdmUnXG4gIHJldHVybiBlbFxufVxuIiwiaW1wb3J0ICQgZnJvbSAnYmxpbmdibGluZ2pzJ1xuaW1wb3J0IGhvdGtleXMgZnJvbSAnaG90a2V5cy1qcydcbmltcG9ydCB7IFRpbnlDb2xvciwgcmVhZGFiaWxpdHksIGlzUmVhZGFibGUgfSBmcm9tICdAY3RybC90aW55Y29sb3InXG5pbXBvcnQgeyBnZXRTdHlsZSwgZ2V0U3R5bGVzLCBpc09mZkJvdW5kcywgZ2V0QTExeXMsIGdldFdDQUcyVGV4dFNpemUsIGdldENvbXB1dGVkQmFja2dyb3VuZENvbG9yIH0gZnJvbSAnLi4vdXRpbGl0aWVzLydcblxuY29uc3QgdGlwX21hcCA9IG5ldyBNYXAoKVxuXG5leHBvcnQgZnVuY3Rpb24gQWNjZXNzaWJpbGl0eSgpIHtcbiAgY29uc3QgdGVtcGxhdGUgPSAoe3RhcmdldDogZWx9KSA9PiB7XG4gICAgbGV0IHRpcCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3BiLWFsbHknKVxuXG4gICAgY29uc3QgY29udHJhc3RfcmVzdWx0cyA9IGRldGVybWluZUNvbG9yQ29udHJhc3QoZWwpXG4gICAgY29uc3QgYWxseV9hdHRyaWJ1dGVzID0gZ2V0QTExeXMoZWwpXG5cbiAgICBhbGx5X2F0dHJpYnV0ZXMubWFwKGFsbHkgPT5cbiAgICAgIGFsbHkucHJvcC5pbmNsdWRlcygnYWx0JylcbiAgICAgICAgPyBhbGx5LnZhbHVlID0gYDxzcGFuIHRleHQ+JHthbGx5LnZhbHVlfTwvc3Bhbj5gXG4gICAgICAgIDogYWxseSlcblxuICAgIHRpcC5tZXRhID0ge1xuICAgICAgZWwsIFxuICAgICAgYWxseV9hdHRyaWJ1dGVzLFxuICAgICAgY29udHJhc3RfcmVzdWx0cyxcbiAgICB9XG5cbiAgICByZXR1cm4gdGlwXG4gIH1cblxuICBjb25zdCBkZXRlcm1pbmVDb2xvckNvbnRyYXN0ID0gZWwgPT4ge1xuICAgIC8vIHF1ZXN0aW9uOiBob3cgdG8ga25vdyBpZiB0aGUgY3VycmVudCBub2RlIGlzIGFjdHVhbGx5IGEgYmxhY2sgYmFja2dyb3VuZD9cbiAgICAvLyBxdWVzdGlvbjogaXMgdGhlcmUgYW4gYXBpIGZvciBjb21wb3NpdGVkIHZhbHVlcz9cbiAgICBjb25zdCB0ZXh0ICAgICAgPSBnZXRTdHlsZShlbCwgJ2NvbG9yJylcbiAgICBjb25zdCB0ZXh0U2l6ZSAgPSBnZXRXQ0FHMlRleHRTaXplKGVsKVxuXG4gICAgbGV0IGJhY2tncm91bmQgID0gZ2V0Q29tcHV0ZWRCYWNrZ3JvdW5kQ29sb3IoZWwpXG5cbiAgICBjb25zdCBbIGFhX2NvbnRyYXN0LCBhYWFfY29udHJhc3QgXSA9IFtcbiAgICAgIGlzUmVhZGFibGUoYmFja2dyb3VuZCwgdGV4dCwgeyBsZXZlbDogXCJBQVwiLCBzaXplOiB0ZXh0U2l6ZS50b0xvd2VyQ2FzZSgpIH0pLFxuICAgICAgaXNSZWFkYWJsZShiYWNrZ3JvdW5kLCB0ZXh0LCB7IGxldmVsOiBcIkFBQVwiLCBzaXplOiB0ZXh0U2l6ZS50b0xvd2VyQ2FzZSgpIH0pXG4gICAgXVxuXG4gICAgcmV0dXJuIGBcbiAgICAgIDxzcGFuIHByb3A+Q29sb3IgY29udHJhc3Q8L3NwYW4+XG4gICAgICA8c3BhbiB2YWx1ZSBjb250cmFzdD5cbiAgICAgICAgPHNwYW4gc3R5bGU9XCJcbiAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiR7YmFja2dyb3VuZH07XG4gICAgICAgICAgY29sb3I6JHt0ZXh0fTtcbiAgICAgICAgXCI+JHtNYXRoLmZsb29yKHJlYWRhYmlsaXR5KGJhY2tncm91bmQsIHRleHQpICAqIDEwMCkgLyAxMDB9PC9zcGFuPlxuICAgICAgPC9zcGFuPlxuICAgICAgPHNwYW4gcHJvcD7igLogQUEgJHt0ZXh0U2l6ZX08L3NwYW4+XG4gICAgICA8c3BhbiB2YWx1ZSBzdHlsZT1cIiR7YWFfY29udHJhc3QgPyAnY29sb3I6Z3JlZW47JyA6ICdjb2xvcjpyZWQnfVwiPiR7YWFfY29udHJhc3QgPyAn4pyTJyA6ICfDlyd9PC9zcGFuPlxuICAgICAgPHNwYW4gcHJvcD7igLogQUFBICR7dGV4dFNpemV9PC9zcGFuPlxuICAgICAgPHNwYW4gdmFsdWUgc3R5bGU9XCIke2FhYV9jb250cmFzdCA/ICdjb2xvcjpncmVlbjsnIDogJ2NvbG9yOnJlZCd9XCI+JHthYWFfY29udHJhc3QgPyAn4pyTJyA6ICfDlyd9PC9zcGFuPlxuICAgIGBcbiAgfVxuXG4gIGNvbnN0IG1vdXNlX3F1YWRyYW50ID0gZSA9PiAoe1xuICAgIG5vcnRoOiBlLmNsaWVudFkgPiB3aW5kb3cuaW5uZXJIZWlnaHQgLyAyLFxuICAgIHdlc3Q6ICBlLmNsaWVudFggPiB3aW5kb3cuaW5uZXJXaWR0aCAvIDJcbiAgfSlcblxuICBjb25zdCB0aXBfcG9zaXRpb24gPSAobm9kZSwgZSwgbm9ydGgsIHdlc3QpID0+ICh7XG4gICAgdG9wOiBgJHtub3J0aFxuICAgICAgPyBlLnBhZ2VZIC0gbm9kZS5jbGllbnRIZWlnaHQgLSAyMFxuICAgICAgOiBlLnBhZ2VZICsgMjV9cHhgLFxuICAgIGxlZnQ6IGAke3dlc3RcbiAgICAgID8gZS5wYWdlWCAtIG5vZGUuY2xpZW50V2lkdGggKyAyM1xuICAgICAgOiBlLnBhZ2VYIC0gMjF9cHhgLFxuICB9KVxuXG4gIGNvbnN0IHVwZGF0ZV90aXAgPSAodGlwLCBlKSA9PiB7XG4gICAgY29uc3QgeyBub3J0aCwgd2VzdCB9ID0gbW91c2VfcXVhZHJhbnQoZSlcbiAgICBjb25zdCB7bGVmdCwgdG9wfSAgICAgPSB0aXBfcG9zaXRpb24odGlwLCBlLCBub3J0aCwgd2VzdClcblxuICAgIHRpcC5zdHlsZS5sZWZ0ICA9IGxlZnRcbiAgICB0aXAuc3R5bGUudG9wICAgPSB0b3AgXG5cbiAgICB0aXAuc3R5bGUuc2V0UHJvcGVydHkoJy0tYXJyb3cnLCBub3J0aCBcbiAgICAgID8gJ3ZhcigtLWFycm93LXVwKSdcbiAgICAgIDogJ3ZhcigtLWFycm93LWRvd24pJylcblxuICAgIHRpcC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1zaGFkb3ctZGlyZWN0aW9uJywgbm9ydGggXG4gICAgICA/ICd2YXIoLS1zaGFkb3ctdXApJ1xuICAgICAgOiAndmFyKC0tc2hhZG93LWRvd24pJylcblxuICAgIHRpcC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1hcnJvdy10b3AnLCAhbm9ydGggXG4gICAgICA/ICctOHB4J1xuICAgICAgOiAnMTAwJScpXG5cbiAgICB0aXAuc3R5bGUuc2V0UHJvcGVydHkoJy0tYXJyb3ctbGVmdCcsIHdlc3QgXG4gICAgICA/ICdjYWxjKDEwMCUgLSAxNXB4IC0gMTVweCknXG4gICAgICA6ICcxNXB4JylcbiAgfVxuXG4gIGNvbnN0IG1vdXNlT3V0ID0gKHt0YXJnZXR9KSA9PiB7XG4gICAgaWYgKHRpcF9tYXAuaGFzKHRhcmdldCkgJiYgIXRhcmdldC5oYXNBdHRyaWJ1dGUoJ2RhdGEtbWV0YXRpcCcpKSB7XG4gICAgICB0YXJnZXQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2VvdXQnLCBtb3VzZU91dClcbiAgICAgIHRhcmdldC5yZW1vdmVFdmVudExpc3RlbmVyKCdET01Ob2RlUmVtb3ZlZCcsIG1vdXNlT3V0KVxuICAgICAgdGFyZ2V0LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdG9nZ2xlUGlubmVkKVxuICAgICAgdGlwX21hcC5nZXQodGFyZ2V0KS50aXAucmVtb3ZlKClcbiAgICAgIHRpcF9tYXAuZGVsZXRlKHRhcmdldClcbiAgICB9XG4gIH1cblxuICBjb25zdCB0b2dnbGVQaW5uZWQgPSBlID0+IHtcbiAgICBpZiAoZS5hbHRLZXkpIHtcbiAgICAgICFlLnRhcmdldC5oYXNBdHRyaWJ1dGUoJ2RhdGEtbWV0YXRpcCcpXG4gICAgICAgID8gZS50YXJnZXQuc2V0QXR0cmlidXRlKCdkYXRhLW1ldGF0aXAnLCB0cnVlKVxuICAgICAgICA6IGUudGFyZ2V0LnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1tZXRhdGlwJylcbiAgICB9XG4gIH1cblxuICBjb25zdCBtb3VzZU1vdmUgPSBlID0+IHtcbiAgICBpZiAoaXNPZmZCb3VuZHMoZS50YXJnZXQpKSByZXR1cm5cblxuICAgIGUuYWx0S2V5XG4gICAgICA/IGUudGFyZ2V0LnNldEF0dHJpYnV0ZSgnZGF0YS1waW5ob3ZlcicsIHRydWUpXG4gICAgICA6IGUudGFyZ2V0LnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1waW5ob3ZlcicpXG5cbiAgICAvLyBpZiBub2RlIGlzIGluIG91ciBoYXNoIChhbHJlYWR5IGNyZWF0ZWQpXG4gICAgaWYgKHRpcF9tYXAuaGFzKGUudGFyZ2V0KSkge1xuICAgICAgLy8gcmV0dXJuIGlmIGl0J3MgcGlubmVkXG4gICAgICBpZiAoZS50YXJnZXQuaGFzQXR0cmlidXRlKCdkYXRhLW1ldGF0aXAnKSkgXG4gICAgICAgIHJldHVyblxuICAgICAgLy8gb3RoZXJ3aXNlIHVwZGF0ZSBwb3NpdGlvblxuICAgICAgY29uc3QgeyB0aXAgfSA9IHRpcF9tYXAuZ2V0KGUudGFyZ2V0KVxuICAgICAgdXBkYXRlX3RpcCh0aXAsIGUpXG4gICAgfVxuICAgIC8vIGNyZWF0ZSBuZXcgdGlwXG4gICAgZWxzZSB7XG4gICAgICBjb25zdCB0aXAgPSB0ZW1wbGF0ZShlKVxuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh0aXApXG5cbiAgICAgIHVwZGF0ZV90aXAodGlwLCBlKVxuXG4gICAgICAkKGUudGFyZ2V0KS5vbignbW91c2VvdXQgRE9NTm9kZVJlbW92ZWQnLCBtb3VzZU91dClcbiAgICAgICQoZS50YXJnZXQpLm9uKCdjbGljaycsIHRvZ2dsZVBpbm5lZClcblxuICAgICAgdGlwX21hcC5zZXQoZS50YXJnZXQsIHsgdGlwLCBlIH0pXG5cbiAgICAgIC8vIHRpcC5hbmltYXRlKFtcbiAgICAgIC8vICAge3RyYW5zZm9ybTogJ3RyYW5zbGF0ZVkoLTVweCknLCBvcGFjaXR5OiAwfSxcbiAgICAgIC8vICAge3RyYW5zZm9ybTogJ3RyYW5zbGF0ZVkoMCknLCBvcGFjaXR5OiAxfVxuICAgICAgLy8gXSwgMTUwKVxuICAgIH1cbiAgfVxuXG4gICQoJ2JvZHknKS5vbignbW91c2Vtb3ZlJywgbW91c2VNb3ZlKVxuXG4gIGhvdGtleXMoJ2VzYycsIF8gPT4gcmVtb3ZlQWxsKCkpXG5cbiAgY29uc3QgaGlkZUFsbCA9ICgpID0+IHtcbiAgICBmb3IgKGNvbnN0IHt0aXB9IG9mIHRpcF9tYXAudmFsdWVzKCkpIHtcbiAgICAgIHRpcC5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnXG4gICAgICAkKHRpcCkub2ZmKCdtb3VzZW91dCBET01Ob2RlUmVtb3ZlZCcsIG1vdXNlT3V0KVxuICAgICAgJCh0aXApLm9mZignY2xpY2snLCB0b2dnbGVQaW5uZWQpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgcmVtb3ZlQWxsID0gKCkgPT4ge1xuICAgIGZvciAoY29uc3Qge3RpcH0gb2YgdGlwX21hcC52YWx1ZXMoKSkge1xuICAgICAgdGlwLnJlbW92ZSgpXG4gICAgICAkKHRpcCkub2ZmKCdtb3VzZW91dCBET01Ob2RlUmVtb3ZlZCcsIG1vdXNlT3V0KVxuICAgICAgJCh0aXApLm9mZignY2xpY2snLCB0b2dnbGVQaW5uZWQpXG4gICAgfVxuICAgIFxuICAgICQoJ1tkYXRhLW1ldGF0aXBdJykuYXR0cignZGF0YS1tZXRhdGlwJywgbnVsbClcblxuICAgIHRpcF9tYXAuY2xlYXIoKVxuICB9XG5cbiAgZm9yIChjb25zdCB7dGlwLGV9IG9mIHRpcF9tYXAudmFsdWVzKCkpIHtcbiAgICB0aXAuc3R5bGUuZGlzcGxheSA9ICdibG9jaydcbiAgICB0aXAuaW5uZXJIVE1MID0gdGVtcGxhdGUoZSkuaW5uZXJIVE1MXG4gICAgdGlwLm9uKCdtb3VzZW91dCcsIG1vdXNlT3V0KVxuICAgIHRpcC5vbignY2xpY2snLCB0b2dnbGVQaW5uZWQpXG4gIH1cblxuICByZXR1cm4gKCkgPT4ge1xuICAgICQoJ2JvZHknKS5vZmYoJ21vdXNlbW92ZScsIG1vdXNlTW92ZSlcbiAgICBob3RrZXlzLnVuYmluZCgnZXNjJylcbiAgICBoaWRlQWxsKClcbiAgfVxufSIsImltcG9ydCAqIGFzIEljb25zIGZyb20gJy4vdG9vbHBhbGxldGUuaWNvbnMnXG5pbXBvcnQgeyBtZXRhS2V5LCBhbHRLZXkgfSBmcm9tICcuLi8uLi91dGlsaXRpZXMvJ1xuXG5leHBvcnQgY29uc3QgVG9vbE1vZGVsID0ge1xuICBnOiB7XG4gICAgdG9vbDogICAgICAgICdndWlkZXMnLFxuICAgIGljb246ICAgICAgICBJY29ucy5ndWlkZXMsXG4gICAgbGFiZWw6ICAgICAgICdHdWlkZXMnLFxuICAgIGRlc2NyaXB0aW9uOiAnVmVyaWZ5IGFsaWdubWVudCAmIGNoZWNrIHlvdXIgZ3JpZCcsXG4gICAgaW5zdHJ1Y3Rpb246ICcnLFxuICB9LFxuICBpOiB7XG4gICAgdG9vbDogICAgICAgICdpbnNwZWN0b3InLFxuICAgIGljb246ICAgICAgICBJY29ucy5pbnNwZWN0b3IsXG4gICAgbGFiZWw6ICAgICAgICdJbnNwZWN0JyxcbiAgICBkZXNjcmlwdGlvbjogJ1BlZWsgaW50byBjb21tb24gJiBjdXJyZW50IHN0eWxlcyBvZiBhbiBlbGVtZW50JyxcbiAgICBpbnN0cnVjdGlvbjogYDxkaXYgdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+UGluIGl0OjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4ke2FsdEtleX0gKyBjbGljazwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5gLFxuICB9LFxuICB4OiB7XG4gICAgdG9vbDogICAgICAgICdhY2Nlc3NpYmlsaXR5JyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMuYWNjZXNzaWJpbGl0eSxcbiAgICBsYWJlbDogICAgICAgJ0FjY2Vzc2liaWxpdHknLFxuICAgIGRlc2NyaXB0aW9uOiAnUGVlayBpbnRvIEExMXkgYXR0cmlidXRlcyAmIGNvbXBsaWFuY2Ugc3RhdHVzJyxcbiAgICBpbnN0cnVjdGlvbjogYDxkaXYgdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+UGluIGl0OjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4ke2FsdEtleX0gKyBjbGljazwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5gLFxuICB9LFxuICB2OiB7XG4gICAgdG9vbDogICAgICAgICdtb3ZlJyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMubW92ZSxcbiAgICBsYWJlbDogICAgICAgJ01vdmUnLFxuICAgIGRlc2NyaXB0aW9uOiAnUHVzaCBlbGVtZW50cyBpbiAmIG91dCBvZiB0aGVpciBjb250YWluZXIsIG9yIHNodWZmbGUgdGhlbSB3aXRoaW4gaXQnLFxuICAgIGluc3RydWN0aW9uOiBgPGRpdiB0YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5MYXRlcmFsOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7il4Ag4pa2PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5PdXQgYW5kIGFib3ZlOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7ilrI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPkRvd24gYW5kIGluOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7ilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+YCxcbiAgfSxcbiAgLy8gcjoge1xuICAvLyAgIHRvb2w6ICAgICAgICAncmVzaXplJyxcbiAgLy8gICBpY29uOiAgICAgICAgSWNvbnMucmVzaXplLFxuICAvLyAgIGxhYmVsOiAgICAgICAnUmVzaXplJyxcbiAgLy8gICBkZXNjcmlwdGlvbjogJydcbiAgLy8gfSxcbiAgbToge1xuICAgIHRvb2w6ICAgICAgICAnbWFyZ2luJyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMubWFyZ2luLFxuICAgIGxhYmVsOiAgICAgICAnTWFyZ2luJyxcbiAgICBkZXNjcmlwdGlvbjogJ0FkZCBvciBzdWJ0cmFjdCBvdXRlciBzcGFjZSBmcm9tIGFueSBvciBhbGwgc2lkZXMgb2YgdGhlIHNlbGVjdGVkIGVsZW1lbnQocyknLFxuICAgIGluc3RydWN0aW9uOiBgPGRpdiB0YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj4rIE1hcmdpbjo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4peAIOKWtiDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj4tIE1hcmdpbjo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+JHthbHRLZXl9ICsg4peAIOKWtiDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5BbGwgU2lkZXM6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiR7bWV0YUtleX0gKyAg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5gLFxuICB9LFxuICBwOiB7XG4gICAgdG9vbDogICAgICAgICdwYWRkaW5nJyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMucGFkZGluZyxcbiAgICBsYWJlbDogICAgICAgJ1BhZGRpbmcnLFxuICAgIGRlc2NyaXB0aW9uOiBgQWRkIG9yIHN1YnRyYWN0IGlubmVyIHNwYWNlIGZyb20gYW55IG9yIGFsbCBzaWRlcyBvZiB0aGUgc2VsZWN0ZWQgZWxlbWVudChzKWAsXG4gICAgaW5zdHJ1Y3Rpb246IGA8ZGl2IHRhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPisgUGFkZGluZzo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4peAIOKWtiDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj4tIFBhZGRpbmc6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiR7YWx0S2V5fSArIOKXgCDilrYg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+QWxsIFNpZGVzOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4ke21ldGFLZXl9ICsgIOKWsiDilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+YFxuICB9LFxuICAvLyBiOiB7XG4gIC8vICAgdG9vbDogICAgICAgICdib3JkZXInLFxuICAvLyAgIGljb246ICAgICAgICBJY29ucy5ib3JkZXIsXG4gIC8vICAgbGFiZWw6ICAgICAgICdCb3JkZXInLFxuICAvLyAgIGRlc2NyaXB0aW9uOiAnJ1xuICAvLyB9LFxuICBhOiB7XG4gICAgdG9vbDogICAgICAgICdhbGlnbicsXG4gICAgaWNvbjogICAgICAgIEljb25zLmFsaWduLFxuICAgIGxhYmVsOiAgICAgICAnRmxleGJveCBBbGlnbicsXG4gICAgZGVzY3JpcHRpb246IGBDcmVhdGUgb3IgbW9kaWZ5IGZsZXhib3ggZGlyZWN0aW9uLCBkaXN0cmlidXRpb24gJiBhbGlnbm1lbnRgLFxuICAgIGluc3RydWN0aW9uOiBgPGRpdiB0YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5BbGlnbm1lbnQ6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKXgCDilrYg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+RGlzdHJpYnV0aW9uOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TaGlmdCArIOKXgCDilrY8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPkRpcmVjdGlvbjo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+JHttZXRhS2V5fSArICDil4Ag4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PmAsXG4gIH0sXG4gIGg6IHtcbiAgICB0b29sOiAgICAgICAgJ2h1ZXNoaWZ0JyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMuaHVlc2hpZnQsXG4gICAgbGFiZWw6ICAgICAgICdIdWUgU2hpZnQnLFxuICAgIGRlc2NyaXB0aW9uOiBgQ2hhbmdlIGZvcmVncm91bmQvYmFja2dyb3VuZCBodWUsIGJyaWdodG5lc3MsIHNhdHVyYXRpb24gJiBvcGFjaXR5YCxcbiAgICBpbnN0cnVjdGlvbjogYDxkaXYgdGFibGU+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+U2F0dXJhdGlvbjo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4peAIOKWtjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+QnJpZ2h0bmVzczo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+SHVlOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4ke21ldGFLZXl9ICsgIOKWsiDilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPk9wYWNpdHk6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiR7bWV0YUtleX0gKyAg4peAIOKWtjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5gLFxuICB9LFxuICBkOiB7XG4gICAgdG9vbDogICAgICAgICdib3hzaGFkb3cnLFxuICAgIGljb246ICAgICAgICBJY29ucy5ib3hzaGFkb3csXG4gICAgbGFiZWw6ICAgICAgICdTaGFkb3cnLFxuICAgIGRlc2NyaXB0aW9uOiBgQ3JlYXRlICYgYWRqdXN0IHBvc2l0aW9uLCBibHVyICYgb3BhY2l0eSBvZiBhIGJveCBzaGFkb3dgLFxuICAgIGluc3RydWN0aW9uOiBgPGRpdiB0YWJsZT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5YL1kgUG9zaXRpb246PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKXgCDilrYg4payIOKWvDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+Qmx1cjo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2hpZnQgKyDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5TcHJlYWQ6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlNoaWZ0ICsg4peAIOKWtjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+T3BhY2l0eTo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+JHttZXRhS2V5fSArIOKXgCDilrY8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+YCxcbiAgfSxcbiAgLy8gdDoge1xuICAvLyAgIHRvb2w6ICAgICAgICAndHJhbnNmb3JtJyxcbiAgLy8gICBpY29uOiAgICAgICAgSWNvbnMudHJhbnNmb3JtLFxuICAvLyAgIGxhYmVsOiAgICAgICAnM0QgVHJhbnNmb3JtJyxcbiAgLy8gICBkZXNjcmlwdGlvbjogJydcbiAgLy8gfSxcbiAgbDoge1xuICAgIHRvb2w6ICAgICAgICAncG9zaXRpb24nLFxuICAgIGljb246ICAgICAgICBJY29ucy5wb3NpdGlvbixcbiAgICBsYWJlbDogICAgICAgJ1Bvc2l0aW9uJyxcbiAgICBkZXNjcmlwdGlvbjogJ01vdmUgc3ZnICh4LHkpIGFuZCBlbGVtZW50cyAodG9wLGxlZnQsYm90dG9tLHJpZ2h0KScsXG4gICAgaW5zdHJ1Y3Rpb246IGA8ZGl2IHRhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPk51ZGdlOjwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7il4Ag4pa2IOKWsiDilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPk1vdmU6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkNsaWNrICYgZHJhZzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5gLFxuICB9LFxuICBmOiB7XG4gICAgdG9vbDogICAgICAgICdmb250JyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMuZm9udCxcbiAgICBsYWJlbDogICAgICAgJ0ZvbnQgU3R5bGVzJyxcbiAgICBkZXNjcmlwdGlvbjogJ0NoYW5nZSBzaXplLCBhbGlnbm1lbnQsIGxlYWRpbmcsIGxldHRlci1zcGFjaW5nLCAmIHdlaWdodCcsXG4gICAgaW5zdHJ1Y3Rpb246IGA8ZGl2IHRhYmxlPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPlNpemU6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKWsiDilrw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxiPkFsaWdubWVudDo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4peAIOKWtjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGI+TGVhZGluZzo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2hpZnQgKyDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5MZXR0ZXItc3BhY2luZzo8L2I+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2hpZnQgKyDil4Ag4pa2PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5XZWlnaHQ6PC9iPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiR7bWV0YUtleX0gKyDilrIg4pa8PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PmAsXG4gIH0sXG4gIGU6IHtcbiAgICB0b29sOiAgICAgICAgJ3RleHQnLFxuICAgIGljb246ICAgICAgICBJY29ucy50ZXh0LFxuICAgIGxhYmVsOiAgICAgICAnRWRpdCBUZXh0JyxcbiAgICBkZXNjcmlwdGlvbjogJ0NoYW5nZSBhbnkgdGV4dCBvbiB0aGUgcGFnZSB3aXRoIGEgPGI+ZG91YmxlIGNsaWNrPC9iPicsXG4gICAgaW5zdHJ1Y3Rpb246ICcnLFxuICB9LFxuICAvLyBjOiB7XG4gIC8vICAgdG9vbDogICAgICAgICdzY3JlZW5zaG90JyxcbiAgLy8gICBpY29uOiAgICAgICAgSWNvbnMuY2FtZXJhLFxuICAvLyAgIGxhYmVsOiAgICAgICAnU2NyZWVuc2hvdCcsXG4gIC8vICAgZGVzY3JpcHRpb246ICdTY3JlZW5zaG90IHNlbGVjdGVkIGVsZW1lbnRzIG9yIHRoZSBlbnRpcmUgcGFnZSdcbiAgLy8gfSxcbiAgczoge1xuICAgIHRvb2w6ICAgICAgICAnc2VhcmNoJyxcbiAgICBpY29uOiAgICAgICAgSWNvbnMuc2VhcmNoLFxuICAgIGxhYmVsOiAgICAgICAnU2VhcmNoJyxcbiAgICBkZXNjcmlwdGlvbjogJ1NlbGVjdCBlbGVtZW50cyBieSBzZWFyY2hpbmcgZm9yIHRoZW0nLFxuICAgIGluc3RydWN0aW9uOiAnJyxcbiAgfSxcbn1cbiIsImltcG9ydCAkICAgICAgICAgIGZyb20gJ2JsaW5nYmxpbmdqcydcbmltcG9ydCBob3RrZXlzICAgIGZyb20gJ2hvdGtleXMtanMnXG5pbXBvcnQgc3R5bGVzICAgICBmcm9tICcuL3Rvb2xwYWxsZXRlLmVsZW1lbnQuY3NzJ1xuXG5pbXBvcnQge1xuICBIYW5kbGVzLCBMYWJlbCwgT3ZlcmxheSwgR3JpZGxpbmVzLFxuICBIb3RrZXlzLCBNZXRhdGlwLCBBbGx5LFxufSBmcm9tICcuLi8nXG5cbmltcG9ydCB7XG4gIFNlbGVjdGFibGUsIE1vdmVhYmxlLCBQYWRkaW5nLCBNYXJnaW4sIEVkaXRUZXh0LCBGb250LFxuICBGbGV4LCBTZWFyY2gsIENvbG9yUGlja2VyLCBCb3hTaGFkb3csIEh1ZVNoaWZ0LCBNZXRhVGlwLFxuICBHdWlkZXMsIFNjcmVlbnNob3QsIFBvc2l0aW9uLCBBY2Nlc3NpYmlsaXR5XG59IGZyb20gJy4uLy4uL2ZlYXR1cmVzLydcblxuaW1wb3J0IHsgVG9vbE1vZGVsIH0gICAgICAgICAgICAgIGZyb20gJy4vbW9kZWwnXG5pbXBvcnQgKiBhcyBJY29ucyAgICAgICAgICAgICAgICAgZnJvbSAnLi90b29scGFsbGV0ZS5pY29ucydcbmltcG9ydCB7IHByb3ZpZGVTZWxlY3RvckVuZ2luZSB9ICBmcm9tICcuLi8uLi9mZWF0dXJlcy9zZWFyY2gnXG5pbXBvcnQgeyBtZXRhS2V5IH0gICAgICAgICAgICAgICAgZnJvbSAnLi4vLi4vdXRpbGl0aWVzLydcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgVG9vbFBhbGxldGUgZXh0ZW5kcyBIVE1MRWxlbWVudCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKClcblxuICAgIHRoaXMudG9vbGJhcl9tb2RlbCAgPSBUb29sTW9kZWxcbiAgICB0aGlzLl90dXRzQmFzZVVSTCAgID0gJ3R1dHMnIC8vIGNhbiBiZSBzZXQgYnkgY29udGVudCBzY3JpcHRcbiAgICB0aGlzLiRzaGFkb3cgICAgICAgID0gdGhpcy5hdHRhY2hTaGFkb3coe21vZGU6ICdvcGVuJ30pXG4gIH1cblxuICBjb25uZWN0ZWRDYWxsYmFjaygpIHtcbiAgICBpZiAoIXRoaXMuJHNoYWRvdy5pbm5lckhUTUwpXG4gICAgICB0aGlzLnNldHVwKClcblxuICAgIHRoaXMuc2VsZWN0b3JFbmdpbmUgPSBTZWxlY3RhYmxlKClcbiAgICB0aGlzLmNvbG9yUGlja2VyICAgID0gQ29sb3JQaWNrZXIodGhpcy4kc2hhZG93LCB0aGlzLnNlbGVjdG9yRW5naW5lKVxuICAgIHByb3ZpZGVTZWxlY3RvckVuZ2luZSh0aGlzLnNlbGVjdG9yRW5naW5lKVxuICB9XG5cbiAgZGlzY29ubmVjdGVkQ2FsbGJhY2soKSB7XG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUoKVxuICAgIHRoaXMuc2VsZWN0b3JFbmdpbmUuZGlzY29ubmVjdCgpXG4gICAgaG90a2V5cy51bmJpbmQoXG4gICAgICBPYmplY3Qua2V5cyh0aGlzLnRvb2xiYXJfbW9kZWwpLnJlZHVjZSgoZXZlbnRzLCBrZXkpID0+XG4gICAgICAgIGV2ZW50cyArPSAnLCcgKyBrZXksICcnKSlcbiAgICBob3RrZXlzLnVuYmluZChgJHttZXRhS2V5fSsvYClcbiAgfVxuXG4gIHNldHVwKCkge1xuICAgIHRoaXMuJHNoYWRvdy5pbm5lckhUTUwgPSB0aGlzLnJlbmRlcigpXG5cbiAgICAkKCdsaVtkYXRhLXRvb2xdJywgdGhpcy4kc2hhZG93KS5vbignY2xpY2snLCBlID0+XG4gICAgICB0aGlzLnRvb2xTZWxlY3RlZChlLmN1cnJlbnRUYXJnZXQpICYmIGUuc3RvcFByb3BhZ2F0aW9uKCkpXG5cbiAgICBPYmplY3QuZW50cmllcyh0aGlzLnRvb2xiYXJfbW9kZWwpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT5cbiAgICAgIGhvdGtleXMoa2V5LCBlID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIHRoaXMudG9vbFNlbGVjdGVkKFxuICAgICAgICAgICQoYFtkYXRhLXRvb2w9XCIke3ZhbHVlLnRvb2x9XCJdYCwgdGhpcy4kc2hhZG93KVswXVxuICAgICAgICApXG4gICAgICB9KVxuICAgIClcblxuICAgIGhvdGtleXMoYCR7bWV0YUtleX0rLywke21ldGFLZXl9Ky5gLCBlID0+XG4gICAgICB0aGlzLiRzaGFkb3cuaG9zdC5zdHlsZS5kaXNwbGF5ID1cbiAgICAgICAgdGhpcy4kc2hhZG93Lmhvc3Quc3R5bGUuZGlzcGxheSA9PT0gJ25vbmUnXG4gICAgICAgICAgPyAnYmxvY2snXG4gICAgICAgICAgOiAnbm9uZScpXG5cbiAgICB0aGlzLnRvb2xTZWxlY3RlZCgkKCdbZGF0YS10b29sPVwiZ3VpZGVzXCJdJywgdGhpcy4kc2hhZG93KVswXSlcbiAgfVxuXG4gIHRvb2xTZWxlY3RlZChlbCkge1xuICAgIGlmICh0eXBlb2YgZWwgPT09ICdzdHJpbmcnKVxuICAgICAgZWwgPSAkKGBbZGF0YS10b29sPVwiJHtlbH1cIl1gLCB0aGlzLiRzaGFkb3cpWzBdXG5cbiAgICBpZiAodGhpcy5hY3RpdmVfdG9vbCAmJiB0aGlzLmFjdGl2ZV90b29sLmRhdGFzZXQudG9vbCA9PT0gZWwuZGF0YXNldC50b29sKSByZXR1cm5cblxuICAgIGlmICh0aGlzLmFjdGl2ZV90b29sKSB7XG4gICAgICB0aGlzLmFjdGl2ZV90b29sLmF0dHIoJ2RhdGEtYWN0aXZlJywgbnVsbClcbiAgICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlKClcbiAgICB9XG5cbiAgICBlbC5hdHRyKCdkYXRhLWFjdGl2ZScsIHRydWUpXG4gICAgdGhpcy5hY3RpdmVfdG9vbCA9IGVsXG4gICAgdGhpc1tlbC5kYXRhc2V0LnRvb2xdKClcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gYFxuICAgICAgJHt0aGlzLnN0eWxlcygpfVxuICAgICAgPHBiLWhvdGtleXM+PC9wYi1ob3RrZXlzPlxuICAgICAgPG9sPlxuICAgICAgICAke09iamVjdC5lbnRyaWVzKHRoaXMudG9vbGJhcl9tb2RlbCkucmVkdWNlKChsaXN0LCBba2V5LCB0b29sXSkgPT4gYFxuICAgICAgICAgICR7bGlzdH1cbiAgICAgICAgICA8bGkgYXJpYS1sYWJlbD1cIiR7dG9vbC5sYWJlbH0gVG9vbFwiIGFyaWEtZGVzY3JpcHRpb249XCIke3Rvb2wuZGVzY3JpcHRpb259XCIgYXJpYS1ob3RrZXk9XCIke2tleX1cIiBkYXRhLXRvb2w9XCIke3Rvb2wudG9vbH1cIiBkYXRhLWFjdGl2ZT1cIiR7a2V5ID09ICdnJ31cIj5cbiAgICAgICAgICAgICR7dG9vbC5pY29ufVxuICAgICAgICAgICAgJHt0aGlzLmRlbW9UaXAoe2tleSwgLi4udG9vbH0pfVxuICAgICAgICAgIDwvbGk+XG4gICAgICAgIGAsJycpfVxuICAgICAgPC9vbD5cbiAgICAgIDxvbCBjb2xvcnM+XG4gICAgICAgIDxsaSBzdHlsZT1cImRpc3BsYXk6IG5vbmU7XCIgY2xhc3M9XCJjb2xvclwiIGlkPVwiZm9yZWdyb3VuZFwiIGFyaWEtbGFiZWw9XCJUZXh0XCIgYXJpYS1kZXNjcmlwdGlvbj1cIkNoYW5nZSB0aGUgdGV4dCBjb2xvclwiPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY29sb3JcIiB2YWx1ZT1cIlwiPlxuICAgICAgICAgICR7SWNvbnMuY29sb3JfdGV4dH1cbiAgICAgICAgPC9saT5cbiAgICAgICAgPGxpIHN0eWxlPVwiZGlzcGxheTogbm9uZTtcIiBjbGFzcz1cImNvbG9yXCIgaWQ9XCJiYWNrZ3JvdW5kXCIgYXJpYS1sYWJlbD1cIkJhY2tncm91bmQgb3IgRmlsbFwiIGFyaWEtZGVzY3JpcHRpb249XCJDaGFuZ2UgdGhlIGJhY2tncm91bmQgY29sb3Igb3IgZmlsbCBvZiBzdmdcIj5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cImNvbG9yXCIgdmFsdWU9XCJcIj5cbiAgICAgICAgICAke0ljb25zLmNvbG9yX2JhY2tncm91bmR9XG4gICAgICAgIDwvbGk+XG4gICAgICAgIDxsaSBzdHlsZT1cImRpc3BsYXk6IG5vbmU7XCIgY2xhc3M9XCJjb2xvclwiIGlkPVwiYm9yZGVyXCIgYXJpYS1sYWJlbD1cIkJvcmRlciBvciBTdHJva2VcIiBhcmlhLWRlc2NyaXB0aW9uPVwiQ2hhbmdlIHRoZSBib3JkZXIgY29sb3Igb3Igc3Ryb2tlIG9mIHN2Z1wiPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY29sb3JcIiB2YWx1ZT1cIlwiPlxuICAgICAgICAgICR7SWNvbnMuY29sb3JfYm9yZGVyfVxuICAgICAgICA8L2xpPlxuICAgICAgPC9vbD5cbiAgICBgXG4gIH1cblxuICBzdHlsZXMoKSB7XG4gICAgcmV0dXJuIGBcbiAgICAgIDxzdHlsZT5cbiAgICAgICAgJHtzdHlsZXN9XG4gICAgICA8L3N0eWxlPlxuICAgIGBcbiAgfVxuXG4gIGRlbW9UaXAoe2tleSwgdG9vbCwgbGFiZWwsIGRlc2NyaXB0aW9uLCBpbnN0cnVjdGlvbn0pIHtcbiAgICByZXR1cm4gYFxuICAgICAgPGFzaWRlICR7dG9vbH0+XG4gICAgICAgIDxmaWd1cmU+XG4gICAgICAgICAgPGltZyBzcmM9XCIke3RoaXMuX3R1dHNCYXNlVVJMfS8ke3Rvb2x9LmdpZlwiIGFsdD1cIiR7ZGVzY3JpcHRpb259XCIgLz5cbiAgICAgICAgICA8ZmlnY2FwdGlvbj5cbiAgICAgICAgICAgIDxoMj5cbiAgICAgICAgICAgICAgJHtsYWJlbH1cbiAgICAgICAgICAgICAgPHNwYW4gaG90a2V5PiR7a2V5fTwvc3Bhbj5cbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICA8cD4ke2Rlc2NyaXB0aW9ufTwvcD5cbiAgICAgICAgICAgICR7aW5zdHJ1Y3Rpb259XG4gICAgICAgICAgPC9maWdjYXB0aW9uPlxuICAgICAgICA8L2ZpZ3VyZT5cbiAgICAgIDwvYXNpZGU+XG4gICAgYFxuICB9XG5cbiAgbW92ZSgpIHtcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9IE1vdmVhYmxlKCdbZGF0YS1zZWxlY3RlZD10cnVlXScpXG4gIH1cblxuICBtYXJnaW4oKSB7XG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSBNYXJnaW4oJ1tkYXRhLXNlbGVjdGVkPXRydWVdJylcbiAgfVxuXG4gIHBhZGRpbmcoKSB7XG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSBQYWRkaW5nKCdbZGF0YS1zZWxlY3RlZD10cnVlXScpXG4gIH1cblxuICBmb250KCkge1xuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gRm9udCgnW2RhdGEtc2VsZWN0ZWQ9dHJ1ZV0nKVxuICB9XG5cbiAgdGV4dCgpIHtcbiAgICB0aGlzLnNlbGVjdG9yRW5naW5lLm9uU2VsZWN0ZWRVcGRhdGUoRWRpdFRleHQpXG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSAoKSA9PlxuICAgICAgdGhpcy5zZWxlY3RvckVuZ2luZS5yZW1vdmVTZWxlY3RlZENhbGxiYWNrKEVkaXRUZXh0KVxuICB9XG5cbiAgYWxpZ24oKSB7XG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSBGbGV4KCdbZGF0YS1zZWxlY3RlZD10cnVlXScpXG4gIH1cblxuICBzZWFyY2goKSB7XG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSBTZWFyY2goJCgnW2RhdGEtdG9vbD1cInNlYXJjaFwiXScsIHRoaXMuJHNoYWRvdykpXG4gIH1cblxuICBib3hzaGFkb3coKSB7XG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSBCb3hTaGFkb3coJ1tkYXRhLXNlbGVjdGVkPXRydWVdJylcbiAgfVxuXG4gIGh1ZXNoaWZ0KCkge1xuICAgIGxldCBmZWF0dXJlID0gSHVlU2hpZnQodGhpcy5jb2xvclBpY2tlcilcbiAgICB0aGlzLnNlbGVjdG9yRW5naW5lLm9uU2VsZWN0ZWRVcGRhdGUoZmVhdHVyZS5vbk5vZGVzU2VsZWN0ZWQpXG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSAoKSA9PiB7XG4gICAgICB0aGlzLnNlbGVjdG9yRW5naW5lLnJlbW92ZVNlbGVjdGVkQ2FsbGJhY2soZmVhdHVyZS5vbk5vZGVzU2VsZWN0ZWQpXG4gICAgICBmZWF0dXJlLmRpc2Nvbm5lY3QoKVxuICAgIH1cbiAgfVxuXG4gIGluc3BlY3RvcigpIHtcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9IE1ldGFUaXAodGhpcy5zZWxlY3RvckVuZ2luZSlcbiAgfVxuXG4gIGFjY2Vzc2liaWxpdHkoKSB7XG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSBBY2Nlc3NpYmlsaXR5KClcbiAgfVxuXG4gIGd1aWRlcygpIHtcbiAgICB0aGlzLmRlYWN0aXZhdGVfZmVhdHVyZSA9IEd1aWRlcygpXG4gIH1cblxuICBzY3JlZW5zaG90KCkge1xuICAgIHRoaXMuZGVhY3RpdmF0ZV9mZWF0dXJlID0gU2NyZWVuc2hvdCgpXG4gIH1cblxuICBwb3NpdGlvbigpIHtcbiAgICBsZXQgZmVhdHVyZSA9IFBvc2l0aW9uKClcbiAgICB0aGlzLnNlbGVjdG9yRW5naW5lLm9uU2VsZWN0ZWRVcGRhdGUoZmVhdHVyZS5vbk5vZGVzU2VsZWN0ZWQpXG4gICAgdGhpcy5kZWFjdGl2YXRlX2ZlYXR1cmUgPSAoKSA9PiB7XG4gICAgICB0aGlzLnNlbGVjdG9yRW5naW5lLnJlbW92ZVNlbGVjdGVkQ2FsbGJhY2soZmVhdHVyZS5vbk5vZGVzU2VsZWN0ZWQpXG4gICAgICBmZWF0dXJlLmRpc2Nvbm5lY3QoKVxuICAgIH1cbiAgfVxuXG4gIGdldCBhY3RpdmVUb29sKCkge1xuICAgIHJldHVybiB0aGlzLmFjdGl2ZV90b29sLmRhdGFzZXQudG9vbFxuICB9XG5cbiAgc2V0IHR1dHNCYXNlVVJMKHVybCkge1xuICAgIHRoaXMuX3R1dHNCYXNlVVJMID0gdXJsXG4gICAgdGhpcy5zZXR1cCgpXG4gIH1cbn1cblxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCd0b29sLXBhbGxldGUnLCBUb29sUGFsbGV0ZSlcbiIsImltcG9ydCBUb29sUGFsbGV0ZSBmcm9tICcuL2NvbXBvbmVudHMvdG9vbC1wYWxsZXRlL3Rvb2xwYWxsZXRlLmVsZW1lbnQnXG5pbXBvcnQgeyBtZXRhS2V5IH0gZnJvbSAnLi91dGlsaXRpZXMnXG5cbmlmICgnb250b3VjaHN0YXJ0JyBpbiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdtb2JpbGUtaW5mbycpLnN0eWxlLmRpc3BsYXkgPSAnJ1xuXG5pZiAobWV0YUtleSA9PT0gJ2N0cmwnKVxuICBbLi4uZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgna2JkJyldXG4gICAgLmZvckVhY2gobm9kZSA9PiB7XG4gICAgICBub2RlLnRleHRDb250ZW50ID0gbm9kZS50ZXh0Q29udGVudC5yZXBsYWNlKCdjbWQnLCdjdHJsJylcbiAgICAgIG5vZGUudGV4dENvbnRlbnQgPSBub2RlLnRleHRDb250ZW50LnJlcGxhY2UoJ29wdCcsJ2FsdCcpXG4gICAgfSlcbiJdLCJuYW1lcyI6WyJzdHlsZXMiLCJob3RrZXlzIiwiaWNvbiIsImtleV9ldmVudHMiLCJzZWFyY2giLCJjb21tYW5kX2V2ZW50cyIsInN0b3BCdWJibGluZyIsImhfYWxpZ25PcHRpb25zIiwidl9hbGlnbk9wdGlvbnMiLCJ0aXBfbWFwIiwiSWNvbnMuZ3VpZGVzIiwiSWNvbnMuaW5zcGVjdG9yIiwiSWNvbnMuYWNjZXNzaWJpbGl0eSIsIkljb25zLm1vdmUiLCJJY29ucy5tYXJnaW4iLCJJY29ucy5wYWRkaW5nIiwiSWNvbnMuYWxpZ24iLCJJY29ucy5odWVzaGlmdCIsIkljb25zLmJveHNoYWRvdyIsIkljb25zLnBvc2l0aW9uIiwiSWNvbnMuZm9udCIsIkljb25zLnRleHQiLCJJY29ucy5zZWFyY2giLCJJY29ucy5jb2xvcl90ZXh0IiwiSWNvbnMuY29sb3JfYmFja2dyb3VuZCIsIkljb25zLmNvbG9yX2JvcmRlciJdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxLQUFLLEdBQUc7RUFDWixFQUFFLEVBQUUsU0FBUyxLQUFLLEVBQUUsRUFBRSxFQUFFO0lBQ3RCLEtBQUs7T0FDRixLQUFLLENBQUMsR0FBRyxDQUFDO09BQ1YsT0FBTyxDQUFDLElBQUk7UUFDWCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxFQUFDO0lBQ3BDLE9BQU8sSUFBSTtHQUNaO0VBQ0QsR0FBRyxFQUFFLFNBQVMsS0FBSyxFQUFFLEVBQUUsRUFBRTtJQUN2QixLQUFLO09BQ0YsS0FBSyxDQUFDLEdBQUcsQ0FBQztPQUNWLE9BQU8sQ0FBQyxJQUFJO1FBQ1gsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsRUFBQztJQUN2QyxPQUFPLElBQUk7R0FDWjtFQUNELElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxHQUFHLEVBQUU7SUFDeEIsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUM7O0lBRXJELEdBQUcsSUFBSSxJQUFJO1FBQ1AsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUM7UUFDMUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsR0FBRyxJQUFJLEVBQUUsRUFBQzs7SUFFdEMsT0FBTyxJQUFJO0dBQ1o7RUFDRjs7QUFFRCxBQUFlLFNBQVMsQ0FBQyxDQUFDLEtBQUssRUFBRSxRQUFRLEdBQUcsUUFBUSxFQUFFO0VBQ3BELElBQUksTUFBTSxHQUFHLEtBQUssWUFBWSxRQUFRLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7TUFDMUQsS0FBSztNQUNMLEtBQUssWUFBWSxXQUFXLElBQUksS0FBSyxZQUFZLFVBQVU7UUFDekQsQ0FBQyxLQUFLLENBQUM7UUFDUCxRQUFRLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxFQUFDOztFQUV0QyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxNQUFNLEdBQUcsR0FBRTs7RUFFL0IsT0FBTyxNQUFNLENBQUMsTUFBTTtJQUNsQixDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqRDtNQUNFLEVBQUUsRUFBRSxTQUFTLEtBQUssRUFBRSxFQUFFLEVBQUU7UUFDdEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLEVBQUM7UUFDdEMsT0FBTyxJQUFJO09BQ1o7TUFDRCxHQUFHLEVBQUUsU0FBUyxLQUFLLEVBQUUsRUFBRSxFQUFFO1FBQ3ZCLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxFQUFDO1FBQ3ZDLE9BQU8sSUFBSTtPQUNaO01BQ0QsSUFBSSxFQUFFLFNBQVMsS0FBSyxFQUFFLEdBQUcsRUFBRTtRQUN6QixJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsSUFBSSxHQUFHLEtBQUssU0FBUztVQUNoRCxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDOzthQUV2QixJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVE7VUFDaEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHO1lBQ2QsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7ZUFDbEIsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDO2dCQUNsQixHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUFDOzthQUV2QixJQUFJLE9BQU8sS0FBSyxJQUFJLFFBQVEsS0FBSyxHQUFHLElBQUksR0FBRyxJQUFJLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxDQUFDO1VBQ3BFLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxFQUFDOztRQUUzQyxPQUFPLElBQUk7T0FDWjtLQUNGO0dBQ0Y7OztBQzlESDs7Ozs7Ozs7OztBQVVBLElBQUksSUFBSSxHQUFHLE9BQU8sU0FBUyxLQUFLLFdBQVcsR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDOzs7QUFHL0csU0FBUyxRQUFRLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUU7RUFDdkMsSUFBSSxNQUFNLENBQUMsZ0JBQWdCLEVBQUU7SUFDM0IsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7R0FDL0MsTUFBTSxJQUFJLE1BQU0sQ0FBQyxXQUFXLEVBQUU7SUFDN0IsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsS0FBSyxFQUFFLFlBQVk7TUFDM0MsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztLQUN0QixDQUFDLENBQUM7R0FDSjtDQUNGOzs7QUFHRCxTQUFTLE9BQU8sQ0FBQyxRQUFRLEVBQUUsR0FBRyxFQUFFO0VBQzlCLElBQUksSUFBSSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFDeEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7SUFDcEMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztHQUMzQyxPQUFPLElBQUksQ0FBQztDQUNkOzs7QUFHRCxTQUFTLE9BQU8sQ0FBQyxHQUFHLEVBQUU7RUFDcEIsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLEdBQUcsRUFBRSxDQUFDOztFQUVuQixHQUFHLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7RUFDN0IsSUFBSSxJQUFJLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUMxQixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDOzs7RUFHakMsT0FBTyxLQUFLLElBQUksQ0FBQyxHQUFHO0lBQ2xCLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDO0lBQ3ZCLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3RCLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0dBQzlCOztFQUVELE9BQU8sSUFBSSxDQUFDO0NBQ2I7OztBQUdELFNBQVMsWUFBWSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUU7RUFDNUIsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUMsTUFBTSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7RUFDNUMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUMsTUFBTSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7RUFDNUMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDOztFQUVuQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtJQUNwQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsT0FBTyxHQUFHLEtBQUssQ0FBQztHQUNuRDtFQUNELE9BQU8sT0FBTyxDQUFDO0NBQ2hCOztBQUVELElBQUksT0FBTyxHQUFHO0VBQ1osU0FBUyxFQUFFLENBQUM7RUFDWixHQUFHLEVBQUUsQ0FBQztFQUNOLEtBQUssRUFBRSxFQUFFO0VBQ1QsS0FBSyxFQUFFLEVBQUU7RUFDVCxNQUFNLEVBQUUsRUFBRTtFQUNWLEdBQUcsRUFBRSxFQUFFO0VBQ1AsTUFBTSxFQUFFLEVBQUU7RUFDVixLQUFLLEVBQUUsRUFBRTtFQUNULElBQUksRUFBRSxFQUFFO0VBQ1IsRUFBRSxFQUFFLEVBQUU7RUFDTixLQUFLLEVBQUUsRUFBRTtFQUNULElBQUksRUFBRSxFQUFFO0VBQ1IsR0FBRyxFQUFFLEVBQUU7RUFDUCxNQUFNLEVBQUUsRUFBRTtFQUNWLEdBQUcsRUFBRSxFQUFFO0VBQ1AsTUFBTSxFQUFFLEVBQUU7RUFDVixJQUFJLEVBQUUsRUFBRTtFQUNSLEdBQUcsRUFBRSxFQUFFO0VBQ1AsTUFBTSxFQUFFLEVBQUU7RUFDVixRQUFRLEVBQUUsRUFBRTtFQUNaLFFBQVEsRUFBRSxFQUFFO0VBQ1osR0FBRyxFQUFFLEVBQUU7RUFDUCxHQUFHLEVBQUUsR0FBRztFQUNSLEdBQUcsRUFBRSxHQUFHO0VBQ1IsR0FBRyxFQUFFLEdBQUc7RUFDUixHQUFHLEVBQUUsR0FBRztFQUNSLEdBQUcsRUFBRSxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUc7RUFDckIsR0FBRyxFQUFFLElBQUksR0FBRyxFQUFFLEdBQUcsR0FBRztFQUNwQixHQUFHLEVBQUUsSUFBSSxHQUFHLEVBQUUsR0FBRyxHQUFHO0VBQ3BCLElBQUksRUFBRSxHQUFHO0VBQ1QsR0FBRyxFQUFFLEdBQUc7RUFDUixHQUFHLEVBQUUsR0FBRztFQUNSLElBQUksRUFBRSxHQUFHO0NBQ1YsQ0FBQzs7QUFFRixJQUFJLFNBQVMsR0FBRztFQUNkLEdBQUcsRUFBRSxFQUFFO0VBQ1AsS0FBSyxFQUFFLEVBQUU7RUFDVCxHQUFHLEVBQUUsRUFBRTtFQUNQLEdBQUcsRUFBRSxFQUFFO0VBQ1AsTUFBTSxFQUFFLEVBQUU7RUFDVixHQUFHLEVBQUUsRUFBRTtFQUNQLElBQUksRUFBRSxFQUFFO0VBQ1IsT0FBTyxFQUFFLEVBQUU7RUFDWCxHQUFHLEVBQUUsSUFBSSxHQUFHLEdBQUcsR0FBRyxFQUFFO0VBQ3BCLEdBQUcsRUFBRSxJQUFJLEdBQUcsR0FBRyxHQUFHLEVBQUU7RUFDcEIsT0FBTyxFQUFFLElBQUksR0FBRyxHQUFHLEdBQUcsRUFBRTtDQUN6QixDQUFDO0FBQ0YsSUFBSSxTQUFTLEdBQUcsRUFBRSxDQUFDO0FBQ25CLElBQUksV0FBVyxHQUFHO0VBQ2hCLEVBQUUsRUFBRSxVQUFVO0VBQ2QsRUFBRSxFQUFFLFFBQVE7RUFDWixFQUFFLEVBQUUsU0FBUztDQUNkLENBQUM7QUFDRixJQUFJLEtBQUssR0FBRyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUM7QUFDaEQsSUFBSSxTQUFTLEdBQUcsRUFBRSxDQUFDOzs7QUFHbkIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRTtFQUMzQixPQUFPLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUM7Q0FDNUI7OztBQUdELFdBQVcsQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQztBQUN6QyxLQUFLLENBQUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUM7O0FBRS9CLElBQUksTUFBTSxHQUFHLEtBQUssQ0FBQztBQUNuQixJQUFJLGFBQWEsR0FBRyxLQUFLLENBQUM7OztBQUcxQixJQUFJLElBQUksR0FBRyxTQUFTLElBQUksQ0FBQyxDQUFDLEVBQUU7RUFDMUIsT0FBTyxPQUFPLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztDQUNsRSxDQUFDOzs7QUFHRixTQUFTLFFBQVEsQ0FBQyxLQUFLLEVBQUU7RUFDdkIsTUFBTSxHQUFHLEtBQUssSUFBSSxLQUFLLENBQUM7Q0FDekI7O0FBRUQsU0FBUyxRQUFRLEdBQUc7RUFDbEIsT0FBTyxNQUFNLElBQUksS0FBSyxDQUFDO0NBQ3hCOztBQUVELFNBQVMsa0JBQWtCLEdBQUc7RUFDNUIsT0FBTyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0NBQzNCOzs7QUFHRCxTQUFTLE1BQU0sQ0FBQyxLQUFLLEVBQUU7RUFDckIsSUFBSSxPQUFPLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7O0VBRS9ELE9BQU8sRUFBRSxPQUFPLEtBQUssT0FBTyxJQUFJLE9BQU8sS0FBSyxRQUFRLElBQUksT0FBTyxLQUFLLFVBQVUsQ0FBQyxDQUFDO0NBQ2pGOzs7QUFHRCxTQUFTLFNBQVMsQ0FBQyxPQUFPLEVBQUU7RUFDMUIsSUFBSSxPQUFPLE9BQU8sS0FBSyxRQUFRLEVBQUU7SUFDL0IsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztHQUN6QjtFQUNELE9BQU8sU0FBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztDQUMxQzs7O0FBR0QsU0FBUyxXQUFXLENBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRTtFQUNwQyxJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsQ0FBQztFQUN0QixJQUFJLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQzs7O0VBR2YsSUFBSSxDQUFDLEtBQUssRUFBRSxLQUFLLEdBQUcsUUFBUSxFQUFFLENBQUM7O0VBRS9CLEtBQUssSUFBSSxHQUFHLElBQUksU0FBUyxFQUFFO0lBQ3pCLElBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsRUFBRTtNQUN4RCxRQUFRLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO01BQzFCLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sR0FBRztRQUNoQyxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssS0FBSyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7T0FDakU7S0FDRjtHQUNGOzs7RUFHRCxJQUFJLFFBQVEsRUFBRSxLQUFLLEtBQUssRUFBRSxRQUFRLENBQUMsUUFBUSxJQUFJLEtBQUssQ0FBQyxDQUFDO0NBQ3ZEOzs7QUFHRCxTQUFTLGFBQWEsQ0FBQyxLQUFLLEVBQUU7RUFDNUIsSUFBSSxHQUFHLEdBQUcsS0FBSyxDQUFDLE9BQU8sSUFBSSxLQUFLLENBQUMsS0FBSyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUM7RUFDekQsSUFBSSxDQUFDLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O0VBRy9CLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzs7O0VBR25DLElBQUksR0FBRyxLQUFLLEVBQUUsSUFBSSxHQUFHLEtBQUssR0FBRyxFQUFFLEdBQUcsR0FBRyxFQUFFLENBQUM7RUFDeEMsSUFBSSxHQUFHLElBQUksS0FBSyxFQUFFO0lBQ2hCLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUM7OztJQUduQixLQUFLLElBQUksQ0FBQyxJQUFJLFNBQVMsRUFBRTtNQUN2QixJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQztLQUM5QztHQUNGO0NBQ0Y7OztBQUdELFNBQVMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUU7RUFDMUIsSUFBSSxZQUFZLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQ2hDLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxDQUFDO0VBQ2xCLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztFQUNkLElBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxDQUFDOztFQUVqQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTs7SUFFNUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7OztJQUdsQyxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLElBQUksR0FBRyxPQUFPLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDOzs7SUFHckQsR0FBRyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQzVCLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7OztJQUdwQyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssR0FBRyxRQUFRLEVBQUUsQ0FBQzs7O0lBRy9CLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTzs7OztJQUk1QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtNQUM5QyxHQUFHLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztNQUV4QixJQUFJLEdBQUcsQ0FBQyxLQUFLLEtBQUssS0FBSyxJQUFJLFlBQVksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxFQUFFO1FBQ3ZELFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7T0FDeEI7S0FDRjtHQUNGO0NBQ0Y7OztBQUdELFNBQVMsWUFBWSxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFO0VBQzNDLElBQUksY0FBYyxHQUFHLEtBQUssQ0FBQyxDQUFDOzs7RUFHNUIsSUFBSSxPQUFPLENBQUMsS0FBSyxLQUFLLEtBQUssSUFBSSxPQUFPLENBQUMsS0FBSyxLQUFLLEtBQUssRUFBRTs7SUFFdEQsY0FBYyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzs7SUFFekMsS0FBSyxJQUFJLENBQUMsSUFBSSxLQUFLLEVBQUU7TUFDbkIsSUFBSSxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFO1FBQ2xELElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxjQUFjLEdBQUcsS0FBSyxDQUFDO09BQ3ZIO0tBQ0Y7OztJQUdELElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFJLGNBQWMsSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLEdBQUcsRUFBRTtNQUNuSSxJQUFJLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLLEtBQUssRUFBRTtRQUM1QyxJQUFJLEtBQUssQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDLEtBQUssS0FBSyxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7UUFDaEYsSUFBSSxLQUFLLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUNuRCxJQUFJLEtBQUssQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7T0FDbkQ7S0FDRjtHQUNGO0NBQ0Y7OztBQUdELFNBQVMsUUFBUSxDQUFDLEtBQUssRUFBRTtFQUN2QixJQUFJLFFBQVEsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDOUIsSUFBSSxHQUFHLEdBQUcsS0FBSyxDQUFDLE9BQU8sSUFBSSxLQUFLLENBQUMsS0FBSyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUM7OztFQUd6RCxJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzs7OztFQUl2RCxJQUFJLEdBQUcsS0FBSyxFQUFFLElBQUksR0FBRyxLQUFLLEdBQUcsRUFBRSxHQUFHLEdBQUcsRUFBRSxDQUFDOztFQUV4QyxJQUFJLEdBQUcsSUFBSSxLQUFLLEVBQUU7SUFDaEIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQzs7O0lBR2xCLEtBQUssSUFBSSxDQUFDLElBQUksU0FBUyxFQUFFO01BQ3ZCLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDO0tBQzdDOztJQUVELElBQUksQ0FBQyxRQUFRLEVBQUUsT0FBTztHQUN2Qjs7O0VBR0QsS0FBSyxJQUFJLENBQUMsSUFBSSxLQUFLLEVBQUU7SUFDbkIsSUFBSSxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFO01BQ2xELEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDbEM7R0FDRjs7O0VBR0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFBRSxPQUFPOzs7RUFHOUMsSUFBSSxLQUFLLEdBQUcsUUFBUSxFQUFFLENBQUM7OztFQUd2QixJQUFJLFFBQVEsRUFBRTtJQUNaLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO01BQ3hDLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxLQUFLLEVBQUUsWUFBWSxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDMUU7R0FDRjs7RUFFRCxJQUFJLEVBQUUsR0FBRyxJQUFJLFNBQVMsQ0FBQyxFQUFFLE9BQU87O0VBRWhDLEtBQUssSUFBSSxFQUFFLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsRUFBRSxFQUFFOztJQUVqRCxZQUFZLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztHQUNoRDtDQUNGOztBQUVELFNBQVMsT0FBTyxDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFO0VBQ3BDLElBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUN4QixJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7RUFDZCxJQUFJLEtBQUssR0FBRyxLQUFLLENBQUM7RUFDbEIsSUFBSSxPQUFPLEdBQUcsUUFBUSxDQUFDO0VBQ3ZCLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O0VBR1YsSUFBSSxNQUFNLEtBQUssU0FBUyxJQUFJLE9BQU8sTUFBTSxLQUFLLFVBQVUsRUFBRTtJQUN4RCxNQUFNLEdBQUcsTUFBTSxDQUFDO0dBQ2pCOztFQUVELElBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLGlCQUFpQixFQUFFO0lBQ2hFLElBQUksTUFBTSxDQUFDLEtBQUssRUFBRSxLQUFLLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQztJQUN2QyxJQUFJLE1BQU0sQ0FBQyxPQUFPLEVBQUUsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUM7R0FDOUM7O0VBRUQsSUFBSSxPQUFPLE1BQU0sS0FBSyxRQUFRLEVBQUUsS0FBSyxHQUFHLE1BQU0sQ0FBQzs7O0VBRy9DLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7SUFDM0IsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDekIsSUFBSSxHQUFHLEVBQUUsQ0FBQzs7O0lBR1YsSUFBSSxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxJQUFJLEdBQUcsT0FBTyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQzs7O0lBR25ELEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztJQUMxQixHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7SUFHcEMsSUFBSSxFQUFFLEdBQUcsSUFBSSxTQUFTLENBQUMsRUFBRSxTQUFTLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDOztJQUU3QyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO01BQ2xCLEtBQUssRUFBRSxLQUFLO01BQ1osSUFBSSxFQUFFLElBQUk7TUFDVixRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztNQUNqQixNQUFNLEVBQUUsTUFBTTtNQUNkLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0tBQ2IsQ0FBQyxDQUFDO0dBQ0o7O0VBRUQsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksQ0FBQyxhQUFhLEVBQUU7SUFDcEQsYUFBYSxHQUFHLElBQUksQ0FBQztJQUNyQixRQUFRLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxVQUFVLENBQUMsRUFBRTtNQUN4QyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDYixDQUFDLENBQUM7SUFDSCxRQUFRLENBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxVQUFVLENBQUMsRUFBRTtNQUN0QyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDbEIsQ0FBQyxDQUFDO0dBQ0o7Q0FDRjs7QUFFRCxJQUFJLElBQUksR0FBRztFQUNULFFBQVEsRUFBRSxRQUFRO0VBQ2xCLFFBQVEsRUFBRSxRQUFRO0VBQ2xCLFdBQVcsRUFBRSxXQUFXO0VBQ3hCLGtCQUFrQixFQUFFLGtCQUFrQjtFQUN0QyxTQUFTLEVBQUUsU0FBUztFQUNwQixNQUFNLEVBQUUsTUFBTTtFQUNkLE1BQU0sRUFBRSxNQUFNO0NBQ2YsQ0FBQztBQUNGLEtBQUssSUFBSSxDQUFDLElBQUksSUFBSSxFQUFFO0VBQ2xCLElBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRTtJQUNqRCxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0dBQ3RCO0NBQ0Y7O0FBRUQsSUFBSSxPQUFPLE1BQU0sS0FBSyxXQUFXLEVBQUU7RUFDakMsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztFQUM5QixPQUFPLENBQUMsVUFBVSxHQUFHLFVBQVUsSUFBSSxFQUFFO0lBQ25DLElBQUksSUFBSSxJQUFJLE1BQU0sQ0FBQyxPQUFPLEtBQUssT0FBTyxFQUFFO01BQ3RDLE1BQU0sQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDO0tBQzNCO0lBQ0QsT0FBTyxPQUFPLENBQUM7R0FDaEIsQ0FBQztFQUNGLE1BQU0sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO0NBQzFCOzs7O0FDMVlNLE1BQU0sT0FBTyxTQUFTLFdBQVcsQ0FBQzs7RUFFdkMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFO0lBQ1AsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxFQUFDO0dBQ2pEOztFQUVELGlCQUFpQixHQUFHO0lBQ2xCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUM7R0FDN0Q7RUFDRCxvQkFBb0IsR0FBRztJQUNyQixNQUFNLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUM7R0FDckQ7O0VBRUQsU0FBUyxHQUFHO0lBQ1YsTUFBTSxDQUFDLHFCQUFxQixDQUFDLE1BQU07TUFDakMsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsRUFBQztNQUNyRSxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLEVBQUUsYUFBYSxDQUFDLEVBQUUsQ0FBQyxFQUFDOztNQUUzRCxJQUFJLENBQUMsUUFBUSxHQUFHO1FBQ2QsYUFBYTtRQUNiLFlBQVksRUFBRSxTQUFTLENBQUMscUJBQXFCLEVBQUU7UUFDaEQ7S0FDRixFQUFDO0dBQ0g7O0VBRUQsSUFBSSxRQUFRLENBQUMsQ0FBQyxZQUFZLEVBQUUsYUFBYSxDQUFDLEVBQUU7SUFDMUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsYUFBYSxFQUFDO0dBQ25FOztFQUVELE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUUsYUFBYSxFQUFFO0lBQ3hELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLEVBQUUsYUFBYSxFQUFDO0lBQzlELE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDOzs7ZUFHakIsRUFBRSxLQUFLLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQztxQkFDckIsRUFBRSxLQUFLLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQzs7Ozs7Ozs7bUNBUUosRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDOzBDQUNILEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQzttQ0FDbEIsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUM7bUNBQ3pCLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDOztJQUV4RCxDQUFDO0dBQ0Y7O0VBRUQsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQ2pCLE9BQU8sQ0FBQzs7OztlQUlHLEVBQUUsR0FBRyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUM7Z0JBQ3RCLEVBQUUsSUFBSSxDQUFDOzs7Ozs7SUFNbkIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsT0FBTzs7NENBQUMsNUNDckVyQyxNQUFNLEtBQUssU0FBUyxXQUFXLENBQUM7O0VBRXJDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTtJQUNQLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsRUFBQztHQUNqRDs7RUFFRCxpQkFBaUIsR0FBRztJQUNsQixDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUM7SUFDMUUsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQztHQUM3RDs7RUFFRCxvQkFBb0IsR0FBRztJQUNyQixDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUM7SUFDckQsTUFBTSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFDO0dBQ3JEOztFQUVELFNBQVMsR0FBRztJQUNWLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNO01BQ2pDLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLEVBQUM7TUFDckUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixFQUFFLGFBQWEsQ0FBQyxFQUFFLENBQUMsRUFBQzs7TUFFN0QsSUFBSSxDQUFDLFNBQVMsRUFBRSxNQUFNOztNQUV0QixJQUFJLENBQUMsUUFBUSxHQUFHO1FBQ2QsYUFBYTtRQUNiLFlBQVksRUFBRSxTQUFTLENBQUMscUJBQXFCLEVBQUU7UUFDaEQ7S0FDRixFQUFDO0dBQ0g7O0VBRUQsYUFBYSxDQUFDLENBQUMsRUFBRTtJQUNmLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLFdBQVcsQ0FBQyxPQUFPLEVBQUU7TUFDdkQsT0FBTyxFQUFFLElBQUk7TUFDYixNQUFNLElBQUk7UUFDUixJQUFJLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXO1FBQ2hDLFNBQVMsR0FBRyxDQUFDLENBQUMsSUFBSTtPQUNuQjtLQUNGLENBQUMsRUFBQztHQUNKOztFQUVELElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtJQUNoQixJQUFJLENBQUMsS0FBSyxHQUFHLFFBQU87R0FDckI7O0VBRUQsSUFBSSxRQUFRLENBQUMsQ0FBQyxZQUFZLEVBQUUsYUFBYSxDQUFDLEVBQUU7SUFDMUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsYUFBYSxFQUFDO0dBQ25FOztFQUVELElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO0lBQ2hCLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQztJQUN0QyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsTUFBTSxDQUFDLE9BQU8sR0FBRyxLQUFJO0lBQzVDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSTtHQUNoQzs7RUFFRCxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFLGFBQWEsRUFBRTtJQUN4RCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFFLGFBQWEsRUFBQzs7SUFFOUQsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDOztRQUU5QixFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7O0lBRWpCLENBQUM7R0FDRjs7RUFFRCxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO0lBQ3ZCLE9BQU8sQ0FBQzs7Ozs7Ozs7ZUFRRyxFQUFFLEdBQUcsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDO2dCQUN0QixFQUFFLElBQUksR0FBRyxDQUFDLENBQUM7cUJBQ04sRUFBRSxLQUFLLElBQUksTUFBTSxDQUFDLFVBQVUsR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHLEVBQUUsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQTZCbkUsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsS0FBSzs7d0NBQUMseENDaEhqQyxNQUFNLGNBQWMsR0FBRztFQUM1QixLQUFLLGlCQUFpQixjQUFjO0VBQ3BDLGVBQWUsT0FBTyxrQkFBa0I7RUFDeEMsZUFBZSxPQUFPLE1BQU07RUFDNUIsY0FBYyxRQUFRLE1BQU07RUFDNUIsa0JBQWtCLElBQUksT0FBTzs7RUFFN0IsV0FBVyxXQUFXLEtBQUs7RUFDM0IsWUFBWSxVQUFVLEtBQUs7RUFDM0IsU0FBUyxhQUFhLE1BQU07RUFDNUIsT0FBTyxlQUFlLEtBQUs7RUFDM0IsTUFBTSxnQkFBZ0IsS0FBSztFQUMzQixVQUFVLFlBQVksRUFBRTtFQUN4QixRQUFRLGNBQWMsTUFBTTtFQUM1QixVQUFVLFlBQVksS0FBSztFQUMzQixTQUFTLGFBQWEsT0FBTztFQUM3QixVQUFVLFlBQVksTUFBTTtFQUM1QixhQUFhLFNBQVMsTUFBTTtFQUM1QixVQUFVLFlBQVksUUFBUTtFQUM5QixhQUFhLFNBQVMsUUFBUTtFQUM5QixPQUFPLGVBQWUsT0FBTztFQUM3QixVQUFVLFlBQVksUUFBUTtFQUM5QixjQUFjLFFBQVEsUUFBUTtFQUM5QixJQUFJLGtCQUFrQixjQUFjO0VBQ3BDLE1BQU0sZ0JBQWdCLE1BQU07RUFDN0I7O0FBRUQsQUFBTyxNQUFNLHVCQUF1QixHQUFHO0VBQ3JDLE1BQU07RUFDTixVQUFVO0VBQ1YsUUFBUTtFQUNSLEtBQUs7RUFDTCxLQUFLO0VBQ0wsT0FBTztFQUNSOztBQUVELEFBQU8sTUFBTSxpQkFBaUIsR0FBRztFQUMvQjtJQUNFLFFBQVEsRUFBRSxNQUFNO0lBQ2hCLFVBQVUsRUFBRSxHQUFHO0dBQ2hCO0VBQ0Q7SUFDRSxRQUFRLEVBQUUsUUFBUTtJQUNsQixVQUFVLEVBQUUsS0FBSztHQUNsQjs7O0NBQ0YsREMzQ00sTUFBTSxRQUFRLEdBQUcsQ0FBQyxFQUFFLEVBQUUsSUFBSSxLQUFLO0VBQ3BDLElBQUksUUFBUSxDQUFDLFdBQVcsSUFBSSxRQUFRLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFO0lBQ2pFLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxLQUFLLEVBQUM7SUFDdEMsSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFXLEdBQUU7SUFDekIsSUFBSSxDQUFDLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFDO0lBQ3JELE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUM7R0FDckM7RUFDRjs7QUFFRCxBQUFPLE1BQU0sU0FBUyxHQUFHLEVBQUUsSUFBSTtFQUM3QixNQUFNLGFBQWEsR0FBRyxFQUFFLENBQUMsTUFBSztFQUM5QixNQUFNLGFBQWEsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxFQUFFLElBQUksRUFBQzs7RUFFdkQsSUFBSSxhQUFhLEdBQUcsR0FBRTs7RUFFdEIsS0FBSyxJQUFJLElBQUksRUFBRSxDQUFDLEtBQUs7SUFDbkIsSUFBSSxJQUFJLElBQUksY0FBYyxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxhQUFhLENBQUMsSUFBSSxDQUFDO01BQ3ZFLGFBQWEsQ0FBQyxJQUFJLENBQUM7UUFDakIsSUFBSTtRQUNKLEtBQUssRUFBRSxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUM7T0FDeEQsRUFBQzs7RUFFTixPQUFPLGFBQWE7RUFDckI7O0FBRUQsQUFBTyxNQUFNLDBCQUEwQixHQUFHLEVBQUUsSUFBSTtFQUM5QyxJQUFJLFVBQVUsR0FBRyxRQUFRLENBQUMsRUFBRSxFQUFFLGtCQUFrQixFQUFDOztFQUVqRCxJQUFJLFVBQVUsS0FBSyxrQkFBa0IsRUFBRTtJQUNyQyxJQUFJLElBQUksSUFBSSxFQUFFLENBQUMsVUFBVTtRQUNyQixLQUFLLEdBQUcsTUFBSzs7SUFFakIsTUFBTSxDQUFDLEtBQUssRUFBRTtNQUNaLElBQUksRUFBRSxJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsa0JBQWtCLEVBQUM7O01BRTVDLElBQUksRUFBRSxLQUFLLGtCQUFrQixFQUFFO1FBQzdCLEtBQUssR0FBRyxLQUFJO1FBQ1osVUFBVSxHQUFHLEdBQUU7T0FDaEI7O01BRUQsSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFVO0tBQ3ZCO0dBQ0Y7O0VBRUQsT0FBTyxVQUFVO0NBQ2xCOztBQzVDTSxNQUFNLFFBQVEsR0FBRyxFQUFFLElBQUk7RUFDNUIsTUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDLGlCQUFpQixHQUFFOztFQUUzQyxPQUFPLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxTQUFTLEtBQUs7SUFDeEQsSUFBSSxZQUFZLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQztNQUNsQyxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsSUFBSSxJQUFJLFNBQVM7UUFDakIsS0FBSyxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDO09BQ25DLEVBQUM7O0lBRUosSUFBSSxTQUFTLEtBQUssUUFBUTtNQUN4QixZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSTtRQUMzQixJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1VBQ3ZCLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxJQUFJLElBQUksSUFBSTtZQUNaLEtBQUssR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQztXQUM5QixFQUFDO09BQ0wsRUFBQzs7SUFFSixPQUFPLEdBQUc7R0FDWCxFQUFFLEVBQUUsQ0FBQztFQUNQOztBQUVELEFBQU8sTUFBTSxnQkFBZ0IsR0FBRyxFQUFFLElBQUk7O0VBRXBDLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxLQUFLO01BQ3JELFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQUs7TUFDbEMsT0FBTyxRQUFRO0dBQ2xCLEVBQUUsRUFBRSxFQUFDOztFQUVOLE1BQU0sRUFBRSxRQUFRLEtBQUssY0FBYyxDQUFDLFFBQVE7VUFDcEMsVUFBVSxHQUFHLGNBQWMsQ0FBQyxVQUFVO09BQ3pDLEdBQUcsT0FBTTs7RUFFZCxNQUFNLE9BQU8sR0FBRyxpQkFBaUIsQ0FBQyxJQUFJO0lBQ3BDLENBQUMsZUFBZSxLQUFLLFVBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxVQUFVLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztVQUMzRSxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksVUFBVSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUM7SUFDdkU7O0VBRUQsUUFBUSxPQUFPLEdBQUcsT0FBTyxHQUFHLE9BQU87OztDQUNwQyxEQzNDTSxNQUFNLFdBQVcsR0FBRyxDQUFDLFdBQVcsR0FBRyxFQUFFO0VBQzFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUMsRUFBRTtJQUNqQyxHQUFHLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxFQUFDOztBQUV6QixBQUFPLE1BQU0sT0FBTyxHQUFHLElBQUksSUFBSTtFQUM3QixJQUFJLElBQUksR0FBRyxHQUFFO0VBQ2IsSUFBSSxhQUFhLEdBQUcsS0FBSTs7RUFFeEIsT0FBTyxhQUFhLEVBQUU7SUFDcEIsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUM7SUFDeEIsYUFBYSxHQUFHLGFBQWEsQ0FBQyxVQUFVO1FBQ3BDLGFBQWEsQ0FBQyxVQUFVO1FBQ3hCLE1BQUs7R0FDVjs7RUFFRCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxLQUFLLENBQUM7SUFDcEMsRUFBRSxJQUFJLENBQUMsRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO0VBQ3JILENBQUMsRUFBRSxFQUFFLENBQUM7RUFDUDs7QUFFRCxBQUFPLE1BQU0sZUFBZSxHQUFHLENBQUMsRUFBRSxFQUFFLE9BQU8sR0FBRyxLQUFLLEtBQUs7RUFDdEQsSUFBSSxDQUFDLEVBQUUsQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDLFFBQVEsS0FBSyxLQUFLLElBQUksRUFBRSxDQUFDLGVBQWUsRUFBRSxPQUFPLEVBQUU7RUFDM0UsSUFBSSxZQUFZLEdBQUcsR0FBRyxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUM7O0VBRXhELE9BQU8sT0FBTyxJQUFJLFlBQVksQ0FBQyxNQUFNLEdBQUcsRUFBRTtNQUN0QyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLO01BQ3BDLFlBQVk7RUFDakI7O0FBRUQsQUFBTyxNQUFNLE9BQU8sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDO0lBQzVELEtBQUs7SUFDTCxPQUFNOztBQUVWLEFBQU8sTUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztJQUMzRCxLQUFLO0lBQ0wsS0FBSzs7QUNoQ0YsTUFBTSxPQUFPLEdBQUcsU0FBUyxJQUFJO0VBQ2xDLElBQUksS0FBSyxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxFQUFDO0VBQzNFLElBQUksS0FBSyxJQUFJLElBQUksRUFBRSxLQUFLLEdBQUcsTUFBSztFQUNoQyxJQUFJLEtBQUssSUFBSSxNQUFNLEVBQUUsS0FBSyxHQUFHLFNBQVE7RUFDckMsT0FBTyxLQUFLO0VBQ2I7O0FBRUQsQUFBTyxNQUFNLFlBQVksR0FBRyxFQUFFLElBQUk7RUFDaEMsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDO0tBQ2hELE9BQU8sQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDO0VBQzdCOztBQUVELEFBQU8sU0FBUyxRQUFRLENBQUMsRUFBRSxFQUFFO0VBQzNCLE9BQU8sRUFBRSxDQUFDLE9BQU8sQ0FBQztJQUNoQixFQUFFLE9BQU8sRUFBRSx1QkFBdUIsRUFBRTtJQUNwQyxFQUFFLE9BQU8sRUFBRSxxQ0FBcUMsRUFBRTtJQUNsRCxFQUFFLE9BQU8sRUFBRSx1QkFBdUIsRUFBRTtHQUNyQyxFQUFFLEdBQUcsQ0FBQztDQUNSOztBQUVELElBQUksVUFBVSxHQUFHLEdBQUU7QUFDbkIsQUFBTyxNQUFNLGdCQUFnQixHQUFHLENBQUMsRUFBRSxFQUFFLFFBQVEsR0FBRyxHQUFHLEtBQUs7RUFDdEQsRUFBRSxDQUFDLFlBQVksQ0FBQyxvQkFBb0IsRUFBRSxJQUFJLEVBQUM7RUFDM0MsaUJBQWlCLENBQUMsRUFBRSxFQUFFLElBQUksRUFBQzs7RUFFM0IsSUFBSSxVQUFVLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3pCLFlBQVksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUM7O0VBRXZDLFVBQVUsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxJQUFJO0lBQ3hDLEVBQUUsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLEVBQUM7SUFDeEMsaUJBQWlCLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBQztHQUM3QixFQUFFLFFBQVEsRUFBQzs7RUFFWixPQUFPLEVBQUU7RUFDVjs7QUFFRCxBQUFPLE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxFQUFFLEVBQUUsSUFBSSxHQUFHLEtBQUssS0FBSztFQUNyRCxJQUFJLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUM7SUFDbkMsTUFBTTs7RUFFUixNQUFNLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQzs0QkFDUyxFQUFFLEVBQUUsQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLENBQUM7OEJBQ2pDLEVBQUUsRUFBRSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsQ0FBQztFQUMvRCxDQUFDLEVBQUM7O0VBRUYsS0FBSyxDQUFDLE1BQU0sSUFBSSxJQUFJO01BQ2hCLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUNoQixFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7TUFDMUIsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQ2hCLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLElBQUksRUFBQztFQUM3Qjs7QUFFRCxBQUFPLE1BQU0sZUFBZSxHQUFHLENBQUMsVUFBVSxHQUFHLEVBQUU7RUFDN0MsQ0FBQyxJQUFJLFNBQVMsRUFBRSxDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsV0FBVyxDQUFDO0tBQ3RELElBQUksQ0FBQyxXQUFVOztBQUVwQixBQUFPLE1BQU0sV0FBVyxHQUFHLElBQUk7RUFDN0IsSUFBSSxDQUFDLE9BQU87R0FDWCxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQztLQUMxQixJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQztLQUMxQixJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQztLQUMxQixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztLQUN2QixJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztLQUN4QixJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQztLQUMxQixJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQzs7O0dBQzlCLEhDcEVJLFNBQVMsWUFBWSxHQUFHO0VBQzdCLE1BQU0sTUFBTSxJQUFJLE1BQU0sQ0FBQyxZQUFXO0VBQ2xDLE1BQU0sS0FBSyxLQUFLLE1BQU0sQ0FBQyxXQUFVO0VBQ2pDLE1BQU0sSUFBSSxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBVzs7RUFFekMsTUFBTSxTQUFTLEdBQUcsSUFBSSxJQUFJLEtBQUs7TUFDM0IsSUFBSTtNQUNKLE1BQUs7O0VBRVQsT0FBTztJQUNMLFNBQVMsRUFBRSxNQUFNO0lBQ2pCLFFBQVEsR0FBRyxTQUFTO0dBQ3JCO0NBQ0Y7O0FDWE0sTUFBTSxTQUFTLFNBQVMsV0FBVyxDQUFDOztFQUV6QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7SUFDUCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUM7R0FDakQ7O0VBRUQsaUJBQWlCLEdBQUcsRUFBRTtFQUN0QixvQkFBb0IsR0FBRyxFQUFFOztFQUV6QixJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUU7SUFDekIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUM7R0FDcEQ7O0VBRUQsSUFBSSxNQUFNLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRTtJQUN2QyxNQUFNLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxHQUFHLFlBQVksR0FBRTs7SUFFOUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxRQUFPO0lBQ3pDLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQzs7SUFFcEMsR0FBRyxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQyxFQUFDO0lBQzNELEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxLQUFLLEdBQUcsSUFBSSxFQUFDO0lBQ25ELEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxNQUFNLEdBQUcsSUFBSSxFQUFDO0lBQ3JELEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUM7SUFDdkMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBQztJQUN0QyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFDO0lBQ3hDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUM7SUFDeEMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLElBQUksR0FBRyxLQUFLLEVBQUM7SUFDaEQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLElBQUksR0FBRyxLQUFLLEVBQUM7SUFDaEQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBQztJQUN2QyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFDO0lBQ3ZDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7SUFDNUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLEdBQUcsR0FBRyxNQUFNLEVBQUM7SUFDaEQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLEdBQUcsR0FBRyxNQUFNLEVBQUM7SUFDaEQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBQztHQUM3Qzs7RUFFRCxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFO0lBQ3pDLE1BQU0sRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLEdBQUcsWUFBWSxHQUFFOztJQUU5QyxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzs7O3FCQUdYLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUM7Ozs7O2lCQUs1QixFQUFFLEtBQUssQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDO2FBQy9CLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUM7OztrQkFHUixFQUFFLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7a0JBQ3ZDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxhQUFhLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDO3lCQUNoRCxFQUFFLENBQUMsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7eUJBQy9CLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDOztJQUV0RSxDQUFDO0dBQ0Y7O0VBRUQsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQ2pCLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7SUFXUixDQUFDO0dBQ0Y7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxTQUFTLENBQUM7O0FDL0V6QyxNQUFNLE9BQU8sU0FBUyxXQUFXLENBQUM7O0VBRXZDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTtJQUNQLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsRUFBQztHQUNqRDs7RUFFRCxpQkFBaUIsR0FBRyxFQUFFO0VBQ3RCLG9CQUFvQixHQUFHLEVBQUU7O0VBRXpCLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRTtJQUN6QixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBQztHQUNwRDs7RUFFRCxJQUFJLE1BQU0sQ0FBQyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFO0lBQ3ZDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsUUFBTzs7SUFFekMsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFDO0lBQ3BDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLFFBQU87SUFDM0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLE9BQU8sR0FBRyxHQUFHLEdBQUcsS0FBSTtJQUMzQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSTs7SUFFNUIsR0FBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsS0FBSyxHQUFHLElBQUksRUFBQztJQUN2QyxHQUFHLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxNQUFNLEdBQUcsSUFBSSxFQUFDO0dBQzFDOztFQUVELE1BQU0sQ0FBQyxDQUFDLEVBQUUsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRTtJQUNyQyxPQUFPLENBQUM7OztvQkFHUSxFQUFFLEVBQUUsQ0FBQzs7Ozs7Ozs7OztlQVVWLEVBQUUsS0FBSyxDQUFDLFlBQVksRUFBRSxNQUFNLENBQUM7cUJBQ3ZCLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUM7Ozs7Ozs7O0lBUW5DLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLE9BQU87Ozs7QUNqRHBDLE1BQU0sT0FBTyxTQUFTLFdBQVcsQ0FBQzs7RUFFdkMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFO0lBQ1AsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxFQUFDO0dBQ2pEOztFQUVELGlCQUFpQixHQUFHO0lBQ2xCLENBQUMsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQztJQUMvRSxDQUFDLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDO0dBQzVFOztFQUVELG9CQUFvQixHQUFHO0lBQ3JCLENBQUMsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBQztHQUMzRDs7RUFFRCxhQUFhLENBQUMsQ0FBQyxFQUFFO0lBQ2YsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksV0FBVyxDQUFDLE9BQU8sRUFBRTtNQUN2RCxPQUFPLEVBQUUsSUFBSTtNQUNiLE1BQU0sSUFBSTtRQUNSLElBQUksUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVc7UUFDaEMsU0FBUyxHQUFHLENBQUMsQ0FBQyxJQUFJO09BQ25CO0tBQ0YsQ0FBQyxFQUFDO0dBQ0o7O0VBRUQsZUFBZSxDQUFDLENBQUMsRUFBRTtJQUNqQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxXQUFXLENBQUMsU0FBUyxFQUFFO01BQ3pELE9BQU8sRUFBRSxJQUFJO0tBQ2QsQ0FBQyxFQUFDO0dBQ0o7O0VBRUQsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFO0lBQ2IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUM7R0FDM0M7O0VBRUQsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsa0JBQWtCLEVBQUUscUJBQXFCLENBQUMsRUFBRTtJQUNyRSxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzs7O3NCQUdBLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztzQkFDNUIsRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDO1VBQ25DLEVBQUUsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7YUFDN0IsTUFBTSxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDO2FBQzFCLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLEtBQUssQ0FBQztjQUN4QixFQUFFLEtBQUssQ0FBQzsyQkFDSyxFQUFFLElBQUksQ0FBQztZQUN0QixDQUFDLEVBQUUsRUFBRSxDQUFDO1dBQ1A7OztpQkFHTSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7O2dCQUVyQixFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7O2FBRXhCLEVBQUUscUJBQXFCLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLElBQUksS0FBSyxDQUFDO1VBQ3BELEVBQUUsS0FBSyxDQUFDO3FCQUNHLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQztzQkFDWCxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDM0IsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDOztRQUVQLEVBQUUsa0JBQWtCLENBQUMsTUFBTSxHQUFHLENBQUM7O2VBRXhCLEVBQUUsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLElBQUksS0FBSyxDQUFDO1lBQ2pELEVBQUUsS0FBSyxDQUFDO3VCQUNHLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQzt3QkFDWCxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7VUFDM0IsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDOztRQUVULENBQUMsR0FBRyxFQUFFLENBQUM7O0lBRVgsQ0FBQztHQUNGOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQzs7UUFFSixFQUFFQSxLQUFNLENBQUM7O0lBRWIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsT0FBTzs7NENBQUMsNUNDdEZyQyxNQUFNLElBQUksU0FBUyxPQUFPLENBQUM7RUFDaEMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFO0dBQ1I7O0VBRUQsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFFLGVBQWUsRUFBRSxnQkFBZ0IsQ0FBQyxFQUFFO0lBQzlDLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDOztZQUVWLEVBQUUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7O1VBRXJELEVBQUUsZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLEtBQUssQ0FBQztZQUN6QyxFQUFFLEtBQUssQ0FBQzt1QkFDRyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUM7d0JBQ1gsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO1VBQzNCLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztVQUNQLEVBQUUsZ0JBQWdCLENBQUM7OztJQUd6QixDQUFDO0dBQ0Y7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxJQUFJOzs7O0FDekI5QixNQUFNLE1BQU0sR0FBRyxDQUFDOzs7O0FBSXZCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLElBQUksR0FBRyxDQUFDOzs7O0FBSXJCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLE1BQU0sR0FBRyxDQUFDOzs7O0FBSXZCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLE1BQU0sR0FBRyxDQUFDOzs7O0FBSXZCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLE9BQU8sR0FBRyxDQUFDOzs7O0FBSXhCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLElBQUksR0FBRyxDQUFDOzs7O0FBSXJCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLElBQUksR0FBRyxDQUFDOzs7O0FBSXJCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLEtBQUssR0FBRyxDQUFDOzs7O0FBSXRCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLE1BQU0sR0FBRyxDQUFDOzs7O0FBSXZCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLFNBQVMsR0FBRyxDQUFDOzs7OztBQUsxQixFQUFDOztBQUVELEFBQU8sTUFBTSxNQUFNLEdBQUcsQ0FBQzs7OztBQUl2QixFQUFDOztBQUVELEFBQU8sTUFBTSxRQUFRLEdBQUcsQ0FBQzs7OztBQUl6QixFQUFDOztBQUVELEFBQU8sTUFBTSxTQUFTLEdBQUcsQ0FBQzs7OztBQUkxQixFQUFDOztBQUVELEFBQU8sTUFBTSxTQUFTLEdBQUcsQ0FBQzs7Ozs7Ozs7O0FBUzFCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLE1BQU0sR0FBRyxDQUFDOzs7OztBQUt2QixFQUFDOztBQUVELEFBQU8sTUFBTSxNQUFNLEdBQUcsQ0FBQzs7Ozs7QUFLdkIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sVUFBVSxHQUFHLENBQUM7Ozs7O0FBSzNCLEVBQUM7O0FBRUQsQUFBTyxNQUFNLGdCQUFnQixHQUFHLENBQUM7Ozs7O0FBS2pDLEVBQUM7O0FBRUQsQUFBTyxNQUFNLFlBQVksR0FBRyxDQUFDOzs7OztBQUs3QixFQUFDOztBQUVELEFBQU8sTUFBTSxRQUFRLEdBQUcsQ0FBQzs7Ozs7QUFLekIsRUFBQzs7QUFFRCxBQUFPLE1BQU0sYUFBYSxHQUFHLENBQUM7Ozs7QUFJOUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBQUMsRENsSU0sTUFBTSxTQUFTLFNBQVMsV0FBVyxDQUFDOztFQUV6QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLGNBQWMsR0FBRztNQUNwQixHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO01BQ3RFLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7TUFDcEUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7TUFDbEUsS0FBSyxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7TUFDakUsS0FBSyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO01BQzdEOztJQUVELElBQUksQ0FBQyxjQUFjLEdBQUc7TUFDcEIsR0FBRyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztNQUNkLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDYixJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7TUFDbEIsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO01BQ2xCLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7TUFDZjs7SUFFRCxJQUFJLENBQUMsT0FBTyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUM7O0lBRW5ELElBQUksQ0FBQyxPQUFPLE1BQU0sR0FBRTtJQUNwQixJQUFJLENBQUMsU0FBUyxJQUFJLEdBQUU7O0lBRXBCLElBQUksQ0FBQyxJQUFJLFNBQVMsWUFBVztHQUM5Qjs7RUFFRCxpQkFBaUIsR0FBRztJQUNsQixJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxnQ0FBZ0MsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFDO0lBQ2hFLElBQUksQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLCtCQUErQixFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUM7SUFDL0QsSUFBSSxDQUFDLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBQztJQUNwRSxJQUFJLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFDO0lBQ3JFLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFDO0lBQy9DLElBQUksQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUM7SUFDakQsSUFBSSxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBQztJQUNqRCxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFDO0dBQ25EOztFQUVELG9CQUFvQixHQUFHLEVBQUU7O0VBRXpCLElBQUksSUFBSSxDQUFDLElBQUksRUFBRTtJQUNiLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSTtJQUNqQixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFFO0dBQ3ZDOztFQUVELElBQUksR0FBRztJQUNMLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTTtJQUN4QyxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU87TUFDdEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUM7R0FDOUI7O0VBRUQsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFNO0lBQ3hDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFDO0dBQ3BCOztFQUVELFNBQVMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxFQUFFO0lBQ3BCLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsQ0FBQyxDQUFDLHdCQUF3QixHQUFFOztJQUU1QixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBQztJQUMxQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBQztJQUN4QyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBQztJQUN0QyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFDO0lBQzNDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsSUFBSSxLQUFLLFNBQVMsRUFBQztJQUM5QyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUM7SUFDbEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFDO0lBQ2xELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsSUFBSSxLQUFLLFlBQVksRUFBQzs7SUFFcEQsTUFBTSxFQUFFLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsRUFBQzs7SUFFdEYsQ0FBQyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7TUFDOUQsUUFBUSxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxNQUFNO0tBQzFDLEVBQUM7R0FDSDs7RUFFRCxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBRUMsVUFBTyxDQUFDLEVBQUU7SUFDakMsSUFBSSxNQUFNLGdCQUFnQkEsVUFBTyxDQUFDLEtBQUssR0FBRyxFQUFFLEdBQUcsRUFBQztJQUNoRCxJQUFJLFFBQVEsY0FBY0EsVUFBTyxDQUFDLEdBQUcsR0FBRyxVQUFVLEdBQUcsTUFBSztJQUMxRCxJQUFJLGlCQUFpQixLQUFLQSxVQUFPLENBQUMsR0FBRyxHQUFHLE1BQU0sR0FBRyxLQUFJOztJQUVyRCxJQUFJLElBQUksR0FBRyxjQUFhO0lBQ3hCLElBQUksSUFBSSxLQUFLLFNBQVMsTUFBTSxJQUFJLEdBQUcsZUFBYztJQUNqRCxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxHQUFHLGtCQUFpQjtJQUNwRCxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxHQUFHLGdCQUFlO0lBQ2xELElBQUksSUFBSSxLQUFLLFlBQVksR0FBRyxJQUFJLEdBQUcsaUJBQWdCO0lBQ25ELElBQUlBLFVBQU8sQ0FBQyxPQUFPLENBQUMsYUFBYSxJQUFJLEdBQUcsWUFBVzs7SUFFbkQsSUFBSUEsVUFBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLElBQUksS0FBSyxXQUFXLEVBQUU7TUFDNUMsUUFBUSxjQUFjLFdBQVU7TUFDaEMsaUJBQWlCLEtBQUssT0FBTTtLQUM3Qjs7SUFFRCxPQUFPO01BQ0wsUUFBUSxFQUFFLGlCQUFpQixFQUFFLE1BQU0sRUFBRSxJQUFJO0tBQzFDO0dBQ0Y7O0VBRUQsY0FBYyxDQUFDLENBQUMsUUFBUSxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsRUFBRTtJQUMxRCxPQUFPLENBQUM7cUJBQ1MsRUFBRSxRQUFRLENBQUM7aUJBQ2YsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO21CQUNYLEVBQUUsaUJBQWlCLENBQUM7aUJBQ3RCLEVBQUUsSUFBSSxDQUFDOzttQkFFTCxFQUFFLE1BQU0sQ0FBQztJQUN4QixDQUFDO0dBQ0Y7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Ozs7WUFJVixFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDcEIsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzs7O1VBSWYsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDO1lBQ3BCLFFBQVEsRUFBRSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDO1lBQ3pCLGlCQUFpQixFQUFFLE1BQU07WUFDekIsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLO1lBQ2hCLElBQUksRUFBRSxhQUFhO1lBQ25CLE1BQU0sRUFBRSxDQUFDO1dBQ1YsQ0FBQyxDQUFDOzs7O1lBSUQsRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQztjQUMzRSxFQUFFLFFBQVEsQ0FBQzt1QkFDRixFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUM7Z0JBQ2xELEVBQUUsR0FBRyxDQUFDOztrQkFFSixFQUFFLEdBQUcsQ0FBQztrQkFDTixFQUFFLElBQUksQ0FBQyxPQUFPLElBQUksR0FBRyxHQUFHLHFDQUFxQyxHQUFHLEVBQUUsQ0FBQztrQkFDbkUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLEdBQUcsRUFBRSxDQUFDOzhCQUNqQyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNyRCxFQUFFLEdBQUcsQ0FBQztjQUNULENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQzs7WUFFVCxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7Ozs7Ozs7Ozs7OztJQVlmLENBQUM7R0FDRjs7RUFFRCxNQUFNLEdBQUc7SUFDUCxPQUFPLENBQUM7O1FBRUosRUFBRUQsS0FBTSxDQUFDOztJQUViLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQzs7QUMzS3ZDLE1BQU0sYUFBYSxTQUFTLFNBQVMsQ0FBQztFQUMzQyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLElBQUksR0FBRTtJQUNwQixJQUFJLENBQUMsSUFBSSxTQUFTLFNBQVE7R0FDM0I7O0VBRUQsaUJBQWlCLEdBQUcsRUFBRTs7RUFFdEIsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFNO0dBQ3pDOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDOzs7O1lBSVYsRUFBRUUsTUFBSSxDQUFDO1lBQ1AsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzs7Ozs7O0lBT3JCLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsYUFBYTs7c0RBQUMsdERDaEMvQyxNQUFNLGdCQUFnQixTQUFTLFNBQVMsQ0FBQztFQUM5QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUM7SUFDMUIsSUFBSSxDQUFDLElBQUksU0FBUyxZQUFXO0dBQzlCOztFQUVELGlCQUFpQixHQUFHLEVBQUU7O0VBRXRCLElBQUksR0FBRztJQUNMLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTTtHQUN6Qzs7RUFFRCxNQUFNLEdBQUc7SUFDUCxPQUFPLENBQUM7TUFDTixFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzs7OztZQUlWLEVBQUVBLFNBQUksQ0FBQztZQUNQLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQzs7Ozs7OztJQU9yQixDQUFDO0dBQ0Y7Q0FDRjs7QUFFRCxjQUFjLENBQUMsTUFBTSxDQUFDLG1CQUFtQixFQUFFLGdCQUFnQixDQUFDOztBQ2pDckQsTUFBTSxvQkFBb0IsU0FBUyxTQUFTLENBQUM7RUFDbEQsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFDO0lBQzFCLElBQUksQ0FBQyxJQUFJLFNBQVMsZ0JBQWU7R0FDbEM7O0VBRUQsaUJBQWlCLEdBQUcsRUFBRTs7RUFFdEIsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFNO0dBQ3pDOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDOzs7O1lBSVYsRUFBRUEsYUFBSSxDQUFDO1lBQ1AsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzs7Ozs7O0lBT3JCLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsdUJBQXVCLEVBQUUsb0JBQW9CLENBQUM7O0FDbkM3RCxNQUFNLFdBQVcsU0FBUyxTQUFTLENBQUM7RUFDekMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLElBQUksSUFBRztJQUNuQixJQUFJLENBQUMsSUFBSSxPQUFPLE9BQU07R0FDdkI7O0VBRUQsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUU7SUFDakMsSUFBSSxNQUFNLEVBQUUsUUFBUSxFQUFFLGtCQUFpQjs7SUFFdkMsSUFBSSxJQUFJLEdBQUcsY0FBYTtJQUN4QixJQUFJLElBQUksS0FBSyxTQUFTLE1BQU0sSUFBSSxHQUFHLGtCQUFpQjtJQUNwRCxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxHQUFHLDZDQUE0QztJQUMvRSxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxHQUFHLHFDQUFvQztJQUN2RSxJQUFJLElBQUksS0FBSyxZQUFZLEdBQUcsSUFBSSxHQUFHLHVDQUFzQzs7SUFFekUsT0FBTztNQUNMLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxNQUFNLEVBQUUsSUFBSTtLQUMxQztHQUNGOztFQUVELGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQ3JCLE9BQU8sQ0FBQztpQkFDSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7aUJBQ2IsRUFBRSxJQUFJLENBQUM7SUFDcEIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsV0FBVzs7a0RBQUMsbERDN0IzQyxNQUFNLGFBQWEsU0FBUyxTQUFTLENBQUM7RUFDM0MsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUM7O0lBRTFDLElBQUksQ0FBQyxJQUFJLFNBQVMsU0FBUTtHQUMzQjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsYUFBYSxDQUFDOztBQ1gvQyxNQUFNLGNBQWMsU0FBUyxTQUFTLENBQUM7RUFDNUMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUM7O0lBRTFDLElBQUksQ0FBQyxJQUFJLFNBQVMsVUFBUztHQUM1QjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUsY0FBYyxDQUFDOztBQ1h4RCxNQUFNLGNBQWMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFDO0FBQ2pELE1BQU0sY0FBYyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUM7QUFDakQsTUFBTSxXQUFXLE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBQzs7QUFFckQsQUFBTyxNQUFNLFlBQVksU0FBUyxTQUFTLENBQUM7RUFDMUMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLEtBQUssSUFBRztJQUNwQixJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBQzs7SUFFbEMsSUFBSSxDQUFDLE1BQU0sS0FBSyxFQUFDO0lBQ2pCLElBQUksQ0FBQyxNQUFNLEtBQUssRUFBQztJQUNqQixJQUFJLENBQUMsTUFBTSxLQUFLLEVBQUM7O0lBRWpCLElBQUksQ0FBQyxLQUFLLFdBQVcsV0FBVTtJQUMvQixJQUFJLENBQUMsVUFBVSxNQUFNLE1BQUs7SUFDMUIsSUFBSSxDQUFDLGFBQWEsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBQzs7SUFFN0MsSUFBSSxDQUFDLElBQUksT0FBTyxRQUFPO0dBQ3hCOztFQUVELGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFO0lBQ2pDLElBQUksTUFBTSxjQUFjLElBQUksQ0FBQyxhQUFhO1FBQ3RDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxVQUFVO1FBQ25DLElBQUksZ0JBQWdCLElBQUksQ0FBQyxLQUFLO1FBQzlCLFNBQVE7O0lBRVosSUFBSSxPQUFPLENBQUMsR0FBRyxLQUFLLElBQUksS0FBSyxZQUFZLElBQUksSUFBSSxLQUFLLFdBQVcsQ0FBQyxFQUFFO01BQ2xFLGlCQUFpQixHQUFHLElBQUksS0FBSyxXQUFXO1VBQ3BDLFFBQVE7VUFDUixNQUFLO01BQ1QsSUFBSSxDQUFDLFVBQVUsR0FBRyxrQkFBaUI7S0FDcEM7U0FDSTtNQUNILElBQUksSUFBSSxLQUFLLFNBQVMsWUFBWSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFDO1dBQ3hFLElBQUksSUFBSSxLQUFLLFdBQVcsS0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBQzt3Q0FDakQsSUFBSSxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFDOztNQUVwRSxJQUFJLElBQUksS0FBSyxXQUFXLFVBQVUsSUFBSSxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxRQUFRLEVBQUM7V0FDL0UsSUFBSSxJQUFJLEtBQUssWUFBWSxJQUFJLElBQUksSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBQzt3Q0FDeEQsSUFBSSxJQUFJLEdBQUcsR0FBRyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBQzs7TUFFM0UsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFJOztNQUVqQixJQUFJLE9BQU8sQ0FBQyxLQUFLLEtBQUssSUFBSSxLQUFLLFlBQVksSUFBSSxJQUFJLEtBQUssV0FBVyxDQUFDLEVBQUU7UUFDcEUsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLFFBQVEsRUFBRSxJQUFJLEtBQUssWUFBWSxFQUFDO1FBQ2pFLElBQUksQ0FBQyxhQUFhLEdBQUcsT0FBTTtPQUM1QjtLQUNGOztJQUVELE9BQU87TUFDTCxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxFQUFFLElBQUk7S0FDMUM7R0FDRjs7RUFFRCxjQUFjLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLGlCQUFpQixDQUFDLEVBQUU7SUFDaEQsSUFBSSxNQUFNLElBQUksQ0FBQyxFQUFFLE1BQU0sR0FBRyxJQUFJLENBQUMsY0FBYTtJQUM1QyxJQUFJLGlCQUFpQixJQUFJLE1BQU0sRUFBRSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsV0FBVTs7SUFFcEUsT0FBTyxDQUFDO2lCQUNLLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQzs7WUFFbEIsRUFBRSxpQkFBaUIsQ0FBQztpQkFDZixFQUFFLElBQUksQ0FBQzs7bUJBRUwsRUFBRSxNQUFNLENBQUM7SUFDeEIsQ0FBQztHQUNGOztFQUVELEtBQUssQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLFNBQVMsR0FBRyxLQUFLLEVBQUU7SUFDcEMsSUFBSSxTQUFTLEVBQUU7TUFDYixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUM7UUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFDO0tBQzlCO1NBQ0ksSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztNQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUM7O0lBRTdCLE9BQU8sS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztHQUN6QjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLFlBQVksQ0FBQzs7QUNqRjdDLE1BQU0sZUFBZSxTQUFTLFNBQVMsQ0FBQztFQUM3QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFDO0lBQ25DLElBQUksQ0FBQyxJQUFJLFNBQVMsV0FBVTtHQUM3Qjs7RUFFRCxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLENBQUMsRUFBRTtJQUNqQyxJQUFJLE1BQU0sZ0JBQWdCLE9BQU8sQ0FBQyxLQUFLLEdBQUcsRUFBRSxHQUFHLEVBQUM7SUFDaEQsSUFBSSxRQUFRLGNBQWMsc0JBQXFCO0lBQy9DLElBQUksaUJBQWlCLEtBQUssS0FBSTtJQUM5QixJQUFJLElBQUksa0JBQWtCLGNBQWE7OztJQUd2QyxJQUFJLE9BQU8sQ0FBQyxHQUFHLEVBQUU7TUFDZixJQUFJLEVBQUUsTUFBSzs7TUFFWCxJQUFJLElBQUksS0FBSyxXQUFXO1FBQ3RCLFFBQVEsSUFBSSxXQUFVO01BQ3hCLElBQUksSUFBSSxLQUFLLFNBQVM7UUFDcEIsUUFBUSxJQUFJLFdBQVU7S0FDekI7U0FDSSxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxLQUFLLFlBQVksRUFBRTtNQUN0RCxJQUFJLEdBQUcsYUFBWTs7TUFFbkIsSUFBSSxJQUFJLEtBQUssV0FBVztRQUN0QixRQUFRLElBQUksV0FBVTtNQUN4QixJQUFJLElBQUksS0FBSyxZQUFZO1FBQ3ZCLFFBQVEsSUFBSSxXQUFVO0tBQ3pCOztTQUVJLElBQUksSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssV0FBVyxFQUFFO01BQ25ELElBQUksR0FBRyxZQUFXOztNQUVsQixJQUFJLElBQUksS0FBSyxXQUFXO1FBQ3RCLFFBQVEsSUFBSSxXQUFVO01BQ3hCLElBQUksSUFBSSxLQUFLLFNBQVM7UUFDcEIsUUFBUSxJQUFJLFdBQVU7S0FDekI7O0lBRUQsT0FBTztNQUNMLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxNQUFNLEVBQUUsSUFBSTtLQUMxQztHQUNGOztFQUVELGNBQWMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUU7SUFDMUQsSUFBSSxRQUFRLEtBQUssQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQztNQUM5QixRQUFRLEdBQUcsc0JBQXFCO0lBQ2xDLElBQUksaUJBQWlCLEtBQUssTUFBTTtNQUM5QixpQkFBaUIsR0FBRyxPQUFNOztJQUU1QixPQUFPLENBQUM7cUJBQ1MsRUFBRSxRQUFRLENBQUM7c0JBQ1YsRUFBRSxJQUFJLENBQUM7a0JBQ1gsRUFBRSxpQkFBaUIsQ0FBQzttQkFDbkIsRUFBRSxNQUFNLENBQUM7SUFDeEIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxlQUFlLENBQUM7O0FDOURuRCxNQUFNLGdCQUFnQixTQUFTLFNBQVMsQ0FBQztFQUM5QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFDO0lBQ25DLElBQUksQ0FBQyxJQUFJLFNBQVMsWUFBVztHQUM5Qjs7RUFFRCxpQkFBaUIsR0FBRyxFQUFFOztFQUV0QixJQUFJLEdBQUc7SUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU07R0FDekM7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Ozs7WUFJVixFQUFFQSxTQUFJLENBQUM7WUFDUCxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7Ozs7Ozs7SUFPckIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRSxnQkFBZ0IsQ0FBQzs7QUNqQ3JELE1BQU0sZUFBZSxTQUFTLFNBQVMsQ0FBQztFQUM3QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFDO0lBQ2xDLElBQUksQ0FBQyxJQUFJLFNBQVMsV0FBVTtHQUM3Qjs7RUFFRCxpQkFBaUIsR0FBRyxFQUFFOztFQUV0QixJQUFJLEdBQUc7SUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU07R0FDekM7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Ozs7WUFJVixFQUFFQSxRQUFJLENBQUM7WUFDUCxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7Ozs7Ozs7SUFPckIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxlQUFlLENBQUM7O0FDbENuRCxNQUFNLFdBQVcsU0FBUyxTQUFTLENBQUM7RUFDekMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxPQUFPLE1BQU0sSUFBRztJQUNyQixJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBQztJQUNuQyxJQUFJLENBQUMsSUFBSSxTQUFTLE9BQU07R0FDekI7O0VBRUQsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUU7SUFDakMsSUFBSSxNQUFNLGdCQUFnQixPQUFPLENBQUMsS0FBSyxHQUFHLEVBQUUsR0FBRyxFQUFDO0lBQ2hELElBQUksUUFBUSxjQUFjLHNCQUFxQjtJQUMvQyxJQUFJLGlCQUFpQixLQUFLLEtBQUk7SUFDOUIsSUFBSSxJQUFJLGtCQUFrQixjQUFhOzs7SUFHdkMsSUFBSSxPQUFPLENBQUMsS0FBSyxLQUFLLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxLQUFLLFlBQVksQ0FBQyxFQUFFO01BQ3BFLElBQUksTUFBTSxVQUFTO01BQ25CLE1BQU0sSUFBSSxNQUFLOztNQUVmLElBQUksSUFBSSxLQUFLLFdBQVc7UUFDdEIsUUFBUSxJQUFJLFdBQVU7TUFDeEIsSUFBSSxJQUFJLEtBQUssWUFBWTtRQUN2QixRQUFRLElBQUksV0FBVTtLQUN6Qjs7U0FFSSxJQUFJLE9BQU8sQ0FBQyxLQUFLLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssV0FBVyxDQUFDLEVBQUU7TUFDdEUsSUFBSSxNQUFNLFVBQVM7TUFDbkIsTUFBTSxJQUFJLE1BQUs7O01BRWYsSUFBSSxJQUFJLEtBQUssU0FBUztRQUNwQixRQUFRLElBQUksV0FBVTtNQUN4QixJQUFJLElBQUksS0FBSyxXQUFXO1FBQ3RCLFFBQVEsSUFBSSxXQUFVO0tBQ3pCOztTQUVJLElBQUksT0FBTyxDQUFDLEdBQUcsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLElBQUksS0FBSyxXQUFXLENBQUMsRUFBRTtNQUNwRSxJQUFJLGtCQUFrQixjQUFhO01BQ25DLE1BQU0sZ0JBQWdCLEdBQUU7TUFDeEIsaUJBQWlCLEtBQUssR0FBRTs7TUFFeEIsSUFBSSxJQUFJLEtBQUssU0FBUztRQUNwQixRQUFRLElBQUksV0FBVTtNQUN4QixJQUFJLElBQUksS0FBSyxXQUFXO1FBQ3RCLFFBQVEsSUFBSSxXQUFVO0tBQ3pCOztTQUVJLElBQUksSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssV0FBVyxFQUFFO01BQ25ELElBQUksTUFBTSxZQUFXO01BQ3JCLE1BQU0sSUFBSSxNQUFLOztNQUVmLElBQUksSUFBSSxLQUFLLFNBQVM7UUFDcEIsUUFBUSxJQUFJLFdBQVU7TUFDeEIsSUFBSSxJQUFJLEtBQUssV0FBVztRQUN0QixRQUFRLElBQUksV0FBVTtLQUN6Qjs7U0FFSSxJQUFJLElBQUksS0FBSyxZQUFZLElBQUksSUFBSSxLQUFLLFdBQVcsRUFBRTtNQUN0RCxJQUFJLGtCQUFrQixpQkFBZ0I7TUFDdEMsTUFBTSxnQkFBZ0IsR0FBRTtNQUN4QixRQUFRLGNBQWMsU0FBUTtNQUM5QixpQkFBaUIsS0FBSyxHQUFFO0tBQ3pCOztJQUVELE9BQU87TUFDTCxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxFQUFFLElBQUk7S0FDMUM7R0FDRjs7RUFFRCxjQUFjLENBQUMsQ0FBQyxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLE1BQU0sQ0FBQyxFQUFFO0lBQzFELElBQUksUUFBUSxLQUFLLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUM7TUFDOUIsUUFBUSxHQUFHLHNCQUFxQjtJQUNsQyxJQUFJLGlCQUFpQixLQUFLLE1BQU07TUFDOUIsaUJBQWlCLEdBQUcsT0FBTTs7SUFFNUIsT0FBTyxDQUFDO3FCQUNTLEVBQUUsUUFBUSxDQUFDO3NCQUNWLEVBQUUsSUFBSSxDQUFDO2tCQUNYLEVBQUUsaUJBQWlCLENBQUM7bUJBQ25CLEVBQUUsTUFBTSxDQUFDO0lBQ3hCLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLFdBQVcsQ0FBQzs7QUNwRjNDLE1BQU0sV0FBVyxTQUFTLFNBQVMsQ0FBQztFQUN6QyxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLE9BQU8sTUFBTSxJQUFHO0lBQ3JCLElBQUksQ0FBQyxTQUFTLElBQUksR0FBRTtJQUNwQixJQUFJLENBQUMsSUFBSSxTQUFTLE9BQU07R0FDekI7O0VBRUQsaUJBQWlCLEdBQUcsRUFBRTs7RUFFdEIsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFNO0dBQ3pDOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQztNQUNOLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDOzs7O1lBSVYsRUFBRUEsSUFBSSxDQUFDO1lBQ1AsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDOzs7Ozs7O0lBT3JCLENBQUM7R0FDRjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLFdBQVc7O2tEQUFDLGxEQ2pDM0MsTUFBTSxhQUFhLFNBQVMsU0FBUyxDQUFDO0VBQzNDLFdBQVcsR0FBRztJQUNaLEtBQUssR0FBRTs7SUFFUCxJQUFJLENBQUMsT0FBTyxNQUFNLElBQUc7SUFDckIsSUFBSSxDQUFDLFNBQVMsSUFBSSxHQUFFO0lBQ3BCLElBQUksQ0FBQyxJQUFJLFNBQVMsU0FBUTtHQUMzQjs7RUFFRCxpQkFBaUIsR0FBRyxFQUFFOztFQUV0QixJQUFJLEdBQUc7SUFDTCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU07R0FDekM7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Ozs7WUFJVixFQUFFQSxNQUFJLENBQUM7WUFDUCxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7Ozs7Ozs7SUFPckIsQ0FBQztHQUNGO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhOztzREFBQyx0RENuQi9DLE1BQU0sT0FBTyxTQUFTLFdBQVcsQ0FBQzs7RUFFdkMsV0FBVyxHQUFHO0lBQ1osS0FBSyxHQUFFOztJQUVQLElBQUksQ0FBQyxRQUFRLEdBQUc7TUFDZCxNQUFNLFVBQVUsUUFBUSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQztNQUN4RCxTQUFTLE9BQU8sUUFBUSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQztNQUMzRCxhQUFhLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyx1QkFBdUIsQ0FBQztNQUMvRCxJQUFJLFlBQVksUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUM7TUFDdEQsTUFBTSxVQUFVLFFBQVEsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUM7TUFDeEQsT0FBTyxTQUFTLFFBQVEsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUM7TUFDekQsS0FBSyxXQUFXLFFBQVEsQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDO01BQ3ZELFFBQVEsUUFBUSxRQUFRLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDO01BQzFELFNBQVMsT0FBTyxRQUFRLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDO01BQzNELFFBQVEsUUFBUSxRQUFRLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDO01BQzFELElBQUksWUFBWSxRQUFRLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQztNQUN0RCxJQUFJLFlBQVksUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUM7TUFDdEQsTUFBTSxVQUFVLFFBQVEsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUM7TUFDekQ7O0lBRUQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUk7TUFDdkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBQztHQUMxQjs7RUFFRCxpQkFBaUIsR0FBRztJQUNsQixPQUFPLENBQUMsU0FBUyxFQUFFLENBQUM7TUFDbEIsSUFBSSxDQUFDLFFBQVE7VUFDVCxJQUFJLENBQUMsUUFBUSxFQUFFO1VBQ2YsSUFBSSxDQUFDLFFBQVEsRUFBRSxFQUFDOztJQUV0QixPQUFPLENBQUMsS0FBSyxFQUFFLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFLEVBQUM7R0FDckM7O0VBRUQsb0JBQW9CLEdBQUcsRUFBRTs7RUFFekIsUUFBUSxHQUFHO0lBQ1QsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsTUFBTTtJQUMxQixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksR0FBRTtJQUNwQixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUk7R0FDckI7O0VBRUQsUUFBUSxHQUFHO0lBQ1QsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUTtNQUMzQixDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxFQUFDO0lBQ2xDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFFO0dBQ3JCO0NBQ0Y7O0FBRUQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsT0FBTzs7NENBQUMsNUNDOUQ1QztBQUNBLE1BQU0sVUFBVSxHQUFHLG9CQUFvQjtHQUNwQyxLQUFLLENBQUMsR0FBRyxDQUFDO0dBQ1YsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUs7SUFDcEIsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkUsRUFBRSxDQUFDO0dBQ0osU0FBUyxDQUFDLENBQUMsRUFBQzs7QUFFZixNQUFNLGNBQWMsR0FBRyxDQUFDLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLFdBQVcsRUFBQzs7QUFFaEcsQUFBTyxTQUFTLE1BQU0sQ0FBQyxRQUFRLEVBQUU7RUFDL0IsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDbEMsSUFBSSxDQUFDLENBQUMsWUFBWSxFQUFFLE1BQU07O0lBRTFCLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsV0FBVyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFDO0dBQ3RDLEVBQUM7O0VBRUYsT0FBTyxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDdEMsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixtQkFBbUIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBQztHQUM5QyxFQUFDOztFQUVGLE9BQU8sTUFBTTtJQUNYLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFDO0lBQzFCLE9BQU8sQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFDO0lBQzlCLE9BQU8sQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUM7R0FDckM7Q0FDRjs7QUFFRCxBQUFPLFNBQVMsV0FBVyxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDMUMsR0FBRztLQUNBLEdBQUcsQ0FBQyxFQUFFLElBQUksZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDL0IsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLEtBQUssUUFBUSxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUM7TUFDdkMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLFFBQVEsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7TUFDbkUsTUFBTSxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDO01BQ3pELFFBQVEsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7S0FDL0MsQ0FBQyxDQUFDO0tBQ0YsR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixNQUFNLEVBQUUsT0FBTyxDQUFDLFFBQVE7WUFDcEIsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTTtZQUNoQyxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxNQUFNO09BQ3JDLENBQUMsQ0FBQztLQUNKLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUM7TUFDM0IsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTSxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFDO0NBQ3REOztBQUVELEFBQU8sU0FBUyxtQkFBbUIsQ0FBQyxHQUFHLEVBQUUsVUFBVSxFQUFFO0VBQ25ELE1BQU0sS0FBSyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFDO0VBQ25DLElBQUksS0FBSyxHQUFHLEdBQUU7O0VBRWQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEtBQUssR0FBRyxRQUFRLEdBQUcsTUFBSztFQUN0RCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxHQUFHLE1BQU0sR0FBRyxNQUFLOztFQUVwRCxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0tBQzVCLE9BQU8sQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDLEdBQUcsRUFBRSxLQUFLLEdBQUcsSUFBSSxDQUFDLEVBQUM7Q0FDbkQ7O0FDM0RELE1BQU1DLFlBQVUsR0FBRyxxQkFBb0I7OztBQUd2QyxBQUFPLFNBQVMsUUFBUSxDQUFDLFFBQVEsRUFBRTtFQUNqQyxPQUFPLENBQUNBLFlBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLO0lBQ2hDLElBQUksQ0FBQyxDQUFDLFlBQVksRUFBRSxNQUFNOztJQUUxQixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLENBQUMsQ0FBQyxlQUFlLEdBQUU7O0lBRW5CLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxJQUFJO01BQ3hCLFdBQVcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFDO01BQ3BCLGNBQWMsQ0FBQyxFQUFFLEVBQUM7S0FDbkIsRUFBQztHQUNILEVBQUM7O0VBRUYsT0FBTyxNQUFNO0lBQ1gsT0FBTyxDQUFDLE1BQU0sQ0FBQ0EsWUFBVSxFQUFDO0dBQzNCO0NBQ0Y7O0FBRUQsQUFBTyxTQUFTLFdBQVcsQ0FBQyxFQUFFLEVBQUUsU0FBUyxFQUFFO0VBQ3pDLElBQUksQ0FBQyxFQUFFLEVBQUUsTUFBTTs7RUFFZixPQUFPLFNBQVM7SUFDZCxLQUFLLE1BQU07TUFDVCxJQUFJLFdBQVcsQ0FBQyxFQUFFLENBQUM7UUFDakIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxzQkFBc0IsRUFBQzs7UUFFekQsUUFBUSxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUM7TUFDekIsS0FBSzs7SUFFUCxLQUFLLE9BQU87TUFDVixJQUFJLFlBQVksQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsa0JBQWtCLENBQUMsV0FBVztRQUN2RCxFQUFFLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsRUFBQztXQUM5RCxJQUFJLFlBQVksQ0FBQyxFQUFFLENBQUM7UUFDdkIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsRUFBRSxFQUFDOztRQUU3QixRQUFRLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBQztNQUN6QixLQUFLOztJQUVQLEtBQUssSUFBSTtNQUNQLElBQUksU0FBUyxDQUFDLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFDO01BQ2QsS0FBSzs7SUFFUCxLQUFLLE1BQU07TUFDVCxJQUFJLFlBQVksQ0FBQyxFQUFFLENBQUM7UUFDbEIsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBQztXQUN0QixJQUFJLFdBQVcsQ0FBQyxFQUFFLENBQUM7UUFDdEIsRUFBRSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUM7TUFDbkMsS0FBSztHQUNSO0NBQ0Y7O0FBRUQsQUFBTyxNQUFNLFdBQVcsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDLHVCQUFzQjtBQUM3RCxBQUFPLE1BQU0sWUFBWSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsbUJBQWtCO0FBQ3pELEFBQU8sTUFBTSxXQUFXLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxrQkFBa0IsSUFBSSxFQUFFLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLE9BQU07QUFDbEcsQUFBTyxNQUFNLFlBQVksS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsa0JBQWtCLElBQUksRUFBRSxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUMsVUFBVSxDQUFDLFdBQVU7QUFDdkcsQUFBTyxNQUFNLFNBQVMsUUFBUSxFQUFFLElBQUksRUFBRSxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUMsVUFBVSxDQUFDLFdBQVU7O0FBRTdFLEFBQU8sTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEdBQUcsS0FBSyxDQUFDO0VBQ3hDLEVBQUUsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFO0lBQ3RDLEVBQUUsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLFFBQVE7TUFDL0IsS0FBSztVQUNELFlBQVksQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDO1VBQ3BCLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDOztBQUU1QixBQUFPLFNBQVMsY0FBYyxDQUFDLEVBQUUsRUFBRTtFQUNqQyxJQUFJLE9BQU8sR0FBRyxHQUFFOztFQUVoQixJQUFJLFdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLElBQUksSUFBRztFQUNwQyxJQUFJLFlBQVksQ0FBQyxFQUFFLENBQUMsRUFBRSxPQUFPLElBQUksSUFBRztFQUNwQyxJQUFJLFdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLElBQUksSUFBRztFQUNwQyxJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsS0FBSyxPQUFPLElBQUksSUFBRzs7RUFFcEMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxrQkFBa0IsRUFBQzs7O0NBQzFELERDOUVELElBQUksSUFBSSxRQUFRLEVBQUU7SUFDZCxRQUFRLElBQUksR0FBRTs7QUFFbEIsQUFBTyxTQUFTLG9CQUFvQixHQUFHO0VBQ3JDLElBQUksR0FBRyxDQUFDLENBQUM7SUFDUCxHQUFHLFFBQVEsQ0FBQyxNQUFNO0lBQ2xCLEdBQUcsb0JBQW9CLENBQUMsUUFBUSxDQUFDO0dBQ2xDLEVBQUM7O0VBRUYsYUFBYSxDQUFDLElBQUksRUFBQztFQUNuQixZQUFZLENBQUMsSUFBSSxFQUFDO0NBQ25COztBQUVELE1BQU0sWUFBWSxHQUFHLElBQUksSUFBSTtFQUMzQixJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRSxXQUFXLEVBQUM7RUFDaEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFDO0VBQ2pDLElBQUksQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBQztFQUN2QixDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFDO0VBQzVDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUM7RUFDN0MsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBQztFQUNwQzs7QUFFRCxNQUFNLGFBQWEsR0FBRyxJQUFJLElBQUk7RUFDNUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFDO0VBQ2xDLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBQztFQUNsQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUM7RUFDeEIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBQztFQUM5QyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFDO0VBQzlDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUM7RUFDcEMsSUFBSSxHQUFHLEdBQUU7RUFDVjs7QUFFRCxNQUFNLFdBQVcsR0FBRyxJQUFJLElBQUk7RUFDMUIsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEtBQUs7SUFDdEMsSUFBSSxNQUFNLEdBQUcsSUFBSSxVQUFVLEdBQUU7SUFDN0IsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUM7SUFDMUIsTUFBTSxDQUFDLFNBQVMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFDO0dBQ2hELENBQUM7RUFDSDs7QUFFRCxNQUFNLFdBQVcsR0FBRyxDQUFDLElBQUk7RUFDdkIsQ0FBQyxDQUFDLGNBQWMsR0FBRTtFQUNsQixNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMseUJBQXlCLEVBQUM7O0VBRWpELElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTTtJQUN0QixXQUFXLENBQUMsQ0FBQyxDQUFDLGFBQWEsRUFBRSxDQUFDLEVBQUM7O0lBRS9CLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztNQUMxQixXQUFXLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFDO0VBQ3pCOztBQUVELE1BQU0sV0FBVyxHQUFHLENBQUM7RUFDbkIsWUFBWSxHQUFFOztBQUVoQixNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsSUFBSTtFQUN4QixDQUFDLENBQUMsZUFBZSxHQUFFO0VBQ25CLENBQUMsQ0FBQyxjQUFjLEdBQUU7O0VBRWxCLE1BQU0sY0FBYyxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsRUFBQzs7RUFFbkQsTUFBTSxJQUFJLEdBQUcsTUFBTSxPQUFPLENBQUMsR0FBRztJQUM1QixDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUM7O0VBRTdDLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTTtJQUN4QixJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLEtBQUs7TUFDN0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMsRUFBQzs7TUFFdEIsSUFBSTtTQUNELE1BQU0sQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDckMsT0FBTyxDQUFDLEdBQUc7VUFDVixHQUFHLENBQUMsS0FBSyxDQUFDLGVBQWUsR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUM7T0FDakQsSUFBSSxjQUFjLENBQUMsTUFBTSxFQUFFO0lBQzlCLElBQUksQ0FBQyxHQUFHLEVBQUM7SUFDVCxjQUFjLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSTtNQUM1QixHQUFHLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLEVBQUUsRUFBQztNQUNuQixJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxFQUFDO0tBQzVCLEVBQUM7R0FDSDs7RUFFRCxZQUFZLEdBQUU7RUFDZjs7QUFFRCxNQUFNLFdBQVcsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUs7RUFDL0IsTUFBTSxJQUFJLE1BQU0sSUFBSSxDQUFDLHFCQUFxQixHQUFFO0VBQzVDLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQUM7O0VBRTNCLElBQUksT0FBTyxFQUFFO0lBQ1gsT0FBTyxDQUFDLE1BQU0sR0FBRyxLQUFJO0dBQ3RCO09BQ0k7SUFDSCxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUM7SUFDbEQsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxLQUFJO0lBQzNCLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBQztHQUN2QztFQUNGOztBQUVELE1BQU0sWUFBWSxHQUFHLE1BQU07RUFDekIsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPO0lBQ3RCLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBQztFQUNuQixRQUFRLEdBQUcsR0FBRTtFQUNkOztBQUVELE1BQU0sb0JBQW9CLEdBQUcsRUFBRSxJQUFJO0VBQ2pDLE1BQU0sU0FBUyxHQUFHLDJDQUEwQzs7RUFFNUQsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxFQUFFLElBQUksS0FBSztJQUN6QyxNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSSxFQUFFLGtCQUFrQixFQUFDO0lBQy9DLE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDOzs7SUFHbEMsSUFBSSxLQUFLLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUM7O0lBRWhDLE9BQU8sVUFBVTtHQUNsQixFQUFFLEVBQUUsQ0FBQzs7O0NBQ1AsRENsSEQsSUFBSSxlQUFjOzs7QUFHbEIsTUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUM7QUFDakQsV0FBVyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFDO0FBQ25DLFdBQVcsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxzRUFBc0UsRUFBQzs7QUFFaEcsTUFBTUMsUUFBTSxVQUFVLENBQUMsQ0FBQyxXQUFXLEVBQUM7QUFDcEMsTUFBTSxXQUFXLEtBQUssQ0FBQyxDQUFDLE9BQU8sRUFBRSxXQUFXLEVBQUM7O0FBRTdDLE1BQU0sYUFBYSxHQUFHLE1BQU1BLFFBQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLGVBQWUsRUFBQztBQUNqRSxNQUFNLGFBQWEsR0FBRyxNQUFNQSxRQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxjQUFjLEVBQUM7QUFDaEUsTUFBTSxZQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksUUFBUSxJQUFJLENBQUMsQ0FBQyxlQUFlLEdBQUU7O0FBRW5FLEFBQU8sU0FBUyxNQUFNLENBQUMsSUFBSSxFQUFFO0VBQzNCLElBQUksSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUNBLFFBQU0sQ0FBQyxDQUFDLENBQUMsRUFBQzs7RUFFeEMsTUFBTSxPQUFPLEdBQUcsQ0FBQyxJQUFJO0lBQ25CLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsQ0FBQyxDQUFDLGVBQWUsR0FBRTs7SUFFbkIsTUFBTSxLQUFLLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFLOztJQUU1QixNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQztNQUMxQixTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUM7SUFDcEI7O0VBRUQsV0FBVyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsT0FBTyxFQUFDO0VBQ2hDLFdBQVcsQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFLFlBQVksRUFBQzs7O0VBR3ZDLGFBQWEsR0FBRTtFQUNmLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUU7Ozs7Ozs7RUFPdEIsT0FBTyxNQUFNO0lBQ1gsYUFBYSxHQUFFO0lBQ2YsV0FBVyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFDO0lBQ25DLFdBQVcsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLFlBQVksRUFBQztJQUN4QyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxhQUFhLEVBQUM7R0FDdkM7Q0FDRjs7QUFFRCxBQUFPLFNBQVMscUJBQXFCLENBQUMsTUFBTSxFQUFFO0VBQzVDLGNBQWMsR0FBRyxPQUFNO0NBQ3hCOztBQUVELEFBQU8sU0FBUyxTQUFTLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtFQUNuQyxJQUFJLEtBQUssSUFBSSxPQUFPLE1BQU0sS0FBSyxHQUFHLElBQUc7RUFDckMsSUFBSSxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssR0FBRyxTQUFRO0VBQzFDLElBQUksS0FBSyxJQUFJLFFBQVEsS0FBSyxLQUFLLEdBQUcsTUFBSztFQUN2QyxJQUFJLEtBQUssSUFBSSxNQUFNLE9BQU8sS0FBSyxHQUFHLHlEQUF3RDs7RUFFMUYsSUFBSSxDQUFDLEtBQUssRUFBRSxPQUFPLGNBQWMsQ0FBQyxZQUFZLEVBQUU7RUFDaEQsSUFBSSxLQUFLLElBQUksR0FBRyxJQUFJLEtBQUssSUFBSSxHQUFHLElBQUksS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxNQUFNOztFQUV0RSxJQUFJO0lBQ0YsSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRywrRkFBK0YsRUFBQztJQUN4SCxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBQztJQUN2QyxJQUFJLENBQUMsRUFBRSxFQUFFLGNBQWMsQ0FBQyxZQUFZLEdBQUU7SUFDdEMsSUFBSSxPQUFPLENBQUMsTUFBTTtNQUNoQixPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7UUFDaEIsRUFBRTtZQUNFLEVBQUUsQ0FBQyxFQUFFLENBQUM7WUFDTixjQUFjLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFDO0dBQ25DO0VBQ0QsT0FBTyxHQUFHLEVBQUUsRUFBRTs7O0NBQ2YsRENsRU0sU0FBUyxVQUFVLEdBQUc7RUFDM0IsTUFBTSxRQUFRLFlBQVksQ0FBQyxDQUFDLE1BQU0sRUFBQztFQUNuQyxJQUFJLFFBQVEsY0FBYyxHQUFFO0VBQzVCLElBQUksaUJBQWlCLEtBQUssR0FBRTtFQUM1QixJQUFJLE1BQU0sZ0JBQWdCLEdBQUU7RUFDNUIsSUFBSSxPQUFPLGVBQWUsR0FBRTs7RUFFNUIsTUFBTSxNQUFNLEdBQUcsTUFBTTtJQUNuQixRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsRUFBQztJQUNwRSxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBRSxJQUFJLENBQUMsRUFBQztJQUMxRSxRQUFRLENBQUMsRUFBRSxDQUFDLGFBQWEsRUFBRSxZQUFZLEVBQUM7SUFDeEMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsUUFBUSxFQUFDO0lBQ2xDLFFBQVEsQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBQzs7SUFFcEMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUM7SUFDMUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUM7SUFDeEMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUM7O0lBRTVDLGVBQWUsR0FBRTs7SUFFakIsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsY0FBYyxFQUFDO0lBQzNDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxlQUFlLEVBQUUsRUFBQztJQUNuRCxPQUFPLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBQztJQUN0QixPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRSxZQUFZLEVBQUM7SUFDckMsT0FBTyxDQUFDLHNCQUFzQixFQUFFLFNBQVMsRUFBQztJQUMxQyxPQUFPLENBQUMsdUJBQXVCLEVBQUUsY0FBYyxFQUFDO0lBQ2hELE9BQU8sQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUUsbUJBQW1CLEVBQUM7SUFDL0QsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRSxRQUFRLEVBQUM7SUFDcEQsT0FBTyxDQUFDLGlDQUFpQyxFQUFFLHFCQUFxQixFQUFDO0lBQ2xFOztFQUVELE1BQU0sUUFBUSxHQUFHLE1BQU07SUFDckIsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLEVBQUM7SUFDdkUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLG1CQUFtQixDQUFDLFVBQVUsRUFBRSxXQUFXLEVBQUUsSUFBSSxDQUFDLEVBQUM7SUFDN0UsUUFBUSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsWUFBWSxFQUFDO0lBQ3pDLFFBQVEsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFFBQVEsRUFBQztJQUNuQyxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxXQUFXLEVBQUM7O0lBRXJDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFDO0lBQzdDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFDO0lBQzNDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFDOztJQUUvQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyw4Q0FBOEMsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsd0NBQXdDLENBQUMsRUFBQztJQUM5Szs7RUFFRCxNQUFNLFFBQVEsR0FBRyxDQUFDLElBQUk7SUFDcEIsSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNO01BQ3hFLE1BQU07O0lBRVIsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsZUFBZSxHQUFFO0lBQ2xDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLFlBQVksR0FBRTs7SUFFL0IsR0FBRyxDQUFDLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQztNQUNyRCxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLEVBQUM7O0lBRWxELE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDO0lBQ2pCOztFQUVELE1BQU0sUUFBUSxHQUFHLEVBQUUsSUFBSTs7SUFFckIsQ0FBQyxHQUFHLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQztPQUNwQixNQUFNLENBQUMsSUFBSTtVQUNSLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQzNDLE9BQU8sQ0FBQyxJQUFJO1VBQ1gsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFDOztJQUVwQixRQUFRLENBQUMsTUFBTSxDQUFDLElBQUk7TUFDbEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLENBQUM7T0FDekMsT0FBTyxDQUFDLElBQUk7UUFDWCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDO1VBQ1gsZUFBZSxPQUFPLElBQUk7VUFDMUIsb0JBQW9CLEVBQUUsSUFBSTtVQUMxQixlQUFlLE9BQU8sSUFBSTtVQUMxQixZQUFZLEVBQUUsSUFBSTtPQUNyQixDQUFDLEVBQUM7O0lBRUwsUUFBUSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxFQUFDOztJQUU3RSxZQUFZLEdBQUU7SUFDZjs7RUFFRCxNQUFNLFdBQVcsR0FBRyxDQUFDLElBQUk7SUFDdkIsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixDQUFDLENBQUMsZUFBZSxHQUFFO0lBQ25CLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxNQUFNO0lBQ2pDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFDO0lBQzFDOztFQUVELE1BQU0sZUFBZSxHQUFHLENBQUMsSUFBSTtJQUMzQixJQUFJLFFBQVEsR0FBRyxNQUFLOztJQUVwQixRQUFRLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQyxFQUFFO01BQy9CLElBQUksT0FBTyxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsTUFBTSxFQUFFO1FBQ25DLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1VBQ2xDLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU0sRUFBQzs7UUFFNUIsUUFBUSxHQUFHLEtBQUk7T0FDaEI7TUFDRjs7SUFFRCxRQUFRLENBQUMsT0FBTyxHQUFHLFNBQVMsQ0FBQyxFQUFFO01BQzdCLElBQUksUUFBUSxFQUFFO1FBQ1osQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUU7VUFDbEMsRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsSUFBSSxFQUFDOztRQUUxQixRQUFRLEdBQUcsTUFBSztPQUNqQjtNQUNGO0lBQ0Y7O0VBRUQsTUFBTSxNQUFNLEdBQUcsQ0FBQztJQUNkLFFBQVEsQ0FBQyxNQUFNLElBQUksWUFBWSxHQUFFOztFQUVuQyxNQUFNLFlBQVksR0FBRyxDQUFDLElBQUk7SUFDeEIsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFBQztJQUM3QixJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU07O0lBRXRCLE1BQU0sVUFBVSxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFDO0lBQzVDLFVBQVUsQ0FBQyxlQUFlLENBQUMsZUFBZSxFQUFDO0lBQzNDLFNBQVMsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLFVBQVUsRUFBRSxTQUFTLENBQUMsV0FBVyxFQUFDO0lBQ3BFLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbkI7O0VBRUQsTUFBTSxTQUFTLEdBQUcsQ0FBQztJQUNqQixRQUFRLENBQUMsTUFBTSxJQUFJLFVBQVUsR0FBRTs7RUFFakMsTUFBTSxjQUFjLEdBQUcsQ0FBQztJQUN0QixRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUU7TUFDakIsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLEVBQUM7O0VBRTNCLE1BQU0sT0FBTyxHQUFHLENBQUMsSUFBSTs7SUFFbkIsSUFBSSxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTTtNQUN6QyxNQUFNOztJQUVSLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFO01BQ3RELENBQUMsQ0FBQyxjQUFjLEdBQUU7TUFDbEIsSUFBSSxLQUFLLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUM7TUFDdkMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxlQUFlLEVBQUM7TUFDdEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsVUFBUztNQUNsQyxDQUFDLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBQztLQUN2RDtJQUNGOztFQUVELE1BQU0sTUFBTSxHQUFHLENBQUMsSUFBSTtJQUNsQixJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsY0FBYyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRTtNQUN0RCxJQUFJLEtBQUssR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksRUFBQztNQUN2QyxLQUFLLENBQUMsZUFBZSxDQUFDLGVBQWUsRUFBQztNQUN0QyxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQyxVQUFTO01BQ2xDLENBQUMsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFDO01BQ3RELFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUU7S0FDckI7SUFDRjs7RUFFRCxNQUFNLFFBQVEsR0FBRyxDQUFDLElBQUk7SUFDcEIsTUFBTSxRQUFRLEdBQUcsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFDO0lBQ3JELE1BQU0sYUFBYSxHQUFHLFFBQVEsSUFBSSxJQUFJLENBQUMsWUFBVztJQUNsRCxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxhQUFhLEVBQUU7TUFDaEMsQ0FBQyxDQUFDLGNBQWMsR0FBRTtNQUNsQixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVztRQUNyQixlQUFlLENBQUMsYUFBYSxDQUFDLEVBQUM7S0FDbEM7SUFDRjs7RUFFRCxNQUFNLGNBQWMsR0FBRyxDQUFDLElBQUk7SUFDMUIsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixJQUFJLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtNQUNsQyxTQUFTLENBQUMsRUFBRSxDQUFDLEVBQUM7SUFDakI7O0VBRUQsTUFBTSxlQUFlLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQztJQUNoQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsSUFBSTtNQUNyQixJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztTQUN0QixHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUM7VUFDakIsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLEVBQUM7O01BRTNCLEtBQUssSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sR0FBRyxDQUFDO1VBQ2xDLEtBQUssR0FBRyxDQUFDO1VBQ1QsS0FBSyxHQUFFO0tBQ1osRUFBQzs7RUFFSixNQUFNLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUs7SUFDeEMsQ0FBQyxDQUFDLGNBQWMsR0FBRTs7SUFFbEIsZUFBZSxDQUFDO01BQ2QsS0FBSyxHQUFHLHVCQUF1QixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUM1QyxHQUFHLEtBQUssR0FBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7S0FDOUIsRUFBQztJQUNIOztFQUVELE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUs7SUFDN0IsQ0FBQyxDQUFDLGNBQWMsR0FBRTs7SUFFbEIsSUFBSSxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUNwQyxJQUFJLFNBQVMsR0FBRyxDQUFDLEdBQUcsUUFBUSxFQUFDO01BQzdCLFlBQVksR0FBRTtNQUNkLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRSxJQUFJO1FBQ2hDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsT0FBTTtRQUMxQixPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtVQUM3QixJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBQztVQUNoRCxJQUFJLElBQUksQ0FBQyxRQUFRLEtBQUssT0FBTztZQUMzQixNQUFNLENBQUMsSUFBSSxFQUFDO1VBQ2QsRUFBRSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFDO1NBQzVCO1FBQ0QsRUFBRSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsRUFBRSxFQUFDO09BQzlCLEVBQUM7S0FDSDtTQUNJO01BQ0gsSUFBSSxHQUFHLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUM7TUFDdkMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPO1FBQzVCLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxLQUFLO1VBQ3JDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRSxFQUFDO1VBQ25CLE9BQU8sR0FBRztTQUNYLEVBQUUsR0FBRyxDQUFDO1FBQ1I7TUFDRCxZQUFZLEdBQUU7TUFDZCxNQUFNLENBQUMsR0FBRyxFQUFDO0tBQ1o7SUFDRjs7RUFFRCxNQUFNLFlBQVksR0FBRyxDQUFDO0lBQ3BCLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7T0FDbkIsUUFBUSxDQUFDLE1BQU07T0FDZixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVztPQUMvQyxDQUFDLENBQUMsY0FBYyxHQUFFOztFQUV2QixNQUFNLHFCQUFxQixHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUs7SUFDMUMsSUFBSSxRQUFRLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxNQUFNOztJQUVqQyxDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLENBQUMsQ0FBQyxlQUFlLEdBQUU7O0lBRW5CLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQUM7O0lBRTNCLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUN6QixJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksV0FBVyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQy9DLFlBQVksR0FBRTtRQUNkLE1BQU0sQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEVBQUM7T0FDN0I7TUFDRCxJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQy9DLFlBQVksR0FBRTtRQUNkLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFDO09BQzNCO0tBQ0Y7U0FDSTtNQUNILElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxZQUFZLENBQUMsT0FBTyxDQUFDLEVBQUU7UUFDaEQsWUFBWSxHQUFFO1FBQ2QsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsRUFBQztPQUM5QjtNQUNELElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxPQUFPLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRTtRQUNwRCxZQUFZLEdBQUU7UUFDZCxNQUFNLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBQztPQUM1QjtLQUNGO0lBQ0Y7O0VBRUQsTUFBTSxRQUFRLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0lBQzdCLElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxFQUFFLE1BQU07SUFDL0IsTUFBTSxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsSUFBSSxFQUFDO0lBQ3hDOztFQUVELE1BQU0sV0FBVyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztJQUNoQyxNQUFNLENBQUMsZUFBZSxDQUFDLFlBQVksRUFBQztJQUNyQzs7RUFFRCxNQUFNLE1BQU0sR0FBRyxFQUFFLElBQUk7SUFDbkIsRUFBRSxDQUFDLFlBQVksQ0FBQyxlQUFlLEVBQUUsSUFBSSxFQUFDO0lBQ3RDLGFBQWEsQ0FBQyxFQUFFLEVBQUM7SUFDakIsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUM7SUFDcEIsWUFBWSxHQUFFO0lBQ2Y7O0VBRUQsTUFBTSxZQUFZLEdBQUcsTUFBTTtJQUN6QixRQUFRO09BQ0wsT0FBTyxDQUFDLEVBQUU7UUFDVCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDO1VBQ1QsZUFBZSxPQUFPLElBQUk7VUFDMUIsb0JBQW9CLEVBQUUsSUFBSTtVQUMxQixlQUFlLE9BQU8sSUFBSTtVQUMxQixZQUFZLFVBQVUsSUFBSTtTQUMzQixDQUFDLEVBQUM7O0lBRVAsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQ2hCLEVBQUUsQ0FBQyxNQUFNLEVBQUUsRUFBQzs7SUFFZCxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUU7TUFDZixFQUFFLENBQUMsTUFBTSxFQUFFLEVBQUM7O0lBRWQsTUFBTSxNQUFNLEdBQUU7SUFDZCxPQUFPLEtBQUssR0FBRTtJQUNkLFFBQVEsSUFBSSxHQUFFO0lBQ2Y7O0VBRUQsTUFBTSxVQUFVLEdBQUcsTUFBTTtJQUN2QixNQUFNLHFCQUFxQixHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxJQUFJO01BQy9DLElBQUksWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLE9BQU8sWUFBWSxDQUFDLEVBQUUsQ0FBQztXQUM1QyxJQUFJLFdBQVcsQ0FBQyxFQUFFLENBQUMsRUFBRSxPQUFPLFdBQVcsQ0FBQyxFQUFFLENBQUM7V0FDM0MsSUFBSSxFQUFFLENBQUMsVUFBVSxJQUFJLE9BQU8sRUFBRSxDQUFDLFVBQVU7S0FDL0MsRUFBQzs7SUFFRixLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxRQUFRLEVBQUUsR0FBRyxNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQ3pELEVBQUUsQ0FBQyxNQUFNLEVBQUUsRUFBQzs7SUFFZCxNQUFNLE1BQU0sR0FBRTtJQUNkLE9BQU8sS0FBSyxHQUFFO0lBQ2QsUUFBUSxJQUFJLEdBQUU7O0lBRWQscUJBQXFCLENBQUMsT0FBTyxDQUFDLEVBQUU7TUFDOUIsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFDO0lBQ2Q7O0VBRUQsTUFBTSxlQUFlLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxHQUFHLEdBQUcsS0FBSyxDQUFDLEtBQUs7SUFDaEQsSUFBSSxHQUFHLEVBQUU7TUFDUCxNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLHVCQUF1QixFQUFDO01BQ3RELFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFDO0tBQzVCO1NBQ0k7TUFDSCxNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFDO01BQzNCLElBQUksQ0FBQyxVQUFVLEVBQUUsTUFBTTs7TUFFdkIsTUFBTSxlQUFlLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUN2RCx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLO1lBQ2xDLEtBQUssR0FBRyxDQUFDO1lBQ1QsS0FBSztRQUNULElBQUksRUFBQzs7TUFFUCxJQUFJLGVBQWUsS0FBSyxJQUFJLEVBQUU7UUFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxDQUFDLEVBQUU7VUFDcEMsTUFBTSxTQUFTLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDO1VBQ3ZFLElBQUksU0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTLEVBQUM7U0FDakM7YUFDSTtVQUNILE1BQU0sQ0FBQyxVQUFVLENBQUMsZUFBZSxHQUFHLENBQUMsQ0FBQyxFQUFDO1NBQ3hDO09BQ0Y7S0FDRjtJQUNGOztFQUVELE1BQU0sdUJBQXVCLEdBQUcsSUFBSTtJQUNsQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxFQUFFLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFDOztFQUUxRCxNQUFNLGFBQWEsR0FBRyxFQUFFLElBQUk7SUFDMUIsSUFBSSxNQUFNLEdBQUcsWUFBWSxDQUFDLEVBQUUsRUFBQztJQUM3QixJQUFJLEtBQUssSUFBSSxXQUFXLENBQUMsRUFBRSxFQUFFLENBQUM7U0FDekIsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQzVCLEVBQUUsRUFBRSxDQUFDLEVBQUUsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQztNQUMxQixFQUFFLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO1NBQzdCLE1BQU0sQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUUsQ0FBQztTQUMxQixNQUFNLENBQUMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxLQUFLLENBQUM7VUFDeEIsRUFBRSxLQUFLLENBQUM7Y0FDSixFQUFFLElBQUksQ0FBQztRQUNiLENBQUMsRUFBRSxFQUFFLENBQUM7T0FDUDtJQUNILENBQUMsRUFBQzs7SUFFRixJQUFJLFFBQVEsVUFBVSxjQUFjLENBQUMsRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFDO0lBQ3hELElBQUksY0FBYyxJQUFJLGNBQWMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUM7O0lBRXhELFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBRSxFQUFDO0lBQzFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRSxFQUFFLFNBQVMsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxFQUFDOztJQUV2RSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLGdCQUFnQixFQUFFLENBQUMsSUFBSTtNQUNqQyxRQUFRLENBQUMsVUFBVSxHQUFFO01BQ3JCLGNBQWMsQ0FBQyxVQUFVLEdBQUU7S0FDNUIsRUFBQztJQUNIOztFQUVELE1BQU0sUUFBUSxHQUFHLENBQUMsRUFBRSxFQUFFLEtBQUs7SUFDekIsS0FBSyxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUMscUJBQXFCLEdBQUU7O0VBRTNDLE1BQU0sV0FBVyxHQUFHLENBQUMsRUFBRSxFQUFFLElBQUksS0FBSztJQUNoQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsRUFBRTtNQUN2RCxNQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLFVBQVUsRUFBQzs7TUFFaEQsS0FBSyxDQUFDLElBQUksR0FBRyxLQUFJO01BQ2pCLEtBQUssQ0FBQyxRQUFRLEdBQUc7UUFDZixZQUFZLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFO1FBQzFDLGFBQWEsR0FBRyxNQUFNLENBQUMsTUFBTTtRQUM5QjtNQUNELEVBQUUsQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxNQUFNLEVBQUM7O01BRS9DLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBQzs7TUFFaEMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO1FBQ2pDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLE1BQU07UUFDeEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsS0FBSTs7UUFFN0IsU0FBUyxDQUFDLGNBQWMsRUFBRSxFQUFFO1VBQzFCLEVBQUUsQ0FBQyxZQUFZLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxFQUFDOztRQUV0QyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyx1QkFBdUIsRUFBRSxFQUFFO1VBQ3JELE1BQU0sQ0FBQyxTQUFTLEtBQUssWUFBWTtjQUM3QixFQUFFLENBQUMsWUFBWSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUM7Y0FDbkMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFDO09BQ2xCLEVBQUM7O01BRUYsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxJQUFJO1FBQzdCLENBQUMsQ0FBQyxjQUFjLEdBQUU7UUFDbEIsQ0FBQyxDQUFDLGVBQWUsR0FBRTtRQUNuQixTQUFTLENBQUMsY0FBYyxFQUFFLEVBQUU7VUFDMUIsRUFBRSxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLEVBQUM7T0FDdkMsRUFBQzs7TUFFRixNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQUs7TUFDN0IsT0FBTyxLQUFLO0tBQ2I7SUFDRjs7RUFFRCxNQUFNLFlBQVksR0FBRyxFQUFFLElBQUk7SUFDekIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEVBQUU7TUFDeEQsTUFBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUM7O01BRW5ELE1BQU0sQ0FBQyxRQUFRLEdBQUc7UUFDaEIsWUFBWSxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRTtRQUMxQyxhQUFhLEdBQUcsT0FBTyxDQUFDLE1BQU07UUFDL0I7O01BRUQsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFDOztNQUVqQyxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE9BQU07TUFDaEMsT0FBTyxNQUFNO0tBQ2Q7SUFDRjs7RUFFRCxNQUFNLFNBQVMsR0FBRyxDQUFDLElBQUksRUFBRSxNQUFNLEtBQUs7SUFDbEMsTUFBTSxDQUFDLFFBQVEsR0FBRztNQUNoQixZQUFZLElBQUksSUFBSSxDQUFDLHFCQUFxQixFQUFFO01BQzVDLGFBQWEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQztNQUNuRDtJQUNGOztFQUVELE1BQU0sY0FBYyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztJQUMxQyxJQUFJLGdCQUFnQixDQUFDLElBQUksSUFBSTtNQUMzQixRQUFRLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBQztNQUNyQixTQUFTLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBQztLQUN4QixFQUFDOztFQUVKLE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQyxFQUFFLEVBQUUsaUJBQWlCLEdBQUcsSUFBSSxLQUFLO0lBQ3pELGlCQUFpQixDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUM7SUFDMUIsSUFBSSxpQkFBaUIsRUFBRSxFQUFFLENBQUMsUUFBUSxFQUFDO0lBQ3BDOztFQUVELE1BQU0sc0JBQXNCLEdBQUcsRUFBRTtJQUMvQixpQkFBaUIsR0FBRyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsUUFBUSxJQUFJLFFBQVEsSUFBSSxFQUFFLEVBQUM7O0VBRTFFLE1BQU0sWUFBWSxHQUFHO0lBQ25CLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFDOztFQUUvQyxNQUFNLFVBQVUsR0FBRyxNQUFNO0lBQ3ZCLFlBQVksR0FBRTtJQUNkLFFBQVEsR0FBRTtJQUNYOztFQUVELG9CQUFvQixHQUFFO0VBQ3RCLE1BQU0sR0FBRTs7RUFFUixPQUFPO0lBQ0wsTUFBTTtJQUNOLFlBQVk7SUFDWixnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLFVBQVU7R0FDWDtDQUNGOztBQ3BkRDtBQUNBLE1BQU1ELFlBQVUsR0FBRyxvQkFBb0I7R0FDcEMsS0FBSyxDQUFDLEdBQUcsQ0FBQztHQUNWLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLO0lBQ3BCLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25FLEVBQUUsQ0FBQztHQUNKLFNBQVMsQ0FBQyxDQUFDLEVBQUM7O0FBRWYsTUFBTUUsZ0JBQWMsR0FBRyxDQUFDLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLFdBQVcsRUFBQzs7QUFFaEcsQUFBTyxTQUFTLE9BQU8sQ0FBQyxRQUFRLEVBQUU7RUFDaEMsT0FBTyxDQUFDRixZQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ2xDLElBQUksQ0FBQyxDQUFDLFlBQVksRUFBRSxNQUFNOztJQUUxQixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLFVBQVUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBQztHQUNyQyxFQUFDOztFQUVGLE9BQU8sQ0FBQ0UsZ0JBQWMsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDdEMsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixrQkFBa0IsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBQztHQUM3QyxFQUFDOztFQUVGLE9BQU8sTUFBTTtJQUNYLE9BQU8sQ0FBQyxNQUFNLENBQUNGLFlBQVUsRUFBQztJQUMxQixPQUFPLENBQUMsTUFBTSxDQUFDRSxnQkFBYyxFQUFDO0lBQzlCLE9BQU8sQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUM7R0FDckM7Q0FDRjs7QUFFRCxBQUFPLFNBQVMsVUFBVSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDekMsR0FBRztLQUNBLEdBQUcsQ0FBQyxFQUFFLElBQUksZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDL0IsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLEtBQUssU0FBUyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUM7TUFDeEMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLFNBQVMsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7TUFDcEUsTUFBTSxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDO01BQ3pELFFBQVEsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7S0FDL0MsQ0FBQyxDQUFDO0tBQ0YsR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixPQUFPLEVBQUUsT0FBTyxDQUFDLFFBQVE7WUFDckIsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTTtZQUNoQyxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxNQUFNO09BQ3JDLENBQUMsQ0FBQztLQUNKLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUM7TUFDNUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFDO0NBQ3hEOztBQUVELEFBQU8sU0FBUyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsVUFBVSxFQUFFO0VBQ2xELE1BQU0sS0FBSyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFDO0VBQ25DLElBQUksS0FBSyxHQUFHLEdBQUU7O0VBRWQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEtBQUssR0FBRyxRQUFRLEdBQUcsTUFBSztFQUN0RCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxHQUFHLE1BQU0sR0FBRyxNQUFLOztFQUVwRCxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0tBQzVCLE9BQU8sQ0FBQyxJQUFJLElBQUksVUFBVSxDQUFDLEdBQUcsRUFBRSxLQUFLLEdBQUcsSUFBSSxDQUFDLEVBQUM7Q0FDbEQ7O0FDM0RELE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0VBQ3RDLE1BQU0sQ0FBQyxlQUFlLENBQUMsaUJBQWlCLEVBQUM7RUFDekMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxZQUFZLEVBQUM7RUFDcEMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxpQkFBaUIsRUFBQztFQUNyRCxNQUFNLENBQUMsbUJBQW1CLENBQUMsU0FBUyxFQUFFQyxjQUFZLEVBQUM7RUFDbkQsT0FBTyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUM7RUFDN0I7O0FBRUQsTUFBTUEsY0FBWSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLFFBQVEsSUFBSSxDQUFDLENBQUMsZUFBZSxHQUFFOztBQUVsRSxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7RUFDOUIsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sSUFBSSxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUM7RUFDdkUsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDLEtBQUssR0FBRTtFQUM5Qjs7QUFFRCxBQUFPLFNBQVMsUUFBUSxDQUFDLFFBQVEsRUFBRTtFQUNqQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxNQUFNOztFQUU1QixRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsSUFBSTtJQUNqQixJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFDOztJQUVmLEdBQUcsQ0FBQyxJQUFJLENBQUM7TUFDUCxlQUFlLEVBQUUsSUFBSTtNQUNyQixVQUFVLEVBQUUsSUFBSTtLQUNqQixFQUFDO0lBQ0YsRUFBRSxDQUFDLEtBQUssR0FBRTtJQUNWLGlCQUFpQixDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUM7O0lBRTNCLEdBQUcsQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFQSxjQUFZLEVBQUM7SUFDL0IsR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsaUJBQWlCLEVBQUM7R0FDbEMsRUFBQzs7RUFFRixPQUFPLENBQUMsWUFBWSxFQUFFLE9BQU8sRUFBQzs7O0NBQy9CLERDakNELE1BQU1ILFlBQVUsR0FBRyxvQkFBb0I7R0FDcEMsS0FBSyxDQUFDLEdBQUcsQ0FBQztHQUNWLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLO0lBQ3BCLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsRUFBRSxDQUFDO0dBQ0osU0FBUyxDQUFDLENBQUMsRUFBQzs7QUFFZixNQUFNRSxnQkFBYyxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxLQUFLLEVBQUM7O0FBRXRELEFBQU8sU0FBUyxJQUFJLENBQUMsUUFBUSxFQUFFO0VBQzdCLE9BQU8sQ0FBQ0YsWUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUNsQyxJQUFJLENBQUMsQ0FBQyxZQUFZLEVBQUUsTUFBTTs7SUFFMUIsQ0FBQyxDQUFDLGNBQWMsR0FBRTs7SUFFbEIsSUFBSSxhQUFhLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUMzQixJQUFJLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFDOztJQUVqQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7TUFDakQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7VUFDbEIsYUFBYSxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDO1VBQ3pDLGVBQWUsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBQzs7TUFFL0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7VUFDbEIsYUFBYSxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDO1VBQ3pDLGNBQWMsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBQztHQUNqRCxFQUFDOztFQUVGLE9BQU8sQ0FBQ0UsZ0JBQWMsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDdEMsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixJQUFJLElBQUksR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUM7SUFDakMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxHQUFHLE1BQU0sRUFBQztHQUNuRSxFQUFDOztFQUVGLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJO0lBQ3BCLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUNwQixFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVU7UUFDakIsRUFBRSxDQUFDLEtBQUssQ0FBQyxVQUFVLElBQUksTUFBTTtZQUN6QixJQUFJO1lBQ0osTUFBTSxFQUFDO0dBQ2hCLEVBQUM7O0VBRUYsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUk7SUFDcEIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQ3BCLEVBQUUsQ0FBQyxLQUFLLENBQUMsU0FBUztRQUNoQixFQUFFLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxRQUFRO1lBQzFCLElBQUk7WUFDSixRQUFRLEVBQUM7R0FDbEIsRUFBQzs7RUFFRixPQUFPLE1BQU07SUFDWCxPQUFPLENBQUMsTUFBTSxDQUFDRixZQUFVLEVBQUM7SUFDMUIsT0FBTyxDQUFDLE1BQU0sQ0FBQ0UsZ0JBQWMsRUFBQztJQUM5QixPQUFPLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBQztJQUM3QixPQUFPLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUFDO0dBQ3JDO0NBQ0Y7O0FBRUQsQUFBTyxTQUFTLGFBQWEsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFO0VBQzVDLEdBQUc7S0FDQSxHQUFHLENBQUMsRUFBRSxJQUFJLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0tBQy9CLEdBQUcsQ0FBQyxFQUFFLEtBQUs7TUFDVixFQUFFO01BQ0YsS0FBSyxLQUFLLFlBQVk7TUFDdEIsT0FBTyxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLFlBQVksQ0FBQyxDQUFDO01BQzlDLE1BQU0sSUFBSSxDQUFDO01BQ1gsUUFBUSxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztLQUNoRCxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTyxJQUFJLFFBQVEsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztZQUMxRCxJQUFJLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1lBQ2pELE9BQU8sQ0FBQyxPQUFPO09BQ3BCLENBQUMsQ0FBQztLQUNKLEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxRQUFRO1lBQ25CLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU07WUFDaEMsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTTtPQUNyQyxDQUFDLENBQUM7S0FDSixPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO01BQzFCLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsRUFBQztDQUNwQzs7QUFFRCxBQUFPLFNBQVMsYUFBYSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDNUMsR0FBRztLQUNBLEdBQUcsQ0FBQyxFQUFFLElBQUksZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDL0IsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLEtBQUssZUFBZTtNQUN6QixPQUFPLEdBQUcsVUFBVSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsZUFBZSxDQUFDLENBQUM7TUFDbkQsTUFBTSxJQUFJLEVBQUU7TUFDWixRQUFRLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO0tBQ2hELENBQUMsQ0FBQztLQUNGLEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPLElBQUksUUFBUSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1lBQzFELENBQUM7WUFDRCxPQUFPLENBQUMsT0FBTztPQUNwQixDQUFDLENBQUM7S0FDSixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLEtBQUssRUFBRSxPQUFPLENBQUMsUUFBUTtZQUNuQixDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO1lBQzdDLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7T0FDbEQsQ0FBQyxDQUFDO0tBQ0osT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztNQUMxQixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLEVBQUUsQ0FBQyxFQUFDO0NBQ3ZEOztBQUVELEFBQU8sU0FBUyxjQUFjLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRTtFQUM3QyxHQUFHO0tBQ0EsR0FBRyxDQUFDLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUMvQixHQUFHLENBQUMsRUFBRSxLQUFLO01BQ1YsRUFBRTtNQUNGLEtBQUssS0FBSyxVQUFVO01BQ3BCLE9BQU8sR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxVQUFVLENBQUMsQ0FBQztNQUM1QyxNQUFNLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7TUFDekQsUUFBUSxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztLQUNoRCxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLFNBQVMsRUFBRSxPQUFPLENBQUMsUUFBUTtZQUN2QixPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxNQUFNO1lBQ2hDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU07T0FDckMsQ0FBQyxDQUFDO0tBQ0osT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLFNBQVMsQ0FBQztNQUM5QixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxTQUFTLENBQUMsRUFBRSxDQUFDLEVBQUM7Q0FDN0Q7O0FBRUQsTUFBTSxTQUFTLEdBQUc7RUFDaEIsTUFBTSxFQUFFLENBQUM7RUFDVCxJQUFJLElBQUksQ0FBQztFQUNULEtBQUssR0FBRyxDQUFDO0VBQ1QsRUFBRSxFQUFFLENBQUM7RUFDTCxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7RUFDeEU7QUFDRCxNQUFNLGFBQWEsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFDOztBQUUzRCxBQUFPLFNBQVMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRTtFQUMvQyxHQUFHO0tBQ0EsR0FBRyxDQUFDLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUMvQixHQUFHLENBQUMsRUFBRSxLQUFLO01BQ1YsRUFBRTtNQUNGLEtBQUssS0FBSyxZQUFZO01BQ3RCLE9BQU8sR0FBRyxRQUFRLENBQUMsRUFBRSxFQUFFLFlBQVksQ0FBQztNQUNwQyxTQUFTLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO0tBQ2pELENBQUMsQ0FBQztLQUNGLEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxTQUFTO1lBQ3BCLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztZQUM5QixTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7T0FDbkMsQ0FBQyxDQUFDO0tBQ0osT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztNQUMxQixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLGFBQWEsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLElBQUksYUFBYSxDQUFDLE1BQU07VUFDekUsYUFBYSxDQUFDLE1BQU07VUFDcEIsS0FBSztPQUNSLEVBQUM7Q0FDUDs7QUFFRCxNQUFNLFFBQVEsR0FBRztFQUNmLEtBQUssRUFBRSxDQUFDO0VBQ1IsSUFBSSxFQUFFLENBQUM7RUFDUCxNQUFNLEVBQUUsQ0FBQztFQUNULEtBQUssRUFBRSxDQUFDO0VBQ1Q7QUFDRCxNQUFNLFlBQVksR0FBRyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFDOztBQUU5QyxBQUFPLFNBQVMsZUFBZSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDOUMsR0FBRztLQUNBLEdBQUcsQ0FBQyxFQUFFLElBQUksZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDL0IsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLEtBQUssV0FBVztNQUNyQixPQUFPLEdBQUcsUUFBUSxDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUM7TUFDbkMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztLQUNqRCxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLEtBQUssRUFBRSxPQUFPLENBQUMsU0FBUztZQUNwQixRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7WUFDN0IsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO09BQ2xDLENBQUMsQ0FBQztLQUNKLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7TUFDMUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxZQUFZLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUM7Q0FDM0U7O0FDMUxELE1BQU1GLFlBQVUsR0FBRyxvQkFBb0I7R0FDcEMsS0FBSyxDQUFDLEdBQUcsQ0FBQztHQUNWLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLO0lBQ3BCLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsRUFBRSxDQUFDO0dBQ0osU0FBUyxDQUFDLENBQUMsRUFBQzs7QUFFZixNQUFNRSxnQkFBYyxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFDOztBQUV2RixBQUFPLFNBQVMsSUFBSSxDQUFDLFFBQVEsRUFBRTtFQUM3QixPQUFPLENBQUNGLFlBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDbEMsSUFBSSxDQUFDLENBQUMsWUFBWSxFQUFFLE1BQU07O0lBRTFCLENBQUMsQ0FBQyxjQUFjLEdBQUU7O0lBRWxCLElBQUksYUFBYSxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUM7UUFDM0IsSUFBSSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBQzs7SUFFakMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO01BQ2pELElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO1VBQ2xCLG1CQUFtQixDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDO1VBQy9DLGdCQUFnQixDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFDOztNQUVoRCxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztVQUNsQixtQkFBbUIsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQztVQUMvQyxnQkFBZ0IsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBQztHQUNuRCxFQUFDOztFQUVGLE9BQU8sQ0FBQ0UsZ0JBQWMsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDdEMsQ0FBQyxDQUFDLGNBQWMsR0FBRTs7SUFFbEIsSUFBSSxhQUFhLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUMzQixJQUFJLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFDOztJQUVqQyxlQUFlLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsS0FBSyxHQUFHLFFBQVEsRUFBQztHQUN6RSxFQUFDOztFQUVGLE9BQU8sTUFBTTtJQUNYLE9BQU8sQ0FBQyxNQUFNLENBQUNGLFlBQVUsRUFBQztJQUMxQixPQUFPLENBQUMsTUFBTSxDQUFDRSxnQkFBYyxFQUFDO0lBQzlCLE9BQU8sQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUM7R0FDckM7Q0FDRjs7QUFFRCxNQUFNLFVBQVUsR0FBRyxFQUFFLElBQUk7RUFDdkIsRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTTtFQUN6QixPQUFPLEVBQUU7RUFDVjs7QUFFRCxNQUFNLDZCQUE2QixHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksS0FBSztFQUNuRCxJQUFJLElBQUksSUFBSSxPQUFPLEtBQUssR0FBRyxJQUFJLFlBQVksSUFBSSxHQUFHLElBQUksUUFBUSxJQUFJLEdBQUcsSUFBSSxVQUFVLENBQUM7SUFDbEYsR0FBRyxHQUFHLFNBQVE7T0FDWCxJQUFJLElBQUksSUFBSSxZQUFZLEtBQUssR0FBRyxJQUFJLGNBQWMsSUFBSSxHQUFHLElBQUksZUFBZSxDQUFDO0lBQ2hGLEdBQUcsR0FBRyxTQUFROztFQUVoQixPQUFPLEdBQUc7RUFDWDs7O0FBR0QsQUFBTyxTQUFTLGVBQWUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFO0VBQzFDLEdBQUc7S0FDQSxHQUFHLENBQUMsVUFBVSxDQUFDO0tBQ2YsR0FBRyxDQUFDLEVBQUUsSUFBSTtNQUNULEVBQUUsQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLE1BQUs7S0FDL0IsRUFBQztDQUNMOztBQUVELE1BQU0sVUFBVSxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUMsR0FBRTtBQUM5RSxNQUFNRSxnQkFBYyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUM7O0FBRTFELEFBQU8sU0FBUyxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFO0VBQy9DLEdBQUc7S0FDQSxHQUFHLENBQUMsVUFBVSxDQUFDO0tBQ2YsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLEtBQUssZ0JBQWdCO01BQzFCLE9BQU8sR0FBRyw2QkFBNkIsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLGdCQUFnQixDQUFDLEVBQUUsT0FBTyxDQUFDO01BQ2hGLFNBQVMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7S0FDakQsQ0FBQyxDQUFDO0tBQ0YsR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixLQUFLLEVBQUUsT0FBTyxDQUFDLFNBQVM7WUFDcEIsVUFBVSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO1lBQy9CLFVBQVUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztPQUNwQyxDQUFDLENBQUM7S0FDSixPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO01BQzFCLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUdBLGdCQUFjLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUM7Q0FDN0U7QUFDRCxBQUVBLE1BQU1DLGdCQUFjLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBQzs7QUFFMUQsQUFBTyxTQUFTLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDL0MsR0FBRztLQUNBLEdBQUcsQ0FBQyxVQUFVLENBQUM7S0FDZixHQUFHLENBQUMsRUFBRSxLQUFLO01BQ1YsRUFBRTtNQUNGLEtBQUssS0FBSyxZQUFZO01BQ3RCLE9BQU8sR0FBRyxRQUFRLENBQUMsRUFBRSxFQUFFLFlBQVksQ0FBQztNQUNwQyxTQUFTLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO0tBQy9DLENBQUMsQ0FBQztLQUNGLEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxTQUFTO1lBQ3BCLFVBQVUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztZQUMvQixVQUFVLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7T0FDcEMsQ0FBQyxDQUFDO0tBQ0osT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztNQUMxQixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHQSxnQkFBYyxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFDO0NBQzdFOztBQUVELE1BQU0saUJBQWlCLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFFO0FBQ3RGLE1BQU0scUJBQXFCLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLGVBQWUsRUFBQzs7QUFFbEUsQUFBTyxTQUFTLG1CQUFtQixDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDbEQsR0FBRztLQUNBLEdBQUcsQ0FBQyxVQUFVLENBQUM7S0FDZixHQUFHLENBQUMsRUFBRSxLQUFLO01BQ1YsRUFBRTtNQUNGLEtBQUssS0FBSyxnQkFBZ0I7TUFDMUIsT0FBTyxHQUFHLDZCQUE2QixDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsZ0JBQWdCLENBQUMsRUFBRSxZQUFZLENBQUM7TUFDckYsU0FBUyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztLQUNqRCxDQUFDLENBQUM7S0FDRixHQUFHLENBQUMsT0FBTztNQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1FBQ3JCLEtBQUssRUFBRSxPQUFPLENBQUMsU0FBUztZQUNwQixpQkFBaUIsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztZQUN0QyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztPQUMzQyxDQUFDLENBQUM7S0FDSixPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO01BQzFCLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcscUJBQXFCLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUM7Q0FDcEY7O0FBRUQsTUFBTSxpQkFBaUIsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUU7QUFDdEYsTUFBTSxxQkFBcUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsZUFBZSxFQUFDOztBQUVsRSxBQUFPLFNBQVMsbUJBQW1CLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRTtFQUNsRCxHQUFHO0tBQ0EsR0FBRyxDQUFDLFVBQVUsQ0FBQztLQUNmLEdBQUcsQ0FBQyxFQUFFLEtBQUs7TUFDVixFQUFFO01BQ0YsS0FBSyxLQUFLLGNBQWM7TUFDeEIsT0FBTyxHQUFHLFFBQVEsQ0FBQyxFQUFFLEVBQUUsY0FBYyxDQUFDO01BQ3RDLFNBQVMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7S0FDL0MsQ0FBQyxDQUFDO0tBQ0YsR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixLQUFLLEVBQUUsT0FBTyxDQUFDLFNBQVM7WUFDcEIsaUJBQWlCLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7WUFDdEMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7T0FDM0MsQ0FBQyxDQUFDO0tBQ0osT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztNQUMxQixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLHFCQUFxQixDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFDO0NBQ3BGOztBQzdKRDs7OztBQUlBLFNBQVMsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUU7SUFDckIsSUFBSSxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7UUFDbkIsQ0FBQyxHQUFHLE1BQU0sQ0FBQztLQUNkO0lBQ0QsTUFBTSxjQUFjLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3ZDLENBQUMsR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztJQUVoRSxJQUFJLGNBQWMsRUFBRTtRQUNoQixDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDO0tBQzNDOztJQUVELElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsUUFBUSxFQUFFO1FBQzlCLE9BQU8sQ0FBQyxDQUFDO0tBQ1o7O0lBRUQsSUFBSSxHQUFHLEtBQUssR0FBRyxFQUFFOzs7O1FBSWIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxJQUFJLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztLQUNuRTtTQUNJOzs7UUFHRCxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztLQUMzQztJQUNELE9BQU8sQ0FBQyxDQUFDO0NBQ1o7Ozs7O0FBS0QsU0FBUyxPQUFPLENBQUMsR0FBRyxFQUFFO0lBQ2xCLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztDQUN4Qzs7Ozs7O0FBTUQsU0FBUyxjQUFjLENBQUMsQ0FBQyxFQUFFO0lBQ3ZCLE9BQU8sT0FBTyxDQUFDLEtBQUssUUFBUSxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztDQUNoRjs7Ozs7QUFLRCxTQUFTLFlBQVksQ0FBQyxDQUFDLEVBQUU7SUFDckIsT0FBTyxPQUFPLENBQUMsS0FBSyxRQUFRLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztDQUN6RDs7Ozs7QUFLRCxTQUFTLFVBQVUsQ0FBQyxDQUFDLEVBQUU7SUFDbkIsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNsQixJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDNUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUNUO0lBQ0QsT0FBTyxDQUFDLENBQUM7Q0FDWjs7Ozs7QUFLRCxTQUFTLG1CQUFtQixDQUFDLENBQUMsRUFBRTtJQUM1QixJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDUixPQUFPLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7S0FDekI7SUFDRCxPQUFPLENBQUMsQ0FBQztDQUNaOzs7OztBQUtELFNBQVMsSUFBSSxDQUFDLENBQUMsRUFBRTtJQUNiLE9BQU8sQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0NBQzVDOzs7Ozs7Ozs7O0FBVUQsU0FBUyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUU7SUFDdkIsT0FBTztRQUNILENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLEdBQUc7UUFDeEIsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRztRQUN4QixDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsR0FBRyxHQUFHO0tBQzNCLENBQUM7Q0FDTDs7Ozs7O0FBTUQsU0FBUyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUU7SUFDdkIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDcEIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDcEIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDcEIsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzlCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUM5QixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDVixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDVixNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDO0lBQzFCLElBQUksR0FBRyxLQUFLLEdBQUcsRUFBRTtRQUNiLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQ2I7U0FDSTtRQUNELE1BQU0sQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7UUFDcEIsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUNwRCxRQUFRLEdBQUc7WUFDUCxLQUFLLENBQUM7Z0JBQ0YsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xDLE1BQU07WUFDVixLQUFLLENBQUM7Z0JBQ0YsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNwQixNQUFNO1lBQ1YsS0FBSyxDQUFDO2dCQUNGLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDcEIsTUFBTTtTQUNiO1FBQ0QsQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUNWO0lBQ0QsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7Q0FDdEI7Ozs7Ozs7QUFPRCxTQUFTLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRTtJQUN2QixJQUFJLENBQUMsQ0FBQztJQUNOLElBQUksQ0FBQyxDQUFDO0lBQ04sSUFBSSxDQUFDLENBQUM7SUFDTixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNwQixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNwQixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNwQixTQUFTLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRTtRQUN0QixJQUFJLENBQUMsR0FBRyxDQUFDO1lBQ0wsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNYLElBQUksQ0FBQyxHQUFHLENBQUM7WUFDTCxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ1gsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQzlCO1FBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNYLE9BQU8sQ0FBQyxDQUFDO1NBQ1o7UUFDRCxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ1gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3hDO1FBQ0QsT0FBTyxDQUFDLENBQUM7S0FDWjtJQUNELElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUNULENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUNqQjtTQUNJO1FBQ0QsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNoRCxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNwQixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUM3QixDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDckIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7S0FDaEM7SUFDRCxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQztDQUNqRDs7Ozs7OztBQU9ELFNBQVMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFO0lBQ3ZCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUM5QixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDOUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ1YsTUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDO0lBQ2QsTUFBTSxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztJQUNwQixNQUFNLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDO0lBQ2xDLElBQUksR0FBRyxLQUFLLEdBQUcsRUFBRTtRQUNiLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDVDtTQUNJO1FBQ0QsUUFBUSxHQUFHO1lBQ1AsS0FBSyxDQUFDO2dCQUNGLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNsQyxNQUFNO1lBQ1YsS0FBSyxDQUFDO2dCQUNGLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDcEIsTUFBTTtZQUNWLEtBQUssQ0FBQztnQkFDRixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3BCLE1BQU07U0FDYjtRQUNELENBQUMsSUFBSSxDQUFDLENBQUM7S0FDVjtJQUNELE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDO0NBQy9COzs7Ozs7O0FBT0QsU0FBUyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUU7SUFDdkIsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3hCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BCLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDeEIsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNoQixNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3RCLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQzFCLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ2hDLE1BQU0sR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbEIsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2xDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNsQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbEMsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7Q0FDakQ7Ozs7Ozs7QUFPRCxTQUFTLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxVQUFVLEVBQUU7SUFDbkMsTUFBTSxHQUFHLEdBQUc7UUFDUixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUNuQyxDQUFDOztJQUVGLElBQUksVUFBVTtRQUNWLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDckMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNyQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUU7UUFDdkMsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNqRTtJQUNELE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztDQUN2Qjs7Ozs7OztBQU9ELFNBQVMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxVQUFVLEVBQUU7SUFDdkMsTUFBTSxHQUFHLEdBQUc7UUFDUixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNoQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDL0IsQ0FBQzs7SUFFRixJQUFJLFVBQVU7UUFDVixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3JDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDckMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNyQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUU7UUFDdkMsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ3BGO0lBQ0QsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0NBQ3ZCO0FBQ0QsQUFhQTtBQUNBLFNBQVMsbUJBQW1CLENBQUMsQ0FBQyxFQUFFO0lBQzVCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0NBQ3ZEOztBQUVELFNBQVMsbUJBQW1CLENBQUMsQ0FBQyxFQUFFO0lBQzVCLE9BQU8sZUFBZSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztDQUNuQzs7QUFFRCxTQUFTLGVBQWUsQ0FBQyxHQUFHLEVBQUU7SUFDMUIsT0FBTyxRQUFRLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0NBQzVCOzs7Ozs7QUFNRCxNQUFNLEtBQUssR0FBRztJQUNWLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFlBQVksRUFBRSxTQUFTO0lBQ3ZCLElBQUksRUFBRSxTQUFTO0lBQ2YsVUFBVSxFQUFFLFNBQVM7SUFDckIsS0FBSyxFQUFFLFNBQVM7SUFDaEIsS0FBSyxFQUFFLFNBQVM7SUFDaEIsTUFBTSxFQUFFLFNBQVM7SUFDakIsS0FBSyxFQUFFLFNBQVM7SUFDaEIsY0FBYyxFQUFFLFNBQVM7SUFDekIsSUFBSSxFQUFFLFNBQVM7SUFDZixVQUFVLEVBQUUsU0FBUztJQUNyQixLQUFLLEVBQUUsU0FBUztJQUNoQixTQUFTLEVBQUUsU0FBUztJQUNwQixTQUFTLEVBQUUsU0FBUztJQUNwQixVQUFVLEVBQUUsU0FBUztJQUNyQixTQUFTLEVBQUUsU0FBUztJQUNwQixLQUFLLEVBQUUsU0FBUztJQUNoQixjQUFjLEVBQUUsU0FBUztJQUN6QixRQUFRLEVBQUUsU0FBUztJQUNuQixPQUFPLEVBQUUsU0FBUztJQUNsQixJQUFJLEVBQUUsU0FBUztJQUNmLFFBQVEsRUFBRSxTQUFTO0lBQ25CLFFBQVEsRUFBRSxTQUFTO0lBQ25CLGFBQWEsRUFBRSxTQUFTO0lBQ3hCLFFBQVEsRUFBRSxTQUFTO0lBQ25CLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFFBQVEsRUFBRSxTQUFTO0lBQ25CLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLGNBQWMsRUFBRSxTQUFTO0lBQ3pCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFlBQVksRUFBRSxTQUFTO0lBQ3ZCLGFBQWEsRUFBRSxTQUFTO0lBQ3hCLGFBQWEsRUFBRSxTQUFTO0lBQ3hCLGFBQWEsRUFBRSxTQUFTO0lBQ3hCLGFBQWEsRUFBRSxTQUFTO0lBQ3hCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFFBQVEsRUFBRSxTQUFTO0lBQ25CLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLElBQUksRUFBRSxTQUFTO0lBQ2YsU0FBUyxFQUFFLFNBQVM7SUFDcEIsSUFBSSxFQUFFLFNBQVM7SUFDZixLQUFLLEVBQUUsU0FBUztJQUNoQixXQUFXLEVBQUUsU0FBUztJQUN0QixJQUFJLEVBQUUsU0FBUztJQUNmLFFBQVEsRUFBRSxTQUFTO0lBQ25CLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLEtBQUssRUFBRSxTQUFTO0lBQ2hCLEtBQUssRUFBRSxTQUFTO0lBQ2hCLFFBQVEsRUFBRSxTQUFTO0lBQ25CLGFBQWEsRUFBRSxTQUFTO0lBQ3hCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFlBQVksRUFBRSxTQUFTO0lBQ3ZCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLG9CQUFvQixFQUFFLFNBQVM7SUFDL0IsU0FBUyxFQUFFLFNBQVM7SUFDcEIsVUFBVSxFQUFFLFNBQVM7SUFDckIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsV0FBVyxFQUFFLFNBQVM7SUFDdEIsYUFBYSxFQUFFLFNBQVM7SUFDeEIsWUFBWSxFQUFFLFNBQVM7SUFDdkIsY0FBYyxFQUFFLFNBQVM7SUFDekIsY0FBYyxFQUFFLFNBQVM7SUFDekIsY0FBYyxFQUFFLFNBQVM7SUFDekIsV0FBVyxFQUFFLFNBQVM7SUFDdEIsSUFBSSxFQUFFLFNBQVM7SUFDZixTQUFTLEVBQUUsU0FBUztJQUNwQixLQUFLLEVBQUUsU0FBUztJQUNoQixPQUFPLEVBQUUsU0FBUztJQUNsQixNQUFNLEVBQUUsU0FBUztJQUNqQixnQkFBZ0IsRUFBRSxTQUFTO0lBQzNCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFlBQVksRUFBRSxTQUFTO0lBQ3ZCLFlBQVksRUFBRSxTQUFTO0lBQ3ZCLGNBQWMsRUFBRSxTQUFTO0lBQ3pCLGVBQWUsRUFBRSxTQUFTO0lBQzFCLGlCQUFpQixFQUFFLFNBQVM7SUFDNUIsZUFBZSxFQUFFLFNBQVM7SUFDMUIsZUFBZSxFQUFFLFNBQVM7SUFDMUIsWUFBWSxFQUFFLFNBQVM7SUFDdkIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsUUFBUSxFQUFFLFNBQVM7SUFDbkIsV0FBVyxFQUFFLFNBQVM7SUFDdEIsSUFBSSxFQUFFLFNBQVM7SUFDZixPQUFPLEVBQUUsU0FBUztJQUNsQixLQUFLLEVBQUUsU0FBUztJQUNoQixTQUFTLEVBQUUsU0FBUztJQUNwQixNQUFNLEVBQUUsU0FBUztJQUNqQixTQUFTLEVBQUUsU0FBUztJQUNwQixNQUFNLEVBQUUsU0FBUztJQUNqQixhQUFhLEVBQUUsU0FBUztJQUN4QixTQUFTLEVBQUUsU0FBUztJQUNwQixhQUFhLEVBQUUsU0FBUztJQUN4QixhQUFhLEVBQUUsU0FBUztJQUN4QixVQUFVLEVBQUUsU0FBUztJQUNyQixTQUFTLEVBQUUsU0FBUztJQUNwQixJQUFJLEVBQUUsU0FBUztJQUNmLElBQUksRUFBRSxTQUFTO0lBQ2YsSUFBSSxFQUFFLFNBQVM7SUFDZixVQUFVLEVBQUUsU0FBUztJQUNyQixNQUFNLEVBQUUsU0FBUztJQUNqQixhQUFhLEVBQUUsU0FBUztJQUN4QixHQUFHLEVBQUUsU0FBUztJQUNkLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFdBQVcsRUFBRSxTQUFTO0lBQ3RCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLFFBQVEsRUFBRSxTQUFTO0lBQ25CLFFBQVEsRUFBRSxTQUFTO0lBQ25CLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLElBQUksRUFBRSxTQUFTO0lBQ2YsV0FBVyxFQUFFLFNBQVM7SUFDdEIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsR0FBRyxFQUFFLFNBQVM7SUFDZCxJQUFJLEVBQUUsU0FBUztJQUNmLE9BQU8sRUFBRSxTQUFTO0lBQ2xCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLFNBQVMsRUFBRSxTQUFTO0lBQ3BCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLEtBQUssRUFBRSxTQUFTO0lBQ2hCLEtBQUssRUFBRSxTQUFTO0lBQ2hCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCLE1BQU0sRUFBRSxTQUFTO0lBQ2pCLFdBQVcsRUFBRSxTQUFTO0NBQ3pCLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBb0JGLFNBQVMsVUFBVSxDQUFDLEtBQUssRUFBRTtJQUN2QixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7SUFDL0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ1YsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO0lBQ2IsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO0lBQ2IsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO0lBQ2IsSUFBSSxFQUFFLEdBQUcsS0FBSyxDQUFDO0lBQ2YsSUFBSSxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQ25CLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFO1FBQzNCLEtBQUssR0FBRyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztLQUN0QztJQUNELElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFO1FBQzNCLElBQUksY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDL0UsR0FBRyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFDLEVBQUUsR0FBRyxJQUFJLENBQUM7WUFDVixNQUFNLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsTUFBTSxHQUFHLEtBQUssQ0FBQztTQUNoRTthQUNJLElBQUksY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDcEYsQ0FBQyxHQUFHLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNqQyxDQUFDLEdBQUcsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2pDLEdBQUcsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDOUIsRUFBRSxHQUFHLElBQUksQ0FBQztZQUNWLE1BQU0sR0FBRyxLQUFLLENBQUM7U0FDbEI7YUFDSSxJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3BGLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakMsQ0FBQyxHQUFHLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNqQyxHQUFHLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzlCLEVBQUUsR0FBRyxJQUFJLENBQUM7WUFDVixNQUFNLEdBQUcsS0FBSyxDQUFDO1NBQ2xCO1FBQ0QsSUFBSSxLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQzNCLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDO1NBQ2Y7S0FDSjtJQUNELENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbEIsT0FBTztRQUNILEVBQUU7UUFDRixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU0sSUFBSSxNQUFNO1FBQzlCLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNwQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BDLENBQUM7S0FDSixDQUFDO0NBQ0w7O0FBRUQsTUFBTSxXQUFXLEdBQUcsZUFBZSxDQUFDOztBQUVwQyxNQUFNLFVBQVUsR0FBRyxzQkFBc0IsQ0FBQzs7QUFFMUMsTUFBTSxRQUFRLEdBQUcsQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7QUFJeEQsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLFdBQVcsRUFBRSxRQUFRLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3RHLE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxXQUFXLEVBQUUsUUFBUSxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQzNILE1BQU0sUUFBUSxHQUFHO0lBQ2IsUUFBUSxFQUFFLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQztJQUM5QixHQUFHLEVBQUUsSUFBSSxNQUFNLENBQUMsS0FBSyxHQUFHLGlCQUFpQixDQUFDO0lBQzFDLElBQUksRUFBRSxJQUFJLE1BQU0sQ0FBQyxNQUFNLEdBQUcsaUJBQWlCLENBQUM7SUFDNUMsR0FBRyxFQUFFLElBQUksTUFBTSxDQUFDLEtBQUssR0FBRyxpQkFBaUIsQ0FBQztJQUMxQyxJQUFJLEVBQUUsSUFBSSxNQUFNLENBQUMsTUFBTSxHQUFHLGlCQUFpQixDQUFDO0lBQzVDLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQyxLQUFLLEdBQUcsaUJBQWlCLENBQUM7SUFDMUMsSUFBSSxFQUFFLElBQUksTUFBTSxDQUFDLE1BQU0sR0FBRyxpQkFBaUIsQ0FBQztJQUM1QyxJQUFJLEVBQUUsc0RBQXNEO0lBQzVELElBQUksRUFBRSxzREFBc0Q7SUFDNUQsSUFBSSxFQUFFLHNFQUFzRTtJQUM1RSxJQUFJLEVBQUUsc0VBQXNFO0NBQy9FLENBQUM7Ozs7O0FBS0YsU0FBUyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUU7SUFDaEMsS0FBSyxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUNuQyxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1FBQ3BCLE9BQU8sS0FBSyxDQUFDO0tBQ2hCO0lBQ0QsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDO0lBQ2xCLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO1FBQ2QsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyQixLQUFLLEdBQUcsSUFBSSxDQUFDO0tBQ2hCO1NBQ0ksSUFBSSxLQUFLLEtBQUssYUFBYSxFQUFFO1FBQzlCLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsQ0FBQztLQUNyRDs7Ozs7SUFLRCxJQUFJLEtBQUssR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNyQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0tBQ3BEO0lBQ0QsS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2xDLElBQUksS0FBSyxFQUFFO1FBQ1AsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUNqRTtJQUNELEtBQUssR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNqQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0tBQ3BEO0lBQ0QsS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2xDLElBQUksS0FBSyxFQUFFO1FBQ1AsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUNqRTtJQUNELEtBQUssR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNqQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0tBQ3BEO0lBQ0QsS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2xDLElBQUksS0FBSyxFQUFFO1FBQ1AsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUNqRTtJQUNELEtBQUssR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNsQyxJQUFJLEtBQUssRUFBRTtRQUNQLE9BQU87WUFDSCxDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QixDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QixDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QixDQUFDLEVBQUUsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2hDLE1BQU0sRUFBRSxLQUFLLEdBQUcsTUFBTSxHQUFHLE1BQU07U0FDbEMsQ0FBQztLQUNMO0lBQ0QsS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2xDLElBQUksS0FBSyxFQUFFO1FBQ1AsT0FBTztZQUNILENBQUMsRUFBRSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVCLENBQUMsRUFBRSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVCLENBQUMsRUFBRSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVCLE1BQU0sRUFBRSxLQUFLLEdBQUcsTUFBTSxHQUFHLEtBQUs7U0FDakMsQ0FBQztLQUNMO0lBQ0QsS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2xDLElBQUksS0FBSyxFQUFFO1FBQ1AsT0FBTztZQUNILENBQUMsRUFBRSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2QyxDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdkMsQ0FBQyxFQUFFLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZDLENBQUMsRUFBRSxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNDLE1BQU0sRUFBRSxLQUFLLEdBQUcsTUFBTSxHQUFHLE1BQU07U0FDbEMsQ0FBQztLQUNMO0lBQ0QsS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2xDLElBQUksS0FBSyxFQUFFO1FBQ1AsT0FBTztZQUNILENBQUMsRUFBRSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2QyxDQUFDLEVBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdkMsQ0FBQyxFQUFFLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZDLE1BQU0sRUFBRSxLQUFLLEdBQUcsTUFBTSxHQUFHLEtBQUs7U0FDakMsQ0FBQztLQUNMO0lBQ0QsT0FBTyxLQUFLLENBQUM7Q0FDaEI7Ozs7O0FBS0QsU0FBUyxjQUFjLENBQUMsS0FBSyxFQUFFO0lBQzNCLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0NBQ2xEOztBQUVELE1BQU0sU0FBUyxDQUFDO0lBQ1osV0FBVyxDQUFDLEtBQUssR0FBRyxFQUFFLEVBQUUsSUFBSSxHQUFHLEVBQUUsRUFBRTs7UUFFL0IsSUFBSSxLQUFLLFlBQVksU0FBUyxFQUFFO1lBQzVCLE9BQU8sS0FBSyxDQUFDO1NBQ2hCO1FBQ0QsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7UUFDM0IsTUFBTSxHQUFHLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzlCLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBQzNCLElBQUksQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNmLElBQUksQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNmLElBQUksQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNmLElBQUksQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNmLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUM3QyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQztRQUN4QyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7Ozs7O1FBS3RDLElBQUksSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDWixJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQy9CO1FBQ0QsSUFBSSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNaLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDL0I7UUFDRCxJQUFJLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ1osSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUMvQjtRQUNELElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDLEVBQUUsQ0FBQztLQUN6QjtJQUNELE1BQU0sR0FBRztRQUNMLE9BQU8sSUFBSSxDQUFDLGFBQWEsRUFBRSxHQUFHLEdBQUcsQ0FBQztLQUNyQztJQUNELE9BQU8sR0FBRztRQUNOLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7S0FDekI7Ozs7SUFJRCxhQUFhLEdBQUc7O1FBRVosTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxJQUFJLENBQUM7S0FDM0Q7Ozs7SUFJRCxZQUFZLEdBQUc7O1FBRVgsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxDQUFDO1FBQ04sSUFBSSxDQUFDLENBQUM7UUFDTixJQUFJLENBQUMsQ0FBQztRQUNOLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1FBQzFCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1FBQzFCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1FBQzFCLElBQUksS0FBSyxJQUFJLE9BQU8sRUFBRTtZQUNsQixDQUFDLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztTQUNyQjthQUNJO1lBQ0QsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxJQUFJLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztTQUM5QztRQUNELElBQUksS0FBSyxJQUFJLE9BQU8sRUFBRTtZQUNsQixDQUFDLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztTQUNyQjthQUNJO1lBQ0QsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxJQUFJLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztTQUM5QztRQUNELElBQUksS0FBSyxJQUFJLE9BQU8sRUFBRTtZQUNsQixDQUFDLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztTQUNyQjthQUNJO1lBQ0QsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxJQUFJLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztTQUM5QztRQUNELE9BQU8sTUFBTSxHQUFHLENBQUMsR0FBRyxNQUFNLEdBQUcsQ0FBQyxHQUFHLE1BQU0sR0FBRyxDQUFDLENBQUM7S0FDL0M7Ozs7OztJQU1ELFFBQVEsQ0FBQyxLQUFLLEVBQUU7UUFDWixJQUFJLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMzQixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7UUFDN0MsT0FBTyxJQUFJLENBQUM7S0FDZjs7OztJQUlELEtBQUssR0FBRztRQUNKLE1BQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzdDLE9BQU8sRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUM1RDs7Ozs7SUFLRCxXQUFXLEdBQUc7UUFDVixNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDbEMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ2xDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUNsQyxPQUFPLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNoRzs7OztJQUlELEtBQUssR0FBRztRQUNKLE1BQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzdDLE9BQU8sRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztLQUM1RDs7Ozs7SUFLRCxXQUFXLEdBQUc7UUFDVixNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDbEMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ2xDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUNsQyxPQUFPLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNoRzs7Ozs7SUFLRCxLQUFLLENBQUMsVUFBVSxHQUFHLEtBQUssRUFBRTtRQUN0QixPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztLQUN2RDs7Ozs7SUFLRCxXQUFXLENBQUMsVUFBVSxHQUFHLEtBQUssRUFBRTtRQUM1QixPQUFPLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0tBQ3ZDOzs7OztJQUtELE1BQU0sQ0FBQyxVQUFVLEdBQUcsS0FBSyxFQUFFO1FBQ3ZCLE9BQU8sU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7S0FDaEU7Ozs7O0lBS0QsWUFBWSxDQUFDLFVBQVUsR0FBRyxLQUFLLEVBQUU7UUFDN0IsT0FBTyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztLQUN4Qzs7OztJQUlELEtBQUssR0FBRztRQUNKLE9BQU87WUFDSCxDQUFDLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ3JCLENBQUMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDckIsQ0FBQyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUNyQixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDWixDQUFDO0tBQ0w7Ozs7O0lBS0QsV0FBVyxHQUFHO1FBQ1YsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0IsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0IsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0IsT0FBTyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDNUY7Ozs7SUFJRCxlQUFlLEdBQUc7UUFDZCxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDO1FBQzNELE9BQU87WUFDSCxDQUFDLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDZCxDQUFDLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDZCxDQUFDLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDZCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDWixDQUFDO0tBQ0w7Ozs7SUFJRCxxQkFBcUIsR0FBRztRQUNwQixNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDckQsT0FBTyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUM7Y0FDYixDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztjQUN4RCxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ25GOzs7O0lBSUQsTUFBTSxHQUFHO1FBQ0wsSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNkLE9BQU8sYUFBYSxDQUFDO1NBQ3hCO1FBQ0QsSUFBSSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNaLE9BQU8sS0FBSyxDQUFDO1NBQ2hCO1FBQ0QsTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUMxRCxLQUFLLE1BQU0sR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDbEMsSUFBSSxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRyxFQUFFO2dCQUNwQixPQUFPLEdBQUcsQ0FBQzthQUNkO1NBQ0o7UUFDRCxPQUFPLEtBQUssQ0FBQztLQUNoQjs7Ozs7O0lBTUQsUUFBUSxDQUFDLE1BQU0sRUFBRTtRQUNiLE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFDM0IsTUFBTSxHQUFHLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQy9CLElBQUksZUFBZSxHQUFHLEtBQUssQ0FBQztRQUM1QixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMzQyxNQUFNLGdCQUFnQixHQUFHLENBQUMsU0FBUyxJQUFJLFFBQVEsS0FBSyxNQUFNLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLE1BQU0sS0FBSyxNQUFNLENBQUMsQ0FBQztRQUNuRyxJQUFJLGdCQUFnQixFQUFFOzs7WUFHbEIsSUFBSSxNQUFNLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNuQyxPQUFPLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzthQUN4QjtZQUNELE9BQU8sSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQzdCO1FBQ0QsSUFBSSxNQUFNLEtBQUssS0FBSyxFQUFFO1lBQ2xCLGVBQWUsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDeEM7UUFDRCxJQUFJLE1BQU0sS0FBSyxNQUFNLEVBQUU7WUFDbkIsZUFBZSxHQUFHLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1NBQ2xEO1FBQ0QsSUFBSSxNQUFNLEtBQUssS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNLEVBQUU7WUFDdkMsZUFBZSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUN4QztRQUNELElBQUksTUFBTSxLQUFLLE1BQU0sRUFBRTtZQUNuQixlQUFlLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM1QztRQUNELElBQUksTUFBTSxLQUFLLE1BQU0sRUFBRTtZQUNuQixlQUFlLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM3QztRQUNELElBQUksTUFBTSxLQUFLLE1BQU0sRUFBRTtZQUNuQixlQUFlLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ3pDO1FBQ0QsSUFBSSxNQUFNLEtBQUssTUFBTSxFQUFFO1lBQ25CLGVBQWUsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7U0FDbkM7UUFDRCxJQUFJLE1BQU0sS0FBSyxLQUFLLEVBQUU7WUFDbEIsZUFBZSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUN4QztRQUNELElBQUksTUFBTSxLQUFLLEtBQUssRUFBRTtZQUNsQixlQUFlLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3hDO1FBQ0QsT0FBTyxlQUFlLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0tBQ2hEO0lBQ0QsS0FBSyxHQUFHO1FBQ0osT0FBTyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztLQUN6Qzs7Ozs7SUFLRCxPQUFPLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRTtRQUNqQixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDekIsR0FBRyxDQUFDLENBQUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxDQUFDO1FBQ3RCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QixPQUFPLElBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQzdCOzs7OztJQUtELFFBQVEsQ0FBQyxNQUFNLEdBQUcsRUFBRSxFQUFFO1FBQ2xCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN6QixHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsRUFBRSxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDOUUsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEVBQUUsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzlFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxFQUFFLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM5RSxPQUFPLElBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQzdCOzs7Ozs7SUFNRCxNQUFNLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRTtRQUNoQixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDekIsR0FBRyxDQUFDLENBQUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxDQUFDO1FBQ3RCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QixPQUFPLElBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQzdCOzs7Ozs7SUFNRCxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRTtRQUNkLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUM7S0FDcEM7Ozs7OztJQU1ELEtBQUssQ0FBQyxNQUFNLEdBQUcsRUFBRSxFQUFFO1FBQ2YsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztLQUNwQzs7Ozs7O0lBTUQsVUFBVSxDQUFDLE1BQU0sR0FBRyxFQUFFLEVBQUU7UUFDcEIsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLEdBQUcsQ0FBQyxDQUFDLElBQUksTUFBTSxHQUFHLEdBQUcsQ0FBQztRQUN0QixHQUFHLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdkIsT0FBTyxJQUFJLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUM3Qjs7Ozs7SUFLRCxRQUFRLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRTtRQUNsQixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDekIsR0FBRyxDQUFDLENBQUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxDQUFDO1FBQ3RCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QixPQUFPLElBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQzdCOzs7OztJQUtELFNBQVMsR0FBRztRQUNSLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUMvQjs7Ozs7SUFLRCxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ1QsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLE1BQU0sR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxNQUFNLElBQUksR0FBRyxDQUFDO1FBQ25DLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztRQUNsQyxPQUFPLElBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQzdCO0lBQ0QsR0FBRyxDQUFDLEtBQUssRUFBRSxNQUFNLEdBQUcsRUFBRSxFQUFFO1FBQ3BCLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUMxQixNQUFNLElBQUksR0FBRyxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUMxQyxNQUFNLENBQUMsR0FBRyxNQUFNLEdBQUcsR0FBRyxDQUFDO1FBQ3ZCLE1BQU0sSUFBSSxHQUFHO1lBQ1QsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztZQUNqQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1lBQ2pDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7WUFDakMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUNwQyxDQUFDO1FBQ0YsT0FBTyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUM5QjtJQUNELFNBQVMsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxFQUFFLE1BQU0sR0FBRyxFQUFFLEVBQUU7UUFDaEMsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLE1BQU0sSUFBSSxHQUFHLEdBQUcsR0FBRyxNQUFNLENBQUM7UUFDMUIsTUFBTSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNuQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLE9BQU8sS0FBSyxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksR0FBRyxFQUFFLEVBQUUsT0FBTyxHQUFHO1lBQ3BFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksSUFBSSxHQUFHLENBQUM7WUFDN0IsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQ2hDO1FBQ0QsT0FBTyxHQUFHLENBQUM7S0FDZDs7OztJQUlELFVBQVUsR0FBRztRQUNULE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN6QixHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksR0FBRyxDQUFDO1FBQzVCLE9BQU8sSUFBSSxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDN0I7SUFDRCxhQUFhLENBQUMsT0FBTyxHQUFHLENBQUMsRUFBRTtRQUN2QixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDekIsTUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNoQixNQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ2hCLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDZCxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7UUFDZixNQUFNLFlBQVksR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDO1FBQ2pDLE9BQU8sT0FBTyxFQUFFLEVBQUU7WUFDZCxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDckMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLFlBQVksSUFBSSxDQUFDLENBQUM7U0FDOUI7UUFDRCxPQUFPLEdBQUcsQ0FBQztLQUNkO0lBQ0QsZUFBZSxHQUFHO1FBQ2QsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDaEIsT0FBTztZQUNILElBQUk7WUFDSixJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksR0FBRyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDeEQsSUFBSSxTQUFTLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDO1NBQzVELENBQUM7S0FDTDtJQUNELEtBQUssR0FBRztRQUNKLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUN6QjtJQUNELE1BQU0sR0FBRztRQUNMLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUN6Qjs7Ozs7SUFLRCxNQUFNLENBQUMsQ0FBQyxFQUFFO1FBQ04sTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ3pCLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDaEIsTUFBTSxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN0QixNQUFNLFNBQVMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQzFCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDeEIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsU0FBUyxJQUFJLEdBQUcsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUNwRjtRQUNELE9BQU8sTUFBTSxDQUFDO0tBQ2pCOzs7O0lBSUQsTUFBTSxDQUFDLEtBQUssRUFBRTtRQUNWLE9BQU8sSUFBSSxDQUFDLFdBQVcsRUFBRSxLQUFLLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO0tBQ3BFO0NBQ0o7Ozs7Ozs7Ozs7QUFVRCxTQUFTLFdBQVcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFO0lBQ2pDLE1BQU0sRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2pDLE1BQU0sRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2pDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxZQUFZLEVBQUUsRUFBRSxFQUFFLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxJQUFJO1NBQ3pELElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFlBQVksRUFBRSxFQUFFLEVBQUUsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxFQUFFO0NBQ2hFOzs7Ozs7Ozs7Ozs7OztBQWNELFNBQVMsVUFBVSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsS0FBSyxHQUFHLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLEVBQUU7SUFDeEUsTUFBTSxnQkFBZ0IsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ3JELFFBQVEsQ0FBQyxLQUFLLENBQUMsS0FBSyxJQUFJLElBQUksS0FBSyxLQUFLLENBQUMsSUFBSSxJQUFJLE9BQU8sQ0FBQztRQUNuRCxLQUFLLFNBQVMsQ0FBQztRQUNmLEtBQUssVUFBVTtZQUNYLE9BQU8sZ0JBQWdCLElBQUksR0FBRyxDQUFDO1FBQ25DLEtBQUssU0FBUztZQUNWLE9BQU8sZ0JBQWdCLElBQUksQ0FBQyxDQUFDO1FBQ2pDLEtBQUssVUFBVTtZQUNYLE9BQU8sZ0JBQWdCLElBQUksQ0FBQyxDQUFDO0tBQ3BDO0lBQ0QsT0FBTyxLQUFLLENBQUM7Q0FDaEI7O0FDMWtDTSxTQUFTLFdBQVcsQ0FBQyxPQUFPLEVBQUUsY0FBYyxFQUFFO0VBQ25ELE1BQU0sZ0JBQWdCLElBQUksQ0FBQyxDQUFDLGFBQWEsRUFBRSxPQUFPLEVBQUM7RUFDbkQsTUFBTSxnQkFBZ0IsSUFBSSxDQUFDLENBQUMsYUFBYSxFQUFFLE9BQU8sRUFBQztFQUNuRCxNQUFNLFlBQVksUUFBUSxDQUFDLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBQztFQUMvQyxNQUFNLE9BQU8sYUFBYSxDQUFDLENBQUMsT0FBTyxFQUFFLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxFQUFDO0VBQ3pELE1BQU0sT0FBTyxhQUFhLENBQUMsQ0FBQyxPQUFPLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLEVBQUM7RUFDekQsTUFBTSxPQUFPLGFBQWEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLEVBQUM7O0VBRXJELElBQUksQ0FBQyxZQUFZLFNBQVMsYUFBWTs7O0VBR3RDLE9BQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDbkIsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7TUFDOUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFDOztFQUV4QyxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQ25CLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFO01BQzlCLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxZQUFZLFVBQVU7VUFDN0IsTUFBTTtVQUNOLGlCQUFpQjtPQUNwQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUM7O0VBRXhCLE9BQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDbkIsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7TUFDOUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLFlBQVksVUFBVTtVQUM3QixRQUFRO1VBQ1IsY0FBYztPQUNqQixHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUM7OztFQUd4QixjQUFjLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxJQUFJO0lBQzFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLE1BQU07O0lBRTVCLElBQUksc0JBQXNCLElBQUksTUFBSztJQUNuQyxJQUFJLHNCQUFzQixJQUFJLE1BQUs7SUFDbkMsSUFBSSxrQkFBa0IsUUFBUSxNQUFLO0lBQ25DLElBQUksRUFBRSxFQUFFLEVBQUUsRUFBRSxHQUFFOztJQUVkLElBQUksUUFBUSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7TUFDeEIsTUFBTSxFQUFFLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFBQzs7TUFFdEIsSUFBSSxFQUFFLFlBQVksVUFBVSxFQUFFO1FBQzVCLEVBQUUsR0FBRyxJQUFJLFNBQVMsQ0FBQyxjQUFjLEVBQUM7UUFDbEMsSUFBSSxPQUFPLEdBQUcsUUFBUSxDQUFDLEVBQUUsRUFBRSxRQUFRLEVBQUM7UUFDcEMsRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLE9BQU8sS0FBSyxNQUFNO1lBQ2pDLGNBQWM7WUFDZCxPQUFPLEVBQUM7UUFDWixFQUFFLEdBQUcsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBQztPQUN6QztXQUNJO1FBQ0gsRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLEVBQUM7UUFDekMsRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsaUJBQWlCLENBQUMsRUFBQztRQUNuRCxFQUFFLEdBQUcsUUFBUSxDQUFDLEVBQUUsRUFBRSxhQUFhLENBQUMsS0FBSyxLQUFLO1lBQ3RDLElBQUksU0FBUyxDQUFDLGNBQWMsQ0FBQztZQUM3QixJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxFQUFDO09BQy9DOztNQUVELElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQyxXQUFXLEdBQUU7TUFDekIsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDLFdBQVcsR0FBRTtNQUN6QixJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUMsV0FBVyxHQUFFOztNQUV6QixzQkFBc0IsR0FBRyxFQUFFLENBQUMsYUFBYSxLQUFLLGNBQWMsS0FBSyxFQUFFLENBQUMsUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLFdBQVcsS0FBSyxFQUFFLEVBQUM7TUFDbkgsc0JBQXNCLEdBQUcsRUFBRSxDQUFDLGFBQWEsS0FBSyxtQkFBa0I7TUFDaEUsa0JBQWtCLE9BQU8sRUFBRSxDQUFDLGFBQWEsS0FBSyxlQUFjOztNQUU1RCxJQUFJLHNCQUFzQixJQUFJLENBQUMsc0JBQXNCO1FBQ25ELFNBQVMsQ0FBQyxZQUFZLEVBQUM7V0FDcEIsSUFBSSxzQkFBc0IsSUFBSSxDQUFDLHNCQUFzQjtRQUN4RCxTQUFTLENBQUMsWUFBWSxFQUFDOztNQUV6QixNQUFNLE1BQU0sR0FBRyxzQkFBc0IsR0FBRyxFQUFFLEdBQUcsR0FBRTtNQUMvQyxNQUFNLE1BQU0sR0FBRyxzQkFBc0IsR0FBRyxFQUFFLEdBQUcsR0FBRTtNQUMvQyxNQUFNLE1BQU0sR0FBRyxrQkFBa0IsR0FBRyxFQUFFLEdBQUcsR0FBRTs7TUFFM0MsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFDO01BQzdCLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBQztNQUM3QixPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUM7O01BRTdCLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQzs0QkFDVixFQUFFLE1BQU0sQ0FBQztpQkFDcEIsRUFBRSxzQkFBc0IsR0FBRyxhQUFhLEdBQUcsTUFBTSxDQUFDO01BQzdELENBQUMsRUFBQzs7TUFFRixnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7NEJBQ1YsRUFBRSxNQUFNLENBQUM7aUJBQ3BCLEVBQUUsc0JBQXNCLEdBQUcsYUFBYSxHQUFHLE1BQU0sQ0FBQztNQUM3RCxDQUFDLEVBQUM7O01BRUYsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQzs0QkFDTixFQUFFLE1BQU0sQ0FBQztpQkFDcEIsRUFBRSxrQkFBa0IsR0FBRyxhQUFhLEdBQUcsTUFBTSxDQUFDO01BQ3pELENBQUMsRUFBQztLQUNIO1NBQ0k7O01BRUgsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO3dCQUNkLEVBQUUsSUFBSSxDQUFDLFlBQVksSUFBSSxZQUFZLEdBQUcsU0FBUyxFQUFFLEVBQUUsQ0FBQzs7TUFFdEUsQ0FBQyxFQUFDOztNQUVGLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQzt3QkFDZCxFQUFFLElBQUksQ0FBQyxZQUFZLElBQUksWUFBWSxHQUFHLFNBQVMsRUFBRSxFQUFFLENBQUM7O01BRXRFLENBQUMsRUFBQzs7TUFFRixZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO3dCQUNWLEVBQUUsSUFBSSxDQUFDLFlBQVksSUFBSSxRQUFRLEdBQUcsU0FBUyxFQUFFLEVBQUUsQ0FBQzs7TUFFbEUsQ0FBQyxFQUFDO0tBQ0g7R0FDRixFQUFDOztFQUVGLE1BQU0sU0FBUyxHQUFHO0lBQ2hCLElBQUksQ0FBQyxhQUFZOztFQUVuQixNQUFNLFNBQVMsR0FBRyxHQUFHLElBQUk7SUFDdkIsWUFBWSxHQUFFO0lBQ2QsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFHO0lBQ3ZCLElBQUksR0FBRyxLQUFLLFlBQVk7TUFDdEIsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxTQUFTLEVBQUM7SUFDcEUsSUFBSSxHQUFHLEtBQUssWUFBWTtNQUN0QixnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLFNBQVMsRUFBQztJQUNwRSxJQUFJLEdBQUcsS0FBSyxRQUFRO01BQ2xCLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLFNBQVMsRUFBQztJQUNqRTs7RUFFRCxNQUFNLFlBQVksR0FBRztJQUNuQixDQUFDLGdCQUFnQixFQUFFLGdCQUFnQixFQUFFLFlBQVksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNO01BQy9ELE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLEVBQUM7O0VBRXJELE9BQU87SUFDTCxTQUFTO0lBQ1QsU0FBUztJQUNULFVBQVUsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLO01BQ3hCLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckUsVUFBVSxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUs7TUFDeEIsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztHQUN0RTs7O0NBQ0YsREN4SUQsTUFBTSxPQUFPLEdBQUcsSUFBSSxHQUFHLEdBQUU7Ozs7O0FBS3pCLEFBQU8sU0FBUyxPQUFPLENBQUMsY0FBYyxFQUFFO0VBQ3RDLE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEtBQUs7SUFDakMsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLENBQUMscUJBQXFCLEdBQUU7SUFDcEQsTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQztPQUN6QixHQUFHLENBQUMsS0FBSyxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO1FBQ2pDLElBQUksRUFBRSxXQUFXLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztPQUM5QixDQUFDLENBQUM7T0FDRixNQUFNLENBQUMsS0FBSztRQUNYLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQztZQUM5QixFQUFFLENBQUMsT0FBTyxDQUFDLHdFQUF3RSxDQUFDO1lBQ3BGLElBQUk7T0FDVDtPQUNBLEdBQUcsQ0FBQyxLQUFLLElBQUk7UUFDWixJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQztVQUM5SCxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsb0NBQW9DLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUM7O1FBRXpILElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsRUFBRTtVQUMvRCxLQUFLLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFLOztRQUUvQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDO1VBQ3pDLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyx5QkFBeUIsRUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsSUFBSSxFQUFDOzs7UUFHN0osSUFBSSxFQUFFLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7VUFDM0UsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFDOztRQUUxRCxPQUFPLEtBQUs7T0FDYixFQUFDOztJQUVKLE1BQU0sa0JBQWtCLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLO01BQzVDLEVBQUUsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztVQUNyRSxDQUFDO1VBQ0QsQ0FBQyxFQUFDOztJQUVSLE1BQU0scUJBQXFCLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLO01BQy9DLEVBQUUsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztVQUNyRSxDQUFDO1VBQ0QsQ0FBQyxFQUFDOztJQUVSLElBQUksR0FBRyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsWUFBWSxFQUFDOztJQUU5QyxHQUFHLENBQUMsSUFBSSxHQUFHO01BQ1QsRUFBRTtNQUNGLEtBQUs7TUFDTCxNQUFNO01BQ04sa0JBQWtCO01BQ2xCLHFCQUFxQjtNQUN0Qjs7SUFFRCxPQUFPLEdBQUc7SUFDWDs7RUFFRCxNQUFNLGNBQWMsR0FBRyxDQUFDLEtBQUs7SUFDM0IsS0FBSyxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLFdBQVcsR0FBRyxDQUFDO0lBQ3pDLElBQUksR0FBRyxDQUFDLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxVQUFVLEdBQUcsQ0FBQztHQUN6QyxFQUFDOztFQUVGLE1BQU0sWUFBWSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsSUFBSSxNQUFNO0lBQzlDLEdBQUcsRUFBRSxDQUFDLEVBQUUsS0FBSztRQUNULENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFO1FBQ2hDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQztJQUNwQixJQUFJLEVBQUUsQ0FBQyxFQUFFLElBQUk7UUFDVCxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRTtRQUMvQixDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7R0FDckIsRUFBQzs7RUFFRixNQUFNLFVBQVUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUs7SUFDN0IsTUFBTSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxjQUFjLENBQUMsQ0FBQyxFQUFDO0lBQ3pDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLE9BQU8sWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBQzs7SUFFekQsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLElBQUksS0FBSTtJQUN0QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsS0FBSyxJQUFHOztJQUVyQixHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsS0FBSztRQUNsQyxpQkFBaUI7UUFDakIsbUJBQW1CLEVBQUM7O0lBRXhCLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLG9CQUFvQixFQUFFLEtBQUs7UUFDN0Msa0JBQWtCO1FBQ2xCLG9CQUFvQixFQUFDOztJQUV6QixHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxLQUFLO1FBQ3ZDLE1BQU07UUFDTixrQkFBa0IsRUFBQzs7SUFFdkIsR0FBRyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsY0FBYyxFQUFFLElBQUk7UUFDdEMsMEJBQTBCO1FBQzFCLE1BQU0sRUFBQztJQUNaOztFQUVELE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztJQUM3QixJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxFQUFFO01BQy9ELE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFDO01BQ2hELE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxnQkFBZ0IsRUFBRSxRQUFRLEVBQUM7TUFDdEQsTUFBTSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUM7TUFDakQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFFO01BQ2hDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFDO0tBQ3ZCO0lBQ0Y7O0VBRUQsTUFBTSxZQUFZLEdBQUcsQ0FBQyxJQUFJO0lBQ3hCLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRTtNQUNaLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDO1VBQ2xDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUM7VUFDM0MsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsY0FBYyxFQUFDO0tBQzdDO0lBQ0Y7O0VBRUQsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7SUFDckMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsTUFBTTs7SUFFeEIsU0FBUyxDQUFDLGNBQWMsRUFBRSxFQUFFO01BQzFCLEVBQUUsQ0FBQyxZQUFZLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxFQUFDOztJQUV0QyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyx1QkFBdUIsRUFBRSxFQUFFO01BQ2pELE1BQU0sQ0FBQyxTQUFTLEtBQUssWUFBWTtVQUM3QixFQUFFLENBQUMsWUFBWSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUM7VUFDbkMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBQztJQUNqQzs7RUFFRCxNQUFNLGlCQUFpQixHQUFHLENBQUMsSUFBSTtJQUM3QixTQUFTLENBQUMsY0FBYyxFQUFFLEVBQUU7TUFDMUIsRUFBRSxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLEVBQUM7SUFDdkM7O0VBRUQsTUFBTSxTQUFTLEdBQUcsQ0FBQyxJQUFJO0lBQ3JCLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxNQUFNOztJQUVqQyxDQUFDLENBQUMsTUFBTTtRQUNKLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7UUFDNUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsZUFBZSxFQUFDOzs7SUFHN0MsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRTs7TUFFekIsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUM7UUFDdkMsTUFBTTs7TUFFUixNQUFNLEVBQUUsR0FBRyxFQUFFLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDOztNQUVyQyxVQUFVLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBQztLQUNuQjs7U0FFSTtNQUNILE1BQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQUM7TUFDdkIsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFDOztNQUU5QixVQUFVLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBQzs7TUFFbEIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUM7TUFDcEMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUUsaUJBQWlCLEVBQUM7TUFDdkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMseUJBQXlCLEVBQUUsUUFBUSxFQUFDO01BQ25ELENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUM7O01BRXJDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBQzs7Ozs7O0tBTWxDO0lBQ0Y7O0VBRUQsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFDOztFQUVwQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUMsSUFBSSxTQUFTLEVBQUUsRUFBQzs7RUFFaEMsTUFBTSxPQUFPLEdBQUcsTUFBTTtJQUNwQixLQUFLLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUU7TUFDcEMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTTtNQUMxQixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLHlCQUF5QixFQUFFLFFBQVEsRUFBQztNQUMvQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUM7TUFDakMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLGdCQUFnQixFQUFDO0tBQzNDO0lBQ0Y7O0VBRUQsTUFBTSxTQUFTLEdBQUcsTUFBTTtJQUN0QixLQUFLLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUU7TUFDcEMsR0FBRyxDQUFDLE1BQU0sR0FBRTtNQUNaLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMseUJBQXlCLEVBQUUsUUFBUSxFQUFDO01BQy9DLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBQztNQUNqQyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUM7S0FDM0M7O0lBRUQsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLEVBQUM7O0lBRTlDLE9BQU8sQ0FBQyxLQUFLLEdBQUU7SUFDaEI7O0VBRUQsS0FBSyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRTtJQUN0QyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxRQUFPO0lBQzNCLEdBQUcsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVM7SUFDckMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFDO0lBQzVCLEdBQUcsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBQztHQUM5Qjs7RUFFRCxPQUFPLE1BQU07SUFDWCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUM7SUFDckMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUM7SUFDckIsT0FBTyxHQUFFO0dBQ1Y7OztDQUNGLERDaE5ELE1BQU1MLFlBQVUsR0FBRyxvQkFBb0I7R0FDcEMsS0FBSyxDQUFDLEdBQUcsQ0FBQztHQUNWLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLO0lBQ3BCLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsRUFBRSxDQUFDO0dBQ0osU0FBUyxDQUFDLENBQUMsRUFBQzs7QUFFZixNQUFNRSxnQkFBYyxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxZQUFZLEVBQUM7O0FBRTlLLEFBQU8sU0FBUyxTQUFTLENBQUMsUUFBUSxFQUFFO0VBQ2xDLE9BQU8sQ0FBQ0YsWUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUNsQyxJQUFJLENBQUMsQ0FBQyxZQUFZLEVBQUUsTUFBTTs7SUFFMUIsQ0FBQyxDQUFDLGNBQWMsR0FBRTs7SUFFbEIsSUFBSSxhQUFhLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUMzQixJQUFJLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFDOztJQUVqQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7TUFDakQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7VUFDbEIsZUFBZSxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsTUFBTSxDQUFDO1VBQzVDLGVBQWUsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBQzs7TUFFN0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7VUFDbEIsZUFBZSxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsTUFBTSxDQUFDO1VBQzVDLGVBQWUsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBQztHQUNoRCxFQUFDOztFQUVGLE9BQU8sQ0FBQ0UsZ0JBQWMsRUFBRSxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDdEMsQ0FBQyxDQUFDLGNBQWMsR0FBRTtJQUNsQixJQUFJLElBQUksR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUM7SUFDakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztRQUMzQyxlQUFlLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLElBQUksRUFBRSxTQUFTLENBQUM7UUFDN0MsZUFBZSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFDO0dBQ2hELEVBQUM7O0VBRUYsT0FBTyxNQUFNO0lBQ1gsT0FBTyxDQUFDLE1BQU0sQ0FBQ0YsWUFBVSxFQUFDO0lBQzFCLE9BQU8sQ0FBQyxNQUFNLENBQUNFLGdCQUFjLEVBQUM7SUFDOUIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsRUFBQztHQUNyQztDQUNGOztBQUVELE1BQU0sZUFBZSxHQUFHLEVBQUUsSUFBSTtFQUM1QixJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxNQUFNO0lBQzFELEVBQUUsQ0FBQyxLQUFLLENBQUMsU0FBUyxHQUFHLDRCQUEyQjtFQUNsRCxPQUFPLEVBQUU7RUFDVjs7O0FBR0QsTUFBTSxPQUFPLEdBQUc7RUFDZCxTQUFTLEdBQUcsQ0FBQztFQUNiLEdBQUcsU0FBUyxDQUFDO0VBQ2IsR0FBRyxTQUFTLENBQUM7RUFDYixNQUFNLE1BQU0sQ0FBQztFQUNiLE1BQU0sTUFBTSxDQUFDO0VBQ2IsT0FBTyxLQUFLLENBQUM7RUFDZDs7QUFFRCxNQUFNLGtCQUFrQixHQUFHLEVBQUUsSUFBSSxRQUFRLENBQUMsRUFBRSxFQUFFLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUM7O0FBRXJFLEFBQU8sU0FBUyxlQUFlLENBQUMsR0FBRyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUU7RUFDcEQsR0FBRztLQUNBLEdBQUcsQ0FBQyxlQUFlLENBQUM7S0FDcEIsR0FBRyxDQUFDLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDckMsR0FBRyxDQUFDLEVBQUUsS0FBSztNQUNWLEVBQUU7TUFDRixLQUFLLE1BQU0sV0FBVztNQUN0QixPQUFPLElBQUksa0JBQWtCLENBQUMsRUFBRSxDQUFDO01BQ2pDLFNBQVMsRUFBRSxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0tBQzFGLENBQUMsQ0FBQztLQUNGLEdBQUcsQ0FBQyxPQUFPLElBQUk7TUFDZCxJQUFJLE9BQU8sR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBQztNQUNsQyxJQUFJLEdBQUcsT0FBTyxJQUFJLEtBQUssU0FBUztVQUM1QixPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7VUFDbEMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFDOztNQUVoRCxPQUFPLElBQUk7UUFDVCxLQUFLLE1BQU07VUFDVCxJQUFJLE1BQU0sR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFDO1VBQ2pELE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7Y0FDbkQsQ0FBQyxFQUFFLEdBQUcsR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDO2NBQ25CLENBQUMsRUFBRSxHQUFHLEdBQUcsTUFBTSxDQUFDLEVBQUUsRUFBQztVQUN2QixLQUFLO1FBQ1AsS0FBSyxPQUFPO1VBQ1YsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztjQUNuRCxPQUFPO2NBQ1AsR0FBRTtVQUNOLEtBQUs7UUFDUCxLQUFLLFNBQVM7VUFDWixJQUFJLFdBQVcsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDO1VBQzVELElBQUksTUFBTSxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxHQUFHLEtBQUk7VUFDdEQsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztjQUNuRCxXQUFXLEdBQUcsTUFBTSxHQUFHLEdBQUc7Y0FDMUIsV0FBVyxHQUFHLE1BQU0sR0FBRyxJQUFHO1VBQzlCLEtBQUs7UUFDUDtVQUNFLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztjQUMvRSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUM7Y0FDZCxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUM7VUFDbEIsS0FBSztPQUNSOztNQUVELE9BQU8sQ0FBQyxLQUFLLEdBQUcsUUFBTztNQUN2QixPQUFPLE9BQU87S0FDZixDQUFDO0tBQ0QsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztNQUMxQixFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUM7Q0FDdkM7O0FDMUdELE1BQU1GLFlBQVUsR0FBRyxvQkFBb0I7R0FDcEMsS0FBSyxDQUFDLEdBQUcsQ0FBQztHQUNWLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLO0lBQ3BCLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkMsRUFBRSxDQUFDO0dBQ0osU0FBUyxDQUFDLENBQUMsRUFBQzs7QUFFZixNQUFNRSxnQkFBYyxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxZQUFZLEVBQUM7O0FBRTlLLEFBQU8sU0FBUyxRQUFRLENBQUMsS0FBSyxFQUFFO0VBQzlCLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDLFNBQVMsR0FBRTs7RUFFckMsT0FBTyxDQUFDRixZQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ2xDLElBQUksQ0FBQyxDQUFDLFlBQVksRUFBRSxNQUFNOztJQUUxQixDQUFDLENBQUMsY0FBYyxHQUFFOztJQUVsQixJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUMsc0JBQXNCLENBQUM7UUFDekMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBQzs7SUFFakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztRQUMzQyxTQUFTLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDO1FBQzFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUM7R0FDL0MsRUFBQzs7RUFFRixPQUFPLENBQUNFLGdCQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ3RDLENBQUMsQ0FBQyxjQUFjLEdBQUU7SUFDbEIsSUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFDO0lBQ2pDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7UUFDM0MsU0FBUyxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDO1FBQ3RELFNBQVMsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBQztHQUMzRCxFQUFDOztFQUVGLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQzdCLENBQUMsQ0FBQyxjQUFjLEdBQUU7O0lBRWxCLElBQUksSUFBSSxDQUFDLFlBQVksSUFBSSxZQUFZO01BQ25DLElBQUksQ0FBQyxZQUFZLEdBQUcsYUFBWTtTQUM3QixJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksWUFBWTtNQUN4QyxJQUFJLENBQUMsWUFBWSxHQUFHLGFBQVk7O0lBRWxDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBQztHQUNuQyxFQUFDOztFQUVGLE1BQU0sZUFBZSxHQUFHLEdBQUc7SUFDekIsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFDOztFQUVwQyxNQUFNLFVBQVUsR0FBRyxNQUFNO0lBQ3ZCLE9BQU8sQ0FBQyxNQUFNLENBQUNGLFlBQVUsRUFBQztJQUMxQixPQUFPLENBQUMsTUFBTSxDQUFDRSxnQkFBYyxFQUFDO0lBQzlCLE9BQU8sQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUM7SUFDckM7O0VBRUQsT0FBTztJQUNMLGVBQWU7SUFDZixVQUFVO0dBQ1g7Q0FDRjs7QUFFRCxBQUFPLFNBQVMsU0FBUyxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRTtFQUNyRCxHQUFHO0tBQ0EsR0FBRyxDQUFDLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUMvQixHQUFHLENBQUMsRUFBRSxJQUFJO01BQ1QsTUFBTSxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsR0FBRyxvQkFBb0IsQ0FBQyxFQUFFLEVBQUM7OztNQUczRCxPQUFPLEtBQUssQ0FBQyxTQUFTLEVBQUU7UUFDdEIsS0FBSyxZQUFZO1VBQ2YsT0FBTyxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxLQUFLLEVBQUUsVUFBVSxDQUFDLEtBQUssRUFBRTtRQUMzRSxLQUFLLFlBQVk7VUFDZixPQUFPLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEtBQUssRUFBRSxVQUFVLENBQUMsS0FBSyxFQUFFO09BQzVFO0tBQ0YsQ0FBQztLQUNELEdBQUcsQ0FBQyxPQUFPO01BQ1YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7UUFDckIsTUFBTSxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDOUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7T0FDbkUsQ0FBQyxDQUFDO0tBQ0osR0FBRyxDQUFDLE9BQU8sSUFBSTtNQUNkLElBQUksSUFBSSxLQUFLLEdBQUcsSUFBSSxJQUFJLEtBQUssR0FBRyxJQUFJLElBQUksS0FBSyxHQUFHO1FBQzlDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLE1BQU0sR0FBRyxLQUFJOztNQUV4QyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRO1VBQ3BDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU07VUFDdEMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxPQUFPLENBQUMsT0FBTTs7TUFFMUMsSUFBSSxJQUFJLEtBQUssR0FBRyxJQUFJLElBQUksS0FBSyxHQUFHLElBQUksSUFBSSxLQUFLLEdBQUcsRUFBRTtRQUNoRCxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBQztRQUN4RCxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBQztPQUN6RDs7TUFFRCxPQUFPLE9BQU87S0FDZixDQUFDO0tBQ0QsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO01BQ2pDLElBQUksS0FBSyxHQUFHLElBQUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFDO01BQ3RELEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLFdBQVcsR0FBRTs7TUFFckMsSUFBSSxLQUFLLElBQUksT0FBTyxFQUFFLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsRUFBQztNQUNqRSxJQUFJLEtBQUssSUFBSSxpQkFBaUIsRUFBRSxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLEVBQUM7S0FDNUUsRUFBQztDQUNMOztBQUVELEFBQU8sU0FBUyxvQkFBb0IsQ0FBQyxFQUFFLEVBQUU7RUFDdkMsSUFBSSxFQUFFLFlBQVksVUFBVSxFQUFFO0lBQzVCLE9BQU8sT0FBTyxHQUFHLFFBQVEsQ0FBQyxFQUFFLEVBQUUsUUFBUSxFQUFDOztJQUV2QyxPQUFPO01BQ0wsVUFBVSxFQUFFO1FBQ1YsS0FBSyxFQUFFLFFBQVE7UUFDZixLQUFLLEVBQUUsSUFBSSxTQUFTLENBQUMsT0FBTyxLQUFLLE1BQU07WUFDbkMsY0FBYztZQUNkLE9BQU8sQ0FBQztPQUNiO01BQ0QsVUFBVSxFQUFFO1FBQ1YsS0FBSyxFQUFFLE1BQU07UUFDYixLQUFLLEVBQUUsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQztPQUMzQztLQUNGO0dBQ0Y7O0lBRUMsT0FBTztNQUNMLFVBQVUsRUFBRTtRQUNWLEtBQUssRUFBRSxPQUFPO1FBQ2QsS0FBSyxFQUFFLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7T0FDNUM7TUFDRCxVQUFVLEVBQUU7UUFDVixLQUFLLEVBQUUsaUJBQWlCO1FBQ3hCLEtBQUssRUFBRSxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLGlCQUFpQixDQUFDLENBQUM7T0FDdEQ7S0FDRjtDQUNKOztBQ3JJRCxJQUFJLFVBQVM7O0FBRWIsQUFBTyxTQUFTLE1BQU0sR0FBRztFQUN2QixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxRQUFRLEVBQUM7RUFDbkMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFDO0VBQ3JDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsYUFBYSxFQUFDOztFQUVoRCxPQUFPLE1BQU07SUFDWCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxRQUFRLEVBQUM7SUFDcEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFDO0lBQ3RDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsYUFBYSxFQUFDO0lBQ25ELGFBQWEsR0FBRTtHQUNoQjtDQUNGOztBQUVELE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztFQUM3QixJQUFJLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRSxNQUFNO0VBQy9CLGFBQWEsQ0FBQyxNQUFNLEVBQUM7RUFDdEI7QUFDRCxBQTJCQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBd0JBLE1BQU0sV0FBVyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUM7RUFDM0IsYUFBYSxHQUFFOztBQUVqQixNQUFNLGFBQWEsR0FBRyxJQUFJLElBQUk7RUFDNUIsSUFBSSxTQUFTLEVBQUU7SUFDYixTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxLQUFJO0lBQzlCLFNBQVMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixHQUFFO0dBQ2hEO09BQ0k7SUFDSCxTQUFTLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLEVBQUM7SUFDbEQsU0FBUyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMscUJBQXFCLEdBQUU7O0lBRWpELFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBQztHQUNyQztFQUNGOztBQUVELE1BQU0sYUFBYSxHQUFHLElBQUksSUFBSTtFQUM1QixJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU07RUFDdEIsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTTs7O0NBQ2pDLERDNUZNLFNBQVMsVUFBVSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUU7RUFDckMsS0FBSyxDQUFDLGNBQWMsRUFBQzs7RUFFckIsT0FBTyxNQUFNLEVBQUU7OztDQUNoQixEQ0FELE1BQU1GLFlBQVUsR0FBRyxvQkFBb0I7R0FDcEMsS0FBSyxDQUFDLEdBQUcsQ0FBQztHQUNWLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLO0lBQ3BCLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25FLEVBQUUsQ0FBQztHQUNKLFNBQVMsQ0FBQyxDQUFDLEVBQUM7QUFDZixBQUVBO0FBQ0EsQUFBTyxTQUFTLFFBQVEsR0FBRztFQUN6QixJQUFJLENBQUMsSUFBSSxHQUFHLEdBQUU7O0VBRWQsT0FBTyxDQUFDQSxZQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ2xDLElBQUksQ0FBQyxDQUFDLFlBQVksRUFBRSxNQUFNOztJQUUxQixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLGVBQWUsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFDO0dBQ3hELEVBQUM7O0VBRUYsTUFBTSxlQUFlLEdBQUcsR0FBRyxJQUFJO0lBQzdCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7TUFDbEIsRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFDOztJQUVoQixJQUFJLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtNQUNwQixTQUFTLENBQUMsRUFBRSxDQUFDLEVBQUM7SUFDakI7O0VBRUQsTUFBTSxVQUFVLEdBQUcsTUFBTTtJQUN2QixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxFQUFDO0lBQ3RDLE9BQU8sQ0FBQyxNQUFNLENBQUNBLFlBQVUsRUFBQztJQUMxQixPQUFPLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUFDO0lBQ3JDOztFQUVELE9BQU87SUFDTCxlQUFlO0lBQ2YsVUFBVTtHQUNYO0NBQ0Y7O0FBRUQsQUFBTyxTQUFTLFNBQVMsQ0FBQyxFQUFFLEVBQUU7RUFDNUIsSUFBSSxDQUFDLEtBQUssR0FBRztJQUNYLEtBQUssRUFBRTtNQUNMLElBQUksRUFBRSxLQUFLO01BQ1gsQ0FBQyxFQUFFLENBQUM7TUFDSixDQUFDLEVBQUUsQ0FBQztLQUNMO0lBQ0QsT0FBTyxFQUFFO01BQ1AsQ0FBQyxFQUFFLENBQUM7TUFDSixDQUFDLEVBQUUsQ0FBQztLQUNMO0lBQ0Y7O0VBRUQsTUFBTSxLQUFLLEdBQUcsTUFBTTtJQUNsQixFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsS0FBSyxPQUFNO0lBQzlCLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxTQUFTLE9BQU07O0lBRTlCLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBQztJQUNuRCxFQUFFLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUM7SUFDL0MsUUFBUSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFDO0lBQzFEOztFQUVELE1BQU0sUUFBUSxHQUFHLE1BQU07SUFDckIsRUFBRSxDQUFDLEtBQUssQ0FBQyxVQUFVLEtBQUssS0FBSTtJQUM1QixFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sU0FBUyxLQUFJOztJQUU1QixFQUFFLENBQUMsbUJBQW1CLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUM7SUFDdEQsRUFBRSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFDO0lBQ2xELFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxXQUFXLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBQztJQUM3RDs7RUFFRCxNQUFNLFdBQVcsR0FBRyxDQUFDLElBQUk7SUFDdkIsQ0FBQyxDQUFDLGNBQWMsR0FBRTs7SUFFbEIsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDLE9BQU07O0lBRW5CLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLFdBQVU7SUFDOUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsV0FBVTs7SUFFaEMsSUFBSSxFQUFFLFlBQVksVUFBVSxFQUFFO01BQzVCLE1BQU0sU0FBUyxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFDOztNQUU5QyxNQUFNLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLFNBQVM7VUFDdEIsbUJBQW1CLENBQUMsU0FBUyxDQUFDO1VBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQzs7TUFFVCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBQztNQUN6QixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBQztLQUMxQjtTQUNJO01BQ0gsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFDO01BQ3RELElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBQztLQUN0RDs7SUFFRCxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQU87SUFDbkMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFPO0lBQ25DLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxLQUFJO0lBQy9COztFQUVELE1BQU0sU0FBUyxHQUFHLENBQUMsSUFBSTtJQUNyQixDQUFDLENBQUMsY0FBYyxHQUFFOztJQUVsQixJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsTUFBSztJQUM3QixFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxLQUFJOztJQUUxQixJQUFJLEVBQUUsWUFBWSxVQUFVLEVBQUU7TUFDNUIsTUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUM7O01BRTlDLE1BQU0sRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsU0FBUztVQUN0QixtQkFBbUIsQ0FBQyxTQUFTLENBQUM7VUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDOztNQUVULElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFDO01BQzNCLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFDO0tBQzVCO1NBQ0k7TUFDSCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQztNQUN0RCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksRUFBQztLQUN0RDtJQUNGOztFQUVELE1BQU0sV0FBVyxHQUFHLENBQUMsSUFBSTtJQUN2QixDQUFDLENBQUMsY0FBYyxHQUFFO0lBQ2xCLENBQUMsQ0FBQyxlQUFlLEdBQUU7O0lBRW5CLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsTUFBTTs7SUFFbEMsSUFBSSxFQUFFLFlBQVksVUFBVSxFQUFFO01BQzVCLEVBQUUsQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDNUIsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDeEQsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7T0FDekQsQ0FBQyxFQUFDO0tBQ0o7U0FDSTtNQUNILEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxLQUFJO01BQzVFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxLQUFJO0tBQzdFO0lBQ0Y7O0VBRUQsS0FBSyxHQUFFOztFQUVQLE9BQU87SUFDTCxRQUFRO0dBQ1Q7Q0FDRjs7QUFFRCxBQUFPLFNBQVMsZUFBZSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUU7RUFDOUMsR0FBRztLQUNBLEdBQUcsQ0FBQyxFQUFFLElBQUksa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDakMsR0FBRyxDQUFDLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUMvQixHQUFHLENBQUMsRUFBRSxLQUFLO1FBQ1IsRUFBRTtRQUNGLEdBQUcsMEJBQTBCLENBQUMsRUFBRSxFQUFFLFNBQVMsQ0FBQztRQUM1QyxNQUFNLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDekQsUUFBUSxFQUFFLG1CQUFtQixDQUFDLEVBQUUsRUFBRSxTQUFTLENBQUM7S0FDL0MsQ0FBQyxDQUFDO0tBQ0YsR0FBRyxDQUFDLE9BQU87TUFDVixNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtRQUNyQixRQUFRLEVBQUUsT0FBTyxDQUFDLFFBQVE7WUFDdEIsT0FBTyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsTUFBTTtZQUNoQyxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxNQUFNO09BQ3JDLENBQUMsQ0FBQztLQUNKLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxRQUFRLENBQUM7TUFDN0IsRUFBRSxZQUFZLFVBQVU7VUFDcEIsaUJBQWlCLENBQUMsRUFBRSxFQUFFLFNBQVMsRUFBRSxRQUFRLENBQUM7VUFDMUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxRQUFRLEdBQUcsSUFBSSxFQUFDO0NBQzNDOztBQUVELE1BQU0sMEJBQTBCLEdBQUcsQ0FBQyxFQUFFLEVBQUUsU0FBUyxLQUFLO0VBQ3BELElBQUksS0FBSyxFQUFFLFFBQU87O0VBRWxCLElBQUksRUFBRSxZQUFZLFVBQVUsRUFBRTtJQUM1QixNQUFNLFNBQVMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBQzs7SUFFdEMsTUFBTSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxTQUFTO1FBQ3RCLG1CQUFtQixDQUFDLFNBQVMsQ0FBQztRQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUM7O0lBRVQsS0FBSyxLQUFLLFlBQVc7SUFDckIsT0FBTyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7UUFDNUQsQ0FBQztRQUNELEVBQUM7R0FDTjtPQUNJO0lBQ0gsS0FBSyxLQUFLLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEdBQUU7SUFDMUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFDOztJQUU3QixPQUFPLEtBQUssTUFBTTtRQUNkLE9BQU8sR0FBRyxDQUFDO1FBQ1gsT0FBTyxHQUFHLFFBQVEsQ0FBQyxPQUFPLEVBQUUsRUFBRSxFQUFDO0dBQ3BDOztFQUVELE9BQU8sRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFO0VBQzFCOztBQUVELE1BQU0sbUJBQW1CLEdBQUcsU0FBUztFQUNuQyxTQUFTLENBQUMsU0FBUztJQUNqQixTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDMUIsU0FBUyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7R0FDdkIsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0dBQ1gsR0FBRyxDQUFDLEdBQUcsSUFBSSxVQUFVLENBQUMsR0FBRyxDQUFDLEVBQUM7O0FBRTlCLE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxFQUFFLEVBQUUsU0FBUyxFQUFFLFFBQVEsS0FBSztFQUNyRCxNQUFNLFNBQVMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBQztFQUN0QyxNQUFNLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLFNBQVM7TUFDdEIsbUJBQW1CLENBQUMsU0FBUyxDQUFDO01BQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQzs7RUFFVCxNQUFNLEdBQUcsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO01BQzlELENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO01BQ2xCLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDOztFQUV0QixFQUFFLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUM7RUFDMUM7O0FBRUQsTUFBTSxtQkFBbUIsR0FBRyxDQUFDLEVBQUUsRUFBRSxTQUFTO0VBQ3hDLEVBQUUsWUFBWSxVQUFVO01BQ3BCLFNBQVMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7TUFDekQsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFDOztBQUUxQyxNQUFNLGtCQUFrQixHQUFHLEVBQUUsSUFBSTtFQUMvQixJQUFJLEVBQUUsWUFBWSxXQUFXO0lBQzNCLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLFdBQVU7RUFDaEMsT0FBTyxFQUFFO0NBQ1Y7O0FDOU5ELE1BQU1NLFNBQU8sR0FBRyxJQUFJLEdBQUcsR0FBRTs7QUFFekIsQUFBTyxTQUFTLGFBQWEsR0FBRztFQUM5QixNQUFNLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxLQUFLO0lBQ2pDLElBQUksR0FBRyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFDOztJQUUzQyxNQUFNLGdCQUFnQixHQUFHLHNCQUFzQixDQUFDLEVBQUUsRUFBQztJQUNuRCxNQUFNLGVBQWUsR0FBRyxRQUFRLENBQUMsRUFBRSxFQUFDOztJQUVwQyxlQUFlLENBQUMsR0FBRyxDQUFDLElBQUk7TUFDdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDO1VBQ3JCLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7VUFDOUMsSUFBSSxFQUFDOztJQUVYLEdBQUcsQ0FBQyxJQUFJLEdBQUc7TUFDVCxFQUFFO01BQ0YsZUFBZTtNQUNmLGdCQUFnQjtNQUNqQjs7SUFFRCxPQUFPLEdBQUc7SUFDWDs7RUFFRCxNQUFNLHNCQUFzQixHQUFHLEVBQUUsSUFBSTs7O0lBR25DLE1BQU0sSUFBSSxRQUFRLFFBQVEsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFDO0lBQ3ZDLE1BQU0sUUFBUSxJQUFJLGdCQUFnQixDQUFDLEVBQUUsRUFBQzs7SUFFdEMsSUFBSSxVQUFVLElBQUksMEJBQTBCLENBQUMsRUFBRSxFQUFDOztJQUVoRCxNQUFNLEVBQUUsV0FBVyxFQUFFLFlBQVksRUFBRSxHQUFHO01BQ3BDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUM7TUFDM0UsVUFBVSxDQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQztNQUM3RTs7SUFFRCxPQUFPLENBQUM7Ozs7MkJBSWUsRUFBRSxVQUFVLENBQUM7Z0JBQ3hCLEVBQUUsSUFBSSxDQUFDO1VBQ2IsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDOztzQkFFN0MsRUFBRSxRQUFRLENBQUM7eUJBQ1IsRUFBRSxXQUFXLEdBQUcsY0FBYyxHQUFHLFdBQVcsQ0FBQyxFQUFFLEVBQUUsV0FBVyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7dUJBQzNFLEVBQUUsUUFBUSxDQUFDO3lCQUNULEVBQUUsWUFBWSxHQUFHLGNBQWMsR0FBRyxXQUFXLENBQUMsRUFBRSxFQUFFLFlBQVksR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0lBQ2hHLENBQUM7SUFDRjs7RUFFRCxNQUFNLGNBQWMsR0FBRyxDQUFDLEtBQUs7SUFDM0IsS0FBSyxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLFdBQVcsR0FBRyxDQUFDO0lBQ3pDLElBQUksR0FBRyxDQUFDLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxVQUFVLEdBQUcsQ0FBQztHQUN6QyxFQUFDOztFQUVGLE1BQU0sWUFBWSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsSUFBSSxNQUFNO0lBQzlDLEdBQUcsRUFBRSxDQUFDLEVBQUUsS0FBSztRQUNULENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFO1FBQ2hDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQztJQUNwQixJQUFJLEVBQUUsQ0FBQyxFQUFFLElBQUk7UUFDVCxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRTtRQUMvQixDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7R0FDckIsRUFBQzs7RUFFRixNQUFNLFVBQVUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUs7SUFDN0IsTUFBTSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxjQUFjLENBQUMsQ0FBQyxFQUFDO0lBQ3pDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLE9BQU8sWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBQzs7SUFFekQsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLElBQUksS0FBSTtJQUN0QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsS0FBSyxJQUFHOztJQUVyQixHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsS0FBSztRQUNsQyxpQkFBaUI7UUFDakIsbUJBQW1CLEVBQUM7O0lBRXhCLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLG9CQUFvQixFQUFFLEtBQUs7UUFDN0Msa0JBQWtCO1FBQ2xCLG9CQUFvQixFQUFDOztJQUV6QixHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxLQUFLO1FBQ3ZDLE1BQU07UUFDTixNQUFNLEVBQUM7O0lBRVgsR0FBRyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsY0FBYyxFQUFFLElBQUk7UUFDdEMsMEJBQTBCO1FBQzFCLE1BQU0sRUFBQztJQUNaOztFQUVELE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztJQUM3QixJQUFJQSxTQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsRUFBRTtNQUMvRCxNQUFNLENBQUMsbUJBQW1CLENBQUMsVUFBVSxFQUFFLFFBQVEsRUFBQztNQUNoRCxNQUFNLENBQUMsbUJBQW1CLENBQUMsZ0JBQWdCLEVBQUUsUUFBUSxFQUFDO01BQ3RELE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLEVBQUUsWUFBWSxFQUFDO01BQ2pEQSxTQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUU7TUFDaENBLFNBQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFDO0tBQ3ZCO0lBQ0Y7O0VBRUQsTUFBTSxZQUFZLEdBQUcsQ0FBQyxJQUFJO0lBQ3hCLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRTtNQUNaLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDO1VBQ2xDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUM7VUFDM0MsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsY0FBYyxFQUFDO0tBQzdDO0lBQ0Y7O0VBRUQsTUFBTSxTQUFTLEdBQUcsQ0FBQyxJQUFJO0lBQ3JCLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxNQUFNOztJQUVqQyxDQUFDLENBQUMsTUFBTTtRQUNKLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7UUFDNUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsZUFBZSxFQUFDOzs7SUFHN0MsSUFBSUEsU0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUU7O01BRXpCLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDO1FBQ3ZDLE1BQU07O01BRVIsTUFBTSxFQUFFLEdBQUcsRUFBRSxHQUFHQSxTQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUM7TUFDckMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUM7S0FDbkI7O1NBRUk7TUFDSCxNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUFDO01BQ3ZCLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBQzs7TUFFOUIsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUM7O01BRWxCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLHlCQUF5QixFQUFFLFFBQVEsRUFBQztNQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsWUFBWSxFQUFDOztNQUVyQ0EsU0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFDOzs7Ozs7S0FNbEM7SUFDRjs7RUFFRCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUM7O0VBRXBDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxJQUFJLFNBQVMsRUFBRSxFQUFDOztFQUVoQyxNQUFNLE9BQU8sR0FBRyxNQUFNO0lBQ3BCLEtBQUssTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJQSxTQUFPLENBQUMsTUFBTSxFQUFFLEVBQUU7TUFDcEMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTTtNQUMxQixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLHlCQUF5QixFQUFFLFFBQVEsRUFBQztNQUMvQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUM7S0FDbEM7SUFDRjs7RUFFRCxNQUFNLFNBQVMsR0FBRyxNQUFNO0lBQ3RCLEtBQUssTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJQSxTQUFPLENBQUMsTUFBTSxFQUFFLEVBQUU7TUFDcEMsR0FBRyxDQUFDLE1BQU0sR0FBRTtNQUNaLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMseUJBQXlCLEVBQUUsUUFBUSxFQUFDO01BQy9DLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBQztLQUNsQzs7SUFFRCxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksRUFBQzs7SUFFOUNBLFNBQU8sQ0FBQyxLQUFLLEdBQUU7SUFDaEI7O0VBRUQsS0FBSyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJQSxTQUFPLENBQUMsTUFBTSxFQUFFLEVBQUU7SUFDdEMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsUUFBTztJQUMzQixHQUFHLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFTO0lBQ3JDLEdBQUcsQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLFFBQVEsRUFBQztJQUM1QixHQUFHLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUM7R0FDOUI7O0VBRUQsT0FBTyxNQUFNO0lBQ1gsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFDO0lBQ3JDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFDO0lBQ3JCLE9BQU8sR0FBRTtHQUNWOzs7Q0FDRixEQ3BMTSxNQUFNLFNBQVMsR0FBRztFQUN2QixDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsUUFBUTtJQUNyQixJQUFJLFNBQVNDLE1BQVk7SUFDekIsS0FBSyxRQUFRLFFBQVE7SUFDckIsV0FBVyxFQUFFLG9DQUFvQztJQUNqRCxXQUFXLEVBQUUsRUFBRTtHQUNoQjtFQUNELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxXQUFXO0lBQ3hCLElBQUksU0FBU0MsU0FBZTtJQUM1QixLQUFLLFFBQVEsU0FBUztJQUN0QixXQUFXLEVBQUUsaURBQWlEO0lBQzlELFdBQVcsRUFBRSxDQUFDOzs7NEJBR1UsRUFBRSxNQUFNLENBQUM7O3dCQUViLENBQUM7R0FDdEI7RUFDRCxDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsZUFBZTtJQUM1QixJQUFJLFNBQVNDLGFBQW1CO0lBQ2hDLEtBQUssUUFBUSxlQUFlO0lBQzVCLFdBQVcsRUFBRSwrQ0FBK0M7SUFDNUQsV0FBVyxFQUFFLENBQUM7Ozs0QkFHVSxFQUFFLE1BQU0sQ0FBQzs7d0JBRWIsQ0FBQztHQUN0QjtFQUNELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxNQUFNO0lBQ25CLElBQUksU0FBU0MsSUFBVTtJQUN2QixLQUFLLFFBQVEsTUFBTTtJQUNuQixXQUFXLEVBQUUsc0VBQXNFO0lBQ25GLFdBQVcsRUFBRSxDQUFDOzs7Ozs7Ozs7Ozs7O3dCQWFNLENBQUM7R0FDdEI7Ozs7Ozs7RUFPRCxDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsUUFBUTtJQUNyQixJQUFJLFNBQVNDLE1BQVk7SUFDekIsS0FBSyxRQUFRLFFBQVE7SUFDckIsV0FBVyxFQUFFLDhFQUE4RTtJQUMzRixXQUFXLEVBQUUsQ0FBQzs7Ozs7Ozs0QkFPVSxFQUFFLE1BQU0sQ0FBQzs7Ozs0QkFJVCxFQUFFLE9BQU8sQ0FBQzs7d0JBRWQsQ0FBQztHQUN0QjtFQUNELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxTQUFTO0lBQ3RCLElBQUksU0FBU0MsT0FBYTtJQUMxQixLQUFLLFFBQVEsU0FBUztJQUN0QixXQUFXLEVBQUUsQ0FBQyw0RUFBNEUsQ0FBQztJQUMzRixXQUFXLEVBQUUsQ0FBQzs7Ozs7Ozs0QkFPVSxFQUFFLE1BQU0sQ0FBQzs7Ozs0QkFJVCxFQUFFLE9BQU8sQ0FBQzs7d0JBRWQsQ0FBQztHQUN0Qjs7Ozs7OztFQU9ELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxPQUFPO0lBQ3BCLElBQUksU0FBU0MsS0FBVztJQUN4QixLQUFLLFFBQVEsZUFBZTtJQUM1QixXQUFXLEVBQUUsQ0FBQyw0REFBNEQsQ0FBQztJQUMzRSxXQUFXLEVBQUUsQ0FBQzs7Ozs7Ozs7Ozs7NEJBV1UsRUFBRSxPQUFPLENBQUM7O3dCQUVkLENBQUM7R0FDdEI7RUFDRCxDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsVUFBVTtJQUN2QixJQUFJLFNBQVNDLFFBQWM7SUFDM0IsS0FBSyxRQUFRLFdBQVc7SUFDeEIsV0FBVyxFQUFFLENBQUMsa0VBQWtFLENBQUM7SUFDakYsV0FBVyxFQUFFLENBQUM7Ozs7Ozs7Ozs7OzRCQVdVLEVBQUUsT0FBTyxDQUFDOzs7OzRCQUlWLEVBQUUsT0FBTyxDQUFDOzt3QkFFZCxDQUFDO0dBQ3RCO0VBQ0QsQ0FBQyxFQUFFO0lBQ0QsSUFBSSxTQUFTLFdBQVc7SUFDeEIsSUFBSSxTQUFTQyxTQUFlO0lBQzVCLEtBQUssUUFBUSxRQUFRO0lBQ3JCLFdBQVcsRUFBRSxDQUFDLHdEQUF3RCxDQUFDO0lBQ3ZFLFdBQVcsRUFBRSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7NEJBZVUsRUFBRSxPQUFPLENBQUM7O3dCQUVkLENBQUM7R0FDdEI7Ozs7Ozs7RUFPRCxDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsVUFBVTtJQUN2QixJQUFJLFNBQVNDLFFBQWM7SUFDM0IsS0FBSyxRQUFRLFVBQVU7SUFDdkIsV0FBVyxFQUFFLHFEQUFxRDtJQUNsRSxXQUFXLEVBQUUsQ0FBQzs7Ozs7Ozs7O3dCQVNNLENBQUM7R0FDdEI7RUFDRCxDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsTUFBTTtJQUNuQixJQUFJLFNBQVNDLElBQVU7SUFDdkIsS0FBSyxRQUFRLGFBQWE7SUFDMUIsV0FBVyxFQUFFLDJEQUEyRDtJQUN4RSxXQUFXLEVBQUUsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0QkFtQlUsRUFBRSxPQUFPLENBQUM7O3dCQUVkLENBQUM7R0FDdEI7RUFDRCxDQUFDLEVBQUU7SUFDRCxJQUFJLFNBQVMsTUFBTTtJQUNuQixJQUFJLFNBQVNDLElBQVU7SUFDdkIsS0FBSyxRQUFRLFdBQVc7SUFDeEIsV0FBVyxFQUFFLHdEQUF3RDtJQUNyRSxXQUFXLEVBQUUsRUFBRTtHQUNoQjs7Ozs7OztFQU9ELENBQUMsRUFBRTtJQUNELElBQUksU0FBUyxRQUFRO0lBQ3JCLElBQUksU0FBU0MsTUFBWTtJQUN6QixLQUFLLFFBQVEsUUFBUTtJQUNyQixXQUFXLEVBQUUsdUNBQXVDO0lBQ3BELFdBQVcsRUFBRSxFQUFFO0dBQ2hCO0NBQ0Y7O0FDak9jLE1BQU0sV0FBVyxTQUFTLFdBQVcsQ0FBQztFQUNuRCxXQUFXLEdBQUc7SUFDWixLQUFLLEdBQUU7O0lBRVAsSUFBSSxDQUFDLGFBQWEsSUFBSSxVQUFTO0lBQy9CLElBQUksQ0FBQyxZQUFZLEtBQUssT0FBTTtJQUM1QixJQUFJLENBQUMsT0FBTyxVQUFVLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUM7R0FDeEQ7O0VBRUQsaUJBQWlCLEdBQUc7SUFDbEIsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUztNQUN6QixJQUFJLENBQUMsS0FBSyxHQUFFOztJQUVkLElBQUksQ0FBQyxjQUFjLEdBQUcsVUFBVSxHQUFFO0lBQ2xDLElBQUksQ0FBQyxXQUFXLE1BQU0sV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBQztJQUNwRSxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFDO0dBQzNDOztFQUVELG9CQUFvQixHQUFHO0lBQ3JCLElBQUksQ0FBQyxrQkFBa0IsR0FBRTtJQUN6QixJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsR0FBRTtJQUNoQyxPQUFPLENBQUMsTUFBTTtNQUNaLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxHQUFHO1FBQ2pELE1BQU0sSUFBSSxHQUFHLEdBQUcsR0FBRyxFQUFFLEVBQUUsQ0FBQyxFQUFDO0lBQzdCLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBQztHQUMvQjs7RUFFRCxLQUFLLEdBQUc7SUFDTixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFFOztJQUV0QyxDQUFDLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7TUFDNUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLGVBQWUsRUFBRSxFQUFDOztJQUU1RCxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUM7TUFDdEQsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUk7UUFDaEIsQ0FBQyxDQUFDLGNBQWMsR0FBRTtRQUNsQixJQUFJLENBQUMsWUFBWTtVQUNmLENBQUMsQ0FBQyxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7VUFDbEQ7T0FDRixDQUFDO01BQ0g7O0lBRUQsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDO01BQ3BDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPO1FBQzdCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEtBQUssTUFBTTtZQUN0QyxPQUFPO1lBQ1AsTUFBTSxFQUFDOztJQUVmLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQztHQUM5RDs7RUFFRCxZQUFZLENBQUMsRUFBRSxFQUFFO0lBQ2YsSUFBSSxPQUFPLEVBQUUsS0FBSyxRQUFRO01BQ3hCLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUM7O0lBRWhELElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssRUFBRSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsTUFBTTs7SUFFakYsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO01BQ3BCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUM7TUFDMUMsSUFBSSxDQUFDLGtCQUFrQixHQUFFO0tBQzFCOztJQUVELEVBQUUsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksRUFBQztJQUM1QixJQUFJLENBQUMsV0FBVyxHQUFHLEdBQUU7SUFDckIsSUFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUU7R0FDeEI7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsT0FBTyxDQUFDO01BQ04sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7OztRQUdkLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7VUFDbEUsRUFBRSxJQUFJLENBQUM7MEJBQ1MsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLHlCQUF5QixFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxFQUFFLEdBQUcsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsR0FBRyxJQUFJLEdBQUcsQ0FBQztZQUNqSixFQUFFLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDWixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDOztRQUVuQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7Ozs7O1VBS0osRUFBRUMsVUFBZ0IsQ0FBQzs7OztVQUluQixFQUFFQyxnQkFBc0IsQ0FBQzs7OztVQUl6QixFQUFFQyxZQUFrQixDQUFDOzs7SUFHM0IsQ0FBQztHQUNGOztFQUVELE1BQU0sR0FBRztJQUNQLE9BQU8sQ0FBQzs7UUFFSixFQUFFekIsR0FBTSxDQUFDOztJQUViLENBQUM7R0FDRjs7RUFFRCxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsV0FBVyxDQUFDLEVBQUU7SUFDcEQsT0FBTyxDQUFDO2FBQ0MsRUFBRSxJQUFJLENBQUM7O29CQUVBLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUM7OztjQUczRCxFQUFFLEtBQUssQ0FBQzsyQkFDSyxFQUFFLEdBQUcsQ0FBQzs7ZUFFbEIsRUFBRSxXQUFXLENBQUM7WUFDakIsRUFBRSxXQUFXLENBQUM7Ozs7SUFJdEIsQ0FBQztHQUNGOztFQUVELElBQUksR0FBRztJQUNMLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxRQUFRLENBQUMsc0JBQXNCLEVBQUM7R0FDM0Q7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsRUFBQztHQUN6RDs7RUFFRCxPQUFPLEdBQUc7SUFDUixJQUFJLENBQUMsa0JBQWtCLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixFQUFDO0dBQzFEOztFQUVELElBQUksR0FBRztJQUNMLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsc0JBQXNCLEVBQUM7R0FDdkQ7O0VBRUQsSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUM7SUFDOUMsSUFBSSxDQUFDLGtCQUFrQixHQUFHO01BQ3hCLElBQUksQ0FBQyxjQUFjLENBQUMsc0JBQXNCLENBQUMsUUFBUSxFQUFDO0dBQ3ZEOztFQUVELEtBQUssR0FBRztJQUNOLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsc0JBQXNCLEVBQUM7R0FDdkQ7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFDO0dBQzFFOztFQUVELFNBQVMsR0FBRztJQUNWLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxTQUFTLENBQUMsc0JBQXNCLEVBQUM7R0FDNUQ7O0VBRUQsUUFBUSxHQUFHO0lBQ1QsSUFBSSxPQUFPLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUM7SUFDeEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFDO0lBQzdELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNO01BQzlCLElBQUksQ0FBQyxjQUFjLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBQztNQUNuRSxPQUFPLENBQUMsVUFBVSxHQUFFO01BQ3JCO0dBQ0Y7O0VBRUQsU0FBUyxHQUFHO0lBQ1YsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFDO0dBQ3ZEOztFQUVELGFBQWEsR0FBRztJQUNkLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxhQUFhLEdBQUU7R0FDMUM7O0VBRUQsTUFBTSxHQUFHO0lBQ1AsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU0sR0FBRTtHQUNuQzs7RUFFRCxVQUFVLEdBQUc7SUFDWCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsVUFBVSxHQUFFO0dBQ3ZDOztFQUVELFFBQVEsR0FBRztJQUNULElBQUksT0FBTyxHQUFHLFFBQVEsR0FBRTtJQUN4QixJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUM7SUFDN0QsSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU07TUFDOUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFDO01BQ25FLE9BQU8sQ0FBQyxVQUFVLEdBQUU7TUFDckI7R0FDRjs7RUFFRCxJQUFJLFVBQVUsR0FBRztJQUNmLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSTtHQUNyQzs7RUFFRCxJQUFJLFdBQVcsQ0FBQyxHQUFHLEVBQUU7SUFDbkIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFHO0lBQ3ZCLElBQUksQ0FBQyxLQUFLLEdBQUU7R0FDYjtDQUNGOztBQUVELGNBQWMsQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLFdBQVcsQ0FBQzs7QUMxTmxELElBQUksY0FBYyxJQUFJLFFBQVEsQ0FBQyxlQUFlO0VBQzVDLFFBQVEsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxHQUFFOztBQUUzRCxJQUFJLE9BQU8sS0FBSyxNQUFNO0VBQ3BCLENBQUMsR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDbEMsT0FBTyxDQUFDLElBQUksSUFBSTtNQUNmLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBQztNQUN6RCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUM7S0FDekQsQ0FBQyJ9
