/*
 Copyright (c) 2012 Amazon.com, Inc. All rights reserved.         *
*/
(function(){window.addEventListener("s2k-automation-test",function(a){chrome.extension.sendRequest({action:"extract",selected:!1,preview:!1})})})();